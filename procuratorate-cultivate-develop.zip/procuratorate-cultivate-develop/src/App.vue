<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
.content-area {
  .ivu-card-body {
    padding: 20px;
  }
  .ivu-btn-large {
    height: 34px;
  }
  .ivu-table-cell div {
    .ivu-tooltip {
      width: 100%;
      height: $btn-height;
      display: flex !important;
      align-items: center;
    }
    .ivu-tooltip-rel {
      @extend .text-ellipsis;
    }
  }
  .ivu-input[disabled],
  .ivu-input-number-input[disabled] {
    color: #999;
  }
}
.ivu-table,
.ivu-modal-body,
.ivu-form-item-content,
.ivu-form .ivu-form-item-label {
  @extend .normal-font;
}
.ivu-form-item-error-tip {
  @extend .tip-font;
}
.ivu-form-item {
  &:not(.ivu-form-item-required) {
    margin-bottom: 20px;
  }
  &.ivu-form-item-required {
    margin-bottom: 20px;
  }
}
.ivu-date-picker-rel .ivu-input-wrapper {
  width: 211px;
}

pre {
  margin: 0;
  white-space: pre-wrap;
  tab-size: 4;
}
</style>
