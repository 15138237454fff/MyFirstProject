import Vue from 'vue'
import Router from 'vue-router'
import Index from './views/index.vue';
import store from './store/store';

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index,
      redirect: "/mySpace",
      children: [
        {
          path: 'homeNotice',
          name: 'homeNotice',
          component: () => import('./views/notice/homeNotice.vue'),
          meta: {
            alias: "/mySpace",
            title: "通知公告"
          }
        },
        {
          path: 'homeNoticeDetail/:id',
          name: 'homeNoticeDetail',
          component: () => import('./views/notice/homeNoticeDetail.vue'),
          meta: {
            alias: "/mySpace",
            title: "通知公告详情"
          },
          props: true
        },
        // 我的空间
        {
          path: 'mySpace',
          name: 'mySpace',
          component: () => import('./views/mySpace/mySpace.vue'),
          meta: {
            alias: "/mySpace",
            title: "我的空间",
            pageState: 1
          }
        },
        // 我的培训
        {
          path: 'myTrain',
          name: 'myTrain',
          component: () => import('./views/myTrain/myTrain.vue'),
          meta: {
            alias: "/myTrain",
            title: "我的培训",
            pageState: 1
          }
        },
        {
          path: 'myTrainDetail/:id',
          name: 'myTrainDetail',
          component: () => import('./views/myTrain/myTrainDetail.vue'),
          meta: {
            alias: "/myTrain",
            title: "培训详情",
            pageState: 1
          },
          props: true
        },
        // 我的学习
        {
          path: 'myStudy',
          name: 'myStudy',
          component: () => import('./views/myStudy/myStudy.vue'),
          meta: {
            alias: "/myStudy",
            pageState: 1
          }
        },
        {
          path: "myStudyDetail/:id",
          name: "myStudyDetail",
          component: () => import('./views/myStudy/myStudyDetail.vue'),
          meta: {
            alias: "/myStudy",
            title: "资源详情",
            pageState: 1
          },
          props: true
        },
        // 我的考试
        {
          path: 'myExam',
          name: 'myExam',
          component: () => import('./views/myExam/myExam.vue'),
          meta: {
            alias: "/myExam",
            pageState: 1
          }
        },
        {
          path: 'onlineExam/:id/:projectClassId',
          name: 'onlineExam',
          component: () => import('./views/myExam/onlineExam.vue'),
          meta: {
            alias: "/myExam",
            title: "在线考试",
            pageState: 1
          },
          props: true
        },
        {
          path: 'myExamDetail/:id',
          name: 'myExamDetail',
          component: () => import('./views/myExam/myExamDetail.vue'),
          meta: {
            alias: "/myExam",
            title: "试卷详情",
            pageState: 1
          },
          props: true
        },
        // 我的小结
        {
          path: 'mySummary',
          name: 'mySummary',
          component: () => import('./views/mySummary/mySummary.vue'),
          meta: {
            alias: "/mySummary",
            pageState: 1
          }
        },
        // 我的评教
        {
          path: 'myEvaluation',
          name: 'myEvaluation',
          component: () => import('./views/myEvaluation/myEvaluation.vue'),
          meta: {
            alias: "/myEvaluation",
            pageState: 1
          }
        },
        {
          path: 'onlineEvaluation/:id',
          name: 'onlineEvaluation',
          component: () => import('./views/myEvaluation/onlineEvaluation.vue'),
          meta: {
            alias: "/myEvaluation",
            title: "在线评教",
            pageState: 1
          },
          props: true
        },
        {
          path: 'myEvaluationDetail/:id',
          name: 'myEvaluationDetail',
          component: () => import('./views/myEvaluation/myEvaluationDetail.vue'),
          meta: {
            alias: "/myEvaluation",
            title: "评教详情",
            pageState: 1
          },
          props: true
        },
        // 我的请假
        {
          path: 'myLeave',
          name: 'myLeave',
          component: () => import('./views/myLeave/myLeave.vue'),
          meta: {
            alias: "/myLeave",
            pageState: 1
          }
        },
        // 资源中心
        {
          path: 'resourceCenter',
          name: 'resourceCenter',
          component: () => import('./views/resourceCenter/resourceCenter.vue'),
          meta: {
            alias: "/resourceCenter",
            pageState: 1
          }
        },
        {
          path: 'resourceCenterDetail/:id',
          name: 'resourceCenterDetail',
          component: () => import('./views/resourceCenter/resourceCenterDetail.vue'),
          meta: {
            alias: "/resourceCenter",
            title: "资源详情",
            pageState: 1
          },
          props: true
        },
        // 我的培训证书
        {
          path: 'myCredentials',
          name: 'myCredentials',
          component: () => import('./views/myCredentials/myCredentials.vue'),
          meta: {
            alias: "/myCredentials",
            pageState: 1
          }
        },
        // 教师端我的空间
        {
          path: 'teacherSpace',
          name: 'teacherSpace',
          component: () => import('./views/teacherSpace/teacherSpace.vue'),
          meta: {
            alias: "/teacherSpace",
            pageState: 2
          }
        },
        // 教师端我的培训
        {
          path: 'teacherTrain',
          name: 'teacherTrain',
          component: () => import('./views/teacherTrain/teacherTrain.vue'),
          meta: {
            alias: "/teacherTrain",
            pageState: 2
          }
        },
        // 教师端我的小结
        {
          path: 'teacherSummary',
          name: 'teacherSummary',
          component: () => import('./views/teacherSummary/teacherSummary.vue'),
          meta: {
            alias: "/teacherSummary",
            pageState: 2
          }
        },
        // 教师端我的课程
        {
          path: 'teacherCourse',
          name: 'teacherCourse',
          component: () => import('./views/teacherCourse/teacherCourse.vue'),
          meta: {
            alias: "/teacherCourse",
            pageState: 2
          }
        },
        {
          path: 'teacherCourseAdd',
          name: 'teacherCourseAdd',
          component: () => import('./views/teacherCourse/teacherCourseAdd.vue'),
          meta: {
            alias: "/teacherCourse",
            title: "添加",
            pageState: 2
          }
        },
        {
          path: 'teacherCourseModify/:id',
          name: 'teacherCourseModify',
          component: () => import('./views/teacherCourse/teacherCourseModify.vue'),
          meta: {
            alias: "/teacherCourse",
            title: "修改",
            pageState: 2
          },
          props: true
        },
        {
          path: 'teacherCourseDetail/:id',
          name: 'teacherCourseDetail',
          component: () => import('./views/teacherCourse/teacherCourseDetail.vue'),
          meta: {
            alias: "/teacherCourse",
            title: "课程详情",
            pageState: 2
          },
          props: true
        },
        {
          path: 'teacherCoursePaper/:id/:className',
          name: 'teacherCoursePaper',
          component: () => import('./views/teacherCourse/teacherCoursePaper.vue'),
          meta: {
            alias: "/teacherCourse",
            title: "考试试卷",
            pageState: 2
          },
          props: true
        },
        {
          path: 'teacherCoursePaperQuestion/:id/:className',
          name: 'teacherCoursePaperQuestion',
          component: () => import('./views/teacherCourse/teacherCoursePaperQuestion.vue'),
          meta: {
            alias: "/teacherCourse",
            title: "设置考试题目",
            pageState: 2
          },
          props: true
        },
        // 教师端我的案例
        {
          path: 'teacherCase',
          name: 'teacherCase',
          component: () => import('./views/teacherCase/teacherCase.vue'),
          meta: {
            alias: "/teacherCase",
            pageState: 2
          }
        },
        // 教师端我的资源
        {
          path: 'teacherResource',
          name: 'teacherResource',
          component: () => import('./views/teacherResource/teacherResource.vue'),
          meta: {
            alias: "/teacherResource",
            pageState: 2
          }
        },
        {
          path: 'teacherResourceDetail/:id',
          name: 'teacherResourceDetail',
          component: () => import('./views/teacherResource/teacherResourceDetail.vue'),
          meta: {
            alias: "/teacherResource",
            title: "资源详情",
            pageState: 2
          },
          props: true
        },
        // 教师端考试试题
        {
          path: 'teacherQuestions',
          name: 'teacherQuestions',
          component: () => import('./views/teacherQuestions/teacherQuestions.vue'),
          meta: {
            alias: "/teacherQuestions",
            pageState: 2
          }
        },
        {
          path: 'teacherQuestionsDetail',
          name: 'teacherQuestionsDetail',
          component: () => import('./views/teacherQuestions/teacherQuestionsDetail.vue'),
          meta: {
            alias: "/teacherQuestions",
            title: "添加",
            pageState: 2
          }
        },
        // 教师端统计分析
        {
          path: 'teacherAnalyse',
          name: 'teacherAnalyse',
          component: () => import('./views/teacherAnalyse/teacherAnalyse.vue'),
          meta: {
            alias: "/teacherAnalyse",
            pageState: 2
          }
        }
      ]
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('./views/login/login.vue')
    },
    {
      path: '/forget',
      name: 'forget',
      component: () => import('./views/login/forget.vue')
    }
  ]
})
// 可以拦截登录，如果未登陆，则重定向到'/login'页面
router.beforeEach((to, from, next) => {
  let isLogin = store.getters['skb/getLogin'],
    pageState = store.getters['skb/getPageState']
  if (!isLogin) {
    console.log("未登录")
    if (to.path !== '/login' && to.path !== '/forget') {
      next('/login')
      return
    }
    next()
  } else {
    console.log("已登录")
    if (to.path === '/login' || to.path === '/forget') {
      next(from.path)
      return
    }
    if (to.meta.pageState !== undefined && to.meta.pageState !== pageState) {
      if (pageState === 1) {
        next('/mySpace')
      } else {
        next('/teacherSpace')
      }
      return
    }
    next()
  }
  // if (to.path !== '/login' && to.path !== '/forget' && !isLogin) {
  //   next('/login');
  // } else if ((to.path === '/login' || to.path === '/forget') && isLogin) {
  //   next(from.path);
  // }  else {
  //   next()
  // }
});
export default router
