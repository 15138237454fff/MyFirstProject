<template>
  <div class="myHeaderNav">
    <ul class="nav-list">
      <template v-if="pageState !== 2">
        <li
          class="nav-item"
          v-for="(item, index) of navListForStudent"
          :key="index"
          :class="{ isActive: $route.meta.alias === item.path }"
        >
          <router-link :to="item.path">{{ item.name }}</router-link>
        </li>
      </template>
      <template v-else>
        <li
          class="nav-item"
          v-for="(item, index) of navListForTeacher"
          :key="index + 10"
          :class="{ isActive: $route.meta.alias === item.path }"
        >
          <router-link :to="item.path">{{ item.name }}</router-link>
        </li>
      </template>
    </ul>
  </div>
</template>
<script>
export default {
  name: "myHeaderNav",
  data() {
    return {
      navListForStudent: [
        { name: "我的空间", path: "/mySpace" },
        { name: "我的培训", path: "/myTrain" },
        { name: "我的学习", path: "/myStudy" },
        { name: "我的考试", path: "/myExam" },
        { name: "我的小结", path: "/mySummary" },
        { name: "我的评教", path: "/myEvaluation" },
        { name: "我的请假", path: "/myLeave" },
        { name: "资源中心", path: "/resourceCenter" },
        { name: "我的培训证书", path: "/myCredentials" }
      ],
      navListForTeacher: [
        { name: "我的空间", path: "/teacherSpace" },
        { name: "我的培训", path: "/teacherTrain" },
        { name: "我的小结", path: "/teacherSummary" },
        { name: "我的课程", path: "/teacherCourse" },
        { name: "我的案例", path: "/teacherCase" },
        { name: "我的资源", path: "/teacherResource" },
        { name: "考试试题", path: "/teacherQuestions" },
        { name: "统计分析", path: "/teacherAnalyse" }
      ]
    };
  },
  computed: {
    pageState() {
      return this.$store.getters["skb/getPageState"];
    }
  }
};
</script>
<style lang="scss" scoped>
.myHeaderNav {
  .nav-list {
    width: 100%;
    height: 50px;
    padding: 0 10%;
    display: flex;
    .nav-item {
      flex: 1;
      line-height: 50px;
      font-size: 16px;
      text-align: center;
      a {
        color: $bz-color;
        cursor: pointer;
        white-space: nowrap;
        outline: none;
      }
      &.isActive {
        a {
          color: $theme;
        }
        border-bottom: 2px solid $theme;
        background-image: linear-gradient(
          #fff 20%,
          rgba(24, 143, 150, 0.2) 100%
        );
      }
    }
  }
}
</style>
