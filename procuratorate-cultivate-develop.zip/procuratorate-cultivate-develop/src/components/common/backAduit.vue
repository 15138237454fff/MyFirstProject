<template>
  <div class="backAduit">
    <i-icon type="md-refresh-circle" :size="36" color="red" />
    <div class="aduit-text">
      <i-row :gutter="30" type="flex">
        <i-col>
          <span class="aduit-name"> 退回（{{ name }}）</span>
        </i-col>
        <i-col>
          <span class="aduit-tip"
            >{{ $tagTime(auditDate, "yyyy-MM:dd") }}
          </span>
        </i-col>
      </i-row>
      <i-row type="flex">
        <span class="aduit-tip text-ellipsis">退回原因：{{ comment }}</span>
      </i-row>
    </div>
  </div>
</template>
<script>
import { Icon, Row, Col } from "view-design";
export default {
  name: "backAduit",
  props: {
    name: {},
    comment: {},
    auditDate: {}
  },
  components: {
    "i-icon": Icon,
    "i-row": Row,
    "i-col": Col
  },
  mounted() {
    console.log(this.name);
  }
};
</script>
<style lang="scss" scoped>
.backAduit {
  height: 80px;
  padding: 10px;
  background: #fff;
  margin-top: $top;
  display: flex;
  .aduit-text {
    flex: 1;
    margin-left: 20px;
    span {
      line-height: 30px;
    }
  }
  .aduit-name {
    color: #000;
  }
  .aduit-tip {
    font-size: 12px;
    color: #999;
  }
}
</style>
