<template>
  <div class="resourceDetail">
    <div class="detail-left">
      <div v-if="isMV">
        <!-- <video ref="myVideo" controls class="my-video"></video> -->
        <div id="video" class="my-video"></div>
      </div>
      <div v-else class="my-pdf" ref="myPdf">
        <iframe
          :src="formData.resourceFile.url"
          ref="iframe"
          width="100%"
          height="100%"
          scroll="auto"
          class="iframe"
        ></iframe>
      </div>
    </div>
    <div class="detail-right">
      <div class="row">
        <span>资源名称：</span>
        <span>{{ formData.resourceName }}</span>
      </div>
      <div class="row">
        <span>资源类别：</span>
        <span>{{ formData.resourceType.join(" / ") }}</span>
      </div>
      <div class="row">
        <span>访问量：</span>
        <span>{{ formData.visits }}</span>
      </div>
      <div class="row attention">
        <span>关注量：</span>
        <span>{{ formData.attention }}</span>
        <i-button
          size="large"
          @click="clickCancelAttention"
          class="cancel-attention"
          v-if="formData.concerns === 1"
          >已关注</i-button
        >
        <i-button
          size="large"
          type="primary"
          ghost
          @click="clickAttention"
          v-else
          >关注+</i-button
        >
      </div>
      <div class="row">
        <span class="rate">评价星级：</span>
        <i-tooltip
          :max-width="400"
          theme="light"
          placement="bottom"
          :transfer="true"
        >
          <div slot="content">
            <div v-for="(val, ind) of formData.evaluateDetail" :key="ind">
              <i-rate disabled :value="ind + 1" />
              <span class="evaluate-count">{{ val }}人</span>
            </div>
          </div>
          <i-rate
            disabled
            :value="formData.evaluate ? formData.evaluate : 0"
            allow-half
          />
        </i-tooltip>
      </div>
      <div class="row" v-if="formData.isEvaluate === 0">
        <div class="my-rate">
          <span>留下你的星级评价：</span>
          <i-rate v-model="myRate" />
          <i-button size="large" type="primary" @click="clickMyRate"
            >发布</i-button
          >
        </div>
      </div>
      <div class="row my-progress" v-if="formData.concerns === 1">
        <span>学习进度：</span>
        <i-progress
          :percent="(formData.watchTime / formData.resourceExtent) * 100"
          hide-info
          :stroke-width="8"
        ></i-progress>
        <span class="step"
          >{{
            parseInt((formData.watchTime / formData.resourceExtent) * 100)
          }}%</span
        >
      </div>
    </div>
  </div>
</template>
<script>
import { Button, Tooltip, Rate, Progress } from "view-design";
export default {
  name: "resourceDetail",
  props: {
    id: {}
  },
  components: {
    "i-button": Button,
    "i-tooltip": Tooltip,
    "i-rate": Rate,
    "i-progress": Progress
  },
  data() {
    return {
      formData: {
        // 关注量
        attention: "",
        // 评价
        evaluate: 0,
        // 文件
        resourceFile: {
          fileName: "",
          url:
            "http://192.168.31.57:8888/group1/M00/00/0A/wKgfOV2gaeSAdeEDBk7iQwf4a3g211.pdf"
        },
        // 资源文件类型
        resourceFileType: "",
        // 是否关注
        concerns: 1,
        // 是否评价
        isEvaluate: 0,
        // 观看时长
        watchTime: 0,
        // 评价详情
        evaluateDetail: "",
        // 总时长/页数
        resourceExtent: 1,
        // 缩略图
        resourcePreview: "",
        // 资源名称
        resourceName: "",
        // 资源类别
        resourceType: [],
        // 访问量
        visits: ""
      },
      videoObject: {
        height: "100%",
        container: "#video", // “#”代表容器的ID，“.”或“”代表容器的class
        variable: "player", // 该属性必需设置，值等于下面的new chplayer()的对象
        autoplay: false, // 自动播放
        loaded: this.loadedHandler, // 监听播放器加载成功
        seek: 0,
        drag: "start", // 拖动的属性
        video: "" // 视频地址(必填)
      },
      player: null,
      myRate: 0,
      // pdf定时提交阅读记录的定时器id
      pdfTimer: null,
      isMV: false,
      // mvList:['rm','rmvb','mpeg1-4','mov','mtv', 'dat' ,'wmv','avi','3gp','amv','dmv','flv','mkv','mp4'],
      wordList: ["pdf", "doc", "docx"]
    };
  },
  mounted() {
    // 请求项目详情
    this.callBack();
    console.log(this.id);
  },
  methods: {
    // 返回列表方法
    goBack() {
      // 提交一次观看记录
      this.handleCommitWatch();
      this.$router.go(-1);
    },
    // 根据资源id回显数据
    callBack() {
      this.$axios
        .get(`/api/rcc/${this.id}/${this.isVisit}`)
        .then(res => {
          // 访问成功，继续请求不增加访问记录
          this.$store.commit("skb/updateIsVisit", 0);
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          if (data.evaluate === null) {
            this.formData.evaluate = 0;
          }
          this.isMV = !this.wordList.includes(
            data.resourceFileType.toLowerCase()
          );
          // 如果是视频资源
          if (this.isMV) {
            this.playVideo(data.resourceFile.url);
          } else {
            // 监听Pdf的查看时间
            this.handlePdfWatch();
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    playVideo(url) {
      this.$nextTick(() => {
        this.initCkplay(url);
      });
    },
    clickMyRate() {
      if (this.myRate === 0) {
        this.$Message.error("请选择评价分数后再尝试发布");
        return;
      }
      this.$axios
        .post(`/api/rcc/evaluate/${this.id}/${this.myRate}`)
        .then(res => {
          this.$Message.success("评价成功");
          this.formData.isEvaluate = 1;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 初始化ck播放器
    initCkplay(url) {
      this.videoObject.video = url;
      this.videoObject.seek = this.formData.watchTime;
      this.player = new ckplayer(this.videoObject);
    },
    // 播放器加载后会调用该函数
    loadedHandler() {
      console.log("视频加载完成");
      // 监听播放时间,addListener是监听函数，需要传递二个参数，'time'是监听属性，这里是监听时间，timeHandler是监听接受的函数
      this.player.addListener("pause", this.pauseHandler);
    },
    // 监听暂停事件
    pauseHandler() {
      // 获取当前播放时间
      let time = parseInt(this.player.time);
      // 如果时间有意义
      if (!time) {
        return;
      }
      console.log(time);
      this.$debounce(() => {
        this.handleCommitWatch(time);
      }, 1000);
    },
    // 监听pdf监听
    handlePdfWatch() {
      clearInterval(this.pdfTimer);
      this.pdfTimer = setInterval(() => {
        if (this.formData.watchTime === this.formData.resourceExtent) {
          clearInterval(this.pdfTimer);
        }
        this.handleCommitWatch(this.formData.watchTime + 1);
      }, 12000);
    },
    // 处理提交观看记录的方法
    handleCommitWatch(time) {
      // 如果比历史记录小不提交
      if (
        time < this.formData.watchTime ||
        this.formData.watchTime === this.formData.resourceExtent
      ) {
        console.log("无意义的观看记录");
        return;
      }
      console.log("记录观看记录");
      this.$axios
        .post(`/api/rcc/watch/${this.id}/${time}`)
        .then(res => {
          this.formData.watchTime = time;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击关注
    clickAttention() {
      console.log("点击关注");
      this.$axios
        .post(`/api/rcc/focus/${this.id}`)
        .then(res => {
          this.formData.concerns = 1;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击取消关注
    clickCancelAttention() {
      console.log("点击取消关注");
      this.$axios
        .post(`/api/rcc/unfollow/${this.id}`)
        .then(res => {
          this.formData.concerns = 0;
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  },
  destroyed() {
    clearInterval(this.pdfTimer);
    this.pdfTimer = null;
  },
  computed: {
    isVisit() {
      return this.$store.getters["skb/getIsVisit"];
    }
  }
};
</script>
<style lang="scss" scoped>
.resourceDetail {
  background: #fff;
  display: flex;
  padding: 20px;
  height: calc(100vh - 236px);
  .detail-left {
    flex: 1;
    height: 100%;
    padding-right: 10px;
    .my-video {
      width: 100%;
      height: calc(100vh - 276px);
    }
    .my-pdf {
      height: 100%;
    }
  }
  .detail-right {
    width: 300px;
    padding: 0px 20px;
    position: relative;
    // border-left: 1px solid $border-color;
    .row {
      display: flex;
      padding: 10px 0;
      border-top: 1px solid $border-color;
      & > span:first-child {
        width: 100px;
        padding-right: 10px;
        padding-left: 10px;
        white-space: nowrap;
        &.rate {
          line-height: 32px;
        }
      }
      .my-rate {
        background: rgba(200, 200, 200, 0.1);
        width: 100%;
        padding: 10px;
        position: relative;
        display: flex;
        flex-direction: column;
        /deep/ .ivu-btn {
          position: absolute;
          right: 10px;
          bottom: 10px;
        }
      }
    }
    .my-progress {
      border-bottom: 1px solid $border-color;
      position: absolute;
      bottom: 0;
      width: 260px;
      span:first-child {
        white-space: nowrap; //溢出不换行
      }
      .ivu-progress {
        padding-right: 10px;
        width: 130px;
      }
      .step {
        white-space: nowrap; //溢出不换行
      }
    }
    .attention {
      position: relative;
      /deep/ .ivu-btn {
        position: absolute;
        right: 0;
        bottom: 50%;
        transform: translateY(50%);
      }
      .cancel-attention {
        &:hover {
          color: inherit;
          border: 1px solid #ccc;
        }
        background: #ccc;
      }
    }
  }
  /deep/ .ivu-rate-star {
    margin-right: 0px;
  }
}
</style>
