<template>
  <div class="myContentHead">
    <div class="header">
      <div class="left">
        <slot name="left"></slot>
        <span class="current-path">&nbsp;/ {{ $route.meta.title }}</span>
      </div>
      <div class="right">
        <slot name="right"></slot>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "myContentHead"
};
</script>
<style lang="scss" scoped>
.myContentHead {
  .header {
    width: 100%;
    height: 36px;
    margin-bottom: $top;
    display: flex;
    .ivu-input-wrapper {
      margin-right: $left;
    }
    /deep/ .ivu-icon {
      font-size: 16px;
    }
  }

  .left {
    flex: 1;
    display: flex;
    .current-path {
      color: $theme;
      line-height: 36px;
    }
    a {
      line-height: 36px;
      color: #999;
    }
  }
  .right {
    flex: 2;
    text-align: right;
    & > div > :not(:last-child) {
      margin-right: $top;
    }
  }
}
</style>
