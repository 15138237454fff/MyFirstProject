<template>
  <div class="calendarPoptipContent">
    <ul>
      <li v-for="(item, index) of list" :key="index">
        <div class="title">{{ item.projectName }}</div>
        <div>培训课程：{{ item.className }}</div>
        <div>
          {{
            `${$tagTime(item.trainingTimeStart, "yyyy-MM-dd HH:mm")} ~
                ${$tagTime(item.trainingTimeEnd, "HH:mm")}`
          }}
        </div>
        <div>培训场地：{{ item.siteName }}</div>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: "calendarPoptipContent",
  props: {
    list: {}
  }
};
</script>
<style lang="scss" scoped>
.calendarPoptipContent {
  li:not(:last-child) {
    border-bottom: 1px solid #ccc;
  }
  li {
    padding-top: 5px;
    padding-bottom: 10px;
  }
  div {
    font-size: 12px;
    line-height: 20px;
  }
  .title {
    font-weight: bold;
    font-size: 14px;
    line-height: 40px;
  }
}
</style>
