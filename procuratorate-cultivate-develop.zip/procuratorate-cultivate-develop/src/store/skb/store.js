import router from '@/router'
export default {
  state: {
    // 表格高度
    tableHeight: null,
    // 是否登录
    isLogin: false,
    // 确认对话框参数
    confirmModalOption: {
      // 对话框显示状态
      modalVisiabal: false,
      // 标题内容
      title: "",
      // 内容
      msg: "",
      className: "modal-confirm",
      handleOk: () => { }
    },
    // 文档后缀类型列表
    wordList: ["pdf", "doc", "docx"],
    // 是否是从列表页访问详情数据
    isVisit: 0,
    // 用户状态 1 学员 2 讲师
    userStatus: 1,
    // 页面状态 1 学员页面 2 讲师页面
    pageState: 1,
    // 文件上传地址
    uploadUrl: "/api/upload",
    // 分页参数
    limitQuery: {
      pageNum: 1,
      pageSize: 15,
      query: "",
      startTime: "",
      endTime: "",
      category: ""
    }
  },
  getters: {
    // 外部获取表格高度
    getTableHeight(state) {
      return state.tableHeight
    },
    // 外部获取登录状态
    getLogin(state) {
      return state.isLogin
    },
    // 外部获取确认对话框参数
    getConfirmModalOption(state) {
      return state.confirmModalOption
    },
    // 获取文档后缀类型列表
    getWordList(state) {
      return state.wordList
    },
    getIsVisit(state) {
      return state.isVisit
    },
    // 获取用户类型
    getUserStatus(state) {
      return state.userStatus
    },
    // 获取页面状态
    getPageState(state) {
      return state.pageState
    },
    // 外部获取上传地址
    getUploadUrl(state) {
      return state.uploadUrl
    },
    // 外部获取列表查询参数
    getLimitQuery(state) {
      return state.limitQuery
    }
  },
  mutations: {
    // 更新表格高度
    updateTableHeight(state) {
      state.tableHeight = document.documentElement.clientHeight - 230
    },
    // 更新登录状态
    updateLogin(state, bool) {
      state.isLogin = bool
      if (!bool) {
        router.push("/login")
      }
    },
    // 更新对话框参数
    updateConfirmModalOption(state, obj) {
      let { modalVisiabal, title, handleOk, msg } = obj
      if (modalVisiabal !== undefined) {
        state.confirmModalOption.modalVisiabal = modalVisiabal
      }
      if (title) {
        state.confirmModalOption.title = title
      }
      if (handleOk) {
        state.confirmModalOption.handleOk = handleOk
      }
      if (msg) {
        state.confirmModalOption.msg = msg
      }
    },
    updateIsVisit(state, val) {
      state.isVisit = val
    },
    // 更新用户类型
    updateUserStatus(state, val) {
      state.userStatus = val
    },
    // 更新页面状态
    updatePageState(state, val) {
      state.pageState = val
    },
    updateLimitQuery(state, obj) {
      let { pageNum, pageSize, query, startTime, endTime, category } = obj
      if (pageNum !== undefined) {
        state.limitQuery.pageNum = pageNum
      }
      if (pageSize !== undefined) {
        state.limitQuery.pageSize = pageSize
      }
      if (query !== undefined) {
        state.limitQuery.query = query
      }
      if (startTime !== undefined) {
        state.limitQuery.startTime = startTime
      }
      if (endTime !== undefined) {
        state.limitQuery.endTime = endTime
      }
      if (category !== undefined) {
        state.limitQuery.category = category
      }
    }
  },
  actions: {

  },
  namespaced: true
}
