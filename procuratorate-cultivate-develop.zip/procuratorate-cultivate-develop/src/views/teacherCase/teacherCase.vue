<template>
  <div class="teacherCase">
    <div class="my-header">
      <div class="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入案例名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div class="right">
        <i-button size="large" @click="handleAdd" type="primary">添加</i-button>
        <i-button size="large" @click="clickDelete" type="error">删除</i-button>
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="option" slot-scope="{ row }">
          <span class="view" @click="viewCaseBaseInfo(row.caseId)">查看</span>
          <span>&nbsp;|&nbsp;</span>
          <span class="modify" @click="updateCaseBaseInfo(row.caseId)"
            >修改</span
          >
        </template>
        <template slot="option" slot-scope="{ row }">
          <span class="view" @click="viewCaseBaseInfo(row.caseId)">查看</span>
          <span>&nbsp;|&nbsp;</span>
          <span class="modify" @click="updateCaseBaseInfo(row.caseId)"
            >修改</span
          >
        </template>
      </i-table>
      <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
        <div class="modal-content">
          <template v-if="modalOption.key === 'view'">
            <div>
              <span>案例名称：</span>
              <span>{{ caseBase.caseName }}</span>
            </div>
            <div>
              <span>关联课程：</span>
              <span>{{ caseBase.caseClassName }}</span>
            </div>
            <div>
              <span>培训讲师：</span>
              <span>{{ listToString(caseBase.caseClassTeacherName) }}</span>
            </div>
            <div>
              <span>案例内容：</span>
              <!-- <span
                v-html="
                  this.$replaceAllStr(caseBase.caseContent, '\n', '<br/>')
                "
                class="text-content"
              ></span> -->
              <pre>{{ caseBase.caseContent }}</pre>
            </div>
            <div>
              <span>案例解答：</span>
              <!-- <span
                v-html="this.$replaceAllStr(caseBase.caseAnswer, '\n', '<br/>')"
                class="text-content"
              ></span> -->
              <pre>{{ caseBase.caseAnswer }}</pre>
            </div>
          </template>
          <template v-if="modalOption.key === 'add'">
            <i-form
              :model="caseBase"
              :label-width="100"
              class="case-form"
              ref="formValidate"
              :rules="ruleValidate"
            >
              <i-form-item label="案例名称：" required prop="caseName">
                <i-input
                  v-model="caseBase.caseName"
                  placeholder="请输入"
                  size="large"
                ></i-input>
              </i-form-item>
              <i-form-item label="关联课程：" required prop="caseClassId">
                <i-select
                  v-model="caseBase.caseClassId"
                  placeholder="请输入选择"
                  size="large"
                  filterable
                  :loading="searchLoading"
                  @on-change="searchClassChange"
                >
                  <i-option
                    v-for="(option, index) in classList"
                    :value="option.classId"
                    :key="index"
                    >{{ option.className }}</i-option
                  >
                </i-select>
              </i-form-item>
              <i-form-item label="培训讲师：">
                <span>{{ listToString(caseBase.caseClassTeacherName) }}</span>
              </i-form-item>
              <i-form-item label="案例内容：" required prop="caseContent">
                <i-input
                  v-model="caseBase.caseContent"
                  placeholder="请输入"
                  type="textarea"
                  size="large"
                  :autosize="{ minRows: 4, maxRows: 4 }"
                ></i-input>
              </i-form-item>
              <i-form-item label="案例解答：" required prop="caseAnswer">
                <i-input
                  v-model="caseBase.caseAnswer"
                  placeholder="请输入"
                  type="textarea"
                  size="large"
                  :autosize="{ minRows: 4, maxRows: 4 }"
                ></i-input>
              </i-form-item>
            </i-form>
          </template>
        </div>
        <p
          slot="footer"
          v-if="modalOption.key === 'modify' || modalOption.key === 'add'"
        >
          <i-button size="large" @click="modalOption.modalVisiabal = false"
            >取消</i-button
          >
          <i-button size="large" type="primary" @click="handleUpdate"
            >保存</i-button
          >
        </p>
      </my-modal>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Form,
  FormItem
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
export default {
  name: "teacherCase",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-form": Form,
    "i-form-item": FormItem,
    "my-modal": myModal,
    "my-pagination": myPagination
  },
  data() {
    return {
      loading: false,
      searchLoading: false,
      // 消息总数量
      msgCount: 0,
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "案例号",
          align: "center",
          key: "caseNum",
          tooltip: true,
          width: 160
        },
        { title: "案例名称", align: "center", key: "caseName", tooltip: true },
        {
          title: "关联课程",
          align: "center",
          key: "className",
          tooltip: true
        },
        { title: "操作", align: "center", slot: "option", width: 120 }
      ],
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-case-view"
      },
      // 表单数据
      caseBase: {
        // 案例解答
        caseAnswer: "",
        // 关联课程id
        caseClassId: "",
        // 案例内容
        caseContent: "",
        // 案例名称
        caseName: ""
      },
      // 列表选中ID
      selectedHistoryList: [],
      // 表单校验规则
      ruleValidate: {
        caseName: [
          {
            required: true,
            message: "案例名称不能为空,且长度不能超过20位",
            trigger: "blur",
            max: 20
          }
        ],
        caseClassId: [
          {
            required: true,
            message: "请选择关联课程",
            trigger: "change",
            type: "number"
          }
        ],
        caseContent: [
          {
            required: true,
            message: "案例内容不能为空,且长度不能超过500位",
            trigger: "blur",
            max: 500
          }
        ],
        caseAnswer: [
          {
            required: true,
            message: "案例解答不能为空,且长度不能超过500位",
            trigger: "blur",
            max: 500
          }
        ]
      },
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 课程下拉框
      classList: [],
      timer: null
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    //
    this.requireClassList();
  },
  methods: {
    listToString(list) {
      if (this.$isEmpty(list)) {
        return "";
      }
      return list.toString();
    },
    // 请求关联的课程列表
    requireClassList(query) {
      this.$axios
        .get(`/api/teacher/teacherClass`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("关联课程列表获取失败");
            return false;
          }
          this.classList = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 选择课程改变事件
    searchClassChange(value) {
      var item = this.classList.find(item => {
        if (item.classId === value) {
          return item;
        }
      });
      if (this.$isEmpty(item)) {
        this.caseBase.caseClassTeacherName = [];
        return;
      }
      this.caseBase.caseClassTeacherName = item.classTeacherVOS.map(item => {
        return item.name;
      });
    },
    // 添加按钮
    handleAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = "add";
      this.modalOption.className = "modal-case-add";
      this.modalOption.modalVisiabal = true;
    },
    // 提交添加数据
    submitSave() {
      this.$axios
        .post("/api/teacherCase/insert", this.caseBase)
        .then(res => {
          this.$Message.success("添加成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 删除按钮
    clickDelete() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 保存按钮
    handleUpdate() {
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          if (this.$isEmpty(this.caseBase.caseId)) {
            this.submitSave();
          } else {
            this.submitUpdate();
          }
        } else {
          this.$Message.error("请填写完整后再尝试保存！");
        }
      });
    },
    // 提交删除数据
    handleDelete() {
      this.$axios
        .delete("/api/case/delete", { data: this.selectedHistoryList })
        .then(res => {
          this.$Message.success("删除成功");
          this.selectedHistoryList = [];
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查看详情
    viewCaseBaseInfo(caseId) {
      this.queryDetailById(caseId);
      this.modalOption = {
        // 对话框显示状态
        modalVisiabal: true,
        // 标题内容
        title: "详情",
        key: "view",
        className: "modal-case-view"
      };
    },
    // 修改
    updateCaseBaseInfo(caseId) {
      this.queryDetailById(caseId);
      this.modalOption = {
        // 对话框显示状态
        modalVisiabal: true,
        // 标题内容
        title: "修改",
        key: "add",
        className: "modal-case-add"
      };
    },
    // 提交修改数据
    submitUpdate() {
      this.$axios.put("/api/case/update", this.caseBase).then(res => {
        this.$Message.success("修改成功");
        // 重新加载列表数据
        this.loadTable();
        // 隐藏Model
        this.modalOption.modalVisiabal = false;
      });
    },
    // 根据ID查询详情
    queryDetailById(caseId) {
      this.$axios
        .get(`/api/case/${caseId}`)
        .then(res => {
          this.caseBase = res.data.data;
          this.requireClassList();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 列表
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/teacherCase/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection.map(item => {
        return item.caseId;
      });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        if (this.modalOption.key === "add") {
          this.$refs.formValidate.resetFields();
        }
        // 清空表单
        this.clearCaseBase();
      }
    },
    // 下载模板
    handleDown() {
      this.$log.INFO("正在下载模板");
    },
    // 导入的方法
    handleInput() {
      this.$log.INFO("正在导入");
    },
    // 导出的方法
    handleOutput() {
      this.$log.INFO("正在导出");
    },
    // 处理下拉项点击事件的方法
    handleDropdownItemClick(name) {
      if (name === "input") {
        // 调用导入
        this.handleInput();
      } else {
        // 调用导出
        this.handleOutput();
      }
    },
    clearCaseBase() {
      this.caseBase = {
        // 案例解答
        caseAnswer: "",
        // 关联课程id
        caseClassId: "",
        // 案例内容
        caseContent: "",
        // 案例名称
        caseName: ""
      };
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 64;
    }
  }
};
</script>

<style lang="scss" scoped>
.teacherCase {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    .right > :not(:last-child),
    .left > :not(:last-child) {
      margin-right: $top;
    }
  }
  .detail {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .view {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
<style lang="scss">
.modal-case-view {
  .ivu-modal-body {
    // line-height: 40px !important;
    .modal-content {
      & > div {
        display: flex;
        line-height: $btn-height;
        &:not(:last-child) {
          margin-bottom: $top;
        }
        :first-child {
          width: 80px;
        }
        :last-child {
          width: 90%;
        }
      }
      .text-content {
        max-height: 150px;
        overflow: auto;
      }
    }
  }
}
.modal-case-add {
  /deep/ .ivu-select {
    width: 100% !important;
  }
  /deep/ .ivu-input-wrapper {
    width: 100% !important;
  }
}
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .ivu-date-picker:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .left {
    flex: 2 !important;
  }
  /deep/ .right {
    flex: 1 !important;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
    // max-width: 380px;
    // min-width: 320px;
  }
}
</style>
