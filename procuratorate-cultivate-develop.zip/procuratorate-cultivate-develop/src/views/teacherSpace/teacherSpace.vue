<template>
  <div class="teacherSpace">
    <i-row :gutter="20">
      <i-col :span="16">
        <i-card>
          <div class="user-info">
            <div class="left">
              <div class="avatar">
                <img :src="userInfo.photo" alt="头像" v-if="userInfo.photo" />
                <i-icon type="ios-contact" :size="80" v-else></i-icon>
              </div>
              <div>
                <p class="welcome">您好，{{ userInfo.name }}老师！</p>
                <p class="introduction">
                  {{ !userInfo.introducation ? "无" : userInfo.introducation }}
                </p>
              </div>
            </div>
            <div class="right"></div>
          </div>
        </i-card>
        <i-row :gutter="20">
          <i-col :span="12">
            <i-card class="summary">
              <p slot="title">
                <span>待参加的培训课程</span>
              </p>
              <p slot="extra">
                <router-link class="see-more" to="/teacherTrain"
                  >前往查看>></router-link
                >
              </p>
              <i-table
                :data="courseData"
                :columns="courseColOption"
                height="186"
              >
                <template slot-scope="{ row }" slot="course">
                  <i-tooltip
                    :content="
                      `${$tagTime(row.trainingTimeStart, 'yyyy-MM-dd HH:mm')} ~
                ${$tagTime(row.trainingTimeEnd, 'HH:mm')}`
                    "
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ $tagTime(row.trainingTimeStart, "yyyy-MM-dd HH:mm") }} ~
                    {{ $tagTime(row.trainingTimeEnd, "HH:mm") }}
                  </i-tooltip>
                </template>
              </i-table>
            </i-card>
          </i-col>
          <i-col :span="12">
            <i-card class="summary">
              <p slot="title">
                <span>待提交的培训小结</span>
              </p>
              <p slot="extra">
                <router-link class="see-more" to="/teacherSummary"
                  >前往填写>></router-link
                >
              </p>
              <i-table
                :data="summaryData"
                :columns="summaryColOption"
                height="186"
              >
                <template slot-scope="{ row }" slot="summaryTime">
                  <i-tooltip
                    :content="
                      `${$tagTime(
                        row.projetStartTime,
                        'yyyy-MM-dd'
                      )} 至 ${$tagTime(row.projetEndTime, 'yyyy-MM-dd')}`
                    "
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ $tagTime(row.projetStartTime, "yyyy-MM-dd") }} 至
                    {{ $tagTime(row.projetEndTime, "yyyy-MM-dd") }}
                  </i-tooltip>
                </template>
              </i-table>
            </i-card>
          </i-col>
        </i-row>
      </i-col>
      <i-col :span="8">
        <i-card class="teacher-plan">
          <p slot="title">
            <span>个人教学计划</span>
          </p>
          <p slot="extra">
            <i-date-picker
              v-model="limitQuery.startTime"
              type="month"
              style="width: 200px"
              format="yyyy-MM"
              @on-change="requireTeacherPlan"
            ></i-date-picker>
          </p>
          <div class="time-table">
            <table>
              <tr>
                <th>日</th>
                <th>一</th>
                <th>二</th>
                <th>三</th>
                <th>四</th>
                <th>五</th>
                <th>六</th>
              </tr>
              <tr
                v-for="(val, index) of Math.ceil(timeList.length / 7)"
                :key="index"
              >
                <td
                  v-for="(item, ind) of timeList.slice(
                    index * 7,
                    index * 7 + 7
                  )"
                  :key="ind"
                >
                  <template
                    v-if="
                      teacherPlan.some(el =>
                        $dateEqual(item.value, el.studyDay)
                      )
                    "
                  >
                    <div class="triangle" :class="greyFilter(item.value)"></div>
                    <i-poptip
                      trigger="click"
                      :transfer="true"
                      placement="bottom"
                    >
                      <div slot="content">
                        <calendar-poptip-content
                          :list="
                            teacherPlan.find(el =>
                              $dateEqual(item.value, el.studyDay)
                            ).calendarClassVOS
                          "
                        ></calendar-poptip-content>
                      </div>
                      <span>{{ item.label }}</span>
                      <span v-if="item.isToday">(今)</span></i-poptip
                    >
                  </template>
                  <template v-else>
                    <span>{{ item.label }}</span>
                    <span v-if="item.isToday">(今)</span>
                  </template>
                </td>
              </tr>
            </table>

            <span
              v-if="!teacherPlan.some(el => $dateEqual(new Date(), el))"
              style="color:#999"
              class="plan-tip"
            >
              您今天没有教学计划哦！
            </span>
          </div>
        </i-card>
      </i-col>
    </i-row>
    <i-row :gutter="20">
      <i-col :span="16">
        <i-card class="resource-center">
          <p slot="title">
            <span>个人教学资源排名</span>
          </p>
          <p slot="extra">
            <router-link class="see-more" to="/teacherResource"
              >我的资源>></router-link
            >
          </p>
          <ul>
            <li
              v-for="(item, index) of resourceData"
              :key="index"
              class="resource-item"
            >
              <div class="left">
                <div class="badge">
                  {{ index + 1 }}
                </div>
                <div class="preview">
                  <img :src="item.resourcePreview" />
                  <div class="preview-mock">
                    <img
                      src="../../assets/images/pdf.png"
                      v-if="wordList.includes(item.resourceFileType)"
                    />
                    <img src="../../assets/images/video.png" v-else />
                  </div>
                </div>
                <div class="resource-text">
                  <p>{{ item.resourceName }}</p>
                  <p>
                    资源类型：<span v-if="Array.isArray(item.resourceType)">{{
                      item.resourceType.join("/")
                    }}</span>
                  </p>
                </div>
              </div>
              <div class="right">
                <div class="resoure-data">
                  <p>
                    <i-icon type="md-eye" size="19" />
                    <span>{{ item.visits }}</span>
                  </p>
                  <p>
                    <i-icon type="md-star-outline" size="19" />
                    <span>{{ item.attention }}</span>
                  </p>
                </div>
              </div>
            </li>
          </ul>
        </i-card>
      </i-col>
      <i-col :span="8">
        <i-card class="notice">
          <p slot="title">
            <span>通知公告</span>
          </p>
          <p slot="extra">
            <router-link class="see-more" to="homeNotice"
              >查看更多>></router-link
            >
          </p>
          <ul class="msg-list">
            <li
              class="msg-item"
              v-for="(item, index) of noticeList"
              :class="{ isTop: item.stick === 1 }"
              :key="index"
              @click="goToNociceDetail(item.id)"
            >
              <span class="text-ellipsis">{{ item.title }}</span>
              <span class="time text-ellipsis">{{
                $tagTime(item.publishTime, "yyyy-MM-dd HH:mm")
              }}</span>
            </li>
          </ul>
        </i-card>
      </i-col>
    </i-row>
    <i-spin size="large" fix v-if="loading"></i-spin>
  </div>
</template>
<script>
import {
  Row,
  Col,
  Card,
  Icon,
  DatePicker,
  Table,
  Tooltip,
  Poptip,
  Spin
} from "view-design";
import calendarPoptipContent from "@/components/common/calendarPoptipContent";
export default {
  name: "teacherSpace",
  components: {
    "i-row": Row,
    "i-col": Col,
    "i-card": Card,
    "i-icon": Icon,
    "i-table": Table,
    "i-tooltip": Tooltip,
    "i-poptip": Poptip,
    "i-date-picker": DatePicker,
    "i-spin": Spin,
    "calendar-poptip-content": calendarPoptipContent
  },
  data() {
    return {
      loading: false,
      // 用户基本信息
      userInfo: {
        // 学员姓名
        name: "",
        // 个人简介
        introducation: "",
        // 学员照片
        photo: ""
      },
      // 指定月教学计划列表
      teacherPlan: [],
      // 培训小结
      courseData: [],
      courseColOption: [
        { title: "培训课程", align: "left", key: "className", tooltip: true },
        {
          title: "培训时间",
          align: "left",
          slot: "course"
        }
      ],
      // 培训小结
      summaryData: [],
      summaryColOption: [
        { title: "培训项目", align: "left", key: "projectName", tooltip: true },
        {
          title: "培训时间",
          align: "left",
          slot: "summaryTime"
        }
      ],
      // 通知公告列表
      noticeList: [],
      limitQuery: {
        startTime: new Date(),
        endTime: "",
        query: "",
        pageNum: "",
        pageSize: ""
      },
      // 教学资源
      resourceData: []
    };
  },
  created() {
    this.loading = true;
    Promise.all([
      // 请求用户基本信息
      this.requireUserInfo(),
      // 请求指定月个人教学计划
      this.requireTeacherPlan(),
      // 请求待参加的培训课程
      this.requireCourse(),
      // 请求待提交的培训小结
      this.requireSummary(),
      // 请求通知公告列表
      this.requireNoticeList(),
      // 请求教学资源推荐列表
      this.requireResourceList()
    ])
      .then(res => {
        this.loading = false;
      })
      .catch(err => {
        console.error(err.message);
        this.loading = false;
      });
  },
  methods: {
    // 请求用户基本信息的方法
    requireUserInfo() {
      return new Promise((resolve, reject) => {
        this.$axios
          .get("/api/teacherSpace/welcome")
          .then(res => {
            let data = res.data.data;
            if (this.$isEmpty(data)) {
              this.loading = false;
              console.error("用户基本信息获取失败");
              return;
            }
            this.userInfo = data;
            resolve();
          })
          .catch(error => {
            console.error(error.message);
            reject(error);
          });
      });
    },
    // 请求待参加的培训课程的方法
    requireCourse() {
      return new Promise((resolve, reject) => {
        this.$axios
          .get(`/api/teacherSpace/waitProjectClass/${3}`)
          .then(res => {
            let data = res.data.data;
            if (!Array.isArray(data)) {
              this.loading = false;
              console.error("待提交的培训小结列表获取失败");
              return;
            }
            this.courseData = data;
            resolve();
          })
          .catch(error => {
            console.error(error.message);
            reject(error);
          });
      });
    },
    // 请求待提交的培训小结的方法
    requireSummary() {
      return new Promise((resolve, reject) => {
        this.$axios
          .post(`/api/summary/lecturer/toSubmit/list`, {
            pageNum: 1,
            pageSize: 3
          })
          .then(res => {
            let data = res.data.data.list;
            if (!Array.isArray(data)) {
              this.loading = false;
              console.error("待提交的培训小结列表获取失败");
              return;
            }
            this.summaryData = data;
            resolve();
          })
          .catch(error => {
            console.error(error.message);
            reject(error);
          });
      });
    },
    // 请求指定月个人教学计划的方法
    requireTeacherPlan() {
      return new Promise((resolve, reject) => {
        this.$axios
          .post(`/api/teacherSpace/calendar`, this.limitQuery)
          .then(res => {
            let data = res.data.data;
            if (!Array.isArray(data)) {
              this.loading = false;
              console.error("指定月个人教学计划获取失败");
              return;
            }
            this.teacherPlan = data;
            resolve();
          })
          .catch(error => {
            console.error(error.message);
            reject(error);
          });
      });
    },
    greyFilter(val) {
      if (
        new Date(this.$tagTime(val, "yyyy-MM-dd 23:59:59")).getTime() <
        new Date().getTime()
      ) {
        return "grey";
      }
      return "";
    },
    // 请求通知公告列表的方法
    requireNoticeList() {
      return new Promise((resolve, reject) => {
        this.$axios
          .post(`/api/notice/home`, { pageNum: 1, pageSize: 5, query: "" })
          .then(res => {
            let data = res.data.data;
            if (!data || !Array.isArray(data.list)) {
              this.loading = false;
              console.error("通知公告列表获取失败");
              return false;
            }
            this.noticeList = data.list;
            resolve();
          })
          .catch(error => {
            console.error(error.message);
            reject(error);
          });
      });
    },
    // 前往查看通知详情
    goToNociceDetail(id) {
      this.$router.push(`/homeNoticeDetail/${id}`);
    },
    // 请求教学资源推荐列表的方法
    requireResourceList() {
      return new Promise((resolve, reject) => {
        this.$axios
          .post(`/api/library/lecturer/mine/list`, {
            pageNum: 1,
            pageSize: 3
          })
          .then(res => {
            let data = res.data.data.list;
            if (!Array.isArray(data)) {
              this.loading = false;
              console.error("待评价的培训课程列表获取失败");
              return;
            }
            this.resourceData = data;
            resolve();
          })
          .catch(error => {
            console.error(error.message);
            reject(error);
          });
      });
    }
  },
  filters: {},
  computed: {
    // 文档类型的后缀列表
    wordList() {
      return this.$store.getters["skb/getWordList"];
    },
    // 展示的时间列表
    timeList() {
      // 获取当月天数
      let countDay = this.$monthCalcDay(this.limitQuery.startTime),
        timeList = [],
        time = new Date(this.limitQuery.startTime),
        year = time.getFullYear(),
        month = time.getMonth() + 1,
        tableRowCount = 5;
      // 根据天数把自定义的对象放入列表中
      for (let i = 0; i < countDay; i++) {
        let tmpTime = new Date([year, month, i + 1].join("-"));
        timeList.push({
          label: i + 1,
          value: tmpTime.getTime(),
          isToday: this.$dateEqual(tmpTime, new Date())
        });
      }
      // 获取本月一号的星期数
      let day = new Date(timeList[0].value).getDay();
      if ((day === 5 && countDay > 30) || (day === 6 && countDay > 29)) {
        tableRowCount = 6;
      }
      // 根据星期数补充空白值，使日期跟星期对应
      for (let i = 0; i < day; i++) {
        timeList.unshift({ label: "", value: null, isToday: false });
      }
      // 剩下的表格补充完整
      for (let i = 0, len = tableRowCount * 7 - timeList.length; i < len; i++) {
        timeList.push({ label: "", value: null, isToday: false });
      }
      return timeList;
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherSpace {
  .user-info {
    display: flex;
    justify-content: space-between;
    .left {
      display: flex;
      align-items: flex-end;
      .welcome {
        font-size: 20px;
        font-weight: 500;
        line-height: 30px;
      }
      .introduction {
        line-height: 30px;
        color: #999;
      }
      .avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        overflow: hidden;
        margin-right: 20px;
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }
    }
  }
  .teacher-plan {
    height: 420px;
    /deep/ .ivu-card-extra {
      top: 10px;
    }
    .time-table {
      height: 246px;
      position: relative;
      tr {
        & > :first-child,
        & > :last-child {
          color: red;
        }
        th {
          height: 30px;
        }
        td {
          border: 1px solid $border-color;
          height: 30px;
          line-height: 30px;
          text-align: center;
          position: relative;
          &:hover {
            background: rgba(24, 143, 150, 0.1);
            cursor: pointer;
          }
          .ivu-poptip,
          /deep/ .ivu-poptip-rel {
            width: 100%;
            height: 100%;
          }
          .triangle {
            position: absolute;
            bottom: 0;
            right: 0;
            transform: translate(50%, 50%) rotate(45deg);
            border: 5px solid;
            border-color: red;
          }
          .grey {
            border-color: grey;
          }
        }
      }
      .plan-tip {
        display: block;
        color: #999;
        margin-top: 10px;
        position: absolute;
        bottom: 0;
      }
    }
  }
  .see-more {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
  .ivu-card-head p i,
  .ivu-card-head p span {
    font-size: 16px;
  }
  .ivu-card {
    margin-bottom: 20px;
  }
  .notice {
    height: 294px;
    overflow: auto;
    .msg-list {
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      height: 100%;
      .msg-item {
        display: flex;
        justify-content: space-between;
        line-height: 34px;
        height: 34px;
        cursor: pointer;
        &.isTop {
          background: url("../../assets/images/top.png") no-repeat 0px 0px;
          background-size: 30px;
        }
        span:first-child {
          flex: 2;
          padding-right: $left;
          text-indent: 1em;
        }
        .time {
          flex: 1;
          color: $bz-color;
          text-align: right;
        }
      }
    }
  }
  .resource-center {
    height: 294px;
    overflow: auto;
    .resource-item {
      display: flex;
      justify-content: space-between;
      &:not(:last-child) {
        margin-bottom: 10px;
      }
      .left {
        display: flex;
      }
      .right {
        display: flex;
      }
      .badge {
        background: #000;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        color: #fff;
        font-weight: 600;
        text-align: center;
        line-height: 18px;
        margin-right: 10px;
      }
      .preview {
        border-radius: 5px;
        width: 100px;
        height: 60px;
        overflow: hidden;
        position: relative;
        margin-right: 10px;
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .preview-mock {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.3);
          text-align: center;
          color: #fff;
          line-height: 60px;
          img {
            width: 24px;
            height: 24px;
            vertical-align: middle;
          }
        }
      }
      .resource-text {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        width: 320px;
        margin-right: 10px;
        p:first-child {
          font-weight: 600;
          word-break: break-all;
          text-overflow: ellipsis;
          display: -webkit-box; /** 对象作为伸缩盒子模型显示 **/
          -webkit-box-orient: vertical; /** 设置或检索伸缩盒对象的子元素的排列方式 **/
          -webkit-line-clamp: 2; /** 显示的行数 **/
          overflow: hidden; /** 隐藏超出的内容 **/
        }
        p:last-child {
          color: #999;
          font-size: 12px;
        }
      }
      .resoure-data {
        display: flex;
        p {
          @extend .text-ellipsis;
        }
        p:last-child {
          margin-left: 10px;
        }
        span {
          line-height: 24px;
          display: inline-block;
        }
        .ivu-icon {
          margin-right: 5px;
          line-height: 24px;
        }
      }
    }
  }
}
</style>
