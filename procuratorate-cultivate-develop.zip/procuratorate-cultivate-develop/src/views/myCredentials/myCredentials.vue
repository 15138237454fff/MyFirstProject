<template>
  <div class="myCredentials">
    <div class="content">
      <i-row class="card-list" :gutter="30" type="flex">
        <i-col :span="8" v-for="(item, index) of tableData" :key="index">
          <div class="my-card">
            <div class="photo">
              <!-- <img :src="item.photo" /> -->
              <img src="../../assets/images/credent.png" />
            </div>
            <div>
              <p>
                <img src="../../assets/images/credentials.png" alt="" />
                <span>{{ item.projectName }}</span>
              </p>
              <p>获得日期：{{ $tagTime(item.endTime, "yyyy.MM.dd") }}</p>
            </div>
            <i-icon
              :size="36"
              type="md-download"
              class="down-load"
              @click="clickDownLoad(item.id)"
            ></i-icon>
          </div>
        </i-col>
      </i-row>
      <i-spin size="large" fix v-if="loading"></i-spin>
    </div>
  </div>
</template>
<script>
import { Row, Col, Icon, Spin } from "view-design";
export default {
  name: "myCredentials",
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      iconImg: require("../../assets/images/train.png"),
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        startTime: "",
        endTime: ""
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  components: {
    "i-row": Row,
    "i-col": Col,
    "i-icon": Icon,
    "i-spin": Spin
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/training/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击下载证书
    clickDownLoad(id) {
      window.location.href = `/api/training/down/${id}`;
    },
    // 列表查询时的时间段改变的方法
    handleDatePickChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = arr[0];
      this.limitQuery.endTime = arr[1];
      this.initLoadTable();
    }
  }
};
</script>
<style lang="scss" scoped>
.myCredentials {
  .content {
    height: calc(100vh - 190px);
    padding-right: 10px;
    overflow-y: auto;
    overflow-x: hidden;
    position: relative;
    .card-list {
      .my-card {
        background: #fff;
        padding: 20px;
        display: flex;
        justify-content: flex-start;
        position: relative;
        .photo {
          width: 160px;
          height: 105px;
          border: 1px solid $border-color;
          margin-right: 20px;
          img {
            width: 100%;
            height: 100%;
            object-fit: contain;
          }
        }
        .down-load {
          position: absolute;
          right: 20px;
          top: 20px;
          cursor: pointer;
        }
        p:first-child {
          color: #333;
          font-weight: bold;
          font-size: 16px;
          line-height: 40px;
          width: 200px;
          height: 70px;
          word-break: break-all;
          text-overflow: ellipsis;
          display: -webkit-box; /** 对象作为伸缩盒子模型显示 **/
          -webkit-box-orient: vertical; /** 设置或检索伸缩盒对象的子元素的排列方式 **/
          -webkit-line-clamp: 2; /** 显示的行数 **/
          overflow: hidden; /** 隐藏超出的内容 **/
          img {
            width: 34px;
            vertical-align: middle;
            margin-right: 5px;
          }
        }
        p:last-child {
          color: #999;
          line-height: 40px;
          font-size: 12px;
          width: 200px;
          @extend .text-ellipsis;
        }
      }
    }
    /deep/ .ivu-row-flex {
      margin-bottom: -30px;
      .ivu-col {
        margin-bottom: 30px;
      }
    }
  }
}
</style>
