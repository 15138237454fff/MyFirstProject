<template>
  <div class="homeNotice">
    <my-content-head>
      <div slot="left">
        <router-link to="/mySpace">我的空间</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="title">通知通告</div>
      <ul class="notice-list">
        <li
          class="msgItem"
          v-for="(item, index) of noticeList"
          :key="index"
          @click="goDetail(item.id)"
        >
          <span class="msg">· {{ item.title }}</span>
          <span class="time">{{
            $tagTime(item.publishTime, "yyyy-MM-dd HH:mm")
          }}</span>
        </li>
      </ul>
      <my-pagination
        @paginate="handlePaginate"
        v-bind="limitQuery"
        :msgCount="msgCount"
      ></my-pagination>
    </div>
  </div>
</template>
<script>
import { Button } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "homeNotice",
  components: {
    "i-button": Button,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      noticeList: [],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/mySpace");
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post(`/api/notice/home`, this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.noticeList = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 前往查看通知详情
    goDetail(id) {
      this.$router.push(`/homeNoticeDetail/${id}`);
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.homeNotice {
  .content {
    border-top: 1px solid $border-color;
    padding: 0 20px;
    height: calc(100vh - 224px);
    overflow: auto;
    background: #fff;
    position: relative;
    .title {
      font-weight: 900;
      width: 100%;
      text-align: left;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .notice-list {
      height: calc(100vh - 358px);
      overflow: auto;
    }
    .msgItem {
      height: 44px;
      line-height: 44px;
      border-bottom: 1px solid $border-color;
      width: 100%;
      display: flex;
      justify-content: space-between;
      cursor: pointer;
    }
    .time {
      color: $bz-color;
    }
  }
  .back {
    background: #fff;
  }
}
</style>
