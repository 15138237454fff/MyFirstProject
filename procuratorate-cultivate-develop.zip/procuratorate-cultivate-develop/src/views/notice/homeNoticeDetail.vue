<template>
  <div class="homeNotice">
    <my-content-head>
      <div slot="left">
        <router-link to="/mySpace">我的空间</router-link>
        <router-link to="/homeNotice">&nbsp;/&nbsp;通知公告</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="title">·{{ noticeDetail.title }}·</div>
      <div class="notice-content" v-html="noticeDetail.content"></div>
      <div class="attachment">
        <span>相关附件：</span>
        <span v-for="(item, index) of noticeDetail.attachment" :key="index"
          ><a :href="item.url" target="_blank" :download="item.fileName">{{
            item.fileName
          }}</a></span
        >
      </div>
    </div>
  </div>
</template>
<script>
import { Button } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "homeNotice",
  props: {
    id: {}
  },
  components: {
    "i-button": Button,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      noticeDetail: {
        // 附件
        attachment: [],
        // 正文
        content: "",
        // 标题
        title: ""
      }
    };
  },
  mounted() {
    // 请求通知详情数据
    this.requireNoticeDetail();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.go(-1);
      // this.$router.push("/homeNotice");
    },
    requireNoticeDetail() {
      // 列表加载状态
      // 发送请求列表数据的请求
      this.$axios
        .get(`/api/notice/${this.id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.noticeDetail = data;
          Object.keys(this.noticeDetail).forEach(key => {
            this.noticeDetail[key] = data[key];
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.homeNotice {
  .content {
    border-top: 1px solid $border-color;
    padding: 0 20px 20px;
    background: #fff;
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .notice-content {
      height: calc(100vh - 358px);
      padding-top: 20px;
      padding-right: 10px;
      overflow: auto;
    }
    .attachment {
      padding-top: $top;
      a {
        cursor: pointer;
        text-decoration: underline;
        color: $theme;
        margin-right: 20px;
      }
    }
  }
  .back {
    background: #fff;
  }
}
</style>
