<template>
  <div class="teacherResource">
    <div class="my-header">
      <div class="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入资源名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-cascader
          size="large"
          v-model="limitQuery.category"
          :data="moreCategoryList"
          @on-change="handleCascaderChange"
          change-on-select
          :clearable="false"
        ></i-cascader>
      </div>
      <div class="right">
        <i-button size="large" @click="handleAdd" type="primary">添加</i-button>
        <i-button size="large" @click="clickDelete" type="error">删除</i-button>
        <i-button size="large" @click="clickAduit" type="primary" ghost
          >提交审核</i-button
        >
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="evaluate" slot-scope="{ row }">
          <i-tooltip
            max-width="300"
            theme="light"
            placement="bottom"
            :transfer="true"
          >
            <div slot="content">
              <div v-for="(item, index) of row.evaluateDetail" :key="index">
                <i-rate disabled :value="index + 1" />
                <span class="evaluate-count">{{ item }}人</span>
              </div>
            </div>
            <i-rate
              disabled
              :value="row.evaluate ? row.evaluate : 0"
              allow-half
            />
          </i-tooltip>
        </template>
        <template slot="status" slot-scope="{ row }">
          <span :class="row.status | statusClassFilter">{{
            row.status | statusValueFilter
          }}</span>
        </template>
        <template slot="option" slot-scope="{ row }">
          <span class="view" @click="viewLibraryInfo(row.id)">查看</span>
          <span>&nbsp;|&nbsp;</span>
          <span
            class="modify"
            @click="updateLibraryInfo(row.id)"
            v-if="row.status !== 0"
            >修改</span
          >
          <span class="disabled" v-else>修改</span>
        </template>
      </i-table>
      <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
        <div class="modal-content">
          <template>
            <i-form
              :model="resourceLibrary"
              :label-width="100"
              class="library-form"
              ref="formValidate"
              :rules="ruleValidate"
            >
              <i-form-item label="资源名称：" required prop="resourceName">
                <i-input
                  v-model="resourceLibrary.resourceName"
                  placeholder="请输入"
                  size="large"
                ></i-input>
              </i-form-item>
              <i-form-item label="资源类别：" required prop="resourceType">
                <i-cascader
                  size="large"
                  v-model="resourceLibrary.resourceType"
                  :data="categoryList"
                ></i-cascader>
              </i-form-item>
              <i-form-item label="上传资源：" required prop="resourceFile">
                <div
                  v-if="resourceLibrary.resourceFile.url !== ''"
                  class="resource-file"
                >
                  <a
                    :href="resourceLibrary.resourceFile.url"
                    target="_blank"
                    class="attachment"
                    :download="resourceLibrary.resourceFile.fileName"
                    >{{ resourceLibrary.resourceFile.fileName }}</a
                  >
                  <span @click="removeFile">×</span>
                </div>
                <i-upload
                  v-else
                  :action="uploadUrl"
                  :on-success="fileUploadSucess"
                  ref="upload"
                  type="drag"
                  :before-upload="handleBeforeUpload"
                  :on-error="handleErrorUpload"
                  :on-remove="removeFile"
                  :on-format-error="handleFormatError"
                  :show-upload-list="false"
                  :format="uploadFormat"
                >
                  <div style="padding:10px 0;">
                    <i-icon
                      type="ios-cloud-upload"
                      size="52"
                      style="color: #3399ff"
                    ></i-icon>
                    <p>点击上传资源</p>
                    <p v-if="resourceLibrary.resourceFile.url !== ''">
                      {{ resourceLibrary.resourceFile.fileName }}
                    </p>
                    <i-spin size="large" fix v-if="spinShow"></i-spin>
                  </div>
                </i-upload>
              </i-form-item>
            </i-form>
          </template>
        </div>
        <p slot="footer">
          <i-button size="large" @click="modalOption.modalVisiabal = false"
            >取消</i-button
          >
          <i-button size="large" type="primary" @click="handleUpdate()"
            >保存</i-button
          >
        </p>
      </my-modal>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      v-bind="limitQuery"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import {
  Table,
  Input,
  Button,
  Rate,
  Upload,
  Icon,
  Spin,
  Form,
  FormItem,
  Tooltip,
  Cascader
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
export default {
  name: "teacherResource",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-rate": Rate,
    "i-icon": Icon,
    "i-upload": Upload,
    "i-spin": Spin,
    "i-tooltip": Tooltip,
    "i-cascader": Cascader,
    "my-modal": myModal,
    "my-pagination": myPagination
  },
  data() {
    return {
      // 加载动画显示状态
      spinShow: false,
      // // 错误信息显示状态
      // showRuleMessage: false,
      loading: false,
      // 消息总数量
      msgCount: 0,
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "资源名称",
          align: "center",
          key: "resourceName",
          tooltip: true
        },
        {
          title: "资源类别",
          align: "center",
          key: "resourceType",
          // tooltip: true
          render: (h, params) => {
            let type = params.row.resourceType;
            if (!Array.isArray(type)) {
              type = [];
            }
            return h("span", type.join(" / "));
          }
        },
        {
          title: "访问量",
          align: "center",
          key: "visits",
          tooltip: true,
          width: 120
        },
        {
          title: "关注量",
          align: "center",
          key: "attention",
          tooltip: true,
          width: 120
        },
        { title: "评价星级", align: "center", slot: "evaluate", width: 140 },
        { title: "状态", align: "center", slot: "status", width: 120 },
        { title: "操作", align: "center", slot: "option", width: 120 }
      ],
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-resource-library"
      },
      // 表单校验规则
      ruleValidate: {
        resourceName: [
          {
            required: true,
            message: "请输入资源名称,长度不能超过20位",
            trigger: "blur",
            max: 20
          }
        ],
        resourceType: [
          {
            required: true,
            message: "请选择资源类别",
            trigger: "change",
            type: "array"
          }
        ],
        resourceFile: [
          {
            required: true,
            message: "请上传资源文件",
            trigger: "blur",
            validator: (rule, value, callback) => {
              this.$log.INFO("验证资源");
              if (this.$isEmpty(this.resourceLibrary.resourceFile.url)) {
                callback(new Error("请上传资源文件"));
              } else {
                callback();
              }
            }
          }
        ]
      },
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        category: [""]
      },
      // 资源库模型
      resourceLibrary: {
        // 文件对象
        resourceFile: {
          fileName: "",
          url: ""
        },
        // 时长
        resourceExtent: "",
        // 预览图
        resourcePreview: "",
        // 资源名称
        resourceName: "",
        // 资源类别
        resourceType: []
      },
      // 需要提醒的文档类型
      noticeWordList: ["doc", "docx"],
      uploadFormat: [
        "pdf",
        "doc",
        "docx",
        "rm",
        "rmvb",
        "mpeg1-4",
        "mov",
        "mtv",
        "dat",
        "wmv",
        "avi",
        "3gp",
        "amv",
        "dmv",
        "flv",
        "mkv",
        "mp4"
      ],
      // 资源类别
      categoryList: [],
      // 待审核条数
      auditCount: 0,
      // 选中数据
      selectedHistoryList: []
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
      // 查询资源类别
      this.queryResoureType();
    });
  },
  methods: {
    handleFormatError() {
      this.$Message.error("请上传视频文档类型文件！");
      this.spinShow = false;
    },
    // 文件移除事件
    removeFile() {
      this.resourceLibrary.resourceFile = {
        fileName: "",
        url: ""
      };
      this.$log.INFO("移除成功");
    },
    // 文件成功上传事件
    fileUploadSucess(response, file, fileList) {
      if (!response) {
        this.$Message.error("文件上传失败，请重试");
        this.spinShow = false;
        return;
      }
      this.resourceLibrary.resourceFile = response.data;
      this.resourceLibrary.resourceExtent = response.data.resourceExtent;
      this.resourceLibrary.resourcePreview = response.data.resourcePreview;
      this.spinShow = false;
    },
    // 上传失败事件
    handleErrorUpload() {
      this.$Message.error("文件上传失败，请重试");
      this.spinShow = false;
    },
    // 文件开始上传前的事件
    handleBeforeUpload(file) {
      this.spinShow = true;
      let fileName = file.name,
        suffix = fileName.split(".")[1];
      if (this.noticeWordList.includes(suffix)) {
        this.$Message.info({
          content: `上传了${suffix}格式的文件，需要等待系统自动转为pdf格式文件`,
          duration: 10
        });
      }
    },
    // 添加按钮
    handleAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = "add";
      this.modalOption.className = "modal-resource-library";
      this.modalOption.modalVisiabal = true;
    },
    // 删除按钮
    clickDelete() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除资源
    handleDelete() {
      this.$axios
        .delete("/api/library/lecturer", { data: this.selectedHistoryList })
        .then(res => {
          this.$Message.success("删除成功");
          this.selectedHistoryList = [];
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击提交审核
    clickAduit() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "提交审核",
        msg: "确定提交所选资源？",
        modalVisiabal: true,
        handleOk: this.handleSubmitAduit
      });
    },
    // 提交审核
    handleSubmitAduit() {
      this.$axios
        .put("/api/library/lecturer/submit", this.selectedHistoryList)
        .then(res => {
          this.$Message.success("提交成功");
          this.selectedHistoryList = [];
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查询资源类别
    queryResoureType() {
      this.$axios
        .get("/api/param/select/XP-002")
        .then(res => {
          let data = res.data.data;
          // 数据格式化
          data = data.map(obj => {
            return {
              label: obj.title,
              value: obj.title,
              children: obj.children.map(el => {
                return { value: el, label: el };
              })
            };
          });
          console.log(data);
          this.categoryList = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 表单保存
    handleUpdate() {
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          if (this.$isEmpty(this.resourceLibrary.id)) {
            this.submitSaveInfo();
          } else {
            this.submitUpdateInfo();
          }
        } else {
          this.$Message.error("请填写完整后再尝试保存！");
        }
      });
    },
    // 提交修改信息
    submitUpdateInfo() {
      let tmpObj = Object.assign({}, this.resourceLibrary);
      this.$axios
        .put(`/api/library/lecturer/${this.resourceLibrary.id}`, tmpObj)
        .then(res => {
          this.$Message.success("修改成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 提交保存信息
    submitSaveInfo() {
      let tmpObj = Object.assign({}, this.resourceLibrary);
      this.$axios
        .post("/api/library/lecturer", tmpObj)
        .then(res => {
          this.$Message.success("添加成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 修改
    updateLibraryInfo(id) {
      // 查询详情
      this.queryDetailById(id);
    },
    // 根据ID查询详情
    queryDetailById(id) {
      this.$axios
        .get(`/api/library/${id}`)
        .then(res => {
          let data = res.data.data;
          // data.resourceType = [data.resourceType];
          this.resourceLibrary = data;
          this.modalOption = {
            // 对话框显示状态
            modalVisiabal: true,
            // 标题内容
            title: "修改",
            key: "modify",
            className: "modal-resource-library"
          };
        })
        .catch(error => {
          console.error(error.message);
        });
    },

    // 查看
    viewLibraryInfo(id) {
      this.$router.push(`/teacherResourceDetail/${id}`);
    },
    // 监听级联选择器的变化
    handleCascaderChange(val) {
      this.limitQuery.category = val;
      this.initLoadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 列表
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      let tmpObj = Object.assign({}, this.limitQuery);
      // 取出资源类别并覆盖原值
      tmpObj.category = tmpObj.category[tmpObj.category.length - 1];
      this.$axios
        .post("/api/library/lecturer/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection.map(item => {
        return item.id;
      });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    clearFormData() {
      // 重置表单
      this.$refs.formValidate.resetFields();
      this.resourceLibrary = {
        // 文件对象
        resourceFile: {
          fileName: "",
          url: ""
        },
        // 时长
        resourceExtent: "",
        // 预览图
        resourcePreview: "",
        // 资源名称
        resourceName: "",
        // 资源类别
        resourceType: []
      };
    }
  },
  filters: {
    statusClassFilter(val) {
      switch (val) {
        case 0:
          return "orange";
        case 1:
          return "green";
        case 2:
          return "red";
        case 3:
          return "blue";
        default:
          return "";
      }
    },
    statusValueFilter(val) {
      switch (val) {
        case 0:
          return "待审核";
        case 1:
          return "已通过";
        case 2:
          return "退回";
        case 3:
          return "未提交";
        default:
          return "";
      }
    }
  },
  computed: {
    uploadUrl() {
      // return this.$store.getters["skb/getUploadUrl"];
      return "/api/upload/resource";
    },
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 64;
    },
    moreCategoryList() {
      let tmpArr = this.categoryList.map(el => el);
      tmpArr.unshift({
        label: "全部资源类别",
        value: ""
      });
      return tmpArr;
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
        vm.limitQuery.category = limitQuery.category;
      }
    });
  }
};
</script>

<style lang="scss" scoped>
.teacherResource {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    .left {
      flex: 1;
      display: flex;
    }
    .right > :not(:last-child),
    .left > :not(:last-child) {
      margin-right: $top;
    }
  }
  /deep/ .ivu-rate-star {
    margin-right: 0px;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .view {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .disabled {
    text-decoration: underline;
    color: #999;
  }
}
</style>
<style lang="scss">
.evaluate-count {
  margin-left: 10px;
}
.modal-resource-library {
  .ivu-modal {
    width: 400px !important;
  }
  // &.ivu-modal-wrap .ivu-modal-body {
  //   min-height: 234px;
  // }
  .ivu-upload-drag {
    width: 90% !important;
  }
  /deep/ .ivu-cascader {
    width: 90% !important;
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
  /deep/ .ivu-input-wrapper {
    width: 90% !important;
  }
  // .ivu-form-item {
  //   margin-bottom: $top;
  //   &:last-child {
  //     margin-bottom: 0;
  //   }
  // }
  .resource-file {
    padding: 0 10px;
    width: 90%;
    display: flex;
    justify-content: space-between;
    background: #fff;
    transition: all 1s;
    &:hover {
      background: rgba(0, 0, 0, 0.1);
    }

    span {
      font-size: 16px;
      cursor: pointer;
    }
  }
}
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .ivu-badge {
    margin-right: $left;
    .ivu-btn-large {
      margin-right: 0;
    }
  }
  /deep/ .ivu-date-picker:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .left {
    flex: 2 !important;
  }
  /deep/ .right {
    flex: 1 !important;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
    // max-width: 380px;
    // min-width: 320px;
  }
}
</style>
