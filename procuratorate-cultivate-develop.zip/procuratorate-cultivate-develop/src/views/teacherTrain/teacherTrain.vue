<template>
  <div class="teacherTrain">
    <div class="my-header">
      <i-input
        size="large"
        suffix="ios-search"
        v-model="limitQuery.query"
        @keyup.enter.native="initLoadTable"
        placeholder="请输入培训项目/课程名称"
        style="width: 210px"
        clearable
        @on-clear="initLoadTable"
      />
      <i-button size="large" @click="initLoadTable">查询</i-button>
      <i-date-picker
        :editable="false"
        type="daterange"
        separator=" 至 "
        :value="[limitQuery.startTime, limitQuery.endTime]"
        @on-change="handleDatePickChange"
        placeholder="请选择时间段"
        size="large"
      ></i-date-picker>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="trainingTime">
          <i-tooltip
            :content="`${row.trainingTimeStart} ~ ${row.trainingTimeEnd}`"
            :transfer="true"
            max-width="300px"
            >{{ row.trainingTimeStart }} ~ {{ row.trainingTimeEnd }}</i-tooltip
          >
        </template>
        <template slot-scope="{ row, index }" slot="isHasTeaching">
          <span
            class="to-see"
            v-if="row.isHasTeaching === 1"
            @click="clickTeaching(index)"
            >评教汇总</span
          >
          <span v-else>无</span>
        </template>
        <template slot-scope="{ row, index }" slot="studentRole">
          <span class="to-see" @click="clickRole(index)">学员名单</span>
        </template>
        <template slot-scope="{ row, index }" slot="studentScore">
          <span
            class="to-see"
            v-if="row.isNeedExam === 1"
            @click="clickScore(index)"
            >成绩统计</span
          >
          <span v-else>无</span>
        </template>
        <template slot-scope="{ row }" slot="status">
          <span :class="row.classStatus | statusClassFilter">{{
            row.classStatus | statusValueFilter
          }}</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="modalOption.key === 'role'">
          <div>
            <div class="row">
              <div>
                <span>培训项目：</span>
                <span>{{ dataForRole.projectName }}</span>
              </div>
              <div>
                <span>培训人数：</span>
                <span>{{ dataForRole.memberActual }}</span>
              </div>
            </div>
            <div class="row">
              <div>
                <span>培训课程：</span>
                <span>{{ dataForRole.className }}</span>
              </div>
              <div></div>
            </div>
            <i-table
              :data="tableDataForRole"
              :columns="roleColOption"
              :border="true"
              :max-height="300"
            >
              <template slot-scope="{ row }" slot="checkInStatus">
                <span :class="row.checkInStatus | checkinStatusClassFilter">{{
                  row.checkInStatus | checkinStatusValueFilter
                }}</span>
              </template>
            </i-table>
          </div>
        </template>
        <template v-if="modalOption.key === 'score'">
          <div>
            <div class="row">
              <div>
                <span>培训项目：</span>
                <span>{{ dataForScore.projectName }}</span>
              </div>
              <div>
                <span>考试人数：</span>
                <span>{{ dataForScore.examNum }}</span>
              </div>
            </div>
            <div class="row">
              <div>
                <span>培训课程：</span>
                <span>{{ dataForScore.className }}</span>
              </div>
              <div>
                <span>未考人数：</span>
                <span>{{ dataForScore.unExamNum }}</span>
              </div>
            </div>
            <i-table
              :data="tableDataForScore"
              :columns="scoreColOption"
              :border="true"
              :max-height="300"
              :row-class-name="rowClassName"
            >
            </i-table>
          </div>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" type="primary" @click="clickOutput"
          >导出</i-button
        >
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Table, Input, Button, Tooltip, DatePicker } from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
export default {
  name: "teacherTrain",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "i-date-picker": DatePicker,
    "my-pagination": myPagination,
    "my-modal": myModal
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      tableDataForRole: [],
      tableDataForScore: [],
      // 表格上方展示的数据
      dataForRole: {
        memberActual: 0,
        projectName: "",
        className: ""
      },
      dataForScore: {
        projectName: "",
        className: "",
        // 考试人数
        examNum: "",
        // 未考人数
        unExamNum: ""
      },
      // 表格显示的配置项
      colOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "课程名称", align: "center", key: "className", tooltip: true },
        { title: "培训时间", align: "center", slot: "trainingTime" },
        {
          title: "培训地点",
          align: "center",
          key: "trainingLocation",
          tooltip: true
        },
        { title: "培训场地", align: "center", key: "siteName", tooltip: true },
        { title: "住宿信息", align: "center", key: "roomNum", tooltip: true },
        {
          title: "学员名单",
          align: "center",
          slot: "studentRole",
          tooltip: true
        },
        {
          title: "学员成绩",
          align: "center",
          slot: "studentScore",
          tooltip: true
        },
        { title: "状态", align: "center", width: 120, slot: "status" }
      ],
      roleColOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "性别",
          align: "center",
          tooltip: true,
          width: 80,
          render: (h, params) => {
            return h("span", params.row.sex === 1 ? "男" : "女");
          }
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "联系方式",
          align: "center",
          key: "mobile",
          tooltip: true
        }
      ],
      scoreColOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "成绩",
          align: "center",
          key: "examScore",
          tooltip: true
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        startTime: "",
        endTime: ""
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-teacher-train"
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      tmpObj.startTime = new Date(tmpObj.startTime + " " + "00:00:00") || "";
      tmpObj.endTime = new Date(tmpObj.endTime + " " + "23:59:59") || "";
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/teacherProject/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          data.list.forEach(el => {
            el.roomNum = el.roomNum.join(",");
          });
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查看学员名单
    clickRole(index) {
      let currentObj = this.tableData[index];
      this.modalOption.title = "学员名单";
      this.modalOption.key = "role";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-teacher-train-role";
      this.dataForRole.projectName = currentObj.projectName;
      this.dataForRole.className = currentObj.className;
      this.requireRoleList(currentObj.projectId);
    },
    // 获取学员名单列表
    requireRoleList(id) {
      this.$axios
        .get(`/api/teacherProject/studentList/${id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data) {
            console.error("学员名单数据获取失败");
            return false;
          }
          this.dataForRole.memberActual = data.memberActual;
          // 保存列表数据
          this.tableDataForRole = data.studentListVOS.sort(
            (a, b) => a.examScore - b.examScore
          );
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查看学员成绩
    clickScore(index) {
      // 取出当前点击的记录对象
      let currentObj = this.tableData[index];
      if (currentObj.classStatus !== 4005) {
        this.$Message.warning("培训课程未开始，暂不可查看成绩统计！");
        return;
      }
      this.modalOption.title = "成绩统计";
      this.modalOption.key = "score";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-teacher-train-score";
      this.dataForScore.className = currentObj.className;
      this.dataForScore.projectName = currentObj.projectName;
      this.requireScoreList(currentObj.projectClassapplyId);
    },
    // 获取考试成绩列表
    requireScoreList(id) {
      this.$axios
        .get(`/api/scene/scoreSummary/${id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data) {
            console.error("学员名单数据获取失败");
            return false;
          }
          this.dataForScore.examNum = data.examNum;
          this.dataForScore.unExamNum = data.unExamNum;
          // 保存列表数据
          this.tableDataForScore = data.scoreSummaryListVOS;
          console.log(this.tableDataForScore);
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    rowClassName(row) {
      if (row.examScore === null) {
        return "red";
      }
    },
    // 列表查询时的时间段改变的方法
    handleDatePickChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = arr[0];
      this.limitQuery.endTime = arr[1];
      this.initLoadTable();
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 导出的方法
    clickOutput() {
      this.$log.INFO("正在导出");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 62;
    }
  },
  filters: {
    statusValueFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4003:
        case 4007:
          return "未开始";
        case 4004:
          return "已开始";
        case 4005:
          return "已结束";
        default:
          return "";
      }
    },
    statusClassFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4003:
        case 4007:
          return "orange";
        case 4004:
          return "green";
        case 4005:
          return "";
        default:
          return "";
      }
    },
    checkinStatusValueFilter(value) {
      // 101-已签到 102-未签到 103-请假
      value = parseInt(value);
      switch (value) {
        case 101:
          return "已签到";
        case 102:
          return "未签到";
        case 103:
          return "请假";
        default:
          return "";
      }
    },
    checkinStatusClassFilter(value) {
      // 101-已签到 102-未签到 103-请假
      value = parseInt(value);
      switch (value) {
        case 101:
          return "green";
        case 102:
          return "red";
        case 103:
          return "blue";
        default:
          return "";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherTrain {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    margin-bottom: 20px;
    & > :not(:last-child) {
      margin-right: $top;
    }
  }
  .orange {
    color: $orange;
  }
  .green {
    color: $theme;
  }
  .blue {
    color: $blue;
  }
  .red {
    color: $error;
  }
  .to-see {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-teacher-train-role,
.modal-teacher-train-score {
  .ivu-modal {
    width: 650px !important;
  }
  .modal-content {
    .ivu-select {
      width: 200px !important;
    }
  }
  .to-see {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .green {
    color: $theme;
  }
  .blue {
    color: $blue;
  }
  .red {
    color: $error;
  }
}
.modal-teacher-train-role {
  .row:nth-child(1) {
    & > div:last-child span {
      color: $theme;
    }
  }
}
.modal-teacher-train-score {
  .row:nth-child(2) {
    & > div:last-child span {
      color: $error;
    }
  }
}
</style>
