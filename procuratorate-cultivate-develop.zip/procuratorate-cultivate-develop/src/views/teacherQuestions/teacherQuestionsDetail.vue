<template>
  <div class="teacherQuestionsDetail">
    <my-content-head>
      <div slot="left">
        <router-link to="/teacherQuestions">考试试题</router-link>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clickSave">保存</i-button>
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="content-head">
        <div class="content-head-left">
          <span class="required">关联课程：</span>
          <i-select
            v-model="formData.classId"
            size="large"
            @on-change="requireConnectTeacher"
            filterable
          >
            <i-option
              v-for="(item, index) of courseOption"
              :key="index"
              :value="item.classId"
              >{{ item.className }}</i-option
            >
          </i-select>
        </div>
        <div class="content-head-right">
          <i-button ghost type="primary" @click="clickAddQuestion" size="large"
            >新增题目</i-button
          >
        </div>
      </div>
      <div class="content-body">
        <div
          class="question-card"
          v-for="(item, index1) of formData.questionDTOs"
          :key="index1"
        >
          <div class="btn-close" @click="deleteQuestionDTOs(index1)">
            <i-icon type="ios-trash" size="24"></i-icon>
          </div>
          <div class="row">
            <span class="required">题目名称：</span>
            <i-input
              size="large"
              v-model="item.questionName"
              placeholder="请输入"
              class="question-name"
            ></i-input>
          </div>
          <div class="row">
            <div class="col">
              <span class="required">题目类型：</span>
              <i-select
                v-model="item.questionTypeId"
                size="large"
                :transfer="true"
                @on-change="
                  handleQuestionTypeChange(index1, item.questionTypeId)
                "
              >
                <i-option
                  v-for="(item, index) of questionsOption"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </div>
            <div class="col">
              <span class="required">分值：</span>
              <i-input-number
                v-model="item.questionScore"
                placeholder="请输入"
                :min="1"
                size="large"
              ></i-input-number>
            </div>
          </div>
          <div class="row question-table" v-if="item.questionTypeId !== 3">
            <i-table
              :data="item.resourceQuestionOptionDTOS"
              :columns="colOption"
              :border="true"
              ref="selection"
            >
              <template slot-scope="{ row, index }" slot="action">
                <div
                  @click="addRow(index1)"
                  class="add"
                  v-if="index === item.resourceQuestionOptionDTOS.length - 1"
                >
                  +
                </div>
                <div v-else class="reduce" @click="reduceRow(index1, index)">
                  -
                </div>
              </template>
              <template slot-scope="{ index }" slot="optionText">
                <i-input
                  size="large"
                  v-model="item.resourceQuestionOptionDTOS[index].optionText"
                  placeholder="请输入"
                  class="option-text"
                ></i-input>
              </template>
              <template slot-scope="{ row, index }" slot="optionIsanswer">
                <i-radio
                  size="large"
                  :value="row.optionIsanswer"
                  :true-value="1"
                  :false-value="0"
                  @on-change="
                    handleresourceQuestionOptionDTOSChange(
                      index1,
                      index,
                      row.optionIsanswer
                    )
                  "
                  v-if="item.questionTypeId === 1"
                ></i-radio>
                <i-checkbox
                  size="large"
                  v-model="
                    item.resourceQuestionOptionDTOS[index].optionIsanswer
                  "
                  :true-value="1"
                  :false-value="0"
                  v-if="item.questionTypeId === 2"
                ></i-checkbox>
              </template>
            </i-table>
          </div>
          <div v-else class="row">
            <span class="required">正确答案：</span>
            <div
              v-for="(el, ind) of item.resourceQuestionOptionDTOS"
              :key="ind"
            >
              <i-radio
                @on-change="
                  handleresourceQuestionOptionDTOSChange(
                    index1,
                    ind,
                    el.optionIsanswer
                  )
                "
                :true-value="1"
                :false-value="0"
                :value="el.optionIsanswer"
                >{{ el.optionNum }}</i-radio
              >
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {
  Input,
  Button,
  Select,
  Option,
  Icon,
  Table,
  Radio,
  Checkbox,
  InputNumber
} from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "teacherQuestionsDetail",
  components: {
    "i-input": Input,
    "i-table": Table,
    "i-icon": Icon,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-radio": Radio,
    "i-checkbox": Checkbox,
    "i-input-number": InputNumber,
    "my-content-head": myContentHead
  },
  data() {
    return {
      formData: {
        // 课程id
        classId: "",
        questionDTOs: [
          {
            // 试题名称
            questionName: "",
            // 试题分值
            questionScore: null,
            // 试题类型ID
            questionTypeId: 1,
            // 试题选项列表
            resourceQuestionOptionDTOS: [
              {
                // 是否是答案
                optionIsanswer: 0,
                // 选项名称
                optionNum: "A",
                // 选项内容
                optionText: ""
              },
              {
                // 是否是答案
                optionIsanswer: 0,
                // 选项名称
                optionNum: "B",
                // 选项内容
                optionText: ""
              }
            ]
          }
        ]
      },
      // 表格显示的配置项
      colOption: [
        { title: "选项", align: "center", key: "optionNum", width: 80 },
        { title: "选项内容", align: "center", slot: "optionText" },
        {
          title: "正确答案",
          width: 120,
          align: "center",
          slot: "optionIsanswer"
        },
        { title: "操作", align: "center", width: 80, slot: "action" }
      ],
      // 试题类别可选列表
      questionsOption: [
        { value: 1, label: "单选题" },
        { value: 2, label: "多选题" },
        { value: 3, label: "判断题" }
      ],
      // 选项名称的备选列表
      optionNumOption: ["A", "B", "C", "D", "E", "F"],
      connectTeacher: "",
      // 课程待选列表
      courseOption: []
    };
  },
  mounted() {
    // 请求课程列表
    this.requireCourseOption();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.clearFormData();
      this.$router.push("/teacherQuestions");
    },
    // 校验表单的方法
    testForm() {
      let { classId, questionDTOs } = this.formData,
        sign = true,
        normal = { value: false, msg: "请填写完整后再尝试保存！" };
      // 判断课程是否为空
      if (classId === "") {
        sign = false;
        return normal;
      }
      questionDTOs.forEach(question => {
        let {
          questionName,
          questionScore,
          questionTypeId,
          resourceQuestionOptionDTOS
        } = question;
        // 题目名称为空
        if (questionName === "" || questionName.length > 50) {
          sign = false;
          normal.msg = "请输入50位以内的题目名称";
          return false;
        }
        // 题目分数为空
        if (questionScore === null) {
          sign = false;
          return false;
        }
        // 题目类型为空
        if (questionTypeId === "") {
          sign = false;
          return false;
        }
        // 当多选和单选时判断题目内容
        if (questionTypeId === 1 || questionTypeId === 2) {
          resourceQuestionOptionDTOS.forEach(resource => {
            if (!sign) {
              return;
            }
            let optionText = resource.optionText;
            if (optionText === "" || optionText.length > 50) {
              sign = false;
              normal.msg = "请输入50位以内的选项内容";
            }
          });
        }
        if (questionTypeId === 1) {
          let count = resourceQuestionOptionDTOS.reduce((prev, resource) => {
            return resource.optionIsanswer + prev;
          }, 0);
          console.log(count);
          if (count !== 1) {
            sign = false;
            normal.msg = "单选题请选择一个答案";
          }
        }
        if (questionTypeId === 2) {
          let count = resourceQuestionOptionDTOS.reduce((prev, resource) => {
            return resource.optionIsanswer + prev;
          }, 0);
          if (count < 2) {
            sign = false;
            normal.msg = "多选题请至少选择两个答案";
          }
        }
        if (questionTypeId === 3) {
          let count = resourceQuestionOptionDTOS.reduce((prev, resource) => {
            return resource.optionIsanswer + prev;
          }, 0);
          if (count !== 1) {
            sign = false;
            normal.msg = "判断题请选择一个答案";
          }
        }
      });
      if (sign) {
        return { value: true, msg: "验证通过" };
      } else {
        return normal;
      }
    },
    // 处理保存的方法
    clickSave() {
      this.$log.INFO("正在保存");
      let result = this.testForm();
      if (result.value) {
        this.handleSave();
      } else {
        this.$Message.error(result.msg);
      }
    },
    // 发送请求保存数据
    handleSave() {
      this.$axios
        .post("/api/question/insert", this.formData)
        .then(res => {
          this.$Message.success("添加成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求课程的待选列表
    requireCourseOption() {
      this.$axios
        .get(`/api/teacher/teacherClass`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("课程列表获取失败");
            return false;
          }
          this.courseOption = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求关联课程的老师
    requireConnectTeacher() {
      // 验证课程Id非空
      if (!this.formData.classId) {
        this.$log.INFO("课程Id为空，无法请求关联的老师");
        return;
      }
      this.$axios
        .get(`/api/class/getTeachersName/${this.formData.classId}`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("培训教师获取失败");
            return false;
          }
          this.connectTeacher = data
            .map(el => {
              return el.name;
            })
            .join(",");
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 切换题目类型的处理函数
    handleQuestionTypeChange(index, val) {
      this.$log.INFO("切换题目类型");
      switch (val) {
        case 1:
        case 2:
          this.formData.questionDTOs[index].resourceQuestionOptionDTOS.map(
            (el, index) => {
              el.optionIsanswer = 0;
              el.optionNum = this.optionNumOption[index];
            }
          );
          return false;
        case 3:
          this.formData.questionDTOs[index].resourceQuestionOptionDTOS = [
            {
              // 是否是答案
              optionIsanswer: 0,
              // 选项名称
              optionNum: "T",
              // 选项内容
              optionText: ""
            },
            {
              // 是否是答案
              optionIsanswer: 1,
              // 选项名称
              optionNum: "F",
              // 选项内容
              optionText: ""
            }
          ];
          return false;
      }
    },
    //
    // 点击添加题目
    clickAddQuestion() {
      // 添加一个题目
      this.formData.questionDTOs.push({
        // 试题名称
        questionName: "",
        // 试题分值
        questionScore: null,
        // 试题类型ID
        questionTypeId: 1,
        // 试题选项列表
        resourceQuestionOptionDTOS: [
          {
            // 是否是答案
            optionIsanswer: 0,
            // 选项名称
            optionNum: "A",
            // 选项内容
            optionText: ""
          },
          {
            // 是否是答案
            optionIsanswer: 0,
            // 选项名称
            optionNum: "B",
            // 选项内容
            optionText: ""
          }
        ]
      });
    },
    // 删除一条题目
    deleteQuestionDTOs(index) {
      if (this.formData.questionDTOs.length === 1) {
        this.$Message.error("至少保留一条题目");
        return;
      }
      this.formData.questionDTOs.splice(index, 1);
    },
    // 添加题目的选项
    addRow(index) {
      if (
        this.formData.questionDTOs[index].resourceQuestionOptionDTOS.length > 5
      ) {
        this.$Message.error("题目中的选项不能超过6个");
        return;
      }
      this.formData.questionDTOs[index].resourceQuestionOptionDTOS.push({
        // 是否是答案
        optionIsanswer: 0,
        // 选项名称
        optionNum: "",
        // 选项内容
        optionText: ""
      });
      // 重新定义选项名称
      this.formData.questionDTOs[index].resourceQuestionOptionDTOS.forEach(
        (el, ind) => {
          el.optionNum = this.optionNumOption[ind];
        }
      );
    },
    // 删除题目的选项
    reduceRow(index, ind) {
      if (
        this.formData.questionDTOs[index].resourceQuestionOptionDTOS.length < 3
      ) {
        this.$Message.error("题目中的选项不能少于2个");
        return;
      }
      this.formData.questionDTOs[index].resourceQuestionOptionDTOS.splice(
        ind,
        1
      );
      // 重新定义选项名称
      this.formData.questionDTOs[index].resourceQuestionOptionDTOS.forEach(
        (el, ind) => {
          el.optionNum = this.optionNumOption[ind];
        }
      );
    },
    // 处理判断题选择改变的函数
    handleresourceQuestionOptionDTOSChange(index, ind, val) {
      // 先将所有清空所有选项
      this.formData.questionDTOs[index].resourceQuestionOptionDTOS.forEach(
        el => {
          el.optionIsanswer = 0;
        }
      );
      let tmpObj = this.formData.questionDTOs[index];
      // 选择选中项
      tmpObj.resourceQuestionOptionDTOS[ind].optionIsanswer = 1;
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 课程id
        classId: "",
        questionDTOs: [
          {
            // 试题名称
            questionName: "",
            // 试题分值
            questionScore: null,
            // 试题类型ID
            questionTypeId: 1,
            // 试题选项列表
            resourceQuestionOptionDTOS: [
              {
                // 是否是答案
                optionIsanswer: 0,
                // 选项名称
                optionNum: "A",
                // 选项内容
                optionText: ""
              },
              {
                // 是否是答案
                optionIsanswer: 0,
                // 选项名称
                optionNum: "B",
                // 选项内容
                optionText: ""
              }
            ]
          }
        ]
      };
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherQuestionsDetail {
  .ivu-select {
    width: 160px;
  }
  .content-head-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .content-head {
    display: flex;
    align-items: center;
    height: 100%;
    padding: $top;
    padding-left: 20px;
    height: $btn-height;
    box-sizing: content-box;
    background: $border-color;
    justify-content: space-between;
  }
  .content-body {
    height: calc(100vh - 238px);
    overflow: auto;
    background: #fff;
    .question-card {
      width: 100%;
      border-bottom: 1px solid $border-color;
      padding: 20px;
      position: relative;
      overflow: hidden;
      // min-height: 250px;
      .ivu-table-wrapper {
        width: 100%;
      }
      .btn-close {
        width: 100px;
        height: 100px;
        transform: rotate(45deg);
        line-height: 150px;
        text-align: center;
        background: $error;
        color: $white;
        position: absolute;
        right: -50px;
        top: -50px;
        .ivu-icon {
          transform: rotate(-45deg);
        }
      }
      .question-table {
        .ivu-radio-wrapper,
        .ivu-checkbox-wrapper {
          margin-right: 0;
        }
        .option-text {
          width: 100% !important;
        }
        .add,
        .reduce {
          background: $error;
          margin: 0 auto;
          width: 24px;
          height: 24px;
          text-align: center;
          line-height: 24px;
          color: $white;
          border-radius: 50%;
          font-size: 24px;
        }
        .add {
          background: $theme;
        }
        .reduce {
          line-height: 20px;
          font-size: 30px;
        }
      }

      .question-name {
        width: 80% !important;
      }
      .row {
        display: flex;
        align-items: center;
        &:not(:last-child) {
          margin-bottom: $top;
        }
        .col {
          flex: 1;
          align-items: center;
        }
      }
    }
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
  }
  span.back {
    font-size: 14px;
  }
}
</style>
