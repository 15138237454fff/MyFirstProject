<template>
  <div class="login">
    <div class="login-area">
      <div class="bg-box"></div>
      <div class="main-box">
        <img src="../../assets/images/logo1.png" class="logo" />
        <div class="title-area">
          <p>综合教育培训系统</p>
          <p>Integrated Education and Training Management System</p>
        </div>
        <div class="form-area">
          <i-input
            size="large"
            placeholder="请输入用户名"
            v-model="formData.userName"
            clearable
          ></i-input>
          <i-input
            size="large"
            placeholder="请输入密码"
            v-model="formData.password"
            type="password"
            password
          ></i-input>
          <div class="test-code">
            <i-input
              size="large"
              placeholder="请输入验证码"
              v-model="formData.captcha"
              @keyup.enter.native="handleLogin"
            ></i-input>
            <img :src="testCode" @click="requireCaptcha" />
          </div>
          <div class="bottom-btn">
            <i-checkbox v-model="checked"
              >&nbsp;&nbsp;一周内记住密码</i-checkbox
            >
            <router-link to="/forget">忘记密码？</router-link>
          </div>
          <i-button size="large" @click="handleLogin">登录</i-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { Button, Input, Checkbox } from "view-design";
export default {
  name: "Login",
  data() {
    return {
      // 是否记住密码
      checked: false,
      // 验证码
      testCode: "",
      // 表单数据
      formData: {
        userName: "",
        password: "",
        captcha: ""
      }
    };
  },
  components: {
    "i-button": Button,
    "i-input": Input,
    "i-checkbox": Checkbox
  },
  mounted() {
    // 请求验证码
    this.requireCaptcha();
    // 获取登录信息
    this.readLoginMsg();
  },
  methods: {
    // 获取验证码
    requireCaptcha() {
      this.$axios
        .get("/api/login/captcha.jpg", {
          responseType: "arraybuffer"
        })
        .then(response => {
          return (
            "data:image/png;base64," +
            btoa(
              new Uint8Array(response.data).reduce(
                (data, byte) => data + String.fromCharCode(byte),
                ""
              )
            )
          );
        })
        .then(res => {
          this.testCode = res;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 登录方法
    handleLogin() {
      let { captcha, password, userName } = this.formData;
      // 发送登录请求
      this.$axios
        .post(
          `/api/login?captcha=${captcha}&password=${encodeURIComponent(
            password
          )}&username=${userName}`
        )
        .then(res => {
          // 提示登录成功
          this.$Message.success("登录成功");
          // 修改登录状态
          this.$store.commit("skb/updateLogin", true);
          // 登录成功后更新用户状态
          this.requireUserStatus();
          // 如果勾选记住密码
          if (this.checked) {
            // 准备好要保存的数据
            let tmpObj = {
              userName: userName,
              password: this.compile(password),
              checked: this.checked,
              saveTime: new Date().getTime()
            };
            // 存入浏览器内存中
            window.localStorage.setItem(
              "frontLoginData",
              JSON.stringify(tmpObj)
            );
          } else {
            // 未勾选记住密码，清空内存
            window.localStorage.removeItem("frontLoginData");
          }
        })
        .catch(error => {
          console.error(error.message);
          // 重新请求验证码
          this.requireCaptcha();
          this.formData.captcha = "";
          // 修改登录状态
          // this.$store.commit("skb/updateLogin", false);
        });
    },
    // 获取登录人的身份信息
    requireUserStatus() {
      this.$axios
        .get("/api/teacher/isTutor")
        .then(res => {
          let data = res.data.data,
            status = 1;
          if (data) {
            status = 2;
          } else {
            status = 1;
          }
          this.$store.commit("skb/updatePageState", status);
          this.$store.commit("skb/updateUserStatus", status);
          // 跳转首页
          this.$router.go(0);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 读取登录信息
    readLoginMsg() {
      // 取出登录信息
      let tmpObj = window.localStorage.getItem("frontLoginData");
      // 如果没有登录信息
      if (!tmpObj) {
        return false;
      }
      // json字符串反序列
      tmpObj = JSON.parse(tmpObj);
      let password = tmpObj.password,
        time = new Date(tmpObj.saveTime),
        now = new Date();
      // 如果密码为空
      if (!password) {
        return false;
      }
      password = this.uncompile(password);
      // 如果超过一周
      if (now - time > 7 * 3600 * 1000 * 24) {
        return false;
      }
      // 自动填写用户名密码
      this.formData.userName = tmpObj.userName;
      this.formData.password = password;
      this.checked = tmpObj.checked;
    },
    // 加密函数
    compile(code) {
      let c = String.fromCharCode(code.charCodeAt(0) + code.length);
      for (var i = 1; i < code.length; i++) {
        c += String.fromCharCode(code.charCodeAt(i) + code.charCodeAt(i - 1));
      }
      return escape(c);
    },
    // 解密函数
    uncompile(code) {
      code = unescape(code);
      let c = String.fromCharCode(code.charCodeAt(0) - code.length);
      for (let i = 1; i < code.length; i++) {
        c += String.fromCharCode(code.charCodeAt(i) - c.charCodeAt(i - 1));
      }
      return c;
    }
  }
};
</script>
<style lang="scss" scoped>
.login {
  width: 100%;
  height: 100%;
  background: url("../../assets/images/bg1.png") no-repeat;
  background-size: cover;
  display: flex;
  align-items: center;
  justify-content: center;
  .login-area {
    width: 90vw;
    height: 78vh;
    display: flex;
    box-shadow: #999 20px 20px 20px 0;
    .bg-box {
      width: 62.5%;
      height: 100%;
      background: url("../../assets/images/bg3.png") no-repeat;
      background-size: 101%;
    }
    .main-box {
      width: 37.5%;
      height: 100%;
      background: #fff;
      padding: 2%;
      box-sizing: border-box;
      .logo {
        width: 36%;
      }
      .title-area {
        text-align: center;
        p {
          color: $theme;
        }
        p:first-child {
          font-family: "Arial Black", "Arial Normal", "Arial";
          font-weight: 600;
          font-size: 2.9vw;
        }
        p:last-child {
          font-family: "Arial Normal", "Arial";
          font-weight: 400;
          font-size: 1.1vw;
        }
      }
      .form-area {
        width: 100%;
        height: 70%;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
        padding: 20px;
        /deep/ .ivu-input {
          outline: none;
          box-shadow: none;
          font-size: 1.2vw;
          border: none;
          border-bottom: 1px solid $theme;
          border-radius: 0;
          &:focus {
            border-width: 2px;
          }
        }
        .ivu-input-wrapper {
          width: 100% !important;
        }
        .test-code {
          position: relative;
        }
        img {
          display: inline-block;
          position: absolute;
          right: 0;
          bottom: 2px;
          width: 100px;
          height: 40px;
        }
        .ivu-btn {
          background-color: $theme;
          outline: none;
          border: none;
          color: #fff;
          font-size: 1.2vw;
          border-radius: 24px;
        }
        .bottom-btn {
          display: flex;
          justify-content: space-between;
          .ivu-checkbox-wrapper {
            color: #333;
            font-size: 1vw;
          }
          a {
            color: $theme;
            font-size: 1vw;
          }
        }
      }
    }
  }
}
</style>
