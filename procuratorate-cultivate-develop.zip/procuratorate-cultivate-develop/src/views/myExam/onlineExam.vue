<template>
  <div class="onlineExam">
    <my-content-head>
      <div slot="left">
        <router-link to="/myExam">我的考试</router-link>
      </div>
      <div slot="right">
        <i-button @click="clickSubmit" size="large" type="primary"
          >提交</i-button
        >
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="card-title">
      <div class="left"></div>
      <div class="center">{{ formData.className }}</div>
      <div class="right"></div>
    </div>
    <div class="content">
      <ul class="question-list">
        <li
          class="question-item"
          v-for="(item, index) of formData.queationVOS"
          :key="index"
        >
          <p class="question-title">
            {{ index + 1 }}.&nbsp;{{ item.questionName }}({{
              item.questionTypeId | questionTypeFilter
            }})
          </p>
          <template v-if="item.questionTypeId !== 2">
            <ul>
              <li
                v-for="(obj, ind) of item.optionList"
                :key="ind"
                class="question-line"
              >
                <i-radio
                  size="large"
                  :value="obj.isChoose"
                  :true-value="1"
                  :false-value="0"
                  @on-change="
                    handleresourceQuestionOptionDTOSChange(index, ind)
                  "
                  >&nbsp;{{ obj.optionNum }}.&nbsp;{{ obj.optionText }}</i-radio
                >
              </li>
            </ul>
          </template>
          <template v-else>
            <ul>
              <li
                v-for="(obj, ind) of item.optionList"
                :key="ind"
                class="question-line"
              >
                <i-checkbox
                  size="large"
                  v-model="obj.isChoose"
                  :true-value="1"
                  :false-value="0"
                  >&nbsp;{{ obj.optionNum }}. {{ obj.optionText }}</i-checkbox
                >
              </li>
            </ul>
          </template>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { Button, Checkbox, Radio } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "onlineExam",
  props: {
    id: {},
    projectClassId: {}
  },
  components: {
    "i-button": Button,
    "i-checkbox": Checkbox,
    "i-radio": Radio,
    "my-content-head": myContentHead
  },
  data() {
    return {
      formData: {
        classId: "",
        // 合格分
        passScore: 0,
        // 试题数据
        queationVOS: [],
        // 项目名称
        className: ""
      }
    };
  },
  mounted() {
    // 请求项目详情
    this.requireProjectDetail();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/myExam");
    },
    requireProjectDetail() {
      this.$axios
        .get(`/api/myExam/examInfo/${this.id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (this.$isEmpty(data)) {
            console.error("项目详情数据获取失败");
            return false;
          }
          // 保存列表数据
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          console.log(this.formData);
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
        });
    },
    // 点击提交
    clickSubmit() {
      let tmpObj = {
        classId: this.formData.classId,
        paperId: this.id,
        projectClassId: this.projectClassId,
        questionList: this.formData.queationVOS.map(item => {
          return {
            options: item.optionList.map(el => {
              return {
                isChoose: el.isChoose,
                optionIsanswer: el.optionIsanswer,
                questionOptionId: el.questionOptionId
              };
            }),
            questionId: item.questionId,
            questionScore: item.questionScore,
            questionTypeId: item.questionTypeId
          };
        })
      };
      this.$axios
        .post("/api/myExam/onlineExam", tmpObj)
        .then(res => {
          this.$Message.success("保存成功");
          this.goBack();
        })
        .catch(error => {
          console.errror(error.message);
        });
    },
    // 处理判断题选择改变的函数
    handleresourceQuestionOptionDTOSChange(index, ind, val) {
      // 先将所有清空所有选项
      this.formData.queationVOS[index].optionList.forEach(el => {
        el.isChoose = 0;
      });
      let tmpObj = this.formData.queationVOS[index];
      // 选择选中项
      tmpObj.optionList[ind].isChoose = 1;
    }
  },
  filters: {
    questionTypeFilter(val) {
      switch (val) {
        case 1:
          return "单选";
        case 2:
          return "多选";
        case 3:
          return "判断";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.onlineExam {
  .content {
    border-top: 1px solid $border-color;
    padding: 20px;
    background: #fff;
    position: relative;
    height: calc(100vh - 296px);
    overflow: auto;
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .question-list {
      .question-item {
        border-bottom: 1px solid $border-color;
        padding: 20px;
        .question-title {
          font-weight: bold;
          margin-bottom: 20px;
        }
      }
      .question-line {
        line-height: 34px;
      }
    }
  }
  .card-title {
    display: flex;
    height: 50px;
    line-height: 50px;
    margin-bottom: 10px;
    justify-content: space-between;
    background: #fff;
    border-radius: 5px;
    padding: 0 20px;
    font-size: 18px;
    font-weight: bold;
    div {
      flex: 1;
      text-align: center;
    }
    .right {
      text-align: right;
    }
  }
  .back {
    background: #fff;
    margin-left: 10px;
  }
}
</style>
