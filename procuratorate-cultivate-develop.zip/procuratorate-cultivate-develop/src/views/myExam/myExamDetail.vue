<template>
  <div class="myExamDetail">
    <my-content-head>
      <div slot="left">
        <router-link to="/myExam">我的考试</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="card-title">
      <div class="left"></div>
      <div class="center">{{ formData.className }}</div>
      <div class="right">
        <span :class="formData.examScore > formData.passScore ? 'green' : 'red'"
          >成绩：{{ formData.examScore }}分</span
        >
      </div>
    </div>
    <div class="content">
      <ul class="question-list">
        <li
          class="question-item"
          v-for="(item, index) of formData.queationVOS"
          :key="index"
        >
          <p class="question-title">
            <span
              >{{ index + 1 }}.&nbsp;{{ item.questionName }}({{
                item.questionTypeId | questionTypeFilter
              }})</span
            >
            <i-icon
              type="md-checkmark-circle"
              size="30"
              class="green"
              v-if="item.status"
            />
            <i-icon type="md-close-circle" size="30" color="red" v-else />
          </p>
          <ul>
            <li
              v-for="(obj, ind) of item.optionList"
              :key="ind"
              class="question-line"
            >
              <span>&nbsp;&nbsp;{{ obj.optionNum }}</span>
              <span v-if="obj.optionText">.&nbsp;{{ obj.optionText }}</span>
              <span
                v-if="obj.optionIsanswer === 1 && obj.isChoose === 1"
                class="green"
                >（您选择的选项✔）</span
              >
              <span
                v-if="
                  item.questionTypeId === 2 &&
                    obj.optionIsanswer === 1 &&
                    obj.isChoose === 0
                "
                class="orange"
                >（漏选选项）</span
              >
              <span
                v-else-if="obj.optionIsanswer === 0 && obj.isChoose === 1"
                class="red"
                >（您选择的选项✖）</span
              >
              <span
                v-if="
                  item.questionTypeId !== 2 &&
                    obj.optionIsanswer === 1 &&
                    obj.isChoose === 0
                "
                class="green"
                >（正确选项）</span
              >
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { Button, Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "myExamDetail",
  props: {
    id: {}
  },
  components: {
    "i-icon": Icon,
    "i-button": Button,
    "my-content-head": myContentHead
  },
  data() {
    return {
      formData: {
        classId: "",
        // 合格分
        passScore: 0,
        examScore: 0,
        // 试题数据
        queationVOS: [],
        // 项目名称
        className: ""
      }
    };
  },
  mounted() {
    // 请求项目详情
    this.requireProjectDetail();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/myExam");
    },
    requireProjectDetail() {
      this.$axios
        .get(`/api/myExam/examInfo/${this.id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (this.$isEmpty(data)) {
            console.error("项目详情数据获取失败");
            return false;
          }
          // 给每个题目给定正确与错误状态
          data.queationVOS.forEach(item => {
            item.status = !item.optionList.some(obj => {
              return obj.isChoose !== obj.optionIsanswer;
            });
          });
          // 保存列表数据
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          console.log(this.formData);
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
        });
    }
  },
  filters: {
    questionTypeFilter(val) {
      switch (val) {
        case 1:
          return "单选";
        case 2:
          return "多选";
        case 3:
          return "判断";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.myExamDetail {
  .content {
    border-top: 1px solid $border-color;
    padding: 20px;
    background: #fff;
    position: relative;
    height: calc(100vh - 296px);
    overflow: auto;
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .question-list {
      .question-item {
        border-bottom: 1px solid $border-color;
        padding: 20px;
        .question-title {
          display: flex;
          justify-content: space-between;
          font-weight: bold;
          margin-bottom: 20px;
        }
      }
      .question-line {
        line-height: 34px;
      }
    }
  }
  .card-title {
    display: flex;
    height: 50px;
    line-height: 50px;
    margin-bottom: 10px;
    justify-content: space-between;
    background: #fff;
    border-radius: 5px;
    padding: 0 20px;
    font-size: 18px;
    font-weight: bold;
    div {
      flex: 1;
      text-align: center;
    }
    .right {
      text-align: right;
    }
  }
  .back {
    background: #fff;
    margin-left: 10px;
  }
  .red {
    color: red;
  }
  .green {
    color: $theme;
  }
}
</style>
