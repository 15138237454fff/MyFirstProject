<template>
  <div class="myTrainDetail">
    <my-content-head>
      <div slot="left">
        <router-link to="/myTrain">我的培训</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="card-title">
      <div class="left">
        <p class="project-name">{{ showData.projectName }}</p>
        <p>
          培训时间：{{ $tagTime(showData.startTime, "yyyy.MM.dd") }} 至
          {{ $tagTime(showData.endTime, "yyyy.MM.dd") }}
        </p>
      </div>
      <div class="right">
        <p>培训地点：{{ showData.trainingLocation }}</p>
        <p>住宿信息：{{ showData.roomInfo }}</p>
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot="time" slot-scope="{ row }">
          <i-tooltip
            :content="
              `${$tagTime(
                row.trainingTimeStart,
                'yyyy-MM-dd HH:mm'
              )} 至 ${$tagTime(row.trainingTimeEnd, 'yyyy-MM-dd HH:mm')}`
            "
            :transfer="true"
            max-width="300px"
          >
            {{ $tagTime(row.trainingTimeStart, "yyyy-MM-dd HH:mm") }} 至
            {{ $tagTime(row.trainingTimeEnd, "yyyy-MM-dd HH:mm") }}
          </i-tooltip>
        </template>
        <template slot="action" slot-scope="{ row }">
          <span v-if="row.isNeedExam === 0">无考试</span>
          <span class="to-see" @click="toExam()" v-else-if="!row.score"
            >前往考试</span
          >
          <span v-else>{{ row.score }}</span>
        </template>
      </i-table>
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="msgCount"
      ></my-pagination>
    </div>
  </div>
</template>
<script>
import { Button, Table, Tooltip } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import myPagination from "@/components/common/myPagination";
export default {
  name: "myTrainDetail",
  props: {
    id: {}
  },
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "my-content-head": myContentHead,
    "my-pagination": myPagination
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      showData: {
        startTime: "",
        endTime: "",
        // 培训地点
        trainingLocation: "",
        // 住宿信息
        roomInfo: "",
        // 项目名称
        projectName: ""
      },
      // 表格显示的配置项
      colOption: [
        {
          title: "培训课程",
          align: "center",
          key: "className",
          tooltip: true
        },
        { title: "培训时间", align: "center", slot: "time" },
        {
          title: "培训讲师",
          align: "center",
          key: "teacherName",
          tooltip: true
        },
        {
          title: "培训场地",
          align: "center",
          key: "siteName",
          tooltip: true
        },
        {
          title: "学时",
          align: "center",
          key: "classPeriod",
          tooltip: true,
          width: 80
        },
        {
          title: "学分",
          align: "center",
          key: "classCredit",
          tooltip: true,
          width: 80
        },
        { title: "考试成绩", align: "center", width: 120, slot: "action" }
      ],
      limitQuery: {
        pageSize: 15,
        pageNum: 1
      },
      msgCount: 0,
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求项目详情
    this.requireProjectDetail();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/myTrain");
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    requireProjectDetail() {
      this.$axios
        .get(`/api/myProject/projectInfo/${this.id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (this.$isEmpty(data)) {
            console.error("项目详情数据获取失败");
            return false;
          }
          // 保存列表数据
          Object.keys(this.showData).forEach(key => {
            this.showData[key] = data[key];
          });
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
        });
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery, { projectId: this.id });
      this.$axios
        .post(`/api/myProject/projectInfo/list`, tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 前往考试
    toExam() {
      this.$router.push("/myExam");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 190;
    }
  }
};
</script>
<style lang="scss" scoped>
.myTrainDetail {
  .content {
    border-top: 1px solid $border-color;
    padding: 20px;
    background: #fff;
    position: relative;
    height: calc(100vh - 346px);
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .attachment {
      padding-top: $top;
      a {
        cursor: pointer;
        text-decoration: underline;
        color: $theme;
        margin-right: 20px;
      }
    }
  }
  .card-title {
    display: flex;
    height: 100px;
    margin-bottom: 10px;
    justify-content: space-between;
    background: #fff;
    border-radius: 5px;
    padding: 20px;
    p {
      line-height: 30px;
    }
    .project-name {
      font-weight: bold;
      font-size: 16px;
    }
  }
  .to-see {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
  .back {
    background: #fff;
  }
}
</style>
