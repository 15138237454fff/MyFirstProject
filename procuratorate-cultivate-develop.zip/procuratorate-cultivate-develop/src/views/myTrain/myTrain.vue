<template>
  <div class="myTrain">
    <div class="my-header">
      <i-input
        size="large"
        suffix="ios-search"
        v-model="limitQuery.query"
        @keyup.enter.native="initLoadTable"
        placeholder="请输入项目名称"
        style="width: 210px"
        clearable
        @on-clear="initLoadTable"
      />
      <i-button size="large" @click="initLoadTable">查询</i-button>
      <i-date-picker
        :editable="false"
        type="daterange"
        separator=" 至 "
        :value="[limitQuery.startTime, limitQuery.endTime]"
        @on-change="handleDatePickChange"
        placeholder="请选择时间段"
        size="large"
      ></i-date-picker>
    </div>
    <div class="content">
      <i-row class="card-list" :gutter="30" type="flex">
        <i-col :span="6" v-for="(item, index) of tableData" :key="index">
          <div class="my-card" @click="clickToDetail(item.projectId)">
            <div class="my-head">
              <div class="left">
                <div class="icon-img">
                  <img :src="iconImg" />
                </div>
                <span>{{ item.projectName }}</span>
              </div>
              <div
                class="right"
                :class="item.projectStatus | projectStatusClassFilter"
              >
                {{ item.projectStatus | projectStatusValueFilter }}
              </div>
            </div>
            <div class="my-body">
              <p>
                <span>
                  培训时间：{{ $tagTime(item.trainingTimeStart, "yyyy.MM.dd") }}
                  ~
                  {{ $tagTime(item.trainingTimeEnd, "yyyy.MM.dd") }}
                </span>
              </p>

              <p>培训地点：{{ item.trainingLocation }}</p>
            </div>
            <div class="my-foot">
              <span>查看项目详情</span>
            </div>
          </div>
        </i-col>
      </i-row>
      <i-spin size="large" fix v-if="loading"></i-spin>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      v-bind="limitQuery"
      :msgCount="msgCount"
      :pageSizeOptions="[12, 24, 36, 48]"
    ></my-pagination>
  </div>
</template>
<script>
import { Input, Button, DatePicker, Row, Col, Spin } from "view-design";
import myPagination from "@/components/common/myPagination";
export default {
  name: "myTrain",
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      iconImg: require("../../assets/images/train.png"),
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 12,
        pageNum: 1,
        startTime: "",
        endTime: ""
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  components: {
    "i-input": Input,
    "i-button": Button,
    "i-date-picker": DatePicker,
    "i-row": Row,
    "i-col": Col,
    "i-spin": Spin,
    "my-pagination": myPagination
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      tmpObj.startTime = new Date(tmpObj.startTime + " " + "00:00:00") || "";
      tmpObj.endTime = new Date(tmpObj.endTime + " " + "23:59:59") || "";
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/myProject/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 列表查询时的时间段改变的方法
    handleDatePickChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = arr[0];
      this.limitQuery.endTime = arr[1];
      this.initLoadTable();
    },
    clickToDetail(projectId) {
      this.$router.push(`/myTrainDetail/${projectId}`);
    }
  },
  filters: {
    projectStatusClassFilter(state) {
      switch (state) {
        case 4000:
          return "red";
        case 4002:
        case 4003:
        case 4007:
          return "orange";
        default:
          return "green";
      }
    },
    projectStatusValueFilter(state) {
      switch (state) {
        case 4000:
          return "已延期";
        case 4002:
        case 4003:
        case 4007:
          return "待参加";
        default:
          return "已参加";
      }
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        console.log(limitQuery);
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
        vm.limitQuery.startTime = limitQuery.startTime;
        vm.limitQuery.endTime = limitQuery.endTime;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.myTrain {
  position: relative;
  height: calc(100vh - 162px);
  .my-header {
    height: 36px;
    margin-bottom: 20px;
    & > :not(:last-child) {
      margin-right: $top;
    }
  }
  .content {
    height: calc(100vh - 278px);
    padding-right: 10px;
    overflow-y: auto;
    overflow-x: hidden;
    position: relative;
    .card-list {
      .my-card {
        background: #fff;
        cursor: pointer;
        .my-head {
          padding: 20px;
          line-height: 30px;
          height: 90px;
          max-height: 90px;
          display: flex;
          justify-content: space-between;
          .left {
            display: flex;
            .icon-img {
              width: 30px;
              height: 30px;
              border-radius: 50%;
              margin-right: 10px;
              img {
                width: 100%;
                height: 100%;
              }
            }
            span {
              font-weight: 900;
            }
          }
          .right {
            width: 70px;
            text-align: right;
          }
        }
        .my-body {
          padding: 20px;
          padding-top: 0;
          p {
            color: #999;
            line-height: 30px;
            font-size: 12px;
          }
        }
        .my-foot {
          border-top: 1px solid $border-color;
          height: 50px;
          text-align: center;
          line-height: 50px;
          color: $theme;
        }
      }
    }
    /deep/ .ivu-row-flex {
      margin-bottom: -30px;
      .ivu-col {
        margin-bottom: 30px;
      }
    }
  }
  .green {
    color: $theme;
    font-size: 12px;
  }
  .orange {
    color: $orange;
    font-size: 12px;
  }
  .red {
    color: $error;
    font-size: 12px;
  }
}
</style>
