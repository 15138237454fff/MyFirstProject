<template>
  <div class="teacherSummary">
    <div class="my-header">
      <i-input
        size="large"
        suffix="ios-search"
        v-model="limitQuery.query"
        @keyup.enter.native="initLoadTable"
        placeholder="请输入培训项目/课程名称"
        style="width: 210px"
        clearable
        @on-clear="initLoadTable"
      />
      <i-button size="large" @click="initLoadTable">查询</i-button>
      <i-date-picker
        :editable="false"
        type="daterange"
        separator=" 至 "
        :value="[limitQuery.startTime, limitQuery.endTime]"
        @on-change="handleDatePickChange"
        placeholder="请选择时间段"
        size="large"
      ></i-date-picker>
    </div>
    <i-table
      :height="tableHeight"
      :data="tableData"
      :columns="colOption"
      :border="true"
      :loading="loading"
    >
      <template slot="time" slot-scope="{ row }">
        <i-tooltip
          :content="
            `${$tagTime(row.projetStartTime, 'yyyy-MM-dd HH:mm')}
            至 ${$tagTime(row.projetEndTime, 'yyyy-MM-dd HH:mm')}`
          "
          :transfer="true"
          max-width="300px"
        >
          {{ $tagTime(row.projetStartTime, "yyyy-MM-dd HH:mm") }} 至
          {{ $tagTime(row.projetEndTime, "yyyy-MM-dd HH:mm") }}
        </i-tooltip>
      </template>
      <template slot="action" slot-scope="{ row, index }">
        <i-button
          size="large"
          @click="clickAdd(index)"
          type="primary"
          ghost
          v-if="row.status === 0"
          >在线添加</i-button
        >
        <span class="to-see" @click="clickDetail(index)" v-else>查看详情</span>
      </template>
    </i-table>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <template v-if="modalOption.key === 'add'">
        <div class="modal-content">
          <span>请填写培训小结：</span>
          <i-input
            placeholder="请输入"
            size="large"
            v-model="formData.summary"
            type="textarea"
            :autosize="{ minRows: 10, maxRows: 15 }"
          ></i-input>
        </div>
        <p slot="footer">
          <i-button size="large" @click="clickCancel">取消</i-button>
          <i-button size="large" type="primary" @click="clickOk">提交</i-button>
        </p>
      </template>
      <template v-else>
        <div class="modal-content">
          <!-- <div
            class="summary-content"
            v-html="this.$replaceAllStr(formData.summary, '\n', '<br/>')"
          ></div> -->
          <pre class="summary-content">{{ formData.summary }}</pre>
        </div>
      </template>
    </my-modal>
  </div>
</template>
<script>
import { Button, Table, Tooltip, Input, DatePicker } from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
export default {
  name: "teacherSummary",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-input": Input,
    "i-date-picker": DatePicker,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      showData: {
        startTime: "",
        endTime: "",
        // 培训地点
        trainingLocation: "",
        // 住宿信息
        roomInfo: "",
        // 项目名称
        projectName: ""
      },
      // 表格显示的配置项
      colOption: [
        {
          title: "序号",
          align: "center",
          width: 80,
          type: "index"
        },
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "培训课程", align: "center", key: "className", tooltip: true },
        { title: "培训时间", align: "center", slot: "time" },
        {
          title: "培训地点",
          align: "center",
          key: "trainingLocation",
          tooltip: true
        },
        { title: "培训小结", align: "center", width: 120, slot: "action" }
      ],
      limitQuery: {
        pageSize: 15,
        pageNum: 1,
        query: "",
        startTime: "",
        endTime: ""
      },
      formData: {
        projectId: "",
        summary: ""
      },
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-summary"
      },
      msgCount: 0,
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      tmpObj.startTime = new Date(tmpObj.startTime + " " + "00:00:00") || "";
      tmpObj.endTime = new Date(tmpObj.endTime + " " + "23:59:59") || "";
      this.$axios
        .post(`/api/summary/lecturer/mine/list`, tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 列表查询时的时间段改变的方法
    handleDatePickChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = arr[0];
      this.limitQuery.endTime = arr[1];
      this.initLoadTable();
    },
    // 点击在线添加
    clickAdd(index) {
      this.modalOption.title = `${this.tableData[index].projectName} 小结`;
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
      this.formData.projectId = this.tableData[index].projectId;
    },
    // 点击查看详情
    clickDetail(index) {
      this.modalOption.title = `${this.tableData[index].projectName} 小结`;
      this.modalOption.key = "detail";
      this.modalOption.modalVisiabal = true;
      this.formData.projectId = this.tableData[index].projectId;
      this.formData.summary = this.tableData[index].summary;
    },
    // 处理添加
    handleAdd() {
      this.$axios
        .post(`/api/summary/submit`, this.formData)
        .then(res => {
          this.$Message.success("提交成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击对话框的确认按钮
    clickOk() {
      let sign = this.testForm();
      if (!sign) {
        return;
      }
      this.handleAdd();
    },
    // 点击对话框的取消按钮
    clickCancel() {
      this.modalOption.modalVisiabal = false;
    },
    testForm() {
      if (this.formData.summary === "") {
        this.$Message.error("培训小结不能为空");
        return false;
      }
      if (this.formData.summary.length > 500) {
        this.$Message.error("培训小结不能超过500字");
        return false;
      }
      return true;
    },
    clearForm() {
      this.formData = {
        projectId: "",
        summary: ""
      };
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearForm();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 62;
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherSummary {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    margin-bottom: 20px;
    & > :not(:last-child) {
      margin-right: $top;
    }
  }
  .to-see {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
}
</style>
<style lang="scss" >
.modal-summary {
  .modal-content {
    span {
      display: block;
      font-size: 14px;
      line-height: 40px;
    }
    .summary-content {
      height: 300px;
      font-size: 14px;
      overflow: auto;
    }
  }
}
</style>
