<template>
  <div class="teacherAnalyse">teacherAnalyse</div>
</template>
<script>
export default {
  name: "teacherAnalyse"
};
</script>
<style lang="scss" scoped>
.teacherAnalyse {
}
</style>
