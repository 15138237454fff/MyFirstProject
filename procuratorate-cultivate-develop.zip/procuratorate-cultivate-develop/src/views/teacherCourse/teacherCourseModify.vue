<template>
  <div class="teacherCourseModify">
    <my-content-head>
      <div slot="left">
        <router-link to="/teacherCourse">我的课程</router-link>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clickSave">保存</i-button>
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-form :label-width="100" ref="formValidate" :rules="ruleValidate">
        <div class="row">
          <div class="col">
            <i-form-item label="课程名称：" required prop="className">
              <i-input
                v-model="formData.className"
                placeholder="请输入"
                size="large"
                :disabled="formData.isGray !== 0 || formData.classStatus === 2"
              ></i-input>
            </i-form-item>
          </div>
        </div>
        <div>
          <i-form-item label="课程类别：" required prop="classCategoryId">
            <i-cascader
              size="large"
              v-model="formData.classCategoryId"
              :data="courseTypeOption"
              :disabled="formData.classStatus === 2"
            ></i-cascader>
          </i-form-item>
        </div>
        <div class="row">
          <div class="col">
            <i-form-item label="学分：" required prop="classCredit">
              <i-input-number
                v-model="formData.classCredit"
                placeholder="请输入"
                size="large"
                :min="0.5"
                :disabled="formData.classStatus === 2"
              ></i-input-number>
            </i-form-item>
          </div>
          <div class="col">
            <i-form-item label="学时：" required prop="classPeriod">
              <i-input-number
                v-model="formData.classPeriod"
                placeholder="请输入"
                size="large"
                :disabled="formData.classStatus === 2"
                :min="0.5"
              ></i-input-number>
              <span style="color:#aaa;margin-left:5px;">
                时
              </span>
            </i-form-item>
          </div>
        </div>
        <i-form-item label="课程简介：" prop="classIntroduction">
          <div class="introduct">
            <i-input
              size="large"
              v-model="formData.classIntroduction"
              type="textarea"
              :autosize="{ minRows: 5, maxRows: 10 }"
            ></i-input>
          </div>
        </i-form-item>
        <i-form-item label="教学大纲：" prop="classOutline">
          <div class="outline">
            <tinymce-editor v-model="formData.classOutline"></tinymce-editor>
          </div>
        </i-form-item>
        <i-form-item label="教学课件：">
          <div class="upload">
            <i-upload
              :action="uploadUrl"
              :on-success="handleUploadSuccess"
              multiple
              :on-exceeded-size="handleMaxSize"
              :on-remove="handleRemoveList"
              :default-file-list="resourceFile"
              :show-upload-list="true"
            >
              <i-button ghost type="primary" size="large"
                >点击上传附件+</i-button
              >
            </i-upload>
          </div>
        </i-form-item>
      </i-form>
    </div>
  </div>
</template>
<script>
import {
  Input,
  Button,
  Upload,
  Form,
  FormItem,
  Cascader,
  InputNumber
} from "view-design";
import myContentHead from "@/components/common/myContentHead";
import TinymceEditor from "@/components/common/tinymce-editor";
export default {
  name: "teacherCourseModify",
  components: {
    "i-input": Input,
    "i-button": Button,
    "i-upload": Upload,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-cascader": Cascader,
    "i-input-number": InputNumber,
    "tinymce-editor": TinymceEditor,
    "my-content-head": myContentHead
  },
  props: { id: {} },
  data() {
    return {
      formData: {
        // 课程id
        classId: "",
        // 课程名称
        className: "",
        // 课程类别
        classCategoryId: [],
        // 学分
        classCredit: null,
        // 学时
        classPeriod: null,
        // 课程简介
        classIntroduction: "",
        // 审核状态
        classStatus: "",
        // 教学大纲
        classOutline: "",
        // 教学课件
        resourceFile: [],
        isGray: 0
      },
      ruleValidate: {
        className: [
          {
            require: true,
            message: "课程名称不能为空，且长度不能超过20位",
            trigger: "blur",
            max: 20
          }
        ],
        classCategoryId: [
          {
            require: true,
            message: "请选择课程类别",
            trigger: "blur"
          }
        ],
        classCredit: [
          {
            require: true,
            message: "学分不能为空",
            min: 0,
            trigger: "blur"
          }
        ],
        classPeriod: [
          {
            require: true,
            message: "学时不能为空",
            min: 0,
            trigger: "blur"
          }
        ]
      },
      // 课程类型查询的参数id
      parameterID: "XP-001",
      // 课程类型待选列表
      courseTypeOption: [],
      // 文件最大大小
      maxSize: 10240
    };
  },
  mounted() {
    // 请求课程类别下拉框数据
    this.requireCourseTypeOption();
    // 回显数据
    this.dataCallBack();
  },
  methods: {
    // 数据回显
    dataCallBack() {
      this.$axios
        .get(`/api/class/${this.id}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.formData.classCategoryId = [data.classCategoryId];
          this.formData.resourceFile = data.classFileVOS.map(el => {
            return { fileName: el.fileName, url: el.fileSrc };
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 校验表单的方法
    testForm() {
      let {
          className,
          classCredit,
          classPeriod,
          classCategoryId
        } = this.formData,
        normal = { value: false, msg: "请填写完整后再尝试保存！" };
      // 验证课程名称非空
      if (className === "") {
        return normal;
      }
      // 验证课程名称长度
      if (className.length > 20) {
        return { value: false, msg: "课程名称长度不能超过20位" };
      }
      // 验证课程类型非空
      if (classCategoryId.length === 0) {
        return normal;
      }
      // 验证学分非空
      if (classCredit === null) {
        return normal;
      }
      // 验证学时非空
      if (classPeriod === null) {
        return normal;
      }
      return { value: true, msg: "验证通过" };
    },
    // 处理保存的方法
    clickSave() {
      this.$log.INFO("正在保存");
      let result = this.testForm();
      if (result.value) {
        this.handleSave();
      } else {
        this.$Message.error(result.msg);
      }
    },
    handleSave() {
      // 浅克隆一份表单数据
      let tmpObj = Object.assign({}, this.formData);
      delete tmpObj.isGray;
      delete tmpObj.classStatus;
      // 将发送对象转为字符串
      tmpObj.classCategoryId =
        tmpObj.classCategoryId[tmpObj.classCategoryId.length - 1];
      this.$axios
        .put("/api/teacherClass/update", tmpObj)
        .then(res => {
          this.$Message.success("修改成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求课程类型参数的待选列表
    requireCourseTypeOption() {
      this.$axios
        .get(`/api/param/${this.parameterID}`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data.content)) {
            console.error("课程类别参数获取失败");
            return false;
          }
          // 数据格式化
          data.content = data.content.map(el => {
            return { label: el.title, value: el.title };
          });
          this.courseTypeOption = data.content;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 文件上传成功的处理函数
    handleUploadSuccess(res) {
      this.formData.resourceFile.push(res.data);
    },
    // 上传文件大小超过限制的处理函数
    handleMaxSize() {
      this.$Message.error(`请上传${this.maxSize / 1024}M以下的文件`);
    },
    handleRemoveList(file, fileList) {
      this.$log.INFO("移除文件列表");
      let index = this.formData.resourceFile.findIndex(el => {
        return el.name === file.name && el.url === file.url;
      });
      this.formData.resourceFile.splice(index, 1);
    },

    // 返回列表方法
    goBack() {
      this.clearFormData();
      this.$router.push("/teacherCourse");
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 课程id
        classId: "",
        // 课程名称
        className: "",
        // 课程类别
        classCategoryId: [],
        // 学分
        classCredit: null,
        // 学时
        classPeriod: null,
        // 课程简介
        classIntroduction: "",
        // 审核状态
        classStatus: "",
        // 教学大纲
        classOutline: "",
        // 教学课件
        resourceFile: [],
        isGray: 0
      };
    }
  },
  computed: {
    uploadUrl() {
      return this.$store.getters["skb/getUploadUrl"];
    },
    resourceFile() {
      return this.formData.resourceFile.map(el => {
        return { name: el.fileName, url: el.url };
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherCourseModify {
  .content {
    height: calc(100vh - 248px);
    background: #fff;
    padding: 30px 20px;
    overflow: auto;
    .row {
      display: flex;
      .col {
        flex: 1;
        display: flex;
      }
    }
    /deep/ .ivu-form .ivu-form-item-label {
      font-size: 14px;
    }
    .ivu-cascader {
      width: 300px;
    }
    /deep/ .ivu-input-wrapper {
      width: 300px !important;
    }
    .upload {
      width: 300px;
      .upload-msg {
        color: $error;
        margin-left: $top;
        line-height: $btn-height;
      }
    }
    .introduct {
      /deep/ .ivu-input-wrapper {
        width: 100% !important;
      }
    }
    .tinymce-editor {
      width: 100%;
    }
  }
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
}
</style>
