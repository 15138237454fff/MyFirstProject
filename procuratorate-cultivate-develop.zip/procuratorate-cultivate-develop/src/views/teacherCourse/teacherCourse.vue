<template>
  <div class="teacherCourse">
    <div class="my-header">
      <div class="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入课程名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div class="right">
        <i-button size="large" @click="clickAdd" type="primary">添加</i-button>
        <i-button size="large" @click="clickDelete" type="error">删除</i-button>
        <i-button size="large" @click="clickAduit" type="primary" ghost
          >提交审核</i-button
        >
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="examPaper" slot-scope="{ row }">
          <i-button size="large" v-if="row.classStatus !== 2" class="grey"
            >考试试卷</i-button
          >
          <i-button
            size="large"
            @click="clickPaper(row.classId, row.className)"
            type="primary"
            ghost
            v-else
            >考试试卷</i-button
          >
        </template>
        <template slot="status" slot-scope="{ row }">
          <span :class="row.classStatus | classStatusClassFilter">{{
            row.classStatus | classStatusValueFilter
          }}</span>
        </template>
        <template slot="option" slot-scope="{ row }">
          <span class="view" @click="clickDetail(row.classId)">查看</span>
          <span>&nbsp;|&nbsp;</span>
          <span
            class="modify"
            @click="clickModify(row.classId)"
            v-if="row.classStatus !== 1 && row.isUse === 0"
            >修改</span
          >
          <span class="disabled" v-else>修改</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      v-bind="limitQuery"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import { Table, Input, Button } from "view-design";
import myPagination from "@/components/common/myPagination";
export default {
  name: "teacherCourse",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "my-pagination": myPagination
  },
  data() {
    return {
      loading: false,
      // 消息总数量
      msgCount: 0,
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "课程名称",
          align: "center",
          key: "className",
          tooltip: true
        },
        {
          title: "课程类别",
          align: "center",
          key: "classCategoryId",
          tooltip: true
        },
        {
          title: "学分",
          align: "center",
          key: "classCredit",
          tooltip: true,
          width: 120
        },
        {
          title: "学时",
          align: "center",
          key: "classPeriod",
          tooltip: true,
          width: 120
        },
        { title: "考试试卷", align: "center", slot: "examPaper", width: 140 },
        { title: "状态", align: "center", slot: "status", width: 120 },
        { title: "操作", align: "center", slot: "option", width: 120 }
      ],
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 选中数据
      selectedHistoryList: []
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 点击添加按钮
    clickAdd() {
      console.log("添加");
      this.$router.push("/teacherCourseAdd");
    },
    // 删除按钮
    clickDelete() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除资源
    handleDelete() {
      this.$axios
        .delete("/api/teacherClass/delete", { data: this.selectedHistoryList })
        .then(res => {
          this.$Message.success("删除成功");
          this.selectedHistoryList = [];
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击提交审核
    clickAduit() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "提交审核",
        msg: "确定提交所选资源？",
        modalVisiabal: true,
        handleOk: this.handleSubmitAduit
      });
    },
    // 提交审核
    handleSubmitAduit() {
      this.$axios
        .put("/api/teacherClass/submitReview", this.selectedHistoryList)
        .then(res => {
          this.$Message.success("提交成功");
          this.selectedHistoryList = [];
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击考试试卷
    clickPaper(id, className) {
      this.$router.push(`/teacherCoursePaper/${id}/${className}`);
    },
    // 点击查看详情
    clickDetail(id) {
      console.log("点击查看详情");
      this.$router.push(`/teacherCourseDetail/${id}`);
    },
    // 点击修改
    clickModify(id) {
      console.log("点击修改");
      this.$router.push(`/teacherCourseModify/${id}`);
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 列表
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      let tmpObj = Object.assign({}, this.limitQuery);
      this.$axios
        .post("/api/teacherClass/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          data.list.forEach(el => {
            el._disabled = el.classStatus === 2 || el.classStatus === 1;
          });
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection.map(item => {
        return item.classId;
      });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 64;
    }
  },
  filters: {
    classStatusClassFilter(val) {
      switch (val) {
        case 0:
          return "red";
        case 1:
          return "orange";
        case 2:
          return "green";
        case 3:
          return "blue";
        default:
          return "";
      }
    },
    classStatusValueFilter(val) {
      switch (val) {
        case 0:
          return "退回";
        case 1:
          return "待审核";
        case 2:
          return "已通过";
        case 3:
          return "待提交";
        default:
          return "";
      }
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
      }
    });
  }
};
</script>

<style lang="scss" scoped>
.teacherCourse {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    .left {
      flex: 1;
      display: flex;
    }
    .right > :not(:last-child),
    .left > :not(:last-child) {
      margin-right: $top;
    }
  }
  /deep/ .ivu-rate-star {
    margin-right: 0px;
  }
  .grey {
    color: #ddd;
    &:hover {
      border-color: #ddd;
    }
  }
  .disabled {
    color: #999;
    text-decoration: underline;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .view {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
