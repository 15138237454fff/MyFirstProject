<template>
  <div class="teacherCourseDetail">
    <my-content-head>
      <div slot="left">
        <router-link to="/teacherCourse">我的课程</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="row">
        <span>课程名称：</span>
        <span>{{ showData.className }}</span>
      </div>
      <div class="row">
        <div class="col">
          <span>课程类别：</span>
          <span>{{ showData.classCategoryId }}</span>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <span>学分：</span>
          <span>{{ showData.classCredit }}</span>
        </div>
        <div class="col">
          <span>学时：</span>
          <span class="danwei">{{ showData.classPeriod }}</span>
        </div>
      </div>
      <div class="row">
        <span>课程简介：</span>
        <pre>{{ showData.classIntroduction }}</pre>
      </div>
      <div class="row outline">
        <span>教学大纲：</span>
        <p v-html="showData.classOutline"></p>
      </div>
      <div class="row">
        <span>教学课件：</span>
        <div
          class="attachment"
          v-for="(item, index) of showData.classFileVOS"
          :key="index"
        >
          <a
            :href="item.fileSrc"
            target="_blank"
            class="attachment"
            :download="item.fileName"
            >{{ item.fileName }}</a
          >
        </div>
      </div>
    </div>
    <back-aduit
      v-bind="backDetail"
      v-if="showData.classStatus === backStatus"
    ></back-aduit>
  </div>
</template>
<script>
import { Button } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import backAduit from "@/components/common/backAduit";
export default {
  name: "teacherCourseDetail",
  props: {
    id: {}
  },
  components: {
    "i-button": Button,
    "my-content-head": myContentHead,
    "back-aduit": backAduit
  },
  data() {
    return {
      // 课程详情数据
      showData: {
        // 课程名称
        className: "",
        // 课程类别
        classCategoryId: "",
        // 学分
        classCredit: "",
        // 学时
        classPeriod: "",
        // 课程简介
        classIntroduction: "",
        // 教学大纲
        classOutline: "",
        // 教学课件
        classFileVOS: [],
        classStatus: ""
      },
      backStatus: 0,
      backDetail: {
        // 审核人
        name: "",
        // 退回理由
        comment: "",
        // 审核时间
        auditDate: ""
      }
    };
  },
  mounted() {
    // 请求详情数据
    this.requireDetail();
  },
  methods: {
    // 请求课程详情数据
    requireDetail() {
      this.$axios
        .get(`/api/class/${this.id}`)
        .then(res => {
          let data = res.data.data;
          data.teacherName = data.teacherInfoVOS.map(el => (el ? el.name : ""));
          if (data.classTeacherType === 1) {
            data.teacherName.push(data.classExternalTeacherName);
          }
          Object.keys(this.showData).forEach(key => {
            this.showData[key] = data[key];
          });
          if (data.classStatus === 0) {
            this.requireBackDetail();
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求退回详情
    requireBackDetail() {
      this.$axios
        .get(`/api/teacherClass/rejectReason/${this.id}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            this.$Message.error("退回详情数据获取失败");
            return;
          }
          this.backDetail.name = data.name;
          this.backDetail.comment = data.classRejectReason;
          this.backDetail.auditDate = data.reviewerTime;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 返回列表方法
    goBack() {
      this.$router.push("/teacherCourse");
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherCourseDetail {
  .content {
    height: calc(100vh - 248px);
    background: #fff;
    padding: 30px 20px;
    overflow: auto;
    display: flex;
    flex-direction: column;
    .row {
      display: flex;
      margin-bottom: $input-top;
      span:first-child {
        display: block;
        width: 80px;
      }
      .col {
        flex: 1;
        display: flex;
        span:first-child {
          width: 80px;
        }
      }
    }
    .outline {
      height: 400px;
      p {
        width: 90%;
        height: 100%;
        overflow: auto;
        padding: $top;
        border: 1px solid $border-color;
      }
    }
    .attachment {
      text-decoration: underline;
      color: $theme;
    }
    .danwei:after {
      content: "时";
      color: $input-color;
      margin-left: 5px;
    }
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
  }
  span.back {
    font-size: 14px;
  }
}
</style>
