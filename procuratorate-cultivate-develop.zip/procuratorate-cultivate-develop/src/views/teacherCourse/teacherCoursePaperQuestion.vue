<template>
  <div class="teacherCoursePaper">
    <my-content-head>
      <div slot="left">
        <router-link to="/teacherCourse">我的课程</router-link>
        <router-link :to="`/teacherCoursePaper/${id}`"
          >&nbsp;/&nbsp;考试试卷</router-link
        >
      </div>
      <div slot="right">
        <i-button size="large" @click="clickSave" type="primary">保存</i-button>
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="card-title">
      <div class="left">
        <span class="class-name">课程名称：</span>
        <span class="class-name">{{ className }}</span>
      </div>
      <div class="right">
        <span>已选总分：{{ sumScore }}</span>
        <span class="require"
          >设置合格成绩：<i-input-number
            v-model="showData.passScore"
            placeholder="请输入"
            size="large"
            :min="0"
            :max="sumScore"
            :precision="0"
          ></i-input-number
        ></span>
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
      </i-table>
    </div>
  </div>
</template>
<script>
import { Button, Table, InputNumber } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "teacherCoursePaper",
  props: {
    id: {},
    className: {}
  },
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-input-number": InputNumber,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      showData: {
        paperId: "",
        passScore: 0
      },
      // 表格显示的配置项
      colOption: [
        { type: "selection", align: "center", width: 50 },
        {
          title: "题目名称",
          align: "center",
          key: "questionName",
          tooltip: true
        },
        {
          title: "题目类型",
          align: "center",
          render: (h, params) => {
            return h(
              "span",
              this.$getListValue(
                params.row.questionTypeId,
                this.questionsOption
              )
            );
          },
          width: 120
        },
        {
          title: "答案",
          align: "center",
          key: "answer",
          tooltip: true
        },
        {
          title: "分值",
          align: "center",
          key: "questionScore",
          tooltip: true,
          width: 100
        }
      ],
      loading: false,
      // 列表勾选项
      selectedHistoryList: [],
      // 试题类别可选列表
      questionsOption: [
        { value: 1, label: "单选题" },
        { value: 2, label: "多选题" },
        { value: 3, label: "判断题" }
      ]
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push(`/teacherCoursePaper/${this.id}/${this.className}`);
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      this.$axios
        .get(`/api/teacherClass/classQuestionList/${this.id}`)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.queationVOS)) {
            console.error("列表数据获取失败");
            return false;
          }
          data.queationVOS.forEach(el => {
            el._checked = el.questionNum !== null;
          });
          this.selectedHistoryList = data.queationVOS.filter(el => {
            return el._checked;
          });
          Object.keys(this.showData).forEach(key => {
            this.showData[key] = data[key];
          });
          // 保存列表数据
          this.tableData = data.queationVOS;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击保存
    clickSave() {
      this.handleSave();
    },
    // 保存考试题目
    handleSave() {
      console.log(this.selectedHistoryList);
      if (this.$isEmpty(this.showData.passScore)) {
        this.$Message.error("请填写通过成绩");
        return;
      }
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请至少勾选一条试题");
        return;
      }
      let questionList = this.selectedHistoryList.map((el, index) => {
          return {
            questionId: el.questionId,
            questionNum: index,
            questionStatus: el.questionStatus
          };
        }),
        questionDeleteList = this.tableData.filter(el => {
          return (
            el._checked &&
            questionList.findIndex(item => {
              return item.questionId === el.questionId;
            }) === -1
          );
        });
      this.$axios
        .post("/api/teacherClass/savePaper", {
          questionList,
          questionDeleteList,
          passScore: this.showData.passScore,
          classId: parseInt(this.id),
          paperId: parseInt(this.showData.paperId),
          sumScore: this.sumScore
        })
        .then(res => {
          this.$Message.success("添加成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
      if (this.showData.passScore > this.sumScore) {
        this.showData.passScore = this.sumScore;
      }
      console.log(selection);
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 190;
    },
    // 计算勾选的总分
    sumScore() {
      return this.selectedHistoryList.reduce((prev, el) => {
        return prev + el.questionScore;
      }, 0);
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherCoursePaper {
  .content {
    border-top: 1px solid $border-color;
    padding: 20px;
    background: #fff;
    position: relative;
    height: calc(100vh - 346px);
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .attachment {
      padding-top: $top;
      a {
        cursor: pointer;
        text-decoration: underline;
        color: $theme;
        margin-right: 20px;
      }
    }
  }
  .card-title {
    display: flex;
    height: 80px;
    margin-bottom: 10px;
    justify-content: space-between;
    align-items: center;
    background: #fff;
    border-radius: 5px;
    padding: 20px;
    .left,
    .right {
      flex: 1;
    }
    .right {
      text-align: right;
      span {
        display: inline-block;
        text-align: left;
        width: 200px;
      }
    }
    .class-name {
      font-weight: bold;
      font-size: 18px;
      color: #000;
    }
  }
  .to-see {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
  .back {
    background: #fff;
  }
}
</style>
