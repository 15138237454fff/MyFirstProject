<template>
  <div class="teacherCoursePaper">
    <my-content-head>
      <div slot="left">
        <router-link to="/teacherCourse">我的课程</router-link>
      </div>
      <div slot="right">
        <i-button size="large" @click="clickSetQuestion" type="primary"
          >设置考试题目</i-button
        >
        <i-button size="large" @click="clickModifySort" type="primary" ghost>{{
          canSortTable ? "保存试题排序" : "调整试题排序"
        }}</i-button>
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="card-title">
      <div class="left">
        <span class="class-name">课程名称：</span>
        <span class="class-name">{{ className }}</span>
      </div>
      <div class="right">
        <span>已选总分：{{ showData.sumScore }}</span>
        <span>合格成绩：{{ showData.passScore }}</span>
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :draggable="canSortTable"
        @on-drag-drop="handleDragDrop"
        :border="true"
        :loading="loading"
      >
        <template slot="sort" slot-scope="{ row, index }">
          <span v-if="canSortTable">
            <i-icon type="md-move" :size="24" />
          </span>
          <span v-else>{{ index + 1 }}</span>
        </template>
      </i-table>
    </div>
  </div>
</template>
<script>
import { Button, Table, Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "teacherCoursePaper",
  props: {
    id: {},
    className: {}
  },
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-icon": Icon,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      showData: {
        passScore: 0,
        sumScore: 0,
        paperId: ""
      },
      // 表格显示的配置项
      colOption: [
        {
          title: "题目名称",
          align: "center",
          key: "questionName",
          tooltip: true
        },
        {
          title: "题目类型",
          align: "center",
          render: (h, params) => {
            return h(
              "span",
              this.$getListValue(
                params.row.questionTypeId,
                this.questionsOption
              )
            );
          },
          width: 120
        },
        {
          title: "答案",
          align: "center",
          key: "answer",
          tooltip: true
        },
        {
          title: "分值",
          align: "center",
          key: "questionScore",
          tooltip: true,
          width: 100
        },
        { title: "排序", align: "center", width: 120, slot: "sort" }
      ],
      loading: false,
      canSortTable: false,
      // 试题类别可选列表
      questionsOption: [
        { value: 1, label: "单选题" },
        { value: 2, label: "多选题" },
        { value: 3, label: "判断题" }
      ]
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/teacherCourse");
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      this.$axios
        .get(`/api/teacherClass/getPaper/${this.id}`)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data) {
            console.error("试卷数据获取失败");
            return false;
          }
          Object.keys(this.showData).forEach(key => {
            this.showData[key] = data[key];
          });
          // 保存列表数据
          this.tableData = data.queationVOS;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击设置考试题目
    clickSetQuestion() {
      console.log(this.showData);
      this.$router.push(
        `/teacherCoursePaperQuestion/${this.id}/${this.className}`
      );
    },
    // 点击调整排序
    clickModifySort() {
      if (this.canSortTable) {
        this.handleSavePaper();
      } else {
        this.canSortTable = true;
      }
    },
    // 处理拖拽的方法
    handleDragDrop(index1, index2) {
      index1 = parseInt(index1);
      index2 = parseInt(index2);
      // this.tableData[index1].questionNum = index2;
      // this.tableData[index2].questionNum = index1;
      // 交换拖拽的起始行和目标行
      this.tableData = this.$displace(index1, index2, this.tableData);
      this.tableData.forEach((el, index) => {
        el.questionNum = index;
      });
    },
    // 保存试卷排序结果
    handleSavePaper() {
      this.$axios
        .put("/api/teacherClass/questionOrder", this.tableData)
        .then(res => {
          this.$Message.success("调整成功");
          this.canSortTable = false;
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 190;
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherCoursePaper {
  .content {
    border-top: 1px solid $border-color;
    padding: 20px;
    background: #fff;
    position: relative;
    height: calc(100vh - 346px);
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .attachment {
      padding-top: $top;
      a {
        cursor: pointer;
        text-decoration: underline;
        color: $theme;
        margin-right: 20px;
      }
    }
  }
  .card-title {
    display: flex;
    height: 80px;
    margin-bottom: 10px;
    justify-content: space-between;
    align-items: center;
    background: #fff;
    border-radius: 5px;
    padding: 20px;
    .left,
    .right {
      flex: 1;
    }
    .right {
      text-align: right;
      span {
        display: inline-block;
        text-align: left;
        width: 200px;
      }
    }
    .class-name {
      font-weight: bold;
      font-size: 18px;
      color: #000;
    }
  }
  .to-see {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
  .back {
    background: #fff;
  }
}
</style>
