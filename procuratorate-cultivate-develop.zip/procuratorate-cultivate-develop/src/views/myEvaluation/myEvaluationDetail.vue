<template>
  <div class="onlineEvaluation">
    <my-content-head>
      <div slot="left">
        <router-link to="/myEvaluation">我的评价</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="card-title">
      <div class="left">
        <div class="class-name">
          <span>
            {{ formData.className }}
          </span>
        </div>
        <div class="tip">
          <p>培训项目：{{ formData.projectName }}</p>
          <p>
            培训时间：{{ $tagTime(formData.startTime, "yyyy-MM-dd") }}
            {{ $tagTime(formData.startTime, "HH:mm") }} ~
            {{ $tagTime(formData.endTime, "HH:mm") }}
          </p>
        </div>
      </div>
      <div class="center tip">
        <div class="text">
          <p>培训讲师：{{ formData.teacherName }}</p>
          <p>培训地点：{{ formData.trainingLocation }}</p>
        </div>
      </div>
      <div class="right">
        <span class="green">评教总分：{{ formData.sumScore }}分</span>
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
      </i-table>
    </div>
  </div>
</template>
<script>
import { Button, Table } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "onlineEvaluation",
  props: {
    id: {}
  },
  components: {
    "i-button": Button,
    "i-table": Table,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "序号",
          align: "center",
          width: 80,
          type: "index"
        },
        {
          title: "评价项目",
          align: "center",
          key: "questionnaireProject",
          tooltip: true
        },
        {
          title: "评价内容",
          align: "center",
          key: "questionnaireContent",
          tooltip: true
        },
        {
          title: "评价分数",
          align: "center",
          width: 120,
          key: "questionnaireSorce"
        }
      ],
      formData: {
        // 结束时间
        endTime: "",
        // 项目名称
        projectName: "",
        // 开始时间
        startTime: "",
        // 评价总分
        sumScore: 0,
        // 教师姓名
        teacherName: "",
        // 培训地点
        trainingLocation: "",
        // 课程名称
        className: ""
      },
      loading: false
    };
  },
  mounted() {
    // 请求项目详情
    this.requireProjectDetail();
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/myEvaluation");
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      this.$axios
        .get(`/api/myEvaluate/myEvaluateInfoList/${this.id}`)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    requireProjectDetail() {
      this.$axios
        .get(`/api/myEvaluate/getEvaluateBanner/${this.id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (this.$isEmpty(data)) {
            console.error("项目详情数据获取失败");
            return false;
          }
          // 保存列表数据
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
        });
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 160;
    }
  }
};
</script>
<style lang="scss" scoped>
.onlineEvaluation {
  .content {
    border-top: 1px solid $border-color;
    padding: 20px;
    background: #fff;
    position: relative;
    overflow: auto;
    .title {
      font-weight: 900;
      width: 100%;
      text-align: center;
      height: 80px;
      line-height: 80px;
      font-size: 16px;
      border-bottom: 1px solid $border-color;
    }
    .attachment {
      padding-top: $top;
      a {
        cursor: pointer;
        text-decoration: underline;
        color: $theme;
        margin-right: 20px;
      }
    }
  }
  .card-title {
    display: flex;
    margin-bottom: 10px;
    line-height: 30px;
    justify-content: space-between;
    background: #fff;
    border-radius: 5px;
    padding: 20px;
    .left {
      display: flex;
      flex: 1;
    }
    .right {
      text-align: right;
      font-size: 18px;
      font-weight: bold;
      flex: 1;
    }
    .green {
      color: $theme;
    }
    .class-name {
      font-size: 18px;
      font-weight: bold;
      margin-right: 40px;
    }
    .tip p {
      color: #999;
    }
  }
  .back {
    background: #fff;
    margin-left: 10px;
  }
}
</style>
