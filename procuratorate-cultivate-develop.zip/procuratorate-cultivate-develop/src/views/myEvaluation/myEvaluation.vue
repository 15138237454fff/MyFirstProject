<template>
  <div class="myEvaluation">
    <div class="my-header">
      <i-input
        size="large"
        suffix="ios-search"
        v-model="limitQuery.query"
        @keyup.enter.native="initLoadTable"
        placeholder="请输入培训项目名称"
        style="width: 210px"
        clearable
        @on-clear="initLoadTable"
      />
      <i-button size="large" @click="initLoadTable">查询</i-button>
    </div>
    <i-table
      :height="tableHeight"
      :data="tableData"
      :columns="colOption"
      :border="true"
      :loading="loading"
    >
      <template slot="time" slot-scope="{ row }">
        <i-tooltip
          :content="
            `${$tagTime(row.trainingTimeStart, 'yyyy-MM-dd HH:mm')}
            至 ${$tagTime(row.trainingTimeEnd, 'yyyy-MM-dd HH:mm')}`
          "
          :transfer="true"
          max-width="300px"
        >
          {{ $tagTime(row.trainingTimeStart, "yyyy-MM-dd HH:mm") }} 至
          {{ $tagTime(row.trainingTimeEnd, "yyyy-MM-dd HH:mm") }}
        </i-tooltip>
      </template>
      <template slot="action" slot-scope="{ row, index }">
        <i-button
          size="large"
          @click="clickAdd(index)"
          type="primary"
          ghost
          v-if="row.questionnaireSorce === 0"
          >在线评教</i-button
        >
        <span class="to-see" @click="clickDetail(index)" v-else>查看评教</span>
      </template>
    </i-table>
    <my-pagination
      @paginate="handlePaginate"
      v-bind="limitQuery"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Button, Table, Tooltip, Input } from "view-design";
import myPagination from "@/components/common/myPagination";
export default {
  name: "myEvaluation",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-input": Input,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      showData: {
        startTime: "",
        endTime: "",
        // 培训地点
        trainingLocation: "",
        // 住宿信息
        roomInfo: "",
        // 项目名称
        projectName: ""
      },
      // 表格显示的配置项
      colOption: [
        {
          title: "序号",
          align: "center",
          width: 80,
          type: "index"
        },
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "课程名称", align: "center", key: "className", tooltip: true },
        {
          title: "培训讲师",
          align: "center",
          key: "teacherName",
          tooltip: true
        },
        { title: "培训时间", align: "center", slot: "time" },
        {
          title: "培训地点",
          align: "center",
          key: "trainingLocation",
          tooltip: true
        },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      limitQuery: {
        pageSize: 15,
        pageNum: 1,
        query: ""
      },
      formData: {
        projectId: "",
        summary: ""
      },
      msgCount: 0,
      loading: false
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      this.$axios
        .post(`/api/myEvaluate/myEvaluateList`, this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击在线评价
    clickAdd(index) {
      this.$router.push(
        `/onlineEvaluation/${this.tableData[index].projectClassapplyId}`
      );
    },
    // 点击查看详情
    clickDetail(index) {
      this.$router.push(
        `/myEvaluationDetail/${this.tableData[index].projectClassapplyId}`
      );
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 62;
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        console.log(limitQuery);
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.myEvaluation {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    margin-bottom: 20px;
    & > :not(:last-child) {
      margin-right: $top;
    }
  }
  .to-see {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
}
</style>
