<template>
  <div class="myStudyDetail">
    <my-content-head>
      <div slot="left">
        <router-link to="/myStudy">我的学习</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <resource-detail :id="id"></resource-detail>
    </div>
  </div>
</template>
<script>
import { Button } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import resourceDetail from "@/components/common/resourceDetail";
export default {
  name: "myStudyDetail",
  props: {
    id: {}
  },
  components: {
    "i-button": Button,
    "my-content-head": myContentHead,
    "resource-detail": resourceDetail
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/myStudy");
    }
  }
};
</script>
<style lang="scss" scoped>
.myStudyDetail {
  flex-direction: column;
  display: flex;
  .back {
    background: #fff;
  }
}
</style>
