<template>
  <div class="myStudy">
    <div class="my-header">
      <div class="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入资源名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-cascader
          size="large"
          v-model="limitQuery.category"
          :data="moreCategoryList"
          @on-change="handleCascaderChange"
          change-on-select
          :clearable="false"
        ></i-cascader>
      </div>
      <div class="right">
        <i-button size="large" @click="clickToResourceCenter" type="primary"
          >进入资源中心</i-button
        >
      </div>
    </div>
    <div class="content">
      <i-row class="card-list" :gutter="30" type="flex">
        <i-col :span="6" v-for="(item, index) of tableData" :key="index">
          <div class="my-card">
            <div class="preview-img">
              <img :src="item.resourcePreview" />
              <div
                class="preview-mock"
                @click="clickToDetail(item.id)"
                :class="
                  wordList.includes(item.resourceFileType)
                    ? 'pdf-mock'
                    : 'video-mock'
                "
              ></div>
            </div>
            <div class="my-body">
              <div class="top">
                <i-tooltip
                  class="resource-name"
                  :max-width="300"
                  :content="item.resourceName"
                  placement="bottom"
                  :transfer="true"
                  >{{ item.resourceName }}</i-tooltip
                >
                <i-tooltip
                  :max-width="400"
                  theme="light"
                  placement="bottom"
                  :transfer="true"
                >
                  <div slot="content">
                    <div v-for="(val, ind) of item.evaluateDetail" :key="ind">
                      <i-rate disabled :value="ind + 1" />
                      <span class="evaluate-count">{{ val }}人</span>
                    </div>
                  </div>
                  <i-rate
                    disabled
                    :value="item.evaluate ? item.evaluate : 0"
                    allow-half
                  />
                </i-tooltip>
              </div>
              <div class="bottom">
                <span>学习进度：{{ item.progress }}%</span>
                <i-button
                  size="small"
                  @click="clickCancelAttention(item.id)"
                  class="cancel-attention"
                  >取消关注</i-button
                >
              </div>
            </div>
          </div>
        </i-col>
      </i-row>
      <i-spin size="large" fix v-if="loading"></i-spin>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      v-bind="limitQuery"
      :msgCount="msgCount"
      :pageSizeOptions="[12, 24, 36, 48]"
    ></my-pagination>
  </div>
</template>
<script>
import {
  Input,
  Button,
  Row,
  Col,
  Cascader,
  Tooltip,
  Rate,
  Spin
} from "view-design";
import myPagination from "@/components/common/myPagination";
export default {
  name: "myStudy",
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      iconImg: require("../../assets/images/train.png"),
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 12,
        pageNum: 1,
        category: [""]
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 资源类别
      categoryList: []
    };
  },
  components: {
    "i-input": Input,
    "i-button": Button,
    "i-row": Row,
    "i-col": Col,
    "i-cascader": Cascader,
    "i-tooltip": Tooltip,
    "i-rate": Rate,
    "i-spin": Spin,
    "my-pagination": myPagination
  },
  mounted() {
    this.$nextTick(() => {
      // 查询资源类别
      this.queryResoureType();
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 取出资源类别并覆盖原值
      tmpObj.category = tmpObj.category[tmpObj.category.length - 1];
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/rcc/study/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 取消关注
    clickCancelAttention(id) {
      console.log("取消关注");
      this.$axios
        .post(`/api/rcc/unfollow/${id}`)
        .then(res => {
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickToDetail(id) {
      this.$router.push(`/myStudyDetail/${id}`);
      // 准备记录一次访问记录
      this.$store.commit("skb/updateIsVisit", 1);
    },
    // 点击前往资源中心
    clickToResourceCenter() {
      this.$router.push("/resourceCenter");
    },
    // 查询资源类别
    queryResoureType() {
      this.$axios
        .get("/api/param/select/XP-002")
        .then(res => {
          let data = res.data.data;
          // 数据格式化
          data = data.map(obj => {
            return {
              label: obj.title,
              value: obj.title,
              children: obj.children.map(el => {
                return { value: el, label: el };
              })
            };
          });
          this.categoryList = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 监听级联选择器的变化
    handleCascaderChange(val) {
      this.limitQuery.category = val;
      this.initLoadTable();
    }
  },
  computed: {
    moreCategoryList() {
      let tmpArr = this.categoryList.map(el => el);
      tmpArr.unshift({
        label: "全部资源类别",
        value: ""
      });
      return tmpArr;
    },
    wordList() {
      return this.$store.getters["skb/getWordList"];
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
        vm.limitQuery.category = limitQuery.category;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.myStudy {
  position: relative;
  height: calc(100vh - 162px);
  .my-header {
    height: 36px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    .left {
      display: flex;
    }
    .left > :not(:last-child) {
      margin-right: $top;
    }
  }
  .content {
    height: calc(100vh - 278px);
    padding-right: 10px;
    overflow-y: auto;
    overflow-x: hidden;
    position: relative;
    .card-list {
      .my-card {
        padding: 20px;
        background: #fff;
        .preview-img {
          width: 100%;
          border-radius: 5px;
          height: 194px;
          overflow: hidden;
          position: relative;
          img {
            display: block;
            object-fit: cover;
            width: 100%;
            height: 100%;
          }
          .preview-mock {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3) no-repeat 50% 50%;
            background-size: 80px;
            cursor: pointer;
            text-align: center;
            color: #fff;
            line-height: 200px;
          }
          .video-mock {
            background-image: url("../../assets/images/video.png");
          }
          .pdf-mock {
            background-image: url("../../assets/images/pdf.png");
          }
        }
        .my-body {
          padding-top: 10px;
          .top,
          .bottom {
            display: flex;
            justify-content: space-between;
          }
          .resource-name {
            font-weight: bold;
            font-size: 16px;
            line-height: 32px;
            max-width: 150px;
            @extend .text-ellipsis;
          }
          .evaluate-count {
            margin-left: 10px;
          }
          .cancel-attention {
            color: #999;
          }
        }
      }
    }
    /deep/ .ivu-rate-star {
      margin-right: 0px;
    }
    /deep/ .ivu-row-flex {
      margin-bottom: -30px;
      .ivu-col {
        margin-bottom: 30px;
      }
    }
  }
  .green {
    color: $theme;
    font-size: 12px;
  }
  .orange {
    color: $orange;
    font-size: 12px;
  }
}
</style>
