<template>
  <div class="resourceCenter">
    <div class="category">
      <ul class="one-category">
        <li
          v-for="(item, index) of categoryList"
          :key="index"
          :class="{ green: limitQuery.category[0] === item.value }"
          @click="clickOneCategory(item.value)"
        >
          <div
            class="square"
            v-if="limitQuery.category[0] === item.value"
          ></div>
          {{ item.label }}
        </li>
      </ul>
      <ul class="two-category">
        <li
          v-for="(item, index) of categoryList.find(el => {
            return el.value === limitQuery.category[0];
          }) &&
            categoryList.find(el => {
              return el.value === limitQuery.category[0];
            }).children"
          :key="index"
          :class="{ green: limitQuery.category[1] === item.value }"
          @click="clickTwoCategory(item.value)"
        >
          {{ item.label }}
        </li>
      </ul>
    </div>
    <div class="my-header">
      <div class="left">
        <span @click="limitQuery.category = ['', '']">资源中心</span>
        <template v-for="(item, index) of limitQuery.category">
          <span :key="index" v-if="item">
            <span>&nbsp;/&nbsp;</span>
            <span
              @click="
                limitQuery.category = limitQuery.category.slice(0, index + 1)
              "
              >{{ item }}</span
            >
          </span>
        </template>
      </div>
      <div class="right">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入资源名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
    </div>
    <div class="content">
      <i-row class="card-list" :gutter="30" type="flex">
        <i-col :span="8" v-for="(item, index) of tableData" :key="index">
          <div class="my-card">
            <div class="preview-img">
              <img :src="item.resourcePreview" />
              <div
                class="preview-mock"
                :class="
                  wordList.includes(item.resourceFileType)
                    ? 'pdf-mock'
                    : 'video-mock'
                "
                @click="clickToDetail(item.id)"
              ></div>
            </div>
            <div class="my-body">
              <i-tooltip
                :max-width="300"
                class="resource-name"
                placement="bottom"
                :transfer="true"
                :content="item.resourceName"
              >
                {{ item.resourceName }}
              </i-tooltip>
              <i-tooltip
                :max-width="400"
                theme="light"
                placement="bottom"
                :transfer="true"
              >
                <div slot="content">
                  <div v-for="(val, ind) of item.evaluateDetail" :key="ind">
                    <i-rate disabled :value="ind + 1" />
                    <span class="evaluate-count">{{ val }}人</span>
                  </div>
                </div>
                <i-rate
                  disabled
                  :value="item.evaluate ? item.evaluate : 0"
                  allow-half
                />
              </i-tooltip>
              <span v-if="Array.isArray(item.resourceType)">
                资源类型：{{ item.resourceType.join(" / ") }}
              </span>
              <p class="some-data">
                <i-icon type="md-eye" size="19" />
                <span>{{ item.visits }}</span>
                <span>&nbsp;</span>
                <i-icon type="md-star-outline" size="19" />
                <span>{{ item.attention }}</span>
              </p>
              <i-button
                size="small"
                @click="clickAttention(item.id)"
                class="attention"
                v-if="item.concerns === 0"
                >关注</i-button
              >
              <i-button
                size="small"
                @click="clickCancelAttention(item.id)"
                class="cancel-attention"
                v-else
                >取消关注</i-button
              >
            </div>
          </div>
        </i-col>
      </i-row>
      <i-spin size="large" fix v-if="loading"></i-spin>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      v-bind="limitQuery"
      :msgCount="msgCount"
      :pageSizeOptions="[15, 30, 45, 60]"
    ></my-pagination>
  </div>
</template>
<script>
import {
  Input,
  Button,
  Row,
  Col,
  Tooltip,
  Rate,
  Icon,
  Spin
} from "view-design";
import myPagination from "@/components/common/myPagination";
export default {
  name: "resourceCenter",
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      iconImg: require("../../assets/images/train.png"),
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        category: ["", ""]
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 资源类别
      categoryList: []
    };
  },
  components: {
    "i-input": Input,
    "i-button": Button,
    "i-row": Row,
    "i-col": Col,
    "i-tooltip": Tooltip,
    "i-rate": Rate,
    "i-icon": Icon,
    "i-spin": Spin,
    "my-pagination": myPagination
  },
  mounted() {
    this.$nextTick(() => {
      // 查询资源类别
      this.queryResoureType();
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      let category = tmpObj.category[tmpObj.category.length - 1];
      // 取出资源类别并覆盖原值
      tmpObj.category = category === "" ? tmpObj.category[0] : category;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/rcc/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    clickAttention(id) {
      console.log("关注");
      this.$axios
        .post(`/api/rcc/focus/${id}`)
        .then(res => {
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 取消关注
    clickCancelAttention(id) {
      console.log("取消关注");
      this.$axios
        .post(`/api/rcc/unfollow/${id}`)
        .then(res => {
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickToDetail(id) {
      this.$router.push(`/resourceCenterDetail/${id}`);
      // 准备记录一次访问记录
      this.$store.commit("skb/updateIsVisit", 1);
    },
    // 查询资源类别
    queryResoureType() {
      this.$axios
        .get("/api/param/select/XP-002")
        .then(res => {
          let data = res.data.data;
          // 数据格式化
          data = data.map(obj => {
            let children = obj.children.map(el => {
              return { value: el, label: el };
            });
            children.unshift({ value: "", label: "全部分类" });
            return {
              label: obj.title,
              value: obj.title,
              children: children
            };
          });
          data.unshift({
            label: "全部分类",
            value: "",
            children: [{ value: "", label: "全部分类" }]
          });
          this.categoryList = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 监听级联选择器的变化
    clickOneCategory(val) {
      this.limitQuery.category = [val, ""];
      this.initLoadTable();
    },
    // 监听级联选择器的变化
    clickTwoCategory(val) {
      this.limitQuery.category = [this.limitQuery.category[0], val];
      this.initLoadTable();
    }
  },
  computed: {
    wordList() {
      return this.$store.getters["skb/getWordList"];
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.alias === from.meta.alias) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        console.log(limitQuery);
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
        vm.limitQuery.category = limitQuery.category;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.resourceCenter {
  position: relative;
  height: calc(100vh - 192px);
  background: #fff;
  padding: 20px;
  .category {
    margin-bottom: 10px;
    .one-category {
      background: #f5f5f5;
      display: flex;
      align-items: center;
      height: 40px;
      padding: 0 14px;
      li {
        height: 40px;
        line-height: 40px;
        padding: 0 20px;
        cursor: pointer;
        position: relative;
        .square {
          width: 10px;
          height: 10px;
          background: #fff;
          transform: translate(-50%, 50%) rotate(45deg);
          border-top: 1px solid $border-color;
          border-left: 1px solid $border-color;
          position: absolute;
          bottom: 0;
          left: 50%;
        }
      }
    }
    .two-category {
      border: 1px solid $border-color;
      display: flex;
      align-items: center;
      height: 40px;
      padding: 0 14px;
      li {
        height: 40px;
        line-height: 40px;
        padding: 0 20px;
        cursor: pointer;
        &.green {
          border-bottom: 2px solid $theme;
        }
      }
    }
  }
  .my-header {
    height: 36px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    .right > :not(:last-child) {
      margin-right: $top;
    }
    .left {
      & > span {
        line-height: 36px;
        color: #999;
        cursor: pointer;
      }
      & > span:last-child {
        color: $theme;
        line-height: 36px;
        cursor: default;
      }
    }
  }
  .content {
    height: calc(100vh - 410px);
    padding-right: 10px;
    overflow-y: auto;
    overflow-x: hidden;
    position: relative;
    .card-list {
      .my-card {
        background: #fff;
        display: flex;
        .preview-img {
          width: 200px;
          border-radius: 5px;
          height: 120px;
          overflow: hidden;
          position: relative;
          margin-right: 20px;
          img {
            object-fit: cover;
            height: 100%;
            width: 100%;
          }
          .preview-mock {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3) no-repeat 50% 50%;
            background-size: 80px;
            cursor: pointer;
            text-align: center;
            color: #fff;
            line-height: 200px;
          }
          .video-mock {
            background-image: url("../../assets/images/video.png");
          }
          .pdf-mock {
            background-image: url("../../assets/images/pdf.png");
          }
        }
        .my-body {
          position: relative;
          display: flex;
          flex-direction: column;
          justify-content: space-around;
          flex: 1;
          .resource-name /deep/ .ivu-tooltip-rel {
            font-weight: bold;
            font-size: 16px;
            width: 160px;
            word-break: break-all;
            text-overflow: ellipsis;
            display: -webkit-box; /** 对象作为伸缩盒子模型显示 **/
            -webkit-box-orient: vertical; /** 设置或检索伸缩盒对象的子元素的排列方式 **/
            -webkit-line-clamp: 2; /** 显示的行数 **/
            overflow: hidden; /** 隐藏超出的内容 **/
          }
          .evaluate-count {
            margin-left: 10px;
          }
          .some-data {
            line-height: 24px;
          }
          .ivu-icon {
            margin-right: 5px;
            line-height: 24px;
          }
          .attention,
          .cancel-attention {
            color: $theme;
            border: 1px solid $theme;
            position: absolute;
            right: 0;
            top: 0;
          }
          .cancel-attention {
            color: #999;
            border: 1px solid #999;
          }
        }
      }
    }
    /deep/ .ivu-rate-star {
      margin-right: 0px;
    }
    /deep/ .ivu-row-flex {
      margin-bottom: -20px;
      .ivu-col {
        margin-bottom: 20px;
      }
    }
  }
  .green {
    color: $theme;
  }
  .orange {
    color: $orange;
  }
}
</style>
