<template>
  <div class="resourceCenterDetail">
    <my-content-head>
      <div slot="left">
        <router-link to="/resourceCenter">资源中心</router-link>
      </div>
      <div slot="right">
        <i-button
          class="back"
          @click="goBack"
          icon="ios-undo"
          size="large"
          ghost
          type="primary"
          >返回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <resource-detail :id="id"></resource-detail>
    </div>
  </div>
</template>
<script>
import { Button } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import resourceDetail from "@/components/common/resourceDetail";
export default {
  name: "resourceCenterDetail",
  props: {
    id: {}
  },
  components: {
    "i-button": Button,
    "my-content-head": myContentHead,
    "resource-detail": resourceDetail
  },
  mounted() {
    console.log(this.id);
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/resourceCenter");
    }
  }
};
</script>
<style lang="scss" scoped>
.resourceCenterDetail {
  flex-direction: column;
  display: flex;
  .back {
    background: #fff;
  }
}
</style>
