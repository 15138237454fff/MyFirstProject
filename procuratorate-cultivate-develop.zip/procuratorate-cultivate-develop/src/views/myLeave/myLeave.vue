<template>
  <div class="myLeave">
    <div class="my-header">
      <i-date-picker
        :editable="false"
        type="daterange"
        separator=" 至 "
        :value="[limitQuery.startTime, limitQuery.endTime]"
        @on-change="handleDatePickChange"
        placeholder="请选择时间段"
        size="large"
      ></i-date-picker>
      <i-button size="large" type="primary" @click="clickAdd">添加</i-button>
    </div>
    <i-table
      :height="tableHeight"
      :data="tableData"
      :columns="colOption"
      :border="true"
      :loading="loading"
    >
      <template slot="classInfos" slot-scope="{ row }">
        <template v-if="!row.classInfos.includes(null)">
          <i-tooltip
            :content="
              row.classInfos
                .map(el => {
                  return `${el.className}\n（${$tagTime(
                    el.startTime,
                    'yyyy-MM-dd HH:mm'
                  )} ~ ${$tagTime(el.endTime, 'HH:mm')}）`;
                })
                .join('\n')
            "
            :transfer="true"
            max-width="300px"
          >
            {{
              row.classInfos
                .map(el => {
                  return `${el.className} (${$tagTime(
                    el.startTime,
                    "yyyy-MM-dd HH:mm"
                  )} ~ ${$tagTime(el.endTime, "HH:mm")}) `;
                })
                .join("，")
            }}
          </i-tooltip>
        </template>
      </template>
      <template slot="applyTime" slot-scope="{ row }">
        <i-tooltip
          :content="`${$tagTime(row.applyTime, 'yyyy-MM-dd HH:mm')}`"
          :transfer="true"
          max-width="300px"
        >
          {{ $tagTime(row.applyTime, "yyyy-MM-dd HH:mm") }}
        </i-tooltip>
      </template>
      <template slot="status" slot-scope="{ row }">
        <span :class="row.status | statusClassFilter" v-if="row.status !== 1">{{
          row.status | statusValueFilter
        }}</span>
        <i-tooltip
          :transfer="true"
          max-width="300px"
          :content="row.rejectReason"
          v-else
        >
          <span class="red">不通过</span>
        </i-tooltip>
      </template>
    </i-table>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <i-form
          :model="formData"
          :label-width="100"
          ref="formValidate"
          :rules="ruleValidate"
        >
          <i-form-item label="请假类型：" required prop="leaveType">
            <i-radio-group v-model="formData.leaveType" size="large">
              <i-radio :label="0">事假</i-radio>
              <i-radio :label="1">病假</i-radio>
            </i-radio-group>
          </i-form-item>
          <i-form-item label="请假事由：" required prop="leaveReason">
            <i-input
              v-model="formData.leaveReason"
              size="large"
              type="textarea"
              :autosize="{ minRows: 4, maxRows: 6 }"
            >
            </i-input>
          </i-form-item>
          <i-form-item label="请假项目：" required prop="projectId">
            <i-select
              v-model="formData.projectId"
              size="large"
              @on-change="handleSelectChange"
            >
              <i-option
                v-for="(item, index) of projectCourseOption"
                :key="index"
                :value="item.projectId"
                >{{ item.projectName }}</i-option
              >
            </i-select>
          </i-form-item>
          <i-form-item label="请假课程：" required prop="projectClassapplyId">
            <i-select
              v-model="formData.projectClassapplyId"
              size="large"
              multiple
            >
              <i-option
                v-for="(item, index) of projectClassOptions"
                :key="index"
                :value="item.projectClassapplyId"
                ref="projectClass"
                :tag="
                  `${item.className} (${$tagTime(
                    item.trainingTimeStart,
                    'yyyy-MM-dd HH:mm ~'
                  )}${$tagTime(item.trainingTimeEnd, ' HH:mm')})`
                "
                >{{ item.className }} ({{
                  $tagTime(item.trainingTimeStart, "yyyy-MM-dd HH:mm ~")
                }}
                {{ $tagTime(item.trainingTimeEnd, " HH:mm") }})</i-option
              >
            </i-select>
          </i-form-item>
        </i-form>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">提交</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Button,
  Table,
  Tooltip,
  Form,
  FormItem,
  RadioGroup,
  Radio,
  Select,
  Option,
  Input,
  DatePicker
} from "view-design";
import myModal from "@/components/common/myModal";
import myPagination from "@/components/common/myPagination";
export default {
  name: "myLeave",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-input": Input,
    "i-date-picker": DatePicker,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-radio-group": RadioGroup,
    "i-radio": Radio,
    "i-select": Select,
    "i-option": Option,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "请假类型",
          align: "center",
          tooltip: true,
          width: 100,
          key: "leaveType",
          render: (h, params) => {
            return h("span", params.row.leaveType === 0 ? "事假" : "病假");
          }
        },
        {
          title: "请假事由",
          align: "center",
          key: "leaveReason",
          tooltip: true
        },
        {
          title: "请假课程",
          align: "center",
          slot: "classInfos",
          tooltip: true
        },
        { title: "申请时间", align: "center", slot: "applyTime", width: 180 },
        { title: "审核状态", align: "center", width: 120, slot: "status" }
      ],
      limitQuery: {
        pageSize: 15,
        pageNum: 1,
        query: "",
        startTime: "",
        endTime: ""
      },
      formData: {
        // 项目课程id
        projectClassapplyId: [],
        // 项目id
        projectId: "",
        // 请假事由
        leaveReason: "",
        // 请假类型
        leaveType: ""
      },
      // 课程时间的待选列表
      projectCourseOption: [],
      // 表单校验规则
      ruleValidate: {
        leaveType: [{ required: true, message: "请选择请假类型" }],
        leaveReason: [
          { required: true, message: "请填写100字以内的请假事由", max: 100 }
        ],
        projectId: [
          {
            required: true,
            message: "请选择请假项目"
          }
        ],
        projectClassapplyId: [
          {
            required: true,
            type: "array",
            message: "请选择请假课程"
          }
        ]
      },
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-leave"
      },
      msgCount: 0,
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求项目课程时间待选列表
    this.requireProjectCourseOption();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      tmpObj.startTime = new Date(tmpObj.startTime + " " + "00:00:00") || "";
      tmpObj.endTime = new Date(tmpObj.endTime + " " + "23:59:59") || "";
      this.$axios
        .post(`/api/myLeave/list`, tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 请求项目课程时间的待选列表
    requireProjectCourseOption() {
      this.$axios
        .get(`/api/myLeave/getLeaveProject`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("项目课程时间获取失败");
            return false;
          }
          this.projectCourseOption = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    //
    // 点击在线评价
    clickAdd() {
      this.modalOption.title = `请假申请`;
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
    },
    // 处理添加
    handleAdd() {
      // 取出选中的课程列表
      let tmpArr = this.projectClassOptions.filter(item => {
        return this.formData.projectClassapplyId.includes(
          item.projectClassapplyId
        );
      });
      tmpArr = tmpArr.map(el => {
        return {
          projectClassId: el.projectClassapplyId,
          startTime: new Date(el.trainingTimeStart),
          endTime: new Date(el.trainingTimeEnd)
        };
      });
      // 整理要提交的数据
      let tmpObj = {
        projectId: this.formData.projectId,
        leaveClassListDTOS: tmpArr,
        leaveReason: this.formData.leaveReason,
        leaveType: this.formData.leaveType
      };
      this.$axios
        .post(`/api/myLeave/applyLeave`, tmpObj)
        .then(res => {
          this.$Message.success("提交成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 列表查询时的时间段改变的方法
    handleDatePickChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = arr[0];
      this.limitQuery.endTime = arr[1];
      this.initLoadTable();
    },
    // 点击对话框的确认按钮
    clickOk() {
      let sign = this.testForm();
      if (!sign) {
        return;
      }
      this.handleAdd();
    },
    // 点击对话框的取消按钮
    clickCancel() {
      this.modalOption.modalVisiabal = false;
    },
    handleSelectChange() {
      this.formData.projectClassapplyId = [];
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearForm();
      }
    },
    clearForm() {
      this.formData = {
        // 项目课程id
        projectClassapplyId: [],
        // 项目id
        projectId: "",
        // 请假事由
        leaveReason: "",
        // 请假类型
        leaveType: ""
      };
    },
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    }
  },
  filters: {
    statusValueFilter(val) {
      switch (val) {
        case 0:
          return "待审核";
        case 1:
          return "不通过";
        case 2:
          return "已通过";
        default:
          return "";
      }
    },
    statusClassFilter(val) {
      switch (val) {
        case 0:
          return "orange";
        case 1:
          return "red";
        case 2:
          return "green";
        default:
          return "";
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 62;
    },
    projectClassOptions() {
      let tmpObj = this.projectCourseOption.find(el => {
        return el.projectId === this.formData.projectId;
      });
      return tmpObj ? tmpObj.projectClassLeaveVOS : [];
    }
  }
};
</script>
<style lang="scss" scoped>
.myLeave {
  position: relative;
  height: calc(100vh - 162px);
  background: #fff;
  padding: 20px;
  .my-header {
    height: 36px;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    & > :not(:last-child) {
      margin-right: $top;
    }
  }
  .red {
    color: $error;
    text-decoration: underline;
  }
  .green {
    color: $theme;
  }
  .orange {
    color: $orange;
  }
  .to-see {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
}
</style>
<style lang="scss">
.modal-leave {
  .ivu-radio {
    margin-right: 5px;
  }
}
</style>
