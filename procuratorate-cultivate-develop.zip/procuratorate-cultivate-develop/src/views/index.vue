<template>
  <div class="index">
    <my-header></my-header>
    <my-header-nav></my-header-nav>
    <div class="main-area">
      <div class="content-area">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
import myHeader from "@/components/common/myHeader.vue";
import myHeaderNav from "@/components/common/myHeaderNav.vue";
export default {
  name: "index",
  data() {
    return {};
  },
  mounted() {
    // 页面挂载后获取表格高度
    this.$store.commit("skb/updateTableHeight");
    // 窗口大小改变后获取表格高度
    window.onresize = () => {
      return (() => {
        this.$store.commit("skb/updateTableHeight");
      })();
    };
  },
  components: {
    "my-header": myHeader,
    "my-header-nav": myHeaderNav
  }
};
</script>
<style lang="scss" scoped>
.index {
  .main-area {
    position: relative;
    padding: 20px 10% 40px;
    width: 100%;
    height: calc(100vh - 130px);
    overflow: auto;
    @extend .header-bg;
    .content-area {
      height: 100%;
    }
  }
}
</style>
