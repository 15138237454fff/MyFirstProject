<template>
  <div style="position:relative;padding-left:20px;padding-right:20px;">
    <section style="margin-top:20px">
      <el-tabs type="card" v-model="tabNum" @tab-click="handleSelect">
        <el-tab-pane label="投票界面" name="1">
          <div>
            <el-row style="width:100%;margin:0 auto;margin-bottom:7px">
              <el-col :span="5">
                <el-row style="float:left">
                  <el-input clearable v-model="search" placeholder="请输入搜索内容" style="width:65%" prefix-icon="el-icon-search" @clear="handleClear" @keyup.delete.native="handleClear" @keyup.enter.native="handleFind"></el-input>
                  <el-button @click="handleFind" style="margin-left:5px">搜索</el-button>
                </el-row>
              </el-col>
              <el-col :span="7">
              </el-col>
              <el-col :span="19">
                <el-row style="float:right">
                  <el-button type="primary" @click="handleDetail">投票表</el-button>
                  <el-button type="primary" @click="handleSave">保存</el-button>
                  <el-button type="success" @click="handleSubmit" :loading="submitLoading">
                    {{submit}}</el-button>
                </el-row>
              </el-col>
            </el-row>
            <!-- 汇总表 -->
            <el-table :data="listFilter == undefined ? [] : listFilter.slice((currentPage-1)*pageSize,currentPage*pageSize)" border style="width: 100%;height:auto" @selection-change="handleSelectionChange" v-loading="loading" element-loading-text="拼命加载中" :header-cell-style="tableHeaderColor" :height='tableHeight'>
              <el-table-column v-for="(item, index) in tableInfo.tableColInfo" :key="index" :prop="item.attributeName" :label="item.attributeNameCn" :min-width="getColWidth(item.ratio)" :fixed="index==0" align="center">
                <template slot-scope="scope">
                  <el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
                    <div slot="content" v-html="getColHtmlTip(scope.row,item.attributeName)"></div>
                    <div v-html="getColHtml(scope.row,item.attributeName)" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
                  </el-tooltip>
                </template>
              </el-table-column>
              <el-table-column prop="voteStatus" label="排名" width="200" align="center" fixed="right" label-class-name="qbty">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.voteStatus" filterable placeholder="请选择">
                    <el-option v-for="item in selectList" :key="item" :label="item" :value="item">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
            </el-table>
            <div class="block" style="margin-top:15px;text-align:center">
              <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[100,200]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="this.listFilter == undefined ? null : listFilter.length"></el-pagination>
            </div>
            <el-dialog title="投票表" :visible.sync="dialogTableVisible" width="60%">
              <el-row type="flex" justify="end" style="margin:0 auto;margin-bottom:7px;">
                <el-col :span="24">
                </el-col>
              </el-row>
              <el-table :data="this.tpbList == undefined ? [] : tpbList.slice((currentPage1-1)*pageSize1,currentPage1*pageSize1)" border ref="filterTable" :height='tableHeight1'>
                <el-table-column v-for="(item, index) in tableInfo.voteTableColInfo" :key="index" :prop="item.attributeName" :label="item.attributeNameCn" :min-width="getColWidth(item.ratio)">
                </el-table-column>
                <el-table-column prop="voteStatus" label="排名" width="260" align="center">
                </el-table-column>
              </el-table>
              <!-- 投票表分页 -->
              <div class="block" style="margin-top:15px;text-align:center">
                <el-pagination @size-change="handleSizeChange1" @current-change="handleCurrentChange1" :current-page="currentPage1" :page-sizes="[100,200]" :page-size="pageSize1" layout="total, sizes, prev, pager, next, jumper" :total="this.tpbList == undefined ? null : this.tpbList.length"></el-pagination>
              </div>
            </el-dialog>
          </div>
        </el-tab-pane>
        <el-tab-pane label="计票表" name="2">
          <count-rank ref="mychild"></count-rank>
        </el-tab-pane>
      </el-tabs>
    </section>
  </div>
</template>

<script>
import bus from '../../common/bus';
import count from '../../common/count'
import countRank from '../countVotes/countRank'
import { getTableH } from '../../untils/table'
export default {
  inject: ['reload'],
  components: {
    count,
    countRank
  },
  data() {
    return {
      tableHeight: null, //表格高度
      tableHeight1: null, //表格高度
      arrCurr: [], //当前页多少条
      submit: "提交",
      submitLoading: false, //提交显示加载中动画
      loading: false, //页面加载中
      currentPage: 1, // 当前页
      currentPage1: 1, // 当前页
      pageSize: 100, //分页中每页显示条数
      pageSize1: 100, //分页中每页显示条数
      search: "", //查询搜索字段
      dialogTableVisible: false, //投票表展示与否
      tabNum: '1', //切换选项卡
      list: [],
      listFilter: [], //过滤列表
      tpbList: [],
      projectInfo: {},
      //表信息
      tableInfo: {},
      //屏幕宽度
      screenWidth: null,
      //下拉数据
      selectList: []
    };
  },
  watch: {

  },
  mounted() {
    this.initInfo();
    bus.$on('switchProject', () => {
      this.initInfo();
    })
    this.screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  },
  beforeDestroy() {
    bus.$off('switchProject')
  },
  updated() {
    this.getCurr()
    this.tableHeight = getTableH(this.arrCurr, this.tableHeight)
  },
  methods: {
    getColHtmlTip(row, key) {
      return row[key].toString().replace(/\n/g, '<br><br>');
    },
    getColHtml(row, key) {
      return row[key];
    },
    //初始化信息
    initInfo() {
      //获取项目信息
      this.projectInfo = this.$store.state.projectInfo
      //读取投票表表信息
      this.loadTableColumn()
    },
    //获取列宽度
    getColWidth(ratio) {
      var width = this.screenWidth * ratio * 0.01;
      if (width < 100) {
        return "60px";
      } else if (width > 400) {
        return "400px";
      } else {
        return width + "px";
      }
    },
    // 查询
    handleFind() {
      if (this.search.length == 0) {
        this.$message({
          message: '请输入搜索内容',
          type: 'error',
          customClass: 'zZindex'
        })
        return;
      }
      this.currentPage = 1
      let arr = []
      this.list.filter(item => {
        let value = item[this.tableInfo.searchField].toString();
        if (item.status != '1' && value.indexOf(this.search) > -1) {
          arr.push(item)
        }
      })
      this.listFilter = arr
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleSizeChange1(val) {
      this.pageSize1 = val
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage
    },
    handleCurrentChange1(currentPage) {
      this.currentPage1 = currentPage
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // 替换table中thead的颜色
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    },
    //清空搜索框
    handleClear() {
      this.listFilter = []
      this.list.filter(item => {
        if (item.status != '1') {
          this.listFilter.push(item)
        }
      })
    },
    getCurr() {
      this.arrCurr = this.listFilter.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize)
    },
    //投票表表信息
    loadTableColumn() {
      this.$http.get('/api/vtc/voteInfo/' + this.projectInfo.id)
        .then(res => {
          this.tableInfo = res.data.data;
          this.loadTable()
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    //加载列表
    loadTable() {
      this.loading = true
      this.$http
        .get('/api/vtc/vote/' + this.projectInfo.id)
        .then(res => {
          this.list = res.data.data.list;
          this.getList();
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    getList() {
      this.listFilter = []
      this.list.filter(item => {
        if (item.status != '1') {
          this.listFilter.push(item)
        }
      })
      //初始化下拉列表
      if (this.listFilter.length > 0) {
        this.selectList = Array(this.listFilter.length).fill().map((e, i) => i + 1);
      }
      this.getCurr()
      this.tableHeight = getTableH(this.arrCurr, this.tableHeight)
      this.loading = false
    },
    // 切换投票界面与计票表
    handleSelect(tab, event) {
      this.tabNum = tab.name
    },
    // 投票表
    handleDetail() {
      this.dialogTableVisible = true
      this.tpbList = this.list

      this.$nextTick(() => {
        this.tableHeight1 = `${document.documentElement.clientHeight - 255}px`
      })
    },
    // 保存
    handleSave() {
      // console.log(this.list)
    },
    // 提交
    handleSubmit() {
      if (this.listFilter == '') {
        this.errorNotice('提交失败', '当前无可提交数据！');
        return false
      }
      var submitList = [];
      var selected = new Set();
      this.list.some(item => {
        if (item.status != '1') {
          if (item.voteStatus == null) {
            this.errorNotice('提交失败', '还有未操作的数据，请确保所有数据操作完毕再提交！')
            throw new Error('提交失败')
          }
          submitList.push({
            id: item.id,
            voteStatus: item.voteStatus
          })
          selected.add(item.voteStatus)
        }
      })
      if (selected.size < this.selectList.length) {
        this.errorNotice('提交失败', '排名重复，请确保无重复排名数据再提交！')
        throw new Error('提交失败')
      }
      this.$confirm('提交操作，是否确认提交？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.submitSucc(submitList)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消提交'
        })
      })
    },
    //提交成功函数
    submitSucc(list) {
      this.submitLoading = true
      this.submit = "加载中"
      this.$http.post('/api/vtc/saveVoteData/' + this.projectInfo.id, this.listFilter).then(
        res => {
          if (res.data.code == 200) {
            this.$message({
              message: "提交成功",
              type: "success",
              customClass: 'zZindex'
            })
            this.submitLoading = false
            this.submit = "提交"
            this.loadTable()
          } else {
            this.$message({
              message: res.data.message,
              type: "error",
              customClass: 'zZindex'
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
  }
};

</script>

<style lang="scss" scoped>
.tabFlex {
  width: 100%;
  padding-left: 0;
  padding-right: 0;
  display: flex;
}
</style>

<style lang="scss">
@import "../../style/ele"; //必须加分号，不然会报错
.zZindex {
  z-index: 99999 !important;
}
//   .el-table td>.cell {
//   white-space: pre-line;
// }
</style>
