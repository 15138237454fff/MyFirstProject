<template>
  <div class="container">
    <div style="width:100%;height:100%;position:absolute">
      <img src="../../assets/image/school-1.jpg" alt="" srcset="" style="padding:0;margin:0;width:100%;height:100%">
    </div>
    <el-dialog title="请选择项目名称" :visible.sync="dialogVisible" width="30%"  :close-on-click-modal='false' :showClose='false'>
      <el-select v-model="value" placeholder="请选择" @change="handleChange" class="selInp">
        <el-option v-for="item in projectList" :key="item.id" :label="item.name" :value="item.id">
        </el-option>
      </el-select>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleConfirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import bus from '../../common/bus'
export default {
  data() {
    return {
      dialogVisible: true,
      projectList: [],
      projectInfo: {},
      value: '',
    }
  },
  created() {
    //获取项目列表
    this.projectList = this.$store.state.projectList
  },
  methods: {
    handleChange(val) {
      let obj = {}
      // 遍历数组
      obj = this.projectList.find(item => {
        // 筛选出匹配的数据
        return item.id === val
      })
      this.projectInfo = obj;
    },
    handleConfirm() {
      if (!this.isEmpty(this.projectInfo.id)) {
        this.$message({
          message: '请选择一条项目！',
          type: 'error',
          customClass: 'zZindex'
        })
      } else {
        if (this.projectList.sign == 1) {
          this.checkSign();
        } else {
          this.handleSwitch();
        }
      }
    },
    checkSign() {
      this.$http.get('/api/sign/recall/' + this.projectInfo.id)
        .then(res => {
          if (res.data.code == 200) {
            this.handleSwitch()
          } else if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: 'error',
              customClass: 'zZindex'
            })
          }
        })
    },
    handleSwitch() {
      bus.$emit('projectName', this.projectInfo.name)
      this.$store.commit('SET_PROJECT_INFO', this.projectInfo)
      this.dialogVisible = false
      switch (this.projectInfo.voteRules) {
        case 0:
          this.$router.push({
            name: 'vote'
          })
          break;
        case 1:
          this.$router.push({
            name: 'voteMark'
          })
          break;
        case 2:
          this.$router.push({
            name: 'voteRank'
          })
          break;
        default:
          break;
      }
    }
  }
}

</script>

<style scoped>
.selInp >>> .el-input {
  width: 130%;
}
/* .container {
    background: url('../../assets/image/school-1.jpg') !important;
    height: 100%;
    position: absolute;
    width: 100%;
    top:80px;
    bottom: 0;
  } */
.container >>> .el-main {
  padding-top: 20px !important;
}
</style>
<style>
.zZindex {
  z-index: 99999 !important;
}
.el-main {
  padding: 0;
  padding-top: 20px !important;
}
</style>
