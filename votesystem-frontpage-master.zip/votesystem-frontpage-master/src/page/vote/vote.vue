<template>
  <div style="position:relative;padding-left:20px;padding-right:20px;">
    <section style="margin-top:20px">
      <el-tabs type="card" v-model="tabNum" @tab-click="handleSelect">
        <el-tab-pane label="投票界面" name="1">
          <div>
            <el-row style="width:100%;margin:0 auto;margin-bottom:7px">
              <el-col :span="5">
                <el-row style="float:left">
                  <el-input clearable v-model="search" placeholder="请输入搜索内容" style="width:65%" prefix-icon="el-icon-search" @clear="handleClear" @keyup.delete.native="handleClear" @keyup.enter.native="handleFind"></el-input>
                  <el-button @click="handleFind" style="margin-left:5px">搜索</el-button>
                </el-row>
              </el-col>
              <el-col :span="7">
                <span style="line-height:40px;color:#f56c6c" v-if="showMax">友情提醒：当前投票环节最大同意票数为
                  {{maxNum}}</span>
              </el-col>
              <el-col :span="showMax == true? 12: 19">
                <el-row style="float:right">
                  <el-button type="primary" @click="handleDetail">投票表</el-button>
                  <el-button type="primary" @click="handleSave">保存</el-button>
                  <el-button type="success" @click="handleSubmit" :loading="submitLoading">
                    {{submit}}</el-button>
                </el-row>
              </el-col>
            </el-row>
            <!-- 汇总表 -->
            <el-table :data="listFilter == undefined ? [] : listFilter.slice((currentPage-1)*pageSize,currentPage*pageSize)" border style="width: 100%;height:auto" @selection-change="handleSelectionChange" v-loading="loading" element-loading-text="拼命加载中" :header-cell-style="tableHeaderColor" :height='tableHeight'>
              <el-table-column v-for="(item, index) in tableInfo.tableColInfo" :key="index" :prop="item.attributeName" :label="item.attributeNameCn" :min-width="getColWidth(item.ratio)" :fixed="index==0" align="center">
                <template slot-scope="scope">
                  <el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
                    <div slot="content" v-html="getColHtmlTip(scope.row,item.attributeName)"></div>
                    <div v-html="getColHtml(scope.row,item.attributeName)" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
                  </el-tooltip>
                </template>
              </el-table-column>
              <el-table-column prop="voteStatus" label="操作" width="260" align="center" fixed="right" :render-header="renderHeader" label-class-name="qbty">
                <template slot-scope="scope">
                  <el-radio-group v-model="scope.row.voteStatus" @change="handleChange(scope.row)" :fill="scope.row.voteStatus==1? '#67C23A': scope.row.voteStatus==0 ? '#F56C6C' : '#E6A23C'" text-color="ffffff" size="small">
                    <el-radio-button :label="1">同意</el-radio-button>
                    <el-radio-button :label="0">不同意</el-radio-button>
                    <el-radio-button :label="2">弃权</el-radio-button>
                  </el-radio-group>
                </template>
              </el-table-column>
            </el-table>
            <div class="block" style="margin-top:15px;text-align:center">
              <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[100,200]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="this.listFilter == undefined ? null : listFilter.length"></el-pagination>
            </div>
            <el-dialog title="投票表" :visible.sync="dialogTableVisible" width="60%">
              <el-row type="flex" justify="end" style="margin:0 auto;margin-bottom:7px;">
                <el-col :span="24">
                  <el-row style="float:right">
                    <el-button type="text">
                      同意人数：<span>{{num1}}人</span>
                    </el-button>
                    <el-button type="text">
                      不同意人数：<span>{{num2}}人</span>
                    </el-button>
                    <el-button type="text">
                      弃权人数：<span>{{num3}}人</span>
                    </el-button>
                  </el-row>
                </el-col>
              </el-row>
              <el-table :data="this.tpbList == undefined ? [] : tpbList.slice((currentPage1-1)*pageSize1,currentPage1*pageSize1)" border @filter-change="handleFilterChange" ref="filterTable" :height='tableHeight1'>
                <el-table-column v-for="(item, index) in tableInfo.voteTableColInfo" :key="index" :prop="item.attributeName" :label="item.attributeNameCn" :min-width="getColWidth(item.ratio)">
                </el-table-column>
                <el-table-column prop="voteStatus" label="结果" align="center" column-key="voteStatus" :filters="resultTags" :filter-method="filterTag" :filter-multiple="false">
                  <template slot-scope="scope">
                    <el-tag :type="scope.row.voteStatus == '1'? 'success' :scope.row.voteStatus == '0'? 'danger': 'warning'">
                      {{ scope.row.voteStatus == '1'? '同意' : scope.row.voteStatus == '0'? '不同意': scope.row.voteStatus == '2' ? '弃权' : '待定' }}
                    </el-tag>
                  </template>
                </el-table-column>
              </el-table>
              <!-- 投票表分页 -->
              <div class="block" style="margin-top:15px;text-align:center">
                <el-pagination @size-change="handleSizeChange1" @current-change="handleCurrentChange1" :current-page="currentPage1" :page-sizes="[100,200]" :page-size="pageSize1" layout="total, sizes, prev, pager, next, jumper" :total="this.tpbList == undefined ? null : this.tpbList.length"></el-pagination>
              </div>
            </el-dialog>
          </div>
        </el-tab-pane>
        <el-tab-pane label="计票表" name="2">
          <count-a ref="mychild"></count-a>
        </el-tab-pane>
      </el-tabs>
      <!-- <count v-show='tabNum == 1 && sign==1'></count> -->
    </section>
  </div>
</template>

<script>
import bus from '../../common/bus';
import count from '../../common/count'
import countA from '../countVotes/countA'
import { getTableH } from '../../untils/table'
export default {
  inject: ['reload'],
  components: {
    count,
    countA
  },
  data() {
    return {
      num1: null,
      num2: null,
      num3: null,
      tableHeight: null, //表格高度
      tableHeight1: null, //表格高度
      arrCurr: [], //当前页多少条
      arrCurr1: [], //当前页多少条
      maxNum: null, //投票环节通过最大票数
      showMax: false, //友情提醒显示与隐藏
      submit: "提交",
      submitLoading: false, //提交显示加载中动画
      loading: true, //页面加载中
      currentPage: 1, // 当前页
      currentPage1: 1, // 当前页
      pageSize: 100, //分页中每页显示条数
      pageSize1: 100, //分页中每页显示条数
      search: "", //查询搜索字段
      dialogTableVisible: false, //投票表展示与否
      showPass: false, //同意弹窗
      shownoPass: false, //不同意弹窗
      showAbstain: false, //弃权弹窗
      tabNum: '1', //切换选项卡
      sublwtm: '', //论文题目省略
      resultTags: [{
        text: '同意',
        value: '1'
      },
      {
        text: '不同意',
        value: '0'
      },
      {
        text: '弃权',
        value: '2'
      }
      ], //过滤投票表结果列
      tableData: [
      ], //模拟数据
      temp: {},
      list: [],
      listFilter: [], //过滤列表
      listTag: [], //投票表过滤
      tagFilters: null, //临时保存过滤数据
      aaa: null,
      tpbList: [],
      projectInfo: {},
      //表信息
      tableInfo: {},
    };
  },
  watch: {
    tabNum: function (newVal) {
      if (newVal == 2) {
        this.$refs.mychild.parentLoadInfo()
      } else if (newVal == 1) {
        this.$refs.mychild.clearCountTimer()
      }
    },
  },
  mounted() {
    this.initInfo();
    bus.$on('switchProject', () => {
      this.initInfo();
    })
  },
  beforeDestroy() {
    bus.$off('switchProject')
  },
  updated() {
    this.getCurr()
    this.tableHeight = getTableH(this.arrCurr, this.tableHeight)
  },
  methods: {
    getColHtmlTip(row, key) {
      return row[key].toString().replace(/\n/g, '<br><br>');
    },
    getColHtml(row, key) {
      return row[key];
    },
    //初始化信息
    initInfo() {
      //获取项目信息
      this.projectInfo = this.$store.state.projectInfo
      //是否限制最大提交数
      this.handleMaxnum()
      //读取投票表信息
      this.loadTableColumn()
    },
    //获取列宽度
    getColWidth(ratio) {
      var width = this.screenWidth * ratio * 0.01;
      if (width < 100) {
        return "60px";
      } else if (width > 400) {
        return "400px";
      } else {
        return width + "px";
      }
    },
    //全部同意和重置
    renderHeader(h, { column }) {
      return (
        <div style="width:100%;height:50px;line-height:50px">
          <div onClick={this.handlePass} style="height:50px;line-height:50px;background:#409EFF;color:#fff;border:none;cursor:pointer" class="primary">全部同意</div>
          <div onClick={this.handleReset} style="height:50px;line-height:50px;background:#fff;color:#409EFF;border:1px solid #409EFF;cursor:pointer">重置</div>
        </div>
      )
    },
    // 查询
    handleFind() {
      if (this.search.length == 0) {
        this.$message({
          message: '请输入搜索内容',
          type: 'error',
          customClass: 'zZindex'
        })
        return;
      }
      this.currentPage = 1
      let arr = []
      this.list.filter(item => {
        let value = item[this.tableInfo.searchField].toString();
        if (item.status != '1' && value.indexOf(this.search) > -1) {
          arr.push(item)
        }
      })
      this.listFilter = arr
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val
    },
    handleSizeChange1(val) {
      this.pageSize1 = val
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage
    },
    handleCurrentChange1(currentPage) {
      this.currentPage1 = currentPage
    },
    //列表序号
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1;
    },
    //投票表序号
    voteIndexMethod(index) {
      return (this.currentPage1 - 1) * this.pageSize1 + index + 1;
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // 替换table中thead的颜色
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    },
    //清空搜索框
    handleClear() {
      this.listFilter = []
      this.list.filter(item => {
        if (item.status != '1') {
          this.listFilter.push(item)
        }
      })
    },
    //友情提醒
    handleMaxnum() {
      this.$http.get('/api/project/limit/' + this.projectInfo.id)
        .then(res => {
          if (res.data.data.limit == true) {
            this.maxNum = res.data.data.maxPass
            this.showMax = true
          } else {
            this.showMax = false
          }
        })
    },
    //投票表过滤某些数据是否显示
    filterTag(value, row) {
      return row.voteStatus == value
    },
    // 当表格的筛选条件发生变化的时候会触发该事件，参数的值是一个对象，对象的 key 是 column 的 columnKey，对应的 value 为用户选择的筛选条件的数组
    handleFilterChange(filters) {
      this.currentPage1 = 1
      this.tagFilters = filters
      this.aaa = filters.voteStatus[0]
      this.listTag = filters.voteStatus == '0' ? this.passList : filters.voteStatus == '1' ? this.noPassList : filters.voteStatus == '2' ? this.abstainList : ''
      this.tpbList = this.listTag
      if (filters.voteStatus.length == 0) {
        this.tpbList = this.list
      }
    },
    getCurr() {
      this.arrCurr = this.listFilter.slice((this.currentPage - 1) * this.pageSize, this.currentPage * this.pageSize)
    },
    getCurr1() {
      this.arrCurr1 = this.tbpList.slice((this.currentPage1 - 1) * this.pageSize1, this.currentPage1 * this.pageSize1)
    },
    //投票表表信息
    loadTableColumn() {
      this.$http.get('/api/vtc/voteInfo/' + this.projectInfo.id)
        .then(res => {
          this.tableInfo = res.data.data;
          this.loadTable()
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    //加载列表
    loadTable() {
      this.loading = true
      this.$http
        .get('/api/vtc/vote/' + this.projectInfo.id)
        .then(res => {
          this.list = res.data.data.list;
          this.getList()
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    getList() {
      this.listFilter = []
      this.list.filter(item => {
        if (item.status != '1') {
          this.listFilter.push(item)
        }
      })
      this.getCurr()
      this.tableHeight = getTableH(this.arrCurr, this.tableHeight)
      this.loading = false
    },
    // 切换投票界面与计票表
    handleSelect(tab, event) {
      this.tabNum = tab.name
    },
    // 改变状态
    handleChange(row) {
      this.temp = Object.assign({}, row);
    },
    // 重置
    handleReset() {
      this.listFilter.forEach(item => {
        item.voteStatus = null;
      });
    },
    // 一键通过
    handlePass() {
      this.listFilter.forEach(item => {
        item.voteStatus = 1;
      });
    },
    //同意人数
    pass() {
      let obj = []
      this.list.forEach(item => {
        if (item.voteStatus == 1) {
          obj.push(item)
        }
      })
      this.num1 = obj.length
      this.showPass = true
      this.passList = obj
    },
    //不同意人数
    noPass() {
      let obj = []
      this.list.forEach(item => {
        if (item.voteStatus == 0) {
          obj.push(item)
        }
      })
      this.num2 = obj.length
      this.shownoPass = true
      this.noPassList = obj
    },
    //弃权人数
    abstain() {
      let obj = []
      this.list.forEach(item => {
        if (item.voteStatus == 2) {
          obj.push(item)
        }
      })
      this.num3 = obj.length
      this.showAbstain = true
      this.abstainList = obj
    },
    // 投票表
    handleDetail() {
      this.dialogTableVisible = true
      this.tpbList = this.list

      this.$nextTick(() => {
        this.tableHeight1 = `${document.documentElement.clientHeight - 255}px`
      })
      if (this.tagFilters != null) {
        this.clearFilter()
      }
      // this.listTag = this.list
      this.pass()
      this.noPass()
      this.abstain()
    },
    clearFilter() {
      this.$refs.filterTable.clearFilter()
      this.tpbList = this.list
    },
    // 一键不同意
    handleNopass() {
      this.list.forEach(item => {
        item.voteStatus = 1;
      });
    },
    // 弃权
    handleGiveup() {
      this.list.forEach(item => {
        item.voteStatus = 2;
      });
    },
    // 保存
    handleSave() {
      // console.log(this.list)
    },
    // 提交
    handleSubmit() {
      if (this.listFilter == '') {
        this.$notify({
          title: '提交失败',
          message: '当前无可提交数据！',
          type: 'error',
          offset: 70
        });
        return false
      }
      if (this.showMax) {
        this.handleCompare()
      }
      var submitList = [];
      this.list.some(item => {
        if (item.status != '1') {
          if (item.voteStatus == null) {
            this.$notify({
              title: '提交失败',
              message: '还有未操作的数据，请确保所有数据操作完毕再提交！',
              type: 'error',
              offset: 70
            });
            throw new Error('提交失败')
          }
          submitList.push({
            id: item.id,
            voteStatus: item.voteStatus
          })
        }
      })
      this.$confirm('提交操作，是否确认提交？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.submitSucc(submitList)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消提交'
        })
      })
    },
    //提交成功函数
    submitSucc(list) {
      this.submitLoading = true
      this.submit = "加载中"
      this.$http.post('/api/vtc/saveVoteData/' + this.projectInfo.id, this.listFilter).then(
        res => {
          if (res.data.code == 200) {
            this.$message({
              message: "提交成功",
              type: "success",
              customClass: 'zZindex'
            })
            this.submitLoading = false
            this.submit = "提交"
            this.loadTable()
          } else {
            this.$message({
              message: res.data.message,
              type: "error",
              customClass: 'zZindex'
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    //比较大小，同意人数与最大同意人数比较
    handleCompare() {
      let obj = {}
      obj = this.listFilter.filter(item => {
        return item.voteStatus == 1
      })
      if (obj.length > this.maxNum) {
        this.$notify({
          title: '提交失败',
          message: '同意人数不能超过当前投票环节最大同意票数！',
          type: 'error',
          offset: 70
        });
        throw new Error('提交失败')
      }
    }
  }
};

</script>

<style lang="scss" scoped>
.tabFlex {
  width: 100%;
  padding-left: 0;
  padding-right: 0;
  display: flex;
}
</style>

<style lang="scss">
@import "../../style/ele"; //必须加分号，不然会报错
.zZindex {
  z-index: 99999 !important;
}
//   .el-table td>.cell {
//   white-space: pre-line;
// }
</style>