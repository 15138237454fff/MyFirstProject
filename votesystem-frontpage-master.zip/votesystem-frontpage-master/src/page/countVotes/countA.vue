<template>
  <div>
    <el-row style="width:100%;margin:0 auto;margin-bottom:7px">
      <el-col :span="10">
        <el-row style="float:left">
          <el-input clearable v-model="pageHelper.query" placeholder="请输入搜索内容" style="width:65%" prefix-icon="el-icon-search" @keyup.enter.native="loadTable" @clear="handleClear"></el-input>
          <el-button @click="loadTable" style="margin-left:5px">搜索</el-button>
        </el-row>
      </el-col>
      <el-col :span="14">
        <el-row style="float:right">
          <el-button type="text" @click="handleCast">
            已投人数：<span>{{castInfo.cast}}人</span>
          </el-button>
          <el-button type="text" @click="handleNocast">
            未投人数：<span>{{castInfo.noCast}}人</span>
          </el-button>
        </el-row>
      </el-col>
      <el-dialog title="已投人数" :visible.sync="castShow">
        <el-table :data="castInfo.castList">
          <el-table-column property="name" label="姓名"></el-table-column>
          <el-table-column property="userName" label="用户名"></el-table-column>
          <!-- <el-table-column property="idCard" label="身份证号" show-overflow-tooltip></el-table-column> -->
          <el-table-column property="phoneNum" label="手机号" show-overflow-tooltip></el-table-column>
        </el-table>
      </el-dialog>
      <el-dialog title="未投人数" :visible.sync="nocastShow">
        <el-table :data="castInfo.noCastList">
          <el-table-column property="name" label="姓名"></el-table-column>
          <el-table-column property="userName" label="用户名"></el-table-column>
          <!-- <el-table-column property="idCard" label="身份证号" show-overflow-tooltip></el-table-column> -->
          <el-table-column property="phoneNum" label="手机号" show-overflow-tooltip></el-table-column>
        </el-table>
      </el-dialog>
    </el-row>
    <el-table :data="pageInfo.list" v-loading="loading" ref="countTable" border :height="tableHeight" :header-cell-style="tableHeaderColor" @filter-change="filterChange">
      <el-table-column v-for="(item, index) in countTableInfo.tableColInfo" :show-overflow-tooltip="true" :prop="item.attributeName" :label="item.attributeNameCn" :key="index" :min-width="getColWidth(item.ratio)" :fixed="index==0">
      </el-table-column>
      <el-table-column fixed="right" prop="TONGYPS" label="同意数" width="80px">
      </el-table-column>
      <el-table-column fixed="right" prop="BUTYPS" label="不同意数" width="100px">
      </el-table-column>
      <el-table-column fixed="right" prop="QIQPS" label="弃权数" width="80px">
      </el-table-column>
      <el-table-column fixed="right" prop="JIEG" label="结果" width="80px" :filters="resultTags" :filter-method="filterTag" :filter-multiple="false">
        <template slot-scope="scope">
          <span>{{getDictValue(scope.row.JIEG,'result')}}</span>
        </template>
      </el-table-column>
    </el-table>
    <div class="block" style="margin-top:15px;text-align:center">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageInfo.pageNum" :page-sizes="[10,50,100,200]" :page-size="pageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageInfo.total"></el-pagination>
    </div>
  </div>
</template>

<script>
import { getTableH } from '../../untils/jpbTable'
export default {
  data() {
    return {
      loading: false,
      castShow: false,
      nocastShow: false,
      tableHeight: null, //表格高度
      // 分页
      resultTags: [{
        text: '通过',
        value: '1'
      }, {
        text: '不通过',
        value: '0'
      }
      ], //过滤投票表结果列
      countTimer: null,
      countTableInfo: {},
      castInfo: {
        cast: 0,
        nocast: 0
      },
      pageHelper: {
        pageNum: 1,
        pageSize: 10,
        query: null,
        projectId: null
      },
      pageInfo: {}
    }
  },
  created() {

  },
  mounted() {
    //获取项目信息
    this.projectInfo = this.$store.state.projectInfo
    this.pageHelper.projectId = this.projectInfo.id;
    this.loadTableInfo()
  },
  beforeDestroy() {
    clearInterval(this.countTimer);
  },
  methods: {
    clearCountTimer() {
      if (this.clearCountTimer != null) {
        clearInterval(this.countTimer);
      }
    },
    parentLoadInfo() {
      this.loadTable();
      this.loadPeople();
    },
    getColWidth(ratio) {
      return ratio + "px";
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageHelper.pageSize = val
      this.loadTable()
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.pageHelper.pageNum = currentPage
      this.loadTable()
    },
    // 替换table中thead的颜色
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    },
    //清空搜索框
    handleClear() {
      this.loadTable()
    },
    //投票表过滤某些数据是否显示
    filterTag(value, row) {
      return true
    },
    //过滤事件
    filterChange(filters) {
      if (filters[Object.keys(filters)[0]].length == 0) {
        this.pageHelper.countResult = null;
      } else {
        this.pageHelper.countResult = filters[Object.keys(filters)[0]][0];
      }
      this.loadTable();
    },
    //加载表信息
    loadTableInfo() {
      this.$http.get('/api/vtc/countInfo/' + this.pageHelper.projectId).then(res => {
        if (res.data.code == 200) {
          this.countTableInfo = res.data.data;
        } else {
          this.$message.error(res.data.message)
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    //加载列表
    loadTable() {
      this.loading = true;
      this.$http.post('/api/vtc/count', this.pageHelper)
        .then(res => {
          if (res.data.code == 200) {
            this.pageInfo = res.data.data;
            this.loading = false;
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    //已投人数，未投人数
    loadPeople() {
      if (this.countTimer != null) {
        clearInterval(this.countTimer);
      }
      this.loadCastInfo();
      this.countTimer = setInterval(() => {
        if (this.castInfo.nocast != 0) {
          this.loadCastInfo();
        } else {
          clearInterval(this.countTimer);
        }
      }, 60000)
    },
    loadCastInfo() {
      this.$http
        .get("api/spot/castInfo/" + this.pageHelper.projectId)
        .then(res => {
          if (res.data.code == 200) {
            this.castInfo = res.data.data;
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    //已投人数列表显示
    handleCast() {
      this.castShow = true
    },
    //未投人数列表显示
    handleNocast() {
      this.nocastShow = true
    }
  }
}

</script>

<style lang="scss" scoped>
</style>
