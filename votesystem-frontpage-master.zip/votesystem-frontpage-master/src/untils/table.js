//table高度自适应
export function getTableH(listFilter,tableHeight){
  let str = JSON.stringify(listFilter)
  let arr = JSON.parse(str)
  // let arr = []
  // arr = listFilter
  let tableH = document.documentElement.clientHeight
  if(listFilter.length == 0){
    tableHeight = ''
  }
  // if(arr.length > 20){
  //   // arr.length = arr.length%20
  //   let curr = Math.ceil(arr.length/20)
  //   if(curr>2){
  //     if(arr.length%20){

  //     }
  //   }
  // }
  let tH = tableH - 255
  let tL = (arr.length) * 43 + 51
  // console.log(tH,tL,tH > tL)
  if( tH > tL ){
    tableHeight = ''
  }
  else {
    tableHeight = tH
  }
  return tableHeight
}
