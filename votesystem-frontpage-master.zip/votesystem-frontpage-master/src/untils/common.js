//友情提醒最大通过票数
export function handleMaxnum() {
  this.$http.get("/api/vtc/limit/" + this.projectId).then(res => {
    console.log(res.data.data);
    if (res.data.data.limit == true) {
      this.maxNum = res.data.data.maxPass;
      this.showMax = true;
    } else {
      this.showMax = false;
    }
  });
}

//加载列表
export function loadTable() {
  this.$http
    .get("/api/vtc/" + this.projectId + "/" + this.hzid)
    .then(res => {
      // console.log(res.data.data)
      this.listFilter = [];
      res.data.data.filter(item => {
        if (item.status != "1") {
          this.listFilter.push(item);
        }
      });
      console.log(this.listFilter);
      this.list = res.data.data;
      this.loading = false;
    })
    .catch(function(err) {
      console.log(err);
    });
}

//重置
export function handleReset() {
  this.list.forEach(item => {
    item.voteStatus = null;
  });
}

//一键通过
export function handlePass() {
  this.list.forEach(item => {
    item.voteStatus = 0;
  });

//通过人数
export function pass() {
  let obj = [];
  this.list.forEach(item => {
    if (item.voteStatus == 0) {
      obj.push(item);
    }
  });
  this.num1 = obj.length;
  this.showPass = true;
  this.passList = obj;
}

//不通过人数
export function noPass() {
  let obj = [];
  this.list.forEach(item => {
    if (item.voteStatus == 1) {
      obj.push(item);
    }
  });
  this.num2 = obj.length;
  this.shownoPass = true;
  this.noPassList = obj;
}

//弃权人数
export function abstain() {
  let obj = [];
  this.list.forEach(item => {
    if (item.voteStatus == 2) {
      obj.push(item);
    }
  });
  this.num3 = obj.length;
  this.showAbstain = true;
  this.abstainList = obj;
}

//显示投票表
export function handleDetail() {
  this.dialogTableVisible = true;
  this.pass();
  this.noPass();
  this.abstain();
}

// 提交
export function handleSubmit() {
  if (this.listFilter == '') {
    this.$notify({
      title: '提交失败',
      message: '当前无可提交数据！',
      type: 'error',
      offset: 70
    });
    return false
  }
  console.log(this.maxNum)
  if(this.maxNum != null){
    this.handleCompare()
  }
  this.list.some(item => {
    if (item.voteStatus == null) {
      this.$notify({
        title: '提交失败',
        message: '还有未操作的数据，请确保所有数据操作完毕再提交！',
        type: 'error',
        offset: 70
      });
      throw new Error('提交失败')
    }
  })
  this.$confirm('提交操作，是否确认提交？','提示',{
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(()=>{
      this.submitSucc()
    }).catch(()=>{
      this.$message({
        type: 'info',
        message: '已取消提交'
      })
    })
}

//提交成功函数
function submitSucc(){
  this.submitLoading = true
  this.submit = "加载中"
  this.$http.post('/api/vtc/' + this.projectId + '/' + this.hzid, this.listFilter).then(
    res => {
      // console.log(res)
      this.$message({
        message: "提交成功",
        type: "success",
        customClass: 'zZindex'
      })
      this.submitLoading = false
      this.submit = "提交"
      this.loadTable()
      //父组件调用子组件方法
      this.$refs.mychild.loadTable()
      this.$refs.mychild.loadPeople()
    }).catch(err => {
    console.log(err)
  })
}

//比较大小，通过人数与最大通过人数比较
export function handleCompare() {
  // console.log(this.maxNum)
  let obj = {}
  obj = this.listFilter.filter(item => {
    return item.voteStatus == 0
  })
  if (obj.length > this.maxNum) {
    this.$notify({
      title: '提交失败',
      message: '同意人数不能超过当前投票环节最大同意票数！',
      type: 'error',
      offset: 70
    });
    throw new Error('提交失败')
  }
}
