//table高度自适应
export function getTableH(listFilter,tableHeight){
  let tableH = document.documentElement.clientHeight
  if(listFilter.length == 0){
    tableHeight = ''
  }
  let tH = tableH - 255
  let tL = (listFilter.length) * 43 + 51
  // console.log(tH,tL,tH > tL)
  if( tH > tL ){
    tableHeight = ''
  }
  else {
    tableHeight = tH
  }
  // console.log(listFilter)
  return tableHeight
  // let tableH = document.documentElement.clientHeight
  // let tH = parseInt((tableH - 255 )/43)
  // let len = listFilter
  // console.log(tH,len)
  // if(tH>len){
  //   return tableHeight = len*43
  // }else {
  //   return tableHeight = tH*43
  // }
}
