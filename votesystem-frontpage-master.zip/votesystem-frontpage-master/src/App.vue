<template>
  <div id="app">
    <router-view v-if="isRouterAlive" />
  </div>
</template>

<script>
export default {
  name: "App",
  provide() {
    return {
      reload: this.reload
    };
  },
  data() {
    return {
      isRouterAlive: true
    };
  },
  methods: {
    reload() {
      this.isRouterAlive = false;
      this.$nextTick(() => {
        this.isRouterAlive = true;
      });
    }
  }
};
</script>
<style>
html,
body {
  margin: 0 auto;
  height: 100%;
  min-width: 1200px;
}
#app {
  width: 100%;
  height: 100%;
}
/* ::-webkit-scrollbar {
  width: 0px;
} */
.el-scrollbar__wrap {
  /* overflow-x: visible; */
  /* overflow-y: visible; */
  /* box-sizing: border-box; */
}
a {
  text-decoration: none;
}
.el-main{
    padding:0!important;
    padding-top:20px!important;
  }
  .el-icon-arrow-down:before {
    font-size: 20px;
    color: #237ae4;
    font-weight: bold;
  }
.el-dialog__body {
  padding: 0 20px 30px!important;
}
</style>

