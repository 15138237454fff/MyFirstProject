var dict = {
  result: [{ label: '不通过', value: 0 }, { label: '通过', value: 1 }]
};
export default {
  dict
};
