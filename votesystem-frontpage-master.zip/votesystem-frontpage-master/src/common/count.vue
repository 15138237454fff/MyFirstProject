<template>
  <div class="content" v-if="has('vote:sign')">
    <span>
      <!-- 专家到场情况： -->
      本届学位评定委员会共有成员<span class="underline1">{{count.committee}}</span> 人，
      应到会 <span class="underline1">{{count.head}}</span> 人，
      到会 <span class="underline" @click="open1">{{count.sign}}</span> 人，
      未到 <span class="underline" @click="open2">{{count.noSign}}</span> 人，
      签到率 <span class="underline1" @click="open3">{{count.rate}}</span>
      <span v-if="count.sign>=count.startPerson" style="display:block">超过全体成员三分之二（即<span class="underline1">{{count.startPerson}}</span> 人）,已符合会议开启条件</span>
      <span v-else style="color:red;display:block">未超过全体成员三分之二（即<span class="underline1">{{count.startPerson}}</span> 人）,未符合会议开启条件</span>
    </span>
    <!-- 1实到人数 -->
    <el-dialog title="实到人数" :visible.sync="attend">
      <el-table :data="signList">
        <el-table-column property="name" label="姓名"></el-table-column>
        <!-- <el-table-column property="idCard" label="身份证号" show-overflow-tooltip></el-table-column> -->
        <el-table-column property="phoneNum" label="手机号" show-overflow-tooltip></el-table-column>
        <el-table-column property="signDate" label="签到日期" show-overflow-tooltip></el-table-column>
      </el-table>
    </el-dialog>
    <!-- 2未到人数 -->
    <el-dialog title="未到人数" :visible.sync="absent">
      <el-table :data="noSignList">
        <el-table-column property="name" label="姓名"></el-table-column>
        <!-- <el-table-column property="idCard" label="身份证号" show-overflow-tooltip></el-table-column> -->
        <el-table-column property="phoneNum" label="手机号" show-overflow-tooltip></el-table-column>
        <el-table-column property="signDate" label="签到日期" show-overflow-tooltip></el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      count: {
        head: 27, //应到人数
        sign: 0, //实到人数
        noSign: 2, //未到人数
        rate: '92.6%', //签到率
        committee: 28
      },
      signList: [], //实到人数列表
      noSignList: [], //未到人数列表
      hzid: null, //汇总id
      projectId: null, //项目id
      attend: false, //出席
      absent: false, //缺席
      signin: false, //签到率
      list: [{
        id: 1,
        xm: '王鸿远',
        xh: '2111302091',
        lwtm: '高职应用电子技术专业教学改革探析',
        ssxy: '信息安全',
        xk: '软件工程',
        tg: 400,
        btg: 99,
        qq: 1,
        jg: '',
        zt: ''
      }, {
        id: 2,
        xm: '张昆鹏',
        xh: '3186581243',
        lwtm: '应用电子技术专业人才培养模式的探索与实践',
        ssxy: '软件开发',
        xk: '软件工程',
        tg: 400,
        btg: 99,
        qq: 1,
        jg: '',
        zt: ''
      }, {
        id: 3,
        xm: '凌芷梦',
        xh: '00000100',
        lwtm: '基于企业岗位需求的应用电子技术专业人才培养方案的改革',
        ssxy: '智能科技',
        xk: '软件工程',
        tg: 400,
        btg: 99,
        qq: 1,
        jg: '',
        zt: ''
      }, {
        id: 4,
        xm: '夜山',
        xh: '0054301124',
        lwtm: '校企合作共建应用电子技术生产性实训基地的探索',
        ssxy: '通信',
        xk: '软件工程',
        tg: 400,
        btg: 99,
        qq: 1,
        jg: '',
        zt: ''
      }, {
        id: 5,
        xm: '春蕾',
        xh: '2110707074',
        lwtm: '五年制高职应用电子技术专业人才的培养模式',
        ssxy: '信息管理',
        xk: '软件工程',
        tg: 400,
        btg: 99,
        qq: 1,
        jg: '',
        zt: ''
      }, {
        id: 6,
        xm: '芷天',
        xh: '00003498',
        lwtm: '新时期高职应用电子技术专业课程改革',
        ssxy: '工业技术',
        xk: '软件工程',
        tg: 400,
        btg: 99,
        qq: 1,
        jg: '',
        zt: ''
      }, {
        id: 7,
        xm: '云天',
        xh: '053800123',
        lwtm: '多能力结构的应用电子技术人才的培养',
        ssxy: '水利工程',
        xk: '软件工程',
        tg: 400,
        btg: 300,
        qq: 1,
        jg: '',
        zt: ''
      }],
      timer: null
    }
  },
  mounted() {
    this.hzid = this.$store.state.hzid
    this.projectId = this.$store.state.projectId
    // console.log(this.projectId)
    if (this.has('vote:sign')) {
      this.loadSign()
    }
  },
  methods: {
    open1() {
      this.attend = true
      // this.$emit('op1',this.attend)
    },
    open2() {
      this.absent = true
      // this.$emit('op2',this.absent)
    },
    open3() {
      this.signin = true
      // this.$emit('op3',this.signin)
    },
    querySignInfo() {
      this.$http.get('/api/vtc/sign/' + this.projectId)
        .then(res => {
          // console.log(res.data.data)
          let info = res.data.data
          this.count.head = info.head
          this.count.sign = info.sign
          this.count.committee = info.committee
          this.count.startPerson = info.startPerson
          this.count.noSign = info.noSign
          this.count.rate = info.rate
          this.signList = info.signList
          this.noSignList = info.noSignList
        })
    },
    loadSign() {
      this.querySignInfo();
      this.timer = setInterval(() => {
        if (this.count.sign < this.count.committee) {
          this.querySignInfo();
        } else {
          clearInterval(this.timer);
        }
      }, 60000)
    }
  }
}

</script>

<style scoped>
.content {
  margin: auto;
  color: #606266;
  font-size: 16px;
  position: absolute;
  top: -18px;
  left: 25%;
  text-align: center;
  /* margin-left: -402px; */
}

.underline {
  cursor: pointer;
  text-decoration: underline;
  color: #237ae4;
  font-size: 23px;
}
.underline1 {
  color: #237ae4;
  font-size: 23px;
}
</style>
