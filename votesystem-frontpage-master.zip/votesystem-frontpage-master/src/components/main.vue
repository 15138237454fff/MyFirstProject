<template>
  <el-container class="container">
    <el-header class="header-flex">
      <article class="header-left">
        <img src="../assets/image/gdlogo.png" alt="" class="left-img">
        <span class="header-font" style="font-size:20px">浙江工业大学</span>
      </article>
      <article class="header-center" v-show="showTitle1">
        <span class="header-font" style="font-size:25px;line-height:80px">{{projectName}}</span>
      </article>
      <article class="header-center" v-show="showTitle2">
        <div style="vertical-align:center">
          <span class="header-font" style="font-size:25px;line-height:80px">浙工大投票系统</span><br />
        </div>
      </article>
      <article class="header-right">
        <el-select v-model="projectId" placeholder="切换项目" @change="handleChange" class="selInp" v-show="selShow">
          <el-option v-for="item in projectList" :key="item.id" :label="item.name" :value="item.id">
          </el-option>
        </el-select>
        <el-button type="text" @click="handleMe">个人中心</el-button>
        <el-button type="text" @click="handlePass">修改密码</el-button>
        <el-button type="text" @click="loginout">退出</el-button>
      </article>
      <!-- 用户名，姓名，所属机构，手机号码 -->
      <el-dialog title="个人中心" :visible.sync="dialogMe" width="600px">
        <el-form :model="personalCenter" label-width="100px" label-position="right">
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="用户名：" prop="">
                <el-input v-model="personalCenter.userName"></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="11">
              <el-form-item label="姓名：" prop="">
                <el-input v-model="personalCenter.name"></el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="所属机构：" prop="">
                <el-input v-model="personalCenter.daptName"></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="11">
              <el-form-item label="手机号码：" prop="">
                <el-input v-model="personalCenter.phoneNum"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-dialog>
      <el-dialog title="修改密码" :visible.sync="dialogPassword" width="500px" class="changePsd">
        <el-form :model="changePassword" label-width="150px" :rules="rules" ref="changePassword">
          <el-row :gutter="30">
            <el-col :span="20">
              <el-form-item label="原密码" prop="password" v-show="oldShow">
                <el-input type="password" v-model="changePassword.password">
                  <i slot="suffix" title="显示密码" @click="changePass1('show')" style="cursor:pointer;" class="el-input__icon el-icon-hide"></i>
                </el-input>
              </el-form-item>
              <el-form-item label="原密码" prop="password" v-show="!oldShow">
                <el-input type="text" v-model="changePassword.password">
                  <i slot="suffix" title="隐藏密码" @click="changePass1('hide')" style="cursor:pointer;" class="el-input__icon el-icon-view"></i>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="30">
            <el-col :span="20">
              <el-form-item label="新密码" prop="newPassword" v-show="newShow">
                <el-input type="password" v-model="changePassword.newPassword" @focus="condition = true" @blur="condition = false">
                  <i slot="suffix" title="显示密码" @click="changePass2('show')" style="cursor:pointer;" class="el-input__icon el-icon-hide"></i>
                </el-input>
              </el-form-item>
              <el-form-item label="新密码" prop="newPassword" v-show="!newShow">
                <el-input type="text" v-model="changePassword.newPassword">
                  <i slot="suffix" title="隐藏密码" @click="changePass2('hide')" style="cursor:pointer;" class="el-input__icon el-icon-view"></i>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row :gutter="30">
            <el-col :span="20">
              <el-form-item label="再次输入新密码" prop="confirmPassword" v-show="confirmShow">
                <el-input type="password" v-model="changePassword.confirmPassword">
                  <i slot="suffix" title="显示密码" @click="changePass3('show')" style="cursor:pointer;" class="el-input__icon el-icon-hide"></i>
                </el-input>
              </el-form-item>
              <el-form-item label="再次输入新密码" prop="confirmPassword" v-show="!confirmShow">
                <el-input type="text" v-model="changePassword.confirmPassword">
                  <i slot="suffix" title="显示密码" @click="changePass3('hide')" style="cursor:pointer;" class="el-input__icon el-icon-view"></i>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogPassword = false">取 消</el-button>
          <el-button type="primary" @click="updatePassword">确 定</el-button>
        </div>
      </el-dialog>
    </el-header>

    <el-main style="margin-top:60px">
      <transition :duration="300" mode="out-in" appear enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" appear-active-class="animated zoomInDown">
        <keep-alive>
          <router-view></router-view>
        </keep-alive>
      </transition>

    </el-main>
  </el-container>
</template>

<script>
import bus from '../common/bus';
import store from "../store";

export default {
  data() {
    var reg1 = /^(?!\D+$)/ //数字
    var reg2 = /^(?![^a-zA-Z]+$)/ //字母
    // var reg3 = /[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/ //特殊字符
    var reg3 = /[^a-zA-Z0-9]+/ //特殊字符
    var reg4 = /(?!^(\d+|[a-zA-Z]+|[~!@#$%^&*_?]+)$)^[\w~!@#$%^&*_?]{8,32}$/ //字母，数字，特殊符号任意两种
    var validatePass = (rule, value, callback) => {
      // console.log(value)
      if (value == '' || value == undefined) {
        callback(new Error('请输入新密码'))
      } else {
        if (!reg4.test(value)) {
          callback(new Error('8-16位,数字/字母/特殊字符中任意两种'))
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value == '' || value == undefined) {
        callback(new Error('请再次输入新密码'))
      } else if (value !== this.changePassword.newPassword) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    var validatePass3 = (rule, value, callback) => {
      if (value == '' || value == undefined) {
        callback(new Error('请输入原密码'))
      } else {
        callback()
      }
    }
    return {
      count: {
        num0: 500, //应到人数
        num1: 400, //实到人数
        num2: 40, //未到人数
        num3: 90, //签到率
      },
      projectId: null,
      selShow: false, //头部选择项目下拉框显示与否
      projectName: '浙江工业大学投票管理系统', //汇总名字
      dialogMe: false, //个人中心弹窗显示与隐藏
      personalCenter: {}, //个人中心数据模型
      dialogPassword: false, //修改密码弹窗
      changePassword: {}, //修改密码数据模型
      oldShow: true, //原密码
      newShow: true, //新密码显示
      confirmShow: true, //确认新密码显示
      condition: false, //密码提示条件
      opennum0: true,
      opennum1: true,
      opennum2: true,
      opennum3: true,
      showTitle1: true,
      showTitle2: false, //切换导航栏
      userName: "",
      dialogVisible: false,
      imageshow: true,
      menuList: {},
      collapse: false,
      activeName: "first",
      animate: true,
      leftRight: true,
      editableTabsValue2: "2",
      editableTabs2: [{
        title: "Tab 1",
        name: "1",
        content: "Tab 1 content"
      },
      {
        title: "Tab 2",
        name: "2",
        content: "Tab 2 content"
      }
      ],
      tabIndex: 2,
      rules: {
        password: [{
          required: true,
          // message: "请输入原密码",
          validator: validatePass3,
          trigger: "blur"
        }],
        newPassword: [{
          required: true,
          validator: validatePass,
          trigger: 'blur'
        }],
        confirmPassword: [{
          required: true,
          validator: validatePass2,
          trigger: 'blur'
        }],
      },
      projectList: [],
      projectInfo: {}
    };
  },
  computed: {
    defaultActive: function () {
      return this.$route.path.replace("/", "");
    },
  },
  beforeUpdate() {
    if (this.$route.fullPath == '/selProject') {
      this.selShow = false
    } else {
      this.selShow = true
    }
  },

  created() {
    bus.$on('num', msg => {
      this.count = msg
    })
    bus.$on('projectName', msg => {
      this.projectName = msg
    })
  },
  mounted() {
    this.projectList = this.$store.state.projectList
    // this.projectName = this.$store.state.projectInfo.name
  },
  watch: {
  },
  methods: {
    handleChange(val) {
      let obj = {}
      obj = this.projectList.find(item => {
        // 筛选出匹配的数据
        return item.id === val
      })
      this.projectInfo = obj;
      this.handleConfirm()
    },
    handleConfirm(val) {
      if (!this.isEmpty(this.projectInfo.id)) {
        this.$message({
          message: '请选择一条项目！',
          type: 'error',
          customClass: 'zZindex'
        })
      } else {
        if (this.projectInfo.sign == 1) {
          this.checkSign();
        } else {
          this.handleSwitch();
        }
      }
    },
    checkSign() {
      this.$http.get('/api/sign/recall/' + this.projectInfo.id)
        .then(res => {
          if (res.data.code == 200) {
            this.handleSwitch()
          } else if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: 'error',
              customClass: 'zZindex'
            })
          }
        })
    },
    handleSwitch() {
      bus.$emit('projectName', this.projectInfo.name)
      this.$store.commit('SET_PROJECT_INFO', this.projectInfo)
      switch (this.projectInfo.voteRules) {
        case 0:
          this.$router.push({
            name: 'vote'
          })
          break;
        case 1:
          this.$router.push({
            name: 'voteMark'
          })
          break;
        case 2:
          this.$router.push({
            name: 'voteRank'
          })
          break;
        default:
          break;
      }
       bus.$emit('switchProject')
    },
    handleMe() {
      this.dialogMe = true
      this.$http.get('/api/personal/user/frontSearch')
        .then(res => {
          this.personalCenter = res.data.data
        })
    },
    // 点击修改密码
    handlePass() {
      this.dialogPassword = true
    },
    //判断渲染，true:暗文显示，false:明文显示
    changePass(value, visible) {
      visible = !visible
    },
    changePass1(value) {
      this.oldShow = !(value === 'show')
    },
    changePass2(value) {
      this.newShow = !(value === 'show')
    },
    changePass3(value) {
      this.confirmShow = !(value === 'show')
    },
    // 修改密码提交
    updatePassword() {
      this.$refs.changePassword.validate(valid => {
        if (valid) {
          this.$http.put('/api/user/frontPassword/' + this.changePassword.password + '/' + this.changePassword.newPassword)
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: '密码修改成功！',
                  type: 'success'
                })
                this.dialogPassword = false
                this.$router.replace({
                  path: '/login'
                })
              } else if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: 'error',
                  customClass: 'zZindex',
                })
              }
            })
            .catch(err => {
              console.log(err)
            })
        } else {
          console.log('error submit')
          return false
        }
      })
    },
    loginout() {
      this.$confirm("是否退出本次登陆?", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(res => {
          this.$store.commit("LOGOUT");
          this.$router.push("/login");
          this.$message({
            type: "success",
            message: "退出成功!",
            duration: 1000
          });
        })
        .catch(error => {
          console.log(error);
        });
    },
  }
};

</script>

<style>
.zZindex {
  z-index: 99999 !important;
}
/* 密码显示与隐藏 */
.el-icon-view:before {
  font-size: 20px;
}
.el-icon-view {
  /* background: url(../assets/image/showPassword1.png) center no-repeat; */
  /* background-size: auto; */
}
.el-icon-hide {
  background: url(../assets/image/hidePassword.png) center no-repeat;
  background-size: auto;
}

/* .el-main {
    padding:20px;
  } */
</style>

<style lang="scss" scoped>
.el-header {
  background-color: #237ae4;
  /* color: #333; */
  color: #fff;
  // line-height: 80px;
}

// .changePsd>>>.el-dialog__body {
//   padding: 30px 20px 0 20px !important;
// }

.underline0 {
  cursor: pointer;
  text-decoration: underline;
  // color: #67C231;
  color: #fff;
  font-size: 23px;
}

.underline1 {
  cursor: pointer;
  text-decoration: underline;
  // color: #E6A23C;
  color: #fff;
  font-size: 23px;
}

.underline2 {
  cursor: pointer;
  text-decoration: underline;
  // color: darkturquoise;
  color: #fff;
  font-size: 23px;
}

.underline3 {
  cursor: pointer;
  text-decoration: underline;
  // color: #E6A23C;
  color: #fff;
  font-size: 23px;
}

.container .header-flex {
  display: flex;
  -webkit-justify-content: space-between;
  justify-content: space-between;
  height: 80px !important;
  position: fixed;
  width: 100%;
  z-index: 9999;

  .header-left {
    flex: 1;
    line-height: 80px;

    .left-img {
      width: 30px;
      height: 30px;
      line-height: 80px;
      vertical-align: text-bottom;
    }
  }

  .header-center {
    flex: 1.5;
    text-align: center;
  }

  .header-right {
    flex: 1.5;
    text-align: right;
    line-height: 80px;
    font-size: 18px;
    font-weight: 500;
    cursor: pointer;

    span {
      margin-left: 8px;
    }

    .el-badge__content.is-fixed {
      top: 25px !important;
    }

    /* 小铃铛 */
    .badge-big {
      font-size: 28px;
      color: #fff;
    }

    .right-name {
      color: #fff;
      font-size: 17px;
      font-weight: 300px;
    }
  }

  .header-font {
    color: #fff;
    font-size: 20px;
    font-weight: 300;
  }

  .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-left: 20px;
    vertical-align: middle;
  }
}

.router-link-active {
  text-decoration: none;
  color: #606266;
}

a {
  text-decoration: none;
  color: #606266;
}

/* 下拉框上边距 */
.dropdown-top {
  margin-top: 0px !important;
}

.scroll >>> .el-scrollbar__wrap {
  overflow-x: hidden;
  overflow-y: auto;
  /* box-sizing: border-box; */
}

.el-tabs >>> .el-tabs__header {
  margin: 0 0 0;
}

.active {
  background: #e6f7ff;
}

.loginOut {
  width: 80px;
  float: left;
  margin-left: 20px;
}

.loginOut:hover {
  background: #418ae3;
}

.header-right >>> .el-button--text:hover {
  color: #95c5ff;
}

.header-right >>> .el-button--text {
  color: #fff;
  font-size: 18px;
  font-weight: 300;
}
.header-right .el-select /deep/ .el-input__inner {
  background-color: rgba(255, 255, 255, 0.3);
  border: none;
  color: #fff;
}
.header-right .el-select /deep/ .el-input__inner::-webkit-input-placeholder {
  color: #fff;
  // border: none;
}
</style>
