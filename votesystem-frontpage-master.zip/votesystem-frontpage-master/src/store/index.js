import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);
// 初始化时用sessionStore.getItem('token'),这样子刷新页面就无需重新登录
const state = {
  user: window.sessionStorage.getItem('user'),
  token: window.sessionStorage.getItem('token'),
  btns: window.sessionStorage.getItem('btns'),
  projectInfo: JSON.parse(window.sessionStorage.getItem('projectInfo')) || {},
  projectList: JSON.parse(window.sessionStorage.getItem('projectList')) || [],
  voteList: window.sessionStorage.getItem('voteList')
};
const mutations = {
  //将token保存到sessionStorage里，token表示登陆状态
  SET_TOKEN: (state, data) => {
    state.token = data;
    window.sessionStorage.setItem('token', data);
  },
  //获取用户名
  GET_USER: (state, data) => {
    // 把用户名存起来
    state.user = data;
    window.sessionStorage.setItem('user', data);
  },
  //获取用户名
  BTNS: (state, data) => {
    // 把用户名存起来
    state.btns = data;
    window.sessionStorage.setItem('btns', data);
  },
  //登出
  LOGOUT: state => {
    // 登出的时候要清除token
    state.token = null;
    state.user = null;
    state.projectInfo=null;
    state.projectList=null;
    window.sessionStorage.removeItem('token');
    window.sessionStorage.removeItem('user');
    window.sessionStorage.removeItem('projectInfo');
    window.sessionStorage.removeItem('projectList');
  },
  SET_PROJECT_INFO: (state, data) => {
    window.sessionStorage.setItem('projectInfo', JSON.stringify(data));
    state.projectInfo = data;
  },
  SET_PROJECT_LIST: (state, data) => {
    window.sessionStorage.setItem('projectList', JSON.stringify(data));
    state.projectList = data;
  },
  SET_VOTELIST: (state, data) => {
    window.sessionStorage.setItem('voteList', data);
    state.voteList = data;
  }
};
const getters = {};
const actions = {};
export default new Vuex.Store({
  state,
  mutations,
  getters,
  actions
});
