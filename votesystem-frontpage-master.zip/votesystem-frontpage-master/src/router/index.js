import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/login.vue'
import Main from '@/components/main.vue'
import personal from '@/page/personal.vue'

// 个人信息
import me from '@/page/me/me.vue'
import changePassword from '@/page/me/changePassword.vue'
import store from '../store'

// 投票系统
// 选择项目
import selProject from '../page/vote/selProject'
//同意制投票表
import Vote from '../page/vote/vote'
//打分制投票表
import VoteMark from '../page/vote/voteMark'
//排名制投票表
import VoteRank from '../page/vote/voteRank'



Vue.use(Router) // 注册vue-router

const router = new Router({
  //去掉地址中的哈希#
  // mode: "history",
  routes: [{
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/',
      name: 'main',
      component: Main,
      redirect: '/selProject',
      meta: {
        title: '个人信息',
        requireAuth: true, // 添加该字段，表示进入这个路由是需要登录的
      },
      children: [
        // me
        {
          path: '/me',
          component: me,
          meta: {
            title: '个人中心',
            requireAuth: true
          }
        },
        {
          path: '/changePassword',
          component: changePassword,
          meta: {
            title: '修改密码',
            requireAuth: true
          }
        },
        {
          path: '/personal',
          component: personal,
          meta: {
            title: '个人信息',
            requireAuth: true
          }
        },
        {
          path: '/selProject',
          component: selProject,
          meta: {
            title: '选择项目',
            requireAuth: true
          }
        },
        {
          path: '/vote',
          name: 'vote',
          component: Vote,
          meta: {
            title: '同意制投票',
            requireAuth: true
          }
        },{
          path: '/voteMark',
          name: 'voteMark',
          component: VoteMark,
          meta: {
            title: '打分制制投票',
            requireAuth: true
          }
        },{
          path: '/voteRank',
          name: 'voteRank',
          component: VoteRank,
          meta: {
            title: '排名制制投票',
            requireAuth: true
          }
        }
      ]
    },
  ]
})

// 注册全局钩子用来拦截导航
router.beforeEach((to, from, next) => {
  const token = store.state.token
  if (to.meta.requireAuth) { // 判断该路由是否需要登录权限
    if (token) { // 通过vuex state获取当前的token是否存在
      next()
    } else {
      console.log('该页面需要登陆')
      next({
        path: '/login'
        // query: {redirect: to.fullPath} // 将跳转的路由path作为参数，登录成功后跳转到该路由
      })
    }
  } else {
    next()
  }
})
export default router
