import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'
Vue.use(axios)
import createPersistedState from 'vuex-persistedstate'
Vue.use(Vuex)
const year = new Date().getFullYear()
const state = {
    openTab: [], // 所有打开的路由
    activeIndex: '/first', // 激活状态
    learning_code: false, // 学术成果审核审核详情
    learning_code1: false, // 学术成果审核审核详情(发表著作)
    learning_code2: false, // 学术成果审核审核详情(学术论文)
    learning_code3: false, // 学术成果审核审核详情(技术专利)
    learning_code4: false, // 学术成果审核审核详情(科研项目)
    // 当前用户被授权的按钮列表
    btnAuthorityList: [],
    // 流程-路由对应map
    newsRouterMap: {
        tzList: "/homeNoticeList",
        stuTrainingPlanApply: "/trainAudit",
        stuInfoReplaceCardApply: "/rollAudit",
        stuInfoServiceYiYeApply: "/rollAudit",
        stuInfoServiceFinishGraduateApply: "/rollAudit",
        stuTrainingPlanChangeApply: "/trainAudit",
        stuInfoServiceGoBackSchoolApply: "/rollAudit",
        DegreeApplication: "/qualification",
        academicApply: "/learing_xxcg",
        stuInfoServiceChangeTeacherApply: "/rollAudit",
        stuInfoServiceDelayGraduateApply: "/rollAudit",
        stuInfoServiceDoctorAndMesterApply: "/rollAudit",
        stuInfoServiceDropOutApply: "/rollAudit",
        stuInfoServiceQuitSchoolApply: "/rollAudit",
        stuInfoServiceSwitchMajorApply: "/rollAudit",
        stuKcsqRebuildApply: "/studentAudit",
        stuKcsqServiceChangeCourseApply: "/teachClass",
        stuKcsqServiceDelayedExamApply: "/studentAudit",
        stuKcsqServiceExemptionApply: "/studentAudit",
        teaSwitchClassApply: "/teachClass",
        StudentCompletionProcessEducationProject: "/conclusionAduit",
        StudentProgramApplicationEducationProject: "/jiansheProjectAduit",
        TutorCompletionProcessEducationProject: "/conclusionAduit",
        TutorProgramApplicationEducationProject: "/jiansheProjectAduit"
    },
    planclass: [{
            value: year,
            label: year
        },
        {
            value: year + 1,
            label: year + 1
        },
        {
            value: year + 2,
            label: year + 2
        }
    ],
    menuList: [],
    navList: [{
            id: '1',
            name: '系统管理',
            icon: 'el-icon-s-tools',
            children: [{
                    name: '学校参数设置',
                    path: '/schoolBasic',
                    icon: 'el-icon-star-off',
                    id: '846'
                },
                {
                    name: '校区信息管理',
                    path: '/schoolManagement',
                    icon: 'el-icon-star-off',
                    id: '100'
                },
                {
                    name: '组织机构管理',
                    path: '/institutional',
                    icon: 'el-icon-star-off',
                    id: '101'
                },
                {
                    name: '楼栋信息管理',
                    path: '/buildingInformation',
                    icon: 'el-icon-star-off',
                    id: '102'
                },
                {
                    name: '教职工信息管理',
                    path: '/staffManagement',
                    icon: 'el-icon-star-off',
                    id: '103'
                },
                {
                    name: '角色权限管理',
                    path: '/roleManagement',
                    icon: 'el-icon-star-off',
                    id: '104'
                },
                {
                    name: '用户信息管理',
                    path: '/userManagement',
                    icon: 'el-icon-star-off',
                    id: '105'
                },
                {
                    name: '通知公告管理',
                    path: '/notification',
                    icon: 'el-icon-star-off',
                    id: '106'
                },
                {
                    name: '功能模块管理',
                    path: '/moduleManagement',
                    icon: 'el-icon-star-off',
                    id: '108'
                }
            ]
        },
        {
            id: '2',
            name: '培养管理',
            icon: 'el-icon-s-custom',
            children: [{
                    name: '基础数据维护',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '200',
                    children: [{
                            name: '基础参数设置',
                            path: '/preferences',
                            id: '210',
                        },
                        {
                            name: '学院信息管理',
                            path: '/collegeInformation',
                            id: '208',
                        },
                        {
                            name: '专业信息管理',
                            path: '/majorInformation',
                            id: '207',
                        },
                        {
                            name: '班级信息管理',
                            path: '/classInformation',
                            id: '205',
                        },
                        {
                            name: '教室信息维护',
                            path: '/teacherInformation',
                            id: '204',
                        },
                        {
                            name: '导师信息维护',
                            path: '/tutorInformation',
                            id: '203',
                        },
                        {
                            name: '课程信息维护',
                            path: '/courseInformation',
                            id: '202',
                        },
                        {
                            name: '学位点信息维护',
                            path: '/degreeProgram',
                            id: '278',
                        }
                    ]
                },
                {
                    name: '学生信息管理',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '300',
                    children: [{
                            name: '新生数据维护',
                            path: '/rebirthData',
                            id: '301',
                        },
                        {
                            name: '学生信息管理',
                            path: '/studentInformation',
                            id: '302',
                        },
                        {
                            name: '学生信息审核',
                            path: '/rollAudit',
                            id: '303',
                        },
                        {
                            name: '老生批量注册',
                            path: '/oldRegister',
                            id: '304',
                        }
                    ]
                },
                {
                    name: '培养方案管理',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '305',
                    children: [{
                            name: '制定培养方案',
                            path: '/makePlan',
                            id: '306',
                        },
                        {
                            name: '培养方案审核',
                            path: '/projectAduit',
                            id: '307',
                        },
                        {
                            name: '培养方案库',
                            path: '/projectBank',
                            id: '308',
                        }
                    ]
                },
                {
                    name: '课程开课管理',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '309',
                    children: [{
                            name: '制定开课方案',
                            path: '/formulate',
                            id: '310',
                        },
                        {
                            name: '教师调课审核',
                            path: '/teachClass',
                            id: '311',
                        },
                        {
                            name: '课程停开处理',
                            path: '/classStop',
                            id: '312',
                        },
                        {
                            name: '课表查询',
                            path: '/searchClass',
                            id: '356',
                        }
                    ]
                },
                {
                    name: '学生培养计划',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '313',
                    children: [{
                            name: '培养计划审核',
                            path: '/trainAudit',
                            id: '314',
                        },
                        {
                            name: '补选(退选)处理',
                            path: '/byElection',
                            id: '315',
                        },
                        {
                            name: '学生课程审核',
                            path: '/studentAudit',
                            id: '363',
                        },
                        {
                            name: '培养计划查询',
                            path: '/trainSearch',
                            id: '316',
                        }
                    ]
                },
                {
                    name: '学生成绩管理',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '317',
                    children: [{
                            name: '成绩录入审核',
                            path: '/achievementsrecorded',
                            id: '318',
                        },
                        {
                            name: '重修学生名单',
                            path: '/rebuildstudents',
                            id: '319',
                        },
                        {
                            name: '学生成绩汇总',
                            path: '/resultssummary',
                            id: '320',
                        }
                    ]
                },
                {
                    name: '教学评价管理',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '321',
                    children: [{
                            name: '评教问卷管理',
                            path: '/assessmentquestionnaire',
                            id: '322',
                        },
                        {
                            name: '评教结果汇总',
                            path: '/evaluationresults',
                            id: '323',
                        }
                    ]
                },
                {
                    name: '毕业生管理',
                    icon: 'el-icon-s-operation',
                    path: '/graduateManagement',
                    id: '324'
                },
                {
                    name: '四六级报名管理',
                    icon: 'el-icon-s-operation',
                    id: '326',
                    path: '',
                    children: [{
                        name: '四六级报名管理',
                        path: '/Registrationsix',
                        id: '327',
                    }]
                },
                {
                    name: '教学工作量管理',
                    icon: 'el-icon-s-operation',
                    id: '328',
                    path: '/workloadManagement'
                },
                {
                    name: '学生活动管理',
                    icon: 'el-icon-s-operation',
                    id: '330',
                    path: '/activityManagement'
                },
                {
                    name: '统计分析',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '331',
                    children: [{
                            name: '课程信息统计',
                            path: '/courseInfoStatistical',
                            id: '332',
                        },
                        {
                            name: '成绩信息统计',
                            path: '/teacheringStatistical',
                            id: '333',
                        },
                    ]
                },
                {
                    name: '研究生院高级报表',
                    icon: 'el-icon-s-operation',
                    path: '',
                    id: '334',
                    children: [{
                            name: '硕士研究生分专业学生数',
                            path: '/masterNumber',
                            id: '335',
                        },
                        {
                            name: '博士研究生分专业学生数',
                            path: '/doctoralNumber',
                            id: '336',
                        },
                        {
                            name: '在校生分年龄情况',
                            path: '/ageStudents',
                            id: '337',
                        },
                        {
                            name: '招生、在校生来源情况',
                            path: '/sourceStudent',
                            id: '338',
                        },
                        {
                            name: '学生变动情况',
                            path: '/changeStudents',
                            id: '339',
                        },
                        {
                            name: '学生休学退学主要原因',
                            path: '/leaveReson',
                            id: '340',
                        },
                        {
                            name: '在校生中其他情况',
                            path: '/otherStudents',
                            id: '341',
                        },
                        {
                            name: '研究生指导教师情况',
                            path: '/teacherGuidance',
                            id: '342',
                        },
                        {
                            name: '专职辅导员情况',
                            path: '/fullTimeCounselor',
                            id: '343',
                        },
                    ]
                }
            ]
        },
        {
            id: '3',
            name: '迎新管理',
            icon: 'el-icon-s-check',
            children: [{
                    name: '基础数据管理',
                    icon: 'el-icon-monitor',
                    path: '',
                    id: '378',
                    children: [{
                            name: '基础参数设置',
                            path: '/jccs',
                            id: '388',
                        },

                        {
                            name: '新生基本信息',
                            path: '/newstudent',
                            id: '389',
                        },
                        {
                            name: '财务缴费数据',
                            path: '/Financialpayment',
                            id: '390',
                        },
                        {
                            name: '宿舍分配数据',
                            path: '/dormitory',
                            id: '391',
                        },
                        {
                            name: '报到信息采集',
                            path: '/reportedinformation',
                            id: '392',
                        },
                        {
                            name: '报到须知管理',
                            path: '/guidelines',
                            id: '393',
                        },
                        {
                            name: '测试试卷管理',
                            path: '/testpaper',
                            id: '394',
                        },
                        {
                            name: '校园风光',
                            path: '/schoolListimg',
                            id: '394889679',
                        }
                    ]
                },
                {
                    name: '新生报道管理',
                    path: '/newstudentlive',
                    icon: 'el-icon-monitor',
                    id: '395',
                },
                {
                    name: '统计分析',
                    icon: 'el-icon-monitor',
                    id: '396',
                    path: '',
                    children: [{
                            name: '迎新实时统计',
                            path: '/totalallstudent',
                            id: '397',
                        },
                        {
                            name: '道德测试统计',
                            path: '/moralitytest',
                            id: '398',
                        },
                        // {
                        //   name: "历年迎新统计",
                        //   path: ""
                        // }
                    ]
                }
            ]
        },
        {
            id: '4',
            name: '学术成果管理',
            icon: 'el-icon-trophy',
            children: [{
                    name: '基础参数设置',
                    path: '/learing_jccs',
                    icon: 'el-icon-thumb',
                    id: '400',
                },
                {
                    name: '学术成果审核',
                    path: '/learing_xxcg',
                    icon: 'el-icon-thumb',
                    id: '401',
                },
                {
                    name: '学术成果汇总',
                    path: '/learing_xxhz',
                    icon: 'el-icon-thumb',
                    id: '402',
                }
            ]
        },
        {
            id: '5',
            name: '学位论文管理',
            icon: 'el-icon-trophy',
            children: [{
                    name: '预答辩管理',
                    path: '/Basicparameters',
                    icon: 'el-icon-thumb',
                    id: '752',
                },
                {
                    name: '学位论文审核',
                    path: '/qualification',
                    icon: 'el-icon-thumb',
                    id: '0558',
                }, {
                    name: '学位论文查重',
                    path: '/checkdisser',
                    icon: 'el-icon-thumb',
                    id: '96958',
                },
                {
                    name: '学位论文送审',
                    path: '/dissertation',
                    icon: 'el-icon-thumb',
                    id: '0559',
                },
                {
                    name: '毕业答辩管理',
                    path: '/graduation',
                    icon: 'el-icon-thumb',
                    id: '05545',
                },
                {
                    name: '论文终稿存档',
                    path: '/lwzgcd',
                    icon: 'el-icon-thumb',
                    id: '05585455',
                },
                {
                    name: '学位证书授予',
                    path: '/xwzssy',
                    icon: 'el-icon-thumb',
                    id: '0567',
                },
                {
                    name: '学位论文抽检',
                    path: '/xwlwcj',
                    icon: 'el-icon-thumb',
                    id: '05588585',
                },
                {
                    name: '送审账号管理',
                    path: '/yxlwps',
                    icon: 'el-icon-thumb',
                    id: '0558789',
                },
                {
                    name: '送审单位管理',
                    path: '/xwzgsq',
                    icon: 'el-icon-thumb',
                    id: '05585',
                },
                {
                    name: "满意度调查管理",
                    path: "",
                    icon: "el-icon-thumb",
                    id: '05586',
                    children: [{
                            name: "调查问卷设置",
                            path: "/paperSet",
                            icon: "el-icon-thumb",
                            id: '05587',
                        },
                        {
                            name: "满意度调查统计",
                            path: "/paperAnalysis",
                            icon: "el-icon-thumb",
                            id: '05588',
                        },
                    ]
                },
                {
                    name: "学位论文统计",
                    path: "/degreeStatistical",
                    icon: "el-icon-thumb",
                    id: '05589',
                },
            ]
        },
        {
            id: '6',
            name: '招生管理',
            icon: 'el-icon-trophy',
            children: [{
                    name: '基础参数设置',
                    icon: 'el-icon-s-operation',
                    path: '/enrolBasicParams',
                    id: '61'
                },
                {
                    name: '硕士招生管理',
                    icon: 'el-icon-s-operation',
                    id: '62',
                    children: [{
                            name: '专业目录上报',
                            path: '/specialReport?id=2',
                            id: '601',
                        },
                        {
                            name: '专业目录审核',
                            path: '/specialAduit?id=2',
                            id: '602',
                        },
                        {
                            name: '考试科目管理',
                            path: '/examManage?id=2',
                            id: '603',
                        },
                        {
                            name: '考生信息管理',
                            path: '/stuInfoManage?id=2',
                            id: '604',
                        },
                        {
                            name: '考点信息管理',
                            path: '/pointInfoManage?id=2',
                            id: '605',
                        },
                        {
                            name: '初试成绩录入',
                            path: '/firstScoreInput?id=2',
                            id: '606',
                        },
                        {
                            name: '最终初试成绩',
                            path: '/finalFirstScore?id=2',
                            id: '607',
                        },
                        {
                            name: '招生名额限定',
                            path: '/limit',
                            id: '607',
                        },
                        {
                            name: '招生名额上报',
                            path: '/reportQuota',
                            id: '607',
                        },
                        {
                            name: '招生名额审核',
                            path: '/reviewof',
                            id: '607',
                        },
                        {
                            name: '复试分数线及权重上报',
                            path: '/reeaxmReport?id=2',
                            id: '608',
                        },
                        {
                            name: '复试分数线及权重汇总',
                            path: '/reeaxmSummary?id=2',
                            id: '609',
                        },
                        {
                            name: '复试名单管理',
                            path: '/interviewTable',
                            id: '610',
                        },
                        {
                            name: '复试成绩录入',
                            path: '/resultEntryList',
                            id: '611',
                        },
                        {
                            name: '综合成绩管理',
                            path: '/perFormance',
                            id: '612',
                        },
                        {
                            name: '录取名单管理',
                            path: '/addmissProposed',
                            id: '613',
                        },
                        {
                            name: '调剂生名单管理',
                            path: '/adjustTable',
                            id: '614',
                        },
                        {
                            name: '调剂生复试成绩录入',
                            path: '/transferStudentsList',
                            id: '615',
                        },
                        {
                            name: '调剂生最终成绩',
                            path: '/finalgrade',
                            id: '616',
                        },
                        {
                            name: '调剂生录取管理',
                            path: '/enrollment',
                            id: '617',
                        },
                        {
                            name: '最终录取名单',
                            path: '/finaladd',
                            id: '618',
                        },
                    ]
                },
                {
                    name: '博士招生管理',
                    icon: 'el-icon-s-operation',
                    id: '900',
                    children: [{
                            name: '专业目录上报',
                            path: '/submission?id=2',
                            id: '901',
                        },
                        {
                            name: '专业目录审核',
                            path: '/catalogAduit?id=2',
                            id: '902',
                        },
                        {
                            name: '考试科目管理',
                            path: '/Examination?id=2',
                            id: '903',
                        },
                        {
                            name: '考生信息管理',
                            path: '/SubjectManage?id=2',
                            id: '904',
                        },
                        {
                            name: '初试成绩录入',
                            path: '/EntryScore?id=2',
                            id: '905',
                        },
                        {
                            name: '最终初试成绩',
                            path: '/finalTestScore?id=2',
                            id: '906',
                        },
                        {
                            name: '招生名额限定',
                            path: '/restriction',
                            id: '987',
                        },
                        {
                            name: '招生名额上报',
                            path: '/reQuota',
                            id: '947',
                        },
                        {
                            name: '招生名额审核',
                            path: '/reviewsh',
                            id: '921',
                        },
                        {
                            name: '复试分数线及权重上报',
                            path: '/rmReport?id=2',
                            id: '981',
                        },
                        {
                            name: '复试分数线及权重汇总',
                            path: '/reaxmSumary?id=2',
                            id: '931',
                        }, {
                            name: '复试名单管理',
                            path: '/interTable',
                            id: '932',
                        }, {
                            name: '复试成绩录入',
                            path: '/resEntryList',
                            id: '932',
                        }, {
                            name: '综合成绩管理',
                            path: '/permance',
                            id: '933',
                        }, {
                            name: '录取名单管理',
                            path: '/addProsed',
                            id: '934',
                        }
                    ]
                }, {
                    name: '推免生招生管理',
                    icon: 'el-icon-s-operation',
                    id: '701',
                    children: [{
                            name: '专业目录管理',
                            path: '/zymlgl',
                            id: '702',
                        },
                        {
                            name: '考生信息管理',
                            path: '/ksxigl',
                            id: '703',
                        },
                        {
                            name: '复试成绩录入',
                            path: '/fscjlr',
                            id: '704',
                        }, {
                            name: '录取名单管理',
                            path: '/addPromse',
                            id: '705',
                        },
                    ]
                }, {
                    name: '材料上报',
                    icon: 'el-icon-s-operation',
                    id: '920',
                    children: [{
                            name: '材料类型设置',
                            path: '/MaterialTypeSetting',
                            id: '921',
                        },
                        {
                            name: '材料上报',
                            path: '/MaterialReport',
                            id: '922',
                        },
                        {
                            name: '材料审核',
                            path: '/MaterialAduit',
                            id: '923',
                        },
                    ]
                },
                {
                    name: '统计分析',
                    icon: 'el-icon-s-operation',
                    id: '930',
                    children: [{
                            name: '历年招生统计',
                            path: '/actualEnrollmentStatistical',
                            id: '931',
                        },
                        {
                            name: '新生点赞统计',
                            path: '/newbornStatistical',
                            id: '932',
                        },
                        {
                            name: '预计报名统计',
                            path: '/estimatedEnrollStatistical',
                            id: '933',
                        },
                    ]
                }
            ]
        },
        {
            id: '7',
            name: '教育建设项目',
            icon: 'el-icon-trophy',
            children: [{
                    name: '项目信息发布',
                    path: '/projectPublish',
                    icon: 'el-icon-thumb',
                    id: '70001',
                },
                {
                    name: '项目申报审核',
                    path: '/jiansheProjectAduit',
                    icon: 'el-icon-thumb',
                    id: '70002',
                },
                {
                    name: '项目立项管理',
                    path: '/projectApproval',
                    icon: 'el-icon-thumb',
                    id: '70003',
                },
                {
                    name: '项目结题审核',
                    path: '/conclusionAduit',
                    icon: 'el-icon-thumb',
                    id: '70004',
                },
                {
                    name: '项目信息汇总',
                    path: '/projectInfoSummary',
                    icon: 'el-icon-thumb',
                    id: '70005',
                },
                {
                    name: '统计分析',
                    path: '/projectStatistical',
                    icon: 'el-icon-thumb',
                    id: '70006',
                },
                // {
                //     name: '项目立项管理',
                //     path: '/lxgl',
                //     icon: 'el-icon-thumb',
                //     id: '70003',
                // },
                // {
                //     name: '学位论文送审',
                //     path: '/dissertation',
                //     icon: 'el-icon-thumb',
                //     id: '0559',
                // },
                // {
                //     name: '毕业答辩管理',
                //     path: '/graduation',
                //     icon: 'el-icon-thumb',
                //     id: '05545',
                // },
                // {
                //     name: '论文终稿存档',
                //     path: '/lwzgcd',
                //     icon: 'el-icon-thumb',
                //     id: '05585455',
                // },
                // {
                //     name: '学位证书授予',
                //     path: '/xwzssy',
                //     icon: 'el-icon-thumb',
                //     id: '0567',
                // },
                // {
                //     name: '学位资格授予',
                //     path: '/xwzgsq',
                //     icon: 'el-icon-thumb',
                //     id: '05585',
                // },
                // {
                //     name: '优秀论文评审',
                //     path: '/yxlwps',
                //     icon: 'el-icon-thumb',
                //     id: '0558789',
                // },
                // {
                //     name: '学位论文抽检',
                //     path: '/xwlwcj',
                //     icon: 'el-icon-thumb',
                //     id: '05588585',
                // }
            ]
        },
        // {
        //   name: '国际化培养管理',
        //   path: '6',
        //   children: [{
        //       name: "基础参数设置",
        //       path: "/learing_jccs"
        //     },
        //     {
        //       name: "学术成果审核",
        //       path: "/learing_xxcg"
        //     },
        //     {
        //       name: "学术成果汇总",
        //       path: "/learing_xxhz"
        //     }
        //   ]
        // },
        // {
        //   name: '教育建设项目管理',
        //   path: '7'
        // },
        // {
        //   name: '学术成果管理',
        //   path: '8'
        // },
        // {
        //   name: '学位论文管理',
        //   path: '7'
        // },
        // {
        //   name: '研工管理',
        //   path: '9'
        // },
        // {
        //   name: '离校管理',
        //   path: '10'
        // },
        // {
        //   name: '就业管理',
        //   path: '11'
        // },
        // {
        //   name: '统计报表',
        //   path: '12'
        // },
    ],
    typexxcg: 1,
    token: '',
    roleid_tole: '',
    usersnames: '',
    formlist: [
        //   {
        //   js: 'jxb',
        //   message: '教学班不能为空'
        // },
        {
            js: 'zc',
            message: '上课时间--周次不能为空'
        },
        {
            js: 'xq',
            message: '上课时间--星期不能为空'
        },
        {
            js: 'sfmz',
            message: '上课时间--每周,单周,双周必选'
        }
    ],
    tableHeight: null,
    clientHeight: 0,
    offsetTop: 0,
    scrollTop: document.documentElement.scrollTop,
    collapse: false,
    assignee: {},
    menuArrend: {
        xzmneu: '',
        submenuArr: [],
        endmenuArr: []
    },
    degreeObj: {},
    xnxqList: {},
    loGo: '',
    tokenParams: {}

}
const getters = {
    getTableHeight: state => {
        return state.tableHeight
    },
    getBtnAuthorityList(state) {
        return state.btnAuthorityList
    }
}
const mutations = {
    tokenParam(state, key) {
        this.state.tokenParams = key
    },
    loGogh(state, url) {
        state.loGo = url
    },
    xnxqparams(state) {
        axios
            .get("api/cultivate/pycssz/acadmic")
            .then(res => {
                state.xnxqList = res.data.data
            })
            .catch(err => {
                console.log(err.message);
            });
    },
    // 更新获取当前用户被授权的按钮列表
    updateBtnAuthorityList(state, arr) {
        state.btnAuthorityList = arr
    },
    menuArrend(state, key) {
        this.state.menuArrend = key
    },
    // 学术
    INCREMENT(state, key) {
        state[key] = !state[key]
            // console.log(state, key)
    },
    // token验证
    tokenrole(state, tokens) {
        state.token = tokens
    },
    menulistansy(state, statelist) {
        state.menuList = statelist
    },
    typexxcg(state, xxcg) {
        state.typexxcg = xxcg
    },
    roleid_toles(state, statelists) {
        state.roleid_tole = statelists
    },
    username(state, name) {
        state.usersnames = name
    },
    // 添加tabs
    add_tabs(state, data) {
        // console.log(state, data)
        this.state.openTab.push(data)
    },
    assignee(state, keyindex) {
        state.assignee = keyindex
    },
    // 删除tabs
    delete_tabs(state, route) {
        let index = 0
        for (const option of state.openTab) {
            if (option.route === route) {
                break
            }
            index++
        }
        this.state.openTab.splice(index, 1)
    },
    // 设置当前激活的tab
    set_active_index(state, index) {
        // console.log(index)
        this.state.activeIndex = index
    },
    // 获取表格的偏移量
    offsetTop(state, offsetTop) {
        state.offsetTop = offsetTop - state.scrollTop
    },
    updateTableHeight(state) {
        state.tableHeight = document.documentElement.clientHeight - 258
    },
    DEGREE(state, key) {
        state.degreeObj = key
    }
}

const actions = {

}
export default new Vuex.Store({
    state,
    mutations,
    actions,
    getters,
    plugins: [createPersistedState({
        storage: window.sessionStorage
    })]
})
