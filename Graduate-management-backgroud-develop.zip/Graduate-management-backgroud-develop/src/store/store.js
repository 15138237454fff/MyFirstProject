import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import skbStore from './skb/store'
import jiansheProject from "./jiansheProject"
Vue.use(Vuex)
const state = {
  studInformation: false,
  schoolRoll: false,
  rebirthInfor: false,
  teachDistribution: false,
  classDistribution: false,
  staffInfor: false,
  staffDetails: false,
  addtree: false,
  addPlan: false,
  cheakdetails: false,
  addnotific: false,
  modifnotific: false,
  manualClass: false,
  traindetails: false,
  electiondetails: false,
  audit0: false,
  audit1: false,
  audit2: false,
  audit3: false,
  audit4: false,
  audit5: false,
  audit6: false,
  audit7: false,
  audit8: false,
  audit9: false,
  audit00: false,
  audit01: false,
  audit02: false,
  audit03: false,
  audit04: false,
  audit05: false,
  audit06: false,
  audit07: false,
  audit08: false,
  audit09: false,
  auditDetails: false,
  train: false,
  exemption: false,
  rebuild: false,
  delayed: false,
  roledata: false,
  newstudentmessages: false, // 新生基本信息详情
  addguidelines: false, // 报道须知管理的添加
  evaluationresults: false,
  testpaperlist: false, // 道德测试详情
  addnotificlist: false, // 报到须知管理详情
  gridData: [{
    xx: 'A',
    xxnr: '',
    label: 'A',
    duoxuan: false,
    zqda: ''
  },
  {
    xx: 'B',
    xxnr: '',
    label: 'B',
    duoxuan: false,
    zqda: ''
  },
  {
    xx: 'C',
    xxnr: '',
    label: 'C',
    duoxuan: false,
    zqda: ''
  },
  {
    xx: 'D',
    xxnr: '',
    label: 'D',
    duoxuan: false,
    zqda: ''
  }
  ],
  jssc_add: false
}
const mutations = {

}

const actions = {}
export default new Vuex.Store({
  plugins: [createPersistedState({
    storage: window.sessionStorage
  })],
  modules: {
    skb: skbStore,
    jiansheProject
  },
  state,
  mutations,
  actions,
})
