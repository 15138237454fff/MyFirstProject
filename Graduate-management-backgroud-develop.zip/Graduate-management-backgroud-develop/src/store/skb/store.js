export default {
  state: {
    // 保存对话框信息
    dialogMsg: {
      title: '确认提交',
      msgOne: '是否确认提交？',
      msgTwo: '',
      visible: false,
      successCallback: () => {}
    },
  },
  getters: {
    // 外部获取对话框信息
    getDialog(state) {
      return state.dialogMsg
    },
  },
  mutations: {
    // 更新对话框参数
    updateDialog(state, {
      title,
      msgOne,
      msgTwo,
      visible,
      successCallback
    }) {
      !!title && (state.dialogMsg.title = title)
      !!msgOne && (state.dialogMsg.msgOne = msgOne)
      !!msgTwo && (state.dialogMsg.msgTwo = msgTwo)
      visible !== undefined && (state.dialogMsg.visible = visible)
      !!successCallback && (state.dialogMsg.successCallback = successCallback)
    },
  },
  actions: {

  },
  namespaced: true
}
