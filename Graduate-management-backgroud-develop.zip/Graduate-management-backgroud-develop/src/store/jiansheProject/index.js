export default {
  state: {
    // 学生项目部分
    // 田野调查基金项目数据
    formDataForTYDCJJXM: {
      // 学号
      xh: "",
      // 经费使用计划-备注说明
      jfBz: "",
      // 经费使用计划-交通费
      jfJt: "",
      // 经费使用计划-其他费用
      jfQt: "",
      // 经费使用计划-总计申请经费
      jfZj: "",
      // 经费使用计划-资料费
      jfZl: "",
      // 经费使用计划-住宿费
      jfZs: "",
      // 简介附件
      jjfj: { url: "", fileName: "" },
      // 课题名称
      ktmc: "",
      // 申报活动主要内容简介
      nrjj: "",
      // 项目设计论证-预期成果
      sjlzCg: "",
      // 项目设计论证-实施方案
      sjlzFa: "",
      // 设计论证附件
      sjlzFj: { url: "", fileName: "" },
      // 项目设计论证-选题
      sjlzXt: "",
      // 项目ID
      xmId: "",
      // 项目可行性分析附件
      xmfxFj: { url: "", fileName: "" },
      // 项目可行性分析-该项目可能存在的风险和对策
      xmfxFx: "",
      // 项目可行性分析-项目具备的基础和优势
      xmfxJc: "",
      // 项目组信息
      xmzxx: [
        {
          // 院系所名称
          collegeName: "",
          // 院系所号
          collegeNum: "",
          // 专业名称
          majorName: "",
          // 专业代码
          majorNum: "",
          // 姓名
          name: "",
          // 联系电话
          phone: "",
          // 性别
          sex: "",
          // 学号
          studentNumber: "",
          // 承担任务
          tasks: "",
          // 培养层次
          trainingLevel: "",
          // 培养层次
          trainingLevelNum: ""
        }
      ],
      // 预计完成时间
      yjwcsj: "",
      // 指导教师通讯地址
      zdjsdz: "",
      // 指导教师工号
      zdjsgh: ""
    },
    // 校级研究生科研项目数据
    formDataForXJYJSKYXM: {
      // 备注说明
      jfBz: "",
      // 经费使用计划-调研差旅费
      jfCl: 0,
      // 经费使用计划-资料费
      jfJsjsy: 0,
      // 经费使用计划-其他费用
      jfQa: 0,
      // 经费使用计划-文印费
      jfWy: 0,
      // 经费使用计划-总计费用
      jfZj: 0,
      // 经费使用计划-资料费
      jfZl: 0,
      // 论文字数
      lwzs: 0,
      sjlzFj: { url: "", fileName: "" },
      // 项目设计论证-项目研究的基本思路、主要内容、理论与实际意义、创新之处和预期成果
      sjlzNr: "",
      // 学号
      xh: "",
      xmId: 0,
      // 项目名称
      xmmc: "",
      xmzxx: [
        {
          // 出生年月
          birthDate: "",
          // 院系所名称
          collegeName: "",
          // 院系所号
          collegeNum: "",
          // 所在年级
          grade: "",
          // 专业名称
          majorName: "",
          // 专业代码
          majorNum: "",
          // 姓名
          name: "",
          // 联系电话
          phone: "",
          // 性别
          sex: "",
          // 学号
          studentNumber: "",
          // 承担任务
          tasks: "",
          // 培养层次
          trainingLevel: "",
          // 培养层次
          trainingLevelNum: ""
        }
      ],
      // 预期成果 1.论文 2专著 3译著 4研究报告 5工具书 6电脑软件
      yqcg: [],
      // 指导教师工号
      zdjsgh: "",
      // 主题词
      ztc: ""
    },
    // 知行浙江社会调研项目数据
    formDataForZXZJSHDYXM: {
      jfBz: "",
      jfJt: 0,
      jfQt: 0,
      jfZj: 0,
      jfZl: 0,
      jfZs: 0,
      jjfj: {
        fileName: "",
        url: ""
      },
      ktmc: "",
      nrjj: "",
      sjlzFj: {
        fileName: "",
        url: ""
      },
      sjlzJz: "",
      sjlzNr: "",
      sjlzXt: "",
      wcxmFj: {
        fileName: "",
        url: ""
      },
      wcxmTj: "",
      xh: "",
      xmId: "",
      xmzxx: [
        {
          birthDate: "",
          collegeName: "",
          collegeNum: "",
          grade: "",
          majorName: "",
          majorNum: "",
          name: "",
          phone: "",
          sex: "",
          studentNumber: "",
          tasks: "",
          trainingLevel: "",
          trainingLevelNum: ""
        }
      ],
      yjwcsj: "",
      zdjsdz: "",
      zdjsgh: ""
    },
    // 田野调查基金项目结题数据
    formDataIsConclusionForTYDCJJXM: {
      cgfb: [
        {
          feedback: "",
          journalNumber: "",
          paperName: "",
          publishTime: "",
          remark: "",
          sort: ""
        }
      ],
      dcgzzjFj: {
        fileName: "",
        url: ""
      },
      dcgzzjNr: "",
      lcid: "",
      xmId: "",
      xmssqkzjFj: {
        fileName: "",
        url: ""
      },
      xmssqkzjNr: ""
    },
    // 校级研究生科研项目结题数据
    formDataIsConclusionForXJYJSKYXM: {
      cgfb: [
        {
          feedback: "",
          journalNumber: "",
          paperName: "",
          publishTime: "",
          remark: "",
          sort: ""
        }
      ],
      yjgcgzFj: {
        fileName: "",
        url: ""
      },
      yjgcgzNr: "",
      lcid: "",
      xmId: "",
      yjgzzjFj: {
        fileName: "",
        url: ""
      },
      yjgzzjNr: ""
    },
    // 教师项目部分
    // 课程案例库建设项目
    formDataForKCALKJSXM: {
      almc: "",
      cyjxcg: "",
      cyjxcgFj: {
        fileName: "",
        url: ""
      },
      cyxx: [
        {
          dzyx: "",
          ssyxh: "",
          ssyxmc: "",
          yddh: "",
          yjfx: "",
          zc: "",
          zdjsgh: "",
          zdjsxm: "",
          zw: "",
          zy: "",
          zym: "",
          responsible: ""
        }
      ],
      gh: "",
      jscg: "",
      jscgFj: {
        fileName: "",
        url: ""
      },
      jsfa: "",
      jsfaFj: {
        fileName: "",
        url: ""
      },
      jssj: "",
      jxcg: "",
      jxcgFj: {
        fileName: "",
        url: ""
      },
      kcdm: "",
      kcmc: "",
      kssj: "",
      lxyj: "",
      lxyjFj: {
        fileName: "",
        url: ""
      },
      xmId: "",
      zy: "",
      zym: ""
    },
    // 博士研究生课程建设项目
    formDataForBSYJSKCJSXM: {
      cjzxx: [
        {
          dzyx: "",
          ssyxh: "",
          ssyxmc: "",
          yddh: "",
          yjfx: "",
          zc: "",
          zdjsgh: "",
          zdjsxm: "",
          zw: ""
        }
      ],
      gh: "",
      jsfa: "",
      jsfaFj: {
        fileName: "",
        url: ""
      },
      jsmb: "",
      jsmbFj: {
        fileName: "",
        url: ""
      },
      kcmc: "",
      kssj: "",
      kcxm: "",
      lxyj: "",
      lxyjFj: {
        fileName: "",
        url: ""
      },
      rjkcxx: [
        {
          kch: "",
          kcmc: "",
          teacher: {
            gh: "",
            id: "",
            jsxm: "",
            sksjList: [
              {
                id: "",
                kj: "",
                pksjid: "",
                sfmz: "",
                skdd: "",
                xq: "",
                zc: ""
              }
            ]
          }
        }
      ],
      xmId: "",
      zy: "",
      zym: ""
    },
    // 硕士研究生课程建设项目
    formDataForSSYJSKCJSXM: {
      bzjh: "",
      bzjhFj: {
        fileName: "",
        url: ""
      },
      gh: "",
      jsmb: "",
      jsmbFj: {
        fileName: "",
        url: ""
      },
      ktmc: "",
      ktxz: "",
      kyqk: "",
      kyqkFj: {
        fileName: "",
        url: ""
      },
      ryky: "",
      rykyFj: {
        fileName: "",
        url: ""
      },
      xmId: "",
      xwxz: "",
      zy: "",
      zym: "",
      zynr: "",
      zynrFj: {
        fileName: "",
        url: ""
      },
      zyts: "",
      zytsFj: {
        fileName: "",
        url: ""
      }
    },
    // 硕士研究生课程建设项目结题
    formDataIsConclusionForSSYJSKCJSXM: {
      jfsyqkFj: {
        fileName: "",
        url: ""
      },
      jfsyqkNr: "",
      lcid: "",
      qdcgFj: {
        fileName: "",
        url: ""
      },
      qdcgNr: "",
      sfxfFj: {
        fileName: "",
        url: ""
      },
      sfxfNr: "",
      sqId: "",
      xmId: ""
    }
  },
  getters: {
    // 学生
    // 田野调查基金项目
    getFormDataForTYDCJJXM(state) {
      return state.formDataForTYDCJJXM
    },
    // 校级研究生科研项目
    getFormDataForXJYJSKYXM(state) {
      return state.formDataForXJYJSKYXM
    },
    // 知行浙江社会调研项目
    getFormDataForZXZJSHDYXM(state) {
      return state.formDataForZXZJSHDYXM
    },
    // 田野调查基金项目结题
    getFormDataIsConclusionForTYDCJJXM(state) {
      return state.formDataIsConclusionForTYDCJJXM
    },
    // 校级研究生科研项目结题
    getFormDataIsConclusionForXJYJSKYXM(state) {
      return state.formDataIsConclusionForXJYJSKYXM
    },
    // 教师
    // 课程案例库建设项目
    getFormDataForKCALKJSXM(state) {
      return state.formDataForKCALKJSXM
    },
    // 博士研究生课程建设项目
    getFormDataForBSYJSKCJSXM(state) {
      return state.formDataForBSYJSKCJSXM
    },
    // 硕士研究生课程建设项目
    getFormDataForSSYJSKCJSXM(state) {
      return state.formDataForSSYJSKCJSXM
    },
    // 硕士研究生课程建设项目结题
    getFormDataIsConclusionForSSYJSKCJSXM(state) {
      return state.formDataIsConclusionForSSYJSKCJSXM
    }
  },
  mutations: {
    // 学生
    // 田野调查基金项目
    updateFormDataForTYDCJJXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataForTYDCJJXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'xmzxx') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataForTYDCJJXM[key] = obj[key]
      })
    },
    clearFormDataForTYDCJJXM(state) {
      state.formDataForTYDCJJXM = {
        // 学号
        xh: "",
        // 经费使用计划-备注说明
        jfBz: "",
        // 经费使用计划-交通费
        jfJt: "",
        // 经费使用计划-其他费用
        jfQt: "",
        // 经费使用计划-总计申请经费
        jfZj: "",
        // 经费使用计划-资料费
        jfZl: "",
        // 经费使用计划-住宿费
        jfZs: "",
        // 简介附件
        jjfj: { url: "", fileName: "" },
        // 课题名称
        ktmc: "",
        // 申报活动主要内容简介
        nrjj: "",
        // 项目设计论证-预期成果
        sjlzCg: "",
        // 项目设计论证-实施方案
        sjlzFa: "",
        // 设计论证附件
        sjlzFj: { url: "", fileName: "" },
        // 项目设计论证-选题
        sjlzXt: "",
        // 项目ID
        xmId: "",
        // 项目可行性分析附件
        xmfxFj: { url: "", fileName: "" },
        // 项目可行性分析-该项目可能存在的风险和对策
        xmfxFx: "",
        // 项目可行性分析-项目具备的基础和优势
        xmfxJc: "",
        // 项目组信息
        xmzxx: [
          {
            // 院系所名称
            collegeName: "",
            // 院系所号
            collegeNum: "",
            // 专业名称
            majorName: "",
            // 专业代码
            majorNum: "",
            // 姓名
            name: "",
            // 联系电话
            phone: "",
            // 性别
            sex: "",
            // 学号
            studentNumber: "",
            // 承担任务
            tasks: "",
            // 培养层次
            trainingLevel: "",
            // 培养层次
            trainingLevelNum: ""
          }
        ],
        // 预计完成时间
        yjwcsj: "",
        // 指导教师通讯地址
        zdjsdz: "",
        // 指导教师工号
        zdjsgh: ""
      }
    },
    // 校级研究生科研项目
    updateFormDataForXJYJSKYXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataForXJYJSKYXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'xmzxx') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataForXJYJSKYXM[key] = obj[key]
      })
    },
    clearFormDataForXJYJSKYXM(state) {
      state.formDataForXJYJSKYXM = {
        // 备注说明
        jfBz: "",
        // 经费使用计划-调研差旅费
        jfCl: 0,
        // 经费使用计划-资料费
        jfJsjsy: 0,
        // 经费使用计划-其他费用
        jfQa: 0,
        // 经费使用计划-文印费
        jfWy: 0,
        // 经费使用计划-总计费用
        jfZj: 0,
        // 经费使用计划-资料费
        jfZl: 0,
        // 论文字数
        lwzs: 0,
        sjlzFj: { url: "", fileName: "" },
        // 项目设计论证-项目研究的基本思路、主要内容、理论与实际意义、创新之处和预期成果
        sjlzNr: "",
        // 学号
        xh: "",
        xmId: 0,
        // 项目名称
        xmmc: "",
        xmzxx: [
          {
            // 出生年月
            birthDate: "",
            // 院系所名称
            collegeName: "",
            // 院系所号
            collegeNum: "",
            // 所在年级
            grade: "",
            // 专业名称
            majorName: "",
            // 专业代码
            majorNum: "",
            // 姓名
            name: "",
            // 联系电话
            phone: "",
            // 性别
            sex: "",
            // 学号
            studentNumber: "",
            // 承担任务
            tasks: "",
            // 培养层次
            trainingLevel: "",
            // 培养层次
            trainingLevelNum: ""
          }
        ],
        // 预期成果 1.论文 2专著 3译著 4研究报告 5工具书 6电脑软件
        yqcg: [],
        // 指导教师工号
        zdjsgh: "",
        // 主题词
        ztc: ""
      }
    },
    // 知行浙江社会调研项目
    updateFormDataForZXZJSHDYXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataForZXZJSHDYXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'xmzxx') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataForZXZJSHDYXM[key] = obj[key]
      })
    },
    clearFormDataForZXZJSHDYXM(state) {
      state.formDataForZXZJSHDYXM = {
        jfBz: "",
        jfJt: 0,
        jfQt: 0,
        jfZj: 0,
        jfZl: 0,
        jfZs: 0,
        jjfj: {
          fileName: "",
          url: ""
        },
        ktmc: "",
        nrjj: "",
        sjlzFj: {
          fileName: "",
          url: ""
        },
        sjlzJz: "",
        sjlzNr: "",
        sjlzXt: "",
        wcxmFj: {
          fileName: "",
          url: ""
        },
        wcxmTj: "",
        xh: "",
        xmId: "",
        xmzxx: [
          {
            birthDate: "",
            collegeName: "",
            collegeNum: "",
            grade: "",
            majorName: "",
            majorNum: "",
            name: "",
            phone: "",
            sex: "",
            studentNumber: "",
            tasks: "",
            trainingLevel: "",
            trainingLevelNum: ""
          }
        ],
        yjwcsj: "",
        zdjsdz: "",
        zdjsgh: ""
      }
    },
    // 田野调查基金项目结题
    updateFormDataIsConclusionForTYDCJJXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataIsConclusionForTYDCJJXM).forEach(key => {
        console.log(obj)
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'cgfb') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataIsConclusionForTYDCJJXM[key] = obj[key]
      })
    },
    clearFormDataIsConclusionForTYDCJJXM(state) {
      state.formDataIsConclusionForTYDCJJXM = {
        cgfb: [
          {
            feedback: "",
            journalNumber: "",
            paperName: "",
            publishTime: "",
            remark: "",
            sort: ""
          }
        ],
        dcgzzjFj: {
          fileName: "",
          url: ""
        },
        dcgzzjNr: "",
        lcid: "",
        xmId: "",
        xmssqkzjFj: {
          fileName: "",
          url: ""
        },
        xmssqkzjNr: ""
      }
    },
    // 校级研究生科研项目结题
    updateFormDataIsConclusionForXJYJSKYXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataIsConclusionForXJYJSKYXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'cgfb') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataIsConclusionForXJYJSKYXM[key] = obj[key]
      })
    },
    clearFormDataIsConclusionForXJYJSKYXM(state) {
      state.formDataIsConclusionForXJYJSKYXM = {
        cgfb: [
          {
            feedback: "",
            journalNumber: "",
            paperName: "",
            publishTime: "",
            remark: "",
            sort: ""
          }
        ],
        yjgcgzFj: {
          fileName: "",
          url: ""
        },
        yjgcgzNr: "",
        lcid: "",
        xmId: "",
        yjgzzjFj: {
          fileName: "",
          url: ""
        },
        yjgzzjNr: ""
      }
    },
    // 教师
    // 课程案例库建设项目
    updateFormDataForKCALKJSXM(state, obj) {
      console.log("更新数据")
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataForKCALKJSXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'cyxx') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataForKCALKJSXM[key] = obj[key]
      })
    },
    clearFormDataForKCALKJSXM(state) {
      state.formDataForKCALKJSXM = {
        almc: "",
        cyjxcg: "",
        cyjxcgFj: {
          fileName: "",
          url: ""
        },
        cyxx: [
          {
            dzyx: "",
            ssyxh: "",
            ssyxmc: "",
            yddh: "",
            yjfx: "",
            zc: "",
            zdjsgh: "",
            zdjsxm: "",
            zw: "",
            zy: "",
            zym: "",
            responsible: ""
          }
        ],
        gh: "",
        jscg: "",
        jscgFj: {
          fileName: "",
          url: ""
        },
        jsfa: "",
        jsfaFj: {
          fileName: "",
          url: ""
        },
        jssj: "",
        jxcg: "",
        jxcgFj: {
          fileName: "",
          url: ""
        },
        kcdm: "",
        kcmc: "",
        kssj: "",
        lxyj: "",
        lxyjFj: {
          fileName: "",
          url: ""
        },
        xmId: "",
        zy: "",
        zym: ""
      }
    },
    // 博士研究生课程建设项目
    updateFormDataForBSYJSKCJSXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataForBSYJSKCJSXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'cjzxx' || key === 'rjkcxx') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataForBSYJSKCJSXM[key] = obj[key]
      })
    },
    clearFormDataForBSYJSKCJSXM(state) {
      state.formDataForBSYJSKCJSXM = {
        cjzxx: [
          {
            dzyx: "",
            ssyxh: "",
            ssyxmc: "",
            yddh: "",
            yjfx: "",
            zc: "",
            zdjsgh: "",
            zdjsxm: "",
            zw: ""
          }
        ],
        gh: "",
        jsfa: "",
        jsfaFj: {
          fileName: "",
          url: ""
        },
        jsmb: "",
        jsmbFj: {
          fileName: "",
          url: ""
        },
        kcmc: "",
        kssj: "",
        kcxz: "",
        lxyj: "",
        lxyjFj: {
          fileName: "",
          url: ""
        },
        rjkcxx: [
          {
            kch: "",
            kcmc: "",
            teacher: {
              gh: "",
              id: "",
              jsxm: "",
              sksjList: [
                {
                  id: "",
                  kj: "",
                  pksjid: "",
                  sfmz: "",
                  skdd: "",
                  xq: "",
                  zc: ""
                }
              ]
            }
          }
        ],
        xmId: "",
        zy: "",
        zym: ""
      }
    },
    // 硕士研究生课程建设项目
    updateFormDataForSSYJSKCJSXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataForSSYJSKCJSXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        if (key === 'xmzxx') {
          // 如果不是数组
          if (!Array.isArray(obj[key])) {
            return
            // 长度为0
          } else if (obj[key].length === 0) {
            return
          }
        }
        state.formDataForSSYJSKCJSXM[key] = obj[key]
      })
    },
    clearFormDataForSSYJSKCJSXM(state) {
      state.formDataForSSYJSKCJSXM = {
        bzjh: "",
        bzjhFj: {
          fileName: "",
          url: ""
        },
        gh: "",
        jsmb: "",
        jsmbFj: {
          fileName: "",
          url: ""
        },
        ktmc: "",
        ktxz: "",
        kyqk: "",
        kyqkFj: {
          fileName: "",
          url: ""
        },
        ryky: "",
        rykyFj: {
          fileName: "",
          url: ""
        },
        xmId: "",
        xwxz: "",
        zy: "",
        zym: "",
        zynr: "",
        zynrFj: {
          fileName: "",
          url: ""
        },
        zyts: "",
        zytsFj: {
          fileName: "",
          url: ""
        }
      }
    },
    // 硕士研究生课程建设项目结题
    updateFormDataIsConclusionForSSYJSKCJSXM(state, obj) {
      // 遍历目标对象，根据目标对象中的字段赋值
      Object.keys(state.formDataIsConclusionForSSYJSKCJSXM).forEach(key => {
        // 如果传入对象中没有对应字段跳过赋值
        if (obj[key] === undefined || obj[key] === null) {
          return
        }
        state.formDataIsConclusionForSSYJSKCJSXM[key] = obj[key]
      })
    },
    clearFormDataIsConclusionForSSYJSKCJSXM(state) {
      state.formDataIsConclusionForSSYJSKCJSXM = {
        jfsyqkFj: {
          fileName: "",
          url: ""
        },
        jfsyqkNr: "",
        lcid: "",
        qdcgFj: {
          fileName: "",
          url: ""
        },
        qdcgNr: "",
        sfxfFj: {
          fileName: "",
          url: ""
        },
        sfxfNr: "",
        sqId: "",
        xmId: ""
      }
    },
  },
  actions: {

  },
  namespaced: true
}
