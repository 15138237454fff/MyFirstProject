import Vue from 'vue'
import Router from 'vue-router'
// import componentrouter from './router'
import index from '@/page/index'
import error from '@/page/404'
import login from '@/page/login' // 财经大学登录
import forgetPassword from '@/page/forgetPassword' // 财经大学登录
import logincode from '@/page/logincode' // 财经大学登录
import first from '@/page/first' // 首页
// schoolBasic
import schoolBasic from '@/page/childrenPage/SystemManagement/schoolBasic' // 组织机构管理（系统管理）
import institutional from '@/page/childrenPage/SystemManagement/institutional' // 组织机构管理（系统管理）
import buildingInformation from '@/page/childrenPage/SystemManagement/buildingInformation' // 楼栋信息管理（系统管理）
import moduleManagement from '@/page/childrenPage/SystemManagement/moduleManagement' // 功能模块管理（系统管理）
import notification from '@/page/childrenPage/SystemManagement/notification' // 通知公告管理（系统管理）
import roleManagement from '@/page/childrenPage/SystemManagement/roleManagement' // 角色权限管理（系统管理）
import schoolManagement from '@/page/childrenPage/SystemManagement/schoolManagement' // 校区信息管理（系统管理）
import staffManagement from '@/page/childrenPage/SystemManagement/staffManagement' // 教职工信息管理（系统管理）
import userManagement from '@/page/childrenPage/SystemManagement/userManagement' // 用户信息管理（系统管理）
import classInformation from '@/page/childrenPage/TrainManagement/BasicData/classInformation' // 学院信息管理（培养管理-基础数据维护）
import teacherInformation from '@/page/childrenPage/TrainManagement/BasicData/teacherInformation' // 教室信息维护（培养管理-基础数据维护）
import collegeInformation from '@/page/childrenPage/TrainManagement/BasicData/collegeInformation' // 学院信息管理（培养管理-基础数据维护）
import courseInformation from '@/page/childrenPage/TrainManagement/BasicData/courseInformation' // 课程信息维护（培养管理-基础数据维护）
import degreeProgram from '@/page/childrenPage/TrainManagement/BasicData/degreeProgram' // 学位点信息维护（培养管理-基础数据维护）
import majorInformation from '@/page/childrenPage/TrainManagement/BasicData/majorInformation' // 专业信息管理（培养管理-基础数据维护）
import preferences from '@/page/childrenPage/TrainManagement/BasicData/preferences' // 基础参数设置（培养管理-基础数据维护）
import tutorInformation from '@/page/childrenPage/TrainManagement/BasicData/tutorInformation' // 导师信息维护（培养管理-基础数据维护）
import classStop from '@/page/childrenPage/TrainManagement/classManagement/classStop' // 课程停开处理（培养管理-课程开课管理）
import formulate from '@/page/childrenPage/TrainManagement/classManagement/formulate' // 制定开课方案（培养管理-课程开课管理）
import searchClass from '@/page/childrenPage/TrainManagement/classManagement/searchClass' // 课表查询（培养管理-课程开课管理）
import teachClass from '@/page/childrenPage/TrainManagement/classManagement/teachClass' // 教师调课审核（培养管理-课程开课管理）
import oldRegister from '@/page/childrenPage/TrainManagement/StudentInformation/oldRegister' // 老生批量注册（培养管理-学生信息管理）
import rebirthData from '@/page/childrenPage/TrainManagement/StudentInformation/rebirthData' // 新生数据维护（培养管理-新生数据维护）
import rollAudit from '@/page/childrenPage/TrainManagement/StudentInformation/rollAudit' // 学生信息审核（培养管理-新生数据维护）
import studentInformation from '@/page/childrenPage/TrainManagement/StudentInformation/studentInformation' // 学生信息管理（培养管理-新生数据维护）
import makePlan from '@/page/childrenPage/TrainManagement/ProjectManagement/makePlan' // 制定培养方案（培养管理-培养方案管理）
import projectAduit from '@/page/childrenPage/TrainManagement/ProjectManagement/projectAduit' // 培养方案审核（培养管理-培养方案管理）
import projectBank from '@/page/childrenPage/TrainManagement/ProjectManagement/projectBank' // 培养方案库（培养管理-培养方案管理）
import byElection from '@/page/childrenPage/TrainManagement/studentManage/byElection' // 补选(退选)处理（培养管理-学生培养计划）
import studentAudit from '@/page/childrenPage/TrainManagement/studentManage/studentAudit' // 学生课程审核（培养管理-学生培养计划）
import trainAudit from '@/page/childrenPage/TrainManagement/studentManage/trainAudit' // 培养计划审核（培养管理-学生培养计划）
import trainSearch from '@/page/childrenPage/TrainManagement/studentManage/trainSearch' // 培养计划查询（培养管理-学生培养计划）
import studentmessage from '@/page/childrenPage/yingxin/newstudent' // 新生基本信息（迎新管理）
import Financialpayment from '@/page/childrenPage/yingxin/Financialpayment' // 财务缴费数据（迎新管理）
import dormitory from '@/page/childrenPage/yingxin/dormitory' // 宿舍分配数据（迎新管理）
import reportedinformation from '@/page/childrenPage/yingxin/reportedinformation' // 报道信息采集（迎新管理）
import guidelines from '@/page/childrenPage/yingxin/guidelines' // 报道须知（迎新管理）
import testpaper from '@/page/childrenPage/yingxin/testpaper' // 测试试卷管理（迎新管理）
import schoolListimg from '@/page/childrenPage/yingxin/schoolListimg' // 校园风光 （迎新管理）
import achievementsrecorded from '@/page/childrenPage/TrainManagement/student_peiyang/achievementsrecorded' // 成绩录入审核(培养模块)
import rebuildstudents from '@/page/childrenPage/TrainManagement/student_peiyang/rebuildstudents' // 重修学生名单(培养模块)
import resultssummary from '@/page/childrenPage/TrainManagement/student_peiyang/resultssummary' // 学生成绩汇总(培养模块)
import assessmentquestionnaire from '@/page/childrenPage/TrainManagement/student_peiyang/assessmentquestionnaire' // 评教问卷管理(培养模块)
import evaluationresults from '@/page/childrenPage/TrainManagement/student_peiyang/evaluationresults' // 评教结果汇总(培养模块)
import Graduatemanagement from '@/page/childrenPage/TrainManagement/student_peiyang/Graduatemanagement' // 毕业生管理(培养模块)
import Registrationsix from '@/page/childrenPage/TrainManagement/student_peiyang/Registrationsix' // 四六级报名管理(培养模块)
import Teachingworkload from '@/page/childrenPage/TrainManagement/student_peiyang/Teachingworkload' // 教学工作量管理(培养模块)
import evaluationresultslist from '@/page/childrenPage/TrainManagement/student_peiyang/evaluationresultslist' // 评教结果汇总详情(培养模块)
import jccs from '@/page/childrenPage/yingxin/jccs' // (迎新)
import addnotificlist from '@/page/childrenPage/yingxin/addnotificlist' // 报道信息采集
import newstudentlive from '@/page/childrenPage/yingxin/newstudentlive' // 报道信息采集
import totalallstudent from '@/page/childrenPage/yingxin/totalallstudent' // 迎新实习统计(迎新)
import moralitytest from '@/page/childrenPage/yingxin/moralitytest' // 道德测试统计(迎新)
import testpaperlist from '@/page/childrenPage/yingxin/testpaperlist' // 道德测试统计详情(迎新)
import learing_jccs from '@/page/childrenPage/learning/learing_jccs' // 基础参数设置(学术)
import learing_xxcg from '@/page/childrenPage/learning/learing_xxcg' // 学术成果审核(学术)
import learing_xxhz from '@/page/childrenPage/learning/learing_xxhz' // 学术成果汇总(学术)
import Basicparameters from '@/page/childrenPage/degree/Basicparameters' // 基础参数设置(学位)
import qualification from '@/page/childrenPage/degree/qualification' // 学位资格审核(学位)
import checkdisser from '@/page/childrenPage/degree/checkdisser' // 学位论文查重(学位)
import dissertation from '@/page/childrenPage/degree/dissertation' // 学位论文送审(学位)
import graduation from '@/page/childrenPage/degree/graduation' // 毕业答辩管理(学位)
import lwzgcd from '@/page/childrenPage/degree/lwzgcd' // 论文终稿存档(学位)
import xwzgsq from '@/page/childrenPage/degree/xwzgsq' // 学位资格授权(学位)
import yxlwps from '@/page/childrenPage/degree/yxlwps' // 优秀论文评审(学位)
import xwlwcj from '@/page/childrenPage/degree/xwlwcj' // 学位论文抽检(学位)
import xwzssy from '@/page/childrenPage/degree/xwzssy' // 学位证书授予(学位)
// 教育建设项目
// import xxfb from '@/page/childrenPage/educationCreat/xxfb' // 项目信息发布
// import sbsh from '@/page/childrenPage/educationCreat/sbsh' // 项目信息发布
// import lxgl from '@/page/childrenPage/educationCreat/lxgl' // 项目信息发布
// 招生
import enrolBasicParams from '@/page/childrenPage/enrol/basicParams'
// 硕士招生
import specialReport from '@/page/childrenPage/enrol/master/specialReport/specialReport'
import specialAduit from '@/page/childrenPage/enrol/master/specialAduit/specialAduit'
import examManage from '@/page/childrenPage/enrol/master/examManage/examManage'
import stuInfoManage from '@/page/childrenPage/enrol/master/stuInfoManage/stuInfoManage'
import pointInfoManage from '@/page/childrenPage/enrol/master/pointInfoManage/pointInfoManage'
import firstScoreInput from '@/page/childrenPage/enrol/master/firstScoreInput/firstScoreInput'
import finalFirstScore from '@/page/childrenPage/enrol/master/finalFirstScore/finalFirstScore'
import reeaxmReport from '@/page/childrenPage/enrol/master/reeaxmReport/reeaxmReport'
import reeaxmSummary from '@/page/childrenPage/enrol/master/reeaxmSummary/reeaxmSummary'
Vue.use(Router)
// import reeaxmSummary from "@/page/childrenPage/enrol/master/reeaxmSummary/reeaxmSummary"
import perFormance from '@/page/childrenPage/enrol/master/Comprehensive/perFormance' // 综合成绩管理
import alias2 from '@/page/childrenPage/enrol/master/Comprehensive/components/alias2'
import addmissProposed from '@/page/childrenPage/enrol/master/admissionList/addmissProposed' // 录取名单管理
import adjustTable from '@/page/childrenPage/enrol/master/adjustRaw/adjustTable' // 调剂生管理
import adjustxq from '@/page/childrenPage/enrol/master/adjustRaw/componments/adjustxq' // 调剂生管理
import transferStudentsList from '@/page/childrenPage/enrol/master/transferStudents/transferStudentsList' // 调剂生复试成绩录入
import finalgrade from '@/page/childrenPage/enrol/master/finalGrades/finalgrade' // 调剂生最终成绩
import enrollment from '@/page/childrenPage/enrol/master/enrollment/enrollment' // 调剂生录取管理
import finaladd from '@/page/childrenPage/enrol/master/finalAdmission/finaladd' // 最终录取名单
import interviewTable from '@/page/childrenPage/enrol/master/interview/interviewTable' // 复试名单管理
import resultEntryList from '@/page/childrenPage/enrol/master/resultEntry/resultEntryList' // 复试名单管理
import scheduling from '@/page/childrenPage/TrainManagement/classManagement/formulate/scheduling'
import limit from '@/page/childrenPage/enrol/master/enrollmentLimit/limit' // 最终录取名单
import reviewof from '@/page/childrenPage/enrol/master/enrollmentReview/reviewof' // 最终录取名单
import reportQuota from '@/page/childrenPage/enrol/master/report/reportQuota' // 最终录取名单

Vue.use(Router)
const list = false
export default new Router({
  routes: [{
    path: '*',
    name: 'error',
    component: error
  },
  {
    path: '/forgetPassword',
    name: 'forgetPassword',
    component: forgetPassword
  },
  {
    path: '/login',
    name: 'login',
    component: login,
    meta: {
      title: '登录页',
      requireAuth: true
    }
  },
  {
    path: '/',
    name: 'logincode',
    component: logincode,
    meta: {
      title: '登录页',
      requireAuth: true
    }
  },
  {
    path: '/first',
    name: 'index',
    component: index,
    redirect: '/first',
    meta: {
      title: '主页',
      requireAuth: true
    },
    children: [{
      path: '/first',
      name: 'first',
      component: first,
      meta: {
        title: '首页',
        requireAuth: true
      }
    },
    {
      path: '/byElection',
      name: 'byElection',
      component: byElection,
      meta: {
        title: '补选(退选)处理',
        requireAuth: true
      }
    },
    {
      path: '/studentAudit',
      name: 'studentAudit',
      component: studentAudit,
      meta: {
        title: '学生课程审核',
        requireAuth: true
      }
    },
    {
      path: '/classStop',
      name: 'classStop',
      component: classStop,
      meta: {
        title: '课程停开处理',
        requireAuth: true
      }
    },
    {
      path: '/trainAudit',
      name: 'trainAudit',
      component: trainAudit,
      meta: {
        title: '培养计划审核',
        requireAuth: true
      }
    },
    {
      path: '/trainSearch',
      name: 'trainSearch',
      component: trainSearch,
      meta: {
        title: '培养计划查询',
        requireAuth: true
      }
    },
    {
      path: '/formulate',
      name: 'formulate',
      component: formulate,
      meta: {
        title: '制定开课方案',
        requireAuth: true
      },
      children: [{
        path: `/formulate/scheduling`,
        component: scheduling,
        name: 'formulate/scheduling',
        meta: {
          alias: '/formulate',
          title: '制定开课方案',
          requireAuth: true,
          noCache: true
        }
      }]
    },
    {
      path: '/searchClass',
      name: 'searchClass',
      component: searchClass,
      meta: {
        title: '课表查询',
        requireAuth: true
      }
    },
    {
      path: '/teachClass',
      name: 'teachClass',
      component: teachClass,
      meta: {
        title: '教师调课审核',
        requireAuth: true
      }
    },
    {
      path: '/buildingInformation',
      name: 'buildingInformation',
      component: buildingInformation,
      meta: {
        title: '楼栋信息管理',
        requireAuth: true
      }
    },
    {
      path: '/projectBank',
      name: 'projectBank',
      component: projectBank,
      meta: {
        title: '培养方案库',
        requireAuth: true
      }
    },
    {
      path: '/projectAduit',
      name: 'projectAduit',
      component: projectAduit,
      meta: {
        title: '培养方案审核',
        requireAuth: true
      }
    },
    {
      path: '/makePlan',
      name: 'makePlan',
      component: makePlan,
      meta: {
        title: '制定培养方案',
        requireAuth: true
      }
    },
    {
      path: '/studentInformation',
      name: 'studentInformation',
      component: studentInformation,
      meta: {
        title: '学生信息管理',
        requireAuth: true
      }
    },
    {
      path: '/teacherInformation',
      name: 'teacherInformation',
      component: teacherInformation,
      meta: {
        title: '教室信息维护',
        requireAuth: true
      }
    },
    {
      path: '/rollAudit',
      name: 'rollAudit',
      component: rollAudit,
      meta: {
        title: '学生信息审核',
        requireAuth: true
      }
    },
    {
      path: '/rebirthData',
      name: 'rebirthData',
      component: rebirthData,
      meta: {
        title: '新生数据维护',
        requireAuth: true
      }
    },
    {
      path: '/oldRegister',
      name: 'oldRegister',
      component: oldRegister,
      meta: {
        title: '老生批量注册',
        requireAuth: true
      }
    },
    {
      path: '/tutorInformation',
      name: 'tutorInformation',
      component: tutorInformation,
      meta: {
        title: '导师信息维护',
        requireAuth: true
      }
    },
    {
      path: '/preferences',
      name: 'preferences',
      component: preferences,
      meta: {
        title: '基础参数设置',
        requireAuth: true
      }
    },
    {
      path: '/majorInformation',
      name: 'majorInformation',
      component: majorInformation,
      meta: {
        title: '专业信息管理',
        requireAuth: true
      }
    },
    {
      path: '/degreeProgram',
      name: 'degreeProgram',
      component: degreeProgram,
      meta: {
        title: '学位点信息维护',
        requireAuth: true
      }
    },
    {
      path: '/courseInformation',
      name: 'courseInformation',
      component: courseInformation,
      meta: {
        title: '课程信息维护',
        requireAuth: true
      }
    },
    {
      path: '/collegeInformation',
      name: 'collegeInformation',
      component: collegeInformation,
      meta: {
        title: '学院信息管理',
        requireAuth: true
      }
    },
    {
      path: '/classInformation',
      name: 'classInformation',
      component: classInformation,
      meta: {
        title: '班级信息管理',
        requireAuth: true
      }
    },
    {
      path: '/institutional',
      name: 'institutional',
      component: institutional,
      meta: {
        title: '组织机构管理',
        requireAuth: true
      }
    },
    {
      path: '/moduleManagement',
      name: 'moduleManagement',
      component: moduleManagement,
      meta: {
        title: '功能模块管理',
        requireAuth: true
      }
    },
    {
      path: '/notification',
      name: 'notification',
      component: notification,
      meta: {
        title: '通知公告管理',
        requireAuth: true
      }
    },
    {
      path: '/roleManagement',
      name: 'roleManagement',
      component: roleManagement,
      meta: {
        title: '角色权限管理',
        requireAuth: true
      }
    },
    {
      path: '/schoolBasic',
      name: 'schoolBasic',
      component: schoolBasic,
      meta: {
        title: '学校参数设置',
        requireAuth: true
      }
    },
    {
      path: '/schoolManagement',
      name: 'schoolManagement',
      component: schoolManagement,
      meta: {
        title: '校区信息管理',
        requireAuth: true
      }
    },
    {
      path: '/staffManagement',
      name: 'staffManagement',
      component: staffManagement,
      meta: {
        title: '教职工信息管理',
        requireAuth: true
      }
    },
    {
      path: '/userManagement',
      name: 'userManagement',
      component: userManagement,
      meta: {
        title: '用户信息管理',
        requireAuth: true
      }
    },
    // 迎新模块
    {
      path: '/newstudent',
      name: 'studentmessage',
      component: studentmessage,
      meta: {
        title: '新生基本信息',
        requireAuth: true
      }
    },
    {
      path: '/Financialpayment',
      name: 'Financialpayment',
      component: Financialpayment,
      meta: {
        title: '财务缴费数据',
        requireAuth: true
      }
    },
    {
      path: '/dormitory',
      name: 'dormitory',
      component: dormitory,
      meta: {
        title: '宿舍分配数据',
        requireAuth: true
      }
    },
    {
      path: '/reportedinformation',
      name: 'reportedinformation',
      component: reportedinformation,
      meta: {
        title: '报道信息采集',
        requireAuth: true
      }
    },
    {
      path: '/guidelines',
      name: 'guidelines',
      component: guidelines,
      meta: {
        title: '报道须知管理',
        requireAuth: true
      }
    },
    {
      path: '/schoolListimg',
      name: 'schoolListimg',
      component: schoolListimg,
      meta: {
        title: '校园风光',
        requireAuth: true
      }
    },
    {
      path: '/testpaper',
      name: 'testpaper',
      component: testpaper,
      meta: {
        title: '测试试卷管理',
        requireAuth: true
      }
    },
    {
      path: '/achievementsrecorded',
      name: 'achievementsrecorded',
      component: achievementsrecorded,
      meta: {
        title: '成绩录入审核',
        requireAuth: true
      }
    },
    {
      path: '/rebuildstudents',
      name: 'rebuildstudents',
      component: rebuildstudents,
      meta: {
        title: '重修学生名单',
        requireAuth: true
      }
    },
    {
      path: '/resultssummary',
      name: 'resultssummary',
      component: resultssummary,
      meta: {
        title: '学生成绩汇总',
        requireAuth: true
      }
    },
    {
      path: '/assessmentquestionnaire',
      name: 'assessmentquestionnaire',
      component: assessmentquestionnaire,
      meta: {
        title: '评教问卷管理',
        requireAuth: true
      }
    },
    {
      path: '/evaluationresults',
      name: 'evaluationresults',
      component: evaluationresults,
      meta: {
        title: '评教结果汇总',
        requireAuth: true,
      },
      children: [{
        path: `/evaluationresultslist`,
        component: evaluationresultslist,
        name: 'evaluationresultslist',
        meta: {
          alias: '/evaluationresults',
          title: '评教结果汇总',
          requireAuth: true,
          noCache: true
        }
      }]
    },
    {
      path: '/graduateManagement',
      name: 'graduateManagement',
      component: () => import('@/page/childrenPage/TrainManagement/graduateManagement/graduateManagement.vue'),
      meta: {
        title: '毕业生管理',
        requireAuth: true,
      }
    },
    {
      path: '/Registrationsix',
      name: 'Registrationsix',
      component: Registrationsix,
      meta: {
        title: '四六级报名管理',
        requireAuth: true
      }
    },
    {
      path: '/workloadManagement',
      name: 'workloadManagement',
      component: () => import('../page/childrenPage/TrainManagement/workloadManagement/workloadManagement.vue'),
      meta: {
        title: '教学工作量管理',
        requireAuth: true
      }
    },
    {
      path: '/activityManagement',
      name: 'activityManagement',
      component: () => import('@/page/childrenPage/TrainManagement/activityManagement/activityManagement.vue'),
      meta: {
        title: '学生活动管理',
        requireAuth: true
      }
    },
    {
      path: '/activityManagementAdd',
      name: 'activityManagementAdd',
      component: () => import('@/page/childrenPage/TrainManagement/activityManagement/activityManagementAdd.vue'),
      meta: {
        title: '学生活动管理',
        requireAuth: true,
        noCache: true,
        alias: "/activityManagement"
      }
    },
    {
      path: '/activityManagementSummary/:id',
      name: 'activityManagementSummary',
      component: () => import('@/page/childrenPage/TrainManagement/activityManagement/activityManagementSummary.vue'),
      meta: {
        title: '学生活动管理',
        requireAuth: true,
        noCache: true,
        alias: "/activityManagement"
      },
      props: true
    },
    {
      path: '/masterNumber',
      name: 'masterNumber',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/masterNumber/masterNumber.vue'),
      meta: {
        title: '硕士研究生分专业学生数',
        requireAuth: true
      }
    },
    {
      path: '/doctoralNumber',
      name: 'doctoralNumber',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/doctoralNumber/doctoralNumber.vue'),
      meta: {
        title: '博士研究生分专业学生数',
        requireAuth: true
      }
    },
    {
      path: '/ageStudents',
      name: 'ageStudents',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/ageStudents/ageStudents.vue'),
      meta: {
        title: '在校生分年龄情况',
        requireAuth: true
      }
    },
    {
      path: '/sourceStudent',
      name: 'sourceStudent',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/sourceStudent/sourceStudent.vue'),
      meta: {
        title: '招生、在校生来源情况',
        requireAuth: true
      }
    },
    {
      path: '/changeStudents',
      name: 'changeStudents',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/changeStudents/changeStudents.vue'),
      meta: {
        title: '学生变动情况',
        requireAuth: true
      }
    },
    {
      path: '/leaveReson',
      name: 'leaveReson',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/leaveReson/leaveReson.vue'),
      meta: {
        title: '学生休学退学主要原因',
        requireAuth: true
      }
    },
    {
      path: '/otherStudents',
      name: 'otherStudents',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/otherStudents/otherStudents.vue'),
      meta: {
        title: '在校生中其他情况',
        requireAuth: true
      }
    },
    {
      path: '/teacherGuidance',
      name: 'teacherGuidance',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/teacherGuidance/teacherGuidance.vue'),
      meta: {
        title: '研究生指导教师情况',
        requireAuth: true
      }
    },
    {
      path: '/fullTimeCounselor',
      name: 'fullTimeCounselor',
      component: () => import('@/page/childrenPage/TrainManagement/advancedReport/fullTimeCounselor/fullTimeCounselor.vue'),
      meta: {
        title: '专职辅导员情况',
        requireAuth: true
      }
    },
    {
      path: '/jccs',
      name: 'jccs',
      component: jccs,
      meta: {
        title: '基础参数设置',
        requireAuth: true
      }
    },
    {
      path: '/addnotificlist',
      name: 'addnotificlist',
      component: addnotificlist,
      meta: {
        title: '报道须知管理',
        requireAuth: true
      }
    },
    {
      path: '/newstudentlive',
      name: 'newstudentlive',
      component: newstudentlive,
      meta: {
        title: '新生报道管理',
        requireAuth: true
      }
    },
    {
      path: '/totalallstudent',
      name: 'totalallstudent',
      component: totalallstudent,
      meta: {
        title: '迎新实时统计',
        requireAuth: true
      }
    },
    {
      path: '/moralitytest',
      name: 'moralitytest',
      component: moralitytest,
      meta: {
        title: '道德测试统计',
        requireAuth: true
      }
    },
    {
      path: '/testpaperlist',
      name: 'testpaperlist',
      component: testpaperlist,
      meta: {
        title: '道德测试详情',
        requireAuth: true
      }
    },
    {
      path: '/learing_jccs',
      name: 'learing_jccs',
      component: learing_jccs,
      meta: {
        title: '基础参数设置',
        requireAuth: true
      }
    },
    {
      path: '/learing_xxcg',
      name: 'learing_xxcg',
      component: learing_xxcg,
      meta: {
        title: '学术成果审核',
        requireAuth: true,
        // alias: "/learing_xxcg?id=2"
      }
    },
    {
      path: '/learing_xxhz',
      name: 'learing_xxhz',
      component: learing_xxhz,
      meta: {
        title: '学术成果汇总',
        requireAuth: true
      }
    },
    {
      path: '/Basicparameters',
      name: 'Basicparameters',
      component: Basicparameters,
      meta: {
        title: '预答辩管理',
        requireAuth: true
      }
    },
    {
      path: '/qualification',
      name: 'qualification',
      component: qualification,
      meta: {
        title: '学位论文审核',
        requireAuth: true
      }
    },
    {
      path: '/checkdisser',
      name: 'checkdisser',
      component: checkdisser,
      meta: {
        title: '学位论文查重',
        requireAuth: true
      }
    },
    {
      path: '/dissertation',
      name: 'dissertation',
      component: dissertation,
      meta: {
        title: '学位论文送审',
        requireAuth: true
      }
    },

    {
      path: '/graduation',
      name: 'graduation',
      component: graduation,
      meta: {
        title: '毕业答辩管理',
        requireAuth: true
      }
    },
    {
      path: '/lwzgcd',
      name: 'lwzgcd',
      component: lwzgcd,
      meta: {
        title: '论文终稿存档',
        requireAuth: true
      }
    },
    {
      path: '/xwzssy',
      name: 'xwzssy',
      component: xwzssy,
      meta: {
        title: '学位证书授予',
        requireAuth: true
      }
    },
    {
      path: '/xwzgsq',
      name: 'xwzgsq',
      component: xwzgsq,
      meta: {
        title: '送审单位管理',
        requireAuth: true
      }
    },
    {
      path: '/yxlwps',
      name: 'yxlwps',
      component: yxlwps,
      meta: {
        title: '送审账号管理',
        requireAuth: true
      }
    },
    {
      path: '/xwlwcj',
      name: 'xwlwcj',
      component: xwlwcj,
      meta: {
        title: '学位论文抽检',
        requireAuth: true
      }
    },
    {
      path: '/projectPublish',
      name: 'projectPublish',
      component: () => import("../page/childrenPage/educationCreat/projectPublish/projectPublish.vue"),
      meta: {
        title: '项目信息发布',
        requireAuth: true
      }
    },
    {
      path: '/projectPublishAdd',
      name: 'projectPublishAdd',
      component: () => import("../page/childrenPage/educationCreat/projectPublish/projectPublishAdd.vue"),
      meta: {
        title: '项目信息发布',
        requireAuth: true,
        alias: "/projectPublish",
        noCache: true
      }
    },
    {
      path: '/projectPublishDetail/:id',
      name: 'projectPublishDetail',
      component: () => import("../page/childrenPage/educationCreat/projectPublish/projectPublishDetail.vue"),
      meta: {
        title: '项目信息发布',
        alias: "/projectPublish",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/projectPublishModify/:id',
      name: 'projectPublishModify',
      component: () => import("../page/childrenPage/educationCreat/projectPublish/projectPublishModify.vue"),
      meta: {
        title: '项目信息发布',
        alias: "/projectPublish",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/jiansheProjectAduit',
      name: 'jiansheProjectAduit',
      component: () => import('../page/childrenPage/educationCreat/projectAduit/jiansheProjectAduit.vue'),
      meta: {
        title: "项目申报审核"
      }
    },
    {
      path: '/projectAduitAdd/:type/:id/:taskId/:transmit/:collegeNum',
      name: 'projectAduitAdd',
      component: () => import('../page/childrenPage/educationCreat/projectAduit/projectAduitAdd.vue'),
      meta: {
        title: "项目申报审核",
        alias: "/jiansheProjectAduit",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/projectAduitDetail/:type/:id',
      name: 'projectAduitDetail',
      component: () => import('../page/childrenPage/educationCreat/projectAduit/projectAduitDetail.vue'),
      meta: {
        title: "项目申报审核",
        alias: "/jiansheProjectAduit",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/projectApproval',
      name: 'projectApproval',
      component: () => import("../page/childrenPage/educationCreat/projectApproval/projectApproval.vue"),
      meta: {
        title: '项目立项管理',
        requireAuth: true
      }
    },
    {
      path: '/projectApprovalProjectDetailByTeacher/:type/:id',
      name: 'projectApprovalProjectDetailByTeacher',
      component: () => import("../page/childrenPage/educationCreat/projectApproval/projectApprovalProjectDetailByTeacher.vue"),
      meta: {
        title: '项目立项管理',
        alias: "/projectApproval",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/conclusionAduit',
      name: 'conclusionAduit',
      component: () => import("../page/childrenPage/educationCreat/conclusionAduit/conclusionAduit.vue"),
      meta: {
        title: '项目结题审核',
        requireAuth: true
      }
    },
    {
      path: '/conclusionAduitProjectDetailByTeacher/:type/:id',
      name: 'conclusionAduitProjectDetailByTeacher',
      component: () => import('../page/childrenPage/educationCreat/conclusionAduit/conclusionAduitProjectDetailByTeacher.vue'),
      meta: {
        title: "项目结题审核",
        alias: "/conclusionAduit",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/conclusionAduitAdd/:type/:id/:taskId/:executionId/:transmit/:collegeNum',
      name: 'conclusionAduitAdd',
      component: () => import('../page/childrenPage/educationCreat/conclusionAduit/conclusionAduitAdd.vue'),
      meta: {
        title: "项目结题审核",
        alias: "/conclusionAduit",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/conclusionAduitDetail/:type/:id/:executionId',
      name: 'conclusionAduitDetail',
      component: () => import('../page/childrenPage/educationCreat/conclusionAduit/conclusionAduitDetail.vue'),
      meta: {
        title: "项目结题审核",
        alias: "/conclusionAduit",
        requireAuth: true,
        noCache: true
      },
      props: true
    },
    {
      path: '/projectInfoSummary',
      name: 'projectInfoSummary',
      component: () => import("../page/childrenPage/educationCreat/projectInfoSummary/projectInfoSummary.vue"),
      meta: {
        title: '项目信息汇总',
        requireAuth: true
      }
    },
    {
      path: '/projectInfoSummaryProjectDetailByTeacher/:type/:id',
      name: 'projectInfoSummaryProjectDetailByTeacher',
      component: () => import('../page/childrenPage/educationCreat/projectInfoSummary/projectInfoSummaryProjectDetailByTeacher.vue'),
      meta: {
        title: "项目信息汇总",
        alias: "/projectInfoSummary",
        noCache: true
      },
      props: true
    },
    {
      path: '/projectInfoSummaryDetail/:type/:id',
      name: 'projectInfoSummaryDetail',
      component: () => import('../page/childrenPage/educationCreat/projectInfoSummary/projectInfoSummaryDetail.vue'),
      meta: {
        title: "项目信息汇总",
        alias: "/projectInfoSummary",
        noCache: true
      },
      props: true
    },
    // 招生部分--基础参数
    {
      path: '/enrolBasicParams',
      name: 'enrolBasicParams',
      component: enrolBasicParams,
      meta: {
        title: '基础参数设置',
        requireAuth: true
      }
    },
    {
      path: '/specialReport',
      name: 'specialReport',
      component: specialReport,
      meta: {
        title: '专业目录上报',
        requireAuth: true,
        alias: '/specialReport?id=2'
      }
    },
    {
      path: '/submission',
      name: 'submission',
      component: () => import('@/page/childrenPage/enrol/enrolment/specialReport/submission.vue'),
      meta: {
        title: '专业目录上报',
        requireAuth: true,
        alias: '/submission?id=2'
      }
    },
    {
      path: '/specialAduit',
      name: 'specialAduit',
      component: specialAduit,
      meta: {
        title: '专业目录审核',
        requireAuth: true,
        alias: '/specialAduit?id=2'
      },
    },
    {
      path: '/catalogAduit',
      name: 'catalogAduit',
      component: () => import('@/page/childrenPage/enrol/enrolment/specialAduit/catalogAduit.vue'),
      meta: {
        title: '专业目录审核',
        requireAuth: true,
        alias: '/catalogAduit?id=2'
      },
    },
    {
      path: '/examManage',
      name: 'examManage',
      component: examManage,
      meta: {
        title: '考试科目管理',
        requireAuth: true,
        alias: '/examManage?id=2'
      },
    },
    {
      path: '/Examination',
      name: 'Examination',
      component: () => import('@/page/childrenPage/enrol/enrolment/examManage/Examination.vue'),
      meta: {
        title: '考试科目管理',
        requireAuth: true,
        alias: '/Examination?id=2'
      },
    },
    {
      path: '/stuInfoManage',
      name: 'stuInfoManage',
      component: stuInfoManage,
      meta: {
        title: '考生信息管理',
        requireAuth: true,
        alias: '/stuInfoManage?id=2'
      },
    },
    {
      path: '/SubjectManage',
      name: 'SubjectManage',
      component: () => import('@/page/childrenPage/enrol/enrolment/stuInfoManage/SubjectManage.vue'),
      meta: {
        title: '考生信息管理',
        requireAuth: true,
        alias: '/SubjectManage?id=2'
      },
    },
    {
      path: '/pointInfoManage',
      name: 'pointInfoManage',
      component: pointInfoManage,
      meta: {
        title: '考点信息管理',
        requireAuth: true,
        alias: '/pointInfoManage?id=2'
      },
    },
    {
      path: '/reeaxmReport',
      name: 'reeaxmReport',
      component: reeaxmReport,
      meta: {
        title: '复试分数线及权重上报',
        requireAuth: true,
        alias: '/reeaxmReport?id=2'
      },
    },
    {
      path: '/reeaxmSummary',
      name: 'reeaxmSummary',
      component: reeaxmSummary,
      meta: {
        title: '复试分数线及权重汇总',
        requireAuth: true,
        alias: '/reeaxmSummary?id=2'
      },
    },
    {
      path: '/firstScoreInput',
      name: 'firstScoreInput',
      component: firstScoreInput,
      meta: {
        title: '初试成绩录入',
        requireAuth: true,
        alias: '/firstScoreInput?id=2'
      },
    },
    {
      path: '/EntryScore',
      name: 'EntryScore',
      component: () => import('@/page/childrenPage/enrol/enrolment/firstScoreInput/EntryScore.vue'),
      meta: {
        title: '初试成绩录入',
        requireAuth: true,
        alias: '/EntryScore?id=2'
      },
    },
    {
      path: '/finalFirstScore',
      name: 'finalFirstScore',
      component: finalFirstScore,
      meta: {
        title: '最终初试成绩',
        requireAuth: true,
        alias: '/finalFirstScore?id=2'
      },
    },
    {
      path: '/finalTestScore',
      name: 'finalTestScore',
      component: () => import('@/page/childrenPage/enrol/enrolment/finalFirstScore/finalTestScore.vue'),
      meta: {
        title: '最终初试成绩',
        requireAuth: true,
        alias: '/finalTestScore?id=2'
      },
    },
    {
      path: '/perFormance',
      name: 'perFormance',
      component: perFormance,
      meta: {
        title: '综合成绩管理',
        requireAuth: true
      },
      children: [{
        path: `/perFormance/alias2`,
        component: alias2,
        name: 'perFormance/alias2',
        meta: {
          alias: '/perFormance',
          title: '综合成绩管理',
          requireAuth: true,
          noCache: true
        }
      }]
    },
    {
      path: '/addmissProposed',
      name: 'addmissProposed',
      component: addmissProposed,
      meta: {
        title: '录取名单管理',
        requireAuth: true
      }
    },
    {
      path: '/limit',
      name: 'limit',
      component: limit,
      meta: {
        title: '招生名额限定',
        requireAuth: true
      }
    },
    {
      path: '/restriction',
      name: 'restriction',
      component: () => import('@/page/childrenPage/enrol/enrolment/enrollmentLimit/restriction.vue'),
      meta: {
        title: '招生名额限定',
        requireAuth: true
      }
    },
    {
      path: '/reportQuota',
      name: 'reportQuota',
      component: reportQuota,
      meta: {
        title: '招生名额上报',
        requireAuth: true
      }
    },
    {
      path: '/reQuota',
      name: 'reQuota',
      component: () => import('@/page/childrenPage/enrol/enrolment/report/reQuota.vue'),
      meta: {
        title: '招生名额上报',
        requireAuth: true
      }
    },
    {
      path: '/reviewof',
      name: 'reviewof',
      component: reviewof,
      meta: {
        title: '招生名额审核',
        requireAuth: true
      }
    },
    {
      path: '/reviewsh',
      name: 'reviewsh',
      component: () => import('@/page/childrenPage/enrol/enrolment/enrollmentReview/reviewsh.vue'),
      meta: {
        title: '招生名额审核',
        requireAuth: true
      }
    },
    {
      path: '/adjustTable',
      name: 'adjustTable',
      component: adjustTable,
      meta: {
        title: '调剂生名单管理',
        requireAuth: true
      },
      children: [{
        path: `/adjustTable/adjustxq`,
        component: adjustxq,
        name: 'adjustTable/adjustxq',
        meta: {
          alias: '/adjustTable',
          title: '调剂生名单管理',
          requireAuth: true,
          noCache: true
        }
      }]
    },
    {
      path: '/transferStudentsList',
      name: 'transferStudentsList',
      component: transferStudentsList,
      meta: {
        title: '调剂生复试成绩录入',
        requireAuth: true
      }
    },
    {
      path: '/finalgrade',
      name: 'finalgrade',
      component: finalgrade,
      meta: {
        title: '调剂生最终成绩',
        requireAuth: true
      }
    },
    {
      path: '/enrollment',
      name: 'enrollment',
      component: enrollment,
      meta: {
        title: '调剂生录取管理',
        requireAuth: true
      }
    },
    {
      path: '/finaladd',
      name: 'finaladd',
      component: finaladd,
      meta: {
        title: '最终录取名单',
        requireAuth: true
      }
    },
    {
      path: '/interviewTable',
      name: 'interviewTable',
      component: interviewTable,
      meta: {
        title: '复试名单管理',
        requireAuth: true
      }
    },
    {
      path: '/resultEntryList',
      name: 'resultEntryList',
      component: resultEntryList,
      meta: {
        title: '复试成绩录入',
        requireAuth: true
      }
    },
    {
      path: '/MaterialTypeSetting',
      name: 'MaterialTypeSetting',
      component: () => import('@/page/childrenPage/enrol/materialReported/MaterialTypeSetting/MaterialTypeSetting.vue'),
      meta: {
        title: '材料类型设置',
        requireAuth: true
      }
    },
    {
      path: '/MaterialReport',
      name: 'MaterialReport',
      component: () => import('@/page/childrenPage/enrol/materialReported/MaterialReport/MaterialReport.vue'),
      meta: {
        title: '材料上报',
        requireAuth: true
      }
    },
    {
      path: '/MaterialAduit',
      name: 'MaterialAduit',
      component: () => import('@/page/childrenPage/enrol/materialReported/MaterialAduit/MaterialAduit.vue'),
      meta: {
        title: '材料审核',
        requireAuth: true
      }
    },
    {
      path: '/rmReport',
      name: 'rmReport',
      component: () => import('@/page/childrenPage/enrol/enrolment/reeaxmReport/rmReport.vue'),
      meta: {
        title: '复试分数线及权重上报',
        requireAuth: true,
        alias: '/rmReport?id=2'
      }
    },
    {
      path: '/reaxmSumary',
      name: 'reaxmSumary',
      component: () => import('@/page/childrenPage/enrol/enrolment/reeaxmSummary/reaxmSumary.vue'),
      meta: {
        title: '复试分数线及权重汇总',
        requireAuth: true,
        alias: '/reaxmSumary?id=2'
      }
    }, {
      path: '/interTable',
      name: 'interTable',
      component: () => import('@/page/childrenPage/enrol/enrolment/interview/interTable.vue'),
      meta: {
        title: '复试名单管理',
        requireAuth: true,
        alias: '/interTable'
      },
    }, {
      path: '/resEntryList',
      name: 'resEntryList',
      component: () => import('@/page/childrenPage/enrol/enrolment/resultEntry/resEntryList.vue'),
      meta: {
        title: '复试成绩录入',
        requireAuth: true,
        alias: '/resEntryList'
      },
    }, {
      path: '/permance',
      name: 'permance',
      component: () => import('@/page/childrenPage/enrol/enrolment/Comprehensive/permance.vue'),
      meta: {
        title: '综合成绩管理',
        requireAuth: true,
        alias: '/permance'
      },
    }, {
      path: '/addProsed',
      name: 'addProsed',
      component: () => import('@/page/childrenPage/enrol/enrolment/admissionList/addProsed.vue'),
      meta: {
        title: '录取名单管理',
        requireAuth: true,
        alias: '/addProsed'
      },
    }, {
      path: '/zymlgl',
      name: 'zymlgl',
      component: () => import('@/page/childrenPage/enrol/tmStudent/zymlgl.vue'),
      meta: {
        title: '专业目录管理',
        requireAuth: true,
        alias: '/zymlgl'
      },
    }, {
      path: '/ksxigl',
      name: 'ksxigl',
      component: () => import('@/page/childrenPage/enrol/tmStudent/ksxigl.vue'),
      meta: {
        title: '考生信息管理',
        requireAuth: true,
        alias: '/ksxigl'
      },
    }, {
      path: '/fscjlr',
      name: 'fscjlr',
      component: () => import('@/page/childrenPage/enrol/tmStudent/fscjlr.vue'),
      meta: {
        title: '复试成绩录入',
        requireAuth: true,
        alias: '/fscjlr'
      },
    },
    {
      path: "/courseInfoStatistical",
      name: "courseInfoStatistical",
      component: () => import('@/page/childrenPage/TrainManagement/statisticalAnalysis/courseInfoStatistical/courseInfoStatistical.vue'),
      meta: {
        title: "课程信息统计",
        requireAuth: true
      }
    },
    {
      path: "/teacheringStatistical",
      name: "teacheringStatistical",
      component: () => import('@/page/childrenPage/TrainManagement/statisticalAnalysis/teacheringStatistical/teacheringStatistical.vue'),
      meta: {
        title: "教学统计",
        requireAuth: true
      }
    },
    {
      path: "/actualEnrollmentStatistical",
      name: "actualEnrollmentStatistical",
      component: () => import('@/page/childrenPage/enrol/statisticalAnalysis/actualEnrollmentStatistical/actualEnrollmentStatistical.vue'),
      meta: {
        title: "历年招生统计",
        requireAuth: true
      }
    },
    {
      path: "/newbornStatistical",
      name: "newbornStatistical",
      component: () => import('@/page/childrenPage/enrol/statisticalAnalysis/newbornStatistical/newbornStatistical.vue'),
      meta: {
        title: "新生点赞统计",
        requireAuth: true
      }
    },
    {
      path: "/estimatedEnrollStatistical",
      name: "estimatedEnrollStatistical",
      component: () => import('@/page/childrenPage/enrol/statisticalAnalysis/estimatedEnrollStatistical/estimatedEnrollStatistical.vue'),
      meta: {
        title: "预计报名统计",
        requireAuth: true
      }
    }, {
      path: '/addPromse',
      name: 'addPromse',
      component: () => import('@/page/childrenPage/enrol/tmStudent/admissionList/addPromse.vue'),
      meta: {
        title: '录取名单管理',
        requireAuth: true,
        alias: '/addPromse'
      },
    },
    {
      path: "/projectStatistical",
      name: "projectStatistical",
      component: () => import('@/page/childrenPage/educationCreat/projectStatistical/projectStatistical.vue'),
      meta: {
        title: "统计分析",
        requireAuth: true
      }
    },
    {
      path: "/degreeStatistical",
      name: "degreeStatistical",
      component: () => import('@/page/childrenPage/degree/statisticalAnalysis/degreeStatistical/degreeStatistical.vue'),
      meta: {
        title: "学位论文统计",
        requireAuth: true
      }
    },
    {
      path: "/homeNoticeList",
      name: "homeNoticeList",
      component: () => import('@/page/childrenPage/home/noticeList.vue'),
      meta: {
        title: "首页",
        requireAuth: true,
        noCache: true,
        alias: "/first"
      }
    },
    {
      path: "/homeNoticeDetail/:id",
      name: "homeNoticeDetail",
      component: () => import('@/page/childrenPage/home/noticeDetail.vue'),
      meta: {
        title: "首页",
        requireAuth: true,
        noCache: true,
        alias: "/first"
      },
      props: true
    },
    {
      path: "/waitThing",
      name: "waitThing",
      component: () => import('@/page/childrenPage/home/waitThing.vue'),
      meta: {
        title: "首页",
        requireAuth: true,
        noCache: true,
        alias: "/first"
      },
    },
    {
      path: "/paperSet",
      name: "paperSet",
      component: () => import('@/page/childrenPage/degree/satisfactionSurveyManage/paperSet/paperSet.vue'),
      meta: {
        title: "调查问卷设置",
        requireAuth: true,
      },
    },
    {
      path: "/paperAnalysis",
      name: "paperAnalysis",
      component: () => import('@/page/childrenPage/degree/satisfactionSurveyManage/paperAnalysis/paperAnalysis.vue'),
      meta: {
        title: "满意度调查统计",
        requireAuth: true,
      },

    },
    {
      path: `/paperAnalysisDetail/:id`,
      component: () => import('@/page/childrenPage/degree/satisfactionSurveyManage/paperAnalysis/paperAnalysisDetail.vue'),
      name: 'paperAnalysisDetail',
      meta: {
        alias: '/paperAnalysis',
        title: '满意度调查统计',
        requireAuth: true,
        noCache: true
      }, props: true
    }, {
      path: `/paperPersonDetail/:id/:xh`,
      component: () => import('@/page/childrenPage/degree/satisfactionSurveyManage/paperAnalysis/paperPersonDetail.vue'),
      name: 'paperPersonDetail',
      meta: {
        alias: '/paperAnalysis',
        title: '满意度调查统计',
        requireAuth: true,
        noCache: true
      },
      props: true
    }
    ]
  }
  ]
})
