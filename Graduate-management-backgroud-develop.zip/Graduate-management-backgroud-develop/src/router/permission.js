import router from './index.js'
import Stores from '../store/stores.js'
// 路由跳转之前
router.beforeEach((to, from, next) => {
  if (to.path == '/') { // 判断是否需要登录
    Stores.state.openTab = []
    Stores.state.activeIndex = '/first'
    // sessionStorage.clear()
    localStorage.clear()
    next()
  } else if (to.path == '/learing_xxhz') {
    Stores.state.learning_code = false // 学术成果审核审核详情
    Stores.state.learning_code1 = false // 学术成果审核审核详情(发表著作)
    Stores.state.learning_code2 = false // 学术成果审核审核详情(学术论文)
    Stores.state.learning_code3 = false // 学术成果审核审核详情(技术专利)
    Stores.state.learning_code4 = false // 学术成果审核审核详情(科研项目)
    next()
  } else {
    next()
  }
})
export default router
