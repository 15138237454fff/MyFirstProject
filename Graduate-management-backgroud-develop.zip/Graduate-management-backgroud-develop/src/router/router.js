import {
  Loading
} from 'element-ui'
var storage = {

  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value))
  },
  get(key) {
    return JSON.parse(localStorage.getItem(key))
  },
  remove(key) {
    localStorage.removeItem(key)
  },
  addObjectKey(data, object) {
    if (Object.prototype.toString.call(data) === '[object Object]' && Object.prototype.toString.call(object) === '[object Object]') {
      Object.keys(data).forEach(key => {
        this.set(object, key, data[key])
      })
    }
  },
  tableHeaderColor({
    rowIndex,
  }) {
    if (rowIndex === 0) {
      return 'background-color: #F2F2F2;font-weight: 700;color:#333333'
    }
  },
  startLoading(key, val) {
    var loading
    if (key == 'open') {
      loading = Loading.service({
        lock: true,
        text: `${val}切换中……`,
        background: '#fff'
      })
      setTimeout(() => {
        loading.close()
      }, 800);
    }
  },
}
export default storage
