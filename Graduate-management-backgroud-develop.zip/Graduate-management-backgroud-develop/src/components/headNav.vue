<template>
  <div class="headnav">
    <div class="headnav_divone">
      <div style="width:250px;height:80px;;display: table-cell;vertical-align: middle;text-align: center;">
        <img :src="logo" alt class="img" />
      </div>
    </div>
    <div class="headnav_divsecond">研究生院综合管理平台</div>
    <div class="headnav_divthree">
      <div>
        <el-dropdown trigger="click" @command="handleCommand" v-if="menulist.length">
          <span type="text" style="color:#fff;cursor: pointer;" icon="el-icon-arrow-down el-icon--right">切换身份 |</span>
          <el-dropdown-menu slot="dropdown" style="height:300px;overflow:hidden;overflow:auto">
            <el-dropdown-item icon="el-icon-s-custom" v-for="(item, index) in menulist" :key="index" :command="item.jsid">
              <span>{{ item.name }}</span>
              <i class="el-icon-check" v-if="item.jsid == $stores.state.roleid_tole"></i>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-popover placement="top-end" trigger="click" v-model="popVisible">
          <el-table height="170" :data="newMsgList" :show-header="false" @row-click="readMsg">
            <el-table-column prop="msg" width="300"></el-table-column>
          </el-table>
          <span slot="reference" class="hasMsg">
            消息中心 |
            <span v-show="!!newMsgList.length" style="color:red">({{ newMsgList.length }})</span>
          </span>
        </el-popover>
        <span type="text" @click="passwordcacel" style="color:#fff;font-size:14px;cursor: pointer;">修改密码 |</span>
        <span type="text" @click="loginout" style="color:#fff;margin-left:0;font-size:14px;cursor: pointer;">退出</span>
      </div>
      <div style="font-size:14px;">
        欢迎
        <span style="margin-left:5px;margin-right:10px">{{ UserName }}</span>
        {{ this.$stores.state.usersnames }}登录
      </div>
    </div>
    <el-dialog title="修改密码" :visible.sync="modifyMMDialogVisible" width="500px">
      <el-form :model="form" ref="ruleForm" status-icon label-width="100px">
        <el-form-item label="用户名：" prop="userName">
          <span>{{ form.userName }}</span>
        </el-form-item>
        <el-form-item label="姓 名：" prop="name">
          <span>{{ form.name }}</span>
        </el-form-item>
        <el-form-item label="原密码：" prop="password" :required="true">
          <el-input v-model="form.password" style="width:350px"></el-input>
        </el-form-item>
        <el-form-item label="新密码：" prop="newpassword" :required="true">
          <el-input v-model="form.newpassword" style="width:350px"></el-input>
          <div class="tishi">密码长度为8-16位</div>
          <div class="tishi">新密码必须至少包含字母、数字、特殊字符中的2种</div>
        </el-form-item>
        <el-form-item label="确认密码：" prop="qrpassword" :required="true">
          <el-input v-model="form.qrpassword" style="width:350px"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="confirmMM">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import mrLogo from "../assets/mrLogo.png";
export default {
  name: "headNav",
  data() {
    return {
      show: false,
      bodyHeight: "",
      UserName: "admin",
      modifyMMDialogVisible: false,
      newPassRegx: /^(?![\d]+$)(?![a-zA-Z]+$)(?![^\da-zA-Z]+$).{6,20}$/,
      popVisible: false,
      form: {
        userName: "",
        password: "",
        name: "",
        newpassword: "",
        qrpassword: "",
        id: ""
      },
      menulist: [],
      newMsgList: [],
      mrLog: mrLogo
    };
  },
  methods: {
    handleCommand(val) {
      this.$stores.commit("menuArrend", {
        xzmneu: "",
        submenuArr: [],
        endmenuArr: []
      });
      this.$storage.startLoading("open", "身份");
      this.menulist.map(v => {
        if (v.jsid === val) {
          this.$message({
            message: `您切换的当前角色为${v.name}`,
            type: "success"
          });
          this.$stores.commit("username", v.name);
        }
      });
      this.$stores.commit("roleid_toles", val);
      this.$stores.state.openTab = [];
      this.$stores.state.menuList = [];
      this.$stores.commit("add_tabs", {
        route: "/first",
        name: "first",
        title: "首页"
      });
      this.$stores.commit("set_active_index", "/first");
      this.$router.push("/first");
      this.roles(val);
      this.getXxList();
    },
    roles(val) {
      this.$http.get("api/system/home/selectByRoleId/" + val).then(res => {
        if (this.$stores.state.roleid_tole == "1") {
          this.$stores.commit("menuArrend", {
            xzmneu: this.$stores.state.navList[0].id,
            submenuArr: this.$stores.state.navList[0].children,
            endmenuArr: this.$stores.state.navList
          });
        } else {
          // console.log(res.data.data[0] && res.data.data[0].childen);
          let data = res.data.data;
          let tmpArr = [];
          data.forEach(item => {
            if (item.menuType == 4) {
              tmpArr.push(item.menuUuid);
              return;
            }
            if (!Array.isArray(item.childen)) {
              return;
            }
            item.childen.forEach(obj => {
              if (obj.menuType == 4) {
                tmpArr.push(obj.menuUuid);
                return;
              }
              if (!Array.isArray(obj.childen)) {
                return;
              }

              obj.childen.forEach(el => {
                if (el.menuType == 4) {
                  tmpArr.push(el.menuUuid);
                  return;
                }
                if (!Array.isArray(el.childen)) {
                  return;
                }
                el.childen.forEach(v => {
                  if (!v) {
                    return;
                  }
                  tmpArr.push(v.menuUuid);
                });
              });
            });
          });
          this.$stores.commit("updateBtnAuthorityList", tmpArr);
          let submenuArr = data[0] ? data[0].childen : [];
          submenuArr.forEach(el => {
            if (!el.childen) {
              return;
            }
            el.childen = el.childen.filter(v => {
              return v.menuType !== "4";
            });
            if (Array.isArray(el.childen) && el.childen.length === 0) {
              el.childen = null;
            }
          });
          this.$stores.commit("menuArrend", {
            xzmneu: data[0] && data[0].id,
            submenuArr: submenuArr,
            endmenuArr: res.data.data
          });
          this.$stores.commit("menulistansy", data);
        }
      });
      this.$http.get("api/system/home/getNewToken/" + val).then(res => {
        this.$stores.commit("tokenrole", res.data);
      });
    },
    readMsg(row) {
      this.popVisible = false;
      let routerPath = this.$stores.state.newsRouterMap[row.childType];
      if (routerPath) {
        this.$router.push(routerPath);
      }
    },
    passwordcacel() {
      this.modifyMMDialogVisible = true;
    },
    confirmMM() {
      if (!this.newPassRegx.test(this.form.newpassword)) {
        this.$message.error("新密码必须至少包含字母、数字、特殊字符中的2种");
        return false;
      }
      this.$http
        .put("/api/system/home/updatePassword", this.form)
        .then(result => {
          if (result.data.code === 200) {
            this.modifyMMDialogVisible = false;
            this.$message.success(result.data.data);
          } else {
            this.$message.error(result.data.message);
          }
        });
    },
    loginout() {
      this.$confirm("退出系统, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.$http
          .get(
            `api/usermanage/user/loginOut/${this.$storage.get(
              "UserID"
            )}/${this.$storage.get("userSsy")}`
          )
          .then(res => {
            if (res.status == 200) {
              this.$message({
                message: "退出成功",
                type: "success"
              });
              this.$router.replace("/");
              this.logoutComfirm = false;
              this.$stores.state.openTab = [];
              this.$stores.state.activeIndex = "/first";
              this.$stores.state.roleid_tole = "";
              this.$stores.state.menuList = [];
              this.$stores.state.token = "";
              this.$stores.commit("menuArrend", {
                xzmneu: "",
                submenuArr: [],
                endmenuArr: []
              });
            } else {
              this.$message({
                message: "退出失败",
                type: "error"
              });
            }
          });
      });
    },
    getXxList() {
      this.newMsgList = [];
      this.$http.get("/api/system/xxzx/xxList?type=1").then(result => {
        const data = result.data.data;
        const ztArray = ["失败", "成功", "审核中", "待审核", "退回"];
        // 对数据进行非空验证
        if (!data) {
          return false;
        }
        // 遍历消息的关键词数组
        Object.keys(data).forEach(key => {
          switch (key) {
            // 申请状态
            case "sqztXxList":
              data[key].forEach(el => {
                // console.log(el);
                el.msg = `您的${el.proDefName}${ztArray[el.zt]}！`;
                this.newMsgList.push(el);
              });
              break;
            // 待审核
            case "dshXxList":
              data[key].forEach(el => {
                el.msg = `您有${el.count}条${el.proDefName}待审核！`;
                this.newMsgList.push(el);
              });
              break;
            // 参数变动
            case "csXxList":
              data[key].forEach(el => {
                el.msg = `可以开始${el.title}了`;
                // 测试时间
                el.starTime = "2019-7-20";
                el.endTime = "2020-7-21";
                this.newMsgList.push(el);
              });
              break;
            // 收到通知公告
            case "tz":
              if (data[key].count !== 0) {
                data[key].msg = `您有${data[key].count}条新通知！`;
                data[key].childType = "tzList";
                this.newMsgList.push(data[key]);
              }
              break;
          }
        });
      });
    },
    userIdrole() {
      this.$http
        .get("api/system/home/switchRole/" + this.$storage.get("UserID"))
        .then(res => {
          if (res.data.data.length == 0) {
            this.menulist = [];
          } else {
            this.menulist = res.data.data;
            if (this.menulist.length) {
              this.menulist.forEach(el => {
                if (
                  parseInt(el.jsid) == parseInt(this.$stores.state.roleid_tole)
                ) {
                  this.$stores.commit("username", el.name); // 管理员名称
                }
              });
            }
            this.$http
              .get(
                "api/system/home/selectByRoleId/" +
                  this.$stores.state.roleid_tole
              )
              .then(res => {
                let data = res.data.data,
                  tmpArr = [];
                this.$stores.commit("menulistansy", data);
                data.forEach(item => {
                  if (item.menuType == 4) {
                    tmpArr.push(item.menuUuid);
                    return;
                  }
                  if (!Array.isArray(item.childen)) {
                    return;
                  }
                  item.childen.forEach(obj => {
                    if (obj.menuType == 4) {
                      tmpArr.push(obj.menuUuid);
                      return;
                    }
                    if (!Array.isArray(obj.childen)) {
                      return;
                    }

                    obj.childen.forEach(el => {
                      if (el.menuType == 4) {
                        tmpArr.push(el.menuUuid);
                        return;
                      }
                      if (!Array.isArray(el.childen)) {
                        return;
                      }
                      el.childen.forEach(v => {
                        if (!v) {
                          return;
                        }
                        tmpArr.push(v.menuUuid);
                      });
                    });
                  });
                });
                this.$stores.commit("updateBtnAuthorityList", tmpArr);
              });
          }
        });
    }
  },
  created() {},
  computed: {
    // mrLogo.png
    logo() {
      return this.$stores.state.loGo ? this.$stores.state.loGo : this.mrLog;
    }
  },
  mounted() {
    this.UserName = this.$storage.get("UserName");
    this.form.userName = this.$storage.get("UserName");
    this.form.name = this.$storage.get("usersnames");
    this.form.id = this.$storage.get("UserID");
    this.getXxList();
    this.userIdrole();
  }
};
</script>

<style scoped lang="scss">
.headnav {
  width: 100%;
  display: flex;
  background: #237ae4;
  height: 100%;
  color: #ffffff;
  align-items: center;
  -webkit-align-items: center;
  justify-content: center;
}
.headnav > div {
  flex: 1;
}
.headnav_divone {
  padding-left: 16px;
}
.img {
  width: 100%;
  margin: 0 auto;
}
.headnav_divsecond {
  white-space: nowrap;
  text-align: center;
}
.headnav_divthree {
  text-align: right;
  padding-right: 8px;
}
.item {
  margin-right: 8px;
  color: #ffffff;
}
.hasMsg {
  font-size: 14px;
  cursor: pointer;
}
</style>
<style lang="scss">
.el-popover {
  .el-table .cell {
    cursor: pointer;
  }
}
</style>
