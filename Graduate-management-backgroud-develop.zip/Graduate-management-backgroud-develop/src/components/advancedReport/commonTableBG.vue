<template>
  <div class="commonTableBG">
    <div class="header">
      <span>{{ title }}</span>
      <el-button type="primary" @click="clickInput" :disabled="loading"
        >全表导出</el-button
      >
    </div>
    <slot name="top"></slot>
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: "commonTableBG",
  props: {
    title: {}
  },
  data() {
    return {
      loading: false
    };
  },
  methods: {
    clickInput() {
      this.loading = true;
      this.$emit("input");
      setTimeout(() => {
        this.loading = false;
      }, 2000);
    }
  }
};
</script>
<style lang="scss" scoped>
.commonTableBG {
  margin-top: 10px;
  border: 1px solid rgba(228, 228, 228, 1);
  .header {
    display: flex;
    font-size: 18px;
    padding: 10px 20px;
    line-height: 34px;
    font-weight: bold;
    justify-content: space-between;
  }
  /deep/ .el-table {
    thead {
      color: rgb(51, 51, 51);
      &.is-group th {
        border: 1px solid #e4e4e4;
        background: #f2f2f2;
        font-weight: normal;
      }
      th > .cell {
        font-weight: normal;
      }
    }
    th,
    td {
      border-color: #e4e4e4;
    }
  }
  table {
    width: 100%;
    border: 1px solid #e4e4e4;
    td,
    th {
      height: 40px;
    }
    thead th {
      background: #f2f2f2;
      font-size: 14px;
      border: 1px solid #e4e4e4;
    }
    tbody {
      td {
        font-size: 14px;
        padding-left: 5px;
        border: 1px solid #e4e4e4;
      }
    }
  }
}
</style>
