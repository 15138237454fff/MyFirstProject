<template>
  <!-- 申请结果不通过 -->
  <div class="applyStatusBottom" v-if="audit.status == 2 || audit.status == 0">
    <div :class="audit.status|cssFilter" class="icon-font"></div>
    <div class="text">
      <div>
        <span>招生办审核({{audit.auditor}})</span>
        <span>{{audit.verifytime}}</span>
      </div>
      <div>
        <span class="text-ellipsis">{{audit.status|stateFilter}}原因：{{audit.comment}}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'applyStatusBottom',
  filters: {
    stateFilter(state) {
      const stateMap = {
        '0': '不通过',
        '2': '退回'
      }
      return stateMap[state]
    },
    cssFilter(state) {
      const cssMap = {
        '0': 'el-icon-close',
        '2': 'el-icon-d-arrow-left'
      }
      return cssMap[state]
    }
  },
  data() {
    return {
      audit: {}
    }
  },
  mounted() {
    // //console.log(this.$store.state.auditList)
    this.getList()
  },
  watch: {
    $route() {
      this.getList()
    }
  },
  updated() {
    this.getList()
  },
  methods: {
    getList() {
      this.$bus.$on('stepList', msg => {
        if (msg.length != 0) this.audit = msg[msg.length - 1]
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.applyStatusBottom {
  border: 1px solid #e4e4e4;
  width: 100%;
  height: 95px;
  margin-top: 20px;
  display: flex;
  padding: 20px;
  box-sizing: border-box;
  .icon-font {
    width: 32px;
    line-height: inherit;
    text-align: center;
    &::before {
      font-size: 32px;
      border-radius: 50%;
      color: #fff;
      background: #f56c6c;
    }
  }
  .text {
    width: 60%;
    margin-left: 20px;
    div:first-child {
      margin-bottom: 10px;
      span:last-child {
        margin-left: 30px;
        color: #999999;
        font-size: 12px;
      }
    }
    div:last-child {
      color: #999999;
      font-size: 12px;
    }
  }
}
</style>