// 侧边栏导航
<template>
  <div class="navTag test-1">
    <div v-if="roleid == '1' && $stores.state.menuArrend.endmenuArr.length > 0">
      <el-select
        v-model="$stores.state.menuArrend.xzmneu"
        placeholder="请选择"
        style="width:100%;"
        @change="hangerselect($stores.state.menuArrend.xzmneu)"
        class="navTag-select"
      >
        <el-option
          v-for="(item, index) in $stores.state.menuArrend.endmenuArr"
          :key="index"
          :label="item.name"
          :value="item.id"
        >
        </el-option>
      </el-select>
      <el-menu
        :default-active="defaultActive"
        class="el-menu-vertical-demo"
        background-color="rgb(40, 66, 97)"
        text-color="#fff"
        active-text-color="#fff"
        :unique-opened="isOne"
        router
        @select="mySelect"
        v-if="roleid == '1' && $stores.state.menuArrend.submenuArr.length > 0"
      >
        <template>
          <!-- 当前继有一级又有二级的情况 -->
          <!-- <template v-for="(item, index) in $stores.state.menuArrend.submenuArr" v-if="item.children && item.children.length"> -->
          <template
            v-for="(item, index) in $stores.state.menuArrend.submenuArr"
          >
            <el-submenu :index="item.id" :key="item.id" v-if="item.children">
              <template slot="title">
                <i :class="item.icon"></i>
                <span>{{ item.name }}</span>
              </template>
              <template v-for="(children, index2) in item.children">
                <el-menu-item :index="children.path" :key="index2">{{
                  children.name
                }}</el-menu-item>
              </template>
            </el-submenu>
            <el-menu-item :index="item.path" v-else :key="item.id">
              <i :class="item.icon"></i>
              <span slot="title">{{ item.name }}</span>
            </el-menu-item>
          </template>
          <!-- 当前只有一级菜单的情况 -->
          <!-- <template v-for="(item, index) in $stores.state.menuArrend.submenuArr" v-if="!item.children">
            <el-menu-item :index="item.path" :key="item.id">
              <i :class="item.icon"></i>
              <span>{{ item.name }}</span>
            </el-menu-item>
          </template> -->
        </template>
      </el-menu>
    </div>
    <div
      v-if="roleid !== '1' && $stores.state.menuArrend.endmenuArr.length > 0"
    >
      <el-select
        v-model="$stores.state.menuArrend.xzmneu"
        placeholder="请选择"
        style="width:100%;"
        @change="hangerselect($stores.state.menuArrend.xzmneu)"
        class="navTag-select"
      >
        <el-option
          v-for="(item, index) in $stores.state.menuArrend.endmenuArr"
          :key="index"
          :label="item.gncdmc"
          :value="item.id"
        >
        </el-option>
      </el-select>
      <el-menu
        :default-active="defaultActive"
        class="el-menu-vertical-demo"
        background-color="rgb(40, 66, 97)"
        text-color="#fff"
        active-text-color="#fff"
        :unique-opened="isOne"
        router
        @select="mySelect"
        v-if="roleid !== '1' && $stores.state.menuArrend.submenuArr.length > 0"
      >
        <template>
          <!-- 当前只有一级菜单的情况 -->
          <!-- <template v-for="(item, index) in $stores.state.menuArrend.submenuArr" v-if="!item.childen">
            <el-menu-item :index="item.url" :key="item.id">
              <i :class="item.menuIcon"></i>
              <span>{{ item.gncdmc }}</span>
            </el-menu-item>
          </template> -->
          <!-- 当前继有一级又有二级的情况 -->
          <template
            v-for="(item, index) in $stores.state.menuArrend.submenuArr"
          >
            <el-submenu
              :index="`${item.id}`"
              :key="item.id"
              v-if="item.childen"
            >
              <template slot="title">
                <i :class="item.menuIcon"></i>
                <span>{{ item.gncdmc }}</span>
              </template>
              <template v-for="(children, index2) in item.childen">
                <el-menu-item :index="children.url" :key="children.gncdid">{{
                  children.gncdmc
                }}</el-menu-item>
              </template>
            </el-submenu>
            <el-menu-item :index="item.url" v-else :key="`${item.id}`">
              <i :class="item.menuIcon"></i>
              <span slot="title">{{ item.gncdmc }}</span>
            </el-menu-item>
          </template>
        </template>
      </el-menu>
    </div>
  </div>
</template>

<script>
export default {
  name: "navTag",
  data() {
    return {
      isCollapse: false,
      isOne: true,
      selectValue: "",
      submenuArr: []
    };
  },
  computed: {
    defaultActive() {
      if (!this.$route.meta.alias) return this.$route.path;
      else return this.$route.meta.alias;
    },
    roleid() {
      return this.$stores.state.roleid_tole;
    },
    menuList() {
      return this.$stores.state.menuList;
    }
  },
  created() {
    // console.log(this.$stores.state.menuArrend);
  },
  methods: {
    mySelect(index) {
      this.$stores.state.learning_code = false;
      this.$stores.state.learning_code1 = false;
      this.$stores.state.learning_code2 = false;
      this.$stores.state.learning_code3 = false;
      this.$stores.state.learning_code4 = false;
      for (var i in this.$store.state) {
        if (i === "skb") return;
        this.$store.state[i] = false;
      }
    },
    collapse() {
      this.isCollapse == false
        ? (this.isCollapse = true)
        : (this.isCollapse = false);
      this.$emit("showcool", this.isCollapse);
    },
    userlist() {},
    hangerselect(val) {
      this.$storage.startLoading("open", "菜单");
      this.$stores.state.openTab = [];
      this.$stores.commit("add_tabs", {
        route: "/first",
        name: "first",
        title: "首页"
      });
      this.$stores.commit("set_active_index", "/first");
      this.$router.push("/first");
      var submenuArr = [];
      var endmenuArr = [];
      var indexOf = this.$stores.state.menuArrend.endmenuArr.find(
        el => el.id === val
      );

      if (indexOf && this.roleid == "1") {
        submenuArr = indexOf.children;
      } else {
        submenuArr = indexOf.childen;
        submenuArr.forEach(el => {
          if (!el.childen) {
            return;
          }
          el.childen = el.childen.filter(v => {
            return v.menuType !== "4";
          });
          if (Array.isArray(el.childen) && el.childen.length === 0) {
            el.childen = null;
          }
        });
        // console.log(submenuArr);
      }
      if (this.roleid == "1") {
        endmenuArr = this.$stores.state.navList;
      } else {
        endmenuArr = this.menuList;
      }
      this.$stores.commit("menuArrend", {
        xzmneu: val,
        submenuArr: submenuArr,
        endmenuArr: endmenuArr
      });
    }
  }
};
</script>

<style scoped lang="scss">
.navTag {
  background: rgb(40, 66, 97) !important;
  width: 100%;
  .navTag-select {
    background-color: rgb(40, 66, 97) !important;
    /deep/ .el-input__inner {
      background-color: rgb(40, 66, 97) !important;
      border: 1px solid rgb(40, 66, 97) !important;
      color: #ffffff;
      text-align: left;
      height: 56px !important;
    }
  }
  .icon-button {
    width: 100%;
    height: 40px;
    text-align: center;
    line-height: 40px;
    button {
      background: transparent;
      padding: 0;
      border: none;
    }
  }
  .iconscss {
    width: 24px;
  }
  .el-menu-item:hover {
    background-color: #237ae4 !important;
    color: #fff !important;
  }
}
.el-submenu__title {
  background: rgb(40, 66, 97) !important;
}
.el-menu {
  height: 100%;
  background: rgb(40, 66, 97) !important;
}
.el-menu-vertical-demo:not(.el-menu--collapse) {
  width: 230px;
  height: 100%;
  background: rgb(40, 66, 97) !important;
  border-right: 1px solid rgb(40, 66, 97) !important;
}
.xtszgb {
  background: url("../assets/img/xtszgb.png");
}
.navTag /deep/ .is-active {
  color: #fff !important;
}
</style>
<style>
.el-menu-item.is-active {
  background-color: #237ae4 !important;
}
.el-menu-item:active .el-submenu .is-active .is-opened {
  background-color: rgb(40, 66, 97) !important;
}
.el-submenu__title:hover {
  background-color: rgb(40, 66, 97) !important;
}
.el-submenu__title span {
  color: #abb1bb;
}
.is-opened .el-submenu__title span {
  color: #fff;
}
.el-menu-item {
  color: #abb1bb !important;
  background: red;
}
</style>
