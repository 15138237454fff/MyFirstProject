<template>
  <div class="blank">
    <div class="card">
      <img :src="require('../assets/' + picUrl)" />
      <span>{{ msg }}</span>
    </div>
  </div>
</template>
<script>
export default {
  name: "blank",
  props: {
    msg: {},
    picUrl: {
      default: "blank.png"
    }
  },
  data() {
    return {};
  }
};
</script>
<style lang="scss" scoped>
.blank {
  width: 100%;
  height: 87vh;
  display: flex;
  position: absolute;
  left: 0;
  justify-content: center;
  align-items: center;
  margin: 0 auto;
  background: #f5f6f7;
  .card {
    width: 477px;
    height: 350px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    img {
      height: 100%;
    }
    span {
      margin-top: 10px;
      font-size: 18px;
      color: #999999;
      white-space: nowrap;
    }
  }
}
</style>
