
<template>
  <div class="searchcomponment">
    <div class="head_left">
      <slot name="left"></slot>
    </div>
    <div class="head_right">
      <slot name="right"></slot>
    </div>
  </div>
</template>
<script>
export default {
  name: 'searchcomponment',
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped lang="scss">
.searchcomponment {
  width: 100%;
  margin-bottom: 10px;
  justify-content: space-between;
  align-items: center;
  display: flex;
  height: 34px;
  .head_left {
    // flex: 2;
  }
  .head_right {
    // flex: 1;
    text-align: right;
  }
}
</style>