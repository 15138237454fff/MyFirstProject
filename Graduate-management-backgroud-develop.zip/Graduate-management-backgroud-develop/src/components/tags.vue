<template>
  <div class="tagslist">
    <div class="tagslist_left">
      <div class="tags">
        <el-tabs v-model="activeIndex" type="border-card" :closable="closable" v-if="this.$stores.state.openTab.length" @tab-click="tabClick" @tab-remove="tabRemove">
          <el-tab-pane :key="index" v-for="(item, index) of this.$stores.state.openTab" :label="item.title" :name="item.route"></el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <div class="tagslist_right">
      <div class="tags-close-box">
        <el-dropdown @command="handleTags">
          <el-button type="primary" style="border-radius:2px;cursor: pointer;">
            菜单选项
            <i class="el-icon-arrow-down el-icon--right"></i>
          </el-button>
          <el-dropdown-menu size="small" slot="dropdown" style="margin-top:80px">
            <el-dropdown-item command="other">关闭其他</el-dropdown-item>
            <el-dropdown-item command="all">关闭所有</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
export default {
  data() {
    return {
      closable: true
    };
  },
  methods: {
    handleTags(val) {
      if (val == "all") {
        this.closetab(); // 关闭标签
        this.$router.push("/first"); // 显示首页路由
      }
      if (val == "other") {
        let path;
        if (this.$route.meta.noCache) return false;
        if (!this.$route.meta.alias) path = this.$route.path;
        else path = this.$route.meta.alias;
        this.closetab(); // 关闭标签
        if (this.$route.path == "/first") {
          return false;
        }

        this.$stores.commit("add_tabs", {
          route: path,
          name: this.$route.name,
          title: this.$route.meta.title
        });
        this.$stores.commit("set_active_index", path);
      }
    },
    closetab() {
      this.$stores.state.openTab = [];
      this.$stores.state.openTab.unshift({
        route: "/first",
        name: "first",
        title: "首页"
      });
    },
    tabClick(tab) {
      this.$router.push({ path: this.activeIndex });
    },
    // 移除tab标签
    tabRemove(targetName) {
      // 首页不删
      if (targetName == "/first") {
        return;
      }
      this.$stores.commit("delete_tabs", targetName);
      if (this.activeIndex === targetName) {
        // 设置当前激活的路由
        if (this.openTab && this.openTab.length >= 1) {
          this.$stores.commit(
            "set_active_index",
            this.openTab[this.openTab.length - 1].route
          );
          this.$router.push({ path: this.activeIndex });
        } else {
          this.$router.push({ path: "/first" });
        }
      }
    }
  },
  computed: {
    openTab() {
      return this.$stores.state.openTab;
    },
    activeIndex: {
      get() {
        return this.$stores.state.activeIndex;
      },
      set(val) {
        this.$stores.commit("set_active_index", val);
      }
    }
  },
  watch: {
    $route(to, from) {
      // console.log(to, from);
      // 判断路由是否已经打开
      // 已经打开的 ，将其置为active
      // 未打开的，将其放入队列里
      let path;
      if (!this.$route.meta.alias) path = to.path;
      else path = to.meta.alias;
      if (this.$route.meta.noCache) return false;
      let flag = false;
      for (const item of this.openTab) {
        if (item.name === to.name) {
          this.$stores.commit("set_active_index", path);
          flag = true;
          break;
        }
      }
      if (!flag) {
        this.$stores.commit("add_tabs", {
          route: path,
          name: to.name,
          title: to.meta.title
        });
        this.$stores.commit("set_active_index", path);
      }
    }
  },
  mounted() {
    let path;
    if (this.$route.meta.noCache) return false;
    if (!this.$route.meta.alias) path = this.$route.path;
    else path = this.$route.meta.alias;
    if (this.$route.path !== "/first") {
      this.$stores.state.openTab.map((v, index) => {
        if (v.route == "/first") {
          this.$stores.state.openTab.splice(index, 1);
          this.$stores.state.openTab.unshift({
            route: "/first",
            name: "first",
            title: "首页"
          });
        }
        if (v.route === path) {
          this.$stores.state.openTab.splice(index, 1);
          return false;
        }
      });
      this.$stores.commit("add_tabs", {
        route: path,
        name: this.$route.name,
        title: this.$route.meta.title
      });
      this.$stores.commit("set_active_index", path);
    } else {
      this.$stores.state.openTab.map((v, index) => {
        if (v.route === this.$route.path) {
          this.$stores.state.openTab.splice(index, 1);
        }
      });
      this.$stores.commit("add_tabs", {
        route: "/first",
        name: "first",
        title: "首页"
      });
      this.$stores.commit("set_active_index", "/first");
      this.$router.push("/first");
    }
  }
};
</script>


<style scoped>
.tagslist {
  width: 100%;
}
.tagslist:after {
  content: "";
  display: block;
  clear: both;
}
.tagslist {
  zoom: 1;
}
.tagslist_left {
  float: left;
  width: calc(100% - 120px);
  overflow: hidden;
  position: relative;
  height: 40px;
}
.tagslist_right {
  width: 120px;
  float: right;
  height: 40px;
  position: relative;
}
.tags {
  background: #ffffff;
  white-space: nowrap;
  zoom: 1;
  text-overflow: ellipsis;
  position: absolute;
  left: 0;
  top: 0;
  right: -17px;
  bottom: 0;
  overflow-x: auto;
  overflow-y: hidden;
  padding-right: 20px;
}
.tags-close-box {
  text-align: center;
  width: 110px;
  height: 40px;
  overflow: hidden;
  background: #fff;
  box-shadow: -3px 0 15px 3px rgba(0, 0, 0, 0.1);
  z-index: 10;
  position: absolute;
  top: 0px;
}
.el-dropdown-menu {
  margin-top: 5px !important;
}
.el-tabs--border-card {
  box-shadow: none !important;
  border-bottom: 0;
}
.el-tabs--border-card .el-tabs__item .is-top .is-active .is-closable {
  background: #ffffff !important;
  border-bottom: 0 !important;
}
.el-tabs--border-card > .el-tabs__content {
  padding: 0 !important;
}
.el-tabs--border-card > .el-tabs__nav .is-top {
  margin-right: 3px;
}
.el-tabs--border-card > .el-tabs__header > .el-tabs__item > .is-active {
  background: #f5f7fa;
  border: 1px solid #e9eaec;
}
.el-tabs__nav .el-tabs__item:nth-child(1) span {
  display: none;
}
</style>
