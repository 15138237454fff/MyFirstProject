<template>
  <div class="projectDetailForKCALKJSXM">
    <div class="title">
      浙江财经大学研究生 · 专业学位研究生课程案例库建设项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr class="display-none">
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>案例名称</td>
          <td colspan="3">
            {{ formData.almc }}
          </td>
        </tr>
        <tr>
          <td>适用课程</td>
          <td>
            {{ `${formData.kcmc}(${formData.kcdm})` }}
          </td>
          <td>建设起止时间</td>
          <td>
            {{ $tagTime(formData.kssj, "yyyy-MM-dd ~")
            }}{{ $tagTime(formData.jssj, "yyyy-MM-dd") }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jxcgFj.url !== ''">
        <a
          :href="formData.jxcgFj.url"
          target="_blank"
          class="blue"
          :download="formData.jxcgFj.fileName"
          >{{ formData.jxcgFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <table class="charge-man">
        <tr>
          <td>姓名</td>
          <td>
            {{ `${personInfo.xm}(${personInfo.gh})` }}
          </td>
          <td>所属专业</td>
          <td>
            {{ `${formData.zy}(${formData.zym})` }}
          </td>
        </tr>
        <tr>
          <td>职称</td>
          <td>
            {{ personInfo.zc }}
          </td>
          <td>研究方向</td>
          <td>
            {{ personInfo.yjfx }}
          </td>
        </tr>
      </table>

      <div class="textarea-area">
        <div>
          <span>负责人主要教学经历（授课名称、起止时间等）和教学成果</span>
          <div class="content-box">{{ formData.jxcg }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="成员情况">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.cyjxcgFj.url !== ''">
        <a
          :href="formData.cyjxcgFj.url"
          target="_blank"
          class="blue"
          :download="formData.cyjxcgFj.fileName"
          >{{ formData.cyjxcgFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>所属专业</td>
          <td>研究方向</td>
          <td>主要负责内容</td>
        </tr>
        <tr v-for="(item, index) of formData.cyxx" :key="index">
          <td>
            {{ `${item.zdjsxm}(${item.zdjsgh})` }}
          </td>
          <td>{{ `${item.zy}(${item.zym})` }}</td>
          <td>
            {{ item.yjfx }}
          </td>
          <td>
            {{ item.responsible }}
          </td>
        </tr>
      </table>

      <div class="textarea-area">
        <div>
          <span>
            项目组成员的教学经历和教学成果（主讲的研究生课程、编写的教材、获奖情况等）</span
          >
          <div class="content-box">{{ formData.cyjxcg }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="立项依据">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.lxyjFj.url !== ''">
        <a
          :href="formData.lxyjFj.url"
          target="_blank"
          class="blue"
          :download="formData.lxyjFj.fileName"
          >{{ formData.lxyjFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >项目建设的意义；国内外建设概况、发展趋势；案例的应用前景及实用价值；前期已开展的相关工作。</span
          >
          <div class="content-box">{{ formData.lxyj }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="建设方案">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jsfaFj.url !== ''">
        <a
          :href="formData.jsfaFj.url"
          target="_blank"
          class="blue"
          :download="formData.jsfaFj.fileName"
          >{{ formData.jsfaFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >拟建设的相关案例内容、重点、特色、创新性、教学效果及教学价值；建设计划及进度安排。</span
          >
          <div class="content-box">{{ formData.jsfa }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="建设目标与成果">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jscgFj.url !== ''">
        <a
          :href="formData.jscgFj.url"
          target="_blank"
          class="blue"
          :download="formData.jscgFj.fileName"
          >{{ formData.jscgFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >项目建设拟达成的目标，预期成果及形式，案例库的教学应用计划等。</span
          >
          <div class="content-box">{{ formData.jscg }}</div>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "projectDetailForKCALKJSXM",
  components: {
    "project-card": projectCard
  },
  data() {
    return {
      formData: null,
      ktxzList: [],
      personInfo: {
        dzyx: "",
        gh: "",
        rjnx: "",
        sfbd: 0,
        ssyxh: "",
        ssyxmc: "",
        xm: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zhxw: "",
        zw: ""
      },
      getPath: "jiansheProject/getFormDataForKCALKJSXM",
      clearPath: "jiansheProject/clearFormDataForKCALKJSXM",
      updatePath: "jiansheProject/updateFormDataForKCALKJSXM",
      pickerOptionsEnd: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() > new Date().getTime();
        }
      },
      pickerOptionsStart: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() < new Date().getTime() - 86400000;
        }
      }
    };
  },
  mounted() {
    this.requireKtxzList();
  },
  methods: {
    // 请求负责人信息
    requirePersonInfo() {
      this.$http
        .get(`/api/baseservice/jzg/education/${this.formData.gh}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("教职工信息数据获取失败");
            return false;
          }
          this.personInfo = data;
        });
    },
    // 请求课程性质列表
    requireKtxzList() {
      this.$http.get(`/api/system/dict/select/kcxz`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("课程性质列表数据获取失败");
          return false;
        }
        this.ktxzList = data;
      });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
        if (this.formData.gh !== "") {
          this.requirePersonInfo();
        }
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    },
    computedTime: {
      get() {
        return [this.formData.kssj, this.formData.jssj];
      },
      set(arr) {
        if (arr === null) {
          arr = ["", ""];
        }
        this.formData.kssj = arr[0];
        this.formData.jssj = arr[1];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.projectDetailForKCALKJSXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    color: #409dff;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .charge-man {
    margin-bottom: 14px;
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
    td.no-indent {
      padding-left: 0;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
  .group-man {
    margin-bottom: 14px;
    td {
      text-align: center;
      padding: 0;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .display-none {
    td {
      visibility: hidden;
      height: 0px;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    white-space: pre-wrap;
    border: 1px solid #ccc;
  }
}
</style>
