<template>
  <div class="conclusionAddForXJYJSKYXM">
    <div class="title">
      浙江财经大学研究生 · 校级科研项目结题
    </div>
    <project-card title="项目基本信息">
      <table class="project-info">
        <tr>
          <td>课题名称</td>
          <td>
            {{ projectInfo.xmmc }}
          </td>
        </tr>
        <tr>
          <td>负责人</td>
          <td>
            {{ `${projectInfo.xm}(${projectInfo.xh})` }}
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ projectInfo.yxsmc }}
          </td>
        </tr>
        <tr>
          <td>所学专业</td>
          <td>
            {{ projectInfo.zy }}
          </td>
        </tr>
        <tr>
          <td>年级</td>
          <td>
            {{ projectInfo.sznj }}
          </td>
        </tr>
        <tr>
          <td>联系电话</td>
          <td>
            {{ projectInfo.yddh }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="主要参加者">
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>性别</td>
          <td>所在学院</td>
          <td>所学专业</td>
          <td>联系电话</td>
        </tr>
        <tr v-for="(item, index) of projectInfo.xmzxx" :key="index">
          <td>
            {{ `${item.name}(${item.studentNumber})` }}
          </td>
          <td>
            {{ item.sex | sexFilter }}
          </td>
          <td>
            {{ item.collegeName }}
          </td>
          <td>
            {{ item.majorName }}
          </td>
          <td>
            {{ item.phone }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="研究过程中进行的工作">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.yjgcgzFj.url !== ''">
        <a
          :href="formData.yjgcgzFj.url"
          target="_blank"
          class="blue"
          :download="formData.yjgcgzFj.fileName"
          >{{ formData.yjgcgzFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="project-design">
        <div>
          <span>调研、搜集材料、学术讨论、征求意见等情况</span>
          <div class="content-box">{{ formData.yjgcgzNr }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="成果发表">
      <!-- <span slot="tag" class="required"></span> -->
      <table class="group-man">
        <tr>
          <td>刊物论著名称</td>
          <td>发表时间</td>
          <td width="120px">卷期号</td>
          <td width="120px">本人排序</td>
          <td>采用情况及反映</td>
          <td>备注</td>
        </tr>
        <tr v-for="(item, index) of formData.cgfb" :key="index">
          <td>
            <div>{{ item.paperName }}</div>
          </td>
          <td>
            <div>{{ $tagTime(item.publishTime, "yyyy-MM-dd") }}</div>
          </td>
          <td>
            <div>{{ item.journalNumber }}</div>
          </td>
          <td style="width:120px;">
            <div>{{ item.sort }}</div>
          </td>
          <td>
            <div>{{ item.feedback }}</div>
          </td>
          <td>
            <div>{{ item.remark }}</div>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="研究工作总结">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.yjgzzjFj.url !== ''">
        <a
          :href="formData.yjgzzjFj.url"
          target="_blank"
          class="blue"
          :download="formData.yjgzzjFj.fileName"
          >{{ formData.yjgzzjFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="project-design">
        <div>
          <span
            >成果提出的新观点、新方案、研究中突破的难点，成果的社会效益，经济效益，存在的不足之处等</span
          >
          <div class="content-box">{{ formData.yjgzzjNr }}</div>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";

export default {
  name: "conclusionAddForXJYJSKYXM",
  components: {
    "project-card": projectCard
  },
  props: {
    lcid: {}
  },
  data() {
    return {
      formData: {},
      projectInfo: {
        sznj: "",
        xh: "",
        xm: "",
        xmmc: "",
        xmzxx: [
          {
            birthDate: "",
            collegeName: "",
            collegeNum: "",
            email: "",
            grade: "",
            majorName: "",
            majorNum: "",
            name: "",
            phone: "",
            sex: "",
            studentNumber: "",
            tasks: "",
            trainingLevel: "",
            trainingLevelNum: ""
          }
        ],
        yddh: "",
        yxsmc: "",
        zy: ""
      },
      getPath: "jiansheProject/getFormDataIsConclusionForXJYJSKYXM",
      clearPath: "jiansheProject/clearFormDataIsConclusionForXJYJSKYXM",
      updatePath: "jiansheProject/updateFormDataIsConclusionForXJYJSKYXM"
    };
  },
  mounted() {
    this.requireProjectInfo();
  },
  methods: {
    requireProjectInfo() {
      this.$http
        .get(`/api/education/university/conclusion/${this.lcid}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          console.log(data);
          this.projectInfo = data.data;
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAddForXJYJSKYXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    color: #409dff;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .project-info {
    td:first-child {
      width: 200px;
      background: #f5f5f5;
    }
    td:last-child {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }

    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
    .el-input-number {
      width: 120px;
    }
  }
  .project-design {
    & > div {
      display: flex;
      flex-direction: column;
      margin-bottom: 14px;
      span {
        line-height: 30px;
      }
    }
  }
  .totalMoney {
    font-weight: normal;
  }
  .project-plan-coast {
    td {
      text-align: center;
      &:not(:last-child) {
        width: 120px;
      }
    }
    .el-input-number {
      width: 120px;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    white-space: pre-wrap;
    border: 1px solid #ccc;
  }
}
</style>
