<template>
  <td class="projectDetailForSSYJSKCJSXM">
    <div class="title">
      浙江财经大学研究生 · 硕士研究生课程建设项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>课程名称</td>
          <td>
            {{ formData.ktmc }}
          </td>
          <td>课程性质</td>
          <td>
            {{ getListValue(formData.ktxz, this.ktxzList) }}
          </td>
        </tr>
        <tr>
          <td>所属专业</td>
          <td>
            {{ `${formData.zy}(${formData.zym})` }}
          </td>
          <td>学位性质</td>
          <td>
            {{ formData.xwxz === 1 ? "学科学位" : "专业学位" }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <table class="charge-man">
        <tr>
          <td>姓名</td>
          <td>
            {{ personInfo.xm }}
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.xbm | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>出生年月</td>
          <td>
            {{ $tagTime(personInfo.csrq, "yyyy年MM月dd日") }}
          </td>
          <td>最终学历/学位</td>
          <td>
            {{ personInfo.zhxw }}
          </td>
        </tr>
        <tr>
          <td>是否为硕导/博导</td>
          <td>
            <span v-if="personInfo.dslb">{{
              personInfo.dslb === 1 ? "硕导" : "博导"
            }}</span>
            <span v-else>未知</span>
          </td>
          <td>聘为硕导/博导时间</td>
          <td>
            {{ personInfo.hdny }}
          </td>
        </tr>
        <tr>
          <td>职务</td>
          <td>
            {{ personInfo.zw }}
          </td>
          <td>职称</td>
          <td>
            {{ personInfo.zc }}
          </td>
        </tr>
        <tr>
          <td>联系电话</td>
          <td>
            {{ personInfo.yddh }}
          </td>
          <td>电子信箱</td>
          <td>
            {{ personInfo.dzyx }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="本课程的主要特色">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.zytsFj.url !== ''">
        <a
          :href="formData.zytsFj.url"
          target="_blank"
          class="blue"
          :download="formData.zytsFj.fileName"
          >{{ formData.zytsFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.zyts }}</div>
    </project-card>
    <project-card title="预期达到的建设目标">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jsmbFj.url !== ''">
        <a
          :href="formData.jsmbFj.url"
          target="_blank"
          class="blue"
          :download="formData.jsmbFj.fileName"
          >{{ formData.jsmbFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.jsmb }}</div>
    </project-card>
    <project-card title="课程建设主要内容">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.zynrFj.url !== ''">
        <a
          :href="formData.zynrFj.url"
          target="_blank"
          class="blue"
          :download="formData.zynrFj.fileName"
          >{{ formData.zynrFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span> 1.师资队伍；</span>
          <span>2.课程教学大纲、教材、教学案例库和参考文献库；</span>
          <span>3.教学范式改革；</span>
          <span>4.教学方法和教学辅助手段；</span>
          <span>5.实践环节和其他教学环节设计等。不够可加页，限4000字</span>
          <div class="content-box">{{ formData.zynr }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="本课程的建设目标、步骤、课程资源上网计划等">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.bzjhFj.url !== ''">
        <a
          :href="formData.bzjhFj.url"
          target="_blank"
          class="blue"
          :download="formData.bzjhFj.fileName"
          >{{ formData.bzjhFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.bzjh }}</div>
    </project-card>
    <project-card title="课程负责人的教学和科研情况（附近三年科研成果清单）">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.kyqkFj.url !== ''">
        <a
          :href="formData.kyqkFj.url"
          target="_blank"
          class="blue"
          :download="formData.kyqkFj.fileName"
          >{{ formData.kyqkFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.kyqk }}</div>
    </project-card>
    <project-card title="主要参加人员的教学和科研情况（附近三年科研成果清单）">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.rykyFj.url !== ''">
        <a
          :href="formData.rykyFj.url"
          target="_blank"
          class="blue"
          :download="formData.rykyFj.fileName"
          >{{ formData.rykyFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.ryky }}</div>
    </project-card>
  </td>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "projectDetailForSSYJSKCJSXM",
  components: {
    "project-card": projectCard
  },
  props: {
    lcid: {}
  },
  data() {
    return {
      formData: null,
      ktxzList: [],
      personInfo: {
        csrq: "",
        dslb: "",
        dzyx: "",
        gh: "",
        hdny: "",
        rjnx: "",
        ssyxh: "",
        ssyxmc: "",
        xbm: "",
        xm: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zhxw: "",
        zw: ""
      },
      getPath: "jiansheProject/getFormDataForSSYJSKCJSXM",
      clearPath: "jiansheProject/clearFormDataForSSYJSKCJSXM",
      updatePath: "jiansheProject/updateFormDataForSSYJSKCJSXM",
      pickerOptionsStart: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() < new Date().getTime() - 86400000;
        }
      }
    };
  },
  mounted() {
    this.requireKtxzList();
  },
  methods: {
    // 请求负责人信息
    requirePersonInfo() {
      this.$http
        .get(`/api/baseservice/jzg/education/${this.formData.gh}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("教职工信息数据获取失败");
            return false;
          }
          this.personInfo = data;
        });
    },
    // 请求课程性质列表
    requireKtxzList() {
      this.$http.get(`/api/system/dict/select/kcxz`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("课程性质列表数据获取失败");
          return false;
        }
        this.ktxzList = data;
      });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
        if (this.formData.gh !== "") {
          this.requirePersonInfo();
        }
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.projectDetailForSSYJSKCJSXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    color: #409dff;
    font-weight: bold;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    white-space: pre-wrap;
    border: 1px solid #ccc;
  }
}
</style>
