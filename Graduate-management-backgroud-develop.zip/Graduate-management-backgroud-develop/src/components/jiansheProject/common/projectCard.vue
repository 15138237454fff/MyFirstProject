<template>
  <div class="projectCard">
    <table class="projectCardTable">
      <thead>
        <tr>
          <th>
            <slot name="tag">
              <span class="default-tag">|</span>
            </slot>
            <span>{{ title }}</span>
            <div class="right-btn">
              <slot name="btn"> </slot>
            </div>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <slot></slot>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  name: "projectCard",
  props: {
    title: {}
  }
};
</script>
<style lang="scss" scoped>
.projectCard {
  margin-bottom: 20px;
  width: 100%;
  table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    font-size: 14px;
    td {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      padding-left: 10px;
      padding-right: 10px;
    }
  }
  .projectCardTable > thead > tr > th {
    height: 40px;
    line-height: 40px;
    text-align: left;
    padding-left: 10px;
    border: 1px solid #ccc;
    color: #333;
    position: relative;
    .default-tag {
      color: #409eff;
      margin-right: 5px;
    }
    background: #f5f5f5;
    .right-btn {
      position: absolute;
      top: 50%;
      right: 0;
      margin-right: 10px;
      transform: translate(0%, -50%);
    }
  }
  .projectCardTable > tbody > tr > td {
    border: 1px solid #ccc;
    padding: 20px;
  }
}
</style>
