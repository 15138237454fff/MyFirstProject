
<template>
  <el-dialog :title="dialogtitle" :visible.sync="dialogVisible" width="30%" :before-close="handleClose">
    <p class="dialog_p">{{dialogcontent}}</p>
    <span slot="footer" class="dialog-footer">
      <el-button @click="cancel">取 消</el-button>
      <el-button type="primary" @click="sure">确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  name: 'dialog',
  data() {
    return {
      dialogtitle: '',
      dialogVisible: false,
      dialogcontent: ''
    }
  },
  methods: {
    cancel() {
      this.dialogVisible = false
    },
    sure() {
      this.dialogVisible = true
    },
    handleClose() {}
  }
}
</script>
<style scoped>
.dialog_p {
  text-align: center;
}
.dialog-footer {
  text-align: center;
}
</style>