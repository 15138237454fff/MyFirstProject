<template>
  <div v-if="modalVisiabal">
    <el-dialog
      :title="title"
      :visible="modalVisiabal"
      :custom-class="className"
      :close-on-click-modal="false"
      :destroy-on-close="true"
      @open="$emit('visiableChange', true)"
      @close="$emit('visiableChange', false)"
    >
      <slot></slot>
      <p slot="footer">
        <slot name="footer"></slot>
      </p>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "myModal",
  props: {
    // 对话框显示状态
    modalVisiabal: { type: Boolean },
    // 标题内容
    title: { type: String, default: "标题" },
    // 样式名
    className: { type: String }
  },
  methods: {}
};
</script>
<style lang="scss" scoped>
/deep/ .el-dialog__body {
  min-height: 130px;
  padding: 10px;
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
  padding: 14px 20px;
}
/deep/ .el-dialog__footer {
  button + button {
    margin-left: 20px;
  }
  border-top: 1px solid #ddd;
  padding: 10px 18px;
  text-align: center;
}
</style>
