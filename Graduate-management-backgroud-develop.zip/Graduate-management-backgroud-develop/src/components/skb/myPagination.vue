<template>
  <div class="myPagination">
    <el-pagination
      background
      @size-change="handleSize"
      @current-change="handleCurrent"
      :current-page="pageNum"
      :page-sizes="[15, 25, 50, 100]"
      :page-size="pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="msgCount"
      :class="{ modify: userStatus !== '1' }"
    ></el-pagination>
  </div>
</template>
<script>
export default {
  name: "myPagination",
  props: {
    // 当前页
    pageNum: { default: 1 },
    // 页大小
    pageSize: { default: 10 },
    // 总记录数
    msgCount: { default: 0 }
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  },
  methods: {
    // 监听页大小变化
    handleSize(val) {
      // 触发父组件监听的事件，请求新数据
      this.$emit("paginate", {
        pageNum: this.pageNum,
        pageSize: val,
        msgCount: this.msgCount
      });
    },
    // 监听当前页变化
    handleCurrent(val) {
      // 触发父组件监听的事件，请求新数据
      this.$emit("paginate", {
        pageNum: val,
        pageSize: this.pageSize,
        msgCount: this.msgCount
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.myPagination {
  margin-top: 20px;
  text-align: center;
  position: fixed;
  left: 0;
  right: 0;
  margin: 0 auto;
  bottom: 20px;
  width: 60vw;
}
.modify {
  transform: translateX(115px);
}
</style>
