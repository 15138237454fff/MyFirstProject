<template>
  <!-- 提交审核意见 -->
  <div class="audit">
    <div class="dashed"></div>
    <el-form>
      <el-form-item label="审核：" class="tuige" prop="name">
        <el-radio-group v-model="status" size="medium" style="margin-left:28px">
          <el-radio-button :label="1">通过</el-radio-button>
          <el-radio-button :label="0">不通过</el-radio-button>
          <el-radio-button :label="2" v-if="canBack">退回</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：" prop="name">
        <el-input
          type="textarea"
          v-model="comment"
          placeholder="请输入审核意见"
          :autosize="{ minRows: 6, maxRows: 8 }"
        ></el-input>
      </el-form-item>
    </el-form>
    <div class="bottom">
      <el-button type="primary" @click="clickSumbitAudit">提交</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "auditSubmit",
  props: {
    // 是否显示退回按钮
    canBack: { type: Boolean, default: true }
  },
  data() {
    return {
      comment: "",
      status: 1
    };
  },
  methods: {
    // 点击提交审核
    clickSumbitAudit() {
      if (this.comment === "" && this.status !== 1) {
        this.$message.error("请填写退回/不通过理由");
        return;
      }
      this.$emit("submit", { comment: this.comment, status: this.status });
    }
  }
};
</script>

<style lang="scss" scoped>
.dashed {
  margin-top: 25px;
  margin-bottom: 20px;
  height: 1px;
  background: linear-gradient(
    to right,
    rgba(204, 204, 204, 1),
    rgba(204, 204, 204, 1) 5px,
    transparent 5px,
    transparent
  );
  background-size: 10px 100%;
}
.audit /deep/ .el-textarea {
  width: 90%;
}
.audit /deep/ .el-button {
  margin-left: 82px;
  width: 200px;
}
.audit {
  .bottom {
    text-align: left;
  }
}
</style>
