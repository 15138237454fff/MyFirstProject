<template>
  <div>
    <el-dialog
      :title="title"
      :visible.sync="dialogVisible"
      :width="widthpx"
      top="31vh"
      :close-on-click-modal="false"
    >
      <slot></slot>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary" @click="comfirm">{{ btnName }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "slotDialog",
  props: {
    title: {},
    btnName: {},
    callback: { type: Function },
    widthpx: {}
  },
  data() {
    return {
      dialogVisible: false
    };
  },
  methods: {
    // 关闭对话框的方法
    closeDialog() {
      this.dialogVisible = false;
    },
    // 打开对话框的方法
    openDialog() {
      this.dialogVisible = true;
    },
    // 点击确定的方法
    comfirm() {
      this.callback();
      // this.closeDialog()
    }
  }
};
</script>
<style lang="scss" scoped>
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  padding: 20px 30px;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
</style>
