<template>
  <div class="addBtn">
    <span class="el-icon-plus"></span>
  </div>
</template>
<script>
export default {
  name: "addBtn"
};
</script>
<style lang="scss" scoped>
.addBtn {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: #409dff;
  text-align: center;
  line-height: 24px;
  cursor: pointer;
  margin: auto;
  span {
    font-size: 24px;
    color: #fff;
    font-weight: bold;
  }
}
</style>
