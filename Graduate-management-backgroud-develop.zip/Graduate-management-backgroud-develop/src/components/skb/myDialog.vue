<template>
  <div>
    <el-dialog
      :title="dialog.title"
      :visible.sync="dialog.visible"
      width="380px"
      top="31vh"
    >
      <p>{{ dialog.msgOne }}</p>
      <p>{{ dialog.msgTwo }}</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button type="primary" @click="dialog.successCallback"
          >确 定</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>
<script>
export default {
  name: "myDialog",
  methods: {
    // 关闭对话框的方法
    closeDialog() {
      this.$store.commit("skb/updateDialog", { visible: false });
    }
  },
  mounted() {
    // console.log(this.$store.state.skb);
  },
  computed: {
    //返回对话框参数
    dialog() {
      return this.$store.getters["skb/getDialog"];
    }
  },
  watch: {
    $route() {
      // console.log(this.$store.state.skb);
    }
  }
};
</script>
<style lang="scss" scoped>
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
  padding: 14px 20px;
}
/deep/ .el-dialog__footer {
  button + button {
    margin-left: 20px;
  }
  padding: 10px 18px;
  text-align: center;
}
</style>
