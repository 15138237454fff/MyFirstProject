<template>
  <div>
    <!-- 申请进度 -->
    <div class="main">
      <div class="dashed"></div>
      <div class="step">
        <el-steps :active="active" :space="200">
          <el-step v-for="(item, index) in aduitList" :key="index">
            <!-- <div slot="title">{{item.name}}</div> -->
            <div slot="title" class="text-ellipsis">
              <span>{{ `${item.name}` }}</span>
              <span>{{ `${item.assignee}` }}</span>
            </div>
            <span slot="description" class="time">{{
              $tagTime(item.endTime, "yyyy-MM-dd")
            }}</span>
            <span
              slot="description"
              :class="item.state | dsstatusFilter"
              class="status"
              >{{ item.state | dsztFilter }}</span
            >
            <div slot="description" class="comment" v-if="item.comment">
              {{ item.comment }}
            </div>
            <i v-if="item.state === null" slot="icon" class="el-icon-check"></i>
            <i
              v-else-if="item.state === 1"
              slot="icon"
              class="el-icon-check"
            ></i>
            <i
              v-else-if="item.state === 2"
              slot="icon"
              class="el-icon-d-arrow-left"
            ></i>
            <i
              v-else-if="item.state === 0"
              slot="icon"
              class="el-icon-close"
            ></i>
          </el-step>
        </el-steps>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "applyStatus",
  props: {
    aduitList: { type: Array, default: () => [] }
  },
  filters: {
    dsstatusFilter(sqzt) {
      sqzt = parseInt(sqzt);
      switch (sqzt) {
        case 1:
          return "yes";
        case 2:
          return "back";
        case 0:
          return "back";
      }
    },
    dsztFilter(sqzt) {
      sqzt = parseInt(sqzt);
      switch (sqzt) {
        case 1:
          return "通过";
        case 2:
          return "退回";
        case 0:
          return "不通过";
      }
    }
  },
  computed: {
    active() {
      if (Array.isArray(this.aduitList)) {
        return this.aduitList.length;
      } else {
        return 0;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  .text-ellipsis {
    margin-top: 5px;
    color: #333;
    width: 180px;
    // height: 48px;
    line-height: 24px;
    margin-bottom: 10px;
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden; /** 隐藏超出的内容 **/
    display: flex;
    flex-direction: column;
    & > span {
      width: 100%;
      word-break: keep-all;
    }
  }
  .dashed {
    margin-top: 25px;
    height: 1px;
    background: linear-gradient(
      to right,
      rgba(204, 204, 204, 1),
      rgba(204, 204, 204, 1) 5px,
      transparent 5px,
      transparent
    );
    background-size: 10px 100%;
  }
  .step {
    margin-top: 25px;
    margin-left: 15px;
    .wait {
      margin-right: 15px;
    }
    .yes {
      margin-right: 15px;
    }
    .ing {
      margin-right: 15px;
    }
    .back {
      margin-right: 15px;
    }
    .time {
      // margin-left: 15px;
      color: #909399;
      font-size: 13px;
      margin-left: 0px;
      margin-right: 15px;
    }
    .comment {
      margin-top: 8px;
      color: #333;
      font-size: 13px;
      width: 180px;
      text-overflow: ellipsis;
      overflow: hidden; /** 隐藏超出的内容 **/
    }
  }
}
.step /deep/ .el-step.is-horizontal .el-step__line {
  top: 16px;
}
.step /deep/ .el-step__title.is-success {
  color: #409eff;
}
.step /deep/ .el-step__head.is-success {
  color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-step__description.is-success {
  color: #409eff;
}
.step /deep/ .el-icon-d-arrow-left:before,
.step /deep/ .el-icon-close:before {
  color: #fff;
  background-color: #f56c6c;
  font-size: 16px;
  border-radius: 50%;
  padding: 4px;
}
.step /deep/ .el-step__head.is-process .el-step__icon.is-text {
  color: #fff;
  background-color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-steps {
  overflow-x: auto;
  padding-bottom: 10px;
}
// 重点：flex-shrink 属性指定了 flex 元素的收缩规则。
// flex 元素仅在默认宽度之和 > 容器的时候才会发生收缩，其收缩的大小是依据 flex-shrink 的值。
// flex-shrink默认值为1
.step /deep/ .el-step {
  flex-shrink: 0;
}
</style>
