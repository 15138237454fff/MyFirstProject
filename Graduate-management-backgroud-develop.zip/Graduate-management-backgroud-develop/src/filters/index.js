// 过滤审核状态
export function zsZTFilter(val, type) {
  val = parseInt(val)
  if (type === 0) {
    switch (val) {
      case 1:
        return '通过';
      case 2:
        return '退回';
      case 3:
        return '审核中';
      case 4:
        return '未上报';
    }
  } else {
    switch (val) {
      case 1:
        return 'status-success';
      case 2:
        return 'status-back';
      case 3:
        return 'status-ing';
      case 4:
        return 'status-wait';
    }
  }
} // 过滤审核状态
export function xxfsFilter(arr, type) {
  if (type === 0) {
    console.log(typeof arr)
    if (arr) {
      // const tmp = arr.map(el => (el == 1 ? "全日制" : "非全日制")).toString();
      var key = arr.toString()
      switch (key) {
        case "1":
          return "全日制";
        case "2":
          return "非全日制";
        case "1,2":
          return "全日制,非全日制";
        default:
          break;
      }
    } else {
      console.error("过滤的参数不是一个数组");
      return "";
    }
  }
  if (type === 1) {
    if (arr) {
      var key = arr.toString()
      switch (key) {
        case "1":
          return "全日制";
        case "2":
          return "非全日制";
        case "1,2":
          return "全日制,非全日制";
        default:
          break;
      }
    }
  }
}
// 导师调课：星期过滤
export function xqFilter(xq) {
  const statusMap = {
    '1': '星期一',
    '2': '星期二',
    '3': '星期三',
    '4': '星期四',
    '5': '星期五',
    '6': '星期六',
    '7': '星期日',
  }
  return statusMap[xq]
}

// 时间转为日期格式
export function toDate(time) {
  const tmpTime = new Date(time)
  return `${tmpTime.getFullYear()}.${tmpTime.getMonth() + 1}.${tmpTime.getDate()}`
}
// 时间转为年月日格式
export function toYMD(time) {
  const tmpTime = new Date(time)
  return `${tmpTime.getFullYear()}年${tmpTime.getMonth() + 1}月${tmpTime.getDate()}日`
}
export function sexFilter(val) {
  val = parseInt(val)
  switch (val) {
    case 1:
      return '男'
    case 2:
      return '女'
    case 0:
      return '未知性别'
    case 9:
      return '未说明的性别'
    default:
      return ""
  }
}
