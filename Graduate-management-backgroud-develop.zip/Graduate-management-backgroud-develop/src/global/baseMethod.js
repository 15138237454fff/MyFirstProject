const store = require('../store/stores')
exports.install = function (Vue, options) {
  // 获取数据字典值
  Vue.prototype.getDictValue = function (value, key) {
    var list = this.$dict.dict[key];
    for (let index = 0; index < list.length; index++) {
      const element = list[index];
      if (element.value == value) {
        return element.label;
      }
    }
    return '未知';
  };
  //  根据数组和value查询对应label值
  Vue.prototype.getListValue = function (value, list) {
    for (let index = 0; index < list.length; index++) {
      const element = list[index];
      if (element.value == value) {
        return element.label;
      }
    }
    return '未知';
  };
  Vue.prototype.isEmpty = function (obj) {
    // 判断字符串是否为空
    if (typeof obj == 'boolean') {
      return true;
    }
    if (typeof obj == 'undefined' || obj == null || obj == '' || obj.length == 0) {
      return false;
    } else {
      return true;
    }
  };
  // 从目标数组中删除给定下标的元素
  Vue.prototype.$deleteIndexOfArray = (index, list) => {
    if (!Array.isArray(list)) {
      console.error("目标数组类型错误")
      return
    }
    return [...list.slice(0, index), ...list.slice(index + 1, list.length)]
  }
  /**
       * time 时间对象
       * tag 传入想要得到的时间格式 yyyy-MM-dd HH-mm-ss
       */
  Vue.prototype.$tagTime = (time, tag) => {
    if (!tag) {
      return ""
    }
    if (!time) {
      return ""
    }
    let tmpTime = new Date(time)
    if (isNaN(tmpTime)) {
      return ""
    }
    let year = tmpTime.getFullYear(),
      month = tmpTime.getMonth() + 1,
      date = tmpTime.getDate(),
      hour = tmpTime.getHours(),
      minute = tmpTime.getMinutes(),
      second = tmpTime.getSeconds()
    //  不足10前面补0
    if (month < 10) {
      month = "0" + month
    }
    //  不足10前面补0
    if (date < 10) {
      date = "0" + date
    }
    //  不足10前面补0
    if (hour < 10) {
      hour = "0" + hour
    }
    //  不足10前面补0
    if (minute < 10) {
      minute = "0" + minute
    }
    //  不足10前面补0
    if (second < 10) {
      second = "0" + second
    }
    return tag.replace("yyyy", year).replace("MM", month).replace("dd", date).replace("HH", hour).replace("mm", minute).replace("ss", second)
  }
  // 获取当前时间，格式YYYY-MM-DD
  Vue.prototype.getCurrentDate = function getNowFormatDate() {
    var date = new Date();
    var seperator1 = '-';
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = '0' + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    return currentdate;
  };
  /**
     * 交换给定数组的给定两位置的元素后返回置换后的新数组
     */
  Vue.prototype.$displace = (index1, index2, array) => {
    let newArray = [...array], tmpVal = newArray[index1],
      max, min,
      oneArray, twoArray, threeArray
    if (index1 > index2) {
      min = index2
      max = index1
      oneArray = newArray.slice(0, min)
      twoArray = newArray.slice(min, max)
      threeArray = newArray.slice(max + 1, newArray.length)
      return [...oneArray, tmpVal, ...twoArray, ...threeArray]
    } else {
      min = index1
      max = index2
      oneArray = newArray.slice(0, min)
      twoArray = newArray.slice(min + 1, max + 1)
      threeArray = newArray.slice(max + 1, newArray.length + 1)
      return [...oneArray, ...twoArray, tmpVal, ...threeArray]
    }
  };
  // 按钮权限测试
  Vue.prototype.$btnAuthorityTest = key => {
    if (store.default.state.roleid_tole == "1") {
      return true
    }
    let btnList = store.default.getters.getBtnAuthorityList
    return btnList.includes(key)
  }
};
