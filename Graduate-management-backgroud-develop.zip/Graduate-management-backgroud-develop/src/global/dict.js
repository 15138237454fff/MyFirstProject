var dict = {
  sexCode: [{
      value: 1,
      label: "男"
    },
    {
      value: 2,
      label: "女"
    },
    {
      value: 0,
      label: "未知性别"
    },
    {
      value: 9,
      label: "未说明的性别"
    }
  ],
  whether: [{
    label: '是',
    value: '1'
  }, {
    label: '否',
    value: '0'
  }],
  curriculum: [{
    label: '正常',
    value: '1'
  }, {
    label: '停开',
    value: '0'
  }],
  userStatus: [{
      label: '正常',
      value: 1
    },
    {
      label: '锁定',
      value: 2
    },
    {
      label: '临时',
      value: 3
    },
    {
      label: '失效',
      value: 4
    }
  ],
  dwlb: [{
      value: 1,
      label: '	教学院系'
    },
    {
      value: 2,
      label: '	科研机构'
    },
    {
      value: 3,
      label: '	公共服务'
    },
    {
      value: 4,
      label: '	党务部门'
    },
    {
      value: 5,
      label: '	行政机构'
    },
    {
      value: 6,
      label: '	附属单位'
    },
    {
      value: 7,
      label: '	后勤部门'
    },
    {
      value: 8,
      label: '	校办产业'
    },
    {
      value: 9,
      label: '	其他    '
    }
  ]
};
export default {
  dict
};
