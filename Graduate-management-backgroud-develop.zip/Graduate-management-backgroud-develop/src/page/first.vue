<!-- 首页 -->
<template>
  <div class="first_container">
    <fristone v-if="this.$stores.state.roleid_tole == 1"></fristone>
    <firsttwo v-else></firsttwo>
  </div>
</template>

<script>
import fristone from "./fristone";
import firsttwo from "./firsttwo";
export default {
  name: "first",
  data() {
    return {};
  },
  components: {
    fristone,
    firsttwo
  },
  watch: {},
  methods: {},
  mounted() {
    // console.log(this.$router);
    // console.log(545);
  }
};
</script>

<style scoped lang="scss">
.first_container {
  width: 100%;
  height: calc(100% - 100px);
}
</style>
