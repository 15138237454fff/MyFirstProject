<!-- 首页 -->
<template>
  <div class="first_container">
    <template v-if="!indexshow && !noticeList">
      <el-row>
        <el-col :span="12">
          <div class="grid-content bg-purple">
            <el-card class="box-card">
              <div slot="header" class="clearfix">
                <span class="clearfix_span">通知公告</span>
                <el-button
                  style="float: right; padding: 3px 0"
                  type="text"
                  @click="morelist"
                  >查看更多>></el-button
                >
              </div>
              <div
                v-for="(item, index) in tzgg"
                :key="index + ''"
                class="text item"
                @click="noticeDetail(item)"
                style="cursor: pointer;"
              >
                <template v-if="index <= 5">
                  <span>{{ item.bt }}</span
                  ><span style="text-align:right">{{
                    $tagTime(item.cjsj, "yyyy.MM.dd")
                  }}</span>
                </template>
              </div>
            </el-card>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="grid-content bg-purple-light">
            <el-card class="box-card">
              <div slot="header" class="clearfix">
                <span class="clearfix_span">人数总览</span>
              </div>
              <div class="left">
                <div class="draw-title">
                  <span>在校研究生</span>
                  <div id="draw-pie1"></div>
                </div>
                <div class="draw-title">
                  <span>在校教职工</span>
                  <div id="draw-pie2"></div>
                </div>
              </div>
            </el-card>
          </div>
        </el-col>
      </el-row>
      <div class="container">
        <p>用户登录情况走势图</p>
        <div id="drawLine"></div>
      </div>
    </template>

    <indexlist v-else-if="indexshow" @ishow="ishows"></indexlist>
    <noticelist
      v-else-if="noticeList"
      @notice="notices"
      :noticedata="noticedatas"
      :types="types"
    ></noticelist>
  </div>
</template>

<script>
import indexlist from "./indexlist";
import noticelist from "./noticelist";
import "@/components/codecss/index.scss";
var echarts = require("echarts");
export default {
  name: "first",
  data() {
    return {
      indexshow: false,
      tzgg: [],
      getStuCount: [],
      getStuCounts: [],
      childenj: [],
      childenx: [],
      noticeList: false,
      noticedatas: {},
      types: false
    };
  },
  components: {
    indexlist: indexlist,
    noticelist: noticelist
  },
  filters: {
    toDate(val) {
      const tmpTime = new Date(val);
      return `${tmpTime.getFullYear()}.${tmpTime.getMonth() +
        1}.${tmpTime.getDate()}`;
    }
  },
  methods: {
    notices(val) {
      this.noticeList = val;
    },
    noticeDetail(val) {
      this.$router.push("/homeNoticeDetail/" + val.id);
    },
    ishows(val) {
      this.indexshow = val;
    },
    morelist() {
      // this.indexshow = true;
      this.$router.push("/homeNoticeList");
    },
    // 请求通知公告
    requireTZGG() {
      console.log(this.$store.state.roleid_tole);
      this.$http
        .get("/api/system/home/" + this.$stores.state.roleid_tole)
        .then(result => {
          const list = result.data.data;
          // console.log(result.data.data);
          // 对通知消息进行格式验证
          if (!Array.isArray(list)) {
            this.$message.error("通知信息列表参数格式不正确");
            return false;
          }
          this.tzgg = list;
          // 对正文内容进行过滤
          this.tzgg.forEach(el => {
            if (typeof el.bt === "string") {
              el.bt = el.bt.replace(/<[a-zA-Z]+\/?>|<\/[a-zA-Z]+>/g, "");
            }
          });
          // 通知消息按照时间排序，先展示近期消息
          this.tzgg.sort((a, b) => {
            return new Date(b.cjsj) - new Date(a.cjsj);
          });
        });
    },
    drawLine() {
      const myChart = echarts.init(document.getElementById("drawLine"));
      this.$http.get("/api/system/home").then(result => {
        this.childenj = result.data.data.childenj;
        this.childenx = result.data.data.childenx;
        myChart.setOption({
          backgroundColor: "#fff",
          title: {
            show: false,
            textStyle: {
              fontWeight: "normal",
              fontSize: 16,
              color: "#000"
            },
            left: "6%"
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              lineStyle: {
                color: "#000"
              }
            }
          },
          legend: {
            icon: "rect",
            itemWidth: 14,
            itemHeight: 5,
            itemGap: 13,
            data: ["学生", "教职工"],
            right: "4%",
            textStyle: {
              fontSize: 12,
              color: "#000"
            }
          },
          grid: {
            left: "3%",
            right: "4%",
            bottom: "3%",
            containLabel: true
          },
          xAxis: [
            {
              type: "category",
              boundaryGap: false,
              axisLine: {
                lineStyle: {
                  color: "#ccc"
                }
              },
              axisLabel: {
                margin: 15
              },
              splitLine: {
                lineStyle: {
                  color: "#ccc",
                  type: "dashed"
                }
              },
              data: [
                "9:00",
                "10:00",
                "11:00",
                "12:00",
                "13:00",
                "14:00",
                "15:00",
                "16:00",
                "17:00",
                "18:00"
              ]
            }
          ],
          yAxis: [
            {
              type: "value",
              name: "",
              axisTick: {
                show: false
              },
              axisLine: {
                lineStyle: {
                  color: "#ccc"
                }
              },
              axisLabel: {
                margin: 10,
                textStyle: {
                  fontSize: 14
                }
              },
              splitLine: {
                lineStyle: {
                  color: "#ccc",
                  type: "dashed"
                }
              }
            }
          ],
          series: [
            {
              name: "学生",
              type: "line",
              smooth: true,
              symbol: "circle",
              symbolSize: 5,
              showSymbol: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              areaStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(
                    0,
                    0,
                    0,
                    1,
                    [
                      {
                        offset: 0,
                        color: "rgba(16, 135, 234, 0.3)"
                      },
                      {
                        offset: 0.8,
                        color: "rgba(16, 135, 234, 0)"
                      }
                    ],
                    false
                  ),
                  shadowColor: "rgba(0, 0, 0, 0.1)",
                  shadowBlur: 10
                }
              },
              itemStyle: {
                normal: {
                  color: "rgb(16, 135, 234)",
                  borderColor: "rgba(16, 135, 234,0.2)",
                  borderWidth: 12
                }
              },
              data: this.childenx
            },
            {
              name: "教职工",
              type: "line",
              smooth: true,
              symbol: "circle",
              symbolSize: 5,
              showSymbol: false,
              lineStyle: {
                normal: {
                  width: 1
                }
              },
              areaStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(
                    0,
                    0,
                    0,
                    1,
                    [
                      {
                        offset: 0,
                        color: "rgba(107, 213, 124, 0.3)"
                      },
                      {
                        offset: 0.8,
                        color: "rgba(107, 213, 124, 0)"
                      }
                    ],
                    false
                  ),
                  shadowColor: "rgba(0, 0, 0, 0.1)",
                  shadowBlur: 10
                }
              },
              itemStyle: {
                normal: {
                  color: "rgb(107, 213, 124)",
                  borderColor: "rgba(107, 213, 124,0.2)",
                  borderWidth: 12
                }
              },
              data: this.childenj
            }
          ]
        });
      });
    },
    drawPie() {
      const myChart1 = echarts.init(document.getElementById("draw-pie1"));
      this.$http.get("/api/system/home/getStuCount").then(result => {
        this.getStuCount = [
          { value: result.data.man, name: "男" },
          { value: result.data.woman, name: "女" }
        ];
        myChart1.setOption({
          title: {
            textStyle: {
              color: "#000",
              fontSize: 16
            },
            x: "center",
            y: "center"
          },
          tooltip: {
            trigger: "item",
            formatter: "{a} <br/>{b}: {c} ({d}%)"
          },
          legend: {
            orient: "vertical",
            x: "right",
            data: ["女", "男"]
          },
          series: [
            {
              name: "访问来源",
              type: "pie",
              radius: ["50%", "70%"],
              avoidLabelOverlap: false,
              label: {
                normal: {
                  show: false,
                  position: "center"
                },
                emphasis: {
                  show: true,
                  textStyle: {
                    fontSize: "30",
                    fontWeight: "bold"
                  }
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              data: this.getStuCount
            }
          ]
        });
      });
    },
    drawPies() {
      const myChart1 = echarts.init(document.getElementById("draw-pie2"));
      this.$http.get("/api/system/home/getTerCount").then(result => {
        this.getStuCounts = [
          { value: result.data.man, name: "男" },
          { value: result.data.woman, name: "女" }
        ];
        myChart1.setOption({
          title: {
            textStyle: {
              color: "#000",
              fontSize: 16
              // align: 'center'
            },
            x: "center",
            y: "center"
          },
          tooltip: {
            trigger: "item",
            formatter: "{a} <br/>{b}: {c} ({d}%)"
          },
          legend: {
            orient: "vertical",
            x: "right",
            data: ["女", "男"]
          },
          series: [
            {
              name: "访问来源",
              type: "pie",
              radius: ["50%", "70%"],
              avoidLabelOverlap: false,
              label: {
                normal: {
                  show: false,
                  position: "center"
                },
                emphasis: {
                  show: true,
                  textStyle: {
                    fontSize: "30",
                    fontWeight: "bold"
                  }
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              data: this.getStuCounts
            }
          ]
        });
      });
    }
  },
  created() {
    this.requireTZGG();
  },
  mounted() {
    this.drawLine();
    this.drawPie();
    this.drawPies();
    window.onresize = function() {
      const myChart = echarts.init(document.getElementById("drawLine"));
      myChart.resize();
    };
  }
};
</script>

<style scoped lang="scss"></style>
