<!-- 首页 -->
<template>
  <div class="noticelist">
    <el-row>
      <el-col :span="24">
        <div class="grid-content bg-purple-dark">
          <el-button type="text" icon="el-icon-refresh-left" @click="goBack">返回列表</el-button>
        </div>
      </el-col>
    </el-row>
    <div class="ul_container">
      <header>▪{{title}}▪</header>
      <section v-html="sectioncontent"></section>
      相关附件:<span @click="open(item.url)" style="color:#1890ff;text-decoration:underline" v-for="(item,index) in xtWjscjlbVos" :key="index">{{item.fileName}}</span>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    noticedata: {
      type: Object,
      default: () => {}
    },
    types: {
      type: Boolean
    }
  },
  name: 'noticelist',
  data() {
    return {
      title: '',
      sectioncontent: '',
      fileName: '',
      fileUrl: '',
      xtWjscjlbVos: []
    }
  },
  methods: {
    goBack() {
      if (this.types) {
        this.$emit('notice', false)
      } else {
        // 返回父组件
        this.$emit('notice', false)
        // 刷新父组件的列表
        if (this.role == '2') {
          this.$parent.requireTZGG()
        } else {
          this.$nextTick(() => {
            this.$parent.drawLine()
            this.$parent.drawPie()
            this.$parent.drawPies()
          })
        }
      }
    },
    open(val) {
      if (!val) {
        return false
      } else {
        window.open(val)
      }
    },
    table() {
      this.$http
        .get(`/api/system/notice/selectUp/${this.noticedata.id}`)
        .then(result => {
          this.title = result.data.data.bt
          this.sectioncontent = result.data.data.zw
          this.fileName = result.data.data.fileName
          this.xtWjscjlbVos = result.data.data.xtWjscjlbVos
        })
    }
  },
  mounted() {
    this.table()
  }
}
</script>

<style scoped lang="scss">
.noticelist {
  width: 100%;
  .bg-purple-dark {
    border-bottom: 1px solid rgba(242, 242, 242, 1);
    padding-left: 20px;
    height: 60px;
    line-height: 60px;
  }
  .bg-purple-darks {
    margin: 20px 0;
    border-bottom: 1px solid rgba(233, 233, 233, 1);
    height: 60px;
    line-height: 60px;
  }
  .ul_container {
    padding: 30px;
    // height: 500px;
    overflow: hidden;
    // font-family: "Microsoft YaHei UI Bold", "Microsoft YaHei UI Regular",
    //   "Microsoft YaHei UI";
    font-weight: 600;
    font-style: normal;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.847058823529412);
    header {
      height: 60px;
      line-height: 60px;
      text-align: center;
      font-size: 18px;
      margin-bottom: 20px;
    }
    section {
      width: 100%;
      height: 500px;
      overflow: hidden;
      overflow-y: auto;
      border-top: 1px solid #e9e9e9;
      padding: 20px;
    }
  }
}
</style>
