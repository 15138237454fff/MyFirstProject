<template>
  <div class="safety">
    <section>
      <div class="safety_div">
        <el-button type="primary" circle style="width:40px">1</el-button><span>安全认证</span>
        <div class="step"></div>
      </div>
      <div class="safety_div">
        <el-button circle style="width:40px">2</el-button><span style="color:rgba(0, 0, 0, 0.447058823529412);">重置密码</span>
        <div class="step"></div>
      </div>
      <div class="safety_div1">
        <el-button circle style="width:40px">3</el-button><span style="color:rgba(0, 0, 0, 0.447058823529412);">完成</span>
      </div>
    </section>
    <el-form :model="ruleForm" ref="ruleForm" label-width="150px" class="demo-ruleForm" :rules="rules">
      <el-form-item label="请输入用户名：" prop="username">
        <el-input v-model.trim="ruleForm.username" placeholder="请输入" style="width:450px"></el-input>
      </el-form-item>
      <el-form-item label="请输入验证码：" prop="usercode">
        <el-input v-model.trim="ruleForm.usercode" placeholder="请输入" style="width:335px"></el-input>
        <el-button type="primary" plain @click="getCode" v-show="sendAuthCode">获取验证码</el-button>
        <el-button type="primary" plain @click="getCode" v-show="!sendAuthCode" :disabled="!sendAuthCode">{{authTime}}秒之重新发送验证码</el-button>
      </el-form-item>
      <p>验证码将以邮箱的形式发送至您的邮箱，如在几分钟内未收到邮箱，请点击重新发送</p>
      <el-form-item class="btn">
        <el-button @click="nextForm" class="btn_list">返回登录</el-button>
        <el-button type="primary" @click="submitForm('ruleForm')">下一步</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: 'safety',
  data() {
    return {
      ruleForm: {},
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' }
        ],
        usercode: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
          { min: 3, max: 6, message: '长度在 3 到 6 个字符', trigger: 'blur' }
        ]
      },
      sendAuthCode: true /* 布尔值，通过v-show控制显示‘获取按钮’还是‘倒计时’ */,
      authTime: 0 /* 倒计时 计数器*/
    }
  },
  methods: {
    submitForm(formName) {
      sessionStorage.setItem('deskuserName', this.ruleForm.username)
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$http
            .get(`api/system/deskHome/verifyCode/${this.ruleForm.usercode}`)
            .then(result => {
              if (result.data.code == 200) {
                this.$emit('safetycompentent', true)
              } else {
                this.$message.error({
                  message: result.data.message
                })
              }
            })
        } else {
          return false
        }
      })
    },
    getCode() {
      if (!this.ruleForm.username) {
        return this.$message.error({
          message: '请输入用户名'
        })
      }
      this.authTime = 60
      var authTime = setInterval(() => {
        this.authTime--
        if (this.authTime <= 0) {
          this.sendAuthCode = true
          clearInterval(authTime)
        }
      }, 1000)
      this.$http
        .get(`api/system/deskHome/getVerify/${this.ruleForm.username}`)
        .then(result => {
          if (result.data.code == 200) {
            this.sendAuthCode = false
            this.$message.success({
              message: result.data.message
            })
          } else {
            this.$message.error({
              message: result.data.message
            })
            clearInterval(authTime)
            this.sendAuthCode = true
          }
        })
    },
    nextForm() {
      this.$router.push('/')
    }
  }
}
</script>

<style scoped lang="scss">
.safety {
  width: 100%;
  section {
    display: flex;
    padding: 20px 0px 20px 120px;
    margin-top: 50px;
    margin-bottom: 50px;
    .safety_div {
      position: relative;
      flex: 2;
    }
    .safety_div1 {
      position: relative;
      flex: 1;
    }
    div {
      .step {
        position: absolute;
        border-color: inherit;
        background-color: #e8e8e8;
        height: 1.5px;
        top: 18px;
        left: 116px;
        right: 15px;
      }
      span {
        margin-left: 10px;
        font-family: "MicrosoftTaiLe-Bold", "Microsoft Tai Le Bold",
          "Microsoft Tai Le";
        font-weight: 700;
        font-style: normal;
        font-size: 16px;
        color: rgba(0, 0, 0, 0.847058823529412);
      }
    }
  }
  .demo-ruleForm {
    width: 800px;
    margin: 0 auto;
    p {
      font-family: "MicrosoftTaiLe", "Microsoft Tai Le";
      font-weight: 400;
      font-style: normal;
      font-size: 12px;
      color: rgba(153, 153, 153, 0.647058823529412);
      text-align: center;
      margin-bottom: 80px;
      padding-right: 40px;
    }
    .btn {
      margin-left: 100px;
      .btn_list {
        border-color: #66b1ff;
        color: #66b1ff;
      }
    }
  }
}
</style>
