<template>
  <div class="login">
    404
    <p>未找到</p>
  </div>
</template>

<script>
export default {
  name: "login",
  data() {
    return {};
  }
};
</script>

<style scoped lang="scss">
.login {
  font-size: 48px;
  text-align: center;
  color: red;
}
</style>
