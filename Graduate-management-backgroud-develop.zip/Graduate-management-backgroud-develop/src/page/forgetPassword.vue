<template>
  <div class="forgetPassword">
    <div class="hearders">
      <!--<div class="headnav_divone">-->
        <!--<img src="../assets/logo.png" alt class="img" />-->
      <!--</div>-->
      <!--<div class="headnav_divsecond">浙江财经大学研究生院综合管理平台</div>-->
      <div class="headnav_divsecond">研究生院综合管理平台</div>
      <div class="three"></div>
    </div>
    <div class="bix">
      <header>
        <div style="text-align:right;padding-right:20px;padding-top:10px">
          <img
            src="../assets/open.png"
            alt=""
            style="width:100px;height:100px"
          />
        </div>
        <div style="line-height:120px;">
          找回密码
        </div>
      </header>
      <div>
        <safety
          v-if="safetycompent"
          @safetycompentent="safetycompentent"
        ></safety>
        <resetpass
          v-if="resetpasscompent"
          @resetpasscompentent="resetpasscompentent"
          @finshEndcompentent="finshEndcompentent"
        ></resetpass>
        <finshEnd v-if="finshEndcompent"></finshEnd>
      </div>
    </div>
  </div>
</template>

<script>
import safety from "./safety";
import resetpass from "./resetpass";
import finshEnd from "./finshEnd";
export default {
  name: "forgetPassword",
  data() {
    return {
      percentage: 20,
      customColor: "#409eff",
      safetycompent: true,
      resetpasscompent: false,
      finshEndcompent: false
    };
  },
  components: {
    safety: safety,
    resetpass: resetpass,
    finshEnd: finshEnd
  },
  methods: {
    safetycompentent(val) {
      this.resetpasscompent = val;
      this.safetycompent = !val;
    },
    resetpasscompentent(val) {
      this.resetpasscompent = !val;
      this.safetycompent = val;
    },
    finshEndcompentent(val) {
      this.resetpasscompent = !val;
      this.finshEndcompent = val;
    }
  }
};
</script>

<style scoped lang="scss">
.forgetPassword {
  min-width: 1200px;
  width: 100%;
  overflow: hidden;
  overflow-y: auto;
  padding-bottom: 60px;
  background: rgba(242, 242, 242, 1);
  .hearders {
    width: 100%;
    height: 72px;
    display: flex;
    background: #237ae4;
    color: #ffffff;
    align-items: center;
    -webkit-align-items: center;
    justify-content: center;
    margin-bottom: 33px;
    .headnav_divone {
      flex: 1;
      padding-left: 16px;
    }
    .img {
      width: 230px;
    }
    .headnav_divsecond {
      flex: 1;
      height: 100%;
      line-height: 72px;
      text-align: center;
    }
    .three {
      flex: 1;
    }
  }
  .bix {
    width: 80%;
    height: 800px;
    background: rgba(255, 255, 255, 1);
    margin: 0 auto;
    header {
      width: 100%;
      height: 120px;
      display: flex;
      line-height: 100px;
      border-bottom: 1px solid rgba(217, 217, 217, 1);
      div {
        flex: 1;
        font-weight: bold;
      }
    }
  }
}
</style>
