<template>
  <!-- 导师首页 -->
  <div class="container">
    <template v-if="!ishow && !noticeList">
      <div class="teacher-home">
        <div class="notice">
          <div class="header">
            <h3>通知公告</h3>
            <el-button type="text" @click="loadMoreNotice"
              >查看更多>></el-button
            >
          </div>
          <el-divider></el-divider>
          <div class="notice-view" style="color:#000">
            <ul>
              <li
                v-for="(item, index) in tzgg"
                :key="index"
                @click="noticeDetail(item)"
                style="cursor: pointer"
              >
                <template v-if="index <= 9">
                  <span>• {{ item.bt }}</span>
                  <span>{{ item.cjsj | toDate }}</span>
                </template>
              </li>
            </ul>
          </div>
        </div>
        <div class="schedule">
          <div class="header">
            <h3>待办事项</h3>
            <el-button type="text" @click="loadMoreThing">查看更多>></el-button>
          </div>
          <el-divider></el-divider>
          <div class="schedule-view" style="color:#000">
            <ul>
              <li
                v-for="(item, index) of dbsx"
                :key="index"
                @click="dbxq(item)"
              >
                <span class="content"
                  >您有1条{{ item.xm }}的{{ item.processDefinitionName }}</span
                >
                <span class="time">{{ item.createTime | toDate }}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </template>
    <indexlist v-else-if="ishow" @ishow="ishows" :role="role"></indexlist>
    <noticelist
      v-else-if="noticeList"
      @notice="notices"
      :noticedata="noticedatas"
      :types="types"
    ></noticelist>
  </div>
</template>
<script>
import indexlist from "./indexlist";
import noticelist from "./noticelist";
export default {
  name: "teacherHome",
  data() {
    return {
      // 通知消息
      tzgg: [],
      // 待办事项
      dbsx: [],
      ishow: false,
      role: "2",
      noticeList: false,
      noticedatas: {},
      types: true
    };
  },
  components: {
    indexlist: indexlist,
    noticelist: noticelist
  },
  created() {
    this.requireTZGG();
    this.requireDBSX();
  },
  filters: {
    toDate(val) {
      const tmpTime = new Date(val);
      return `${tmpTime.getFullYear()}.${tmpTime.getMonth() +
        1}.${tmpTime.getDate()}`;
    }
  },
  methods: {
    dbxq(item) {
      let routerPath = this.$stores.state.newsRouterMap[
        item.processDefinitionId.split(":")[0]
      ];
      if (routerPath) {
        this.$router.push(routerPath);
      }
      console.log(routerPath);
    },
    noticeDetail(val) {
      this.$router.push("/homeNoticeDetail/" + val.id);
    },
    notices(val) {
      this.noticeList = val;
    },
    ishows(val) {
      this.ishow = val;
    },
    // 请求通知公告
    requireTZGG() {
      this.$http
        .get(`/api/system/home/${this.$stores.state.roleid_tole}`)
        .then(result => {
          const list = result.data.data;
          // 对通知消息进行格式验证
          if (!Array.isArray(list)) {
            this.$message.error("通知公告列表参数格式不正确");
            return false;
          }
          this.tzgg = list;
          // 对正文内容进行过滤
          this.tzgg.forEach(el => {
            if (typeof el.bt === "string") {
              el.bt = el.bt.replace(/<[a-zA-Z]+\/?>|<\/[a-zA-Z]+>/g, "");
            }
          });
          // 通知消息按照时间排序，先展示近期消息
          this.tzgg.sort((a, b) => {
            return new Date(b.cjsj) - new Date(a.cjsj);
          });
        });
    },
    // 请求待办事项列表
    requireDBSX() {
      this.$http
        .get("/api/system/dbsx/selectRuTask", {
          params: {
            type: 1
          }
        })
        .then(result => {
          const data = result.data.data;
          // console.log(data);
          // 非空验证
          if (!data) {
            this.$message.error("待办事项消息获取失败");
            return false;
          }
          // 对待办事项按时间排序
          // data.sort((a, b) => {
          //   return new Date(b.createTime) - new Date(a.createTime)
          // })
          this.dbsx = data;
        });
    },
    // 显示查看更多通知
    loadMoreNotice() {
      // this.ishow = true
      // console.log(this.ishow)
      this.$router.push("/homeNoticeList");
    },
    // 显示查看更多代办事项
    loadMoreThing() {
      this.$router.push("/waitThing");
    }
  }
};
</script>

<style lang="scss" scoped>
.container {
  height: 100%;
}
.teacher-home {
  // width: 100%;
  display: flex;

  // flex-direction: column;
  height: calc(100% - 70px); //减号前后要有空格，否则很可能不生效！！
  .notice,
  .schedule {
    background-color: #fff;
    margin: 10px;
    height: 100%;
    // display: flex;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
    overflow: hidden;
    width: 98%;
    .header {
      display: flex;
      margin-top: 12px;
      padding: 0 10px;
      img {
        width: 22px;
        height: 22px;
        margin-right: 15px;
      }
      h3 {
        margin: 0;
        flex: 2;
      }
      .el-button {
        padding: 0;
      }
    }
    .el-divider--horizontal {
      margin: 12px 0;
    }
  }
  .notice-view {
    padding-right: 15px;
    ul {
      padding-left: 20px;
      li {
        display: flex;
        line-height: 45px;
        span {
          &:nth-child(1) {
            flex: 4;
            font-size: 14px;
            font-weight: 700;
          }
          &:nth-child(2) {
            flex: 0.5;
            font-size: 13px;
          }
        }
      }
    }
  }
  .schedule-view {
    padding-right: 15px;
    ul {
      padding-left: 20px;
      li {
        display: flex;
        line-height: 45px;
        justify-content: space-between;
        span {
          font-size: 12px;
        }
      }
    }
  }
}
</style>
