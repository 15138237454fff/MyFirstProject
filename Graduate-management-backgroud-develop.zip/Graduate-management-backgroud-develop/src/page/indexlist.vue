<!-- 首页 -->
<template>
  <div class="index_list">
    <template v-if="!noticeList">
      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple-dark">
            <el-button type="text" icon="el-icon-refresh-left" @click="goBack">返回列表</el-button>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple-darks">通知公告</div>
        </el-col>
      </el-row>
      <ul class="ul_container">
        <li v-for="(item,$index) in table" @click="noticeDetail(item)">
          <span>▪ {{item.bt}}</span><span>{{item.cjsj}}</span>
        </li>
      </ul>
      <div class="block">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage4" :page-sizes="[5, 10, 15, 20]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
        </el-pagination>
      </div>
    </template>
    <noticeDetails v-else-if="noticeList" @notice="notices" :noticedata="noticedatas"></noticeDetails>
  </div>
</template>

<script>
import noticeDetails from './noticeDetails';
export default {
  props: {
    role: {
      type: String
    }
  },
  name: 'indexlist',
  data() {
    return {
      table: [],
      currentPage4: 1,
      total: 0,
      pagesize: 5,
      noticeList: false,
      noticedatas: {}
    }
  },
  components: {
    noticeDetails
  },
  methods: {
    notices(val) {
      this.noticeList = val
    },
    noticeDetail(val) {
      this.noticedatas = val
      this.noticeList = true
    },
    handleSizeChange(val) {
      this.pagesize = val
      this.tablelist()
    },
    handleCurrentChange(val) {
      this.currentPage4 = val
      this.tablelist()
    },
    goBack() {
      // 返回父组件
      this.$emit('ishow', false)
      // 刷新父组件的列表
      if (this.role == '2') {
        this.$parent.requireTZGG()
      } else {
        this.$nextTick(() => {
          this.$parent.drawLine()
          this.$parent.drawPie()
          this.$parent.drawPies()
        })
      }
    },
    tablelist() {
      this.$http
        .post(`/api/system/home/listmore/${this.$stores.state.roleid_tole}`, {
          pageNum: this.currentPage4,
          pageSize: this.pagesize
        })
        .then(result => {
          const list = result.data.data.list
          // 对通知消息进行格式验证
          if (!Array.isArray(list)) {
            this.$message.error('通知公告参数格式不正确')
            return false
          }
          this.table = list
          this.total = result.data.data.total
        })
    }
  },
  mounted() {
    this.tablelist()
  }
}
</script>

<style scoped lang="scss">
.index_list {
  width: 100%;
  .bg-purple-dark {
    border-bottom: 1px solid rgba(242, 242, 242, 1);
    padding-left: 20px;
    height: 60px;
    line-height: 60px;
  }
  .bg-purple-darks {
    margin: 20px 0;
    border-bottom: 1px solid rgba(233, 233, 233, 1);
    height: 60px;
    line-height: 60px;
  }
  .ul_container {
    height: 500px;
    overflow: hidden;
    font-family: "Microsoft YaHei UI Bold", "Microsoft YaHei UI Regular",
      "Microsoft YaHei UI";
    font-weight: 700;
    font-style: normal;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.847058823529412);
  }
  .ul_container > li {
    border-bottom: 1px dashed rgba(233, 233, 233, 1);
    height: 60px;
    line-height: 60px;
    display: flex;
    cursor: pointer;
  }
  .ul_container > li > span {
    flex: 1;
  }
  .ul_container > li > span:nth-child(2) {
    text-align: right;
  }
}
</style>
