<template>
  <div class="login">
    <img src="../assets/img/mytitle.png" alt="" class="title">
    <div class="login-container">
      <el-form :model="form" label-width="100px" ref="form">
        <el-form-item label="用户名：" class="first">
          <el-input style="width:200px" v-model="form.userName"></el-input>
        </el-form-item>
        <el-form-item label="密 码：" class="second">
          <el-input style="width:200px" v-model="form.password"></el-input>
        </el-form-item>
      </el-form>
      <el-checkbox v-model="checked">记住密码</el-checkbox>
      <button class="login-button">登录</button>
    </div>
    <img src="../assets/img/line.png" alt="" class="line">
    <p>杭州毕为科技有限公司 主办</p>
  </div>
</template>

<script>
export default {
  name: "login",
  data() {
    return {
      checked: false,
      form: {
        userName: "",
        password: ""
      }
    };
  }
};
</script>

<style scoped lang="scss">
.login {
  width: 100%;
  height: 100%;
  background: url("../assets/img/login.png") no-repeat;
  background-size: cover;
  position: relative;
  p {
    color: #fff;
    position: fixed;
    bottom: 10px;
    left: 50%;
    margin-left: -98px;
  }
  img.title {
    position: absolute;
    left: 50%;
    margin-left: -492px;
    top: 100px;
  }
  img.line {
    position: absolute;
    bottom: 60px;
    left: 50%;
    margin-left: -507px;
  }
  @media screen and (max-width: 1500px) {
    img.title {
      top: 50px;
      width: 600px;
      margin-left: -300px;
    }
  }
  .login-container {
    height: 300px;
    width: 500px;
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -150px;
    margin-left: -320px;
  }
  .login-button {
    height: 50px;
    width: 400px;
    text-align: center;
    background: #1161ee;
    border: none;
    outline: none;
    border-radius: 40px;
    line-height: 50px;
    color: #fff;
    font-size: 20px;
    position: relative;
    top: 20px;
    left: 106px;
  }
}
.login /deep/ .el-input__inner {
  height: 50px;
  width: 400px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 40px;
  border: none;
  color: #fff;
  margin-top: 20px;
  margin-bottom: 10px;
}
.login /deep/ .first .el-form-item__label {
  position: relative;
  top: -25px;
  font-size: 18px;
  left: 106px;
  color: #999;
}
.login /deep/ .second .el-form-item__label {
  position: relative;
  top: -25px;
  font-size: 18px;
  left: 94px;
  color: #999;
}
.login /deep/ .el-checkbox {
  position: relative;
  left: 106px;
}
.login /deep/ .el-checkbox__label {
  color: #fff;
}
</style>
