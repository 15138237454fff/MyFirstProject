
<template>
  <div class="line">
    414
  </div>
</template>

<script>
export default {};
</script>

<style>
.line {
  width: 100%;
  height: 50px;
  margin-top: 10px;
  margin-bottom: 10px;
  border-bottom: 1px solid red;
}
</style>

