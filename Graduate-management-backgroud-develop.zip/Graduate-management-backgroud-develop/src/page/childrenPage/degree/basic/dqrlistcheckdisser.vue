<template>
  <div class="dqrlist">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="form.searchcontent" placeholder="请输入学号/姓名" style="width:200px" clearable suffix-icon="el-icon-search" @clear="freshloadTable"></el-input>
        <el-button @click="freshloadTable">查询</el-button>
        <el-select v-model="form.xy" filterable>
          <el-option v-for="item in xy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="form.zy" filterable>
          <el-option v-for="item in zy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <span style="font-size:16px">重复率( % ){{ xyh }}</span>
        <el-input placeholder="请输入内容" v-model="form.probability" class="input-with-select" style="width:150px" type="number">
          <el-button slot="append" icon="el-icon-search" @click="freshTable"></el-button>
        </el-input>
      </div>
      <div slot="right">
        <el-upload action="/api/degree/duc/importExcel" :show-file-list="false" style="display:inline-block;" :on-success="handleUpload" :on-error="handleError">
          <el-button type="primary" plain v-if="$btnAuthorityTest('checkdisser:import')">导入</el-button>
        </el-upload>
        <el-button type="primary" @click="pass" v-if="$btnAuthorityTest('checkdisser:allPass')">一键通过</el-button>
        <el-button type="danger" @click="returnpass" v-if="$btnAuthorityTest('checkdisser:allBack')">一键退回</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="学号" prop="studentNumber"> </el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="学院"></el-table-column>
      <el-table-column prop="majorName" label="专业"></el-table-column>
      <el-table-column prop="grade" label="年级"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column label="重复率">
        <template slot-scope="scope">
          <span v-if="parseInt(scope.row.cfl) > parseInt(15)" style="color:red">{{ scope.row.cfl }}</span><span v-else>{{ scope.row.cfl }}</span><i v-if="scope.row.cfl">%</i>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="loadTable" v-if="loadingpagination"></pagination>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  components: {
    searchcomponment,
    pagination
  },
  name: "dqrlist",
  data() {
    return {
      xyh: ">",
      form: {
        // 模糊搜索内容
        searchcontent: "",
        // 学院
        xy: "",
        // 专业
        zy: "",
        probability: 0
      },
      //   学院下拉框
      xy: [],
      //   专业下拉框
      zy: [],
      total: 0,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      loading2: false,
      //   刷新分页组件
      loadingpagination: true,
      reg: /^(\d|[1-9]\d|100)(\.\d{1,2})?$/,
      multipleSelection: [],
      recheck: [],
      // 查重按钮
      recheckload: false
    };
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.xy": {
      handler: function(val) {
        const tmp = this.xy.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.zy = tmp.children;
        this.form.zy = this.zy[0].value;
        this.freshloadTable();
      }
    },
    "form.zy": {
      handler: function(val) {
        this.freshloadTable();
      }
    }
  },
  methods: {
    freshTable() {
      if (!this.reg.test(this.form.probability)) {
        return this.$message.error("重复率输入有误");
      } else {
        this.freshloadTable();
      }
    },
    // 导入按钮事件
    handleUpload(res) {
      if (res.code == 200 && res.message) {
        this.$message.success(res.message);
      } else {
        this.$message.error(res.message);
        // 重新申请数据，取消加载状态显示
      }
      this.freshloadTable();
    },
    // 导入出错
    handleError(err) {
      console.log(err);
      this.$message.error("导入失败，请重试");
    },
    returnpass() {
      var multipleSelection = [...this.multipleSelection];
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行通过操作");
      }
      var flag = true;
      this.multipleSelection.forEach(element => {
        if (flag) {
          if (element.cfl == null || !element.cfl) {
            this.$message.error("所选论文尚未查重，请先查重再审核!");
            flag = false;
          }
        }
      });
      if (flag) {
        this.$prompt("是否退回所有已选论文？", "一键退回", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          inputPlaceholder: "请输入退回原因",
          inputPattern: /\S/,
          inputErrorMessage: "请填写退回原因"
        })
          .then(({ value }) => {
            multipleSelection.forEach(element => {
              delete element.cfl;
            });
            this.$http
              .put("api/degree/duc/batchBack1", {
                comment: value,
                dtos: multipleSelection
              })
              .then(res => {
                if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: "error"
                  });
                } else {
                  this.$message({
                    message: res.data.message,
                    type: "success"
                  });
                  this.freshloadTable();
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "error",
              message: "取消输入"
            });
          });
      }
      console.log(222);
    },
    // 刷新列表
    freshloadTable() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
      }, 100);
      this.loadTable();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    pass() {
      var arrform = [];
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行通过操作");
      }
      var flag = true;
      this.multipleSelection.forEach(element => {
        if (flag) {
          if (element.cfl == null || !element.cfl) {
            this.$message.error("所选论文尚未查重，请先查重再审核!");
            flag = false;
          }
        }
      });
      if (flag) {
        return this.$confirm("是否通过所有已选论文？", "一键通过", {
          confirmButtonText: "确定",
          cancelButtonText: "取消"
        })
          .then(() => {
            this.multipleSelection.forEach(item => {
              arrform.push(item.lcId);
            });
            this.$http
              .put("api/degree/duc/updateVariable", arrform)
              .then(res => {
                if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: "error"
                  });
                } else {
                  this.$message({
                    message: res.data.message,
                    type: "success"
                  });
                  this.freshloadTable();
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "error",
              message: "已取消"
            });
          });
      }
    },
    handleSelectionChange(rows) {
      // 查重数组
      this.recheck = [];
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push({
            lcId: row.executionId,
            taskId: row.taskId,
            cfl: row.cfl
          });
          this.recheck.push(row.executionId);
        });
      }
    },
    loadTable() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/duc/toAudit", {
          collegeCode: this.form.xy,
          majorCode: this.form.zy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.form.searchcontent,
          type: "2",
          repetitiveRate: this.form.probability
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        console.log(res);
        // 学院与专业的联动
        this.xy = res.data.data;
        this.zy = this.xy[0].children;
      });
    }
  },
  created() {
    this.loadDeptSelect();
    this.loadTable();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    this.tableData.forEach(element => {
      this.$set(element, "recking", false);
    });
  }
};
</script>

<style lang="scss" scoped>
.dqrlist {
  width: 100%;
  .collegebtn {
    background: #fff;
    color: #409eff;
  }
}
</style>
