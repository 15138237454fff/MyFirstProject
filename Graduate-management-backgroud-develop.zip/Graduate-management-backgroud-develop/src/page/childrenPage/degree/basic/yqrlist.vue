<template>
  <div class="dqrlist">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="form.searchcontent" placeholder="请输入学号/姓名" style="width:200px" clearable suffix-icon="el-icon-search" @clear="freshtable"></el-input>
        <el-button @click="freshtable">查询</el-button>
        <el-select v-model="form.xy" placeholder="全部学院" filterable>
          <el-option v-for="item in xy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="form.zy" placeholder="全部专业" filterable>
          <el-option v-for="item in zy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right"></div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column prop="xh" label="学号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="xymc" label="学院"></el-table-column>
      <el-table-column prop="zymc" label="专业"></el-table-column>
      <el-table-column prop="nj" label="年级"></el-table-column>
      <el-table-column prop="pycc" label="培养层次"></el-table-column>
      <el-table-column prop="xslb" label="学生类别"></el-table-column>
      <el-table-column prop="ds" label="导师"></el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="loadaTable" v-if="loadingpagination"></pagination>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  components: {
    searchcomponment,
    pagination
  },
  name: "dqrlist",
  data() {
    return {
      form: {
        // 模糊搜索内容
        searchcontent: "",
        // 学院
        xy: "",
        // 专业
        zy: ""
      },
      //   学院下拉框
      xy: [],
      //   专业下拉框
      zy: [],
      total: 0,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      loading2: false,
      //   刷新分页组件
      loadingpagination: true
    };
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.xy": {
      handler: function(val) {
        const tmp = this.xy.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.zy = tmp.children;
        this.form.zy = this.zy[0].value;
        this.freshtable();
      }
    },
    "form.zy": {
      handler: function(val) {
        this.freshtable();
      }
    }
  },
  methods: {
    freshtable() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.loadaTable();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    handleSelectionChange() {},
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        // 学院与专业的联动
        this.xy = res.data.data;
        this.zy = res.data.data[0].children;
      });
    },
    loadaTable() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/plea/list", {
          xydm: this.form.xy,
          zydm: this.form.zy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          status: "1",
          query: this.form.searchcontent
        })
        .then(res => {
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 1000);
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  created() {
    this.loadDeptSelect();
    this.loadaTable();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style lang="scss" scoped>
.dqrlist {
  width: 100%;
  .collegebtn {
    background: #fff;
    color: #409eff;
  }
  .dialogfooter {
    text-align: center;
  }
}
</style>
