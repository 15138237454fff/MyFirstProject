<template>
  <div class="paperAnalysisDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="index"
          align="center"
          label="序号"
          :width="60"
        ></el-table-column>
        <el-table-column
          prop="tmmc"
          label="题目"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="tmlx"
          label="题目类型"
          align="center"
          :width="120"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ getListValue(scope.row.tmlx, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="总票数" align="center" :width="120">
          <template slot-scope="scope">
            {{ scope.row.votes }}
          </template>
        </el-table-column>
        <el-table-column label="结果统计" align="center" :width="400">
          <template slot-scope="scope">
            <div
              v-if="scope.row.tmlx !== 3"
              :ref="`pie${scope.$index}`"
              style="width:400px;height:150px;"
            ></div>
            <div v-else style="width:400px;height:150px;"></div>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
var echarts = require("echarts");
export default {
  name: "paperAnalysisDetail",
  props: {
    id: {
      type: String
    }
  },
  data() {
    return {
      tableData: [],
      loading: false,
      typeOptions: [
        { label: "单选题", value: 1 },
        { label: "多选题", value: 2 },
        { label: "问答题", value: 3 }
      ],
      tableHeight: null
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 200;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 200;
      })();
    };
    this.loadTable();
  },
  methods: {
    drawPie(index) {
      console.log(this.$refs[`pie${index}`]);
      var myChart = echarts.init(this.$refs[`pie${index}`]);
      let data = this.tableData[index].xxnr,
        total = data.reduce((prev, el) => {
          return prev + el.count;
        }, 0);
      const option = {
        tooltip: {
          trigger: "item",
          formatter: params => {
            let tmpObj = data.find(el => {
              return el.option === params.name;
            });
            if (!tmpObj) {
              return params.name;
            }
            return `${tmpObj.option}. ${tmpObj.content}   ${tmpObj.count} (${(
              (tmpObj.count / total) *
              100
            ).toFixed(0)}%)`;
          }
        },
        legend: {
          orient: "vertical",
          right: 20,
          data: data.map(el => {
            return {
              name: el.option,
              icon: "roundRect"
            };
          }),
          formatter: name => {
            let tmpObj = data.find(el => {
              return el.option === name;
            });
            if (!tmpObj) {
              return name;
            }
            tmpObj = { ...tmpObj };
            let maxLength = 5;
            if (tmpObj.content.length > maxLength) {
              tmpObj.content = tmpObj.content.slice(0, maxLength + 1) + "...";
            }
            return `{a|${name}. ${tmpObj.content}}  {b|${tmpObj.count} (${(
              (tmpObj.count / total) *
              100
            ).toFixed(0)}%)}`;
          },
          tooltip: {
            show: true,
            formatter: params => {
              let tmpObj = data.find(el => {
                return el.option === params.name;
              });
              if (!tmpObj) {
                return params.name;
              }
              return `${tmpObj.option}. ${tmpObj.content}`;
            }
          },
          textStyle: {
            rich: {
              a: {
                width: 100
              },
              b: {
                color: "#409dff",
                align: "right",
                verticalAlign: "bottom"
              }
            }
          }
        },
        color: [
          "#ef5350",
          "#FFA726",
          "#FFEE58",
          "#66BB6A",
          "#26C6DA",
          "#42A5F5"
        ],
        series: [
          {
            name: "问卷统计",
            type: "pie",
            center: ["20%", "50%"],
            radius: ["60%", "80%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: false,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: data.map(el => {
              return { name: el.option, value: el.count };
            })
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$http
        .get(`/api/degree/qsc/${this.id}`)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data;
          this.tableData.forEach((el, index) => {
            if (el.tmlx !== 3) {
              this.$nextTick(() => {
                this.drawPie(index);
              });
            }
          });
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.paperAnalysisDetail {
  padding-top: 10px;
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
}
</style>
