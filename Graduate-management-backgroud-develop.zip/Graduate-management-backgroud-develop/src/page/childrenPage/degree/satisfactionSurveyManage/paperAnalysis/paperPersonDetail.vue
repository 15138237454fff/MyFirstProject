<template>
  <div class="paperPersonDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="index"
          align="center"
          label="序号"
          :width="80"
        ></el-table-column>
        <el-table-column
          prop="tmmc"
          label="题目"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="tmlx"
          label="题目类型"
          align="center"
          :width="120"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ getListValue(scope.row.tmlx, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="学生回答" align="left">
          <template slot-scope="scope">
            <template v-if="scope.row.tmlx !== 3">
              {{
                scope.row.xxnr
                  .filter(el => {
                    return scope.row.result.includes(el.option);
                  })
                  .map(el => {
                    return `${el.option}. ${el.content}`;
                  })
                  .join("&nbsp;&nbsp;&nbsp;&nbsp;")
              }}
            </template>
            <template v-else> {{ scope.row.result }} </template>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";

export default {
  name: "paperPersonDetail",
  props: {
    id: {
      type: String
    },
    xh: {}
  },
  data() {
    return {
      tableData: [],
      loading: false,
      typeOptions: [
        { label: "单选题", value: 1 },
        { label: "多选题", value: 2 },
        { label: "问答题", value: 3 }
      ],
      tableHeight: null
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 200;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 200;
      })();
    };
    this.loadTable();
  },
  methods: {
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$http
        .get(`/api/degree/qsc/${this.id}/${this.xh}`)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.paperPersonDetail {
  padding-top: 10px;
  .box {
    /deep/ .el-table td.is-left {
      text-align: left !important;
    }
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
}
</style>
