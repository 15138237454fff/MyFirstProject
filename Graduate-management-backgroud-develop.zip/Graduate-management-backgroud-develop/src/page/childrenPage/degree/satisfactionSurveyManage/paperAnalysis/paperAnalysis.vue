<template>
  <div class="paperAnalysis">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称/申请人"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.collegeCode" @change="initLoadTable;">
          <el-option
            v-for="(item, index) in xyList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.grade" @change="initLoadTable">
          <el-option
            v-for="(item, index) in njList"
            :key="index"
            :label="item + ' 级'"
            :value="item"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.id" @change="initLoadTable">
          <el-option
            v-for="(item, index) in timeList"
            :key="index"
            :label="
              `${$tagTime(item.startTime, 'yyyy-MM-dd')} 至 ${$tagTime(
                item.endTime,
                'yyyy-MM-dd'
              )}`
            "
            :value="item.id"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickToAnalysis"
          type="primary"
          v-if="$btnAuthorityTest('paperAnalysis:analysis')"
          >统计</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          prop="xh"
          label="学号"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="xsxm"
          label="姓名"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="xymc"
          label="学院"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="zy"
          label="专业"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="pycc"
          label="培养层次"
          align="center"
          :width="120"
        >
        </el-table-column>
        <el-table-column
          prop="cjsj"
          label="提交时间"
          align="center"
          :width="150"
        >
        </el-table-column>
        <el-table-column
          prop="nodeName"
          label="查看详情"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              @click="clickToDetail(scope.row.xh)"
              >查看详情</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "paperAnalysis",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 15, // 分页中每页显示条数
        query: "",
        collegeCode: "",
        grade: "",
        id: ""
      },
      xyList: [],
      njList: [],
      timeList: [],
      loading: false,
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    Promise.all([
      this.requireXyZyList(),
      this.requireTimeList(),
      this.requireNjList()
    ]).then(this.loadTable);
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  },
  methods: {
    clickToAnalysis() {
      if (this.limitQuery.id === "") {
        this.$message.error("请选择要查看的问卷");
        return;
      }
      this.$router.push(`/paperAnalysisDetail/${this.limitQuery.id}`);
    },
    clickToDetail(xh) {
      this.$router.push(`/paperPersonDetail/${this.limitQuery.id}/${xh}`);
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/degree/qsc/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    },
    // 请求学院专业列表
    requireXyZyList() {
      return new Promise((resolve, reject) => {
        this.$http
          .get(`api/system/dict/noPermission`)
          .then(res => {
            let data = res.data.data;
            if (!Array.isArray(data)) {
              console.error("专业列表数据获取失败");
              return false;
            }
            this.xyList = data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    requireNjList() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("api/degree/plea/stuNj")
          .then(res => {
            // 年级
            if (!Array.isArray(res.data.data)) {
              return this.$message.error("数据异常,请刷新");
            } else {
              this.njList = res.data.data.sort((a, b) => b - a);
              this.limitQuery.grade = this.njList[0];
              resolve();
            }
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    requireTimeList() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("api/degree/question/select")
          .then(res => {
            // 年级
            if (!Array.isArray(res.data.data)) {
              return this.$message.error("数据异常,请刷新");
            } else {
              this.timeList = res.data.data;
              if (this.timeList.length === 0) return;
              this.limitQuery.id = this.timeList[0].id;
              resolve();
            }
          })
          .catch(err => {
            reject(err);
          });
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.paperAnalysis {
  margin-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      & > :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 12px;
  }
  .el-date-editor .el-range__icon,
  .el-date-editor .el-range-separator {
    line-height: 24px;
  }
}
</style>
