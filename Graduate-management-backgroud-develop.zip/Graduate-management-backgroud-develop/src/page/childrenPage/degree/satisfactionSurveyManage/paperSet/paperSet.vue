<template>
  <div class="paperSet">
    <my-breadcrumb>
      <div slot="left">
        <span v-if="isPublish && tipObj.kssj !== '' && tipObj.jssj !== ''">{{
          `当前为已发布状态，学生接收问卷时间为：${this.$tagTime(
            tipObj.kssj,
            "yyyy-MM-dd"
          )} 至 ${this.$tagTime(tipObj.jssj, "yyyy-MM-dd")}`
        }}</span>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAdd"
          type="primary"
          v-if="!isPublish && $btnAuthorityTest('paperSet:add')"
          >添加</el-button
        >
        <el-button
          @click="clickPublish"
          :plain="true"
          type="primary"
          v-if="!isPublish && $btnAuthorityTest('paperSet:publish')"
          >发布问卷</el-button
        >
        <el-button
          @click="clickUnPublish"
          :plain="true"
          type="primary"
          v-else-if="isPublish && $btnAuthorityTest('paperSet:publish')"
          >取消发布</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="index"
          align="center"
          :width="50"
          label="序号"
        ></el-table-column>
        <el-table-column
          prop="tmmc"
          label="题目"
          align="center"
          show-overflow-tooltip
          :width="400"
        ></el-table-column>
        <el-table-column
          prop="tmlx"
          label="题目类型"
          align="center"
          :width="100"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ getListValue(scope.row.tmlx, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="fbdx"
          label="是否必填"
          align="center"
          :width="100"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.sfbt === 1 ? "是" : "否" }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="pjdja"
          label="选项"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-for="(item, index) of scope.row.xxnr"
              :key="index"
              style="margin-right:10px;"
            >
              {{ `${item.option}. ${item.content}` }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" :width="200">
          <template slot-scope="scope">
            <template v-if="$btnAuthorityTest('paperSet:modify')">
              <span
                class="orange under-line cursor-pointer"
                v-if="!isPublish"
                @click="clickModify(scope.row)"
                >修改</span
              >
              <span v-else class="grey under-line">修改</span>
            </template>
            <span>|</span>
            <template v-if="$btnAuthorityTest('paperSet:delete')">
              <span
                class="red under-line cursor-pointer"
                v-if="!isPublish"
                @click="clickDelete(scope.row.id)"
                >删除</span
              >
              <span v-else class="grey under-line">删除</span>
            </template>
            <span>|</span>
            <div
              v-if="$btnAuthorityTest('paperSet:sort')"
              style="display:inline-block;"
            >
              <img
                src="../../../../../assets/greyArrow.png"
                class="topArrow"
                v-if="isPublish || scope.$index === 0"
              />
              <span v-else @click="clickItemMove(scope.row.id, 1)">
                <img
                  src="../../../../../assets/arrow.png"
                  class="topArrow cursor-pointer"
                />
              </span>
              <span
                v-if="!isPublish && scope.$index !== tableData.length - 1"
                @click="clickItemMove(scope.row.id, 2)"
              >
                <img
                  src="../../../../../assets/arrow.png"
                  class="bottomArrow cursor-pointer"
                />
              </span>
              <img
                src="../../../../../assets/greyArrow.png"
                v-else
                class="bottomArrow"
              />
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <template v-if="modalOption.key !== 'publish'">
        <div class="modal-modify">
          <div class="row">
            <span class="required">题目名称：</span>
            <el-input
              size="large"
              v-model="formData.tmmc"
              placeholder="请输入"
            ></el-input>
          </div>
          <div class="row">
            <div>
              <span class="required">题目类型：</span>
              <el-select v-model="formData.tmlx">
                <el-option label="单选题" :value="1">单选题</el-option>
                <el-option label="多选题" :value="2">多选题</el-option>
                <el-option label="问卷题" :value="3">问卷题</el-option>
              </el-select>
            </div>
            <div style="margin-left:40px;">
              <span class="required">是否必填：</span>
              <el-radio-group v-model="formData.sfbt" size="large">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </div>
          </div>
          <el-table
            :data="formData.xxnr"
            :border="true"
            class="question-table"
            v-if="formData.tmlx !== 3"
          >
            <el-table-column
              align="center"
              prop="option"
              label="选项"
              :width="80"
            ></el-table-column>
            <el-table-column align="center" label="选项">
              <template slot-scope="scope">
                <el-input
                  size="large"
                  v-model="scope.row.content"
                  placeholder="请输入"
                  class="option-text"
                ></el-input>
              </template>
            </el-table-column>
            <el-table-column
              align="center"
              props="option"
              label="操作"
              :width="100"
            >
              <template slot-scope="scope">
                <div
                  @click="addRow"
                  class="add el-icon-circle-plus-outline"
                  v-if="scope.$index === formData.xxnr.length - 1"
                ></div>
                <div
                  class="reduce el-icon-remove-outline"
                  @click="reduceRow(scope.$index)"
                  v-else
                ></div>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div slot="footer">
          <el-button @click="clickCancel">取消</el-button>
          <el-button type="primary" @click="clickOk">提交</el-button>
        </div>
      </template>
      <template v-if="modalOption.key === 'publish'">
        <div class="modal-modify">
          <div class="row">
            <span class="required">请选择问卷起止时间：</span>
            <el-date-picker
              v-model="computedTime"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :picker-options="{ disabledDate }"
            >
            </el-date-picker>
          </div>
        </div>
        <div slot="footer">
          <el-button @click="clickCancel">取消</el-button>
          <el-button type="primary" @click="clickOk">发布</el-button>
        </div>
      </template>
    </my-modal>
  </div>
</template>

<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "paperSet",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      loading: false,
      tableHeight: null,
      formData: {
        tmmc: "",
        tmlx: "",
        sfbt: "",
        xxnr: [],
        startTime: "",
        endTime: ""
      },
      isPublish: window.sessionStorage.getItem("paperPublish"),
      questionId: "",
      typeOptions: [
        { label: "单选题", value: 1 },
        { label: "多选题", value: 2 },
        { label: "问答题", value: 3 }
      ],
      optionNumOption: ["A", "B", "C", "D", "E", "F"],
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: ""
      },
      tipObj: {
        kssj: "",
        jssj: ""
      }
    };
  },
  components: {
    "my-modal": myModal,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    console.log(this.isPublish);
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.requirePublishStatus();
    this.loadTable();
  },
  methods: {
    disabledDate(date) {
      return (
        this.$tagTime(date.getTime(), "yyyy-MM-dd") <
        this.$tagTime(Date.now(), "yyyy-MM-dd")
      );
    },
    requirePublishStatus() {
      this.$http.get("/api/degree/question/status").then(res => {
        let data = res.data.data;
        console.log(data);
        this.isPublish = data.publish;
        window.sessionStorage.setItem("paperPublish", data.publish);
        if (data.kssj !== null) this.tipObj.kssj = data.kssj;
        if (data.jssj !== null) this.tipObj.jssj = data.jssj;
      });
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$http
        .get("/api/degree/question/list")
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击添加
    clickAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-paperSet";
      this.clearFormData();
      this.formData.xxnr = [
        { option: "A", content: "" },
        { option: "B", content: "" },
        { option: "C", content: "" },
        { option: "D", content: "" }
      ];
    },
    // 点击前往修改页
    clickModify(row) {
      this.clearFormData();
      let { xxnr, tmmc, tmlx, sfbt, id } = row;
      this.formData.xxnr = xxnr;
      this.formData.tmmc = tmmc;
      this.formData.tmlx = tmlx;
      this.formData.sfbt = sfbt;
      this.questionId = id;
      this.modalOption.title = `修改`;
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-paperSet";
    },
    testForm() {
      if (this.modalOption.key !== "publish") {
        let { tmmc, tmlx, sfbt, xxnr } = this.formData;
        if (tmmc === "") {
          this.$message.error("请填写题目名称后，再尝试提交");
          return false;
        }
        if (tmlx === "") {
          this.$message.error("请选择项目类型后，再尝试提交");
          return false;
        }
        if (sfbt === "") {
          this.$message.error("请选择是否必填后，再尝试提交");
          return false;
        }
        if (tmlx !== 3) {
          let sign = true;
          xxnr.forEach(el => {
            if (sign && el.content === "") {
              sign = false;
              this.$message.error("请将选项内容填写完整后，再尝试提交");
            }
          });
          return sign;
        }
        return true;
      } else {
        if (this.formData.startTime === "" || this.formData.endTime === "") {
          this.$message.error("请选择问卷起止时间后，再尝试发布");
          return false;
        }
        return true;
      }
    },
    clickOk() {
      let result = this.testForm();
      if (!result) {
        return;
      }
      if (this.modalOption.key === "add") {
        this.handleAdd();
      } else if (this.modalOption.key === "modify") {
        this.handleModify();
      } else {
        console.log(1);
        this.handlePublish();
      }
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    handleAdd() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      if (this.formData.tmlx === 3) {
        this.formData.xxnr = [];
      }
      this.$http
        .post("/api/degree/question", this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("添加成功");
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    handleModify() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      if (this.formData.tmlx === 3) {
        this.formData.xxnr = [];
      }
      this.$http
        .put(`/api/degree/question/${this.questionId}`, this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("修改成功");
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    clickItemMove(id, type) {
      this.$http
        .put(`/api/degree/question/${id}/${type}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
        });
    },
    // 添加题目的选项
    addRow() {
      if (this.formData.xxnr.length > 5) {
        this.$message.error("题目中的选项不能超过6个");
        return;
      }
      this.formData.xxnr.push({
        // 选项名称
        option: "",
        // 选项内容
        content: ""
      });
      // // 重新定义选项名称
      this.formData.xxnr.forEach((el, index) => {
        el.option = this.optionNumOption[index];
      });
    },
    // 删除题目的选项
    reduceRow(index) {
      if (this.formData.xxnr.length < 3) {
        this.$message.error("题目中的选项不能少于2个");
        return;
      }
      this.formData.xxnr.splice(index, 1);
      // // 重新定义选项名称
      this.formData.xxnr.forEach((el, index) => {
        el.option = this.optionNumOption[index];
      });
    },
    // 点击删除
    clickDelete(id) {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleDelete,
        title: "删除信息",
        msgOne: "确定删除本条记录？",
        msgTwo: ""
      });
      this.questionId = id;
    },
    handleDelete(id) {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .delete(`/api/degree/question/${this.questionId}`, {})
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("删除成功");
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    // 点击发布
    clickPublish() {
      this.modalOption.title = `发布问卷`;
      this.modalOption.key = "publish";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-paperSet-publish";
    },
    handlePublish() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put("/api/degree/question/publish", {
          startTime: this.formData.startTime,
          endTime: this.formData.endTime
        })
        .then(res => {
          this.requirePublishStatus();
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("发布成功");
            this.formData.startTime = "";
            this.formData.endTime = "";
            // 清空勾选
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    clickUnPublish() {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleUnPublish,
        title: "取消发布",
        msgOne: "确定取消发布？",
        msgTwo: ""
      });
    },
    handleUnPublish() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put("/api/degree/question/unpublish")
        .then(res => {
          this.requirePublishStatus();
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("取消发布成功");
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },

    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    },
    clearFormData() {
      this.formData = {
        xxnr: [],
        tmmc: "",
        tmlx: "",
        sfbt: "",
        startTime: "",
        endTime: ""
      };
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    }
  },
  computed: {
    computedTime: {
      get() {
        return [this.formData.startTime, this.formData.endTime];
      },
      set(arr) {
        console.log(arr);
        if (arr === null) {
          arr = ["", ""];
        }
        this.formData.startTime = arr[0];
        this.formData.endTime = arr[1];
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.paperSet {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.topArrow,
.bottomArrow {
  width: 20px;
  height: 20px;
  vertical-align: middle;
}
.bottomArrow {
  transform: rotate(180deg);
}
/deep/ .el-table td.is-left {
  text-align: left !important;
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
.modal-paperSet {
  width: 600px;
  .el-radio:not(:last-child) {
    margin-right: 10px;
  }
  .row {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
    & > .el-input {
      width: 450px;
    }
    & > span:first-child {
      display: block;
      line-height: 34px;
      width: 90px;
      text-align: left;
    }
  }
  .add,
  .reduce {
    color: red;
    font-size: 24px;
  }
  .add {
    color: #409eff;
  }
}
.el-dialog.modal-paperSet-publish {
  width: 566px;
  .el-dialog__body {
    min-height: auto !important;
    padding: 30px 20px !important;
  }
  .el-date-editor .el-range__icon,
  .el-date-editor .el-range-separator {
    line-height: 24px;
  }
}
</style>
