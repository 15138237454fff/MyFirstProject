<template>
  <div class="qualification">
    <template v-if="!ctrlloter">
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="待送审账号" name="first">
            <yxlwpstables :center="ctrlloter" @formson="fromsonFn" v-if="activeName =='first'"></yxlwpstables>
          </el-tab-pane>
          <el-tab-pane label="已送审账号" name="second">
            <yxlwpstable :center="ctrlloter" @formson="fromsonFn" v-if="activeName =='second'"></yxlwpstable>
          </el-tab-pane>
        </el-tabs>
      </div>
    </template>
    <yxlwpslist v-else-if="ctrlloter" @formson="fromsonFn" :activeName="activeName"></yxlwpslist>
  </div>
</template>

<script>
import yxlwpstable from './yxlwpstable';
import yxlwpstables from './yxlwpstables';
import yxlwpslist from './yxlwpslist';
export default {
  name: 'yxlwps',
  data() {
    return {
      activeName: 'first',
      ctrlloter: false
    }
  },
  components: {
    yxlwpstable,
    yxlwpstables,
    yxlwpslist
  },
  methods: {
    handleClick(tab, event) {},
    fromsonFn(val) {
      this.ctrlloter = val
    }
  }
}
</script>

<style lang="scss" scoped>
.qualification {
  width: 100%;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      height: 42px;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 130px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
    /deep/ .el-tabs__active-bar {
      width: 120px !important;
      margin-bottom: 0px;
    }
  }
}
</style>

