<template>
  <div class="learning_code1">
    <el-row>
      <el-col :span="24">
        <div class="grid-content bg-purple-dark">
          <el-button type="text" icon="el-icon-refresh-left" @click="returncall">返回</el-button>
        </div>
      </el-col>
    </el-row>
    <table>
      <thead>
        <tr>
          <th style="height:60px; font-size: 20px;" colspan="6">浙江财经大学研究生学位资格申请</th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>学生基本信息</td>
      </tr>
      <tr>
        <td class="listcss">学号</td>
        <td>{{content.xh}}</td>
        <td class="listcss">姓名</td>
        <td>{{content.xm}}</td>
        <td class="listcss">性别</td>
        <td>{{content.xbm | xbm}}</td>
      </tr>
      <tr>
        <td class="listcss">出生年月</td>
        <td>{{content.csrq}}</td>
        <td class="listcss">身份证号</td>
        <td>{{content.sfzh}}</td>
        <td class="listcss">学生类别</td>
        <td>{{content.xslbmc}}</td>
      </tr>
      <tr>
        <td class="listcss">学院</td>
        <td>{{content.yxsmc}}</td>
        <td class="listcss">专业</td>
        <td>{{content.zy}}</td>
        <td class="listcss">导师</td>
        <td>{{content.dsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">取得总学分</td>
        <td><span style="color:#409EFF;margin-right:5px">{{content.hdzxf}}</span>(>20)</td>
        <td class="listcss">学位课总学分</td>
        <td><span style="color:#409EFF;margin-right:5px">{{content.xwkzxf}}</span>(>20)</td>
        <td class="listcss">学位课平均分</td>
        <td>{{content.xwkzpjf}}</td>
      </tr>
      <tr>
        <td class="listcss">最后学历</td>
        <td>{{content.zhxlmc}}</td>
        <td class="listcss">已获学位</td>
        <td>{{content.qxwmc}}</td>
        <td class="listcss">已获学位一级学科</td>
        <td>{{content.qxwxk}}</td>
      </tr>
      <tr>
        <td class="listcss">已获学位证书号</td>
        <td>{{content.qxwzsh}}</td>
        <td class="listcss">学位授予日期</td>
        <td>{{content.xwsyrq}}</td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>就业信息</td>
      </tr>
      <tr>
        <td class="listcss">单位名称</td>
        <td>{{menucont.jydw}}</td>
        <td class="listcss">单位性质</td>
        <td>{{menucont.dwxz}}</td>
        <td class="listcss">单位所在地</td>
        <td>{{menucont.dwszd}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>取得代表性成果</td>
      </tr>
      <tr>
        <td class="listcss">序号</td>
        <td class="listcss">成果名称</td>
        <td class="listcss">成果类型</td>
        <td class="listcss">时间</td>
        <td class="listcss" colspan="2">相关附件</td>
      </tr>
      <tr v-for="(item,index) in menucont.dbxcg">
        <td>{{index+1}}</td>
        <td>{{item.resultsName}}</td>
        <td>{{item.resultsType}}</td>
        <td>{{item.applyDate}}</td>
        <td colspan="2" style="color:#409EFF;" @click="open(item.attachment.url)">{{item.attachment.fileName}}</td>
      </tr>
    </table>
    <div class="divcss5"></div>
    <el-steps :active="list.length" :space="200" style="margin-bottom:20px">
      <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
        <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
        <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
        <span slot="description" class="comment"> {{item.startTime}}</span>
        <!-- <div slot="description" class="comment"><span :class="item.state == '0'? sstt[0] : item.state == '1'?sstt[2] :item.state == '2'?sstt[1]:sstt[0]">{{item.state | state}}</span></div> -->
        <div slot="description" class="comment" v-if="item.comment">审核意见：{{item.comment}}</div>
      </el-step>
    </el-steps>
    <div class="divcss5" v-if="activeName !=='second'"></div>
    <el-form ref="form" :model="sizeForm" label-width="120px" size="mini" v-if="activeName !=='second'">
      <el-form-item label="审核：">
        <el-radio-group v-model="sizeForm.radio1">
          <el-radio-button :label="item.value" v-for="(item,index) in check" :key="index">{{item.label}}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：">
        <el-input type="textarea" placeholder="请输入内容" v-model="sizeForm.textarea" maxlength="30" show-word-limit style="width:90%">
        </el-input>
        <el-button type="primary" style="width:100px;" @click="save">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import line from "./line";
export default {
  props: {
    activeName: String
  },
  components: {
    line
  },
  name: "learningcode1",
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ""
      },
      content: {},
      menucont: {},
      list: [],
      check: [
        {
          value: 1,
          label: "通过"
        },
        {
          value: 0,
          label: "不通过"
        }
      ],
      sstt: ["ss1", "ss2", "ss3"]
    };
  },
  mounted() {
    this.userlist();
    this.executionId();
  },

  filters: {
    xbm(val) {
      switch (val) {
        case 1:
          return "男";
        case 2:
          return "女";
        case 0:
          return "未知性别";
        case 9:
          return "未说明性别";
        default:
          break;
      }
    },
    state(val) {
      if (val == 0) {
        return "不通过";
      } else if (val == 1) {
        return "通过";
      } else if (val == 2) {
        return "待审核";
      }
    }
  },
  methods: {
    open(val) {
      window.open(val);
    },
    returncall() {
      this.$emit("formson", false);
    },
    save() {
      this.$http
        .post("api/degree/degree/audit", {
          taskId: this.$storage.get("executionId_xw").taskId,
          check: this.sizeForm.radio1,
          comment: this.sizeForm.textarea
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$emit("formson", false);
          }
        });
    },
    userlist() {
      this.$http
        .get(
          "api/degree/degree/student/basic/" +
            this.$storage.get("executionId_xw").studentNumber
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            if (!res.data.data) {
              this.$message({
                message: "该数据出现异常",
                type: "error"
              });
              this.$emit("formson", false);
            } else {
              this.content = res.data.data;
              this.$storage.addObjectKey(res.data.data, this.content);
            }
          }
        });
      this.$http
        .get(
          `/api/degree/degree/${
            this.$storage.get("executionId_xw").studentNumber
          }`
        )
        .then(res => {
          this.menucont = res.data.data;
          this.$storage.addObjectKey(res.data.data, this.menucont);
        });
    },

    executionId() {
      this.$http
        .get(
          "api/degree/degree/history/" +
            this.$storage.get("executionId_xw").executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.list = res.data.data;
          }
        });
    }
  }
};
</script>
<style scoped lang="scss">
.learning_code1 {
  .bg-purple-dark {
    background: #eeeeee;
    height: 60px;
    line-height: 60px;
    font-size: 16px;
    padding-left: 20px;
  }
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  .ss1 {
    color: red;
  }
  .ss2 {
    color: rgb(255, 153, 0);
  }
  .ss3 {
    color: #409eff;
  }
  .divcss5 {
    height: 1px;
    width: 100%;
    border-bottom: 1px dashed #e0e0e0;
    margin: 10px 0 10px 0;
  }
}
</style>


