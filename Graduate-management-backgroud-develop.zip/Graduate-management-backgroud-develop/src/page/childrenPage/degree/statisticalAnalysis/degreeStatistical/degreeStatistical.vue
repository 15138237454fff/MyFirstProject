<template>
  <div class="courseInfoStatistical">
    <template v-if="!psDetailShow && !lwDetailShow">
      <my-breadcrumb>
        <div slot="left">
          <el-input placeholder="请输入学号/姓名" prefix-icon="el-icon-search" clearable @clear="loadTable" v-model="limitQuery.query" @keyup.enter.native="initLoadTable"></el-input>
          <el-button @click="initLoadTable">查询</el-button>
          <el-select v-model="limitQuery.collegeCode" @change="
              () => {
                limitQuery.majorCode = '';
                initLoadTable();
              }
            ">
            <el-option v-for="(item, index) in xyList" :key="index" :label="item.label" :value="item.value"></el-option>
          </el-select>
          <el-select v-model="limitQuery.majorCode" @change="initLoadTable">
            <el-option v-for="(item, index) in zyList" :key="index" :label="item.label" :value="item.value"></el-option>
          </el-select>
          <el-select v-model="limitQuery.year" @change="initLoadTable">
            <el-option v-for="(item, index) in njList" :key="index" :label="item + ' 级'" :value="item"></el-option>
          </el-select>
        </div>
        <!-- 前往评教和查看详情时的返回按钮 -->
        <div slot="right"></div>
      </my-breadcrumb>
      <div class="box">
        <el-table :data="tableData" border style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading" element-loading-text="加载中" element-loading-spinner="el-icon-loading" ref="box">
          <el-table-column prop="xh" label="学号" align="center" :width="120" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="xsxm" label="姓名" align="center" :width="100" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="xymc" label="学院" align="center" :width="120" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="zy" label="专业" align="center" :width="120" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="sznj" label="年级" align="center" :width="80" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="xslbmc" label="学生类别" align="center" :width="100" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="dsxm" label="导师" align="center" :width="100" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="xwlwtm" label="论文中文题目" align="center" show-overflow-tooltip>
          </el-table-column>
          <el-table-column label="送审级别" align="center" :width="120">
            <template slot-scope="scope">
              <span>{{ scope.row.ssjb | ssjbFilter }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="pscj" label="评审成绩" align="center" show-overflow-tooltip>
            <template slot-scope="scope">
              <span v-for="(item, index) of scope.row.pscj.split(',')" :key="index" :class="item > 70 ? 'blue' : 'red'">
                {{ item }}
              </span>
            </template>
          </el-table-column>
          <el-table-column prop="tycs" label="推优次数" align="center" :width="80" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="yjszdgzl" label="查看评审详情" align="center" :width="120">
            <template slot-scope="scope">
              <span class="blue under-line cursor-pointer" v-if="$btnAuthorityTest('degreeStatistical:view')" @click="clickToDetail(scope.row)">查看</span>
            </template>
          </el-table-column>
          <el-table-column prop="yjszdgzl" label="论文终稿" align="center" :width="120">
            <template slot-scope="scope">
              <template v-if="$btnAuthorityTest('degreeStatistical:view')">
                <span class="blue under-line cursor-pointer" v-if="scope.row.click === 1" @click="clickToFinal(scope)">论文终稿</span>
                <span v-else class="grey">论文终稿</span>
              </template>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!-- 分页 -->
      <my-pagination @paginate="handlePaginate" :pageSize="limitQuery.pageSize" :pageNum="limitQuery.pageNum" :msgCount="msgCount"></my-pagination>
    </template>
    <template v-if="psDetailShow">
      <xw-result @formson="psDetailShow = false"></xw-result>
    </template>
    <template v-if="lwDetailShow">
      <lw-detail @formson="lwDetailShow = false"></lw-detail>
    </template>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import xwResult from "../../xwlwcj/xwResult";
import lwDetail from "./lwDetail";
export default {
  name: "courseInfoStatistical",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        collegeCode: "",
        majorCode: "",
        year: null
      },
      psDetailShow: false,
      lwDetailShow: false,
      loading: false,
      xyList: [],
      njList: [],
      selectedHistoryList: [],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "xw-result": xwResult,
    "lw-detail": lwDetail
  },
  mounted() {
    this.requireXyZyList();
    this.requireNjList();
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/degree/statistics/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击查看评审详情
    clickToDetail(row) {
      this.$http
        .get(`api/degree/duc/selectCheckInfo?xh=${row.xh}&lx=${row.lx}`)
        .then(res => {
          if (res.data.data !== null) {
            var content = res.data.data;
            this.$storage.addObjectKey(res.data.data, content);
            this.$stores.commit("DEGREE", {
              content: content,
              row: row
            });
            setTimeout(() => {
              this.psDetailShow = true;
            }, 50);
          } else {
            this.$message.error("数据异常,请刷新重试");
          }
        });
    },
    // 点击查看论文终稿
    clickToFinal(scope) {
      this.$http.get(`api/degree/pfc/${scope.row.xh}`).then(res => {
        if (res.data.data !== null) {
          var content = res.data.data;
          this.$storage.addObjectKey(res.data.data, content);
          this.$stores.commit("DEGREE", {
            content: content,
            row: scope.row
          });
          setTimeout(() => {
            this.lwDetailShow = true;
          }, 50);
        } else {
          this.$message.error("数据异常,请刷新重试");
        }
      });
    },
    // 请求学院专业列表
    requireXyZyList() {
      this.$http.get(`/api/system/dict/noPermission`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.xyList = data;
      });
    },
    requireNjList() {
      this.$http.get("api/degree/plea/stuNj").then(res => {
        // 年级
        if (!Array.isArray(res.data.data)) {
          return this.$message.error("数据异常,请刷新");
        } else {
          this.njList = res.data.data.sort((a, b) => b - a);
          this.limitQuery.year = this.njList[0];
          this.loadTable();
        }
      });
    }
  },
  filters: {
    ssjbFilter(val) {
      console.log(val);
      val = "" + val;
      switch (val) {
        case "0":
          return "校级送审";
        case "1":
          return "院级送审";
        default:
          return "";
      }
    }
  },
  computed: {
    zyList() {
      let tmpObj = this.xyList.find(el => {
        return el.value === this.limitQuery.collegeCode;
      });
      if (!tmpObj) {
        return [];
      }
      return tmpObj.children;
    }
  }
};
</script>

<style lang="scss" scoped>
.courseInfoStatistical {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
