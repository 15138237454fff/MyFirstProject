<template>
  <div class="ysstable">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="form.searchcontent" placeholder="请输入学号/姓名" style="width:200px" clearable suffix-icon="el-icon-search" @clear="freshloadTable"></el-input>
        <el-button @click="freshloadTable">查询</el-button>
        <el-select v-model="form.xy" placeholder="全部学院" filterable>
          <el-option v-for="item in xy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="form.zy" placeholder="全部专业" filterable>
          <el-option v-for="item in zy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="form.year" placeholder="全部年级" filterable>
          <el-option v-for="item in dictgrade" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right"></div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column prop="studentNumber" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="学院"></el-table-column>
      <el-table-column prop="majorName" label="专业"></el-table-column>
      <el-table-column prop="grade" label="年级"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column prop="score" label="答辩成绩"></el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="loadTable" v-if="loadingpagination"></pagination>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  components: {
    searchcomponment,
    pagination
  },
  name: "ysstable",
  data() {
    return {
      form: {
        // 模糊搜索内容
        searchcontent: "",
        // 学院
        xy: "",
        // 专业
        zy: "",
        year: ""
      },
      //   学院下拉框
      xy: [],
      //   专业下拉框
      zy: [],
      total: 0,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      loading2: false,
      //   刷新分页组件
      loadingpagination: true,
      reg: /^(\d|[1-9]\d|100)(\.\d{1,2})?$/,
      multipleSelection: [],
      dictgrade: []
    };
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.xy": {
      handler: function(val) {
        const tmp = this.xy.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.zy = tmp.children;
        this.form.zy = this.zy[0].value;
        this.freshloadTable();
      }
    },
    "form.zy": {
      handler: function() {
        this.freshloadTable();
      }
    },
    "form.year": {
      handler: function() {
        this.freshloadTable();
      }
    }
  },
  methods: {
    freshloadTable() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.loadTable();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        // 学院与专业的联动
        this.xy = res.data.data;
        this.zy = this.xy[0].children;
      });
      this.$http.get("api/system/dict/select/grade").then(res => {
        // 年级
        if (!Array.isArray(res.data.data)) {
          return this.$message.error("数据异常,请刷新");
        } else {
          this.dictgrade = res.data.data.reverse();
          this.dictgrade.unshift({ value: "", label: "所有年级" });
        }
      });
    },
    loadTable() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false
      // }, 1000)
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/duc/replyList", {
          collegeCode: this.form.xy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.form.searchcontent,
          majorCode: this.form.zy,
          type: "1",
          grade: this.form.year
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  created() {
    this.loadDeptSelect();
    this.loadTable();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style lang="scss" scoped>
.ysstable {
  width: 100%;
  .collegebtn {
    background: #fff;
    color: #409eff;
  }
}
</style>
