<template>
  <div class="tabledss">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="form.searchcontent" placeholder="请输入学号/姓名" style="width:200px" clearable suffix-icon="el-icon-search" @clear="freshloadTable"></el-input>
        <el-button @click="freshloadTable">查询</el-button>
        <el-select v-model="form.xy" placeholder="全部学院" filterable>
          <el-option v-for="item in xy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="form.zy" placeholder="全部专业" filterable>
          <el-option v-for="item in zy" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <span style="font-size:16px">答辩成绩{{ xyh }}</span>
        <el-input v-model="form.dbfs" style="width:100px" type="number" clearable></el-input>
      </div>
      <div slot="right">
        <el-button type="primary" @click="pass" v-if="$btnAuthorityTest('graduation:allPass')">一键通过</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column prop="studentNumber" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="学院"></el-table-column>
      <el-table-column prop="majorName" label="专业"></el-table-column>
      <el-table-column prop="grade" label="年级"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column label="答辩成绩">
        <template slot-scope="scope">
          <el-input v-model="scope.row.score" clearable type="number" @keyup.enter.native="handleFind(scope.row)" :min="1" :max="100" v-if="$btnAuthorityTest('graduation:input')"></el-input>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="loadTable" v-if="loadingpagination"></pagination>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  components: {
    searchcomponment,
    pagination
  },
  name: "tabledss",
  data() {
    return {
      xyh: ">",
      form: {
        // 模糊搜索内容
        searchcontent: "",
        // 学院
        xy: "",
        // 专业
        zy: "",
        dbfs: 0
      },
      //   学院下拉框
      xy: [],
      //   专业下拉框
      zy: [],
      total: 0,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      loading2: false,
      //   刷新分页组件
      loadingpagination: true,
      reg: /^(\d|[1-9]\d|100)(\.\d{1,2})?$/,
      multipleSelection: []
    };
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.xy": {
      handler: function(val) {
        const tmp = this.xy.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.zy = tmp.children;
        this.form.zy = this.zy[0].value;
        this.freshloadTable();
      }
    },
    "form.zy": {
      handler: function(val) {
        this.freshloadTable();
      }
    }
  },
  methods: {
    handleFind(row) {
      if (parseInt(row.score) > 100) {
        return this.$message.error("答辩成绩不能大于100分");
      }
      !row.score
        ? this.$message.error("当前答辩内容不能为空")
        : this.$http
            .put("api/degree/duc/enterScore", {
              lcid: row.executionId,
              zsdbcj: row.score
            })
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.freshloadTable();
              }
            });
    },
    reviewaccount() {
      this.$message.warning("当前功能未开放");
    },
    freshloadTable() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.loadTable();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    pass() {
      var formset = [];
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行通过操作");
      }
      var flag = true;
      this.multipleSelection.forEach(element => {
        if (flag) {
          if (element.click == "0" || !element.score || !element.click) {
            this.$message.error("该学生答辩成绩为空，不可通过！");
            flag = false;
          }
        }
      });
      if (flag) {
        return this.$confirm("是否通过所有已选论文？", "一键通过", {
          confirmButtonText: "确定",
          cancelButtonText: "取消"
        })
          .then(() => {
            this.multipleSelection.forEach(item => {
              formset.push(item.lcId);
            });
            this.$http
              .put("api/degree/duc/replyBatchPass", formset)
              .then(res => {
                if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: "error"
                  });
                } else {
                  this.$message({
                    message: res.data.message,
                    type: "success"
                  });
                  this.freshloadTable();
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "error",
              message: "已取消"
            });
          });
      }
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push({
            lcId: row.executionId,
            score: row.score,
            click: row.click
          });
        });
      }
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        // 学院与专业的联动
        this.xy = res.data.data;
        this.zy = this.xy[0].children;
      });
    },
    loadTable() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      console.log(this.arguments);
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/duc/replyList", {
          collegeCode: this.form.xy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.form.searchcontent,
          majorCode: this.form.zy,
          score: this.form.dbfs,
          type: "2"
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  created() {
    this.loadDeptSelect();
    this.loadTable();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style lang="scss" scoped>
.tabledss {
  width: 100%;
  .collegebtn {
    background: #fff;
    color: #409eff;
  }
}
</style>
