<template>
  <div class="checkdisser">
    <div class="tabs">
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="待查重论文" name="first">
          <dqrlist v-if="activeName =='first'"></dqrlist>
        </el-tab-pane>
        <el-tab-pane label="已通过论文" name="second">
          <yqrlist v-if="activeName =='second'"></yqrlist>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import dqrlist from './basic/dqrlistcheckdisser';
import yqrlist from './basic/yqrlistcheckdisser';
export default {
  components: {
    dqrlist,
    yqrlist
  },
  name: 'checkdisser',
  data() {
    return {
      activeName: 'first'
    }
  },
  methods: {
    handleClick() {}
  },
  created() {}
}
</script>

<style lang="scss" scoped>
.checkdisser {
  width: 100%;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      height: 42px;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 130px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
    /deep/ .el-tabs__active-bar {
      width: 120px !important;
      margin-bottom: 0px;
    }
  }
}
</style>

