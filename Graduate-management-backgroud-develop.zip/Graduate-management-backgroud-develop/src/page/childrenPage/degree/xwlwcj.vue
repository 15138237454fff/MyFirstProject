<template>
  <div class="xwlwcj">
    <template v-if="!ctrlloter">
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="待审核论文" name="first">
            <!-- 待审核 -->
            <exam v-if="activeName=='first'" :center="ctrlloter" @formson="fromsonFn"></exam>
          </el-tab-pane>
          <el-tab-pane label="已审核论文" name="second">
            <!-- 已审核 -->
            <examed v-if="activeName=='second'" :center="ctrlloter" @formson="fromsonFn"></examed>
          </el-tab-pane>
        </el-tabs>
      </div>
    </template>
    <xwzgshlist v-else-if="ctrlloter" @formson="fromsonFn" :activeName="activeName"></xwzgshlist>
  </div>
</template>
<script>
import exam from "./xwlwcj/exam";
import examed from "./xwlwcj/examed";
import xwzgshlist from "./xwlwcj/xwResult";
export default {
  name: "xwlwcj",
  data() {
    return {
      activeName: "first",
      ctrlloter: false
    };
  },
  components: {
    exam,
    examed,
    xwzgshlist
  },
  methods: {
    fromsonFn(val) {
      this.ctrlloter = val;
    },
    handleClick() {}
  }
};
</script>

<style lang="scss" scoped>
.xwlwcj {
  width: 100%;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      height: 42px;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 130px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
    /deep/ .el-tabs__active-bar {
      width: 120px !important;
      margin-bottom: 0px;
    }
  }
}
</style>

