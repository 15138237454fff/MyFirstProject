<template>
  <div class="xxcgtable">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="formInline.user" placeholder="请输入学号/姓名" clearable @clear="userlist" suffix-icon="el-icon-search" style="width:200px"></el-input>
        <el-button @click="handleFind">查询</el-button>
        <el-select v-model="formInline.collegeCode" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genre" :key="index"></el-option>
        </el-select>
        <el-select v-model="formInline.studentStatus" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genres" :key="index"></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button type="primary" @click="onSubmit" v-if="$btnAuthorityTest('qualification:allPass')">一键通过</el-button>
        <el-button type="danger" @click="noSubmit" v-if="$btnAuthorityTest('qualification:allBack')">一键退回</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="学号" prop="studentNumber"> </el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="学院"></el-table-column>
      <el-table-column prop="majorName" label="专业"></el-table-column>
      <el-table-column prop="grade" label="年级"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column label="当前审核环节">
        <template slot-scope="scope">
          <el-button @click.native.prevent="deleteRow(scope.$index, scope)" type="text" size="small" style="text-decoration:underline" v-if="$btnAuthorityTest('qualification:audit')">
            {{ scope.row.nodeName }}
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
    <el-dialog title="一键退回" :visible.sync="dialogVisible" width="350px" :before-close="handleClose">
      <span>是否退回所有已选论文？</span>
      <el-form ref="ruleForm" label-width="150px" class="demo-ruleForm">
        <el-form-item label="请输入退回原因：" :required="true"> </el-form-item>
        <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" v-model="pass">
        </el-input>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div style="text-align:center">
          <el-button @click="cancelvisable">取 消</el-button>
          <el-button type="primary" @click="sruelistnav">确 定</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "xxcgtable",
  props: {
    center: Boolean
  },
  components: {
    pagination,
    searchcomponment
  },

  data() {
    return {
      pass: "",
      dialogVisible: false,
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null, // 表格高度
      total: 0,
      tableData: [], // 表格数据
      formInline: {
        user: "",
        collegeCode: "",
        studentStatus: ""
      },
      statustype: "",
      name: "",
      status: {
        // 父组件传值对象
        typeconst: 1,
        menu: 0
      },
      genre: [],
      multipleSelection: [],
      genres: [],
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loadingpagination: true
    };
  },
  filters: {},
  watch: {
    // 监听学院下拉选则的数据
    "formInline.collegeCode": {
      handler: function(val) {
        const tmp = this.genre.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.genres = tmp.children;
        this.formInline.studentStatus = this.genres[0].value;
        this.userlist();
      }
    },
    "formInline.studentStatus": {
      handler: function(val) {
        this.userlist();
      }
    }
  },

  methods: {
    // 数据刷新
    freshform() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.userlist();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    cancelvisable() {
      this.pass = "";
      this.dialogVisible = false;
    },
    // 退回操作
    sruelistnav() {
      if (this.pass == "") {
        return this.$message({
          message: "请输入退回原因",
          type: "error"
        });
      }
      this.$http
        .put("api/degree/duc/batchBack1", {
          dtos: this.multipleSelection,
          comment: this.pass
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.freshform();
            this.dialogVisible = false;
          }
        });
    },
    handleClose() {
      this.pass = "";
    },
    deleteRow(index, scope) {
      this.$http.get(`api/degree/duc/${scope.row.studentNumber}`).then(res => {
        if (res.data.data !== null) {
          var content = res.data.data;
          this.$storage.addObjectKey(res.data.data, content);
          this.$http
            .get(`api/degree/duc/history/${scope.row.executionId}`)
            .then(res => {
              var history = res.data.data;
              if (res.data.data !== null) {
                this.$stores.commit("DEGREE", {
                  content: content,
                  history: history,
                  row: scope.row
                });
                setTimeout(() => {
                  this.$emit("formson", true);
                }, 50);
              } else {
                this.$message.error("数据异常,请刷新重试");
              }
            });
        } else {
          this.$message.error("数据异常,请刷新重试");
        }
      });
    },
    noSubmit() {
      this.multipleSelection.length == 0
        ? this.$message({
            message: "请勾选数据再进行操作",
            type: "error"
          })
        : (this.dialogVisible = true);
    },
    // 一键通过
    onSubmit() {
      console.log(this.multipleSelection);
      this.multipleSelection.length == 0
        ? this.$message({
            message: "请勾选数据再进行通过操作",
            type: "error"
          })
        : this.$confirm("是否通过所有已选论文？", "一键通过", {
            confirmButtonText: "确定",
            cancelButtonText: "取消"
          })
            .then(() => {
              this.$http
                .put("api/degree/duc/batchPass", this.multipleSelection)
                .then(res => {
                  if (res.data.code == 400) {
                    this.$message({
                      message: res.data.message,
                      type: "error"
                    });
                  } else {
                    this.$message({
                      message: res.data.message,
                      type: "success"
                    });
                    this.freshform();
                  }
                });
            })
            .catch(() => {
              this.$message({
                type: "error",
                message: "已取消"
              });
            });
    },
    // 查询
    handleFind() {
      this.userlist();
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push({
            lcId: row.executionId,
            taskId: row.taskId
          });
        });
      }
    },
    // 列表
    userlist() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/duc/toAudit", {
          collegeCode: this.formInline.collegeCode,
          majorCode: this.formInline.studentStatus,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          type: "1"
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        console.log(res);
        // 学院与专业的联动
        this.genre = res.data.data;
        this.genres = this.genre[0].children;
      });
    }
  },
  mounted() {
    this.loadDeptSelect();
    this.userlist();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  },
  beforeDestroy() {
    this.$bus.$off("shrow");
  }
};
</script>

<style scoped lang="scss">
.xxcgtable {
  width: 100%;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
