<template>
  <div class="tabledss">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="form.searchcontent" placeholder="请输入学号/姓名" style="width:200px" clearable suffix-icon="el-icon-search" @clear="freshloadTable"></el-input>
        <el-button @click="freshloadTable">查询</el-button>
        <el-select v-model="form.xy" placeholder="全部学院" filterable>
          <el-option v-for="(item, index) in xy" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="form.zy" placeholder="全部专业" filterable>
          <el-option v-for="(item, index) in zy" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <span style="font-size:16px">评审成绩{{ xyh }}</span>
        <el-input placeholder="请输入内容" v-model="form.psfs" class="input-with-select" style="width:150px" type="number">
          <el-button slot="append" icon="el-icon-search" @click="freshTable"></el-button>
        </el-input>
      </div>
      <div slot="right">
        <el-button type="primary" plain class="collegebtn" @click="szpszb" v-if="$btnAuthorityTest('dissertation:set')">设置评审指标</el-button>
        <el-button type="primary" plain class="collegebtn" @click="reviewaccount" v-if="$btnAuthorityTest('dissertation:generate')">生成评审账号</el-button>
        <el-button type="primary" @click="pass" v-if="$btnAuthorityTest('dissertation:allPass')">一键通过</el-button>
        <el-button type="danger" @click="returnpass" v-if="$btnAuthorityTest('dissertation:allBack')">一键退回</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column prop="studentNumber" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="学院"></el-table-column>
      <el-table-column prop="majorName" label="专业"></el-table-column>
      <el-table-column prop="grade" label="年级"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column prop="level" label="送审级别">
        <template slot-scope="scope">
          <span>{{ scope.row.level | level }}</span>
        </template>
      </el-table-column>
      <el-table-column label="评审成绩" width="250px">
        <template slot-scope="scope">
          <div v-if="scope.row.type == '1'" class="blue">
            <span :class="{ red: item < 70 }" v-for="(item, index) in scope.row.score.split(',')" style="margin-right:10px">{{ item }}</span>
          </div>
          <span v-if="scope.row.type == '0'" style="color:#FF9900">{{
            scope.row.score
          }}</span>
        </template>
      </el-table-column>
      <el-table-column label="推优次数">
        <template slot-scope="scope">
          <span>{{ scope.row.num }}</span>
        </template>
      </el-table-column>
      <el-table-column label="查看评审详情">
        <template slot-scope="scope" v-if="$btnAuthorityTest('dissertation:view')">
          <el-button type="text" :disabled="true" style="text-decoration: underline" v-if="scope.row.type == '0'">查看</el-button>
          <el-button type="text" :disabled="false" style="text-decoration: underline" @click="detailevent(scope.row)" v-if="scope.row.type == '1'">查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="loadTable" v-if="loadingpagination"></pagination>
    <el-dialog title="提示" :visible.sync="dialogVisible" width="30%" :close-on-click-modal="false">
      <el-form :model="formdialog">
        <el-form-item label="是否第三方送审：" label-width="150px">
          <el-radio v-model="formdialog.str" label="0">否</el-radio>
          <el-radio v-model="formdialog.str" label="1">是</el-radio>
        </el-form-item>
        <el-form-item label="送审范围：" label-width="150px">
          <el-radio v-model="formdialog.scope" label="0" :disabled="ishowrule">未评审论文</el-radio>
          <el-radio v-model="formdialog.scope" label="1" :disabled="ishowrule">未通过论文</el-radio>
        </el-form-item>
        <el-form-item label="论文抽取规则：" label-width="150px">
          <el-select v-model="formdialog.rule" style="width:150px" :disabled="ishow">
            <el-option label="全部" value="0"></el-option>
            <el-option label="随机抽取" value="1"></el-option>
            <el-option label="按专业随机" value="2"></el-option>
          </el-select>
          <el-input v-model="formdialog.ruleNum" class="input-with-select" style="width:130px;margin-top:3px" type="number" :disabled="ishow" :readonly="ruleNum">
            <el-button slot="append">份</el-button>
          </el-input>
        </el-form-item>
        <el-form-item label="论文评审次数：" label-width="150px">
          <span>硕士</span>
          <el-input-number v-model="formdialog.masterNum" controls-position="right" :min="1" :max="5" :disabled="ishow" maxlength="1" clearable></el-input-number>
        </el-form-item>
        <el-form-item label="" label-width="150px">
          <span>博士</span>
          <el-input-number v-model="formdialog.doctorNum" controls-position="right" :min="1" :max="5" :disabled="ishow" maxlength="1" clearable></el-input-number>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="configVisible">确定生成</el-button>
      </span>
    </el-dialog>
    <el-dialog title="送审" :visible.sync="dialogVisibles" width="30%" :close-on-click-modal="false">
      <p style=" text-decoration: underline;color: #409eff;margin-bottom:10px">
        已生成以下评审账号！
      </p>
      <el-table :data="
          tableDatalist.slice(
            pagesize * (currentPage - 1),
            pagesize * currentPage
          )
        " border style="width: 100%" height="280px">
        <el-table-column prop="zh" label="评审账号" width="180">
        </el-table-column>
        <el-table-column prop="mm" label="密码" width="180"> </el-table-column>
        <el-table-column prop="xwlwtm" label="论文中文题目"> </el-table-column>
      </el-table>
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 15, 20]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="tableDatalist.length">
      </el-pagination>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisibles = dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  components: {
    searchcomponment,
    pagination
  },
  name: "tabledss",
  data() {
    return {
      xyh: "<",
      form: {
        // 模糊搜索内容
        searchcontent: "",
        // 学院
        xy: "",
        // 专业
        zy: "",
        psfs: 0
      },
      //   学院下拉框
      xy: [],
      //   专业下拉框
      zy: [],
      total: 0,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      loading2: false,
      //   刷新分页组件
      loadingpagination: true,
      reg: /^(\d|[1-9]\d|100)(\.\d{1,2})?$/,
      multipleSelection: [],
      dialogVisible: false,
      formdialog: {
        str: "",
        scope: "",
        rule: "",
        ruleNum: 1,
        masterNum: 1,
        doctorNum: 1
      },
      ishow: false,
      ishowrule: false,
      ruleNum: false,
      dialogVisibles: false,
      tableDatalist: [],
      currentPage: 1,
      pagesize: 10,
      pagetotal: []
    };
  },
  filters: {
    level(val) {
      switch (val) {
        case "0":
          return "校级";
        case "1":
          return "院级";
        default:
          break;
      }
    }
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.xy": {
      handler: function(val) {
        const tmp = this.xy.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.zy = tmp.children;
        this.form.zy = this.zy[0].value;
        this.freshloadTable();
      }
    },
    "form.zy": {
      handler: function(val) {
        this.freshloadTable();
      }
    },
    "formdialog.str": {
      handler: function(val) {
        if (val == "1") {
          this.ishow = this.ishowrule = true;
        } else if (val == "0" && this.formdialog.scope == "1") {
          this.ishow = true;
          this.ishowrule = false;
        } else {
          this.ishow = this.ishowrule = false;
        }
      },
      deep: true,
      immediate: true
    },
    "formdialog.scope": {
      handler: function(val) {
        if (val == "1") {
          this.ishow = true;
        } else {
          this.ishow = false;
        }
      },
      deep: true,
      immediate: true
    },
    "formdialog.rule": {
      handler: function(val) {
        if (val == "0") {
          this.ruleNum = true;
        } else {
          this.ruleNum = false;
        }
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    freshTable() {
      if (!this.reg.test(this.form.psfs)) {
        return this.$message.error("评审成绩输入有误");
      } else {
        this.freshloadTable();
      }
    },
    handleSizeChange(val) {
      this.pagesize = val;
    },
    handleCurrentChange(val) {
      this.currentPage = val;
    },
    reviewaccount() {
      // this.$message.warning("当前功能未开放");
      this.dialogVisible = true;
      this.formdialog = {
        str: "",
        scope: "",
        rule: "",
        ruleNum: 1,
        masterNum: 1,
        doctorNum: 1
      };
    },
    configVisible() {
      var flag = true;
      if (this.formdialog.str == "1") {
        this.freshloadTable();
        this.dialogVisible = false;
        return this.$message.success("操作成功");
      } else {
        if (this.formdialog.scope != "1") {
          Object.keys(this.formdialog).forEach(key => {
            if (flag) {
              if (this.formdialog[key] == "") {
                this.$message.error("请填写完整再提交");
                flag = false;
              }
            }
          });
        }
        if (flag) {
          this.$http
            .post("api/degree/duc/addAccount", this.formdialog)
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.dialogVisibles = true;
                this.pagetotal = res.data.data;
                this.tableDatalist = res.data.data;
                this.freshloadTable();
              } else {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              }
            });
        }
      }
    },
    freshloadTable() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.loadTable();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    pass() {
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行通过操作");
      }
      var flag = true;
      this.multipleSelection.forEach(element => {
        var indexOf = this.tableData.find(
          el => el.executionId === element.lcId
        );
        if (flag) {
          if (indexOf) {
            if (indexOf.click == "0" || !indexOf.score) {
              this.$message.error("未评审/评审中的学位论文不能进行此操作！");
              flag = false;
            }
          }
        }
      });
      if (flag) {
        return this.$confirm("是否通过所有已选论文？", "一键通过", {
          confirmButtonText: "确定",
          cancelButtonText: "取消"
        })
          .then(() => {
            this.$http
              .put("api/degree/duc/batchPass", this.multipleSelection)
              .then(res => {
                if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: "error"
                  });
                } else {
                  this.$message({
                    message: res.data.message,
                    type: "success"
                  });
                  this.freshloadTable();
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "error",
              message: "已取消"
            });
          });
      }
    },
    returnpass() {
      var multipleSelection = [...this.multipleSelection];
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行通过操作");
      }
      var flag = true;
      this.multipleSelection.forEach(element => {
        var indexOf = this.tableData.find(
          el => el.executionId === element.lcId
        );
        if (flag) {
          if (indexOf) {
            if (indexOf.click == "0" || !indexOf.score) {
              this.$message.error("未评审/评审中的学位论文不能进行此操作！");
              flag = false;
            }
          }
        }
      });
      if (flag) {
        this.$prompt("是否退回所有已选论文？", "一键退回", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          inputPlaceholder: "请输入退回原因",
          inputPattern: /\S/,
          inputErrorMessage: "请填写退回原因"
        })
          .then(({ value }) => {
            this.$http
              .put("api/degree/duc/batchBack1", {
                comment: value,
                dtos: multipleSelection
              })
              .then(res => {
                if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: "error"
                  });
                } else {
                  this.$message({
                    message: res.data.message,
                    type: "success"
                  });
                  this.freshloadTable();
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "error",
              message: "取消输入"
            });
          });
      }
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push({
            lcId: row.executionId,
            taskId: row.taskId
          });
        });
      }
    },
    // 设置评审指标
    szpszb() {
      this.$emit("dissert", true);
    },
    detailevent(row) {
      this.$http
        .get(`api/degree/duc/selectCheckInfo?xh=${row.studentNumber}&lx=1`)
        .then(res => {
          if (res.data.data !== null) {
            var content = res.data.data;
            this.$storage.addObjectKey(res.data.data, content);
            this.$stores.commit("DEGREE", {
              content: content,
              row: row
            });
            setTimeout(() => {
              this.$emit("asevent", true);
            }, 100);
          } else {
            this.$message.error("数据异常,请刷新重试");
          }
        });
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        console.log(res);
        // 学院与专业的联动
        this.xy = res.data.data;
        this.zy = this.xy[0].children;
      });
    },
    loadTable() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/duc/reviewList", {
          collegeCode: this.form.xy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.form.searchcontent,
          majorCode: this.form.zy,
          score: this.form.psfs
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  created() {
    this.loadDeptSelect();
    this.loadTable();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style lang="scss" scoped>
.tabledss {
  width: 100%;
  .collegebtn {
    background: #fff;
    color: #409eff;
  }
  .bule {
    color: #409eff;
  }
  .red {
    color: red;
  }
}
</style>
