<template>
  <div class="dissertxq">
    <el-row>
      <el-row :gutter="20" class="bg-purple-dark">
        <el-col :span="16">
          <div class="grid-content">
            <el-button type="text" icon="el-icon-refresh-left" @click="returncall">返回</el-button>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content right">
            <el-button type="primary" @click="save">保存</el-button>
          </div>
        </el-col>
      </el-row>
    </el-row>
    <el-tabs type="border-card" @tab-click="handleClick" v-if="taboption.length">
      <el-tab-pane :label="item.temp.label" v-for="(item, index) in taboption" :key="index">
        <el-table :data="item.pszb.nr" border style="width: 100%" height="600px" v-loading="loading">
          <el-table-column label="评审指标" width="250">
            <template slot-scope="scope">
              <el-input v-model="scope.row.zb" placeholder="请输入内容"></el-input>
            </template>
          </el-table-column>
          <el-table-column label="评审内容">
            <template slot-scope="scope">
              <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" placeholder="请输入内容" v-model="scope.row.nr"></el-input>
            </template>
          </el-table-column>
          <el-table-column label="满分分数" width="180">
            <template slot-scope="scope">
              <el-input v-model.number="scope.row.fs" type="number"></el-input>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="180">
            <template slot-scope="scope">
              <i class="el-icon-circle-plus" style="color:#409eff" @click="jtcyadd(scope.row, scope.$index, item.pszb.nr)" v-if="scope.$index === item.pszb.nr.length - 1"></i>
              <i class="el-icon-remove" style="color:#f56c6c" v-if="scope.$index !== item.pszb.nr.length - 1" @click="jtcydelet(scope.row, scope.$index, item.pszb.nr)"></i>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
export default {
  name: "dissertxq",
  data() {
    return {
      activeName: "first",
      taboption: [],
      tableData: [
        {
          pfzb: "评审指标",
          psnr: "评审内容",
          mffs: 120
        },
        {
          pfzb: "评审指标",
          psnr: "评审内容",
          mffs: 120
        }
      ],
      loading: false
    };
  },
  methods: {
    jtcyadd(row, index, list) {
      list.push(JSON.parse(JSON.stringify({ zb: "", nr: "", fs: "" })));
    },
    jtcydelet(row, index, list) {
      list.splice(list.findIndex(item => item === row), 1);
    },
    returncall() {
      this.$emit("dissert", false);
    },
    save() {
      // console.log(this.taboption)
      var flag = true;
      this.taboption.forEach(element => {
        if (element.pszb.nr) {
          element.pszb.nr.forEach(item => {
            if (flag) {
              if (item.fs == "" || item.nr == "" || item.zb == "") {
                this.$message.error(element.temp.label + "请填写完整");
                flag = false;
              }
            }
          });
        }
      });
      var arr = [];
      if (flag) {
        this.taboption.forEach(element => {
          if (element.pszb.nr) {
            arr.push({ lb: element.temp.value, nr: element.pszb.nr });
          }
        });
        this.$http.put("api/degree/duc/update", arr).then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            this.returncall();
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
    },
    handleClick() {
      this.loading = true;
      setTimeout(() => {
        this.loading = false;
      }, 800);
    },
    loadTable() {
      this.loading = true;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 2000);
      this.$http
        .get("api/degree/duc/indexList")
        .then(res => {
          this.loading = false;
          if (res.data.code == 200) {
            this.taboption = res.data.data;
            this.taboption.forEach(element => {
              if (!element.pszb) {
                element.pszb = {};
                this.$set(element.pszb, "nr", [
                  JSON.parse(JSON.stringify({ zb: "", nr: "", fs: "" }))
                ]);
              } else if (!element.pszb.nr) {
                element.pszb.nr = [
                  JSON.parse(JSON.stringify({ zb: "", nr: "", fs: "" }))
                ];
              }
            });
          } else {
            this.$message.error(res.data.message);
            this.returncall();
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  created() {
    this.loadTable();
  }
};
</script>

<style lang="scss" scoped>
.dissertxq {
  width: 100%;
  .bg-purple-dark {
    border-bottom: 1px solid #eeeeee;
    height: 48px;
    line-height: 48px;
    font-size: 16px;
    padding-left: 20px;
    margin-bottom: 15px;
  }
  .right {
    text-align: right;
  }
}
</style>
