<template>
  <div class="dissertxq">
    <el-row>
      <el-row :gutter="20" class="bg-purple-dark">
        <el-col :span="16">
          <div class="grid-content">
            <el-button type="text" icon="el-icon-refresh-left" @click="returncall">返回</el-button>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content right"></div>
        </el-col>
      </el-row>
    </el-row>
    <div class="lxmessage">
      <table>
        <tr>
          <td class="left_cont" colspan="6">论文信息</td>
        </tr>
        <tr>
          <td style="padding:10px">
            <table>
              <tr>
                <td class="listcss">论文中文题目</td>
                <td>{{ content.xwlwtm }}</td>
                <td class="listcss">论文英文题目</td>
                <td>{{ content.xwlwywtm }}</td>
              </tr>
              <tr>
                <td class="listcss">论文字数</td>
                <td>{{ content.lwzs }}万</td>
                <td class="listcss">论文类型</td>
                <td>{{ content.lwlx }}</td>
              </tr>
              <tr>
                <td class="listcss">选题来源</td>
                <td>{{ content.xtly }}</td>
                <td class="listcss">论文关键词</td>
                <td>{{ content.lwgjz }}</td>
                <td class="listcss">论文附件</td>
                <td>
                  <span style="color:#409eff; text-decoration: underline;cursor: pointer;" @click="open(content.fj.url)">{{ content.fj.fileName }}</span>
                </td>
              </tr>
              <tr>
                <td class="listcss"> 论文研究方向</td>
                <td>{{ content.lwgjz }}</td>
                <td class="listcss">论文附件</td>
                <td>
                  <span style="color:#409eff; text-decoration: underline;cursor: pointer;" @click="open(content.fj.url)">{{ content.fj.fileName }}</span>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>

      <table>
        <tr>
          <td class="left_cont" colspan="6">评审信息</td>
        </tr>
        <tr>
          <td style="padding:10px">
            <table>
              <tr>
                <td class="left_cont" colspan="6">
                  <span style="margin-right:3px;font-size:12px;font-weight:bold">|</span>专家信息
                </td>
              </tr>
              <tr>
                <td class="listcss" colspan="2">姓名</td>
                <td class="listcss" colspan="2">身份证号码</td>
                <td class="listcss" colspan="2">手机号</td>
              </tr>
              <tr>
                <td colspan="2">{{ content.grxx.xm }}</td>
                <td colspan="2">{{ content.grxx.sfzh }}</td>
                <td colspan="2">{{ content.grxx.sj }}</td>
              </tr>
            </table>

            <table>
              <tr>
                <td class="left_cont" colspan="6">
                  <span style="margin-right:3px;font-size:12px;font-weight:bold">|</span>论文评分<span class="fsstyle">总分：{{ content.zf }}分</span>
                </td>
              </tr>
              <tr>
                <td class="listcss">一级指标</td>
                <td class="listcss" colspan="2">二级指标和评价要点</td>
                <td class="listcss">项目满分</td>
                <td class="listcss">评分</td>
              </tr>
              <tr v-for="(el, index) in content.pszbVOList">
                <td>{{ el.zb }}</td>
                <td colspan="2">{{ el.nr }}</td>
                <td>{{ el.fs }}</td>
                <td>{{ el.pf }}</td>
              </tr>
              <tr>
                <td class="left_cont" colspan="6">
                  <span style="margin-right:3px;font-size:12px;font-weight:bold">|</span>评审意见
                </td>
              </tr>
              <tr style="height:150px">
                <td colspan="6" rowspan="3">{{ content.psyj }}</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: "assessedResult",
  data() {
    return {
      activeName: "first",
      taboption: [
        {
          label: "评审结果1（82分）",
          key: "评审结果1（82分）"
        },
        {
          label: "评审结果2（85分）",
          key: "评审结果2（85分）"
        }
      ],
      tableData: [
        {
          pfzb: "评审指标",
          psnr: "评审内容",
          mffs: 120
        },
        {
          pfzb: "评审指标",
          psnr: "评审内容",
          mffs: 120
        }
      ],
      content: {},
      tablerow: {}
    };
  },
  methods: {
    returncall() {
      this.$emit("formson", false);
    },
    open(val) {
      window.location.href = val;
    }
  },
  created() {
    this.content = this.$stores.state.degreeObj.content;
    this.tablerow = this.$stores.state.degreeObj.row;
    console.log(this.content);
    console.log(this.tablerow);
  }
};
</script>

<style lang="scss" scoped>
.dissertxq {
  width: 100%;
  .bg-purple-dark {
    border-bottom: 1px solid #eeeeee;
    height: 48px;
    line-height: 48px;
    font-size: 16px;
    padding-left: 20px;
    margin-bottom: 15px;
  }
  .right {
    text-align: right;
  }
  table {
    border-collapse: collapse;
    width: 100%;
    color: #666666;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
      color: #000000;
    }
    .listcss {
      background: #f5f5f5;
      width: 180px;
      text-align: center;
    }
    .fsstyle {
      float: right;
      margin-right: 10px;
      color: #409eff;
    }
    .ss1 {
      color: red;
    }
    .ss2 {
      color: rgb(255, 153, 0);
    }
    .ss3 {
      color: rgb(102, 204, 51);
    }
  }
}
</style>
