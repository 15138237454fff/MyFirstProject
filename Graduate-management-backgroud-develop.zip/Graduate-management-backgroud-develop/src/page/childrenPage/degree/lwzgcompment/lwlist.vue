<template>
  <div class="xwzgshlist" v-loading="loading">
    <el-row>
      <el-col :span="24">
        <div class="grid-content bg-purple-dark">
          <el-button type="text" icon="el-icon-refresh-left" @click="returncall">返回</el-button>
        </div>
      </el-col>
    </el-row>
    <table>
      <thead>
        <tr>
          <th style="height:60px; font-size: 20px;" colspan="6">
            浙江工业大学研究生学位论文定稿
          </th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6">
          <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>论文关键信息
        </td>
      </tr>
      <tr>
        <td class="listcss">论文中文题目</td>
        <td colspan="5">{{ content.lwzwtm }}</td>
      </tr>
      <tr>
        <td class="listcss">论文英文题目</td>
        <td colspan="5">{{ content.lwywtm }}</td>
      </tr>
      <tr>
        <td class="listcss">论文字数</td>
        <td>{{ content.lwzs }}万</td>
        <td class="listcss">论文类型</td>
        <td>{{ content.lwlx }}</td>
        <td class="listcss">选题来源</td>
        <td>{{ content.xtly }}</td>
      </tr>
      <tr>
        <td class="listcss">论文关键词</td>
        <td colspan="5">{{ content.lwgjz }}</td>
      </tr>
      <tr>
        <td class="listcss">论文研究方向</td>
        <td colspan="5">{{ content.lwyjfx }}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6">
          <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>论文附件
        </td>
      </tr>
      <tr>
        <td colspan="6" style="color:#409EFF;" @click="open(content.fj.url)">
          {{ content.fj.fileName }}
        </td>
      </tr>
    </table>

    <div class="divcss5"></div>
    <el-steps :active="list.length" :space="200" style="margin-bottom:20px">
      <el-step v-for="(item, index) in list" :key="index" :icon="
          item.state == '1' || item.state == null
            ? 'el-icon-circle-check'
            : item.state == '2'
            ? 'el-icon-d-arrow-left'
            : 'el-icon-close'
        ">
        <div slot="title" class="mytext">
          {{ item.name + "(" + item.assignee + ")" }}
        </div>
        <span slot="description" :class="{
            yes: item.state == '1',
            back: item.state == '2' || item.state == '0'
          }">{{
            item.state == "1"
              ? "通过"
              : item.state == "0"
              ? "不通过"
              : item.state == "2"
              ? "退回"
              : ""
          }}</span>&nbsp;&nbsp;
        <span slot="description" class="comment"> {{ item.startTime }}</span>
      </el-step>
    </el-steps>
    <div class="divcss5" v-if="activeName !== 'second'"></div>
    <el-form ref="form" :model="sizeForm" label-width="120px" size="mini" v-if="activeName !== 'second'">
      <el-form-item label="审核：">
        <el-radio-group v-model="sizeForm.radio1">
          <el-radio-button :label="item.value" v-for="(item, index) in check" :key="index">{{ item.label }}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：">
        <el-input type="textarea" placeholder="请输入内容" v-model="sizeForm.textarea" maxlength="30" show-word-limit style="width:90%">
        </el-input>
        <el-button type="primary" style="width:100px;" @click="save">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  props: ["activeName"],
  name: "learningcode1",
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ""
      },
      content: {
        fj: {}
      },
      menucont: {},
      list: [],
      check: [
        {
          value: 1,
          label: "通过"
        },
        {
          value: 2,
          label: "退回"
        }
      ],
      url: "",
      fileName: "",
      sstt: ["ss1", "ss2", "ss3"],
      loading: false,
      tablerow: {},
      val: {}
    };
  },
  mounted() {
    this.loadtable();
  },
  beforeCreate() {
    console.log(2222);
    this.$bus.$on("sendData", val => {
      console.log(val);
    });
  },
  beforeDestroy() {
    this.$bus.$off("sendData");
  },
  created() {},
  methods: {
    save() {
      if (this.sizeForm.radio1 == 2 && this.sizeForm.textarea == "") {
        return this.$message.error("请填写审核意见");
      }
      this.$http
        .post(`api/degree/pfc/audit`, {
          check: this.sizeForm.radio1,
          comment: this.sizeForm.textarea,
          lcid: this.tablerow.executionId,
          taskId: this.tablerow.taskId,
          type: "1"
        })
        .then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            setTimeout(() => {
              this.$emit("formson", false);
            }, 50);
          } else {
            this.$message.error("数据异常,请刷新重试");
          }
        });
    },
    returncall() {
      this.$emit("formson", false);
    },
    loadtable() {
      this.content = this.$stores.state.degreeObj.content;
      this.list = this.$stores.state.degreeObj.history;
      this.tablerow = this.$stores.state.degreeObj.row;
    },
    open(val) {
      window.open(val);
    }
  }
};
</script>
<style scoped lang="scss">
.xwzgshlist {
  .bg-purple-dark {
    border-bottom: 1px solid #eeeeee;
    height: 48px;
    line-height: 48px;
    font-size: 16px;
    padding-left: 20px;
    margin-bottom: 15px;
  }
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
    .ss1 {
      color: red;
    }
    .ss2 {
      color: rgb(255, 153, 0);
    }
    .ss3 {
      color: rgb(102, 204, 51);
    }
  }
  .divcss5 {
    height: 1px;
    width: 100%;
    border-bottom: 1px dashed #e0e0e0;
    margin: 10px 0 10px 0;
  }
}
</style>
