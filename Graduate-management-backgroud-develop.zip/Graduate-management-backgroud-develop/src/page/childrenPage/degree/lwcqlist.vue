<template>
  <div class="learning_code1">
    <el-row>
      <el-col :span="24">
        <div class="grid-content bg-purple-dark">
          <el-button type="text" icon="el-icon-refresh-left" @click="returncall"
            >返回</el-button
          >
        </div>
      </el-col>
    </el-row>
    <table>
      <thead>
        <tr>
          <th style="height:60px; font-size: 20px;" colspan="6">
            浙江财经大学研究生学位论文定稿
          </th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6">
          <span
            style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold"
            >|</span
          >论文关键信息
        </td>
      </tr>
      <tr>
        <td class="listcss">论文中文题目</td>
        <td colspan="5">{{ content.lwzwtm }}</td>
      </tr>
      <tr>
        <td class="listcss">论文英文题目</td>
        <td colspan="5">{{ content.lwywtm }}</td>
      </tr>
      <tr>
        <td class="listcss">论文字数</td>
        <td>{{ content.lwzs }}万</td>
        <td class="listcss">论文类型</td>
        <td>{{ content.lwlx }}</td>
        <td class="listcss">选题来源</td>
        <td>{{ content.xtly }}</td>
      </tr>
      <tr>
        <td class="listcss">论文起始日期</td>
        <td>{{ content.lwkssj }}</td>
        <td class="listcss">论文终止日期</td>
        <td>{{ content.lwzzsj }}</td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td class="listcss">论文关键词</td>
        <td colspan="5">{{ content.lwgjz }}</td>
      </tr>
      <tr>
        <td class="listcss">中文摘要</td>
        <td colspan="5">{{ content.zwzy }}</td>
      </tr>
      <tr>
        <td class="listcss">英文摘要</td>
        <td colspan="5">{{ content.ywzy }}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6">
          <span
            style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold"
            >|</span
          >论文附件
        </td>
      </tr>
      <tr>
        <td colspan="6" style="color:#409EFF;" @click="open(url)">
          {{ fileName }}
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  props: {
    row: {
      type: Object,
      default: () => {}
    }
  },
  name: "learningcode1",
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ""
      },
      content: {},
      menucont: {},
      list: [],
      check: [
        {
          value: 1,
          label: "通过"
        },
        {
          value: 0,
          label: "不通过"
        }
      ],
      url: "",
      fileName: "",
      sstt: ["ss1", "ss2", "ss3"]
    };
  },
  mounted() {
    this.userlist();
  },

  filters: {
    xbm(val) {
      switch (val) {
        case 1:
          return "男";
        case 2:
          return "女";
        case 0:
          return "未知性别";
        case 9:
          return "未说明性别";
        default:
          break;
      }
    },
    ssjg(val) {
      if (val == 0) {
        return "不通过";
      } else if (val == 1) {
        return "通过";
      } else if (val == 2) {
        return "待审核";
      }
    }
  },
  methods: {
    open(val) {
      window.open(val);
    },
    returncall() {
      this.$emit("formson", false);
    },
    save() {
      this.$http
        .post("api/degree/duc/audit", {
          taskId: this.row.row.taskId,
          check: this.sizeForm.radio1,
          comment: this.sizeForm.textarea
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$emit("formson", false);
          }
        });
    },
    userlist() {
      this.$http.get("api/degree/pfc/" + this.row.xh).then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.message,
            type: "error"
          });
        } else {
          this.content = res.data.data;
          this.$storage.addObjectKey(res.data.data, this.content);
          this.fileName = res.data.data.fj.fileName;
          this.url = res.data.data.fj.url;
        }
      });
    }
  }
};
</script>
<style scoped lang="scss">
.learning_code1 {
  .bg-purple-dark {
    background: #eeeeee;
    height: 60px;
    line-height: 60px;
    font-size: 16px;
    padding-left: 20px;
  }
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
    .ss1 {
      color: red;
    }
    .ss2 {
      color: rgb(255, 153, 0);
    }
    .ss3 {
      color: rgb(102, 204, 51);
    }
  }
}
</style>
