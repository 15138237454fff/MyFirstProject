<template>
  <div class="dissertation">
    <template v-if="!dissertxqshow && !assessed">
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="待送审论文" name="first">
            <dqrlist v-if="activeName =='first'" @dissert="dissert" @asevent="assessedevent"></dqrlist>
          </el-tab-pane>
          <el-tab-pane label="已通过论文" name="second">
            <yqrlist v-if="activeName =='second'" @dissert="dissert" @asevent="assessedevent"></yqrlist>
          </el-tab-pane>
        </el-tabs>
      </div>
    </template>
    <dissertxq v-else-if="dissertxqshow" @dissert="dissert"></dissertxq>
    <assessedResult v-else-if="assessed" @asevent="assessedevent"></assessedResult>
  </div>
</template>
<script>
import dqrlist from "./dissert/tabledss";
import yqrlist from "./dissert/ysstable";
import dissertxq from "./dissert/dissertxq";
import assessedResult from "./dissert/assessedResult";
export default {
  components: {
    dqrlist,
    yqrlist,
    dissertxq,
    assessedResult
  },
  name: "dissertation",
  data() {
    return {
      activeName: "first",
      dissertxqshow: false,
      assessed: false
    };
  },
  methods: {
    dissert(val) {
      this.dissertxqshow = val;
    },
    assessedevent(val) {
      this.assessed = val;
    },
    handleClick() {}
  },
  created() {}
};
</script>

<style lang="scss" scoped>
.dissertation {
  width: 100%;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      height: 42px;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 130px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
    /deep/ .el-tabs__active-bar {
      width: 120px !important;
      margin-bottom: 0px;
    }
  }
}
</style>

