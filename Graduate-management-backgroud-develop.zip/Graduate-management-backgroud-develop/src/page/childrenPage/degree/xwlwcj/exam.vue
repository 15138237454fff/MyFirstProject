<template>
  <div class="qualificationtabletype">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="formInline.user" placeholder="请输入学号/姓名" clearable @clear="freshform" style="width:200px;" suffix-icon="el-icon-search"></el-input>
        <el-button @click="freshform">查询</el-button>
        <el-select v-model="formInline.collegeCode" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genre" :key="index"></el-option>
        </el-select>
        <el-select v-model="formInline.studentStatus" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genres" :key="index"></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button type="primary" @click="extractPaper" plain class="collegebtn" v-if="$btnAuthorityTest('xwlwcj:role')">抽取论文</el-button>
        <el-button type="primary" @click="creatAccount" plain class="collegebtn" v-if="$btnAuthorityTest('xwlwcj:generate')">生成评审账号</el-button>
        <el-button @click="foreview" type="primary" v-if="$btnAuthorityTest('xwlwcj:submit')">提交</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="学号" prop="xh"> </el-table-column>
      <el-table-column prop="xsxm" label="姓名"></el-table-column>
      <el-table-column prop="yxsmc" label="学院"></el-table-column>
      <el-table-column prop="zymc" label="专业"></el-table-column>
      <el-table-column prop="nj" label="年级"></el-table-column>
      <el-table-column prop="xslbmc" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column prop="score" label="评审成绩">
        <template slot-scope="scope">
          <div v-if="scope.row.type == '1'" class="blue">
            <span :class="{ red: item < 70 }" v-for="(item, index) in scope.row.score.split(',')" style="margin-right:10px">{{ item }}</span>
          </div>
          <span v-if="scope.row.type == '0'" style="color:#FF9900">{{
            scope.row.score
          }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="num" label="推优次数"></el-table-column>
      <el-table-column label="查看评审详情">
        <template slot-scope="scope" v-if="$btnAuthorityTest('xwlwcj:view')">
          <el-button type="text" :disabled="true" style="text-decoration: underline" v-if="scope.row.type == '0'">查看</el-button>
          <el-button type="text" :disabled="false" style="text-decoration: underline" @click="detailevent(scope.row)" v-if="scope.row.type == '1'">查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
    <el-dialog title="生成评审账号" :visible.sync="creatAccountDialogVisible" width="500px" custom-class="creatAccount" :close-on-click-modal="false">
      <div class="creatAccountDialog-body">
        <el-form ref="form" :model="form" label-width="150px">
          <el-form-item label="是否第三方送审：">
            <el-radio v-model="form.str" label="0">否</el-radio>
            <el-radio v-model="form.str" label="1">是</el-radio>
          </el-form-item>
          <el-form-item label="论文抽取规则：">
            <el-select v-model="form.rule" :disabled="zhdisable">
              <el-option label="全部" value="0"></el-option>
              <el-option label="随机抽取" value="1"></el-option>
              <el-option label="按专业随机" value="2"></el-option>
            </el-select>
            <el-input v-model="form.ruleNum" style="width:80px;margin-top:2.5px" :disabled="zhdisable">
              <el-button slot="append">份</el-button>
            </el-input>
          </el-form-item>
          <el-form-item label="论文评审次数：">
            <span>硕士：</span>
            <el-input v-model="form.masterNum" type="number" style="width:70px" :disabled="zhdisable">
            </el-input>
          </el-form-item>
          <el-form-item label="">
            <span>博士：</span>
            <el-input v-model="form.doctorNum" type="number" style="width:70px" :disabled="zhdisable">
            </el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="creatAccountDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="configVisible">确认生成</el-button>
      </span>
    </el-dialog>
    <el-dialog title="抽取论文" :visible.sync="extractDialogVisible" width="20%" custom-class="extractDialog" :close-on-click-modal="false">
      <div class="extractDialog-body">
        <span class="extractDialog-body-title">论文评审成绩筛选:</span>
        <el-input placeholder="" v-model="formInline.score" style="width:130px" type="number">
          <el-button slot="prepend" icon="el-icon-arrow-left"></el-button>
          <span slot="append" icon="el-icon-search">分</span>
        </el-input>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="extractDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="cqlwconfirm">确认</el-button>
      </span>
    </el-dialog>
    <el-dialog title="送审" :visible.sync="dialogVisible" width="40%" :close-on-click-modal="false">
      <div style="color:#409EFF;text-decoration: underline;cursor: pointer;" @click="openurl('http://192.168.31.118:5030/#/')">
        已生成以下评审账号
      </div>
      <el-table :data="
          shtable.slice(pagesize * (currentPage - 1), pagesize * currentPage)
        " tooltip-effect="dark" border ref="multipleTables" style="width: 100%;margin-top:15px;" :header-cell-style="$storage.tableHeaderColor" height="280px">
        <el-table-column prop="zh" label="评审账号"></el-table-column>
        <el-table-column prop="mm" label="密码"></el-table-column>
        <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      </el-table>
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 15, 20]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="shtable.length">
      </el-pagination>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = creatAccountDialogVisible = false">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "qualificationtabletype",
  components: {
    pagination,
    searchcomponment
  },
  data() {
    return {
      loading2: false,
      tableHeight: null,
      total: 0,
      tableData: [],
      formInline: {
        user: "",
        collegeCode: "",
        studentStatus: "",
        score: null
      },
      genre: [],
      genres: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loadingpagination: true,
      extractDialogVisible: false,
      creatAccountDialogVisible: false,
      dialogVisible: false,
      form: {
        str: "",
        rule: "",
        ruleNum: 1,
        masterNum: 1,
        doctorNum: 1
      },
      zhdisable: false,
      shtable: [],
      currentPage: 1,
      pagesize: 10,
      multipleSelection: []
    };
  },
  filters: {},
  watch: {
    // 监听学院下拉选则的数据
    "formInline.collegeCode": {
      handler: function(val) {
        const tmp = this.genre.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.genres = tmp.children;
        this.formInline.studentStatus = this.genres[0].value;
        this.freshform();
      }
    },
    "formInline.studentStatus": {
      handler: function(val) {
        this.freshform();
      }
    },
    "formInline.dictgrade": {
      handler: function(val) {
        this.freshform();
      }
    },
    "form.str": {
      handler: function(val) {
        if (val == "1") {
          this.zhdisable = true;
        } else {
          this.zhdisable = false;
        }
      }
    }
  },
  methods: {
    handleSizeChange(val) {
      this.pagesize = val;
    },
    handleCurrentChange(val) {
      this.currentPage = val;
    },
    configVisible() {
      var flag = true;
      console.log(this.form);
      if (this.form.str !== "1") {
        Object.keys(this.form).forEach(el => {
          if (flag) {
            if (this.form[el] == "") {
              this.$message.error("请填写完整再提交");
              flag = false;
            }
          }
        });
      }
      if (flag) {
        this.$http.post("api/degree/psc/addAccount", this.form).then(res => {
          this.freshform();
          this.creatAccountDialogVisible = false;
          if (res.data.code == 200) {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.dialogVisible = true;
            this.shtable = res.data.data;
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          }
        });
      }
    },
    detailevent(row) {
      this.$http
        .get(`api/degree/duc/selectCheckInfo?xh=${row.xh}&lx=2`)
        .then(res => {
          if (res.data.data !== null) {
            var content = res.data.data;
            this.$storage.addObjectKey(res.data.data, content);
            this.$stores.commit("DEGREE", {
              content: content,
              row: row
            });
            setTimeout(() => {
              this.$emit("formson", true);
            }, 100);
          } else {
            this.$message.error("数据异常,请刷新重试");
          }
        });
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    // 数据刷新
    freshform() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.userlist();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    openurl() {},
    // 抽取论文
    extractPaper() {
      this.formInline.score = null;
      this.extractDialogVisible = true;
    },
    // 确认抽取
    cqlwconfirm() {
      if (!this.formInline.score) {
        return this.$message.error("论文评审成绩不能为空!");
      }
      this.$http
        .put(`api/degree/psc/samspling?score=${this.formInline.score}`)
        .then(res => {
          if (res.data.code == 200) {
            this.freshform();
            this.extractDialogVisible = false;
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    // 生成评审账号
    creatAccount() {
      this.creatAccountDialogVisible = true;
    },
    // 提交
    foreview() {
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行操作");
      }
      var flag = true;
      this.multipleSelection.forEach(element => {
        var indexOf = this.tableData.find(el => el.id === element);
        if (flag) {
          if (indexOf) {
            if (indexOf.type == "0" || !indexOf.score) {
              this.$message.error("未评审/评审中的学位论文不能进行此操作！");
              flag = false;
            }
          }
        }
      });
      if (flag) {
        // 未评审/评审中的学位论文不能进行此操作！
        this.$confirm("是否提交所有已选论文？, 是否继续?", "提交", {
          confirmButtonText: "确定",
          cancelButtonText: "取消"
        })
          .then(() => {
            this.$http
              .put("api/degree/psc/send", this.multipleSelection)
              .then(res => {
                if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: "error"
                  });
                } else {
                  this.freshform();
                }
              });
          })
          .catch(() => {
            this.$message({
              type: "error",
              message: "已取消提交"
            });
          });
      }
    },
    surecheck() {},
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        // 学院与专业的联动
        this.genre = res.data.data;
        this.genres = this.genre[0].children;
      });
      this.$http.get("api/system/dict/select/grade").then(res => {
        // 年级
        if (!Array.isArray(res.data.data)) {
          return this.$message.error("数据异常,请刷新");
        } else {
          this.dictgrade = res.data.data.reverse();
          this.dictgrade.unshift({ value: "", label: "所有年级" });
        }
      });
    },
    onSubmit() {},
    userlist() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/psc/list", {
          collegeCode: this.formInline.collegeCode,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          grade: this.formInline.dictgrade,
          majorCode: this.formInline.studentStatus,
          type: "0"
        })
        .then(res => {
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 1000);
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.loadDeptSelect();
    this.userlist();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style scoped lang="scss">
.qualificationtabletype {
  width: 100%;
  .bule {
    color: #409eff;
  }
  .red {
    color: red;
  }
  .collegebtn {
    color: #409dff;
    background: #fff;
  }
  .studentmessage_box {
    width: 100%;
    height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    padding-top: 5px;

    .el-tabs--top >>> .el-tabs__nav-wrap .is-top {
      background: red !important;
    }
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
    .right {
      text-align: right;
      .collegebtn {
        background: #fff;
        color: #409eff;
      }
    }
    .class-a {
      color: red;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .ss1 {
    color: red;
  }
  .ss2 {
    color: rgb(255, 153, 0);
  }
  .ss3 {
    color: rgb(102, 204, 51);
  }
  /deep/ .el-input-group__prepend {
    background: #f5f7fa !important;
    border: 1px solid #dcdfe6 !important;
    padding: 0 5px;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
    border-top: 1px solid #dcdfe6;
  }
  /deep/ .el-input-group__append {
    padding: 0 5px;
  }
  /deep/ .extractDialog {
    .el-dialog__body .el-input .el-input__prefix .el-icon-arrow-left {
      line-height: 34px;
    }
    .extractDialog-body {
      display: flex;
      justify-content: center;
      .extractDialog-body-title {
        display: inline-block;
        height: 34px;
        line-height: 34px;
        margin-right: 1em;
      }
    }
    .el-dialog__footer {
      text-align: center;
      border-top: 1px solid #dcdfe6;
    }
  }
}
</style>
