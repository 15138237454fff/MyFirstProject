<template>
  <div class="qualificationtabletype">
    <searchcomponment>
      <div slot="left">
        <el-input v-model="formInline.user" placeholder="请输入学号/姓名" clearable @clear="freshform" style="width:200px;" suffix-icon="el-icon-search"></el-input>
        <el-button @click="freshform">查询</el-button>
        <el-select v-model="formInline.collegeCode" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genre" :key="index"></el-option>
        </el-select>
        <el-select v-model="formInline.studentStatus" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genres" :key="index"></el-option>
        </el-select>
        <el-select v-model="formInline.dictgrade" filterable>
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in dictgrade" :key="index"></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button type="primary" plain class="collegebtn" v-if="$btnAuthorityTest('xwlwcj:export')">导出</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column prop="xh" label="学号"> </el-table-column>
      <el-table-column prop="xsxm" label="姓名"></el-table-column>
      <el-table-column prop="yxsmc" label="学院"></el-table-column>
      <el-table-column prop="zymc" label="专业"></el-table-column>
      <el-table-column prop="nj" label="年级"></el-table-column>
      <el-table-column prop="xslbmc" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="xwlwtm" label="论文中文题目"></el-table-column>
      <el-table-column prop="score" label="评审成绩">
        <template slot-scope="scope">
          <div class="blue">
            <span :class="{ red: item < 70 }" v-for="(item, index) in scope.row.score.split(',')" style="margin-right:10px">{{ item }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="num" label="推优次数"></el-table-column>
      <el-table-column label="查看评审详情">
        <template slot-scope="scope">
          <el-button type="text" style="text-decoration: underline" @click="detailevent(scope.row)" v-if="$btnAuthorityTest('xwlwcj:view')">查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "examed",
  components: {
    pagination,
    searchcomponment
  },
  data() {
    return {
      loading2: false,
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null,
      total: 0,
      tableData: [],
      formInline: {
        user: "",
        collegeCode: "",
        studentStatus: "",
        dictgrade: ""
      },
      statustype: 0,
      name: "",
      status: {
        typeconst: 1,
        menu: 1
      },
      genre: [],
      genres: [],
      dictgrade: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loadingpagination: true
    };
  },
  filters: {},
  watch: {
    // 监听学院下拉选则的数据
    "formInline.collegeCode": {
      handler: function(val) {
        const tmp = this.genre.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        this.genres = tmp.children;
        this.formInline.studentStatus = this.genres[0].value;
        this.freshform();
      }
    },
    "formInline.studentStatus": {
      handler: function(val) {
        this.freshform();
      }
    },
    "formInline.dictgrade": {
      handler: function(val) {
        this.freshform();
      }
    }
  },
  methods: {
    // 数据刷新
    freshform() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.userlist();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        // 学院与专业的联动
        this.genre = res.data.data;
        this.genres = this.genre[0].children;
      });
      this.$http.get("api/system/dict/select/grade").then(res => {
        // 年级
        if (!Array.isArray(res.data.data)) {
          return this.$message.error("数据异常,请刷新");
        } else {
          this.dictgrade = res.data.data.reverse();
          this.dictgrade.unshift({ value: "", label: "所有年级" });
        }
      });
    },
    detailevent(row) {
      this.$http
        .get(`api/degree/duc/selectCheckInfo?xh=${row.xh}&lx=2`)
        .then(res => {
          if (res.data.data !== null) {
            var content = res.data.data;
            this.$storage.addObjectKey(res.data.data, content);
            this.$stores.commit("DEGREE", {
              content: content,
              row: row
            });
            setTimeout(() => {
              this.$emit("formson", true);
            }, 50);
          } else {
            this.$message.error("数据异常,请刷新重试");
          }
        });
    },
    onSubmit() {},
    handleSelectionChange() {},
    userlist() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/psc/list", {
          collegeCode: this.formInline.collegeCode,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          grade: this.formInline.dictgrade,
          majorCode: this.formInline.studentStatus,
          type: "1"
        })
        .then(res => {
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 1000);
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.loadDeptSelect();
    this.userlist();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style scoped lang="scss">
.qualificationtabletype {
  width: 100%;
  .collegebtn {
    color: #409dff;
    background: #fff;
  }
  .bule {
    color: #409eff;
  }
  .red {
    color: red;
  }
}
</style>
