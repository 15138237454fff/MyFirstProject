<template>
  <div class="qualificationtabletype">
    <searchcomponment>
      <div slot="left">
        <el-input
          v-model="formInline.user"
          placeholder="请输入单位名称"
          clearable
          @clear="freshform"
          style="width:200px;"
          suffix-icon="el-icon-search"
        ></el-input>
        <el-button @click="freshform">查询</el-button>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="addload"
          v-if="$btnAuthorityTest('xwzgsq:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="deletelist"
          v-if="$btnAuthorityTest('xwzgsq:delete')"
          >删除</el-button
        >
        <el-button
          type="primary"
          plain
          class="collegebtn"
          v-if="$btnAuthorityTest('xwzgsq:export')"
          >导出</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="$storage.tableHeaderColor"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="单位名称" prop="dwmc"> </el-table-column>
      <el-table-column prop="dwzh" label="单位账号"></el-table-column>
      <el-table-column prop="password" label="密码"></el-table-column>
      <el-table-column prop="lxr" label="联系人"></el-table-column>
      <el-table-column prop="lxdh" label="联系电话"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click.native.prevent="deleteRow(scope.$index, scope)"
            type="text"
            size="small"
            style="text-decoration:underline"
            class="tablexg"
            v-if="$btnAuthorityTest('xwzgsq:update')"
          >
            修改
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="userlist"
      v-if="loadingpagination"
    ></pagination>
    <el-dialog
      :title="diatitle"
      :visible.sync="dialogVisible"
      width="450px"
      custom-class="creatNumber"
      :close-on-click-modal="false"
    >
      <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
        <el-form-item label="单位名称：" :required="true">
          <el-input
            v-model="sizeForm.dwmc"
            placeholder="请输入"
            :disabled="ishow"
            maxlength="20"
          ></el-input>
        </el-form-item>
        <el-form-item label="单位账号：" :required="true">
          <el-input
            v-model="sizeForm.dwzh"
            placeholder="请输入"
            :disabled="ishow"
            maxlength="20"
          ></el-input>
        </el-form-item>
        <el-form-item label="密  码：" :required="true">
          <el-input
            v-model="sizeForm.password"
            placeholder="请输入"
            maxlength="20"
          ></el-input>
        </el-form-item>
        <el-form-item label="联系人：">
          <el-input
            v-model="sizeForm.lxr"
            placeholder="请输入"
            maxlength="8"
          ></el-input>
        </el-form-item>
        <el-form-item label="联系电话：">
          <el-input
            v-model="sizeForm.lxdh"
            placeholder="请输入"
            maxlength="11"
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div class="dialogfooter">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="confirm">保存</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "xwzgsq",
  components: {
    pagination,
    searchcomponment
  },
  data() {
    return {
      sizeForm: {
        dwmc: "",
        dwzh: "",
        password: "",
        lxr: "",
        lxdh: ""
      },
      loading2: false,
      tableHeight: null,
      total: 0,
      tableData: [],
      formInline: {
        user: ""
      },
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loadingpagination: true,
      multipleSelection: [],
      dialogVisible: false,
      diatitle: "添加",
      ishow: false
    };
  },
  filters: {},
  methods: {
    addload() {
      this.dialogVisible = true;
      this.sizeForm = {
        dwmc: "",
        dwzh: "",
        password: "",
        lxr: "",
        lxdh: ""
      };
      this.ishow = false;
    },
    confirm() {
      if (
        !this.sizeForm.dwmc ||
        !this.sizeForm.dwzh ||
        !this.sizeForm.password
      ) {
        return this.$message({
          message: "请将必填项填写完整",
          type: "error"
        });
      }
      if (this.diatitle == "添加") {
        this.$http.post("api/degree/depart/save", this.sizeForm).then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.dialogVisible = false;
            this.freshform();
          }
        });
      }
      if (this.diatitle == "修改") {
        this.$http.put("api/degree/depart/update", this.sizeForm).then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.dialogVisible = false;
            this.freshform();
          }
        });
      }
    },
    // 数据刷新
    freshform() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.userlist();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    loadDeptSelect() {
      this.$http.get("api/system/dict/noPermission").then(res => {
        // 学院与专业的联动
        this.genre = res.data.data;
        this.genres = this.genre[0].children;
      });
      this.$http.get("api/system/dict/select/grade").then(res => {
        // 年级
        if (!Array.isArray(res.data.data)) {
          return this.$message.error("数据异常,请刷新");
        } else {
          this.dictgrade = res.data.data.reverse();
          this.dictgrade.unshift({ value: "", label: "所有年级" });
        }
      });
    },
    deleteRow(index, scope) {
      this.dialogVisible = true;
      this.diatitle = "修改";
      this.$http.get(`api/degree/depart/info/${scope.row.id}`).then(res => {
        if (res.data.data) {
          if (res.data.data.status == "1") {
            this.ishow = true;
          }
          this.sizeForm = res.data.data;
        } else {
          this.$message({
            message: "数据异常",
            type: "error"
          });
        }
      });
    },
    onSubmit() {},
    deletelist() {
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据再进行通过操作");
      }
      this.$confirm("是否通过所有已选论文？", "一键通过", {
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      })
        .then(() => {
          this.$http
            .delete("api/degree/depart/delete", {
              data: this.multipleSelection
            })
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.freshform();
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "error",
            message: "已取消"
          });
        });
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    userlist() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/depart/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.loadDeptSelect();
    this.userlist();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style scoped lang="scss">
.qualificationtabletype {
  width: 100%;
  padding-top: 7px;
  .collegebtn {
    color: #409dff;
    background: #fff;
  }
  .dialogfooter {
    text-align: center;
  }
}
</style>
