<template>
  <div class="qualification">
    <template v-if="!ctrlloter">
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="待审核论文" name="first">
            <!-- 待审核 -->
            <lwdsh v-if="activeName=='first'" :center="ctrlloter" @formson="fromsonFn"></lwdsh>
          </el-tab-pane>
          <el-tab-pane label="已通过论文" name="second">
            <!-- 已审核 -->
            <lwysh v-if="activeName=='second'" :center="ctrlloter" @formson="fromsonFn"></lwysh>
          </el-tab-pane>
        </el-tabs>
      </div>
    </template>
    <lwlist v-else-if="ctrlloter" @formson="fromsonFn" :activeName="activeName"></lwlist>
  </div>
</template>
<script>
import lwdsh from "./lwzgcompment/lwdsh";
import lwysh from "./lwzgcompment/lwysh";
import lwlist from "./lwzgcompment/lwlist";
export default {
  name: "qualification",
  data() {
    return {
      activeName: "first",
      ctrlloter: false
    };
  },
  components: {
    lwdsh,
    lwysh,
    lwlist
  },
  methods: {
    fromsonFn(val) {
      this.ctrlloter = val;
    },
    handleClick() {}
  }
};
</script>

<style lang="scss" scoped>
.qualification {
  width: 100%;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      height: 42px;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 130px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
    /deep/ .el-tabs__active-bar {
      width: 120px !important;
      margin-bottom: 0px;
    }
  }
}
</style>

