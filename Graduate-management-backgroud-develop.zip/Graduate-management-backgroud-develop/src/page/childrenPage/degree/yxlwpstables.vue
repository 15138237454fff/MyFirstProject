<template>
  <div class="qualificationtabletype">
    <searchcomponment>
      <div slot="left">
        <el-select v-model="formInline.collegeCode" filterable @change="handleXYchange">
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genre" :key="index"></el-option>
        </el-select>
        <el-select v-model="formInline.studentStatus" filterable @change="freshform">
          <el-option :label="item.label" :value="item.value" v-for="(item, index) in genres" :key="index"></el-option>
        </el-select>
        <el-select v-model="formInline.dictgrade" filterable @change="freshform">
          <el-option :label="item + ' 级'" :value="item" v-for="(item, index) in dictgradenj" :key="index"></el-option>
        </el-select>
        <el-date-picker @change="freshform" v-model="formInline.usertime" type="daterange" range-separator="至" style="margin-top:3px;float:right;width:250px;margin-left:8px">
        </el-date-picker>
      </div>
      <div slot="right">
        <el-button type="primary" @click="submit" v-if="$btnAuthorityTest('yxlwps:allPass')">送审</el-button>
      </div>
    </searchcomponment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column label="评审账号" prop="zh"> </el-table-column>
      <el-table-column prop="mm" label="密码"></el-table-column>
      <el-table-column prop="lwtm" label="论文中文题目"></el-table-column>
      <el-table-column prop="xymc" label="学院"></el-table-column>
      <el-table-column prop="zymc" label="专业"></el-table-column>
      <el-table-column prop="nj" label="年级"></el-table-column>
      <el-table-column prop="xslb" label="学生类别"></el-table-column>
      <el-table-column prop="xsxm" label="学生姓名"></el-table-column>
      <el-table-column prop="ssjb" label="送审级别">
        <template slot-scope="scope">
          <span>{{ scope.row.ssjb | ssjb }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="cjsj" label="创建时间"></el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
    <el-dialog title="送审" :visible.sync="extractDialogVisible" width="20%" custom-class="extractDialog">
      <div class="extractDialog-body">
        <p style="margin-bottom:15px">
          选中送审论文<span style="color:#409EFF">{{
            multipleSelection.length
          }}</span>篇
        </p>
        <span>送审单位：</span>
        <el-select v-model="content.selectvalue">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <span slot="footer" class="dialog-footer">
        <div class="dialogfooter">
          <el-button @click="extractDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="cqlwconfirm">确定</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "qualificationtabletype",
  components: {
    pagination,
    searchcomponment
  },
  data() {
    return {
      loading2: false,
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null,
      total: 0,
      tableData: [],
      formInline: {
        usertime: [],
        collegeCode: "",
        studentStatus: "",
        dictgrade: ""
      },
      statustype: 0,
      name: "",
      status: {
        typeconst: 1,
        menu: 1
      },
      genre: [],
      genres: [],
      dictgradenj: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loadingpagination: true,
      content: {
        selectvalue: ""
      },
      options: [],
      extractDialogVisible: false,
      multipleSelection: []
    };
  },
  filters: {
    ssjb(val) {
      switch (val) {
        case "0":
          return "校级";
          break;
        case "1":
          return "院级";
          break;
        default:
          break;
      }
    }
  },
  watch: {
    // 监听学院下拉选则的数据
    // "formInline.collegeCode": {
    //   handler: function(val) {
    //     const tmp = this.genre.find(el => {
    //       return el.value === val;
    //     });
    //     if (!tmp) {
    //       return;
    //     }
    //     this.genres = tmp.children;
    //     this.formInline.studentStatus = this.genres[0].value;
    //     this.freshform();
    //   }
    // },
    // "formInline.studentStatus": {
    //   handler: function(val) {
    //     this.freshform();
    //   }
    // },
    // "formInline.dictgrade": {
    //   handler: function(val) {
    //     this.freshform();
    //   }
    // },
    // "formInline.usertime": {
    //   handler: function(val) {
    //     this.freshform();
    //   }
    // }
  },
  methods: {
    // 数据刷新
    freshform() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.userlist();
        this.listQuery.queryPage.pageNum = 1;
        this.listQuery.queryPage.pageSize = 15;
      }, 100);
    },
    submit() {
      this.content.selectvalue = "";
      this.multipleSelection.length == 0
        ? this.$message.error("请勾选数据再进行送审")
        : (this.extractDialogVisible = true);
    },
    cqlwconfirm() {
      if (!this.content.selectvalue) {
        return this.$message.error("请选择送审单位");
      }
      this.multipleSelection.forEach(element => {
        element.dwzh = this.content.selectvalue;
      });
      this.$http
        .post("api/degree/auditAccount/save", {
          jsid: this.$stores.state.roleid_tole,
          list: this.multipleSelection
        })
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.freshform();
            this.extractDialogVisible = false;
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            });
            this.extractDialogVisible = false;
          }
        });
    },
    loadDeptSelect() {
      return new Promise(resolve => {
        this.$http.get("api/system/dict/noPermission").then(res => {
          // 学院与专业的联动
          this.genre = res.data.data;
          this.genres = this.genre[0].children;
        });
        this.$http.get("api/degree/plea/stuNj").then(res => {
          resolve();
          // 年级
          if (!Array.isArray(res.data.data)) {
            return this.$message.error("数据异常,请刷新");
          } else {
            this.dictgradenj = res.data.data;
            if (
              Array.isArray(this.dictgradenj) &&
              this.dictgradenj.length !== 0
            ) {
              this.dictgradenj = this.dictgradenj.sort((a, b) => b - a);
              this.formInline.dictgrade = "" + Math.max(...this.dictgradenj);
            }
          }
        });
        this.$http.get("api/degree/depart/ssdwTree").then(res => {
          // 学院与专业的联动
          this.options = res.data.data;
        });
      });
    },
    onSubmit() {},
    handleXYchange(val) {
      const tmp = this.genre.find(el => {
        return el.value === val;
      });
      if (!tmp) {
        return;
      }
      this.genres = tmp.children;
      this.formInline.studentStatus = this.genres[0].value;
      this.freshform();
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push({
            dwzh: "",
            zh: row.zh
          });
        });
      }
    },
    userlist() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      var kssj = "";
      var jssj = "";
      if (!this.formInline.usertime) {
        kssj = "";
        jssj = "";
      } else {
        kssj = this.formInline.usertime[0];
        jssj = this.formInline.usertime[1];
      }
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/degree/auditAccount/list", {
          xydm: this.formInline.collegeCode,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          nj: this.formInline.dictgrade,
          zydm: this.formInline.studentStatus,
          status: "0",
          kssj: kssj,
          jssj: jssj
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.loadDeptSelect().then(this.userlist);
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  }
};
</script>

<style scoped lang="scss">
.qualificationtabletype {
  width: 100%;
  .collegebtn {
    color: #409dff;
    background: #fff;
  }
  .dialogfooter {
    text-align: center !important;
  }
  /deep/ .el-range-editor.el-input__inner {
    padding: 1px 0 !important;
  }
}
</style>
