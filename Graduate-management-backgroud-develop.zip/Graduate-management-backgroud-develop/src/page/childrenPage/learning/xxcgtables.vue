<template>
  <div class="xxcgtables">
    <template>
      <div class="studentmessage_box">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-form-item>
            <el-input
              v-model="formInline.user"
              placeholder="请输入学号/姓名"
              clearable
              @clear="clearinput"
            ></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleFind">查询</el-button>
          </el-form-item>
          <el-form-item>
            <el-select
              v-model="formInline.region"
              placeholder="全部成果类型"
              
              @change="cgtype"
            >
              <el-option
                :label="item.label"
                :value="item.value"
                v-for="(item, index) in genre"
                :key="index"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        v-loading="loading2"
        ref="multipleTable"
        style="width: 100%;"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column prop="taskId" label="序号" width="100">
        </el-table-column>
        <el-table-column prop="zyh" label="成果类型">
          <template slot-scope="scope">
            <span>{{ scope.row.resultsType | resultsType }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="resultsName" label="成果名称"></el-table-column>
        <el-table-column prop="name" label="申请人"></el-table-column>
        <el-table-column
          prop="studentNumber"
          label="申请人学号"
        ></el-table-column>
        <el-table-column prop="applyDate" label="申请时间"></el-table-column>
        <el-table-column label="系统状态">
          <template slot-scope="scope">
            <el-button
              @click.native.prevent="deleteRow(scope.$index, scope)"
              type="text"
              size="small"
              v-if="scope.row.status == 1"
              style="text-decoration:underline"
            >
              通过
            </el-button>
            <el-button
              @click.native.prevent="deleteRow(scope.$index, scope)"
              type="text"
              size="small"
              style="color:red;text-decoration:underline"
              v-if="scope.row.status == 0"
            >
              不通过
            </el-button>
            <el-button
              @click.native.prevent="deleteRow(scope.$index, scope)"
              type="text"
              size="small"
              v-if="scope.row.status == 2"
              style="text-decoration:underline"
            >
              退回
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          :current-page.sync="currentPage"
          :page-sizes="[15, 25, 50, 100]"
          :page-size="pagesize"
          class="import"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="changePage"
          :total="total"
          @size-change="sizeChange"
          background
        ></el-pagination>
      </div>
    </template>

    <!-- <learningcode v-else-if="this.$stores.state.learning_code ==true" :type="status"></learningcode> -->
  </div>
</template>

<script>
export default {
  props: {
    centercode: {
      type: Boolean
    }
  },
  name: "xxcgtables",
  data() {
    return {
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 15,
      currentPage: 1,
      loading2: false,
      total: 0,
      tableData: [],
      formInline: {
        user: "",
        region: ""
      },
      statustype: 0,
      name: "",
      status: {
        typeconst: 1,
        menu: 1
      },
      genre: [
        {
          value: "1",
          label: "学术论文"
        },
        {
          value: "2",
          label: "技术专利"
        },
        {
          value: "3",
          label: "发表著作"
        },
        {
          value: "4",
          label: "科研项目"
        }
      ],
      check: [
        {
          value: 1,
          label: "通过"
        },
        {
          value: 0,
          label: "不通过"
        },
        {
          value: 2,
          label: "退回"
        }
      ]
    };
  },
  filters: {
    resultsType(val) {
      if (val == "1") {
        return `学术论文`;
      } else if (val == "2") {
        return `技术专利`;
      } else if (val == "3") {
        return `发表著作`;
      } else if (val == "4") {
        return `科研项目`;
      } else {
        return val;
      }
    }
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    },
    cgtype() {
      this.currentPage = 1;
      this.userlist();
    },
    deleteRow(index, row) {
      this.$emit("xxcg", true);
      this.$stores.commit("typexxcg", row.row.resultsType);
      this.$storage.set("executionIdobj", row.row);
    },
    onSubmit() {},
    clearinput() {
      this.formInline.user = "";
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    yes() {
      this.currentPage = 1;
      this.userlist();
    },
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/academic/aac/checked", {
          status: this.formInline.region,
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.info;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    // this.pagesize = Math.floor(this.tableHeight / 57) - 1
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.xxcgtables {
  width: 100%;
  overflow: hidden;
  .studentmessage_box {
    width: 100%;
    // height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    // padding-top: 5px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
    /deep/ .el-form-item {
      margin-bottom: 0px !important;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
