<template>
  <div class="jccs_add">
    <div class="top-title">
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="grid-content bg-purple left">
            <el-button icon="el-icon-refresh-left" @click="retrunnewstudent" class="btn">返回列表</el-button>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="grid-content bg-purple right">
            <el-button type="primary" @click="onSubmit" v-if="type ==1">确定</el-button>
            <el-button type="primary" @click="onSubmit" v-if="type ==0">保存</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="formlist">
      <el-form ref="form" :model="sizeForm" label-width="150px" size="mini">
        <el-form-item label="字段名称" :required="true">
          <el-input v-model="sizeForm.name" style="width:400px"></el-input>
        </el-form-item>
        <el-form-item label="关联成果类型" :required="true">
          <el-select v-model="sizeForm.associationTypes" placeholder="请选择">
            <el-option :label="item.label" :value="item.value" v-for="(item,undex) in genre" :key="undex"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="字段类型" :required="true">
          <el-select v-model="sizeForm.genre" placeholder="请选择" @change="selectchange(sizeForm.genre)">
            <el-option :label="item.label" :value="item.value" v-for="(item,index) in  option" :key="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="内容" v-if="sizeForm.genre=='2'" :required="true">
          <div v-for="(item,index) in  content" :key="index" style="margin-bottom:5px">
            <el-input v-model="item.name" style="width:400px" placeholder="请输入内容"></el-input>
            <el-select v-model="item.status" placeholder="请选择" @change="selectchanges()" style="width:100px;">
              <el-option :label="item.label" :value="item.value" v-for="(item,index) in  optionlist" :key="index"></el-option>
            </el-select>
            <i class="el-icon-delete" @click="del(item,index)" v-if="index >0 && index!==content.length-1"></i>
            <i class="el-icon-circle-plus-outline" @click="add" v-if="index===content.length-1"></i>
          </div>
        </el-form-item>
        <el-form-item label="提示内容" v-if="sizeForm.genre=='1'" :required="true">
          <el-input v-model="subject" style="width:400px"></el-input>
        </el-form-item>
        </el-form-item>
        <el-form-item label="提示内容" v-if="sizeForm.genre=='3'" :required="true">
          <div class="custom-tree-container">
            <el-button type="primary" icon="el-icon-circle-plus-outline" circle @click="frist_add"></el-button>
            <el-button type="danger" icon="el-icon-delete" circle @click="frist_del"></el-button>
            <div class="block" style="margin-top:20px">
              <el-tree :data="selectTrees" node-key="id" default-expand-all :expand-on-click-node="false">
                <span class="custom-tree-node" slot-scope="{ node, selectTrees }">
                  <span style="font-size:16px">{{node.label}}</span>
                  <span>
                    <i class="el-icon-circle-plus-outline" @click="() => append(node.data)" style="color:#409EFF"></i>
                    <i class="el-icon-delete" @click="() => remove(node,node.data)" v-if="node.level !==1" style="color:red"></i>
                  </span>
                </span>
              </el-tree>
            </div>
          </div>
        </el-form-item>
        <el-form-item label="备注信息">
          <el-input type="textarea" v-model="sizeForm.remark"></el-input>
        </el-form-item>
      </el-form>
    </div>

  </div>
</template>
<script>
const id = 1000
import '@/components/common/common.scss';
export default {
  name: 'jccs_add',
  props: {
    type: Number
  },
  data() {
    const selectTrees = []
    return {
      subject: '',
      selectTrees: JSON.parse(JSON.stringify(selectTrees)),
      sizeForm: {},
      option: [
        {
          value: '2',
          label: '选择类型'
        },
        {
          value: '1',
          label: '消息提示'
        },
        {
          value: '3',
          label: '多级下拉联动'
        }
      ],
      optionlist: [
        {
          value: '0',
          label: '禁用'
        },
        {
          value: '1',
          label: '启用'
        }
      ],
      genre: [
        {
          value: '1',
          label: '学术论文'
        },
        {
          value: '2',
          label: '技术专利'
        },
        {
          value: '3',
          label: '发表著作'
        },
        {
          value: '4',
          label: '科研项目'
        }
      ],
      content: [
        {
          name: '',
          status: ''
        }
      ]
    }
  },
  mounted() {
    if (this.type == 0) {
      this.userlist()
    }
  },
  computed: {
    newName() {
      return this.sizeForm.genre
    }
  },
  watch: {
    newName(val) {
      if (val == '2') {
        this.sizeForm.subject = this.content
      } else if (val == '1') {
        this.sizeForm.subject = this.subject
      } else if (val == '3') {
        this.sizeForm.subject = this.selectTrees
      } else {
        this.sizeForm.subject = '';
      }
    },
    subject(val) {
      this.sizeForm.subject = val
    }
  },
  methods: {
    add() {
      if (this.content.length > 20) {
        alert('内容添加过多')
      } else {
        this.content.push({ name: '', status: '' })
      }
    },
    del(items, index) {
      this.content.splice(this.content.findIndex(item => item === items), 1)
    },
    addsavelist() {
      this.$http.post('api/academic/apc', this.sizeForm).then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.message,
            type: 'error'
          })
        } else {
          this.$store.state.jssc_add = false
          this.$parent.userlist()
          this.$parent.currentPage = 1
        }
      })
    },
    onSubmit() {
      if (this.type == 1) {
        this.addsavelist()
      }
      if (this.type == 0) {
        this.sizeForm.id = this.$storage.get('XS_id')
        this.$http
          .put('api/academic/apc/' + this.sizeForm.id, this.sizeForm)
          .then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.message,
                type: 'error'
              })
            } else {
              this.$store.state.jssc_add = false
              this.$parent.userlist()
              this.$parent.currentPage = 1
              this.$message({
                message: '修改成功',
                type: 'success'
              })
            }
          })
      }
    },
    selectchange(val) {
      console.log(val)
    },
    selectchanges() {},
    retrunnewstudent() {
      this.$store.state.jssc_add = false
    },
    frist_add() {
      this.$prompt('添加一级联动', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      })
        .then(({ value }) => {
          const newChild = { label: value, children: [] }
          this.$nextTick(() => {
            this.selectTrees.push(newChild)
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '取消输入'
          })
        })
    },
    frist_del() {
      this.selectTrees.splice(this.selectTrees.length - 1, 1)
    },
    append(data) {
      this.$prompt('添加一级联动', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      })
        .then(({ value }) => {
          this.$nextTick(() => {
            const newChild = { label: value, children: [] }
            if (!data.children) {
              this.$set(data, 'children', [])
            }
            data.children.push(newChild)
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '取消输入'
          })
        })
    },

    remove(node, data) {
      const parent = node.parent
      const children = parent.data.children || parent.data
      const index = children.findIndex(d => d.id === data.id)
      children.splice(index, 1)
    },
    userlist() {
      this.$http
        .get('api/academic/apc/' + this.$storage.get('XS_id'))
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: 'error'
            })
          } else {
            this.sizeForm = res.data.data
            this.sizeForm.associationTypes = `${res.data.data.associationTypes}`
            this.sizeForm.genre = `${res.data.data.genre}`
            if (this.sizeForm.genre == '2') {
              this.content = res.data.data.subject
            } else if (this.sizeForm.genre == '1') {
              this.subject = res.data.data.subject
            } else if (this.sizeForm.genre == '3') {
              this.selectTrees = res.data.data.subject
            } else {
              this.sizeForm.subject = '';
            }
          }
        })
    }
  }
}
</script>
<style lang="scss" scoped>
.jccs_add {
  width: 100%;
  overflow: hidden;
  .formlist {
    width: 800px;
    margin: 0 auto;
  }
}
</style>


