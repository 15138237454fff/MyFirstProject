<template>
  <div class="xxcgtablelist">
    <template v-if="this.$stores.state.learning_code == false">
      <div class="studentmessage_box">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-row :gutter="20">
            <el-col :span="16">
              <div class="grid-content bg-purple">
                <el-form-item>
                  <el-input v-model="formInline.user" placeholder="请输入学号/姓名" clearable @clear="clearinput"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-select v-model="formInline.region" placeholder="全部成果类型"  @change="cgtype">
                    <el-option :label="item.label" :value="item.value" v-for="(item,index) in genre" :key="index"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-button @click="handleFind">查询</el-button>
                </el-form-item>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple right">
                <el-form-item>
                  <el-button type="primary" @click="onSubmit">一键通过</el-button>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="onSubmit">一键不通过</el-button>
                </el-form-item>
              </div>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55"> </el-table-column>
        <el-table-column prop="zyh" label="成果类型">
        </el-table-column>
        <el-table-column prop="name" label="成果名称"></el-table-column>
        <el-table-column prop="xymc" label="申请人"></el-table-column>
        <el-table-column prop="zyh" label="申请人学号"></el-table-column>
        <el-table-column prop="zyh" label="申请时间"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button @click.native.prevent="deleteRow(scope.$index, tableData)" type="text" size="small">
              审核
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination :current-page.sync="currentPage" :page-sizes="[15, 25, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange" background></el-pagination>
      </div>
    </template>

    <!-- <learningcode v-else-if="this.$stores.state.learning_code ==true" :type="status"></learningcode> -->
  </div>
</template>

<script>
import learningcode from './learning_code';
export default {
  name: 'xxcgtablelist',
  data() {
    return {
      search: '',
      upmodel: '',
      upmodels: '',
      optionsadds: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 15,
      currentPage: 1,
      total: 0,
      tableData: [],
      formInline: {
        user: '',
        region: ''
      },
      statustype: '1',
      name: '',
      status: {
        typeconst: 1,
        menu: 0
      },
      genre: [
        {
          value: '1',
          label: '学术论文'
        },
        {
          value: '2',
          label: '技术专利'
        },
        {
          value: '3',
          label: '发表著作'
        },
        {
          value: '4',
          label: '科研项目'
        }
      ]
    }
  },
  components: {
    learningcode
  },
  methods: {
    deleteRow() {
      this.statustype = 0
      this.$stores.state.learning_code = true
    },
    onSubmit() {
      this.statustype = 1
      this.$stores.state.learning_code = true
    },
    clearinput() {
      this.search = '';
      this.currentPage = 1
      this.userlist()
    },
    handleFind() {
      this.currentPage = 1
      this.userlist()
    },
    yes() {
      this.currentPage = 1
      this.userlist()
    },
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val
      this.userlist()
    },
    sizeChange(val) {
      this.pagesize = val
      this.userlist()
    },
    userlist() {
      this.$http
        .post('api/academic/aac/checked', {
          status: this.formInline.region,
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.formInline.user
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            this.tableData = res.data.data.list
            this.total = res.data.data.total
          }
        })
    }
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160)
        this.pagesize = Math.floor(this.tableHeight / 57) - 1
      })()
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1
    this.userlist()
  }
}
</script>

<style scoped lang="scss">
.xxcgtablelist {
  width: 100%;
  overflow: hidden;
  .studentmessage_box {
    width: 100%;
    height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    padding-top: 5px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
    .right {
      text-align: right;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
