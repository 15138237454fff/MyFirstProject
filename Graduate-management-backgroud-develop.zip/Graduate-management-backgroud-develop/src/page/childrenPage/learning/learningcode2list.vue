<template>
  <div class="learning_code1">
    <div class="top-title">
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="grid-content bg-purple left">
            <el-button icon="el-icon-refresh-left" @click="retrunnewstudent" class="btn">返回列表</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <table>
      <thead>
        <tr>
          <th style="height:48px; font-size: 20px;" colspan="6">浙江财经大学研究生学术论文申请表</th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>作者信息</td>
      </tr>
      <tr>
        <td class="listcss">姓名</td>
        <td>{{content.xsxm}}</td>
        <td class="listcss">学号</td>
        <td>{{content.xh}}</td>
        <td class="listcss">学院</td>
        <td>{{content.xymc}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>关键信息</td>
      </tr>
      <tr>
        <td class="listcss">论文中文题目</td>
        <td colspan="5">{{content.lwmc}}</td>
      </tr>
      <tr>
        <td class="listcss">本人排名/总数</td>
        <td>{{content.brpm}}/{{content.zzzrs}}</td>
        <td class="listcss">是否是第一作者</td>
        <td>{{content.sfdyzz | sfdyzz}}</td>
        <td class="listcss">导师是否是第一作者</td>
        <td>{{content.dsdyzz |dsdyzz}}</td>
      </tr>
      <tr>
        <td class="listcss">刊号</td>
        <td style="width:300px">
          <span>刊号：{{content.kh}}</span>
          <span>刊号代码：{{content.khdm}}</span>
        </td>
        <td class="listcss">出版期刊名称</td>
        <td colspan="3">{{content.cbqkmc}}</td>
      </tr>
      <tr>
        <td class="listcss">发表/录用状态</td>
        <td>{{content.lwzt | lwzt}}</td>
        <td class="listcss">发表日期</td>
        <td>{{content.sj}}</td>
        <td class="listcss">刊出卷号</td>
        <td colspan="2">{{content.kcjh}}</td>
      </tr>
      <tr>
        <td class="listcss">收录佐证</td>
        <td @click="open(content.zz.url)" style="color:#0c64eb;margin-left:10px;">{{content.zz.fileName}}</td>
        <td class="listcss">期刊类别</td>
        <td>{{content.qklb}}</td>
        <td class="listcss"></td>
        <td></td>
      </tr>
      <template>
        <tr v-for="(content,index) in content.slxx">
          <td class="listcss">收录级别/影响因子/佐证</td>
          <td>
            {{content.sljb}}
          </td>
          <td colspan="2"> {{content.yxyz}}</td>
          <td>{{content.scfj.fileName}}</td>
          <td style="color:#0c64eb;margin-left:10px;" @click="open(content.scfj.url)">{{content.scfj.url}}</td>
        </tr>
      </template>

      <tr>
        <td class="listcss"> 备注</td>
        <td colspan="5">{{content.bz}}</td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: "learningcode2",
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ""
      },
      content: {},
      list: [],
      fileName: "",
      url: "",
      check: [
        {
          value: 1,
          label: "通过"
        },
        {
          value: 0,
          label: "不通过"
        },
        {
          value: 2,
          label: "退回"
        }
      ],
      options: [],
      value: "",
      slxx: {
        sljb: "",
        zz: "",
        yxyz: ""
      }
    };
  },
  mounted() {
    this.userlist();
  },
  filters: {
    sfdyzz(val) {
      return val == true ? "是" : "否";
    },
    dsdyzz(val) {
      return val == true ? "是" : "否";
    },
    lwzt(val) {
      return val == 1 ? "录用" : "发表";
    }
  },
  methods: {
    retrunnewstudent() {
      this.$stores.commit("INCREMENT", "learning_code2");
      this.$parent.userlist();
      this.$parent.currentPage = 1;
    },
    open(url) {
      window.open(url);
    },
    userlist() {
      this.$http.get("api/academic/thesisn/" + this.executionId).then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.message,
            type: "error"
          });
        } else {
          this.content = res.data.data;
          this.content.qklb = this.content.qklb.toString();
          this.$storage.addObjectKey(res.data.data, this.content);
          this.fileName = res.data.data.zz.fileName;
          this.url = res.data.data.zz.url;
        }
      });
    }
  },
  props: {
    executionId: String
  }
};
</script>
<style scoped lang="scss">
.learning_code1 {
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
}
</style>


