<template>
  <div class="learning_code1">
    <table>
      <thead>
        <tr>
          <th style="height:48px; font-size: 20px;" colspan="6">浙江财经大学研究生科研项目申请表</th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>作者信息</td>
      </tr>
      <tr>
        <td class="listcss">姓名</td>
        <td>{{content.xsxm}}</td>
        <td class="listcss">学号</td>
        <td>{{content.xh}}</td>
        <td class="listcss">学院</td>
        <td>{{content.xymc}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>关键信息</td>
      </tr>
      <tr>
        <td class="listcss">项目名称</td>
        <td colspan="5">{{content.xmmc}}</td>
      </tr>
      <tr>
        <td class="listcss">项目类型</td>
        <td>{{content.xmlx}}</td>
        <td class="listcss">项目具体类型</td>
        <td>{{content.xmjtlx}}</td>
        <td class="listcss">项目来源</td>
        <td>{{content.xmly}}</td>
      </tr>
      <tr>
        <td class="listcss">项目编号</td>
        <td>{{content.xmbh}}</td>
        <td class="listcss">是否是第一作者</td>
        <td>{{content.sfdyzz | sfdyzz}}</td>
        <td class="listcss">导师是否是第一作者</td>
        <td>{{content.sfdyzz | dsdyzz}}</td>
      </tr>
      <tr>
        <td class="listcss">本人排名/总数</td>
        <td>{{content.brpm}}/{{content.zzzrs}}</td>
        <td class="listcss">学生参与类别</td>
        <td>{{content.xscylb}}</td>
        <td class="listcss">导师参与类别</td>
        <td>{{content.dscylb}}</td>
      </tr>
      <tr>
        <td class="listcss">项目经费</td>
        <td>{{content.xmjf}}</td>
        <td class="listcss">项目开始时间</td>
        <td>{{content.xmkssj}}</td>
        <td class="listcss">项目结束时间</td>
        <td>{{content.xmjssj}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>项目详细信息</td>
      </tr>
      <tr>
        <td class="listcss">中文关键字</td>
        <td colspan="2">{{content.zwgjz}}</td>
        <td class="listcss">英文关键字</td>
        <td colspan="2">{{content.ywgjz}}</td>
      </tr>
      <tr>
        <td class="listcss">中文摘要</td>
        <td colspan="2">{{content.zwzy}}</td>
        <td class="listcss">英文摘要</td>
        <td colspan="2">{{content.ywzy}}</td>
      </tr>
      <tr>
        <td class="listcss">网络收录地址</td>
        <td colspan="5">{{content.wlsldz}}</td>
      </tr>
      <tr>
        <td class="listcss">附件</td>
        <td colspan="5" style="cursor:pointer;"><span style="color:#0c64eb;margin-left:10px;" @click="open(url)">{{fileName}}</span></td>
      </tr>
    </table>
    <div class="divcss5"></div>
    <el-steps :active="list.length" :space="200" style="margin-bottom:20px;">
      <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
        <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
        <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
        <span slot="description" class="comment">开始时间：{{item.startTime}}</span>
        <div slot="description" class="comment">结束时间：{{item.endTime}}</div>
      </el-step>
    </el-steps>
    <div class="divcss5" v-if="this.golist =='first'"></div>
    <el-form ref="form" :model="sizeForm" label-width="90px" size="mini" v-if="this.golist=='first'">
      <el-form-item label="审核：">
        <el-radio-group v-model="sizeForm.radio1">
          <el-radio-button :label="item.value" v-for="(item,index) in check" :key="index">{{item.label}}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：">
        <el-input type="textarea" placeholder="请输入内容" v-model="sizeForm.textarea" maxlength="30" show-word-limit style="width:90%">
        </el-input>
        <el-button type="primary" style="width:100px;" @click="save">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  name: 'learningcode4',
  data() {
    return {
      sizeForm: { radio1: 1, textarea: '' },
      fileName: '',
      url: '',
      content: {},
      list: [],
      check: [
        {
          value: 1,
          label: '通过'
        },
        {
          value: 0,
          label: '不通过'
        },
        {
          value: 2,
          label: '退回'
        }
      ]
    }
  },
  props: {
    golist: String
  },
  filters: {
    sfdyzz(val) {
      return val == true ? '是' : '否';
    },
    dsdyzz(val) {
      return val == true ? '是' : '否';
    }
  },
  mounted() {
    this.userlist()
    this.executionId()
  },
  methods: {
    // save() {
    //   this.$http
    //     .post("api/cultivate/aac/audit", {
    //       taskId: this.$storage.get("executionIdobj").taskId,
    //       check: this.sizeForm.radio1,
    //       comment: this.sizeForm.textarea
    //     })
    //     .then(res => {
    //       if (res.data.code == 400) {
    //         this.$message({
    //           message: res.data.message,
    //           type: "error"
    //         });
    //       } else {
    //         this.$router.go(0);
    //       }
    //     });
    // },
    open(url) {
      window.open(url)
    },
    save() {
      if(this.sizeForm.radio1 != 1 && this.sizeForm.textarea == ''){
        this.$message.warning('请输入评审意见')
        return;
      }
      this.$http
        .post('api/academic/aac/audit', {
          taskId: this.$storage.get('executionIdobj').taskId,
          check: this.sizeForm.radio1,
          comment: this.sizeForm.textarea
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: 'error'
            })
          } else {
            this.$router.go(0)
          }
        })
    },
    userlist() {
      this.$http
        .get(
          'api/academic/rpc/' + this.$storage.get('executionIdobj').executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: 'error'
            })
          } else {
            this.content = res.data.data
            this.$storage.addObjectKey(res.data.data, this.content)
            this.fileName = res.data.data.fj.fileName
            this.url = res.data.data.fj.url
          }
        })
    },

    executionId() {
      this.$http
        .get(
          'api/academic/aac/' + this.$storage.get('executionIdobj').executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            this.list = res.data.data
          }
        })
    }
  }
}
</script>
<style scoped lang="scss">
.learning_code1 {
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  .divcss5 {
    height: 1px;
    width: 100%;
    border-bottom: 1px dashed #e0e0e0;
    margin: 10px 0 10px 0;
  }
}
</style>


