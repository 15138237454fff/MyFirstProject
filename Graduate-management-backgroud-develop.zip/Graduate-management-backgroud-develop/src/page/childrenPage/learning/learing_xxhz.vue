<template>
  <div class="learing_xxhz">
    <template
      v-if="
        $stores.state.learning_code1 == false &&
          $stores.state.learning_code2 == false &&
          $stores.state.learning_code3 == false &&
          $stores.state.learning_code4 == false
      "
    >
      <div class="studentmessage_box">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-row :gutter="20">
            <el-col :span="16">
              <div class="grid-content bg-purple">
                <el-form-item>
                  <el-input
                    v-model="formInline.user"
                    placeholder="请输入学号/姓名"
                    clearable
                    @clear="clearinput"
                  ></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button @click="handleFind">查询</el-button>
                </el-form-item>
                <el-form-item>
                  <el-select
                    v-model="formInline.grade"
                    placeholder="全部年级"
                    @change="gradecall"
                    
                  >
                    <el-option
                      :label="item.label"
                      :value="item.value"
                      v-for="(item, index) in grade"
                      :key="index"
                    ></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-select
                    v-model="formInline.collegeCode"
                    placeholder="全部学院"
                    @change="gradecall"
                    
                  >
                    <el-option
                      :label="item.label"
                      :value="item.value"
                      v-for="(item, index) in coll"
                      :key="index"
                    ></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-select
                    v-model="formInline.region"
                    placeholder="全部成果类型"
                    
                    @change="cgtype"
                  >
                    <el-option
                      :label="item.label"
                      :value="item.value"
                      v-for="(item, index) in genre"
                      :key="index"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple right">
                <el-form-item>
                  <el-button
                    type="primary"
                    @click="onSubmit"
                    v-if="$btnAuthorityTest('learing_xxhz:export')"
                    >导出</el-button
                  >
                </el-form-item>
              </div>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        ref="multipleTable"
        style="width: 100%;"
        v-loading="loading2"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column type="index" width="100" label="序号">
          <template slot-scope="scope">
            <span>{{ (currentPage - 1) * pagesize + scope.$index + 1 }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="studentNumber" label="学号"> </el-table-column>
        <el-table-column prop="name" label="姓名"></el-table-column>
        <el-table-column prop="college" label="学院"></el-table-column>
        <el-table-column prop="major" label="专业"></el-table-column>
        <el-table-column label="成果类型">
          <template slot-scope="scope">
            <span>{{ scope.row.resultsType | resultsType }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="resultsName" label="成果名称"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              @click.native.prevent="deleteRow(scope.$index, scope)"
              type="text"
              size="small"
              style="text-decoration:underline"
              v-if="$btnAuthorityTest('learing_xxhz:view')"
            >
              查看详情
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          :current-page.sync="currentPage"
          :page-sizes="[15, 25, 50, 100]"
          :page-size="pagesize"
          class="import"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="changePage"
          :total="total"
          @size-change="sizeChange"
          background
        ></el-pagination>
      </div>
    </template>
    <!-- 浙江财经大学研究生发表著作申请表3 -->
    <learningcode1
      v-else-if="$stores.state.learning_code1 == true"
      :executionId="executionId"
    ></learningcode1>
    <!-- 浙江财经大学研究生学术论文申请表1 -->
    <learningcode2
      v-else-if="$stores.state.learning_code2 == true"
      :executionId="executionId"
    ></learningcode2>
    <!-- 浙江财经大学研究生技术专利申请表2 -->
    <learningcode3
      v-else-if="$stores.state.learning_code3 == true"
      :executionId="executionId"
    ></learningcode3>
    <!-- 浙江财经大学研究生科研项目申请表4 -->
    <learningcode4
      v-else-if="$stores.state.learning_code4 == true"
      :executionId="executionId"
    ></learningcode4>
  </div>
</template>

<script>
import learningcode1 from "./learningcode1list";
import learningcode2 from "./learningcode2list";
import learningcode3 from "./learningcode3list";
import learningcode4 from "./learningcode4list";
import { mapMutations } from "vuex";
export default {
  name: "learing_xxhz",
  data() {
    return {
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 15,
      loading2: false,
      currentPage: 1,
      total: 0,
      tableData: [],
      formInline: {
        user: "",
        region: "",
        collegeCode: "",
        grade: ""
      },
      statustype: "1",
      name: "",
      status: 3,
      genre: [
        {
          value: "1",
          label: "学术论文"
        },
        {
          value: "2",
          label: "技术专利"
        },
        {
          value: "3",
          label: "发表著作"
        },
        {
          value: "4",
          label: "科研项目"
        }
      ],
      executionId: "",
      coll: [],
      grade: []
    };
  },
  filters: {
    resultsType(val) {
      if (val == "1") {
        return `学术论文`;
      } else if (val == "2") {
        return `技术专利`;
      } else if (val == "3") {
        return `发表著作`;
      } else if (val == "4") {
        return `科研项目`;
      } else {
        return val;
      }
    }
  },
  components: {
    learningcode1,
    learningcode2,
    learningcode3,
    learningcode4
  },
  methods: {
    njlist() {
      this.$http.get("api/system/dict/select/academy").then(res => {
        console.log(res);
        this.coll = res.data.data;
      });
      this.$http.get("api/system/dict/select/grade").then(res => {
        console.log(res);
        this.grade = res.data.data;
      });
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    },
    gradecall() {
      this.currentPage = 1;
      this.userlist();
    },
    cgtype() {
      this.currentPage = 1;
      this.userlist();
    },
    deleteRow(index, scope) {
      this.executionId = scope.row.executionId;
      console.log(this.executionId);
      this.status = scope.row.resultsType;
      console.log(this.status);
      switch (this.status) {
        case 1:
          this.$stores.commit("INCREMENT", "learning_code2");
          break;
        case 2:
          this.$stores.commit("INCREMENT", "learning_code3");
          break;
        case 3:
          this.$stores.commit("INCREMENT", "learning_code1");
          break;
        case 4:
          this.$stores.commit("INCREMENT", "learning_code4");
          break;
        default:
          break;
      }
    },
    onSubmit() {
      this.statustype = 1;
      this.$stores.state.learning_code = true;
    },
    clearinput() {
      this.formInline.user = "";
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    yes() {
      this.currentPage = 1;
      this.userlist();
    },
    indexMethod(index) {
      console.log(index);
    },
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/academic/aac/collect", {
          status: this.formInline.region,
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.formInline.user,
          collegeCode: this.formInline.collegeCode,
          grade: this.formInline.grade
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    // this.pagesize = Math.floor(this.tableHeight / 57) - 1;
    this.njlist();
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.learing_xxhz {
  width: 100%;
  overflow: hidden;
  padding-top: 10px;
  .studentmessage_box {
    width: 100%;
    // height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    // padding-top: 5px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
    .right {
      text-align: right;
    }
    /deep/ .el-form-item {
      margin-bottom: 0px !important;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
