<template>
  <div class="learning_code1">
    <table>
      <thead>
        <tr>
          <th style="height:48px; font-size: 20px;" colspan="6">浙江财经大学研究生学术论文申请表</th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>作者信息</td>
      </tr>
      <tr>
        <td class="listcss">姓名</td>
        <td>{{content.xsxm}}</td>
        <td class="listcss">学号</td>
        <td>{{content.xh}}</td>
        <td class="listcss">学院</td>
        <td>{{content.xymc}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>关键信息</td>
      </tr>
      <tr>
        <td class="listcss">论文中文题目</td>
        <td colspan="5">{{content.lwmc}}</td>
      </tr>
      <tr>
        <td class="listcss">本人排名/总数</td>
        <td>{{content.brpm}}/{{content.zzzrs}}</td>
        <td class="listcss">是否是第一作者</td>
        <td>{{content.sfdyzz | sfdyzz}}</td>
        <td class="listcss">导师是否是第一作者</td>
        <td>{{content.dsdyzz |dsdyzz}}</td>
      </tr>
      <tr>
        <td class="listcss">刊号</td>
        <td style="width:300px">
          <span>刊号：{{content.kh}}</span>
          <span>刊号代码：{{content.khdm}}</span>
        </td>
        <td class="listcss">出版期刊名称</td>
        <td colspan="3">{{content.cbqkmc}}</td>
      </tr>
      <tr>
        <td class="listcss">发表/录用状态</td>
        <td>{{content.lwzt | lwzt}}</td>
        <td class="listcss">发表日期</td>
        <td>{{content.sj}}</td>
        <td class="listcss">刊出卷号</td>
        <td colspan="2">{{content.kcjh}}</td>
      </tr>
      <tr>
        <td class="listcss">收录佐证</td>
        <td @click="open(content.zz.url)" style="color:#0c64eb;margin-left:10px;">{{content.zz.fileName}}</td>
        <td class="listcss">期刊类别</td>
        <td><span v-for="(name,index) in content.qklb" :key="'qklx' + index">{{name}}</span></td>
        <td class="listcss"></td>
        <td></td>
      </tr>
      <template>
        <tr v-for="(content,index) in content.slxx" :key="index">
          <td class="listcss">收录级别/影响因子/佐证</td>
          <td>
            {{content.sljb}}
          </td>
          <td colspan="2"> {{content.yxyz}}</td>
          <td style="color:#0c64eb;margin-left:10px;" @click="open(content.scfj.url)">{{content.scfj.fileName}}</td>
          <td></td>
        </tr>
      </template>

      <tr>
        <td class="listcss"> 备注</td>
        <td colspan="5">{{content.bz}}</td>
      </tr>
    </table>
    <div class="divcss5"></div>
    <el-steps :active="list.length" :space="200" style="margin-bottom:20px">
      <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
        <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
        <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
        <span slot="description" class="comment">开始时间：{{item.startTime}}</span>
        <div slot="description" class="comment">结束时间：{{item.endTime}}</div>
      </el-step>
    </el-steps>
    <div class="divcss5" v-if="this.golist=='first'"></div>
    <el-form ref="form" :model="sizeForm" label-width="120px" size="mini" v-if="this.golist=='first'">
      <el-form-item label="审核：">
        <el-radio-group v-model="sizeForm.radio1">
          <el-radio-button :label="item.value" v-for="(item,index) in check" :key="index">{{item.label}}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：">
        <el-input type="textarea" placeholder="请输入内容" v-model="sizeForm.textarea" maxlength="30" show-word-limit style="width:90%">
        </el-input>
        <el-button type="primary" style="width:100px;" @click="save">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  name: "learningcode2",
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ""
      },
      content: {},
      list: [],
      fileName: "",
      url: "",
      check: [
        {
          value: 1,
          label: "通过"
        },
        {
          value: 0,
          label: "不通过"
        },
        {
          value: 2,
          label: "退回"
        }
      ],
      options: [],
      value: "",
      slxx: {
        sljb: "",
        zz: "",
        yxyz: ""
      }
    };
  },
  props: {
    golist: String
  },
  mounted() {
    this.userlist();
    this.executionId();
  },
  filters: {
    sfdyzz(val) {
      return val == true ? "是" : "否";
    },
    dsdyzz(val) {
      return val == true ? "是" : "否";
    },
    lwzt(val) {
      return val == 1 ? "录用" : "发表";
    }
  },
  methods: {
    open(url) {
      window.open(url);
    },
    save() {
      if (this.sizeForm.radio1 != 1 && this.sizeForm.textarea == "") {
        this.$message.warning("请输入评审意见");
        return;
      }
      this.$http
        .post("api/academic/aac/audit", {
          taskId: this.$storage.get("executionIdobj").taskId,
          check: this.sizeForm.radio1,
          comment: this.sizeForm.textarea
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$router.go(0);
          }
        });
    },
    userlist() {
      this.$http
        .get(
          "api/academic/thesisn/" +
            this.$storage.get("executionIdobj").executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.content = res.data.data;
            this.$storage.addObjectKey(res.data.data, this.content);
            this.fileName = res.data.data.zz.fileName;
            this.url = res.data.data.zz.url;
          }
        });
    },

    executionId() {
      this.$http
        .get(
          "api/academic/aac/" + this.$storage.get("executionIdobj").executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.list = res.data.data;
          }
        });
    }
  }
};
</script>
<style scoped lang="scss">
.learning_code1 {
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  .divcss5 {
    height: 1px;
    width: 100%;
    border-bottom: 1px dashed #e0e0e0;
    margin: 10px 0 10px 0;
  }
}
</style>


