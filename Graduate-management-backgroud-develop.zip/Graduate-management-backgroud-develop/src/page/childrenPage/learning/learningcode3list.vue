<template>
  <div class="learning_code1">
    <div class="top-title">
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="grid-content bg-purple left">
            <el-button icon="el-icon-refresh-left" @click="retrunnewstudent" class="btn">返回列表</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <table>
      <thead>
        <tr>
          <th style="height:48px; font-size: 20px;" colspan="6">浙江财经大学研究生技术专利申请表</th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>作者信息</td>
      </tr>
      <tr>
        <td class="listcss">姓名</td>
        <td>{{content.xsxm}}</td>
        <td class="listcss">学号</td>
        <td>{{content.xh}}</td>
        <td class="listcss">学院</td>
        <td>{{content.xymc}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>关键信息</td>
      </tr>
      <tr>
        <td class="listcss">专利号</td>
        <td>{{content.zlh}}</td>
        <td class="listcss">专利名称</td>
        <td colspan="3">{{content.zlmc}}</td>
      </tr>
      <tr>
        <td class="listcss">专利类型</td>
        <td>{{content.zllx}}</td>
        <td class="listcss">排序/总人数</td>
        <td>{{content.brpm}}/{{content.zzzrs}}</td>
        <td class="listcss">申请时间</td>
        <td colspan="2">{{content.zlsqsj}}</td>
      </tr>
      <tr>
        <td class="listcss">状态</td>
        <td>{{content.zt}}</td>
        <td class="listcss">申请号</td>
        <td>{{content.sqh}}</td>
        <td class="listcss">公开时间</td>
        <td colspan="2">{{content.sqsj}}</td>
      </tr>
      <tr>
        <td class="listcss">是否是第一作者</td>
        <td>{{content.sfdyzz |sfdyzz}}</td>
        <td class="listcss">导师是否是第一作者</td>
        <td>{{content.dsdyzz |dsdyzz}}</td>
        <td class="listcss">专利所有单位</td>
        <td colspan="2">{{content.zlsydw}}</td>
      </tr>
      <tr>
        <td class="listcss">附件</td>
        <td colspan="5"><span @click="open(url)" style="color:#0c64eb;margin-left:10px;cusor:pointer">{{filename}}</span></td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: 'learningcode3',
  props: {
    executionId: String
  },
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ''
      },
      options: [],
      value: '',
      content: {},
      filename: '',
      url: '',
      list: [],
      check: [
        {
          value: 1,
          label: '通过'
        },
        {
          value: 0,
          label: '不通过'
        },
        {
          value: 2,
          label: '退回'
        }
      ]
    }
  },
  filters: {
    sfdyzz(val) {
      return val == true ? '是' : '否';
    },
    dsdyzz(val) {
      return val == true ? '是' : '否';
    }
  },
  methods: {
    open(val) {
      window.open(val)
    },
    retrunnewstudent() {
      this.$stores.commit('INCREMENT', 'learning_code3')
      this.$parent.userlist()
      this.$parent.currentPage = 1
    },
    userlist() {
      this.$http.get('api/academic/ptc/' + this.executionId).then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.message,
            type: 'error'
          })
        } else {
          this.content = res.data.data
          this.$storage.addObjectKey(res.data.data, this.content)
          this.filename = res.data.data.fj.fileName
          this.url = res.data.data.fj.url
        }
      })
    }
  },
  created() {
    this.userlist()
  }
}
</script>
<style scoped lang="scss">
.learning_code1 {
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
}
</style>


