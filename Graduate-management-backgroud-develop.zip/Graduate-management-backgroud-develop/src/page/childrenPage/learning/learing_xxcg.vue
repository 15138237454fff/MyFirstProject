<template>
  <div class="learing_jccs">
    <template v-if="!centercode">
      <el-tabs v-model="activeName" @tab-click="handleClick" class="tabs">
        <el-tab-pane label="待审核" name="first">
          <xxcgtable v-if="activeName=='first'" @xxcg="xxcg"></xxcgtable>
        </el-tab-pane>
        <el-tab-pane label="已审核" name="second">
          <xxcgtables v-if="activeName=='second'" @xxcg="xxcg"></xxcgtables>
        </el-tab-pane>
      </el-tabs>
    </template>
    <learning v-else-if="centercode" @xxcg="xxcg" :typelist='activeName'></learning>
  </div>
</template>

<script>
// import commonbus from "./bus";
import xxcgtable from './xxcgtable';
import xxcgtables from './xxcgtables';
import learning_code from './learning_code';
export default {
  name: 'learing_jccs',
  data() {
    return {
      activeName: 'first',
      centercode: false
    }
  },
  components: {
    xxcgtable,
    xxcgtables,
    learning: learning_code
  },
  methods: {
    handleClick() {},
    xxcg(val) {
      this.centercode = val
    }
  },
  mounted() {}
}
</script>
  
<style scoped lang="scss">
.learing_jccs {
  width: 100%;
  overflow: hidden;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      background: #f2f2f2;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 100px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
  }
  .studentmessage_box {
    width: 100%;
    height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    padding-top: 5px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
