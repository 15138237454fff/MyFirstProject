<template>
  <div class="learing_jccs">
    <template v-if="this.$store.state.jssc_add == false">
      <div class="studentmessage_box">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-row :gutter="20">
            <el-col :span="16">
              <div class="grid-content bg-purple">
                <el-form-item>
                  <el-input
                    v-model="formInline.user"
                    placeholder="请输入字段名称"
                    clearable
                    @clear="clearinput"
                  ></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" @click="handleFind">查询</el-button>
                </el-form-item>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple" style="text-align:right">
                <el-form-item>
                  <el-button
                    type="primary"
                    @click="onSubmit"
                    v-if="$btnAuthorityTest('learing_jccs:add')"
                    >添加</el-button
                  >
                </el-form-item>
              </div>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        ref="multipleTable"
        v-loading="loading2"
        style="width: 100%;"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column label="序号" width="100" prop="id"> </el-table-column>
        <el-table-column prop="name" label="字段名称"> </el-table-column>
        <el-table-column prop="associationTypes" label="关联成果类型">
          <template slot-scope="scope">
            <span>{{ scope.row.associationTypes | toUSD }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="genre" label="字段类型">
          <template slot-scope="scope">
            <span>{{ scope.row.genre | genretype }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="gmtCreate" label="创建时间"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              @click.native.prevent="deleteRow(scope.$index, scope)"
              v-if="$btnAuthorityTest('learing_jccs:update')"
              type="text"
              size="small"
              style=""
            >
              修改
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          :current-page.sync="currentPage"
          :page-sizes="[15, 25, 50, 100]"
          :page-size="pagesize"
          class="import"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="changePage"
          :total="total"
          @size-change="sizeChange"
          background
        ></el-pagination>
      </div>
    </template>

    <jccsadd
      v-else-if="this.$store.state.jssc_add == true"
      :type="statustype"
    ></jccsadd>
  </div>
</template>

<script>
import jccsadd from "./jccs_add";
export default {
  name: "learing_jccs",
  data() {
    return {
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 15,
      loading2: false,
      currentPage: 1,
      total: 0,
      tableData: [],
      formInline: {
        user: ""
      },
      statustype: 0,
      name: ""
    };
  },
  filters: {
    toUSD: function(value) {
      if (value == "1") {
        return `学术论文`;
      } else if (value == "2") {
        return `技术专利`;
      } else if (value == "3") {
        return `发表著作`;
      } else if (value == "4") {
        return `科研项目`;
      } else {
        return value;
      }
    },
    genretype(val) {
      if (val == "1") {
        return `提醒`;
      } else if (val == "2") {
        return `选择`;
      } else if (val == "3") {
        return `多级下拉框联动`;
      } else {
        return val;
      }
    }
  },
  components: {
    jccsadd
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    },
    deleteRow(index, row) {
      this.statustype = 0;
      this.$store.state.jssc_add = true;
      this.$storage.set("XS_id", row.row.id);
    },
    onSubmit() {
      this.statustype = 1;
      this.$store.state.jssc_add = true;
    },
    clearinput() {
      this.search = "";
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    yes() {
      this.currentPage = 1;
      this.userlist();
    },
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/academic/apc/list", {
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    // this.pagesize = Math.floor(this.tableHeight / 57) - 1;
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.learing_jccs {
  width: 100%;
  overflow: hidden;
  padding-top: 10px;
  .studentmessage_box {
    width: 100%;
    // height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    // padding-top: 5px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
    .right {
      text-align: right;
    }
    /deep/ .el-form-item {
      margin-bottom: 0px !important;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
