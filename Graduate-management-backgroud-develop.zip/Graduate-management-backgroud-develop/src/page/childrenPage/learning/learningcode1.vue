<template>
  <div class="learning_code1">
    <table>
      <thead>
        <tr>
          <th style="height:48px; font-size: 20px;" colspan="6">浙江财经大学研究生发表著作申请表</th>
        </tr>
      </thead>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>作者信息</td>
      </tr>
      <tr>
        <td class="listcss">姓名</td>
        <td>{{content.xsxm}}</td>
        <td class="listcss">学号</td>
        <td>{{content.xh}}</td>
        <td class="listcss">学院</td>
        <td>{{content.xymc}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>关键信息</td>
      </tr>
      <tr>
        <td class="listcss">著作名称</td>
        <td colspan="5">{{content.zzmc}}</td>
      </tr>
      <tr>
        <td class="listcss">著作类型</td>
        <td>{{content.zzlx}}</td>
        <td class="listcss">出版状态</td>
        <td>{{content.cbzt}}</td>
        <td class="listcss">排序/总人数</td>
        <td>{{content.brpm}}/{{content.zzzrs}}</td>
      </tr>
      <tr>
        <td class="listcss">是否是第一作者</td>
        <td>{{content.sfdyzz | sfdyzz}}</td>
        <td class="listcss">导师是否是第一作者</td>
        <td colspan="3">{{content.dsdyzz |dsdyzz}}</td>
      </tr>
      <tr>
        <td class="listcss">备注</td>
        <td colspan="5">{{content.bz}}</td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6"><span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>项目资助信息</td>
      </tr>
      <tr>
        <td class="listcss">资助来源名称</td>
        <td>{{content.zzlymc}}</td>
        <td class="listcss">资助号码</td>
        <td>{{content.zzhm}}</td>
        <td class="listcss">资助单位</td>
        <td>{{content.zzdw}}</td>
      </tr>
      <tr>
        <td class="listcss">附件</td>
        <td colspan="5"><span style="color:#0c64eb;margin-left:10px;cursor:pointer;" @click="open(url)">{{fileName}}</span></td>
      </tr>
    </table>
    <div class="divcss5"></div>
    <el-steps :active="list.length" :space="200" style="margin-bottom:20px">
      <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
        <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
        <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
        <span slot="description" class="comment">开始时间：{{item.startTime}}</span>
        <div slot="description" class="comment">结束时间：{{item.endTime}}</div>
      </el-step>
    </el-steps>
    <div class="divcss5" v-if="this.golist=='first'"></div>
    <el-form ref="form" :model="sizeForm" label-width="90px" size="mini" v-if="this.golist=='first'">
      <el-form-item label="审核：">
        <el-radio-group v-model="sizeForm.radio1">
          <el-radio-button :label="item.value" v-for="(item,index) in check" :key="index">{{item.label}}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：">
        <el-input type="textarea" placeholder="请输入内容" v-model="sizeForm.textarea" maxlength="30" show-word-limit style="width:90%">
        </el-input>
        <el-button type="primary" style="width:100px;" @click="save">提交</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  name: 'learningcode1',
  data() {
    return {
      sizeForm: {
        radio1: 1,
        textarea: ''
      },
      content: {},
      list: [],
      fileName: '',
      url: '',
      check: [
        {
          value: 1,
          label: '通过'
        },
        {
          value: 0,
          label: '不通过'
        },
        {
          value: 2,
          label: '退回'
        }
      ]
    }
  },
  props: {
    golist: String
  },
  mounted() {
    this.userlist()
    this.executionId()
  },
  filters: {
    sfdyzz(val) {
      return val == true ? '是' : '否';
    },
    dsdyzz(val) {
      return val == true ? '是' : '否';
    }
  },
  methods: {
    save() {
      console.log(this.sizeForm.radio1)
      if(this.sizeForm.radio1 != 1 && this.sizeForm.textarea == ''){
        this.$message.warning('请输入评审意见')
        return;
      }
      this.$http
        .post('api/academic/aac/audit', {
          taskId: this.$storage.get('executionIdobj').taskId,
          check: this.sizeForm.radio1,
          comment: this.sizeForm.textarea
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: 'error'
            })
          } else {
            this.$router.go(0)
          }
        })
    },
    open(url) {
      window.open(url)
    },
    userlist() {
      this.$http
        .get(
          'api/academic/pwc/' + this.$storage.get('executionIdobj').executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            this.content = res.data.data
            this.$storage.addObjectKey(res.data.data, this.content)
            this.fileName = res.data.data.fj.fileName
            this.url = res.data.data.fj.url
          }
        })
    },

    executionId() {
      this.$http
        .get(
          'api/cultivate/aac/' + this.$storage.get('executionIdobj').executionId
        )
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            this.list = res.data.data
          }
        })
    }
  }
}
</script>
<style scoped lang="scss">
.learning_code1 {
  width: 100%;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  .divcss5 {
    height: 1px;
    width: 100%;
    border-bottom: 1px dashed #e0e0e0;
    margin: 10px 0 10px 0;
  }
}
</style>


