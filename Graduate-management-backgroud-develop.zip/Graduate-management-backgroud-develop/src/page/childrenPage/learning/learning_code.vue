
<template>
  <div class="learning_code">
    <div class="top-title">
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="grid-content bg-purple left">
            <el-button icon="el-icon-refresh-left" @click="retrunnewstudent" class="btn">返回列表</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 浙江财经大学研究生发表著作申请表 -->
    <learningcode1 v-if="this.$stores.state.typexxcg == 3" :golist="this.typelist"></learningcode1>
    <!-- 浙江财经大学研究生学术论文申请表 -->
    <learningcode2 v-if="this.$stores.state.typexxcg == 1" :golist="this.typelist"></learningcode2>
    <!-- 浙江财经大学研究生技术专利申请表 -->
    <learningcode3 v-if="this.$stores.state.typexxcg == 2" :golist="this.typelist"></learningcode3>
    <!-- 浙江财经大学研究生科研项目申请表 -->
    <learningcode4 v-if="this.$stores.state.typexxcg == 4" :golist="this.typelist"></learningcode4>
  </div>
</template>
<script>
import learningcode1 from "./learningcode1";
import learningcode2 from "./learningcode2";
import learningcode3 from "./learningcode3";
import learningcode4 from "./learningcode4";
import "@/components/common/common.scss";
export default {
  name: "learning_code",
  data() {
    return {
      type: ""
    };
  },
  props: {
    typelist: String
  },
  components: {
    learningcode1,
    learningcode2,
    learningcode3,
    learningcode4
  },
  methods: {
    retrunnewstudent() {
      this.$emit("xxcg", false);
      // this.$parent.userlist();
    }
  },
  mounted() {}
};
</script>

<style scoped>
.learning_code {
  width: 100%;
  overflow: hidden;
}
</style>

