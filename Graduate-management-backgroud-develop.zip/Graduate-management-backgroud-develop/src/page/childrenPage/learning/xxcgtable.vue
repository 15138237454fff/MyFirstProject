<template>
  <div class="xxcgtable">
    <template>
      <div class="studentmessage_box">
        <el-form :inline="true" :model="formInline" class="demo-form-inline">
          <el-row :gutter="20">
            <el-col :span="16">
              <div class="grid-content bg-purple">
                <el-form-item>
                  <el-input
                    v-model="formInline.user"
                    placeholder="请输入学号/姓名"
                    clearable
                    @clear="clearinput"
                  ></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button @click="handleFind">查询</el-button>
                </el-form-item>
                <el-form-item>
                  <el-select
                    v-model="formInline.region"
                    placeholder="全部成果类型"
                    
                    @change="cgtype"
                  >
                    <el-option
                      :label="item.label"
                      :value="item.value"
                      v-for="(item, index) in genre"
                      :key="index"
                    ></el-option>
                  </el-select>
                </el-form-item>
              </div>
            </el-col>
            <el-col :span="8">
              <div class="grid-content bg-purple right">
                <el-form-item>
                  <el-button
                    type="primary"
                    @click="onSubmit"
                    v-if="$btnAuthorityTest('learing_xxcg:allPass')"
                    >一键通过</el-button
                  >
                </el-form-item>
                <el-form-item>
                  <el-button
                    type="danger"
                    @click="onPass"
                    v-if="$btnAuthorityTest('learing_xxcg:allBack')"
                    >一键不通过</el-button
                  >
                </el-form-item>
              </div>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        ref="multipleTable"
        style="width: 100%;"
        :height="tableHeight"
        v-loading="loading2"
        @selection-change="handleSelectionChange"
        @row-click="clickRow"
        @select-all="allClick"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column type="selection" width="55"> </el-table-column>
        <el-table-column label="成果类型">
          <template slot-scope="scope">
            <span>{{ scope.row.resultsType | resultsType }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="resultsName" label="成果名称"></el-table-column>
        <el-table-column prop="name" label="申请人"></el-table-column>
        <el-table-column
          prop="studentNumber"
          label="申请人学号"
        ></el-table-column>
        <el-table-column prop="applyDate" label="申请时间"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              @click.native.prevent="deleteRow(scope.$index, scope)"
              type="text"
              size="small"
              style="text-decoration:underline"
              v-if="$btnAuthorityTest('learing_xxcg:audit')"
            >
              审核
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          :current-page.sync="currentPage"
          :page-sizes="[15, 25, 50, 100]"
          :page-size="pagesize"
          class="import"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="changePage"
          :total="total"
          @size-change="sizeChange"
          background
        ></el-pagination>
      </div>
    </template>
    <!-- <learningcode v-else-if="this.$stores.state.learning_code ==true" :type="status"></learningcode> -->
    <el-dialog
      title="一键通过"
      :visible.sync="dialogVisible"
      width="30%"
      :before-close="handleClose"
    >
      <span>是否通过所有已选申请？</span>
      <span slot="footer" class="dialog-footer">
        <div class="footers">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="akeyby">确 定</el-button>
        </div>
      </span>
    </el-dialog>
    <el-dialog
      title="一键不通过"
      :visible.sync="dialogVisibles"
      width="30%"
      :before-close="cancelvisable"
    >
      <span>是否退回所有已选申请？</span>
      <el-form ref="ruleForm" label-width="150px" class="demo-ruleForm">
        <el-form-item label="请输入不通过原因：" :required="true">
        </el-form-item>
        <el-input type="text" v-model="pass" autocomplete="off"></el-input>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancelvisable">取 消</el-button>
        <el-button type="primary" @click="sruelistnav">确 定</el-button>
      </span>
    </el-dialog>
    <!-- <dialogs v-show="dialogVisible"></dialogs> -->
  </div>
</template>

<script>
// import dialogs from "@/components/dialogcommon";
export default {
  name: "xxcgtable",
  props: {
    centercode: {
      type: Boolean
    }
  },
  data() {
    return {
      upmodel: "",
      upmodels: "",
      optionsadds: [],
      tableHeight: null, // 表格高度
      clientHeight: 0, // 偏移量
      offsetTop: 0,
      pagesize: 15, // 条数
      currentPage: 1, // 页数
      total: 0,
      loading2: false,
      tableData: [], // 表格数据
      formInline: {
        user: "",
        region: ""
      },
      statustype: "",
      name: "",
      status: {
        // 父组件传值对象
        typeconst: 1,
        menu: 0
      },
      genre: [
        {
          value: "1",
          label: "学术论文"
        },
        {
          value: "2",
          label: "技术专利"
        },
        {
          value: "3",
          label: "发表著作"
        },
        {
          value: "4",
          label: "科研项目"
        }
      ],
      dialogVisible: false,
      multipleSelection: [],
      dialogVisibles: false,
      pass: ""
    };
  },
  // components: {
  //   dialogs
  // },
  filters: {
    resultsType(val) {
      if (val == "1") {
        return `学术论文`;
      } else if (val == "2") {
        return `技术专利`;
      } else if (val == "3") {
        return `发表著作`;
      } else if (val == "4") {
        return `科研项目`;
      } else {
        return val;
      }
    }
  },
  methods: {
    cancelvisable() {
      this.dialogVisibles = false;
    },
    sruelistnav() {
      this.pass !== ""
        ? this.$http
            .put("api/academic/aac/batchNoPass", {
              comment: this.pass,
              taskIds: this.multipleSelection
            })
            .then(res => {
              this.$message({
                message: res.data.message,
                type: "success"
              });
              this.dialogVisibles = false;
              this.currentPage = 1;
              this.userlist();
            })
        : this.$message({
            message: "请输入不通过原因",
            type: "error"
          });
    },
    handleClose() {
      this.dialogVisible = false;
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    },
    // handleClose() {},
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    allClick() {},
    deleteRow(index, scope) {
      this.$emit("xxcg", true);
      this.$stores.commit("typexxcg", scope.row.resultsType);
      this.$storage.set("executionIdobj", scope.row);
    },
    onSubmit() {
      this.multipleSelection.length == 0
        ? this.$message({
            message: "请勾选数据在进行操作",
            type: "error"
          })
        : (this.dialogVisible = true);
    },
    onPass() {
      this.multipleSelection.length == 0
        ? this.$message({
            message: "请勾选数据在进行操作",
            type: "error"
          })
        : (this.dialogVisibles = true);
    },
    clearinput() {
      this.formInline.user = "";
      this.currentPage = 1;
      this.userlist();
    },
    cgtype() {
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    handleSelectionChange(val) {
      this.multipleSelection = [];
      if (val) {
        val.forEach(row => {
          this.multipleSelection.push(row.taskId);
        });
      }
      console.log(this.multipleSelection);
    },
    akeyby() {
      this.$http
        .put("api/academic/aac/batchPass", this.multipleSelection)
        .then(res => {
          this.$message({
            message: res.data.message,
            type: "success"
          });
          this.dialogVisible = false;
          this.currentPage = 1;
          this.userlist();
        });
    },
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/academic/aac/toAudit", {
          status: this.formInline.region,
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.info;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    // this.pagesize = Math.floor(this.tableHeight / 57) - 1
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.xxcgtable {
  width: 100%;
  overflow: hidden;
  .studentmessage_box {
    width: 100%;
    // height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    // padding-top: 5px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
    .right {
      text-align: right;
    }
    /deep/ .el-form-item {
      margin-bottom: 0px !important;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .footers {
    text-align: center;
  }
}
</style>
<style lang="scss">
.studentmessage_box {
  width: 100%;
  // height: 60px;
  padding-left: 10px;
  margin-bottom: 10px;
  // padding-top: 5px;
  .span {
    margin-left: 15px;
    font-weight: 500;
    color: #606266;
    font-family: verdana, arial, sans-serif;
    font-size: 14px;
  }
  .right {
    text-align: right;
  }
  /deep/ .el-form-item {
    margin-bottom: 0px !important;
  }
}
</style>
