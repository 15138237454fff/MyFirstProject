// 培养计划审核
<template>
  <div class="election">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">
        返回列表
      </el-button>
    </div>
    <div class="personal-details">
      <el-form :model="form" label-width="200px" ref="form" class="myform">
        <el-row>
          <el-col :span="8">
            <el-form-item label="学号：">
              <el-input v-model="form.xh" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="姓名：">
              <el-input v-model="form.xm" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="专业">
              <el-input v-model="form.zy" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="研究方向：">
              <el-input v-model="form.yjfx" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学制：">
              <el-input v-model="form.xz" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="导师：">
              <el-input v-model="form.dsxm" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="border-bottom: 1px solid #eee;">
          <el-col :span="8">
            <el-form-item label="已选总学分：">
              <el-input v-model="form.zxf" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label=""> </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label=""> </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="main-container">
      <el-tabs v-model="activeName" @tab-click="handleClick" style="position: relative; top: 17px;">
        <el-tab-pane label="学位课" name="first"></el-tab-pane>
        <el-tab-pane label="选修课" name="second"></el-tab-pane>
        <el-tab-pane label="必修环节" name="third"></el-tab-pane>
        <!-- <el-tab-pane label="计划外课程" name="fourth"></el-tab-pane> -->
      </el-tabs>
      <el-row style="width: 100%;">
        <div class="statistics">
          <span>总门数: {{ totalClass }}</span>
          <span>总学分：{{ totalScore }}</span>
          <span v-if="activeName !== 'third'">总学时：{{ totalTime }}</span>
          <div class="minimum">最低学分要求：{{ minScore }}</div>
        </div>
      </el-row>
      <el-table v-if="activeName === 'first'" :data="xwkList" border ref="multipleTable" style="width: 100%;margin-top:10px" :header-cell-style="$storage.tableHeaderColor" :span-method="objectSpanMethod">
        <el-table-column prop="kcmc" label="课程">
          <!-- <template slot-scope="scope">
            <span>{{ `${scope.row.kch} ${scope.row.kcmc}` }}</span>
          </template> -->
        </el-table-column>
        <el-table-column prop="xf" label="学分" width="100"> </el-table-column>
        <el-table-column prop="zxs" label="学时" width="100"> </el-table-column>
        <el-table-column prop="kkxq" label="开课学年学期"> </el-table-column>
        <el-table-column prop="kcsxh" label="课程属性"> </el-table-column>
        <el-table-column prop="kcxzh" label="考试形式"> </el-table-column>
        <el-table-column prop="tgcj" label="通过成绩"> </el-table-column>
        <!-- <el-table-column prop="zsxzsl" label="课程组"> </el-table-column> -->
      </el-table>
      <el-table :data="xxkList" border ref="multipleTable" style="width: 100%;margin-top:10px" :header-cell-style="$storage.tableHeaderColor" v-if="activeName === 'second'">
        <el-table-column prop="kcmc" label="课程">
          <!-- <template slot-scope="scope">
            <span>{{ `${scope.row.kch} ${scope.row.kcmc}` }}</span>
          </template> -->
        </el-table-column>
        <el-table-column prop="xf" label="学分" width="100"> </el-table-column>
        <el-table-column prop="zxs" label="学时" width="100"> </el-table-column>
        <el-table-column prop="kkxq" label="开课学年学期"> </el-table-column>
        <el-table-column prop="kcsxh" label="课程属性"> </el-table-column>
        <el-table-column prop="kcxzh" label="考试形式"> </el-table-column>
        <el-table-column prop="tgcj" label="通过成绩"> </el-table-column>
      </el-table>
      <el-table :data="bxhjList" border ref="multipleTable" style="width: 100%;margin-top:10px" :header-cell-style="$storage.tableHeaderColor" v-if="activeName === 'third'">
        <el-table-column prop="mc" label="名称"></el-table-column>
        <el-table-column prop="xf" label="学分" width="100"></el-table-column>
        <el-table-column prop="kcsxh" label="课程属性" width="100">
        </el-table-column>
        <el-table-column prop="fzr" label="负责人"> </el-table-column>
        <el-table-column prop="kkxq" label="学年学期"> </el-table-column>
        <el-table-column prop="bz" label="备注"> </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
export default {
  props: ["row"],
  name: "election",
  data() {
    return {
      list: [],
      form: {},
      bottomform: {
        audit: "通过"
      },
      fileList: [],
      tableData: [],
      degreemin: "",
      activeName: "first",
      xwkList: [], // 学位课列表
      xxkList: [], // 选修课列表
      bxhjList: [], // 必修环节列表
      jhwList: [], // 计划外课程列表
      totalClass: "",
      totalScore: "",
      totalTime: "",
      minScore: "" // 最低总学分
    };
  },
  methods: {
    exitList() {
      this.$store.state.electiondetails = false;
      this.$parent.takeList();
    },
    getList() {
      this.$http
        .get("api/cultivate/pygrpyjhb/infoByLcid2?xh=" + this.row.xh)
        .then(res => {
          const myRes = res.data.data;
          this.form = myRes.xsGrpyjhbsqVo;
          this.xwkList = myRes.xwkList;
          // let tmpArr = [];
          // this.xwkList.forEach(el => {
          //   if (el.kcz === null) {
          //     el.rowspan = 1;
          //     return;
          //   }
          //   if (tmpArr.includes(el.kcz)) {
          //     el.rowspan = 0;
          //   } else {
          //     el.zsxzsl = `最少选择${el.zsxzsl}门课`;
          //     tmpArr.push(el.kcz);
          //     el.rowspan = this.xwkList.filter(
          //       obj => obj.kcz === el.kcz
          //     ).length;
          //   }
          // });
          this.xwkList.forEach(el => {
            el.kcmc = el.kch + " " + el.kcmc;
          });
          this.xxkList = myRes.xxkList;
          this.xxkList.forEach(el => {
            el.kcmc = el.kch + " " + el.kcmc;
          });
          this.bxhjList = myRes.bxhjList;
          this.jhwList = myRes.jhwList;
          this.tableData = this.xwkList;
          this.xwkgrade = myRes.xsGrpyjhbsqVo.xwkmath;
          this.totalClass = this.xwkgrade.split(",")[0];
          this.totalScore = this.xwkgrade.split(",")[1];
          this.totalTime = this.xwkgrade.split(",")[2];
          this.xxkgrade = myRes.xsGrpyjhbsqVo.xxkmath;
          this.bxhjgrade = myRes.xsGrpyjhbsqVo.bxhjmath;
          this.jhwgrade = myRes.xsGrpyjhbsqVo.jhwmath;
          this.xwkMin = myRes.xsGrpyjhbsqVo.xwkMin;
          this.xxkMin = myRes.xsGrpyjhbsqVo.xxkMin;
          this.bxhjMin = myRes.xsGrpyjhbsqVo.bxhjMin;
          this.minScore = this.xwkMin;
          this.list = res.data.data.list;
        })
        .catch(function(err) {
          console.log(err);
        });
    },
    handleClick() {
      if (this.activeName == "first") {
        this.tableData = this.xwkList;
        this.totalClass = this.xwkgrade.split(",")[0];
        this.totalScore = this.xwkgrade.split(",")[1];
        this.totalTime = this.xwkgrade.split(",")[2];
        this.minScore = this.xwkMin;
      } else if (this.activeName == "second") {
        this.tableData = this.xxkList;
        this.totalClass = this.xxkgrade.split(",")[0];
        this.totalScore = this.xxkgrade.split(",")[1];
        this.totalTime = this.xxkgrade.split(",")[2];
        this.minScore = this.xxkMin;
      } else if (this.activeName == "third") {
        this.tableData = this.bxhjList;
        this.totalClass = this.bxhjgrade.split(",")[0];
        this.totalScore = this.bxhjgrade.split(",")[1];
        this.totalTime = this.bxhjgrade.split(",")[2];
        this.minScore = this.bxhjMin;
      }
      //  else if (this.activeName == "fourth") {
      //   this.tableData = this.jhwList;
      //   this.totalClass = this.jhwgrade.split(",")[0];
      //   this.totalScore = this.jhwgrade.split(",")[1];
      //   this.totalTime = this.jhwgrade.split(",")[2];
      // }
    },
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      // 行，列，行号，列号
      if (columnIndex == 7) {
        if (row.rowspan) {
          return {
            rowspan: row.rowspan,
            colspan: 1
          };
        } else if (row.rowspan == 0) {
          return {
            rowspan: 0,
            colspan: 0
          };
        }
      }
    }
  },
  mounted() {
    this.getList();
  }
};
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
.election {
  overflow: hidden;
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .personal-details,
  .family-information {
    width: 100%;
    margin-top: 15px;
    .el-row {
      // height: 50px;
      width: 100%;
      .el-col {
        // height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
    .title {
      font-size: 20px;
      font-weight: bold;
      text-align: center;
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
  .step {
    margin-top: 20px;
  }
  .submitButton {
    margin-top: 15px;
    position: absolute;
    left: 50%;
    margin-left: -20px;
  }
  .main-container {
    width: 100%;
    border: 1px solid #eee;
    margin-top: 10px;
    box-sizing: border-box;
    padding: 0 10px 10px 10px;
    .statistics {
      height: 40px;
      width: 100%;
      background: #f5f5f5;
      line-height: 40px;
      padding-right: 20px;
      span {
        font-size: 14px;
        color: #666;
        margin-left: 30px;
      }
      .minimum {
        float: right;
        font-size: 14px;
        color: #666;
      }
    }
  }
  .table {
    width: 100%;
    .addClass {
      margin-top: 15px;
    }
  }
}

.election /deep/ .myform .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.election /deep/ .myrow > .el-form-item__label {
  line-height: 120px;
}
.election /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.election /deep/ .el-form-item__label {
  text-align: center;
}
</style>
