<!-- 培养计划查询 -->
<template>
  <div class="trainSearch">
    <div class="container" v-if="$store.state.electiondetails == false">
      <componment>
        <div slot="left">
          <el-input v-model="searchField" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="searchData" class="top-input" suffix-icon="el-icon-search"></el-input>
          <el-button @click="searchData" style="margin-left:5px">查询</el-button>
          <el-select v-model="college" filterable style="margin-left: 10px;" class="top-input" @change="selectall">
            <el-option v-for="(item, index) in collegeList" :key="index" :label="item.dwmc" :value="item.dwh">
            </el-option>
          </el-select>
          <el-select v-model="major" filterable style="margin-left: 10px;" class="top-input">
            <el-option v-for="(item, index) in majorList" :key="index" :label="item.zymc" :value="item.zyh" @change="selectmajor">
            </el-option>
          </el-select>
          <el-select v-model="grade" filterable style="margin-left: 10px;" class="top-input" @change="selectgrade">
            <el-option v-for="item in gradeList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
            </el-option>
          </el-select>
        </div>
      </componment>
      <el-table :data="tableData" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
        <el-table-column type="index" label="序号" width="150">
        </el-table-column>
        <el-table-column prop="xh" label="学号" width="150"> </el-table-column>
        <el-table-column prop="xsxm" label="姓名"> </el-table-column>
        <el-table-column prop="xslbmc" label="学生类别"> </el-table-column>
        <el-table-column prop="dwmc" label="学院"> </el-table-column>
        <el-table-column prop="zy" label="专业"> </el-table-column>
        <el-table-column prop="sznj" label="年级"> </el-table-column>
        <el-table-column prop="zxf" label="已选总学分"> </el-table-column>
        <el-table-column prop="status" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="checkDetails(scope.row)" v-if="$btnAuthorityTest('trainSearch:view')">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
    </div>
    <election v-else-if="$store.state.electiondetails == true" :row="row"></election>
  </div>
</template>

<script>
import election from "./election/election";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "trainSearch",
  data() {
    return {
      searchField: "", // 搜索的数据
      tableData: [],
      collegeList: [], // 单位列表
      major: "",
      majorList: [
        {
          value: "选项1",
          label: "全部专业"
        }
      ],
      grade: "",
      gradeList: [],
      college: "", // 选中单位
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      row: {},
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  methods: {
    selectall() {
      this.getzy(this.college);
      this.major = "";
      this.takeList();
    },
    selectmajor() {
      this.takeList();
    },
    selectgrade() {
      this.takeList();
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post(`api/cultivate/pygrpyjhb/selectAllStuPlan`, {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          nj: this.grade,
          xy: this.college,
          zy: this.major
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
          this.tableData.map((item, index) => {
            item.myid = index + 1;
          });
          res.data.data.list.map((item, index) => {
            const obj = {
              value: item.dwh,
              label: item.dwmc
            };
            this.collegeList.push(obj);
          });
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查询列表
    checkDetails(row) {
      this.$store.state.electiondetails = true;
      this.row = row;
    }, // 查看详情
    searchData() {
      this.takeList();
    }, // 搜索数据方法
    registerInfor() {}, // 导出数据
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectDwList").then(res => {
        if (res.data.data.length > 1) {
          this.collegeList = res.data.data;
          this.collegeList.unshift({ dwh: "", dwmc: `全部学院` });
        } else {
          this.collegeList = res.data.data;
        }
      });
    },
    getzy(val) {
      this.$http
        .get(`api/cultivate/pyfa/selectZyByDwh?dwh=${val}`)
        .then(res => {
          if (res.data.data.length > 1) {
            this.majorList = res.data.data;
            this.majorList.unshift({ zyh: "", zymc: "全部专业" });
          } else {
            this.majorList = res.data.data;
          }
        });
    },
    getnj() {
      this.$http.get(`api/cultivate/pyfa/selectNjList`).then(res => {
        if (res.data.data.length > 1) {
          this.gradeList = res.data.data;
          this.gradeList.unshift({ njKey: "", njValue: "全部年级" });
        } else {
          this.gradeList = res.data.data;
        }
      });
    }
  },
  mounted() {
    this.getNumber();
    this.getzy(this.college);
    this.getnj();
    this.tableHeight = document.documentElement.clientHeight - 266;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 266;
      })();
    };
    this.takeList();
  },
  components: {
    election,
    pagination,
    componment
  }
};
</script>

<style scoped lang="scss">
.trainSearch {
  width: 100%;
  padding-top: 7px;
}
</style>
