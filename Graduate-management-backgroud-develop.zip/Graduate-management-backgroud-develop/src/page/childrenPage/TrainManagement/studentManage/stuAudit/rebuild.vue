<!-- 重修 -->
<template>
  <div class="rebuild">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="personal-details">
      <el-form :model="form" label-width="200px" ref="form" class="myform">
        <el-row>
          <el-col :span="24">
            <p class="title" style="position: relative; overflow: hidden;">
              <span :class="{yes1: auditStatus == '成功',back1: auditStatus == '退回' || auditStatus == '失败',audit1: auditStatus == '审核中'}" style="display: inline-block; position: absolute; height: 100%; width: 120px; transform: skew(-30deg); left: -20px;">
                <span class="on-mystatus">{{auditStatus}}</span>
              </span>
              浙江财经大学研究生重修申请表
            </p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="姓名：">
              <el-input v-model="form.xm" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学号：">
              <el-input v-model="form.xh" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学生类别：">
              <el-input v-model="form.xslbmc" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="学院：">
              <el-input v-model="form.yxsh" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="专业：">
              <el-input v-model="form.zy" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="导师：">
              <el-input v-model="form.dsxm" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="重修课程：">
              <el-input v-model="form.cxkc" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="原成绩">
              <el-input v-model="form.ycj" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学分：">
              <el-input v-model="form.xf" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="原修读学年学期：">
              <el-input v-model="form.yxdxnxq" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="重修学年学期">
              <el-input v-model="form.cxxnxq" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="跟读班级：">
              <el-input v-model="form.gdbj" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="height: 200px;" class="myrow">
          <el-col :span="24" style="height: 100%;">
            <el-form-item label="申请理由：" style="height: 100%; line-height: 200px; padding-right: 20px;" :required="true">
              <el-input v-model="form.reason" type="textarea" :rows="8" style="margin-top: 10px; margin-left: 10px;" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="step">
      <el-steps :active="list.length" :space="200">
        <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
          <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
          <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
          <span slot="description" class="comment">{{item.endTime}}</span>
          <div slot="description" class="comment">{{item.comment}}</div>
        </el-step>
      </el-steps>
    </div>
    <el-form :model="bottomform" label-width="200px" ref="bottomform" style="margin-top: 20px;" v-show="status">
      <el-row>
        <el-col :span="24">
          <el-form-item label="审核：">
            <el-radio-group v-model="bottomform.audit">
              <el-radio-button label="通过"></el-radio-button>
              <el-radio-button label="退回"></el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="height: 200px;" class="myrow">
        <el-col :span="24" style="height: 100%;">
          <el-form-item label="审核意见：" style="height: 100%; line-height: 200px; padding-right: 20px;" :required="true">
            <el-input v-model="bottomform.idea" type="textarea" :rows="8" style="margin-top: 10px;"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-button type="primary" @click="submitHandle" class="submitButton" v-show="status">提交</el-button>
  </div>
</template>

<script>
export default {
  props: ["row", "status"],
  name: "rebuild",
  data() {
    return {
      form: {},
      bottomform: {
        audit: "通过"
      },
      fileList: [],
      list: [],
      auditStatus: ""
    };
  },
  methods: {
    submitHandle() {
      if (this.bottomform.audit == "通过") {
        this.$http
          .post("api/cultivate/activityCultivate/saveOrder", {
            check: 1,
            comment: this.bottomform.idea,
            taskId: this.row.id,
            taskKey: this.row.taskDefinitionKey,
            type: "1"
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "提交成功",
                type: "success"
              });
              this.$store.state.rebuild = false;
              this.$parent.takeList(1, "stuKcsq");
            } else {
              this.$message.error({
                message: "提交失败"
              });
            }
          })
          .catch(function(err) {
            console.log(err);
          });
      }
      // else if (this.bottomform.audit == '不通过') {
      // 	this.$http
      // 		.post("api/backgroudpage/activity/saveOrder", {
      // 			check: 0,
      // 			comment: this.bottomform.idea,
      // 			taskId: this.row.id,
      // 			taskKey: this.row.taskDefinitionKey
      // 		})
      // 		.then(res => {
      // 			if(res.data.code == 200) {
      // 				this.$message({
      // 					message: '提交成功',
      // 					type: 'success'
      // 				})
      // 				this.$store.state.rebuild = false
      // 				this.$parent.takeList(1, 'stuInfo')
      // 			} else {
      // 				this.$message.error({
      // 					message: '提交失败'
      // 				})
      // 			}
      // 		})
      // 		.catch(function(err) {
      // 			console.log(err)
      // 		})
      // }
      else if (this.bottomform.audit == "退回") {
        this.$http
          .post("api/cultivate/activityCultivate/back", {
            businesskey: this.row.processVariables.businesskey,
            check: 2,
            comment: this.bottomform.idea,
            executionId: this.row.executionId,
            processDefinitionId: this.row.processDefinitionId,
            processInstanceId: this.row.processInstanceId,
            taskId: this.row.id,
            taskKey: this.row.taskDefinitionKey,
            name: this.row.processVariables.name,
            type: "1"
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "提交成功",
                type: "success"
              });
              this.$store.state.rebuild = false;
              this.$parent.takeList(1, "stuKcsq");
            } else {
              this.$message.error({
                message: "提交失败"
              });
            }
          })
          .catch(function(err) {
            console.log(err);
          });
      }
    }, // 提交
    exitList() {
      this.$store.state.rebuild = false;
    },
    takeList() {
      this.$http
        .get("api/cultivate/kcsq/infoByLcid?lcid=" + this.row.processInstanceId)
        .then(res => {
          // console.log(res.data.data.xsXjydsqTxsqVo)
          this.form = res.data.data.xsKcsqInitVo;
          this.form.reason = res.data.data.pyXskcsq.sqly;
          // this.form.xxy = res.data.data.pyXjydb.xyxsh
          // this.form.xzy = res.data.data.pyXjydb.xzym
          // this.form.xds = res.data.data.pyXjydb.xdsh
          // this.form.xyjxk = res.data.data.pyXjydb.xyjxk
          // this.fileList = res.data.data.pyXjydb.firstfj
          this.list = res.data.data.list;
          this.auditStatus =
            res.data.data.pyXskcsq.zt == "0"
              ? "失败"
              : res.data.data.pyXskcsq.zt == "1"
              ? "成功"
              : res.data.data.pyXskcsq.zt == "2"
              ? "审核中"
              : res.data.data.pyXskcsq.zt == "4"
              ? "退回"
              : "";
        })
        .catch(function(err) {
          console.log(err);
        });
    }
  },
  mounted() {
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
p.title {
  margin: 0;
  padding: 0;
  height: 50px;
  color: #333;
  line-height: 50px;
  width: 100%;
  span.circle {
    color: #2779e3;
    margin-right: 5px;
  }
}
.on-mystatus {
  display: inline-block;
  transform: skew(30deg);
  color: #fff;
}
.rebuild {
  .top-title {
    width: 100%;
    height: 60px;
    background: #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .personal-details,
  .family-information {
    width: 100%;
    margin-top: 15px;
    .el-row {
      // height: 50px;
      width: 100%;
      .el-col {
        // height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
    .title {
      font-size: 20px;
      font-weight: bold;
      text-align: center;
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
  .step {
    margin-top: 20px;
  }
  .submitButton {
    margin-top: 15px;
    position: absolute;
    left: 50%;
    margin-left: -20px;
  }
}

.rebuild /deep/ .myform .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.rebuild /deep/ .myrow > .el-form-item__label {
  line-height: 120px;
}
.rebuild /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.rebuild /deep/ .el-form-item__label {
  text-align: center;
}
</style>