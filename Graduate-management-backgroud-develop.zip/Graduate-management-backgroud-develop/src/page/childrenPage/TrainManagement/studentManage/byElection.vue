<!-- 补选(退选)处理 -->
<template>
  <div class="byElection">
    <template v-if="$store.state.electiondetails == false">
      <componment>
        <div slot="left">
          <el-input
            v-model="searchField"
            placeholder="请输入学号/姓名"
            style="width: 200px"
            @keyup.enter.native="searchData"
            class="top-input"
            suffix-icon="el-icon-search"
          ></el-input>
          <el-button @click="searchData" style="margin-left:5px"
            >查询</el-button
          >
          <el-select
            v-model="college"
            filterable
            placeholder="全部学院"
            style="margin-left: 10px;"
            class="top-input"
          >
            <el-option
              v-for="item in collegeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
          <el-select
            v-model="major"
            filterable
            placeholder="全部专业"
            style="margin-left: 10px;"
            class="top-input"
          >
            <el-option
              v-for="item in majorList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div slot="right">
          <el-button
            type="primary"
            @click="registerInfor"
            v-if="$btnAuthorityTest('byElection:import')"
            >批量注册</el-button
          >
        </div>
      </componment>
      <el-table
        :data="tableData"
        border
        ref="multipleTable"
        style="width: 100%"
        @row-click="clickRow"
        @selection-change="mySelect"
        @select-all="allClick"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading2"
        element-loading-text="加载中"
      >
        <el-table-column
          :show-overflow-tooltip="true"
          type="selection"
          width="55"
        >
        </el-table-column>
        <el-table-column prop="number" label="学号" width="150">
        </el-table-column>
        <el-table-column prop="name" label="姓名"> </el-table-column>
        <el-table-column prop="type" label="学生类别"> </el-table-column>
        <el-table-column prop="college" label="学院"> </el-table-column>
        <el-table-column prop="major" label="专业"> </el-table-column>
        <el-table-column prop="level" label="年级"> </el-table-column>
        <el-table-column prop="status" label="操作">
          <template slot-scope="scope">
            <el-button
              type="text"
              @click="checkDetails(scope.row)"
              v-if="$btnAuthorityTest('byElection:view')"
              >查看详情</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="takeList"
      ></pagination>
    </template>
    <election v-else-if="$store.state.electiondetails == true"></election>
  </div>
</template>

<script>
import election from "./election/election";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "byElection",
  data() {
    return {
      searchField: "", // 搜索的数据
      tableData: [],
      collegeList: [
        {
          value: "选项1",
          label: "全部学院"
        },
        {
          value: "选项2",
          label: "单位1"
        },
        {
          value: "选项3",
          label: "单位2"
        }
      ], // 单位列表
      major: "",
      majorList: [
        {
          value: "选项1",
          label: "全部专业"
        }
      ],
      college: "", // 选中单位
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  methods: {
    checkDetails() {
      this.$store.state.electiondetails = true;
    }, // 查看详情
    searchData() {}, // 搜索数据方法
    registerInfor() {}, // 导出数据
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {}, // 列表选择
    allClick(selection) {} // 列表全选
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.loading2 = true;
    setTimeout(() => {
      this.loading2 = false;
    }, 500);
  },
  components: {
    election,
    pagination,
    componment
  }
};
</script>

<style scoped lang="scss">
.byElection {
  width: 100%;
  padding-top: 7px;
}
</style>
