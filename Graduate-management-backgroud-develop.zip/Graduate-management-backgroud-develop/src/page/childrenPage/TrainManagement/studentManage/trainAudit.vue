<!-- 培养计划审核 -->
<template>
  <div class="trainAudit">
    <div class="container" v-if="this.$store.state.train == false && !comtainer">
      <el-tabs v-model="activeName" @tab-click="tabChangeClick" class="top-nav">
        <el-tab-pane label="待审核" name="first">
          <componment>
            <div slot="left">
              <el-input v-model="search" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind" clearable @clear="clearinput" suffix-icon="el-icon-search"></el-input>
              <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
              <el-select v-model="college" filterable style="width: 200px;" @change="selectall">
                <el-option v-for="(item, index) in collegeList" :key="index" :label="item.dwmc" :value="item.dwh">
                </el-option>
              </el-select>
              <el-select v-model="major" filterable style="width: 200px;" @change="majorselect">
                <el-option v-for="(item, index) in majorList" :key="index" :label="item.zymc" :value="item.zyh">
                </el-option>
              </el-select>
              <el-select v-model="grade" filterable style="width: 200px;" @change="gradeselect">
                <el-option v-for="item in gradeList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
                </el-option>
              </el-select>
            </div>
          </componment>
          <el-table :data="tableData1" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
            <el-table-column type="index" label="序号" width="150">
            </el-table-column>
            <el-table-column prop="xh" label="学号" width="150">
            </el-table-column>
            <el-table-column prop="xm" label="姓名"> </el-table-column>
            <el-table-column prop="xslb" label="学生类别"> </el-table-column>
            <el-table-column prop="xy" label="学院"> </el-table-column>
            <el-table-column prop="zy" label="专业"> </el-table-column>
            <el-table-column prop="sznj" label="年级"> </el-table-column>
            <el-table-column prop="zxf" label="已选总学分"> </el-table-column>
            <el-table-column label="当前审核环节">
              <template slot-scope="scope">
                <el-button type="text" @click="checkDetails(scope.row)" v-if="$btnAuthorityTest('trainAudit:audit')">{{ scope.row.name }}</el-button>
              </template>
            </el-table-column>
          </el-table>
          <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
        </el-tab-pane>
        <el-tab-pane label="已审核" name="second">
          <componment>
            <div slot="left">
              <el-input v-model="search2" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind2" clearable @clear="clearinput2" suffix-icon="el-icon-search"></el-input>
              <el-button @click="handleFind2" style="margin-left:5px">查询</el-button>
              <el-select v-model="college2" filterable style="width: 200px;" @change="selectalls">
                <el-option v-for="(item, index) in collegeList" :key="index" :label="item.dwmc" :value="item.dwh">
                </el-option>
              </el-select>
              <el-select v-model="major2" filterable style="width: 200px;" @change="college2select">
                <el-option v-for="(item, index) in majorList" :key="index" :label="item.zymc" :value="item.zyh">
                </el-option>
              </el-select>
              <el-select v-model="grade2" filterable style="width: 200px;" @change="grade2select">
                <el-option v-for="item in gradeList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
                </el-option>
              </el-select>
            </div>
          </componment>
          <el-table :data="tableData2" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
            <el-table-column type="index" label="序号" width="150">
            </el-table-column>
            <el-table-column prop="xh" label="学号" width="150">
            </el-table-column>
            <el-table-column prop="xm" label="姓名"> </el-table-column>
            <el-table-column prop="xslb" label="学生类别"> </el-table-column>
            <el-table-column prop="xy" label="学院"> </el-table-column>
            <el-table-column prop="zy" label="专业"> </el-table-column>
            <el-table-column prop="sznj" label="年级"> </el-table-column>
            <el-table-column prop="zxf" label="总学分"> </el-table-column>
            <el-table-column label="审核详情" prop="status">
              <template slot-scope="scope">
                <el-button type="text" @click="checkDetails2(scope.row)" v-if="$btnAuthorityTest('trainAudit:view')">{{ scope.row.status }}</el-button>
              </template>
            </el-table-column>
          </el-table>
          <pagination :total="total2" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
        </el-tab-pane>
      </el-tabs>
    </div>
    <train v-else-if="this.$store.state.train == true" :row="row" :status="status"></train>
    <tzAudit v-else-if="comtainer" @tzAuditshow="Auditshow" :row="row" :status="status"></tzAudit>
  </div>
</template>

<script>
import train from "./trainAudit/train";
import tzAudit from "./trainAudit/tzAudit";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "trainAudit",
  data() {
    return {
      comtainer: false,
      tableData1: [],
      tableData2: [],
      search: "",
      search2: "",
      activeName: "first",
      college: "", // 所选学院
      college2: "",
      collegeList: [], // 所有学院列表
      major: "",
      major2: "",
      majorList: [],
      grade: "",
      grade2: "",
      gradeList: [],
      total: 0,
      total2: 0,
      tableHeight: null,
      row: {},
      status: "",
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  methods: {
    Auditshow(val) {
      this.comtainer = val;
    },
    majorselect() {
      this.takeList();
    },
    gradeselect() {
      this.takeList();
    },
    clearinput() {
      this.search = "";
      this.takeList();
    },
    clearinput2() {
      this.search2 = "";
      this.takeList();
    },
    college2select() {
      this.takeList();
    },
    grade2select() {
      this.takeList();
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      if (this.activeName == "first") {
        this.$http
          .post("api/cultivate/activityCultivate/taskStuInfoList", {
            pageNum: params.pageNum,
            pageSize: params.pageSize,
            query: this.search,
            dw: this.college,
            zy: this.major,
            nj: this.grade,
            definitionKeyLike: "stuTrainingPlan",
            type: "1"
          })
          .then(res => {
            this.loading2 = false;
            if (res.data.code == 200 && res.data.data.list.length > 0) {
              this.tableData1 = res.data.data.list;
              this.total = res.data.data.total;
              this.tableData1.map((item, index) => {
                item.myid = index + 1;
              });
            } else {
              this.tableData1 = [];
              this.total = 1;
            }
          })
          .catch(err => {
            console.log(err.message);
            this.loading2 = false;
          });
      } else if (this.activeName == "second") {
        this.$http
          .post(`api/cultivate/activityCultivate/getHistoryAudit`, {
            pageNum: params.pageNum,
            pageSize: params.pageSize,
            query: this.search2,
            dw: this.college2,
            zy: this.major2,
            nj: this.grade2,
            definitionKeyLike: "stuTrainingPlan",
            type: "1"
          })
          .then(res => {
            this.loading2 = false;
            this.tableData2 = res.data.data.list;
            this.total2 = res.data.data.total;
            this.tableData2.map((item, index) => {
              item.myid = index + 1;
            });
            res.data.data.list.map((item, index) => {
              this.tableData2[index].status =
                item.state == "0"
                  ? "不通过"
                  : item.state == "1"
                  ? "通过"
                  : item.state == "2"
                  ? "退回"
                  : "";
            });
          })
          .catch(err => {
            console.log(err.message);
            this.loading2 = false;
          });
      }
    }, // 获取列表
    tabChangeClick(tab, event) {
      this.search = "";
      this.search2 = "";
      this.college = "";
      this.college2 = "";
      this.major = "";
      this.major2 = "";
      this.grade = "";
      this.grade2 = "";
      this.takeList();
      this.getNumber();
    }, // 切换审核
    handleFind() {
      this.takeList();
    },
    handleFind2() {
      this.takeList();
    },
    checkDetails(row) {
      if (
        row.processDefinitionId.indexOf("stuTrainingPlanChangeApply") !== -1
      ) {
        this.comtainer = true;
      } else {
        this.$store.state.train = true;
      }
      this.row = row;
      this.status = true;
    }, // 查看详情
    checkDetails2(row) {
      if (
        row.processDefinitionId.indexOf("stuTrainingPlanChangeApply") !== -1
      ) {
        this.comtainer = true;
      } else {
        this.$store.state.train = true;
      }
      this.row = row;
      this.status = false;
    },
    selectall() {
      this.getzy(this.college);
      this.major = "";
      this.takeList();
    },
    selectalls() {
      this.getzy(this.college2);
      this.takeList();
    },
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectDwList").then(res => {
        if (res.data.data.length > 1) {
          this.collegeList = res.data.data;
          this.collegeList.unshift({ dwh: "", dwmc: `全部学院` });
        } else {
          this.collegeList = res.data.data;
          this.college = res.data.data[0].dwh;
          this.college2 = res.data.data[0].dwh;
        }
      });
    },
    getzy(val) {
      this.$http
        .get(`api/cultivate/pyfa/selectZyByDwh?dwh=${val}`)
        .then(res => {
          if (res.data.data.length > 1) {
            this.majorList = res.data.data;
            this.majorList.unshift({ zyh: "", zymc: "全部专业" });
          } else {
            this.majorList = res.data.data;
          }
        });
    },
    getnj() {
      this.$http.get(`api/cultivate/pyfa/selectNjList`).then(res => {
        if (res.data.data.length > 1) {
          this.gradeList = res.data.data;
          this.gradeList.unshift({ njKey: "", njValue: "全部年级" });
        } else {
          this.gradeList = res.data.data;
        }
      });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 266;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 266;
      })();
    };
    this.getNumber();
    this.getzy(this.college);
    this.getnj();
    this.takeList();
  },
  components: {
    train,
    pagination,
    componment,
    tzAudit
  }
};
</script>

<style scoped lang="scss">
.trainAudit {
  .container {
    .top-nav {
      /deep/ .el-tabs__nav-wrap {
        background: #fff;
      }
      /deep/ .el-tabs__nav {
        margin-left: 15px;
      }
      /deep/ .el-tabs__item {
        width: 100px;
        text-align: center;
      }
      /deep/ .el-tabs__header {
        margin: 0 0 7px;
      }
      /deep/ .el-tabs__active-bar {
        width: 80px !important;
      }
    }
  }
}
</style>
