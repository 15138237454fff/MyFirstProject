// 培养计划审核
<template>
  <div class="train">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="personal-details">
      <el-form :model="form" label-width="200px" ref="form" class="myform">
        <el-row>
          <el-col :span="8">
            <el-form-item label="学号：">
              <el-input v-model="form.xh" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="姓名：">
              <el-input v-model="form.xm" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学院">
              <el-input v-model="form.zy" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="专业">
              <el-input v-model="form.zy" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="研究方向：">
              <el-input v-model="form.yjfx" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学制：">
              <el-input v-model="form.xz" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="border-bottom: 1px solid #eee;">
          <el-col :span="8">
            <el-form-item label="导师：">
              <el-input v-model="form.dsxm" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="已选总学分：">
              <el-input v-model="form.zxf" class="lookOnly" :disabled="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label=""> </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="main-container">
      <el-tabs v-model="activeName" @tab-click="handleClick" style="position: relative; top: 17px;">
        <el-tab-pane label="学位课" name="first"></el-tab-pane>
        <el-tab-pane label="选修课" name="second"></el-tab-pane>
        <el-tab-pane label="必修环节" name="third"></el-tab-pane>
      </el-tabs>
      <el-row style="width: 100%;">
        <div class="statistics">
          <span>总门数: {{ totalClass }}</span>
          <span>总学分：{{ totalScore }}</span>
          <span v-if="totalTime">总学时：{{ totalTime }}</span>
          <div class="minimum" v-show="activeName != 'fourth'">
            最低学分要求：{{ minScore }}
          </div>
        </div>
      </el-row>
      <el-table v-if="activeName !== 'third'" :data="tableData" border ref="multipleTable" style="width: 100%">
        <el-table-column prop="kch" label="课程号"> </el-table-column>
        <el-table-column prop="kcmc" label="课程名称"> </el-table-column>
        <el-table-column prop="xf" label="学分" width="100"> </el-table-column>
        <el-table-column prop="zxs" label="学时" width="100"> </el-table-column>
        <el-table-column prop="kkxq" label="开课学年学期"> </el-table-column>
        <el-table-column prop="kcsxh" label="课程属性"> </el-table-column>
        <el-table-column prop="kcxzh" label="课程性质"> </el-table-column>
        <el-table-column prop="tgcj" label="通过成绩"> </el-table-column>
      </el-table>
      <el-table v-else :data="tableData" border ref="multipleTable" style="width: 100%">
        <el-table-column prop="mc" label="名称" align="center"></el-table-column>
        <el-table-column prop="xf" label="学分" align="center" width="200"></el-table-column>
        <el-table-column prop="kcsxh" label="课程属性" align="center"></el-table-column>
        <el-table-column prop="fzr" label="负责人" align="center"></el-table-column>
        <el-table-column prop="kkxq" label="学年学期" align="center"></el-table-column>
        <el-table-column prop="bz" label="备注" align="center"></el-table-column>
      </el-table>
    </div>
    <table>
      <tr>
        <td class="left_cont" colspan="6">
          <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>更改原因
        </td>
      </tr>
      <tr>
        <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" v-model="ggyy" :disabled="true">
        </el-input>
      </tr>
    </table>

    <div class="step">
      <el-steps :active="list.length" :space="200">
        <el-step v-for="(item, index) in list" :key="index" :icon="
            item.state == '1' || item.state == null
              ? 'el-icon-circle-check'
              : item.state == '2'
              ? 'el-icon-d-arrow-left'
              : 'el-icon-close'
          ">
          <div slot="title" class="mytext">
            {{ item.name + "(" + item.assignee + ")" }}
          </div>
          <span slot="description" :class="{
              yes: item.state == '1',
              back: item.state == '2' || item.state == '0'
            }">{{
              item.state == "1"
                ? "通过"
                : item.state == "0"
                ? "不通过"
                : item.state == "2"
                ? "退回"
                : ""
            }}</span>&nbsp;&nbsp;
          <span slot="description" class="comment">{{ item.endTime }}</span>
          <div slot="description" class="comment">{{ item.comment }}</div>
        </el-step>
      </el-steps>
    </div>
    <el-form :model="bottomform" label-width="200px" ref="bottomform" style="margin-top: 20px;" v-show="status">
      <el-row>
        <el-col :span="24">
          <el-form-item label="审核：">
            <el-radio-group v-model="bottomform.audit">
              <el-radio-button label="通过"></el-radio-button>
              <el-radio-button label="退回"></el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="height: 200px;" class="myrow">
        <el-col :span="24" style="height: 100%;">
          <el-form-item label="审核意见：" style="height: 100%; line-height: 200px; padding-right: 20px;" :required="true">
            <el-input v-model="bottomform.idea" type="textarea" :rows="8" style="margin-top: 10px;"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div style="text-align:center">
      <el-button type="primary" @click="submitHandle" class="submitButton" v-show="status">提交</el-button>
    </div>
  </div>
</template>

<script>
export default {
  props: ["row", "status"],
  name: "train",
  data() {
    return {
      list: [],
      form: {},
      bottomform: {
        audit: "通过"
      },
      fileList: [],
      list: [],
      tableData: [],
      degreemin: "",
      activeName: "first",
      xwkList: [], // 学位课列表
      xxkList: [], // 选修课列表
      bxhjList: [], // 必修环节列表
      jhwList: [], // 计划外课程列表
      totalClass: "",
      totalScore: "",
      totalTime: "",
      minScore: "" // 最低总学分
    };
  },
  methods: {
    submitHandle() {
      if (this.bottomform.audit == "通过") {
        this.$http
          .post("api/cultivate/activityCultivate/saveOrder", {
            check: 1,
            comment: this.bottomform.idea,
            taskId: this.row.id,
            taskKey: this.row.taskDefinitionKey,
            type: "1"
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.data,
                type: "success"
              });
              this.$emit("tzAuditshow", false);
              this.$parent.takeList();
            } else {
              this.$message.error({
                message: res.data.data
              });
            }
          })
          .catch(function(err) {
            console.log(err);
          });
      } else if (this.bottomform.audit == "退回") {
        this.$http
          .post("api/cultivate/activityCultivate/back", {
            businesskey: this.row.processVariables.businesskey,
            check: 2,
            comment: this.bottomform.idea,
            executionId: this.row.executionId,
            processDefinitionId: this.row.processDefinitionId,
            processInstanceId: this.row.processInstanceId,
            taskId: this.row.id,
            taskKey: this.row.taskDefinitionKey,
            name: this.row.processVariables.name,
            type: "1"
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "退回成功",
                type: "success"
              });
              this.$emit("tzAuditshow", false);
              this.$parent.takeList();
            } else {
              this.$message.error({
                message: "退回失败"
              });
            }
          })
          .catch(function(err) {
            console.log(err);
          });
      }
    }, // 提交
    exitList() {
      this.$emit("tzAuditshow", false);
      this.$parent.takeList();
    },
    getList() {
      this.$http
        .get(
          `api/cultivate/pyjhtz/infoByLcid?lcid=${this.row.processInstanceId}&type=1`
        )
        .then(res => {
          const myRes = res.data.data;
          this.form = myRes.xsGrpyjhbsqVo;
          this.xwkList = myRes.xwkList;
          this.xxkList = myRes.xxkList;
          this.bxhjList = myRes.bxhjList;
          this.jhwList = myRes.jhwList;
          this.tableData = this.xwkList;
          this.xwkgrade = myRes.xsGrpyjhbsqVo.xwkmath;
          this.totalClass = this.xwkgrade.split(",")[0];
          this.totalScore = this.xwkgrade.split(",")[1];
          this.totalTime = this.xwkgrade.split(",")[2];
          this.xxkgrade = myRes.xsGrpyjhbsqVo.xxkmath;
          this.bxhjgrade = myRes.xsGrpyjhbsqVo.bxhjmath;
          this.jhwgrade = myRes.xsGrpyjhbsqVo.jhwmath;
          this.xwkMin = myRes.xsGrpyjhbsqVo.xwkMin;
          this.xxkMin = myRes.xsGrpyjhbsqVo.xxkMin;
          this.bxhjMin = myRes.xsGrpyjhbsqVo.bxhjMin;
          this.minScore = this.xwkMin;
          this.list = res.data.data.list;
          this.ggyy = res.data.data.ggyy;
        })
        .catch(function(err) {
          console.log(err);
        });
    },
    handleClick() {
      if (this.activeName == "first") {
        this.tableData = this.xwkList;
        this.totalClass = this.xwkgrade.split(",")[0];
        this.totalScore = this.xwkgrade.split(",")[1];
        this.totalTime = this.xwkgrade.split(",")[2];
        this.minScore = this.xwkMin;
      } else if (this.activeName == "second") {
        this.tableData = this.xxkList;
        this.totalClass = this.xxkgrade.split(",")[0];
        this.totalScore = this.xxkgrade.split(",")[1];
        this.totalTime = this.xxkgrade.split(",")[2];
        this.minScore = this.xxkMin;
      } else if (this.activeName == "third") {
        this.tableData = this.bxhjList;
        this.totalClass = this.bxhjgrade.split(",")[0];
        this.totalScore = this.bxhjgrade.split(",")[1];
        // this.totalTime = this.bxhjgrade.split(",")[2];
        this.totalTime = "";
        this.minScore = this.bxhjMin;
      } else if (this.activeName == "fourth") {
        this.tableData = this.jhwList;
        this.totalClass = this.jhwgrade.split(",")[0];
        this.totalScore = this.jhwgrade.split(",")[1];
        this.totalTime = this.jhwgrade.split(",")[2];
      }
    }
  },
  mounted() {
    this.getList();
  }
};
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
.train {
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .personal-details,
  .family-information {
    width: 100%;
    margin-top: 15px;
    .el-row {
      // height: 50px;
      width: 100%;
      .el-col {
        // height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
    .title {
      font-size: 20px;
      font-weight: bold;
      text-align: center;
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
  .step {
    margin-top: 20px;
  }
  .submitButton {
    margin-top: 15px;
    margin-left: -20px;
  }
  .main-container {
    width: 100%;
    border: 1px solid #eee;
    margin-top: 10px;
    box-sizing: border-box;
    padding: 0 10px 10px 10px;
    .statistics {
      height: 40px;
      width: 98.9%;
      background: #f5f5f5;
      line-height: 40px;
      padding-right: 20px;
      span {
        font-size: 14px;
        color: #666;
        margin-left: 30px;
      }
      .minimum {
        float: right;
        font-size: 14px;
        color: #666;
      }
    }
  }
  .table {
    width: 100%;
    .addClass {
      margin-top: 15px;
    }
  }
  table {
    margin-top: 15px;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 400;
    margin-bottom: 20px;
    border-collapse: collapse;
    text-overflow: ellipsis;
  }
  table thead {
    height: 60px !important;
    border: 1px solid #e0e0e0;
  }
  tr {
    border: 1px solid #e0e0e0;
    height: 48px;
  }
  th,
  td {
    border: 1px solid #e0e0e0;
    height: 48px;
    line-height: 48px;
    padding-left: 5px;
    text-align: center;
    width: 180px;
  }
  .left_cont {
    text-align: left;
    padding-left: 10px;
    font-weight: bold;
  }
  .listcss {
    background: rgba(240, 242, 245, 1);
    width: 180px;
  }
}

.train /deep/ .myform .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.train /deep/ .myrow > .el-form-item__label {
  line-height: 120px;
}
.train /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.train /deep/ .el-form-item__label {
  text-align: center;
}
.train /deep/ .el-icon-d-arrow-left:before,
.train /deep/ .el-icon-close:before {
  color: #fff;
  background-color: #f56c6c;
  font-size: 16px;
  border-radius: 50%;
  padding: 4px;
}

.yes {
  color: #409eff;
}
.back {
  color: #f56c6c;
}
.audit {
  color: #febc5a;
}
.yes1 {
  background: #409eff;
}
.back1 {
  background: #f56c6c;
}
.audit1 {
  // background: #febc5a;
}
.time {
  margin-left: 15px;
  color: #909399;
  font-size: 13px;
}
.comment {
  margin-top: 8px;
  color: #909399;
  font-size: 13px;
}
.mytext {
  color: #333 !important;
}
</style>
