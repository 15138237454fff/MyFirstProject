<!-- 制定培养方案 -->
<template>
  <div class="makePlan">
    <template v-if="isshow == false">
      <div class="container" v-if="
          $store.state.addPlan == false &&
            $store.state.cheakdetails == false &&
            !cheakdxqshow
        ">
        <componment>
          <div slot="left">
            <el-input v-model="search" placeholder="请输入培养方案号" style="width: 200px" @keyup.enter.native="handleFind" clearable @clear="selectClear1" suffix-icon="el-icon-search"></el-input>
            <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
            <el-select v-model="college" filterable  style="width: 200px;" @change="selectChange" @clear="selectClear2">
              <el-option v-for="(item, index) in collegeList" :key="index" :label="item.dwmc" :value="item.dwh">
              </el-option>
            </el-select>
          </div>
          <div slot="right">
            <el-button type="primary" plain @click="gainYear" v-if="$btnAuthorityTest('makePlan:import')">获取历年培养方案</el-button>
            <el-button type="primary" @click="addNew" v-if="$btnAuthorityTest('makePlan:add')">添加</el-button>
            <el-button type="danger" @click="deleteHandle" v-if="$btnAuthorityTest('makePlan:delete')">删除</el-button>
            <el-button type="primary" @click="submitAudit" v-if="$btnAuthorityTest('makePlan:audit')">提交审核</el-button>
            <el-button v-if="$btnAuthorityTest('makePlan:export')">导出</el-button>
          </div>
        </componment>
        <el-table :data="tableData" border ref="multipleTable" style="width: 100%" @row-click="clickRow" @selection-change="mySelect" @select-all="allClick" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
          <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
          </el-table-column>
          <el-table-column prop="pyfah" label="培养方案号" width="150">
          </el-table-column>
          <el-table-column prop="dwh" label="学院"> </el-table-column>
          <el-table-column prop="zyh" label="专业"> </el-table-column>
          <el-table-column prop="jhnj" label="计划年级"> </el-table-column>
          <el-table-column prop="pyccm" label="培养层次"> </el-table-column>
          <el-table-column prop="zdzxf" label="最低总学分要求">
          </el-table-column>
          <el-table-column prop="status" label="审核状态">
            <template slot-scope="scope">
              <span :class="scope.row.status | status">{{
                scope.row.status
              }}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <span class="tablexq" @click="checkDetails(scope.row, 0)" v-if="$btnAuthorityTest('makePlan:view')">查看</span><span v-if="
                  $btnAuthorityTest('makePlan:view') &&
                    $btnAuthorityTest('makePlan:update')
                ">
                |
              </span>
              <template v-if="$btnAuthorityTest('makePlan:update')">
                <span v-if="scope.row.status == '已提交'" style="color:#CCCCCC">修改</span><span class="tablexg" @click="checkDetails(scope.row, 1)" v-else>修改</span>
              </template>
            </template>
          </el-table-column>
        </el-table>
        <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
        <el-dialog title="获取历年培养方案" :visible.sync="addDialog" :before-close="handleClose" width="380px" :close-on-click-modal="false">
          <p class="hr"></p>
          <el-form :model="form" label-width="110px" ref="form">
            <el-row>
              <el-form-item label="选择学年：" :required="true">
                <el-select v-model="form.year" filterable placeholder="请选择" style="width: 200px;">
                  <el-option v-for="(item, index) in yearList" :key="index" :label="item.label" :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-row>
          </el-form>
          <span slot="footer" class="dialog-footer">
            <el-button @click="addCancel">取 消</el-button>
            <el-button type="primary" @click="addSubmit">确 定</el-button>
          </span>
        </el-dialog>
        <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px" :close-on-click-modal="false">
          <p class="hr"></p>
          <span>确定删除已选记录</span>
          <span slot="footer" class="dialog-footer">
            <el-button @click="deleteDialog = false">取 消</el-button>
            <el-button type="primary" @click="closeDia">确 定</el-button>
          </span>
        </el-dialog>
        <div style="font-size:16px;margin-top:15px">
          请于
          <span style="color:#409EFF">{{
            $tagTime(timeout, "yyyy年MM月dd日")
          }}</span>
          前完成专业培养方案的制定
        </div>
      </div>
      <mydetails v-else-if="$store.state.addPlan == true"></mydetails>
      <cheakdetails v-else-if="$store.state.cheakdetails == true" :rowid="rowid" :rowzt="rowzt" :rowxgid="rowxgid" :btnxq="btnxq"></cheakdetails>
      <cheakdxq v-else-if="cheakdxqshow == true" :rowid="rowid" :rowzt="rowzt" :rowxgid="rowxgid" :btnxq="btnxq" @cheakdlist="cheakdlist"></cheakdxq>
    </template>
    <template v-if="isshow == true">
      <div class="fotter">
        <img src="./images/1574069541690_lALPDgQ9q4DlZY7Mls0BLA_300_150.png" alt="" />
        <p>培养方案时间暂未开启!</p>
      </div>
    </template>
  </div>
</template>

<script>
import mydetails from "./makePlan/planDetails";
import cheakdetails from "./makePlan/cheakdetails";
import cheakdxq from "./makePlan/cheakdxq";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "makePlan",
  data() {
    return {
      cheakdxqshow: false,
      deleteDialog: false,
      addDialog: false,
      search: "", // 搜索的参数
      college: "", // 选中的学院
      collegeList: [], // 全部的学院列表
      total: 0,
      tableHeight: null,
      yearList: [], // 学年列表
      form: {},
      tableData: [{}],
      deleteList: [],
      submitList: [],
      rowid: "",
      rowzt: "",
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      btnxq: 0,
      isshow: false,
      loading: false,
      timeout: ""
    };
  },
  filters: {
    status(val) {
      switch (val) {
        case "待提交":
          return "dtj";
        case "退回":
          return "thzt";
        case "已提交":
          return "dshzt";
        case "通过":
          return "tjzt";
        default:
          break;
      }
    }
  },
  methods: {
    cheakdlist(val) {
      this.cheakdxqshow = val;
    },
    // 提交审核
    submitAudit() {
      if (this.deleteList.length == 0) {
        this.$message.error({ message: "请选择数据！" });
        return false;
      }
      let foot = true;
      this.tableData.forEach(element => {
        if (element.status == "已提交") {
          const i = this.deleteList.find(item => item === element.id);
          if (foot) {
            if (i) {
              this.$message.error({
                message: "已提交不能提交审核"
              });
              foot = false;
            }
          }
          return false;
        }
      });
      if (foot) {
        this.$http
          .put("api/cultivate/pyfa/shzt/" + this.deleteList)
          .then(res => {
            console.log(res.data);
            if (res.data.code == 200) {
              this.$message({
                message: "提交审核成功",
                type: "success"
              });
              this.takeList();
            } else {
              this.$message.error({
                message: "提交审核失败"
              });
            }
          });
      }
    },
    closeDia() {
      this.$http
        .delete("api/cultivate/pyfa/" + this.deleteList.join(","))
        .then(res => {
          this.takeList();
          if (res.data.code == 200) {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.deleteDialog = false;
          } else {
            this.$message.error({
              message: res.data.message
            });
          }
        });
    },
    // 删除操作
    deleteHandle() {
      if (this.deleteList.length == 0) {
        this.$message.error({ message: "请选择数据！" });
        return false;
      }
      let foot = true;
      this.tableData.forEach(element => {
        if (element.status == "已提交") {
          const i = this.deleteList.find(item => item === element.id);
          if (foot) {
            if (i) {
              this.$message.error({
                message: "已提交不能删除"
              });
              foot = false;
            }
          }
          return false;
        }
      });
      if (foot) {
        this.deleteDialog = true;
      }
    },
    addSubmit() {
      if (this.form.year != undefined) {
        this.$http.put("api/cultivate/pyfa/" + this.form.year).then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "获取成功"
            });
            this.addDialog = false;
            this.form.year = "";
            this.takeList();
          } else {
            this.$message.error("获取失败");
          }
        });
      } else {
        this.$message.error("请选择学年");
      }
    },
    addCancel() {
      this.addDialog = false;
    },
    // 获取历年培养方案
    gainYear() {
      this.$http.get("api/cultivate/pyfa/checkTotal").then(res => {
        if (res.data.data) {
          this.addDialog = true;
        } else {
          this.addDialog = false;
          this.$message.error(
            "已有当前年份的专业培养方案，不能获取历年培养方案！"
          );
        }
      });
    },
    // 查询所有列表
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .get(
          `api/cultivate/pyfa/selectall/${params.pageSize}/${params.pageNum}?dwh=${this.college}&query=${this.search}`
        )
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 200) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
            res.data.data.list.map((item, index) => {
              this.tableData[index].status =
                item.shzt == "0"
                  ? "待提交"
                  : item.shzt == "1"
                  ? "审核通过"
                  : item.shzt == "2"
                  ? "已提交"
                  : item.shzt == "3"
                  ? "退回"
                  : "";
            });
          } else {
            this.tableData = [];
            this.total = 0;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    // 查询下拉框改变事件
    selectChange(val) {
      this.college = val;
      this.takeList();
    },
    // 查询下拉框清除事件
    selectClear1() {
      this.search = "";
      this.takeList();
    },
    selectClear2() {
      this.college = "全部学院";
      this.takeList();
    },
    // 获取下拉所需要数据
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectDwList").then(res => {
        if (res.data.data.length > 1) {
          this.collegeList = res.data.data;
          this.collegeList.unshift({ dwh: "", dwmc: `全部学院` });
        } else {
          this.collegeList = res.data.data;
          this.college = res.data.data[0].dwh;
        }
      });
    },
    getYears() {
      let obj = {};
      this.$http.get("api/cultivate/pyfa/getYears").then(res => {
        if (res.data.data.length > 0) {
          res.data.data.map(v => {
            obj = {
              value: v,
              label: v
            };
            this.yearList.push(obj);
          });
        }
      });
    },
    addNew() {
      this.$store.state.addPlan = true;
    },
    // 搜索的方法
    handleFind() {
      this.takeList();
    },
    // 列表选择
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    // 列表选择
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
      this.submitList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.submitList.push(item.pyfah);
      });
    },
    // 列表全选
    allClick(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
      this.submitList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.submitList.push(item.pyfah);
      });
    },
    // 查看详情
    checkDetails(row, val) {
      if (val == 0) {
        this.cheakdxqshow = true;
      }
      if (val == 1) {
        this.$store.state.cheakdetails = true;
      }
      this.btnxq = val;
      this.rowid = row.pyfah;
      this.rowzt = row.shzt;
      this.rowxgid = row.id;
    },
    handleClose(done) {
      done();
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.$http
      .get(`api/cultivate/pycssz/checkOpenMain?key=pyfazd`)
      .then(res => {
        if (res.data.code == 200) {
          if (res.data.data.isOpen == 1) {
            this.isshow = false;
            this.getNumber();
            this.getYears();
            this.takeList();
            this.timeout = res.data.data.endTime;
          } else {
            this.isshow = true;
          }
        } else {
          this.$message.error(res.data.message);
        }
      });
  },
  components: {
    mydetails,
    cheakdetails,
    pagination,
    componment,
    cheakdxq
  }
};
</script>

<style scoped lang="scss">
.makePlan {
  width: 100%;
  padding-top: 7px;
  .dtj {
    color: #1e8fff;
  }
  .thzt {
    color: #f56c6c;
  }
  .dshzt {
    color: #faac1b;
  }
  .tjzt {
    color: #53c320;
  }
  .fotter {
    text-align: center;
    margin-top: 280px;
  }
}
.makePlan /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.makePlan /deep/ .dialog-footer button {
  margin: 0 20px;
}
.makePlan /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.makePlan /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
</style>
