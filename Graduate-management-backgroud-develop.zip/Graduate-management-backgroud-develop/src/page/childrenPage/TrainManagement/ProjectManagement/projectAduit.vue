<!-- 培养方案审核 -->
<template>
  <div class="projectAduit">
    <template v-if="$store.state.auditDetails == false">
      <el-tabs v-model="activeName" @tab-click="tabChangeClick" class="top-nav">
        <el-tab-pane label="待审核" name="first">
          <componment>
            <div slot="left">
              <el-input
                v-model="search"
                placeholder="请输入培养方案号"
                style="width: 200px"
                @keyup.enter.native="handleFind"
                clearable
                @clear="inputClear1"
                suffix-icon="el-icon-search"
              ></el-input>
              <el-button @click="handleFind">查询</el-button>
              <el-select
                v-model="college"
                filterable
                
                placeholder="全部学院"
                @change="selectChange"
                @clear="selectClear1"
              >
                <el-option
                  v-for="(item, index) in collegeList"
                  :key="index"
                  :label="item.dwmc"
                  :value="item.dwh"
                >
                </el-option>
              </el-select>
            </div>
            <div slot="right">
              <el-button
                type="primary"
                @click="oneKeyPass"
                v-if="$btnAuthorityTest('projectAduit:allPass')"
                >一键通过</el-button
              >
              <el-button
                type="danger"
                @click="oneKeyBack"
                v-if="$btnAuthorityTest('projectAduit:allBack')"
                >一键退回</el-button
              >
            </div>
          </componment>
          <el-table
            :data="tableData1"
            border
            ref="multipleTable"
            style="width: 100%"
            @row-click="clickRow"
            @selection-change="mySelect"
            @select-all="allClick"
            :header-cell-style="$storage.tableHeaderColor"
            :height="tableHeight"
            v-loading="loading2"
            element-loading-text="加载中"
          >
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="pyfah" label="培养方案号" width="150">
            </el-table-column>
            <el-table-column prop="dwmc" label="学院"> </el-table-column>
            <el-table-column prop="zymc" label="专业"> </el-table-column>
            <el-table-column prop="jhnj" label="计划年级"> </el-table-column>
            <el-table-column prop="pyccm" label="培养层次"> </el-table-column>
            <el-table-column prop="zdzxf" label="最低总学分要求">
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button
                  type="text"
                  @click="checkDetails(scope.row)"
                  v-if="$btnAuthorityTest('projectAduit:view')"
                  >查看详情</el-button
                >
              </template>
            </el-table-column>
          </el-table>
          <pagination
            :total="total"
            :page.sync="listQuery.queryPage.pageNum"
            :limit.sync="listQuery.queryPage.pageSize"
            class="pagination-content"
            @pagination="takeList"
          ></pagination>
        </el-tab-pane>
        <el-tab-pane label="已审核" name="second">
          <componment>
            <div slot="left">
              <el-input
                v-model="search2"
                placeholder="请输入培养方案号"
                style="width: 200px"
                @keyup.enter.native="handleFind2"
                clearable
                @clear="inputClear2"
                suffix-icon="el-icon-search"
              ></el-input>
              <el-button @click="handleFind2">查询</el-button>
              <el-select
                v-model="college2"
                filterable
                
                placeholder="全部学院"
                @change="selectChange2"
                @clear="selectClear2"
              >
                <el-option
                  v-for="(item, index) in collegeList"
                  :key="index"
                  :label="item.dwmc"
                  :value="item.dwh"
                >
                </el-option>
              </el-select>
            </div>
          </componment>
          <el-table
            :data="tableData2"
            border
            ref="multipleTable"
            style="width: 100%"
            :header-cell-style="$storage.tableHeaderColor"
            :height="tableHeight"
            v-loading="loading2"
            element-loading-text="加载中"
          >
            <el-table-column type="index" label="序号" width="100px">
            </el-table-column>
            <el-table-column prop="pyfah" label="培养方案号"> </el-table-column>
            <el-table-column prop="dwmc" label="学院"> </el-table-column>
            <el-table-column prop="zymc" label="专业"> </el-table-column>
            <el-table-column prop="jhnj" label="计划年级"> </el-table-column>
            <el-table-column prop="pyccm" label="培养层次"> </el-table-column>
            <el-table-column prop="zdzxf" label="最低总学分要求">
            </el-table-column>
            <el-table-column prop="status" label="审核状态">
              <template slot-scope="scope">
                <el-button
                  type="text"
                  @click="checkDetails(scope.row)"
                  v-if="$btnAuthorityTest('projectAduit:audit')"
                  ><span :class="scope.row.status | status">{{
                    scope.row.status
                  }}</span>
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <pagination
            :total="total2"
            :page.sync="listQuery.queryPage.pageNum"
            :limit.sync="listQuery.queryPage.pageSize"
            class="pagination-content"
            @pagination="takeList"
          ></pagination>
        </el-tab-pane>
      </el-tabs>
    </template>
    <auditDetails
      v-else-if="$store.state.auditDetails == true"
      :rowid="rowid"
    ></auditDetails>
  </div>
</template>

<script>
import auditDetails from "./details/auditDetails";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "projectAduit",
  data() {
    return {
      tableData1: [],
      tableData2: [],
      search: "",
      search2: "",
      activeName: "first",
      college: "", // 所选学院
      college2: "",
      collegeList: [], // 所有学院列表
      total: 0,
      total2: 0,
      tableHeight: null,
      deleteList: [],
      rowid: "",
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  filters: {
    status(val) {
      switch (val) {
        case "审核通过":
          return "green";
        case "退回":
          return "red";
        default:
          break;
      }
    }
  },
  methods: {
    // 一键通过
    oneKeyPass() {
      if (this.deleteList.length == 0) {
        this.$message.error("请至少选择一条数据！");
        return false;
      }
      this.$http
        .put("api/cultivate/pyfash/tg/" + this.deleteList + "/1")
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "一键通过成功",
              type: "success"
            });
            this.takeList();
          } else {
            this.$message.error({
              message: "一键通过失败"
            });
          }
        });
    },
    // 一键退回
    oneKeyBack() {
      if (this.deleteList.length == 0) {
        this.$message.error("请至少选择一条数据！");
        return false;
      }
      this.$http
        .put("api/cultivate/pyfash/tg/" + this.deleteList + "/3")
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "一键退回成功",
              type: "success"
            });
            this.takeList();
          } else {
            this.$message.error({
              message: "一键退回失败"
            });
          }
        });
    },
    // 获取列表
    takeList() {
      this.loading2 = true;
      var params = {};
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      if (this.activeName == "first") {
        this.$http
          .get(
            `api/cultivate/pyfash/select/${params.pageSize}/${params.pageNum}`,
            {
              params: {
                dwh: this.college,
                query: this.search,
                type: 0
              }
            }
          )
          .then(res => {
            this.loading2 = false;
            if (res.data.code == 200) {
              this.tableData1 = res.data.data.list;
              this.total = res.data.data.total;
            } else {
              this.tableData1 = [];
              this.total = 0;
            }
          })
          .catch(err => {
            console.log(err.message);
            this.loading2 = false;
          });
      } else if (this.activeName == "second") {
        this.$http
          .get(
            `api/cultivate/pyfash/select/${params.pageSize}/${params.pageNum}`,
            {
              params: {
                dwh: this.college2,
                query: this.search2,
                type: 1
              }
            }
          )
          .then(res => {
            this.loading2 = false;
            if (res.data.code == 200) {
              this.tableData2 = res.data.data.list;
              this.total2 = res.data.data.total;
              res.data.data.list.map((item, index) => {
                this.tableData2[index].status =
                  item.shzt == "0"
                    ? "待提交"
                    : item.shzt == "1"
                    ? "审核通过"
                    : item.shzt == "2"
                    ? "已提交"
                    : item.shzt == "3"
                    ? "退回"
                    : "";
              });
            } else {
              this.tableData2 = [];
              this.total2 = 0;
            }
          })
          .catch(err => {
            console.log(err.message);
            this.loading2 = false;
          });
      }
    },
    // 获取下拉所需要数据
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectJsQxJh").then(res => {
        const myRes = res.data.data;
        if (myRes.dwList.length > 1) {
          this.collegeList = myRes.dwList;
          this.collegeList.unshift({ dwh: "", dwmc: `全部学院` });
        } else {
          this.collegeList = myRes.dwList;
        }
      });
    },
    // 切换审核
    tabChangeClick(tab, event) {
      this.takeList();
    },
    handleFind() {
      this.takeList();
    },
    handleFind2() {
      this.takeList();
    },
    // 查询输入框清除事件
    inputClear1() {
      this.search = "";
      this.takeList();
    },
    inputClear2() {
      this.search2 = "";
      this.takeList();
    },
    // 查询下拉框清除事件
    selectClear1() {
      this.college = "";
      this.takeList();
    },
    selectClear2() {
      this.college2 = "";
      this.takeList();
    },
    // 查询下拉框改变事件
    selectChange(val) {
      this.college = val;
      this.takeList();
    },
    selectChange2(val) {
      this.college2 = val;
      this.takeList();
    },
    // 列表选择
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    // 列表选择
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
    },
    // 列表全选
    allClick(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
    },
    // 查看详情
    checkDetails(row) {
      this.$store.state.auditDetails = true;
      this.rowid = row.pyfah;
    }
  },
  components: {
    auditDetails,
    pagination,
    componment
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 266;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 266;
      })();
    };
    this.takeList();
    this.getNumber();
  }
};
</script>

<style scoped lang="scss">
.projectAduit {
  width: 100%;
  .green {
    color: #53c320;
  }
  .red {
    color: red;
  }
  .top-nav {
    /deep/ .el-tabs__nav-wrap {
      background: #fff;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 130px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 10px;
    }
    /deep/ .el-tabs__active-bar {
      width: 80px;
    }
  }
  .container {
    .table {
      width: 100%;
    }
  }
}
</style>
