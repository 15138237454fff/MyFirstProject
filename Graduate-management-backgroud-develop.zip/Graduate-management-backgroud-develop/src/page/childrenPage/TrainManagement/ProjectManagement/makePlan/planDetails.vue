<template>
  <div class="planDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList"
        >返回列表</el-button
      >
      <el-button type="primary" class="fr" @click="saveData">保存</el-button>
    </div>
    <table align="center" border="1" cellspacing="0" cellpadding="0">
      <tr align="center">
        <td class="listcss">培养方案号</td>
        <td class="listcss"></td>
        <td class="listcss required">学院</td>
        <td>
          <el-select v-model="form.dwh" filterable  style="width:100%">
            <el-option
              v-for="(item, index) in collegeList"
              :key="index"
              :label="item.dwmc"
              :value="item.dwh"
            >
            </el-option>
          </el-select>
        </td>
        <td class="listcss required">专业</td>
        <td>
          <el-select v-model="form.zyh" filterable  style="width:100%">
            <el-option
              v-for="(item, index) in majorList"
              :key="index"
              :label="item.zymc"
              :value="item.zyh"
            >
            </el-option>
          </el-select>
        </td>
      </tr>
      <tr align="center">
        <td class="listcss required">计划年级</td>
        <td>
          <el-select
            v-model="form.jhnj"
            filterable
            
            style="width:100%"
          >
            <el-option
              v-for="item in $stores.state.planclass"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </td>
        <td class="listcss required">培养层次</td>
        <td>
          <el-select
            v-model="form.pyccm"
            filterable
            
            style="width:100%"
          >
            <el-option
              v-for="item in levelList"
              :key="item.code"
              :label="item.name"
              :value="item.code"
            >
            </el-option>
          </el-select>
        </td>
        <td class="listcss">最低总学分要求</td>
        <td>
          <span>{{ min }}</span>
        </td>
      </tr>
      <tr align="center">
        <td class="listcss" style="height:80px;">培养目标</td>
        <td colspan="5">
          <el-input
            v-model="form.pymb"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 10 }"
          >
          </el-input>
        </td>
      </tr>
      <tr align="center">
        <td class="listcss" style="height:80px;">研究方向</td>
        <td colspan="5">
          <el-input
            v-model="form.yjfx"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 8 }"
          >
          </el-input>
        </td>
      </tr>
    </table>

    <!-- table切换 -->
    <!-- ---------------------------------------------------------- -->
    <el-tabs v-model="activeName" class="tablehack">
      <el-tab-pane label="学位课" name="first">
        <!-- 学位课 -->
        <div class="hadle-container1">
          <div class="statistics">
            <span>总门数: {{ degreeTotalClass }}</span>
            <span>总学分：{{ degreeTotalScore }}</span>
            <span>总学时：{{ degreeTotalTime }}</span>
            <div class="minimum required">
              最低学分要求：
              <el-input
                v-model.number="degreemin"
                style="width: 150px; position: relative;"
                size="small"
                type="number"
              >
                <template slot="prepend">≥</template>
              </el-input>
            </div>
          </div>
          <div class="table">
            <el-table
              :data="tableData"
              @selection-change="mySelect"
              border
              ref="multipleTable"
              style="width: 100%"
              :span-method="arraySpanMethod"
              :header-cell-style="$storage.tableHeaderColor"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column label="课程号 课程名称">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.kcmc"
                    filterable
                    placeholder="请选择"
                    
                    @focus="getKcList"
                    @change="
                      selectXWtable(
                        scope.row.kcmc,
                        scope.row,
                        scope.$index,
                        '必修'
                      )
                    "
                  >
                    <el-option
                      v-for="item in degreeList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kkdwmc" label="开课学院" width="200px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.kkdwmc }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xf" label="学分" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.xf }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xs" label="学时" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.xs }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kkxq" label="开课学年学期">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.kkxq"
                    filterable
                    placeholder="请选择"
                    style="margin-left: 10px;"
                  >
                    <el-option
                      v-for="item in workList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kcsxh" label="课程属性" width="100px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.kcsxh }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kcxz" label="课程性质" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.kcxz | kcsxh(kcxzList) }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="ksxsmc" label="考试形式" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.ksxsmc }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="tgcj" label="通过成绩" width="160px">
                <template slot-scope="scope">
                  <el-input-number
                    v-model="scope.row.tgcj"
                    controls-position="right"
                    :min="0"
                    :max="100"
                    maxlength="5"
                    style="width:140px"
                    v-if="scope.row.ksxsmc == '考试'"
                  ></el-input-number>
                </template>
              </el-table-column>
              <el-table-column prop="group" label="课程组" width="120px">
                <template slot-scope="scope">
                  {{ scope.row.group }}
                  <el-button
                    v-if="scope.row.shkczh"
                    @click="jiesanclass(scope.row)"
                    >解绑</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
            <div style="margin-top:15px">
              <el-button @click="addtableData" class="addClass" type="primary"
                >添加课程+</el-button
              >
              <el-button @click="mergetableData" class="addClass"
                >课程组维护</el-button
              >
              <el-button @click="deletetableData" class="addClass" type="danger"
                >删除课程</el-button
              >
            </div>
          </div>
        </div>
        <!-- 学位课 -->
      </el-tab-pane>
      <el-tab-pane label="选修课" name="second">
        <div class="hadle-container2" v-if="activeName == 'second'">
          <div class="statistics">
            <span>总门数: {{ electiveTotalClass }}</span>
            <span>总学分：{{ electiveTotalScore }}</span>
            <span>总学时：{{ electiveTotalTime }}</span>
            <div class="minimum">
              最低学分要求：
              <el-input
                v-model.number="electivemin"
                style="width: 150px; position: relative;"
                size="small"
                type="number"
              >
                <template slot="prepend">≥</template>
              </el-input>
            </div>
          </div>
          <div class="table">
            <el-table
              :data="tableData2"
              @selection-change="mySelect2"
              border
              ref="multipleTable1"
              style="width: 100%"
              :header-cell-style="$storage.tableHeaderColor"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column label="课程号 课程名称">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.kcmc"
                    filterable
                    placeholder="请选择"
                    
                    @focus="getKcList"
                    @change="
                      selectXWtable(
                        scope.row.kcmc,
                        scope.row,
                        scope.$index,
                        '选修'
                      )
                    "
                  >
                    <el-option
                      v-for="item in degreeList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kkdwmc" label="开课学院">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.kkdwmc }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xf" label="学分" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.xf }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xs" label="学时" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.xs }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kkxq" label="开课学年学期">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.kkxq"
                    filterable
                    placeholder="请选择"
                    style="margin-left: 10px;"
                  >
                    <el-option
                      v-for="item in workList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kcsxh" label="课程属性">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.kcsxh }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kcxz" label="课程性质" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.kcxz | kcsxh(kcxzList) }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="ksxsmc" label="考试形式" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{ scope.row.ksxsmc }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="tgcj" label="通过成绩" width="160px">
                <template slot-scope="scope">
                  <el-input-number
                    v-model="scope.row.tgcj"
                    controls-position="right"
                    :min="0"
                    :max="100"
                    maxlength="5"
                    style="width:140px"
                    v-if="scope.row.ksxsmc == '考试'"
                  ></el-input-number>
                </template>
              </el-table-column>
            </el-table>
            <div style="margin-top:15px">
              <el-button @click="addXxk" class="addClass" type="primary"
                >添加课程+</el-button
              >
              <el-button @click="deleteXxk" class="addClass" type="danger"
                >删除课程</el-button
              >
            </div>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="必修环节" name="third">
        <div class="hadle-container2" v-if="activeName == 'third'">
          <div class="statistics">
            <span>总门数: {{ bxTotalClass }}</span>
            <span>总学分：{{ bxTotalScore }}</span>
            <div class="minimum">
              最低学分要求：
              <el-input
                v-model.number="tachemin"
                style="width: 150px; position: relative;"
                size="small"
                type="number"
              >
                <template slot="prepend">≥</template>
              </el-input>
            </div>
          </div>
          <div class="table">
            <el-table
              :data="tableData3"
              @selection-change="mySelect3"
              border
              ref="multipleTable1"
              style="width: 100%"
              :header-cell-style="$storage.tableHeaderColor"
            >
              <el-table-column type="selection" width="55"> </el-table-column>
              <el-table-column label="名称">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.mc"></el-input>
                </template>
              </el-table-column>
              <el-table-column prop="xf" label="学分">
                <template slot-scope="scope">
                  <el-input-number
                    v-model="scope.row.xf"
                    controls-position="right"
                    :min="1"
                    :max="50"
                    style="width:140px"
                  ></el-input-number>
                </template>
              </el-table-column>

              <el-table-column prop="kcsxh" label="课程属性">
                <template slot-scope="scope">
                  <div>
                    实践
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="fzr" label="负责人">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.fzr"
                    filterable
                    remote
                    placeholder="请输入负责人"
                    :remote-method="queryTutorByName"
                    :loading="tutorLoading"
                    style="width:200px"
                    @focus="selectjs(scope.$index)"
                  >
                    <el-option
                      v-for="(item, index) in scope.row.semesterList1"
                      :key="index"
                      :value="item.gh"
                      :label="item.xm + item.gh"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="xnxq" label="学年学期">
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.xnxq"
                    filterable
                    placeholder="请选择"
                    style="margin-left: 10px;"
                  >
                    <el-option
                      v-for="item in workList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="bz" label="备注">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.bz"></el-input>
                </template>
              </el-table-column>
            </el-table>
            <div style="margin-top:15px">
              <el-button @click="addbxk" class="addClass" type="primary"
                >添加课程+</el-button
              >
              <el-button @click="deletebxk" class="addClass" type="danger"
                >删除课程</el-button
              >
            </div>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
    <el-dialog
      title="课程组维护"
      :visible.sync="addDialog"
      width="380px"
      :close-on-click-modal="false"
    >
      <el-form :model="leastForm" label-width="130px" ref="leastForm">
        <el-row>
          <el-form-item label="最少选择门数：">
            <el-select
              v-model="leastForm.leastClass"
              filterable
              placeholder="请选择"
              style="width: 200px;"
            >
              <el-option
                v-for="item in leastClassList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialog = false">取 消</el-button>
        <el-button type="primary" @click="addSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "planDetails",
  data() {
    return {
      // 表单参数
      form: {
        zyh: ""
      },
      // 弹框参数
      leastForm: {
        leastClass: ""
      },
      // 学位课列表
      tableData: [],
      addDialog: false,
      activeName: "first",
      // 弹框最少选择门数：
      leastClassList: [],
      collegeList: [], // 学院列表
      majorList: [], // 专业列表
      planGradeList: [], // 计划年级列表
      levelList: [], // 培养层次列表,
      // 学位课最低学分要求：
      degreemin: 0,
      degreeList: [], // 学位课列表
      degreeDetails: [],
      kchHistorys: [],
      kcxzList: [],
      workList: [],
      // 课程组初始的数字
      courseKczNum: 1,
      multipleSelection: [],
      hB: false,
      conArr: [],
      electivemin: 0,
      tachemin: 0,
      tableData2: [], // 选修课列表
      multipleSelection1: [],
      tableData3: [],
      multipleSelection2: [],
      tutorLoading: false,
      tableindex: 0
    };
  },
  filters: {
    kcsxh(val, all) {
      if (val && all.length) {
        return all.find(el => el.code == val).name;
      }
    }
  },
  watch: {
    "form.dwh": {
      handler(val) {
        this.majorList = [];
        this.form.zyh = "";
        this.$http
          .get("/api/cultivate/pyfa/selectZyByDwh", {
            params: {
              dwh: val
            }
          })
          .then(res => {
            const data = res.data.data;
            this.majorList = data;
            this.form.zyh = this.majorList[0].zyh;
          });
      }
    }
  },
  methods: {
    queryTutorByName(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        res.data.data.length > 0
          ? (this.tableData3[this.tableindex].semesterList1 = res.data.data)
          : this.tableData[this.tableindex].semesterList1;
      });
    },
    selectjs(val) {
      this.tableindex = val;
    },
    // 获取下拉所需要数据
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectJsQxJh").then(res => {
        this.kcxzList = res.data.data.kcxzs; // 课程性质
        // 学院
        this.collegeList = res.data.data.dwList;
        // 培养层次
        this.levelList = res.data.data.pyccs;
      });
    },
    // 课程下拉框向后台传值
    getKcList() {
      this.$http
        .post("/api/cultivate/pyfa/selectKcListByTabChange", this.kchList)
        .then(res => {
          this.degreeList = [];
          this.degreeDetails = res.data.data;
          res.data.data.map((item, index) => {
            const obj = {
              value: item.kch + " " + item.kcmc,
              label: item.kch + " " + item.kcmc
            };
            this.degreeList.push(obj);
          });
        });
      this.$http.get("/api/cultivate/pycssz/planTermList").then(res => {
        this.workList = res.data.data;
      });
    },
    selectXWtable(value, row, index, val) {
      this.degreeDetails.map((item, index) => {
        if (value == item.kch + " " + item.kcmc) {
          row.xf = item.xf;
          row.xs = item.zxs;
          row.ksxsmc = item.ksxsmc;
          row.kcxz = item.kcxzh;
          row.kcsxh = val;
          row.kch = item.kch;
          row.ksxs = item.ksxsmc == "考试" ? 1 : 2;
          row.kkdwmc = item.kkdwmc;
        }
      });
    },
    // 返回
    exitList() {
      this.$store.state.addPlan = false;
    },
    // 最后的提交
    saveData() {
      // var tableDatabT = ["kcmc", "kkxq", "tgcj"];
      let tableData = JSON.parse(JSON.stringify(this.tableData));
      let tableData2 = JSON.parse(JSON.stringify(this.tableData2));
      let tableData3 = JSON.parse(JSON.stringify(this.tableData3));
      let { dwh, zyh, jhnj, pyccm } = this.form;
      if (!dwh) {
        this.$message.error("请选择学院");
        return;
      }
      if (!zyh) {
        this.$message.error("请选择专业");
        return;
      }
      if (!jhnj) {
        this.$message.error("请选择计划年级");
        return;
      }
      if (!pyccm) {
        this.$message.error("请选择培养层次");
        return;
      }
      if (!this.degreemin) {
        this.$message.error("请填写学位课最低学分要求");
        return;
      }
      if (this.degreeTotalScore < this.degreemin) {
        this.$message.error("所选学位课总学分不能低于学位课最低学分要求");
        return;
      }
      if (!this.electivemin) {
        this.$message.error("请填写选修课最低学分要求");
        return;
      }
      if (this.electiveTotalScore < this.electivemin) {
        this.$message.error("所选选修课总学分不能低于选修课最低学分要求");
        return;
      }
      if (!this.tachemin) {
        this.$message.error("请填写必修环节课最低学分要求");
        return;
      }
      if (this.bxTotalScore < this.tachemin) {
        this.$message.error("所选必修环节总学分不能低于必修环节最低学分要求");
        return;
      }
      if (this.tableData.some(el => el.kch === "")) {
        this.$message.error("请选择学位课");
        return;
      }
      if (this.tableData.some(el => el.kkxq === "")) {
        this.$message.error("请选择学位课开课学年学期");
        return;
      }
      if (this.tableData2.some(el => el.kch === "")) {
        this.$message.error("请选择选修课");
        return;
      }
      if (this.tableData2.some(el => el.kkxq === "")) {
        this.$message.error("请选择选修课开课学年学期");
        return;
      }
      tableData.map(v => {
        delete v.group;
        delete v.rowspan;
        delete v.shkczh;
      });
      let obj = {
        pyFaBxKcs: tableData3,
        pyFaWwKcs: tableData,
        pyFaXxKcs: tableData2,
        pyPyfasjb: {
          dwh: this.form.dwh,
          zyh: this.form.zyh,
          jhnj: this.form.jhnj,
          pyccm: this.form.pyccm,
          zdzxf: this.min,
          pymb: this.form.pymb,
          yjfx: this.form.yjfx,
          xwknr: `${this.degreeTotalClass},${this.degreeTotalScore},${this.degreeTotalTime}`,
          xwkzdzxf: this.degreemin,
          xxknr: `${this.electiveTotalClass},${this.electiveTotalScore},${this.electiveTotalTime}`,
          xxkzdzxf: this.electivemin,
          bxhjnr: `${this.bxTotalClass},${this.bxTotalScore}`,
          bxhjzdzxf: this.tachemin
        }
      };
      this.$http.post("/api/cultivate/pyfa/saveinsert", obj).then(res => {
        if (res.data.code == 200) {
          this.$store.state.addPlan = false;
          this.$parent.takeList();
          return this.$message.success(res.data.message);
        } else {
          return this.$message.error(res.data.message);
        }
      });
    },
    addSubmit() {
      let arr = [];
      // 获取勾选的课程id,存入arr
      this.multipleSelection.map((v, index) => {
        arr.push(v.id);
      });
      // 遍历列表,组成课程组
      this.tableData.forEach((Element, index) => {
        if (arr.includes(Element.id)) {
          Element.kcz = this.courseKczNum;
        }
      });
      // 根据课程组标识排序，课程组放到一起
      this.tableData.sort((a, b) => {
        return a.kcz - b.kcz;
      });
      arr = [];
      this.tableData.forEach(el => {
        if (el.kcz === this.courseKczNum) arr.push(el.id);
      });
      this.tableData.forEach((el, index) => {
        // 如果是该课程组中的成员
        if (arr.includes(el.id)) {
          el.shkczh = true;
          el.zsxzsl = this.leastForm.leastClass;
          if (arr[0] !== el.id) {
            el.rowspan = 0;
          } else {
            el.group = `最少${this.leastForm.leastClass}门`;
            el.rowspan = arr.length;
          }
        }
      });
      // 课程组标识数字更新
      this.courseKczNum++;
      this.addDialog = false;
      this.$refs.multipleTable.clearSelection();
    },
    jiesanclass(row) {
      var spanArr,
        conArr = [];
      let tableData = JSON.parse(JSON.stringify(this.tableData));
      conArr = tableData.filter(el => el.kcz === row.kcz);
      // 保存过滤出相同解绑的数据
      spanArr = tableData.filter(el => el.kcz === row.kcz);
      spanArr.forEach(el => {
        this.tableData.splice(
          this.tableData.findIndex(item => item.id === el.id),
          1
        );
      });
      conArr.map(item => {
        var obj = {
          kcmc: item.kcmc,
          xf: item.xf,
          xs: item.xs,
          kkxq: item.kkxq,
          kcsxh: item.kcsxh,
          kcxz: item.kcxz,
          ksxsmc: item.ksxsmc,
          tgcj: item.tgcj,
          kcz: "",
          id: "",
          group: "",
          rowspan: [],
          shkczh: false,
          zdxfyq: this.degreemin,
          ksxs: item.ksxs,
          kch: item.kch,
          kclx: item.kclx,
          zsxzsl: "",
          kkdwmc: item.kkdwmc
        };
        this.tableData.push(obj);
      });
      this.tableData.map((v, index) => {
        v.id = index + 1;
      });
    },
    // 学位课添加课程
    addtableData() {
      this.tableData.push({
        kkdwmc: "",
        zdxfyq: this.degreemin, // 最低学分要求
        kcmc: "", // 课程名称
        xf: "", // 学分
        xs: "", // 学时
        kkxq: "", // 开课学期
        kcsxh: "", // 课程属性
        kcxz: "", // 课程性质
        ksxs: "", // 考试形式 DmJxKsxsdmb 1考试2考查
        ksxsmc: "", // 考试形式名称
        tgcj: "", // 通过成绩
        kcz: "", // 课程组
        id: this.tableData.length + 1, // id
        group: "",
        rowspan: [],
        shkczh: false,
        kch: "", // 课程号,
        kclx: 0, // 课程类型
        zsxzsl: "" // 最少选择数量
      });
      this.tableData.map((v, index) => {
        v.id = index + 1;
      });
    },
    // 选修课添加
    addXxk() {
      this.tableData2.push({
        kcmc: "",
        xf: "",
        xs: "",
        kkxq: "",
        kcsxh: "",
        kcxz: "",
        ksxsmc: "",
        tgcj: "",
        kcz: "",
        kch: "",
        kclx: 1,
        ksxs: "",
        zdxfyq: this.electivemin,
        zsxzsl: "",
        kkdwmc: "",
        id: this.tableData2.length + 1 // id
      });
      this.tableData2.map((v, index) => {
        v.id = index + 1;
      });
    },
    // 选修课删除
    deleteXxk() {
      if (this.multipleSelection1.length == 0) {
        return this.$message.error("请勾选数据进行删除！");
      }
      this.multipleSelection1.forEach(element => {
        this.tableData2.splice(
          this.tableData.findIndex(item => item === element),
          1
        );
      });
    },
    // 学位课合并行或者列
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 10 || columnIndex === 0) {
        return {
          rowspan: row.rowspan,
          colspan: 1
        };
      }
    },
    // 学位课课程组维护
    mergetableData() {
      this.leastForm.leastClass = "";
      this.leastClassList = [];
      let index = this.multipleSelection.find(el => el.shkczh == true);
      if (index) {
        this.$message.error("在课程组范围内的不能进行课程组维护！");
        return false;
      }
      this.leastClassList = [];
      if (this.multipleSelection.length < 2) {
        return this.$message.error("请至少选择两门课");
      }
      this.addDialog = true;
      this.multipleSelection.map((v, index) => {
        const obj = {
          value: index,
          label: index
        };
        if (index == "0") {
          this.leastClassList.splice(
            this.leastClassList.findIndex(item => item === obj),
            1
          );
        } else {
          this.leastClassList.push(obj);
        }
      });
    },
    // 学位课删除课程
    deletetableData() {
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据进行删除！");
      }
      let index = this.multipleSelection.find(el => el.shkczh == true);
      if (index) {
        this.$message.error("请解绑后再删除！");
        return false;
      }
      this.multipleSelection.forEach(element => {
        this.tableData.splice(
          this.tableData.findIndex(item => item === element),
          1
        );
      });
    },
    // 学位课复选框勾选方法
    mySelect(val) {
      this.multipleSelection = val;
    },
    // 选修课复选框勾选方法
    mySelect2(val) {
      this.multipleSelection1 = val;
    },
    mySelect3(val) {
      this.multipleSelection2 = val;
    },
    // 必修课添加
    addbxk() {
      this.tableData3.push({
        bz: "",
        fzr: "",
        id: this.tableData3.length + 1,
        mc: "",
        xf: "",
        xnxq: "",
        semesterList1: []
      });
    },
    deletebxk() {
      if (this.multipleSelection2.length == 0) {
        return this.$message.error("请勾选数据进行删除！");
      }
      this.multipleSelection2.forEach(element => {
        this.tableData3.splice(
          this.tableData3.findIndex(item => item === element),
          1
        );
      });
    }
  },
  mounted() {
    this.getNumber();
    this.getKcList();
  },
  computed: {
    min: function() {
      return (
        Number(this.degreemin) +
        Number(this.electivemin) +
        Number(this.tachemin)
      );
    },
    kchList: function() {
      this.kchHistorys = [];
      this.kchHistory.forEach(el => {
        if (el.kcmc) {
          const kch = el.kcmc.split(" ")[0];
          this.kchHistorys.push(kch);
        }
      });
      return this.kchHistorys;
    },
    kchHistory: function() {
      console.log([...this.tableData, ...this.tableData2]);
      return [...this.tableData, ...this.tableData2, ...this.tableData3];
    },
    degreeTotalClass() {
      return this.tableData.length;
    },
    degreeTotalScore() {
      if (this.tableData.length > 0) {
        var totalnum = this.tableData
          .map(row => row.xf * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    degreeTotalTime() {
      if (this.tableData.length > 0) {
        var totalnum = this.tableData
          .map(row => row.xs * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    // 总门数
    electiveTotalClass() {
      return this.tableData2.length;
    },
    // 总学分
    electiveTotalScore() {
      if (this.tableData2.length > 0) {
        var totalnum = this.tableData2
          .map(row => row.xf * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    // 总学时
    electiveTotalTime() {
      if (this.tableData2.length > 0) {
        var totalnum = this.tableData2
          .map(row => row.xs * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    bxTotalClass() {
      return this.tableData3.length;
    },
    bxTotalScore() {
      if (this.tableData3.length > 0) {
        var totalnum = this.tableData3
          .map(row => row.xf * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.myInput {
  width: 200px !important;
}
.fr {
  float: right;
  margin-top: 10px;
}
.planDetails {
  .top-title {
    padding-right: 15px;
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .tablehack {
    .statistics {
      height: 40px;
      width: 100%;
      background: #f5f5f5;
      line-height: 40px;
      padding-right: 20px;
      margin-bottom: 10px;
      span {
        font-size: 14px;
        color: #666;
        margin-left: 30px;
      }

      .minimum {
        float: right;
        font-size: 14px;
        color: #666;
      }
    }
    .main-container {
      width: 100%;
      margin-top: 30px;
      padding-left: 20px;
      padding-bottom: 30px;

      .table {
        width: 100%;
        .addClass {
          margin-top: 15px;
        }
      }
    }
  }

  table {
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 42px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 42px;
      line-height: 42px;
      padding-left: 5px;
      text-align: center;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  /deep/ .el-tabs__active-bar {
    width: 100px !important;
  }
}

.planDetails /deep/ .el-tabs {
  height: 49px;
}
.planDetails /deep/ .el-tabs__header {
  height: 50px;
}
.planDetails /deep/ .el-tabs__nav-scroll {
  height: 50px;
}
.planDetails /deep/ .el-tabs__item {
  height: 50px;
  line-height: 50px;
  width: 125px;
  text-align: center;
}
.planDetails /deep/ thead .el-checkbox__inner {
  display: none;
}
</style>
