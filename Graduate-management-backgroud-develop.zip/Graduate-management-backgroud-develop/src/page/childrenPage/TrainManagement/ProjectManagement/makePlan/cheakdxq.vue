<template>
  <div class="planDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
      <!-- <el-button type="primary" class="fr" @click="saveData">保存</el-button> -->
    </div>
    <table align="center" border="1" cellspacing="0" cellpadding="0">
      <tr align="center">
        <td class="listcss">培养方案号</td>
        <td class="listcss">{{this.rowid}}</td>
        <td class="listcss">学院</td>
        <td>
          <el-select v-model="form.dwh" filterable  style="width:100%" :disabled="true">
            <el-option v-for="(item,index) in collegeList" :key="index" :label="item.dwmc" :value="item.dwh">
            </el-option>
          </el-select>
        </td>
        <td class="listcss">专业</td>
        <td>
          <el-select v-model="form.zyh" filterable  style="width:100%" :disabled="true">
            <el-option v-for="(item,index) in majorList" :key="index" :label="item.zymc" :value="item.zyh">
            </el-option>
          </el-select>
        </td>
      </tr>
      <tr align="center">
        <td class="listcss">计划年级</td>
        <td>
          <el-select v-model="form.jhnj" filterable  style="width:100%" :disabled="true">
            <el-option v-for="item in $stores.state.planclass" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </td>
        <td class="listcss">培养层次</td>
        <td>
          <el-select v-model="form.pyccm" filterable  style="width:100%" :disabled="true">
            <el-option v-for="item in levelList" :key="item.code" :label="item.name" :value="item.code">
            </el-option>
          </el-select>
        </td>
        <td class="listcss">最低总学分要求</td>
        <td>
          <span>{{min}}</span>
        </td>
      </tr>
      <tr align="center">
        <td class="listcss" style="height:80px;">培养目标</td>
        <td colspan="5">
          <el-input v-model="form.pymb" type="textarea" :autosize="{ minRows: 2, maxRows: 10}" :disabled="true">
          </el-input>
        </td>
      </tr>
      <tr align="center">
        <td class="listcss" style="height:80px;">研究方向</td>
        <td colspan="5">
          <el-input v-model="form.yjfx" type="textarea" :autosize="{ minRows: 2, maxRows: 8}" :disabled="true">
          </el-input>
        </td>
      </tr>
    </table>

    <!-- table切换 -->
    <!-- ---------------------------------------------------------- -->
    <el-tabs v-model="activeName" class="tablehack">
      <el-tab-pane label="学位课" name="first">
        <!-- 学位课 -->
        <div class="hadle-container1">
          <div class="statistics">
            <span>总门数: {{degreeTotalClass}}</span>
            <span>总学分：{{degreeTotalScore}}</span>
            <span>总学时：{{degreeTotalTime}}</span>
            <div class="minimum">
              最低学分要求：
              <el-input v-model.number="degreemin" style="width: 150px; position: relative;" size="small" type="number" :disabled="true">
                <template slot="prepend">≥</template>
              </el-input>
            </div>
          </div>
          <div class="table">
            <el-table :data="tableData" @selection-change="mySelect" border ref="multipleTable" style="width: 100%" :span-method="arraySpanMethod" :header-cell-style="$storage.tableHeaderColor">
              <!-- <el-table-column type="selection" width="55">
              </el-table-column> -->
              <el-table-column label="课程号 课程名称">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.kcmc" filterable placeholder="请选择"  @focus="getKcList" @change="selectXWtable(scope.row.kcmc, scope.row,scope.$index,'必修')" :disabled="true">
                    <el-option v-for="item in degreeList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kkdwmc" label="开课学院" width="200px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.kkdwmc}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xf" label="学分" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.xf}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xs" label="学时" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.xs}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kkxq" label="开课学年学期">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.kkxq" filterable placeholder="请选择" style="margin-left: 10px;" :disabled="true">
                    <el-option v-for="item in workList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kcsxh" label="课程属性" width="100px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.kcsxh }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kcxz" label="课程性质" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.kcxz | kcsxh(kcxzList)}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="ksxsmc" label="考试形式" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.ksxsmc}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="tgcj" label="通过成绩" width="160px">
                <template slot-scope="scope">
                  <span v-if="scope.row.ksxsmc =='考试'">{{scope.row.tgcj}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="group" label="课程组" width="120px">
                <template slot-scope="scope">
                  {{scope.row.group}}
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!-- 学位课 -->
      </el-tab-pane>
      <el-tab-pane label="选修课" name="second">
        <div class="hadle-container2" v-if="activeName == 'second'">
          <div class="statistics">
            <span>总门数: {{electiveTotalClass}}</span>
            <span>总学分：{{electiveTotalScore}}</span>
            <span>总学时：{{electiveTotalTime}}</span>
            <div class="minimum">
              最低学分要求：
              <el-input v-model.number="electivemin" style="width: 150px; position: relative;" size="small" type="number" :disabled="true">
                <template slot="prepend">≥</template>
              </el-input>
            </div>
          </div>
          <div class="table">
            <el-table :data="tableData2" @selection-change="mySelect2" border ref="multipleTable1" style="width: 100%" :header-cell-style="$storage.tableHeaderColor">
              <el-table-column label="课程号 课程名称">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.kcmc" filterable placeholder="请选择"  @focus="getKcList" @change="selectXWtable(scope.row.kcmc, scope.row,scope.$index,'选修')" :disabled="true">
                    <el-option v-for="item in degreeList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kkdwmc" label="开课学院">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.kkdwmc}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xf" label="学分" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.xf}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xs" label="学时" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.xs}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kkxq" label="开课学年学期">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.kkxq" filterable placeholder="请选择" style="margin-left: 10px;" :disabled="true">
                    <el-option v-for="item in workList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="kcsxh" label="课程属性">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.kcsxh }}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="kcxz" label="课程性质" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.kcxz | kcsxh(kcxzList)}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="ksxsmc" label="考试形式" width="110px">
                <template slot-scope="scope">
                  <div>
                    {{scope.row.ksxsmc}}
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="tgcj" label="通过成绩" width="160px">
                <template slot-scope="scope">
                  <span v-if="scope.row.ksxsmc =='考试'">{{scope.row.tgcj}}</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="必修环节" name="third">
        <div class="hadle-container2" v-if="activeName == 'third'">
          <div class="statistics">
            <span>总门数: {{bxTotalClass}}</span>
            <span>总学分：{{bxTotalScore}}</span>
            <div class="minimum">
              最低学分要求：
              <el-input v-model.number="tachemin" style="width: 150px; position: relative;" size="small" type="number" :disabled="true">
                <template slot="prepend">≥</template>
              </el-input>
            </div>
          </div>
          <div class="table">
            <el-table :data="tableData3" @selection-change="mySelect3" border ref="multipleTable1" style="width: 100%" :header-cell-style="$storage.tableHeaderColor">
              <el-table-column label="名称">
                <template slot-scope="scope">
                  {{scope.row.mc}}
                </template>
              </el-table-column>
              <el-table-column prop="xf" label="学分">
                <template slot-scope="scope">
                  {{scope.row.xf}}
                </template>
              </el-table-column>

              <el-table-column prop="kcsxh" label="课程属性">
                <template slot-scope="scope">
                  <div>
                    实践
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="fzr" label="负责人">
                <template slot-scope="scope">
                  {{scope.row.temp.label}}
                </template>
              </el-table-column>
              <el-table-column prop="xnxq" label="学年学期">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.xnxq" filterable placeholder="请选择" style="margin-left: 10px;" :disabled="true">
                    <el-option v-for="item in workList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="bz" label="备注">
                <template slot-scope="scope">
                  {{scope.row.bz}}
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
export default {
  props: ["rowid", "rowzt", "rowxgid", "btnxq"],
  name: "planDetails",
  data() {
    return {
      // 表单参数
      form: {
        zyh: ""
      },
      // 弹框参数
      leastForm: { leastClass: "" },
      // 学位课列表
      tableData: [],
      addDialog: false,
      activeName: "first",
      // 弹框最少选择门数：
      leastClassList: [],
      collegeList: [], // 学院列表
      majorList: [], // 专业列表
      planGradeList: [], // 计划年级列表
      levelList: [], // 培养层次列表,
      // 学位课最低学分要求：
      degreemin: 0,
      degreeList: [], // 学位课列表
      degreeDetails: [],
      kchHistorys: [],
      kcxzList: [],
      workList: [],
      // 课程组初始的数字
      courseKczNum: 1,
      multipleSelection: [],
      hB: false,
      conArr: [],
      electivemin: 0,
      tachemin: 0,
      tableData2: [], // 选修课列表
      multipleSelection1: [],
      tableData3: [],
      multipleSelection2: [],
      tutorLoading: false,
      tableindex: 0
    };
  },
  filters: {
    kcsxh(val, all) {
      if (val && all.length) {
        return all.find(el => el.code == val).name;
      }
    }
  },
  watch: {
    "form.dwh": {
      handler(val) {
        this.majorList = [];
        // this.form.zyh = "";
        this.zyselect(val);
      }
    }
  },
  methods: {
    zyselect(val) {
      this.$http
        .get("/api/cultivate/pyfa/selectZyByDwh", {
          params: {
            dwh: val
          }
        })
        .then(res => {
          const data = res.data.data;
          this.majorList = data;
          // this.form.zyh = this.majorList[0].zyh;
        });
    },
    queryTutorByName(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        res.data.data.length > 0
          ? (this.tableData3[this.tableindex].semesterList1 = res.data.data)
          : this.tableData[this.tableindex].semesterList1;
      });
    },
    selectjs(val) {
      this.tableindex = val;
    },
    // 获取下拉所需要数据
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectJsQxJh").then(res => {
        this.kcxzList = res.data.data.kcxzs; // 课程性质
        // 学院
        this.collegeList = res.data.data.dwList;
        // 培养层次
        this.levelList = res.data.data.pyccs;
      });
    },
    // 课程下拉框向后台传值
    getKcList() {
      console.log(this.kchList);
      this.$http
        .post("/api/cultivate/pyfa/selectKcListByTabChange", this.kchList)
        .then(res => {
          this.degreeList = [];
          this.degreeDetails = res.data.data;
          res.data.data.map((item, index) => {
            const obj = {
              value: item.kch + " " + item.kcmc,
              label: item.kch + " " + item.kcmc
            };
            this.degreeList.push(obj);
          });
        });
      this.$http.get("/api/cultivate/pycssz/planTermList").then(res => {
        this.workList = res.data.data;
      });
    },
    selectXWtable(value, row, index, val) {
      this.degreeDetails.map((item, index) => {
        if (value == item.kch + " " + item.kcmc) {
          row.xf = item.xf;
          row.xs = item.zxs;
          row.ksxsmc = item.ksxsmc;
          row.kcxz = item.kcxzh;
          row.kcsxh = val;
          row.kch = item.kch;
          row.ksxs = item.ksxsmc == "考试" ? 1 : 2;
        }
      });
    },
    // 返回
    exitList() {
      this.$emit("cheakdlist", false);
    },
    // 学位课合并行或者列
    arraySpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 9) {
        return {
          rowspan: row.rowspan,
          colspan: 1
        };
      }
    },
    // 学位课复选框勾选方法
    mySelect(val) {
      this.multipleSelection = val;
    },
    // 选修课复选框勾选方法
    mySelect2(val) {
      this.multipleSelection1 = val;
    },
    mySelect3(val) {
      this.multipleSelection2 = val;
    },
    takeDetailsList() {
      this.$http.get("api/cultivate/pyfa/selectXq/" + this.rowid).then(res => {
        this.tableData3 = res.data.data.pyFaBxKcs;
        this.tableData2 = res.data.data.pyFaXxKcs;
        let tableData = JSON.parse(JSON.stringify(res.data.data.pyFaWwKcs));
        let tmp,
          arr = [];
        tableData.sort((a, b) => {
          return a.kcz - b.kcz;
        });
        this.tableData2.map(v => {
          v.kcmc = v.kch + " " + v.kcmc;
          this.kcxzList.forEach(el => {
            if (el.name == v.kcxz) {
              v.kcxz = el.code;
            }
          });
        });
        tableData.map(v => {
          v.kcmc = v.kch + " " + v.kcmc;
          console.log(this.degreeDetails);
          this.kcxzList.forEach(el => {
            if (el.name == v.kcxz) {
              v.kcxz = el.code;
            }
          });
          this.$set(v, "shkczh", false);
          this.$set(v, "rowspan", 1);
          this.$set(v, "group", "");
          tmp = "";
          if (arr.includes(v.kcz)) {
            v.rowspan = 0;
            return;
          }
          if (v.kcz) {
            v.shkczh = true;
            tmp = v.kcz;
            v.rowspan = tableData.reduce((prev, el) => {
              if (el.kcz === tmp) {
                v.group = `最少${prev}门`;
                return prev + 1;
              } else {
                return prev;
              }
            }, 0);
            arr.push(v.kcz);
          }
        });
        this.tableData = tableData;
        this.form = res.data.data.pyPyfasjb;
        this.degreemin = res.data.data.pyPyfasjb.xwkzdzxf;
        this.electivemin = res.data.data.pyPyfasjb.xxkzdzxf;
        this.tachemin = res.data.data.pyPyfasjb.bxhjzdzxf;
        var index = this.collegeList.find(
          el => el.dwmc === res.data.data.pyPyfasjb.dwh
        );
        if (index) {
          this.form.dwh = index.dwh;
        }
        this.zyselect(this.form.dwh);
        console.log(this.tableData);
      });
    }
  },
  mounted() {
    this.getNumber();
    this.getKcList();
    this.takeDetailsList();
  },
  computed: {
    min: function() {
      return (
        Number(this.degreemin) +
        Number(this.electivemin) +
        Number(this.tachemin)
      );
    },
    kchList: function() {
      this.kchHistorys = [];
      this.kchHistory.forEach(el => {
        if (el.kcmc) {
          const kch = el.kcmc.split(" ")[0];
          this.kchHistorys.push(kch);
        }
      });
      return this.kchHistorys;
    },
    kchHistory: function() {
      console.log([...this.tableData, ...this.tableData2]);
      return [...this.tableData, ...this.tableData2, ...this.tableData3];
    },
    degreeTotalClass() {
      return this.tableData.length;
    },
    degreeTotalScore() {
      if (this.tableData.length > 0) {
        var totalnum = this.tableData
          .map(row => row.xf * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    degreeTotalTime() {
      if (this.tableData.length > 0) {
        var totalnum = this.tableData
          .map(row => row.xs * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    // 总门数
    electiveTotalClass() {
      return this.tableData2.length;
    },
    // 总学分
    electiveTotalScore() {
      if (this.tableData2.length > 0) {
        var totalnum = this.tableData2
          .map(row => row.xf * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    // 总学时
    electiveTotalTime() {
      if (this.tableData2.length > 0) {
        var totalnum = this.tableData2
          .map(row => row.xs * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    },
    bxTotalClass() {
      return this.tableData3.length;
    },
    bxTotalScore() {
      if (this.tableData3.length > 0) {
        var totalnum = this.tableData3
          .map(row => row.xf * 1)
          .reduce((acc, cur) => cur + acc, 0);
        return Number(totalnum);
      } else {
        return 0;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.myInput {
  width: 200px !important;
}
.fr {
  float: right;
  margin-top: 10px;
}
.planDetails {
  .top-title {
    padding-right: 15px;
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .tablehack {
    .statistics {
      height: 40px;
      width: 100%;
      background: #f5f5f5;
      line-height: 40px;
      padding-right: 20px;
      margin-bottom: 10px;
      span {
        font-size: 14px;
        color: #666;
        margin-left: 30px;
      }

      .minimum {
        float: right;
        font-size: 14px;
        color: #666;
      }
    }
    .main-container {
      width: 100%;
      margin-top: 30px;
      padding-left: 20px;
      padding-bottom: 30px;

      .table {
        width: 100%;

        .addClass {
          margin-top: 15px;
        }
      }
    }
  }

  table {
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 42px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 42px;
      line-height: 42px;
      padding-left: 5px;
      text-align: center;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  /deep/ .el-tabs__active-bar {
    width: 100px !important;
  }
}

.planDetails /deep/ .el-tabs {
  height: 49px;
}
.planDetails /deep/ .el-tabs__header {
  height: 50px;
}
.planDetails /deep/ .el-tabs__nav-scroll {
  height: 50px;
}
.planDetails /deep/ .el-tabs__item {
  height: 50px;
  line-height: 50px;
  width: 125px;
  text-align: center;
}
.planDetails /deep/ thead .el-checkbox__inner {
  display: none;
}
</style>
