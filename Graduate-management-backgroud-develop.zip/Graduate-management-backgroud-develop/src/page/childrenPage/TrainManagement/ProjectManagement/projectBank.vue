<!-- 培养方案库 -->
<template>
  <div class="projectBank">
    <div class="container" v-if="$store.state.auditDetails == false">
      <componment>
        <div slot="left">
          <el-input v-model="search" placeholder="请输入培养方案号" style="width: 200px" @keyup.enter.native="handleFind" clearable @clear="inputClear1"></el-input>
          <el-button @click="handleFind">查询</el-button>
          <el-select v-model="time" filterable placeholder="全部制定年份" @change="selectChange1" @clear="selectClear1">
            <el-option v-for="item in timeList" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="college" filterable placeholder="全部学院" @change="selectChange2" @clear="selectClear2">
            <el-option v-for="(item, index) in collegeList" :key="index" :label="item.dwmc" :value="item.dwh">
            </el-option>
          </el-select>
        </div>
      </componment>
      <el-table :data="tableData" border ref="multipleTable" style="width:100%;" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
        <el-table-column prop="pyfah" label="培养方案号" width="150">
        </el-table-column>
        <el-table-column prop="zdnd" label="制定年份"> </el-table-column>
        <el-table-column prop="dwh" label="学院"> </el-table-column>
        <el-table-column prop="zyh" label="专业"> </el-table-column>
        <el-table-column prop="jhnj" label="计划年级"> </el-table-column>
        <el-table-column prop="pyccm" label="培养层次"> </el-table-column>
        <el-table-column prop="zdzxf" label="最低总学分要求"> </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="checkDetails(scope.row)" v-if="$btnAuthorityTest('projectBank:view')">查看详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
    </div>
    <auditDetails v-else-if="$store.state.auditDetails == true" :rowid="rowid"></auditDetails>
  </div>
</template>

<script>
import auditDetails from "./details/auditDetails";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "projectBank",
  data() {
    return {
      search: "",
      college: "",
      time: "",
      collegeList: [],
      timeList: [],
      tableData: [],
      total: 0,
      tableHeight: null,
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  methods: {
    // 获取下拉所需要数据
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectJsQxJh").then(res => {
        // console.log(res.data.data)
        const myRes = res.data.data;
        myRes.zdnfs.map((item, index) => {
          const obj = {
            value: item,
            label: item
          };
          this.timeList.push(obj);
        });
        this.timeList.unshift({ value: "", label: "全部年份" });
        if (myRes.dwList.length > 1) {
          this.collegeList = myRes.dwList;
          this.collegeList.unshift({ dwh: "", dwmc: `全部学院` });
        } else {
          this.collegeList = myRes.dwList;
          this.college = myRes.dwList[0].dwh;
        }
      });
    },
    // 查询输入框清除事件
    inputClear1() {
      this.search = "";
      this.takeList();
    },
    // 查询下拉框改变事件
    selectChange1(val) {
      this.time = val;
      this.takeList();
    },
    selectChange2(val) {
      this.college = val;
      this.takeList();
    },
    // 查询下拉框清除事件
    selectClear1() {
      this.time = "";
      this.takeList();
    },
    selectClear2() {
      this.college = "";
      this.takeList();
    },
    // 获取列表
    takeList() {
      this.loading2 = true;
      var params = {};
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .get(
          `api/cultivate/pyfa/all/${params.pageSize}/${params.pageNum}?dwh=${this.college}&zdnd=${this.time}&query=${this.search}`
        )
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 200) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          } else {
            this.tableData = [];
            this.total = 1;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    handleFind() {
      this.takeList();
    },
    // 查看详情
    checkDetails(row) {
      this.$store.state.auditDetails = true;
      this.rowid = row.pyfah;
    }
  },
  components: {
    auditDetails,
    pagination,
    componment
  },
  created() {},
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.getNumber();
  }
};
</script>

<style scoped lang="scss">
.projectBank {
  width: 100%;
  padding-top: 7px;
}
</style>
