<template>
  <div class="assessmentquestionnaire">
    <componment>
      <div slot="left">
        <div class="title">
          <span class="span_container">{{ remark }}</span>
          <span class="span_container">{{ time }} {{ timezq }}</span>
        </div>
      </div>
      <div slot="right">
        <template v-if="$btnAuthorityTest('assessmentquestionnaire:publish')">
          <el-button
            type="primary"
            style="float:right;margin-top:10px;"
            @click="excel"
            v-if="status == 1"
            >取消发布</el-button
          >
          <el-button
            type="primary"
            style="float:right;margin-top:10px;margin-right:10px;"
            @click="excels"
            v-if="status !== 1"
            >发布</el-button
          >
        </template>
      </div>
    </componment>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="$storage.tableHeaderColor"
    >
      <el-table-column label="评价项目" width="200">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.pjxm"
            placeholder="请输入内容"
            :disabled="disbale"
          ></el-input>
        </template>
      </el-table-column>
      <el-table-column label="评价内容">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.pjnr"
            placeholder="请输入内容"
            :disabled="disbale"
          ></el-input>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150px" v-if="status !== 1">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="add"
            v-if="scope.$index === tableData.length - 1"
            >添加</span
          >
          <span
            class="tablesc"
            @click="del(scope.row)"
            v-if="scope.$index !== 0"
            >删除</span
          >
        </template>
      </el-table-column>
    </el-table>
    <el-row>
      <el-col :span="24">
        <div class="grid-content bg-purple-dark">
          <span style="color:red;font-size:16px">注</span
          ><span style="font-size:16px"
            >: 评价等级A为优秀，B为良好，C为及格，D为不及格。</span
          >
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import componment from "@/components/searchcomponment";
export default {
  name: "assessmentquestionnaire",
  data() {
    return {
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadd: [],
      optionsadds: [],
      tableHeight: null,
      tableData: [],
      status: "",
      id_data: "",
      disbale: false,
      foot: 0,
      remark: "当前学年学期",
      time: "",
      timezq: ""
    };
  },
  components: {
    componment
  },
  methods: {
    clearinput() {
      this.search = "";
    },
    handleFind() {},
    excels() {
      var flag = true;
      this.tableData.map(v => {
        if (flag) {
          if (v.pjxm == "" || v.pjnr == "") {
            this.$message({
              message: "发布参数不能为空",
              type: "error"
            });
            flag = false;
          }
        }
      });
      if (flag) {
        this.$http
          .post("api/cultivate/pjwj/start", {
            id: this.id_data,
            xnd: this.upmodel,
            nrList: this.tableData
          })
          .then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.data.message,
                type: "error"
              });
            } else {
              this.userlist();
            }
          });
      }
    },
    excel() {
      this.$http
        .put(`api/cultivate/pjwj/cancel?id=${this.id_data}`)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.userlist();
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          }
        });
    },
    handleSelectionChange() {},
    changePage() {},
    sizeChange() {},
    add() {
      const obj = {
        pjxm: "",
        pjnr: ""
      };
      this.tableData.push(obj);
    },
    del(val) {
      this.tableData.splice(
        this.tableData.findIndex(item => item === val),
        1
      );
    },
    userlist() {
      this.$http.get("api/cultivate/pjwj/selectByWjid").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          if (!res.data.data.nrList || res.data.data.nrList.length == 0) {
            this.tableData.push({
              pjxm: "",
              pjnr: ""
            });
          } else {
            this.id_data = res.data.data.id;
            this.status = res.data.data.zt;
            // ==1已发布状态
            if (this.status == 1) {
              this.tableData = res.data.data.nrList;
              this.disbale = true;
            } else {
              this.disbale = false;
              this.tableData = res.data.data.nrList;
            }
          }
        }
      });
    }
  },
  mounted() {
    this.$http.get("api/cultivate/pycssz/acadmic").then(res => {
      this.loading2 = false;
      this.remark = res.data.data.remark;
      this.time = `${res.data.data.main.year}年`;
      if (res.data.data.main.semester == "2") {
        this.timezq = "春季学期";
      }
      if (res.data.data.main.semester == "1") {
        this.timezq = "秋季学期";
      }
    });
    this.userlist();
    this.$http.get("api/cultivate/pycssz/acadYearTermHisList").then(res => {
      if (res.data.code == 400) {
        this.$message({
          message: res.data.data.message,
          type: "error"
        });
      } else {
        this.optionsadd = res.data.data.kkxq;
      }
    });
  }
};
</script>

<style scoped lang="scss">
.assessmentquestionnaire {
  width: 100%;
  .title {
    width: 100%;
    height: 60px;
    padding: 10px 0 10px 15px;
    box-sizing: border-box;
    border-bottom: 1px solid #e4e4e4;
    border-top: 1px solid #e4e4e4;
    .span_container {
      font-family: "Microsoft Tai Le";
      font-weight: 400;
      font-style: normal;
      font-size: 14px;
      color: #1890ff;
    }
  }
}
</style>
