<template>
  <div class="evaluationresultslist">
    <div class="studentmessage_box">
      <div class="top-title">
        <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
        <el-button type="primary" class="btnright">导出</el-button>
      </div>
    </div>
    <el-row>
      <el-col :span="24" style="font-size:14px;">
        <div class="grid-content bg-purple-dark">
          <div style="float:left;margin-right:30px;">
            <span>学期: </span>2019年秋
          </div>
          <div style="float:left;margin-right:30px;">
            <span>教师: </span>{{username}}
          </div>
          <div style="float:left;margin-right:30px;">
            <span>所在学院: </span>{{classname}}
          </div>
          <div style="float:left">
            <span>所授课程: </span>{{classnumber}}
          </div>
        </div>
      </el-col>
    </el-row>
    <div style="clear:both;margin-bottom:15px"></div>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange">
      <el-table-column prop="pjxm" label="评价项目"></el-table-column>
      <el-table-column prop="pjnr" label="评价内容"></el-table-column>
      <el-table-column prop="id" label="评教结果">
        <template slot-scope="scope">
          <div style="position: relative;height:28px;padding-top:3px;">
            <el-progress :percentage="scope.row.countA/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100" :show-text="false" style="width:92%;"></el-progress><span style="display:inline-block; position: absolute;right:0;top:-5px;font-size:12px;">A:{{scope.row.countA/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100}}%</span>
          </div>
          <div style="position: relative;height:28px;padding-top:3px;">
            <el-progress :percentage="scope.row.countB/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100" :show-text="false" style="width:92%;"></el-progress><span style="display:inline-block; position: absolute;right:0;top:-5px;font-size:12px;">B:{{scope.row.countB/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100}}%</span>
          </div>
          <div style="position: relative;height:28px;padding-top:3px;">
            <el-progress :percentage="scope.row.countC/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100" :show-text="false" style="width:92%;"></el-progress><span style="display:inline-block; position: absolute;right:0;top:-5px;font-size:12px;">C:{{scope.row.countC/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100}}%</span>
          </div>
          <div style="position: relative;height:28px;padding-top:3px;">
            <el-progress :percentage="scope.row.countD/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100" :show-text="false" style="width:92%;"></el-progress><span style="display:inline-block; position: absolute;right:0;top:-5px;font-size:12px;">D:{{scope.row.countD/(scope.row.countA + scope.row.countB + scope.row.countC + scope.row.countD)*100}}%</span>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[15, 25, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange" background></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "evaluationresultslist",
  data() {
    return {
      username: "admin",
      classname: "admin",
      classnumber: "admin",
      search: "",
      upmodel: "",
      upmodels: "",
      upmodeloptions: "",
      optionsadd: [],
      optionsadds: [],
      options: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 5,
      currentPage: 1,
      total: 0,
      tableData: [
        {
          id: 1
        }
      ]
    };
  },
  filters: {
    countA(val) {
      return parseInt(val);
    }
  },
  methods: {
    clearinput() {
      this.search = "";
    },
    handleFind() {},
    excel() {},
    handleSelectionChange() {},
    changePage() {},
    sizeChange() {},
    exitList() {
      this.$router.push("/evaluationresults");
      this.$parent.list();
    },
    userlist() {
      this.$http
        .get("api/cultivate/pjwj/info?gh=" + this.$route.query.gh)
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        });
    }
  },
  mounted() {
    this.username = this.$route.query.xm;
    this.classname = this.$route.query.dwmc;
    this.classnumber = this.$route.query.kcList;
    this.userlist();
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160);
        this.pagesize = Math.floor(this.tableHeight / 57) - 1;
      })();
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1;
  }
};
</script>

<style scoped lang="scss">
.evaluationresultslist {
  width: 100%;
  height: 100%;
  .studentmessage_box {
    width: 100%;
    height: 60px;
    line-height: 60px;
    padding-left: 10px;
    padding-right: 10px;
    margin-bottom: 10px;

    .top-title {
      width: 100%;
      height: 60px;
      border-bottom: 1px solid #f2f2f2;
      line-height: 60px;
      .diyButton {
        background: none;
        border: none;
        color: #2779e3;
      }

      .btnright {
        float: right;
        margin-top: 10px;
        margin-right: 10px;
      }
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
