<template>
  <div class="Registrationsix">
    <componment>
      <div slot="left">
        <el-input
          v-model="search"
          placeholder="请输入学号/姓名"
          style="width: 200px"
          @keyup.enter.native="handleFind"
        >
          <i
            slot="suffix"
            class="el-input__icon el-icon-circle-close"
            @click="clearinput"
          ></i>
        </el-input>
        <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        <template v-if="options">
          <el-select
            v-model="upmodeloptions"
            placeholder="请选择学期学年"
            
            filterable
            @change="changeselectupmodels"
          >
            <el-option
              v-for="(item, $index) in options"
              :key="$index"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </template>
        <template v-if="optionsadd">
          <el-select
            v-model="upmodel"
            placeholder="请选择学院"
            
            filterable
            @change="changeselect"
          >
            <el-option
              v-for="(item, $index) in optionsadd"
              :key="$index"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </template>
        <template v-if="optionsadds">
          <el-select
            v-model="upmodels"
            placeholder="请选择专业"
            
            filterable
            @change="changeselectupmodels"
          >
            <el-option
              v-for="(item, $index) in optionsadds"
              :key="$index"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </template>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          style="float:right;margin-top:10px;"
          @click="excel"
          v-if="$btnAuthorityTest('Registrationsix:export')"
          >导出</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="$storage.tableHeaderColor"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column label="序号" width="55" type="index"></el-table-column>
      <el-table-column prop="xh" label="学号"></el-table-column>
      <el-table-column prop="xsxm" label="姓名"></el-table-column>
      <el-table-column prop="yxsmc" label="学院"></el-table-column>
      <el-table-column prop="zy" label="专业"></el-table-column>
      <el-table-column prop="sznj" label="年级"></el-table-column>
      <el-table-column prop="dh" label="电话号码"></el-table-column>
      <el-table-column prop="bmlx" label="报名考试名称"></el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="userlist"
      v-if="loadingpagination"
    ></pagination>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  components: {
    pagination,
    componment
  },
  name: "Registrationsix",
  data() {
    return {
      search: "",
      upmodel: null,
      upmodels: null,
      upmodeloptions: null,
      upmodelclass: null,
      optionsadd: [],
      optionsadds: [],
      options: [],
      optionsclass: [],
      tableHeight: null,
      total: 0,
      tableData: [],
      loadingpagination: true,
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  methods: {
    formset() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
      }, 500);
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
      this.userlist();
    },
    changeselectupmodels() {
      this.formset();
    },
    changeselect() {
      if (this.optionsadd.length == 0) {
        this.optionsadds = [];
      } else {
        this.optionsadd.map(v => {
          if (this.upmodel === v.value) {
            this.optionsadds = v.children;
          }
        });
      }
    },
    clearinput() {
      this.search = "";
      this.formset();
    },
    handleFind() {
      this.formset();
    },
    excel() {},
    handleSelectionChange() {},
    changePage() {},
    sizeChange() {},
    semesters() {
      this.$http.get("api/cultivate/sac/select/academic").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          this.options = res.data.data;
        }
      });
      this.$http.get("api/system/dict/select/college").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          this.optionsadd = res.data.data;
        }
      });
    },
    userlist() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      this.$http
        .post("api/cultivate/cet/list", {
          academic: this.upmodeloptions,
          collegeCode: this.upmodel,
          majorCode: this.upmodels,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.search
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.semesters();
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.Registrationsix {
  width: 100%;
  padding-top: 7px;
}
</style>
