<template>
  <div class="Graduatemanagement">
    <componment>
      <div slot="left">
        <el-input v-model="search" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind">
          <i slot="suffix" class="el-input__icon el-icon-circle-close" @click="clearinput"></i>
        </el-input>
        <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        <template v-if="options">
          <el-select v-model="upmodeloptions" placeholder="请选择学生类别"  filterable>
            <el-option v-for="(item,$index) in options" :key="$index" :label="item.gncdmc" :value="item.id"></el-option>
          </el-select>
        </template>
        <template v-if="optionsadd">
          <el-select v-model="upmodel" placeholder="请选择学院"  filterable>
            <el-option v-for="(item,$index) in optionsadd" :key="$index" :label="item.gncdmc" :value="item.id"></el-option>
          </el-select>
        </template>
      </div>
      <div slot="right">
        <el-button type="primary" @click="excel">导出</el-button>
        <el-button type="primary" @click="excel">批量生成毕业证号</el-button>
      </div>
    </componment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column prop="id" label="序号" width="55"></el-table-column>
      <el-table-column prop="id" label="学号"></el-table-column>
      <el-table-column prop="id" label="姓名"></el-table-column>
      <el-table-column prop="id" label="学生类别"></el-table-column>
      <el-table-column prop="id" label="学院"></el-table-column>
      <el-table-column prop="id" label="专业"></el-table-column>
      <el-table-column prop="id" label="年级"></el-table-column>
      <el-table-column prop="id" label="毕业时间"></el-table-column>
      <el-table-column prop="id" label="毕业证号"></el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
  </div>
</template>

<script>
import pagination from '@/components/pagination';
import componment from '@/components/searchcomponment';
export default {
  name: 'Financialpayment',
  components: {
    pagination,
    componment
  },
  data() {
    return {
      loading2: false,
      loadingpagination: true,
      search: '',
      upmodel: '',
      upmodels: '',
      upmodeloptions: '',
      upmodelclass: '',
      optionsadd: [],
      optionsadds: [],
      options: [],
      optionsclass: [],
      tableHeight: null,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      total: 0,
      tableData: []
    }
  },
  methods: {
    clearinput() {
      this.search = '';
    },
    handleFind() {},
    excel() {},
    handleSelectionChange() {},
    changePage() {},
    sizeChange() {},
    userlist() {}
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230
      })()
    };
  }
}
</script>

<style scoped lang="scss">
.Graduatemanagement {
  width: 100%;
  padding-top: 7px;
}
</style>
