<template>
  <div class="resultssummary">
    <componment>
      <div slot="left">
        <el-input v-model="search" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind">
          <i slot="suffix" class="el-input__icon el-icon-circle-close" @click="clearinput"></i>
        </el-input>
        <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        <template v-if="options">
          <el-select v-model="upmodeloptions" placeholder="请选择学期学年" filterable @change="changeselectupmodels">
            <el-option v-for="(item, $index) in options" :key="$index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </template>
        <template v-if="optionsadd">
          <el-select v-model="upmodel" placeholder="请选择学院" filterable @change="changeselect">
            <el-option v-for="(item, $index) in optionsadd" :key="$index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </template>
        <template v-if="optionsadds">
          <el-select v-model="upmodels" placeholder="请选择专业" filterable @change="changeselectupmodels">
            <el-option v-for="(item, $index) in optionsadds" :key="$index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </template>
        <template v-if="optionsclass">
          <el-select v-model="upmodelclass" placeholder="请选择年级" filterable @change="changeselectupmodels">
            <el-option v-for="(item, $index) in optionsclass" :key="$index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </template>
      </div>
      <div slot="right">
        <el-button type="primary" style="float:right;margin-top:10px;" @click="excel" v-if="$btnAuthorityTest('resultssummary:export')">导出</el-button>
      </div>
    </componment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column type="index" label="序号" width="55"></el-table-column>
      <el-table-column prop="xh" label="学号"></el-table-column>
      <el-table-column prop="xsxm" label="姓名"></el-table-column>
      <el-table-column prop="yxsmc" label="学院"></el-table-column>
      <el-table-column prop="zy" label="专业"></el-table-column>
      <el-table-column prop="sznj" label="年级"></el-table-column>
      <el-table-column prop="kcmc" label="课程名称"></el-table-column>
      <el-table-column prop="pscj" label="平时成绩"></el-table-column>
      <el-table-column prop="qmcj" label="期末成绩"></el-table-column>
      <el-table-column prop="zzcj" label="最终成绩">
        <template slot-scope="scope">
          <span v-if="scope.row.ksxs == '2'"> {{ scope.row.zzcj | zzcj }}</span>
          <span v-if="scope.row.ksxs == '1'"> {{ scope.row.zzcj }}</span>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  components: {
    pagination,
    componment
  },
  name: "Financialpayment",
  data() {
    return {
      loading2: false,
      loadingpagination: true,
      search: "",
      upmodel: "",
      upmodels: "",
      upmodeloptions: "",
      upmodelclass: "",
      optionsadd: [],
      optionsadds: [],
      options: [],
      optionsclass: [],
      tableHeight: null,
      total: 0,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  filters: {
    zzcj(val) {
      if (val == "0") {
        return "未通过";
      }
      if (val == "1") {
        return "已通过";
      }
    }
  },
  methods: {
    changeselectupmodels() {
      this.formset();
    },
    changeselect() {
      if (this.optionsadd.length == 0) {
        this.optionsadds = [];
      } else {
        this.optionsadd.map(v => {
          if (this.upmodel === v.value) {
            this.optionsadds = v.children;
          }
        });
      }
    },
    clearinput() {
      this.search = "";
      this.formset();
    },
    handleFind() {
      this.formset();
    },
    formset() {
      this.userlist();
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
      }, 500);
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    excel() {},
    handleSelectionChange() {},
    semesters() {
      this.$http.get("/api/cultivate/pycssz/acadYearTermHisList").then(res => {
        console.log(res);
        this.options = res.data.data;
        this.upmodeloptions = res.data.data[0].value;
      });
      // this.$http.get("/api/cultivate/pycssz/planTermList").then(res => {
      //   this.options = res.data.data;
      // });

      this.$http.get("api/system/dict/select/college").then(res => {
        this.optionsadd = res.data.data;
        this.optionsadds = res.data.data[0].children;
        this.upmodels = res.data.data.children[0].value;
      });
      this.$http.get("api/cultivate/sac/select/grade").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          this.optionsclass = res.data.data;
          this.upmodelclass = res.data.data[0].value;
        }
      });
    },
    userlist() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      this.$http
        .post("api/cultivate/sac/list", {
          academic: this.upmodeloptions,
          collegeCode: this.upmodel,
          grade: this.upmodelclass,
          majorCode: this.upmodels,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.search
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.semesters();
    this.userlist();
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
  }
};
</script>

<style scoped lang="scss">
.resultssummary {
  width: 100%;
  padding-top: 7px;
}
</style>
