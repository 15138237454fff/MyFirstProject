<template>
  <div class="evaluationresults">
    <evaluationresultslist
      v-if="this.$route.path == '/evaluationresultslist'"
    ></evaluationresultslist>
    <template v-else>
      <componment>
        <div slot="left">
          <el-input
            v-model="search"
            placeholder="请输入教工号/姓名"
            style="width: 200px"
            @keyup.enter.native="handleFind"
          >
            <i
              slot="suffix"
              class="el-input__icon el-icon-circle-close"
              @click="clearinput"
            ></i>
          </el-input>
          <el-button @click="handleFind" style="margin-left:5px"
            >查询</el-button
          >
          <template v-if="optionsadd">
            <el-select
              v-model="upmodel"
              placeholder="请选择"
              
              filterable
            >
              <el-option
                v-for="(item, $index) in optionsadds"
                :key="$index"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </template>
          <template v-if="optionsadds">
            <el-select
              v-model="upmodels"
              placeholder="全部单位"
              
              filterable
              @change="upmodelschange"
            >
              <el-option
                v-for="(item, $index) in optionsadd"
                :key="$index"
                :label="item.dwmc"
                :value="item.dwh"
              ></el-option>
            </el-select>
          </template>
        </div>
        <div slot="right">
          <el-button
            type="primary"
            style="float:right;margin-top:10px;"
            @click="excel"
            v-if="$btnAuthorityTest('evaluationresults:export')"
            >导出</el-button
          >
        </div>
      </componment>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        ref="multipleTable"
        style="width: 100%;"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        :header-cell-style="$storage.tableHeaderColor"
        v-loading="loading2"
        element-loading-text="加载中"
      >
        <el-table-column prop="gh" label="工号"></el-table-column>
        <el-table-column prop="xm" label="姓名"></el-table-column>
        <el-table-column prop="dwmc" label="部门"></el-table-column>
        <el-table-column
          prop="kcList"
          label="所授课程"
          :show-overflow-tooltip="true"
        >
        </el-table-column>
        <el-table-column prop="id" label="评教结果" header-align="center">
          <template slot-scope="scope">
            <div
              :id="`main${scope.$index}`"
              :style="{ width: '250px', height: '120px' }"
            ></div>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button
              @click="handleClick(scope.row)"
              type="text"
              size="small"
              v-if="$btnAuthorityTest('evaluationresults:view')"
              >查看详情</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="list"
        v-if="loadingpagination"
      ></pagination>
    </template>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
import evaluationresultslist from "./evaluationresultslist";
var echarts = require("echarts");
export default {
  components: {
    pagination,
    componment,
    evaluationresultslist
  },
  name: "evaluationresults",
  data() {
    return {
      loading2: false,
      search: "",
      upmodel: "",
      upmodels: "",
      optionsadd: [],
      optionsadds: [],
      tableHeight: null,
      total: 0,
      tableData: [],
      newarr: [],
      valuedata: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loadingpagination: true
    };
  },
  methods: {
    upmodelschange() {
      this.resetform();
    },
    getAllChart() {
      console.log(142);
      for (let i = 0; i < this.tableData.length; i++) {
        console.log(i);
        this.drawLine(i);
      }
    },
    drawLine(i) {
      this.newarr = [];
      this.valuedata = [];
      // 基于准备好的dom，初始化echarts实例
      let myChart = echarts.init(document.getElementById("main" + i));
      this.newarr = [
        `A:${this.tableData[i].countA}`,
        `B:${this.tableData[i].countB}`,
        `C:${this.tableData[i].countC}`,
        `D:${this.tableData[i].countD}`
      ];
      let obj = {
        value: this.tableData[i].countA,
        name: `A:${this.tableData[i].countA}`
      };
      let obj1 = {
        value: this.tableData[i].countB,
        name: `B:${this.tableData[i].countB}`
      };
      let obj2 = {
        value: this.tableData[i].countC,
        name: `C:${this.tableData[i].countC}`
      };
      let obj3 = {
        value: this.tableData[i].countD,
        name: `D:${this.tableData[i].countD}`
      };
      this.valuedata = [obj, obj1, obj2, obj3];
      console.log(this.valuedata);
      // 绘制图表
      myChart.setOption({
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
          orient: "vertical",
          x: "right",
          data: this.newarr
        },
        series: [
          {
            name: "评教结果",
            type: "pie",
            radius: ["50%", "70%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: this.valuedata
          }
        ]
      });
    },
    clearinput() {
      this.search = "";
      this.resetform();
    },
    resetform() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
      }, 500);
      this.list();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    handleFind() {
      this.resetform();
    },
    excel() {},
    handleSelectionChange() {},
    handleClick(val) {
      const obj = {
        gh: val.gh,
        xm: val.xm,
        dwmc: val.dwmc,
        kcList: val.kcList
      };
      this.$router.push({
        path: "/evaluationresultslist",
        query: obj
      });
    },
    userlist() {
      this.$http.get("api/cultivate/pyfa/selectDwList").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          this.optionsadd = res.data.data;
        }
      });
    },
    list() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      this.$http
        .get(
          "api/cultivate/pjwj/spss?dwh=" +
            this.upmodels +
            "&pageNum=" +
            params.pageNum +
            "&pageSize=" +
            params.pageSize +
            "&query=" +
            this.search
        )
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
            setTimeout(() => {
              this.getAllChart();
            }, 2000);
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  created() {},
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.$http.get("api/cultivate/kc/selectkkxq").then(res => {
      if (res.data.code == 400) {
        this.$message({
          message: res.data.data.message,
          type: "error"
        });
      } else {
        this.optionsadds = res.data.data.kkxq;
      }
    });
    this.userlist();
    this.list();
  }
};
</script>

<style scoped lang="scss">
.evaluationresults {
  width: 100%;
  padding-top: 7px;
}
</style>
