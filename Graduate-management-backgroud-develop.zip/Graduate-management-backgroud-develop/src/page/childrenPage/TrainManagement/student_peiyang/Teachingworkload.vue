<template>
  <div class="financialpayment">
    <componment>
      <div slot="left">
        <el-input v-model="search" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind">
          <i slot="suffix" class="el-input__icon el-icon-circle-close" @click="clearinput"></i>
        </el-input>
        <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        <template v-if="optionsadd">
          <el-select v-model="upmodel" placeholder="请选择学院"  filterable>
            <el-option v-for="(item,$index) in optionsadd" :key="$index" :label="item.gncdmc" :value="item.id"></el-option>
          </el-select>
        </template>
        <template v-if="optionsadds">
          <el-select v-model="upmodels" placeholder="请选择专业"  filterable>
            <el-option v-for="(item,$index) in optionsadd" :key="$index" :label="item.gncdmc" :value="item.id"></el-option>
          </el-select>
        </template>
      </div>
      <div slot="right">
        <el-button type="primary" @click="excel">批量导入</el-button>
      </div>
    </componment>
    <el-table :data="tableData" tooltip-effect="dark" border ref="multipleTable" style="width: 100%;" :height="tableHeight" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" v-loading="loading2" element-loading-text="加载中">
      <el-table-column prop="id" label="序号" width="55"></el-table-column>
      <el-table-column prop="id" label="学号"></el-table-column>
      <el-table-column prop="id" label="姓名"></el-table-column>
      <el-table-column prop="id" label="培养层次"></el-table-column>
      <el-table-column prop="id" label="学院"></el-table-column>
      <el-table-column prop="id" label="专业"></el-table-column>
      <el-table-column prop="id" label="应缴费用"></el-table-column>
      <el-table-column prop="id" label="实缴费用"></el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="userlist" v-if="loadingpagination"></pagination>
  </div>
</template>

<script>
import pagination from '@/components/pagination';
import componment from '@/components/searchcomponment';
export default {
  components: {
    pagination: pagination,
    componment: componment
  },
  name: 'Teachingworkload',
  data() {
    return {
      search: '',
      upmodel: '',
      upmodels: '',
      optionsadd: [],
      optionsadds: [],
      tableHeight: null,
      total: 0,
      tableData: [],
      loadingpagination: true,
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    }
  },
  methods: {
    clearinput() {
      this.search = '';
    },
    handleFind() {},
    excel() {},
    handleSelectionChange() {},
    userlist() {}
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230
      })()
    };
  }
}
</script>

<style scoped lang="scss">
.financialpayment {
  width: 100%;
  padding-top: 7px;
}
</style>
