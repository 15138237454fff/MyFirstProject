<template>
  <div class="sourceStudent">
    <common-table-bg :title="title" @input="inputTable">
      <div slot="top" class="slot-top">
        <div class="left">
          <div style="width:200px;margin-right:10px">
            <el-select
              style="margin-bottom:10px;"
              v-model="selectRange"
              @change="selectType = computedRange[0].value"
            >
              <el-option label="按专业技术职务分" value="1"></el-option>
              <el-option label="按指导关系分" value="2"></el-option>
            </el-select>
            <el-select v-model="selectType">
              <el-option
                :label="item.label"
                :value="item.value"
                v-for="(item, index) of computedRange"
                :key="index"
              ></el-option>
            </el-select>
          </div>
          <div ref="teacher" style="height:300px;width:300px"></div>
          <div class="label">
            <ul>
              <li
                v-for="(item, index) of color"
                :key="index"
                class="label-item"
              >
                <div style="flex:1">
                  <span :style="{ background: item }" class="dot"></span>
                </div>
                <div
                  style="width:100px;border-right:1px solid #ddd;margin:10px 10px 10px 0;"
                >
                  {{ titleList[index] }}
                </div>
                <template v-if="tableData[selectType]">
                  <div
                    v-if="tableData[selectType][0] !== 0"
                    style="color:#409dff"
                  >
                    {{
                      (
                        (tableData[selectType][index + 1] /
                          tableData[selectType][0]) *
                        100
                      ).toFixed(0)
                    }}%
                  </div>
                  <div style="color:#ccc">
                    {{ tableData[selectType][index + 1] }}
                  </div>
                </template>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        :span-method="oneSpanMethod"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span v-if="theadOneText[scope.$index]">{{
              theadOneText[scope.$index].label
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadTwoText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="0" label="合计"></el-table-column>
        <el-table-column prop="1" label="29岁以下"></el-table-column>
        <el-table-column prop="2" label="30-34岁"></el-table-column>
        <el-table-column prop="3" label="35-39岁"></el-table-column>
        <el-table-column prop="4" label="40-44岁"></el-table-column>
        <el-table-column prop="5" label="45-49岁"></el-table-column>
        <el-table-column prop="6" label="50-54岁"></el-table-column>
        <el-table-column prop="7" label="55-59岁"></el-table-column>
        <el-table-column prop="8" label="60-64岁"></el-table-column>
        <el-table-column prop="9" label="65岁以上"></el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
let echarts = require("echarts");
export default {
  name: "sourceStudent",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "研究生指导教师情况",
      tableData: [],
      theadOneText: {
        0: { label: "总计", value: 1 },
        1: { label: "其中：女", value: 1 },
        2: { label: "按专业技术职务分", value: 3 },
        5: { label: "按指导关系分", value: 6 }
      },
      theadTwoText: {
        2: "正高级",
        3: "副高级",
        4: "中级",
        5: "博士导师",
        6: "其中：女",
        7: "硕士导师",
        8: "其中：女",
        9: "博士、硕士导师",
        10: "其中：女"
      },
      selectRange: "1",
      selectType: "2",
      color: [
        "#ccccff",
        "#78bfff",
        "#005097",
        "#6699ff",
        "#6cf",
        "#fcc",
        "#fc9",
        "#9c6",
        "#ffb13e"
      ],
      titleList: [
        "29岁以下",
        "30-34岁",
        "35-39岁",
        "40-44岁",
        "45-49岁",
        "50-54岁",
        "55-59岁",
        "60-64岁",
        "65岁以上"
      ],
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 612;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 612;
      })();
    };
    this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
      location.href = "/api/cultivate/form/teacherFormExport";
    },
    drawTeacher() {
      let myChart = echarts.init(this.$refs.teacher);
      let data = this.tableData[this.selectType].map((el, index) => {
        return {
          value: el,
          name: this.titleList[index]
        };
      });
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c} ({d}%)"
        },
        color: this.color,
        series: [
          {
            name: this.titleList,
            type: "pie",
            center: ["50%", "45%"],
            radius: ["60%", "80%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: false,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    oneSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0 || rowIndex === 1) {
          return {
            rowspan: 1,
            colspan: 2
          };
        } else if (this.theadOneText[rowIndex]) {
          return { rowspan: this.theadOneText[rowIndex].value, colspan: 1 };
        } else {
          return [0, 0];
        }
      } else if (columnIndex === 1) {
        if (this.theadTwoText[rowIndex]) {
          return { rowspan: 1, colspan: 1 };
        } else {
          return [0, 0];
        }
      }
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/specifyForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          this.tableData = data;
          console.log(data);
          this.drawTeacher();
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  computed: {
    computedRange() {
      if (this.selectRange === "1") {
        return [
          { label: "正高级", value: "2" },
          { label: "副高级", value: "3" },
          { label: "中级", value: "4" }
        ];
      } else if (this.selectRange === "2") {
        return [
          { label: "博士导师", value: "5" },
          { label: "硕士导师", value: "7" },
          { label: "博士、硕士导师", value: "9" }
        ];
      } else {
        return [];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.slot-top {
  height: 350px;
  box-sizing: border-box;
  padding: 20px;
  font-size: 14px;
  border-top: 1px solid #ddd;
  .left {
    flex: 1;
    display: flex;
    flex-wrap: wrap;
    ul {
      height: 260px;
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
    }
    .label {
      flex: 1;
      height: 100%;
      // overflow: auto;
      padding-right: 30px;
      padding-left: 40px;
      margin-right: 10px;
      .label-item {
        line-height: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        & > div {
          flex: 3;
        }
      }
      .dot {
        display: inline-block;
        margin-bottom: 2px;
        margin-right: 10px;
        width: 5px;
        height: 5px;
        border-radius: 50%;
      }
    }
  }
}
</style>
