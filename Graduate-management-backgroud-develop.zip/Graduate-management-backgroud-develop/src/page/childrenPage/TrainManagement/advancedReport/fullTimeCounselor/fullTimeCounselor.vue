<template>
  <div class="fullTimeCounselor">
    <common-table-bg :title="title" @input="inputTable">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        :span-method="oneSpanMethod"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span v-if="theadOneText[scope.$index]">{{
              theadOneText[scope.$index].label
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadTwoText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="0" label="合计"></el-table-column>
        <el-table-column prop="1" label="其中：女"></el-table-column>
        <el-table-column label="本专科生专职辅导员">
          <el-table-column prop="2" label="19岁及 以下"></el-table-column>
          <el-table-column prop="3" label="20-29岁"></el-table-column>
          <el-table-column prop="4" label="30-39岁"></el-table-column>
          <el-table-column prop="5" label="40-49岁"></el-table-column>
          <el-table-column prop="6" label="50岁 以上"></el-table-column>
        </el-table-column>
        <el-table-column label="研究生专职辅导员">
          <el-table-column prop="7" label="19岁及 以下"></el-table-column>
          <el-table-column prop="8" label="20-29岁"></el-table-column>
          <el-table-column prop="9" label="30-39岁"></el-table-column>
          <el-table-column prop="10" label="40-49岁"></el-table-column>
          <el-table-column prop="11" label="50岁 以上"></el-table-column>
        </el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
export default {
  name: "fullTimeCounselor",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "专职辅导员分年龄、专业技术职务、学历情况",
      tableData: [],
      theadOneText: {
        0: { label: "总计", value: 1 },
        1: { label: "其中：女", value: 1 },
        2: { label: "按行政职务分", value: 4 },
        6: { label: "按行政职务分", value: 5 },
        11: { label: "按指导关系分", value: 4 }
      },
      theadTwoText: {
        2: "正处级",
        3: "副处级",
        4: "正科级",
        5: "副科级及以下",
        6: "正高级",
        7: "副高级",
        8: "中级",
        9: "初级",
        10: "未定职级",
        11: "博士研究生",
        12: "硕士研究生",
        13: "本科",
        14: "专科及以下"
      },
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 200;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 200;
      })();
    };
    // this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
    },
    oneSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        if (rowIndex === 0 || rowIndex === 1) {
          return {
            rowspan: 1,
            colspan: 2
          };
        } else if (this.theadOneText[rowIndex]) {
          return { rowspan: this.theadOneText[rowIndex].value, colspan: 1 };
        } else {
          return [0, 0];
        }
      } else if (columnIndex === 1) {
        if (this.theadTwoText[rowIndex]) {
          return { rowspan: 1, colspan: 1 };
        } else {
          return [0, 0];
        }
      }
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/ageForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          this.tableData = data;
          console.log(data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
