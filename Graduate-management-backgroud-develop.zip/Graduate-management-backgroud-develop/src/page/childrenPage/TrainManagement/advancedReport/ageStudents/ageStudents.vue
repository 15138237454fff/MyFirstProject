<template>
  <div class="ageStudents">
    <common-table-bg :title="title" @input="inputTable">
      <div slot="top" class="slot-top">
        <div class="left">
          <div>
            <el-select v-model="selectType" @change="drawNlqk">
              <el-option label="硕士研究生" value="2"></el-option>
              <el-option label="博士研究生" value="4"></el-option>
            </el-select>
            <div ref="nlqk" style="height:200px;width:200px"></div>
          </div>
          <div class="label">
            <ul>
              <li
                v-for="(item, index) of color"
                :key="index"
                class="label-item"
              >
                <div style="flex:1">
                  <span :style="{ background: item }" class="dot"></span>
                </div>
                <div
                  style="width:100px;border-right:1px solid #ddd;margin:10px 10px 10px 0;"
                >
                  {{ titleList[index] }}
                </div>
                <template v-if="tableData[selectType]">
                  <div
                    v-if="tableData[selectType][0] !== 0"
                    style="color:#409dff"
                  >
                    {{
                      (
                        (tableData[selectType][index + 1] /
                          tableData[selectType][0]) *
                        100
                      ).toFixed(0)
                    }}%
                  </div>
                  <div style="color:#ccc">
                    {{ tableData[selectType][index + 1] }}
                  </div>
                  <div style="display:flex;align-items:center;">
                    <img src="@/assets/femail.png" style="height:30px;" />
                    <span>{{
                      tableData[parseInt(selectType) + 1][index + 1]
                    }}</span>
                  </div>
                  <div style="display:flex;align-items:center;">
                    <img src="@/assets/mail.png" style="height:30px;" />
                    <span style="line-height:30px;">{{
                      tableData[selectType][index + 1] -
                        tableData[parseInt(selectType) + 1][index + 1]
                    }}</span>
                  </div>
                </template>
              </li>
            </ul>
          </div>
        </div>
        <div class="right">
          <span>总男女比例：</span>
          <div v-if="Array.isArray(tableData[1])">
            <img src="@/assets/mail.png" alt="" />
            <span>女：{{ tableData[1][0] }}</span>
            <img src="@/assets/femail.png" alt="" />
            <span v-if="!isNaN(tableData[0][0] - tableData[1][0])"
              >男：{{ tableData[0][0] - tableData[1][0] }}</span
            >
          </div>
        </div>
      </div>
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="0" label="合计"></el-table-column>
        <el-table-column prop="1" label="17岁及以下"></el-table-column>
        <el-table-column prop="2" label="18岁"></el-table-column>
        <el-table-column prop="3" label="19岁"></el-table-column>
        <el-table-column prop="4" label="20岁"></el-table-column>
        <el-table-column prop="5" label="21岁"></el-table-column>
        <el-table-column prop="6" label="22岁"></el-table-column>
        <el-table-column prop="7" label="23岁"></el-table-column>
        <el-table-column prop="8" label="24岁"></el-table-column>
        <el-table-column prop="9" label="25岁"></el-table-column>
        <el-table-column prop="10" label="26岁"></el-table-column>
        <el-table-column prop="11" label="27岁"></el-table-column>
        <el-table-column prop="12" label="28岁"></el-table-column>
        <el-table-column prop="13" label="29岁"></el-table-column>
        <el-table-column prop="14" label="30岁"></el-table-column>
        <el-table-column prop="15" label="31岁及以上"></el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
let echarts = require("echarts");
export default {
  name: "ageStudents",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "在校生分年龄情况",
      tableData: [],
      selectType: "2",
      color: [
        "#ccccff",
        "#78bfff",
        "#005097",
        "#6699ff",
        "#6cf",
        "#fcc",
        "#fc9",
        "#9c6",
        "#ffb13e",
        "#007bea",
        "#6666ff",
        "#7777ff",
        "#8888aa",
        "#9999ff",
        "#aabbcc"
      ],
      titleList: [
        "17岁及以下",
        "18岁",
        "19岁",
        "20岁",
        "21岁",
        "22岁",
        "23岁",
        "24岁",
        "25岁",
        "26岁",
        "27岁",
        "28岁",
        "29岁",
        "30岁",
        "31岁及以上"
      ],
      theadText: [
        "总计",
        "其中：女",
        // "普通专科生",
        // "其中：女",
        // "普通本科生",
        // "其中：女",
        // "成人专科生",
        // "其中：女",
        // "成人本科生",
        // "其中：女",
        // "网络专科生",
        // "其中：女",
        // "网络本科生",
        // "其中：女",
        "硕士研究生",
        "其中：女",
        "博士研究生",
        "其中：女"
      ],
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 612;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 612;
      })();
    };
    this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
      location.href = "/api/cultivate/form/ageFormExport";
    },
    // 培养方式
    drawNlqk() {
      let myChart = echarts.init(this.$refs.nlqk);
      let data = this.tableData[this.selectType].slice(1).map((el, index) => {
        return {
          value: el,
          name: this.titleList[index]
        };
      });
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c} ({d}%)"
        },
        color: this.color,
        series: [
          {
            name: "年龄情况统计",
            type: "pie",
            center: ["50%", "50%"],
            radius: ["60%", "80%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: false,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/ageForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          data = data.filter(el => {
            return el.some(el => el !== null);
          });

          this.tableData = data;
          this.drawNlqk();
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  computed: {
    selectTotal() {
      return this.tableData[this.selectType].reduce((prev, el) => {
        return prev + el;
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.slot-top {
  height: 280px;
  box-sizing: border-box;
  padding: 20px 30px;
  font-size: 14px;
  border-top: 1px solid #ddd;
  display: flex;

  .left {
    flex: 1;
    display: flex;
    .label {
      flex: 1;
      height: 100%;
      overflow: auto;
      padding-right: 30px;
      padding-left: 40px;
      margin-right: 10px;
      .label-item {
        line-height: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        & > div {
          flex: 3;
        }
      }
      .dot {
        display: inline-block;
        margin-bottom: 2px;
        margin-right: 10px;
        width: 5px;
        height: 5px;
        border-radius: 50%;
      }
    }
  }
  .right {
    & > span {
      font-weight: bold;
      display: block;
      margin-bottom: 50px;
    }
    & > div {
      display: flex;
      align-items: center;
      img {
        height: 100px;
      }
    }
  }
}
</style>
