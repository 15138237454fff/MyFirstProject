<template>
  <div class="changeStudents">
    <common-table-bg :title="title" @input="inputTable">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="0"
          label="上学年初报表在校生数"
        ></el-table-column>
        <el-table-column label="增加学生数">
          <el-table-column prop="1" label="合计"></el-table-column>
          <el-table-column prop="2" label="招生"></el-table-column>
          <el-table-column prop="3" label="复学"></el-table-column>
          <el-table-column prop="4" label="转入"></el-table-column>
          <el-table-column prop="5" label="其他"></el-table-column
        ></el-table-column>
        <el-table-column label="减少学生数">
          <el-table-column prop="6" label="合计"></el-table-column>
          <el-table-column prop="7" label="毕业"></el-table-column>
          <el-table-column prop="8" label="结业"></el-table-column>
          <el-table-column prop="9" label="休学"></el-table-column>
          <el-table-column prop="10" label="退学"></el-table-column>
          <el-table-column prop="11" label="开除"></el-table-column>
          <el-table-column prop="12" label="死亡"></el-table-column>
          <el-table-column prop="13" label="转出"></el-table-column>
          <el-table-column prop="14" label="其他"></el-table-column>
        </el-table-column>
        <el-table-column
          prop="15"
          label="本学年初报表在校生数"
        ></el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
export default {
  name: "changeStudents",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "学生变动情况",
      tableData: [],
      theadText: [
        "总计",
        "普通本科、专科生",
        "普通专科生",
        "普通本科生",
        "成人本科、专科生",
        "成人专科生",
        "成人本科生",
        "网络本科、专科生",
        "网络专科生",
        "网络本科生",
        "研究生",
        "硕士研究生",
        "博士研究生"
      ],
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 200;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 200;
      })();
    };
    // this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/ageForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          this.tableData = data;
          console.log(data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
