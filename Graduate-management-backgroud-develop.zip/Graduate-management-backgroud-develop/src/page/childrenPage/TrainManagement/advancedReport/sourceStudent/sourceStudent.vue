<template>
  <div class="sourceStudent">
    <common-table-bg :title="title" @input="inputTable">
      <div slot="top" class="slot-top">
        <div ref="source" style="height:380px;width:1000px"></div>
      </div>
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <!-- <el-table-column label="招生数">
          <el-table-column prop="date" label="合计"></el-table-column>
          <el-table-column prop="date" label="普通专科生"></el-table-column>
          <el-table-column prop="date" label="普通本科生"></el-table-column>
        </el-table-column> -->
        <el-table-column label="招生数">
          <el-table-column prop="stuCount" label="合计"></el-table-column>
          <!-- <el-table-column prop="date" label="普通专科生"></el-table-column>
          <el-table-column prop="date" label="普通本科生"></el-table-column>
          <el-table-column prop="date" label="成人专科生"></el-table-column>
          <el-table-column prop="date" label="成人本科生"></el-table-column>
          <el-table-column prop="date" label="网络专科生"></el-table-column>
          <el-table-column prop="date" label="网络本科生"></el-table-column> -->
          <el-table-column
            prop="masterCount"
            label="硕士研究生"
          ></el-table-column>
          <el-table-column prop="phdCount" label="博士研究生"></el-table-column>
        </el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
import chinaData from "../../../../../../static/china.json";
let echarts = require("echarts");
export default {
  name: "sourceStudent",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "招生、在校生来源情况",
      tableData: [],
      theadText: [],
      tableHeight: null,
      loading: false
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 612;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 612;
      })();
    };
    this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
      location.href = "/api/cultivate/form/areaFormExport";
    },
    drawSource() {
      echarts.registerMap("china", chinaData);
      let myChart = echarts.init(this.$refs.source);
      let showData = this.tableData.slice(1);
      const option = {
        tooltip: {
          trigger: "item",
          formatter: params => {
            if (!params.data) {
              return "";
            }
            return `<span style="margin-right:50px;font-size:18px;">${
              params.name
            }</span> ${(
              (params.value / this.tableData[0].stuCount) *
              100
            ).toFixed(
              0
            )}%<hr /><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#409dff;margin-right:5px;"></span>硕士研究生：${
              params.data.masterCount
            }<br /><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#FF9A32;margin-right:5px;"></span>博士研究生：${
              params.data.phdCount
            }`;
          },
          extraCssText: "box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);",
          backgroundColor: "#fff",
          padding: 20,
          textStyle: {
            color: "#333",
            fontSize: 14
          }
        },
        visualMap: {
          min: Math.min(
            ...showData.map(el => {
              return el.stuCount;
            })
          ),
          max: Math.max(
            ...showData.map(el => {
              return el.stuCount;
            })
          ),
          text: ["高", "低"],
          realtime: false,
          calculable: true,
          inRange: {
            color: ["lightskyblue", "yellow", "orangered"]
          }
        },
        series: [
          {
            type: "map",
            map: "china",
            zoom: 1.7,
            top: "30%",
            label: {
              fontSize: 12,
              color: "#333",
              formatter: params => {
                return params.name.replace(
                  /省|市|自治区|回族|维吾尔|特别行政区|壮族/g,
                  ""
                );
              },
              show: true
            },
            data: showData.map(el => {
              return {
                name: el.areaName,
                value: el.stuCount,
                phdCount: el.phdCount,
                masterCount: el.masterCount
              };
            }),
            itemStyle: {
              normal: {
                borderColor: "rgba(0, 0, 0, 0.2)"
              },
              emphasis: {
                areaColor: "#F3B329", // 鼠标选择区域颜色
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 10,
                borderWidth: 0,
                shadowColor: "rgba(0, 0, 0, 0.5)"
              }
            },
            nameMap: {
              上海市: "上海",
              云南省: "云南",
              内蒙古自治区: "内蒙古",
              北京市: "北京",
              台湾省: "台湾",
              吉林省: "吉林",
              四川省: "四川",
              天津市: "天津",
              宁夏回族自治区: "宁夏",
              安徽省: "安徽",
              山东省: "山东",
              山西省: "山西",
              广东省: "广东",
              广西壮族自治区: "广西",
              新疆维吾尔自治区: "新疆",
              江苏省: "江苏",
              江西省: "江西",
              河北省: "河北",
              河南省: "河南",
              浙江省: "浙江",
              海南省: "海南",
              湖北省: "湖北",
              湖南省: "湖南",
              澳门特别行政区: "澳门",
              甘肃省: "甘肃",
              福建省: "福建",
              西藏自治区: "西藏",
              贵州省: "贵州",
              辽宁省: "辽宁",
              重庆市: "重庆",
              陕西省: "陕西",
              青海省: "青海",
              香港特别行政区: "香港",
              黑龙江省: "黑龙江"
            }
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/areaForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          let index = data.findIndex(el => el.areaName === "总计");
          data = this.$displace(index, 0, data);
          this.theadText = data.map(el => el.areaName);
          this.tableData = data;
          this.drawSource();
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.slot-top {
  height: 400px;
  box-sizing: border-box;
  // padding: 20px;
  font-size: 14px;
  border-top: 1px solid #ddd;
}
</style>
