<template>
  <div class="otherStudents">
    <common-table-bg :title="title" @input="inputTable">
      <div slot="top" class="slot-top">
        <div class="left">
          <div ref="other" style="height:300px;width:300px"></div>
          <div class="label">
            <ul>
              <li
                v-for="(item, index) of color"
                :key="index"
                class="label-item"
              >
                <div style="flex:1">
                  <span :style="{ background: item }" class="dot"></span>
                </div>
                <div
                  style="width:100px;border-right:1px solid #ddd;margin:10px 10px 10px 0;"
                >
                  {{ titleList[index] }}
                </div>
                <template v-if="tableData[selectType]">
                  <div v-if="total !== 0" style="color:#409dff">
                    {{
                      ((tableData[selectType][index] / total) * 100).toFixed(0)
                    }}%
                  </div>
                  <div style="color:#ccc">
                    {{ tableData[selectType][index] }}
                  </div>
                </template>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="0" label="共产党员"></el-table-column>
        <el-table-column prop="1" label="共青团员"></el-table-column>
        <el-table-column prop="2" label="民主党派"></el-table-column>
        <el-table-column prop="3" label="香港"></el-table-column>
        <el-table-column prop="4" label="澳门"></el-table-column>
        <el-table-column prop="5" label="台湾"></el-table-column>
        <el-table-column prop="6" label="华侨"></el-table-column>
        <el-table-column prop="7" label="少数民族"></el-table-column>
        <el-table-column prop="8" label="残疾人"></el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
let echarts = require("echarts");
export default {
  name: "otherStudents",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "在校生中其他情况",
      tableData: [],
      selectType: 0,
      color: [
        "#ccccff",
        "#78bfff",
        "#005097",
        "#6699ff",
        "#6cf",
        "#fcc",
        "#fc9",
        "#9c6",
        "#ffb13e"
      ],
      titleList: [
        "共产党员",
        "共青团员",
        "民主党派",
        "香港",
        "澳门",
        "台湾",
        "华侨",
        "少数民族",
        "残疾人"
      ],
      theadText: [
        // "总计",
        // "普通本科、专科生",
        // "普通专科生",
        // "普通本科生",
        // "成人本科、专科生",
        // "成人专科生",
        // "成人本科生",
        // "网络本科、专科生",
        // "网络专科生",
        // "网络本科生",
        "总计",
        "硕士研究生",
        "博士研究生"
      ],
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 760;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 760;
      })();
    };
    this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
      location.href = "/api/cultivate/form/otherFormExport";
    },
    // 培养方式
    drawOther() {
      let myChart = echarts.init(this.$refs.other);
      let data = this.tableData[this.selectType].map((el, index) => {
        return {
          value: el,
          name: this.titleList[index]
        };
      });
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c} ({d}%)"
        },
        color: this.color,
        series: [
          {
            name: this.titleList,
            type: "pie",
            center: ["50%", "45%"],
            radius: ["60%", "80%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: false,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/otherForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          data = data.filter(el => {
            return el.some(el => el !== null);
          });
          this.tableData = data;
          this.drawOther();
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  computed: {
    total() {
      return this.tableData[this.selectType].reduce((prev, el) => {
        return prev + el;
      }, 0);
    }
  }
};
</script>
<style lang="scss" scoped>
.slot-top {
  height: 300px;
  box-sizing: border-box;
  padding: 20px;
  font-size: 14px;
  border-top: 1px solid #ddd;
  .left {
    flex: 1;
    display: flex;
    flex-wrap: wrap;
    ul {
      height: 260px;
      display: flex;
      flex-direction: column;
      flex-wrap: wrap;
    }
    .label {
      flex: 1;
      height: 100%;
      // overflow: auto;
      padding-right: 30px;
      padding-left: 40px;
      margin-right: 10px;
      .label-item {
        line-height: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        & > div {
          flex: 3;
        }
      }
      .dot {
        display: inline-block;
        margin-bottom: 2px;
        margin-right: 10px;
        width: 5px;
        height: 5px;
        border-radius: 50%;
      }
    }
  }
}
</style>
