<template>
  <div class="masterNumber">
    <common-table-bg :title="title" @input="inputTable">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="0" label="学科"> </el-table-column>
        <el-table-column prop="1" label="专业分类"> </el-table-column>
        <el-table-column prop="2" label="专业名称"> </el-table-column>
        <el-table-column prop="3" label="自主专业名称"> </el-table-column>
        <el-table-column prop="4" label="专业代码"> </el-table-column>
        <el-table-column prop="5" label="招生计划类型代码"> </el-table-column>
        <el-table-column prop="6" label="年制"> </el-table-column>
        <el-table-column prop="7" label="毕业生数"> </el-table-column>
        <el-table-column prop="8" label="授予学位数"> </el-table-column>
        <el-table-column label="招生数">
          <el-table-column prop="9" label="总计"> </el-table-column>
          <el-table-column prop="10" label="其中应届毕业生"></el-table-column>
        </el-table-column>
        <el-table-column label="在校生数">
          <el-table-column prop="11" label="合计"></el-table-column>
          <el-table-column prop="12" label="一年级"></el-table-column>
          <el-table-column prop="13" label="二年级"></el-table-column>
          <el-table-column prop="14" label="三年级"></el-table-column>
          <el-table-column prop="15" label="四年级"></el-table-column>
          <el-table-column prop="16" label="五年级及以上"></el-table-column>
        </el-table-column>
        <el-table-column prop="17" label="预计毕业生数"> </el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
export default {
  name: "masterNumber",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "硕士研究生分专业（领域）学生数",
      tableData: [],
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 200;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 200;
      })();
    };
    // this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/ageForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          this.tableData = data;
          console.log(data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
