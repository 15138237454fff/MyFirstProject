<template>
  <div class="leaveReson">
    <common-table-bg :title="title" @input="inputTable">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
      >
        <el-table-column prop="date" label="" class-name="thead-bg">
          <template slot-scope="scope">
            <span>{{ theadText[scope.$index] }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="0" label="合计"></el-table-column>
        <el-table-column prop="1" label="患病"></el-table-column>
        <el-table-column prop="2" label="停学实践（求职）"></el-table-column>
        <el-table-column prop="3" label="贫困"></el-table-column>
        <el-table-column prop="4" label="学习成绩不好"></el-table-column>
        <el-table-column prop="5" label="出国"></el-table-column>
        <el-table-column prop="6" label="其他"></el-table-column>
      </el-table>
    </common-table-bg>
  </div>
</template>
<script>
import commonTableBG from "@/components/advancedReport/commonTableBG.vue";
export default {
  name: "leaveReson",
  components: {
    "common-table-bg": commonTableBG
  },
  data() {
    return {
      title: "学生休退学的主要原因",
      tableData: [],
      theadText: [
        "总计",
        "普通本科、专科生",
        "普通专科生",
        "普通本科生",
        "成人本科、专科生",
        "成人专科生",
        "成人本科生",
        "网络本科、专科生",
        "网络专科生",
        "网络本科生",
        "研究生",
        "硕士研究生",
        "博士研究生"
      ],
      loading: false,
      tableHeight: null
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 200;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 200;
      })();
    };
    // this.loadTable();
  },
  methods: {
    inputTable() {
      console.log("全表导出");
    },
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/form/ageForm")
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          this.tableData = data;
          console.log(data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
