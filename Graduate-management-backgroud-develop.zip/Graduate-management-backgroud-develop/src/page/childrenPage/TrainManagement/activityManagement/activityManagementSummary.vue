<template>
  <div class="activityManagementSummary">
    <div class="my-header">
      <div class="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div class="center">
        {{ formData.hdmc }} ({{ $tagTime(formData.tpkssj, "yyyy-MM-dd 至") }}
        {{ $tagTime(formData.tpjssj, "yyyy-MM-dd") }})
      </div>
      <div class="right">
        <span class="blue">投票人数：{{ formData.tprs }}人</span>
      </div>
    </div>
    <div class="detail-content">
      <div
        class="detail-card"
        v-for="(item, index) of formData.queationVOS"
        :key="index"
      >
        <div class="detail-title">
          <span>{{ index + 1 }}. {{ item.tmmc }}</span>
        </div>
        <div class="detail-msg" v-for="(obj, ind) of item.voteList" :key="ind">
          <span>{{ obj.num }}. {{ obj.content }}</span>
          <div>
            <el-progress
              v-if="formData.tprs"
              :percentage="(obj.count / formData.tprs) * 100"
              :format="format"
            ></el-progress>
            <el-progress v-else :percentage="0" :format="format"></el-progress>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "activityManagementSummary",
  props: {
    id: {}
  },
  data() {
    return {
      formData: {
        hdmc: "",
        tpjssj: "",
        tpkssj: "",
        queationVOS: [],
        tprs: 0
      }
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    goBack() {
      this.$router.push(`/activityManagement`);
    },
    dataCallBack() {
      this.$http
        .get(`/api/cultivate/stuAct/voteSummary/${this.id}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.formData = data.data;
        })
        .catch(err => {
          console.log(err.message);
        });
    },
    format(percentage) {
      return `${percentage}%`;
    }
  }
};
</script>
<style lang="scss" scoped>
.activityManagementSummary {
  padding-top: 10px;
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
  .my-header {
    height: 40px;
    line-height: 40px;
    margin-bottom: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 14px;
    & > div {
      flex: 1;
    }
    .center {
      font-size: 18px;
    }
    .right {
      text-align: right;
    }
    .el-button--text {
      color: #409eff;
      background: 0 0;
      padding-left: 0;
      padding-right: 0;
    }
  }
  .detail-content {
    border-top: 1px solid rgba(228, 228, 228, 1);
    .detail-card {
      &:not(:last-child) {
        border-bottom: 2px dashed rgba(228, 228, 228, 1);
      }
      padding: 10px;
      font-size: 14px;
      .detail-title {
        line-height: 50px;
      }
      .detail-msg {
        line-height: 30px;
        display: flex;
        & > span {
          width: 300px;
        }
        & > div {
          width: 600px;
          line-height: 30px;
          margin-left: 30px;
        }
        .el-progress {
          line-height: 30px;
        }
      }
    }
  }
}
</style>
