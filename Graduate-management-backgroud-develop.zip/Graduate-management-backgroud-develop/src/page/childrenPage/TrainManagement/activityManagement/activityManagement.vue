<template>
  <div class="activityManagement">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入工号/姓名"
          suffix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.xmmc"
          @keyup.enter.native="initLoadTable"
          style="width:200px;"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-date-picker
          v-model="computedTime"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          @change="initLoadTable"
        >
        </el-date-picker>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('activityManagement:add')"
          >添加</el-button
        >
        <el-button
          @click="clickDelete"
          type="danger"
          v-if="$btnAuthorityTest('activityManagement:delete')"
          >删除</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="selection"
          align="center"
          :width="50"
        ></el-table-column>
        <el-table-column prop="hdmc" label="活动名称" align="center">
        </el-table-column>
        <el-table-column
          prop="fbdx"
          label="投票时间"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.tpkssj, "yyyy.MM.dd") }}</span>
            <span class="grey">&nbsp;至&nbsp;</span>
            <span>{{ $tagTime(scope.row.tpjssj, "yyyy.MM.dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="pjdja"
          label="投票汇总"
          align="center"
          :width="150"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              v-if="$btnAuthorityTest('activityManagement:view')"
              @click="clickSummary(scope.row.id)"
              >投票汇总</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "activityManagement",
  data() {
    return {
      tableData: [{}],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        tpkssj: "",
        tpjssj: ""
      },
      loading: false,
      selectedHistoryList: [],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-modal": myModal
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/cultivate/stuAct/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击添加
    clickAdd() {
      this.$router.push(`/activityManagementAdd`);
    },
    // 点击删除
    clickDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleDelete,
        title: "删除信息",
        msgOne: "确定删除已选记录？",
        msgTwo: ""
      });
    },
    // 处理删除
    handleDelete() {
      console.log("处理删除");
      let ids = this.selectedHistoryList.map(el => el.id);
      this.$http
        .delete("/api/cultivate/stuAct/delete", { data: ids })
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("删除成功");
          this.initLoadTable();
        })
        .catch(err => {
          console.log(err.message);
        });
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    clickSummary(id) {
      this.$router.push(`/activityManagementSummary/${id}`);
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val;
    }
  },
  computed: {
    computedTime: {
      get() {
        return [this.limitQuery.tpkssj, this.limitQuery.tpjssj];
      },
      set(arr) {
        if (arr === null) {
          arr = ["", ""];
        }
        this.limitQuery.tpkssj = arr[0];
        this.limitQuery.tpjssj = arr[1];
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.activityManagement {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
  .el-date-editor .el-range-separator {
    line-height: 26px;
  }
}
</style>
