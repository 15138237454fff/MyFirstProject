<template>
  <div class="activityManagementAdd">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right">
        <el-button @click="clickPublish" type="primary">发布</el-button>
      </div>
    </my-breadcrumb>
    <div class="add-content">
      <div class="row">
        <div>
          <span class="required">活动名称：</span>
          <el-input
            v-model="formData.hdmc"
            placeholder="请输入"
            :maxlength="50"
          ></el-input>
        </div>
        <div>
          <span class="required">投票时间：</span>
          <el-date-picker
            v-model="computedTime"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
          >
          </el-date-picker>
        </div>
      </div>
      <div class="box">
        <div class="title">
          <span class="required">投票题目</span>
        </div>
        <div class="question-list">
          <div
            class="question-card"
            v-for="(item, index) of formData.voteInfoDTOS"
            :key="index"
          >
            <div class="card-title">
              <div class="question-name">
                <span>{{ `${index + 1}. 投票题目名称：` }}</span>
                <el-input
                  v-model="item.tmmc"
                  placeholder="请输入"
                  :maxlength="50"
                ></el-input>
              </div>
              <div>
                <el-radio-group v-model="item.xxlx">
                  <el-radio-button :label="1">单选</el-radio-button>
                  <el-radio-button :label="2">多选</el-radio-button>
                </el-radio-group>
                <el-button
                  type="danger"
                  plain
                  @click="clickReduce(index)"
                  v-if="index !== 0"
                  >删除题目</el-button
                >
                <el-button type="primary" plain @click="clickAdd" v-else
                  >添加题目</el-button
                >
              </div>
            </div>
            <table class="card-contain">
              <thead>
                <tr>
                  <th width="80px">选项</th>
                  <th>选项内容</th>
                  <th width="80px">操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(obj, ind) of item.xxnr" :key="ind">
                  <td>
                    <span>{{ obj.num }}</span>
                  </td>
                  <td>
                    <el-input
                      v-model="obj.content"
                      placeholder="请输入"
                      :maxlength="50"
                    ></el-input>
                  </td>
                  <td>
                    <reduce-btn
                      @click.native="clickReduceRow(index, ind)"
                      v-if="ind !== 0"
                    ></reduce-btn>
                    <add-btn
                      @click.native="clickAddRow(index)"
                      v-else
                    ></add-btn>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import addBtn from "@/components/skb/addBtn";
import reduceBtn from "@/components/skb/reduceBtn";
export default {
  name: "activityManagementAdd",
  components: {
    "my-breadcrumb": myBreadcrumb,
    "reduce-btn": reduceBtn,
    "add-btn": addBtn
  },
  data() {
    return {
      formData: {
        hdmc: "",
        tpjssj: "",
        tpkssj: "",
        voteInfoDTOS: [
          {
            tmmc: "",
            xxlx: 1,
            xxnr: [
              {
                content: "",
                num: "A"
              },
              {
                content: "",
                num: "B"
              },
              {
                content: "",
                num: "C"
              },
              {
                content: "",
                num: "D"
              }
            ]
          }
        ]
      },
      numOptions: ["A", "B", "C", "D", "E", "F"]
    };
  },
  methods: {
    goBack() {
      this.$router.push(`/activityManagement`);
    },
    clickPublish() {
      console.log("发布");
      let result = this.testFormData();
      if (!result.sign) {
        this.$message.error(result.msg);
        return;
      }
      this.handlePublish();
    },
    handlePublish() {
      console.log("处理发布");
      const loading = this.$loading({
        lock: true,
        text: "发布中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/cultivate/stuAct/save", this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("发布成功");
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    testFormData() {
      let sign = true,
        msg = "",
        testKeys = ["hdmc", "tpjssj", "tpkssj"],
        tmpForm = this.formData;
      testKeys.forEach(key => {
        if (tmpForm[key] === "") {
          sign = false;
          msg = "请填写完整后再尝试提交";
        }
      });
      tmpForm.voteInfoDTOS.forEach(item => {
        if (!sign) {
          return;
        }
        if (item.tmmc === "") {
          sign = false;
          msg = "请填写题目名称";
          return;
        }
        if (item.xxlx === "") {
          sign = false;
          msg = "请选择题目类型";
          return;
        }
        item.xxnr.forEach(el => {
          if (el.content === "") {
            sign = false;
            msg = "请填写选项内容";
          }
        });
      });
      return { sign, msg };
    },
    clickAdd() {
      this.formData.voteInfoDTOS.push({
        tmmc: "",
        xxlx: 1,
        xxnr: [
          {
            content: "",
            num: "A"
          },
          {
            content: "",
            num: "B"
          },
          {
            content: "",
            num: "C"
          },
          {
            content: "",
            num: "D"
          }
        ]
      });
    },
    clickReduce(index) {
      if (this.formData.voteInfoDTOS.length <= 1) {
        this.$message.error("至少保留一条题目信息");
        return;
      }
      this.formData.voteInfoDTOS = this.$deleteIndexOfArray(
        index,
        this.formData.voteInfoDTOS
      );
    },
    clickAddRow(index) {
      let tmpObj = this.formData.voteInfoDTOS[index];
      if (tmpObj.xxnr.length >= 6) {
        this.$message.error("最多只能有六个选项");
        return;
      }
      tmpObj.xxnr.push({
        content: "",
        num: ""
      });
      tmpObj.xxnr.forEach((el, index) => {
        el.num = this.numOptions[index];
      });
    },
    clickReduceRow(index, ind) {
      let tmpObj = this.formData.voteInfoDTOS[index];
      if (!tmpObj) {
        console.log("找不到目标行");
        return;
      }
      if (tmpObj.xxnr.length <= 2) {
        this.$message.error("至少保留两个选项");
        return;
      }
      tmpObj.xxnr = this.$deleteIndexOfArray(ind, tmpObj.xxnr);
      tmpObj.xxnr.forEach((el, index) => {
        el.num = this.numOptions[index];
      });
    }
  },
  computed: {
    computedTime: {
      get() {
        return [this.formData.tpkssj, this.formData.tpjssj];
      },
      set(arr) {
        if (arr === null) {
          arr = ["", ""];
        }
        this.formData.tpkssj = arr[0];
        this.formData.tpjssj = arr[1];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.activityManagementAdd {
  padding-top: 10px;
  font-size: 14px;
  .add-content {
    border-top: 1px solid rgba(228, 228, 228, 1);
    padding: 10px;
    height: calc(100vh - 206px);
    overflow: auto;
    position: relative;
  }
  .row {
    display: flex;
    justify-content: space-between;
    & > div {
      flex: 1;
      &:last-child {
        justify-content: flex-end;
      }
      display: flex;
      & > span:first-child {
        width: 100px;
        line-height: 34px;
        text-align: right;
      }
      .el-date-editor,
      .el-input {
        width: 80%;
      }
      /deep/ .el-date-editor .el-range-separator {
        line-height: 26px;
      }
    }
  }
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    margin-top: 10px;
    .title {
      height: 40px;
      line-height: 40px;
      padding-left: 10px;
      border-bottom: 1px solid rgba(228, 228, 228, 1);
    }
    .question-list {
      padding: 10px;

      .question-card {
        padding: 10px 0 10px;
        &:not(:last-child) {
          border-bottom: 2px dashed rgba(228, 228, 228, 1);
        }
        .card-title {
          display: flex;
          justify-content: space-between;
          height: 40px;
          line-height: 40px;
          /deep/ .el-radio-button__inner {
            padding: 9px 20px;
          }
          .el-radio-group {
            margin-right: 5px;
          }
          .question-name {
            flex: 1;
            & > span {
              display: inline-block;
              width: 120px;
            }
            .el-input {
              display: inline-block;
              width: 60vw;
            }
          }
        }
        .card-contain {
          width: 100%;
          margin-top: 10px;
          td,
          th {
            height: 40px;
            line-height: 40px;
            border: 1px solid #ddd;
            text-align: center;
          }
          thead th {
            background: rgb(242, 242, 242);
          }
        }
      }
    }
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
