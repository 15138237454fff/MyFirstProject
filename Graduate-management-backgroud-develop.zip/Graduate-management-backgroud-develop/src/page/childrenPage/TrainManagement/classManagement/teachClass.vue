<!-- 教师调课审核 -->
<template>
  <div class="teachClass">
    <div class="container" v-if="this.$store.state.train == false">
      <el-tabs v-model="activeName" @tab-click="tabChangeClick" v-if="$store.state.traindetails == false" class="top-nav">
        <el-tab-pane label="待审核" name="first">
          <componment>
            <div slot="left">
              <el-input v-model="search" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind"></el-input>
              <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
              <el-select v-model="college" filterable placeholder="全部学院" style="width: 200px;">
                <el-option v-for="item in collegeList" :key="item.dwh" :label="item.dwmc" :value="item.dwh">
                </el-option>
              </el-select>
              <el-select v-model="major" filterable placeholder="全部专业" style="width: 200px;">
                <el-option v-for="item in majorList" :key="item.zyh" :label="item.zymc" :value="item.zyh">
                </el-option>
              </el-select>
              <el-select v-model="grade" filterable placeholder="全部年级" style="width: 200px;">
                <el-option v-for="item in gradeList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
                </el-option>
              </el-select>
            </div>
          </componment>
          <el-table :data="tableData1" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading" element-loading-text="加载中">
            <el-table-column type="index" label="序号" width="150">
            </el-table-column>
            <el-table-column prop="xh" label="课程号" width="150">
            </el-table-column>
            <el-table-column prop="xm" label="课程名称"> </el-table-column>
            <!-- <el-table-column prop="name" :key="Math.random()" label="任务名称">
            </el-table-column> -->
            <el-table-column prop="xslb" label="开课单位"> </el-table-column>
            <el-table-column prop="xy" label="教学班"> </el-table-column>
            <el-table-column prop="zy" label="申请人"> </el-table-column>
            <el-table-column prop="sznj" label="申请时间"> </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button type="text" @click="checkDetails(scope.row)" v-if="$btnAuthorityTest('teachClass:audit')">审核</el-button>
              </template>
            </el-table-column>
          </el-table>
          <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
        </el-tab-pane>
        <el-tab-pane label="已审核" name="second">
          <componment>
            <div slot="left">
              <el-input v-model="search2" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="handleFind2"></el-input>
              <el-button @click="handleFind2" style="margin-left:5px">查询</el-button>
              <el-select v-model="college2" filterable placeholder="全部学院" style="width: 200px;">
                <el-option v-for="item in collegeList" :key="item.dwh" :label="item.dwmc" :value="item.dwh">
                </el-option>
              </el-select>
              <el-select v-model="major2" filterable placeholder="全部专业" style="width: 200px;">
                <el-option v-for="item in majorList" :key="item.zyh" :label="item.zymc" :value="item.zyh">
                </el-option>
              </el-select>
              <el-select v-model="grade2" filterable placeholder="全部年级" style="width: 200px;">
                <el-option v-for="item in gradeList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
                </el-option>
              </el-select>
            </div>
          </componment>
          <el-table :data="tableData2" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading" element-loading-text="加载中">
            <el-table-column type="index" label="序号" width="150">
            </el-table-column>
            <el-table-column prop="xh" label="课程号" width="150">
            </el-table-column>
            <el-table-column prop="xm" label="课程名称"> </el-table-column>
            <!-- <el-table-column prop="name" :key="Math.random()" label="任务名称">
            </el-table-column> -->
            <el-table-column prop="xslb" label="开课单位"> </el-table-column>
            <el-table-column prop="xy" label="教学班"> </el-table-column>
            <el-table-column prop="zy" label="申请人"> </el-table-column>
            <el-table-column prop="sznj" label="申请时间"> </el-table-column>
            <el-table-column label="审核详情" prop="status">
              <template slot-scope="scope">
                <el-button type="text" @click="checkDetails2(scope.row)" v-if="$btnAuthorityTest('teachClass:view')">{{ scope.row.status }}</el-button>
              </template>
            </el-table-column>
          </el-table>
          <pagination :total="total2" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "teachClass",
  data() {
    return {
      tableData1: [],
      tableData2: [],
      search: "",
      search2: "",
      activeName: "first",
      college: "", // 所选学院
      college2: "",
      collegeList: [], // 所有学院列表
      major: "",
      major2: "",
      majorList: [],
      grade: "",
      grade2: "",
      gradeList: [],
      total: 1,
      total2: 1,
      tableHeight: null,
      row: {},
      status: "",
      loading: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  methods: {
    takeList(index) {
      // if(this.activeName == 'first') {
      // 	this.$http
      // 	.get("api/cultivate/activityCultivate/taskStuInfoList?definitionKeyLike=stuTrainingPlanApply&pageNum="+index+"&pageSize="+this.pagesize2+"&query="+this.search+"&type=1")
      // 	.then(res => {
      // 		this.tableData1 = res.data.data.list
      // 		this.total = res.data.data.total
      // 		this.tableData1.map((item, index) => {
      // 			item.myid = index + 1
      // 		})
      // 	})
      // 	.catch(function(err) {
      // 		console.log(err)
      // 	})
      // } else if(this.activeName == 'second') {
      // 	this.$http
      // 	.get("api/cultivate/activityCultivate/getHistoryAudit?pageNum="+index+"&pageSize="+this.pagesize+"&processKey=stuTrainingPlanApply&query="+this.search2)
      // 	.then(res => {
      // 		this.tableData2 = res.data.data.list
      // 		this.total2 = res.data.data.total
      // 		this.tableData2.map((item, index) => {
      // 			item.myid = index + 1
      // 		})
      // 		res.data.data.list.map((item, index) => {
      // 			this.tableData2[index].status = item.state == '0' ? '不通过' : item.state == '1' ? '通过' : item.state == '2' ? '退回' : ''
      // 		})
      // 	})
      // 	.catch(function(err) {
      // 		console.log(err)
      // 	})
      // }
    }, // 获取列表
    tabChangeClick(tab, event) {
      this.takeList();
    }, // 切换审核
    handleFind() {
      this.takeList();
    },
    handleFind2() {
      this.takeList();
    },
    checkDetails(row) {
      this.$store.state.train = true;
      this.row = row;
      this.status = true;
    }, // 查看详情
    checkDetails2(row) {
      this.$store.state.train = true;
      this.row = row;
      this.status = false;
    },
    getNumber() {
      this.$http.get("api/cultivate/pyfa/selectDwList").then(res => {
        if (res.data.data.length > 1) {
          this.collegeList = res.data.data;
          this.collegeList.unshift({ dwh: "", dwmc: `全部学院` });
        } else {
          this.collegeList = res.data.data;
        }
      });
    },
    getzy(val) {
      this.$http
        .get(`api/cultivate/pyfa/selectZyByDwh?dwh=${val}`)
        .then(res => {
          if (res.data.data.length > 1) {
            this.majorList = res.data.data;
            this.majorList.unshift({ zyh: "", zymc: "全部专业" });
          } else {
            this.majorList = res.data.data;
          }
        });
    },
    getnj() {
      this.$http.get(`api/cultivate/pyfa/selectNjList`).then(res => {
        if (res.data.data.length > 1) {
          this.gradeList = res.data.data;
          this.gradeList.unshift({ njKey: "", njValue: "全部年级" });
        } else {
          this.gradeList = res.data.data;
        }
      });
    }
  },
  created() {
    this.getnj();
    this.getzy(this.college);
    this.getNumber();
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 266;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 266;
      })();
    };
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.teachClass {
  .container {
    .top-nav {
      /deep/ .el-tabs__nav-wrap {
        background: #fff;
      }
      /deep/ .el-tabs__nav {
        margin-left: 15px;
      }
      /deep/ .el-tabs__item {
        width: 100px;
        text-align: center;
      }
      /deep/ .el-tabs__header {
        margin: 0 0 7px;
      }
      /deep/ .el-tabs__active-bar {
        width: 80px !important;
      }
    }
  }
}
</style>
