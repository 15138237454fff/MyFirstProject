<!-- 制定开课方案 -->
<template>
  <div class="formulate">
    <template>
      <div class="container" v-if="$store.state.manualClass == false">
        <componment>
          <div slot="left">
            <el-input v-model="searchField" placeholder="请输入课程号/名称" style="width:200px" @keyup.enter.native="searchData" clearable @clear="clearinput"></el-input>
            <el-button @click="searchData">搜索</el-button>
            <el-select v-model="major" filterable @change="selectchange">
              <el-option v-for="item in majorList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
            <el-select v-model="unit" filterable @change="selectchange">
              <el-option v-for="item in unitList" :key="item.dwh" :label="item.dwmc" :value="item.dwh">
              </el-option>
            </el-select>
            <el-select v-model="grade" filterable @change="selectchange">
              <el-option v-for="item in gradeList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
              </el-option>
            </el-select>
            <el-select v-model="pyccm" filterable @change="selectchange">
              <el-option v-for="(item, index) in pyccmList" :key="index" :label="item.name" :value="item.code">
              </el-option>
            </el-select>
          </div>
          <div slot="right">
            <el-button type="primary" @click="manualClass" plain :disabled="ishow" v-if="$btnAuthorityTest('formulate:online')">在线排课</el-button>
            <!-- <el-button type="primary" @click="scheduling">可视化排课</el-button> -->
            <el-button type="primary" @click="classTime" v-if="$btnAuthorityTest('formulate:set')">排课时间设置</el-button>
            <el-button type="primary" @click="classTimePK" v-if="$btnAuthorityTest('formulate:setxd')">排课限制设置</el-button>
          </div>
        </componment>
        <el-table :data="tableData" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
          <el-table-column prop="kch" label="课程名称" width="200px">
            <template slot-scope="scope">
              <span>{{ scope.row.kch }}{{ scope.row.kcmc }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="kkdwh" label="开课单位" width="180px" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="xknj" label="年级" width="100px">
          </el-table-column>
          <el-table-column prop="pyccm" label="培养层次" width="100px">
          </el-table-column>
          <el-table-column prop="kcxzh" label="课程性质" width="100px">
          </el-table-column>
          <el-table-column prop="bjmc" label="教学班" width="240px" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="jsxm" label="授课教师" width="180px" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="address" label="上课时间,地点" :show-overflow-tooltip="true">
            <template slot-scope="scope">
              <div>
                <div v-for="(item, index) in scope.row.pyPkkcSksjs" :key="index">
                  <span>{{ item.zc }}周</span>&nbsp;&nbsp;<span>({{ item.sfmz | sfmz }})</span>&nbsp;&nbsp;<span>星期{{ item.xq | xq }}</span>&nbsp;<span>{{ item.kj }}</span>节&nbsp;&nbsp;&nbsp;<span>{{ item.jsmc }}&nbsp;&nbsp;&nbsp;</span>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="address" label="操作" width="150px">
            <template slot-scope="scope">
              <p v-if="scope.row.click == '1'">
                <span class="tablexg" @click="modificHandle(scope.row)" v-if="$btnAuthorityTest('formulate:update')">修改</span><span v-if="
                    $btnAuthorityTest('formulate:update') &&
                      $btnAuthorityTest('formulate:delete')
                  ">
                  | </span><span @click="mydeleteHandle(scope.row)" class="tablesc" v-if="$btnAuthorityTest('formulate:delete')">删除</span>
              </p>
              <p v-if="scope.row.click == '0'" style="color:#333333">
                <span v-if="$btnAuthorityTest('formulate:update')">修改</span><span v-if="
                    $btnAuthorityTest('formulate:update') &&
                      $btnAuthorityTest('formulate:delete')
                  ">
                  | </span><span v-if="$btnAuthorityTest('formulate:delete')">删除</span>
              </p>
            </template>
          </el-table-column>
        </el-table>
        <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
        <el-dialog title="排课时间设置" :visible.sync="dialogVisible" width="600px" :before-close="handleClose">
          <el-tabs v-model="activeName" @tab-click="tabClick">
            <el-tab-pane label="周一至周五" name="first">
              <div class="table">
                <el-table :data="timeData1" border ref="timeTable1" style="width: 100%" :header-cell-style="$storage.tableHeaderColor">
                  <el-table-column prop="timeFrame" label="上午/下午/晚上" width="150">
                    <template slot-scope="scope">
                      <el-select v-model="scope.row.timeFrame" filterable placeholder="请选择" style="margin-left: 10px; width: 110px;" class="top-title" @change="
                          timerisk(scope.row, scope.$index, scope.row.timeFrame)
                        ">
                        <el-option v-for="item in timeFrameList" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="class" label="课节"> </el-table-column>
                  <el-table-column prop="classTime" label="开始时间 结束时间" width="230">
                    <template slot-scope="scope">
                      <el-time-picker is-range style="width: 210px;" value-format="HH:mm" v-model="scope.row.classTime" range-separator="-" start-placeholder="开始时间" end-placeholder="结束时间" placeholder="选择时间范围" @change="suretime(scope.row, scope.$index)" :minTime="smalltime" :maxTime="lasttime" format="HH:mm">
                      </el-time-picker>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作">
                    <template slot-scope="scope">
                      <button :class="scope.row.className" @click="
                          scope.row.className == 'addBut'
                            ? addHandle(scope.row, scope.$index)
                            : deleteHandle(scope.row, scope.$index)
                        "></button>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </el-tab-pane>
            <el-tab-pane label="周六 周日" name="second">
              <div class="table">
                <el-table :data="timeData2" border ref="timeTable2" style="width: 100%" :header-cell-style="$storage.tableHeaderColor">
                  <el-table-column prop="timeFrame" label="上午/下午/晚上" width="150">
                    <template slot-scope="scope">
                      <el-select v-model="scope.row.timeFrame" filterable placeholder="请选择" style="margin-left: 10px; width: 110px;" class="top-title" @change="
                          timerisk(scope.row, scope.$index, scope.row.timeFrame)
                        ">
                        <el-option v-for="item in timeFrameList" :key="item.value" :label="item.label" :value="item.value">
                        </el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                  <el-table-column prop="class" label="课节"> </el-table-column>
                  <el-table-column prop="classTime" label="开始时间 结束时间" width="230">
                    <template slot-scope="scope">
                      <el-time-picker is-range style="width: 210px;" value-format="HH:mm" v-model="scope.row.classTime" range-separator="-" start-placeholder="开始时间" end-placeholder="结束时间" placeholder="选择时间范围" format="HH:mm">
                      </el-time-picker>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作">
                    <template slot-scope="scope">
                      <button :class="scope.row.className" @click="
                          scope.row.className == 'addBut'
                            ? addHandle2(scope.row, scope.$index)
                            : deleteHandle2(scope.row, scope.$index)
                        "></button>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </el-tab-pane>
          </el-tabs>
          <span slot="footer" class="dialog-footer">
            <el-button @click="timeCancel">取 消</el-button>
            <el-button type="primary" @click="timeAffirm">确 定</el-button>
          </span>
        </el-dialog>

        <el-dialog title="排课限制设置" :visible.sync="dialogVisiblePK" width="600px">
          <span>请添加不可排课的时间:</span>
          <el-table :data="pksystem" border ref="timeTable2" style="width: 100%;margin-top:10px" :header-cell-style="$storage.tableHeaderColor">
            <el-table-column label="周几">
              <template slot-scope="scope">
                <el-select v-model="scope.row.xq" filterable placeholder="请选择" style="width:100%">
                  <el-option v-for="(item, index) in dateList" :key="index" :value="item.value" :label="item.label">
                  </el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="课节">
              <template slot-scope="scope">
                <el-cascader v-model="scope.row.kj" :options="scope.row.options" separator="-"></el-cascader>
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <i class="el-icon-circle-plus" style="color:#f56c6c" v-if="scope.$index === pksystem.length - 1" @click="
                    pksystem.push({
                      xq: '',
                      kj: [],
                      options: pksystem[scope.$index].options
                    })
                  "></i>
                <i class="el-icon-remove" style="color:#409eff" @click="pksystem.splice(scope.$index, 1)" v-if="scope.$index !== pksystem.length - 1"></i>
              </template>
            </el-table-column>
          </el-table>
          <span slot="footer" class="dialog-footer">
            <div style="text-align:center">
              <el-button @click="dialogVisiblePK = false">取 消</el-button>
              <el-button type="primary" @click="pkSystem">确 定</el-button>
            </div>
          </span>
        </el-dialog>

        <el-dialog title="修改排课" :visible.sync="modificDialog" :before-close="handleClose" :close-on-click-modal="false">
          <p class="hr"></p>
          <table>
            <tr>
              <td class="listcss">课程号：</td>
              <td>{{ form.kch }}</td>
              <td class="listcss">课程名称：</td>
              <td>{{ form.kcmc }}</td>
            </tr>
            <tr>
              <td class="listcss">课程性质：</td>
              <td>{{ form.kcxzh }}</td>
              <td class="listcss">学年学期：</td>
              <td>{{ form.xnxqmc }}</td>
            </tr>
            <tr>
              <td class="listcss">开课单位：</td>
              <td>{{ form.dwmc }}</td>
              <td class="listcss">年级：</td>
              <td>{{ form.xknj }}</td>
            </tr>
            <tr>
              <td class="listcss">培养层次：</td>
              <td colspan="3">{{ form.pyccm }}</td>
            </tr>
            <tr>
              <td class="listcss">授课教师：</td>
              <td colspan="3">
                <el-select v-model="form.jszgh" filterable multiple placeholder="请选择" remote reserve-keyword :remote-method="remoteMethod1" :loading="loading" @focus="selectjs" style="width:100%">
                  <el-option v-for="item in teacherList" :key="item.gh" :collapse-tags="`${item.info}`" :value="item.gh" :label="`${item.info}`">
                  </el-option>
                </el-select>
              </td>
            </tr>
            <tr>
              <td class="listcss">计划专业：</td>
              <td colspan="4">
                <el-tooltip class="item" effect="dark" :content="form.pyfazy" placement="top">
                  <div style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:500px">
                    {{ form.pyfazy }}
                  </div>
                </el-tooltip>
              </td>
            </tr>
            <tr>
              <td class="listcss">教学班：</td>
              <td colspan="3">
                <el-select v-model="form.skbj" filterable placeholder="请选择" style="width:100%" @change="jxbListVoss" :disabled="ishow" multiple>
                  <el-option v-for="(item, index) in form.jxbListVos" :key="index" :label="item.bjmc" :value="item.bh" :disabled="item.disabled">
                  </el-option>
                </el-select>
              </td>
            </tr>

            <tr>
              <td class="listcss">关联专业：</td>
              <td colspan="3">
                <el-tooltip class="item" effect="dark" :content="form.zy" placement="top">
                  <div style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:500px">
                    {{ form.zy }}
                  </div>
                </el-tooltip>
              </td>
            </tr>
            <tr>
              <td class="listcss">上课时间、地点：</td>
              <td colspan="3">
                <div v-for="(item, index) in form.pyPkkcSksjs" :key="index" style="margin-bottom:8px">
                  <el-cascader style="width: 90px;" :options="options" separator="-" v-model="item.zc" :disabled="ishow">
                  </el-cascader>
                  <span>周</span>
                  <el-select v-model="item.xq" filterable placeholder="周一" style="width: 80px;" :disabled="ishow" @change="zckjgg(item.xq, item)">
                    <el-option v-for="item in dateList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                  <el-cascader style="width: 90px;" :options="item.myoptions" separator="-" v-model="item.kj" :disabled="ishow">
                  </el-cascader>
                  <span>节</span>
                  <el-select v-model="item.sfmz" filterable style="width: 80px;" :disabled="ishow">
                    <el-option v-for="item in weekList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                  <el-select v-model="item.skdd" filterable placeholder="请选择" @change="xdrsChange">
                    <el-option v-for="(item, index) in form.classroomList" :key="index" :label="item.jsmc" :value="item.jsh">
                    </el-option>
                  </el-select>
                  <el-button type="primary" icon="el-icon-plus" style="position: relative; top: 0px;" v-if="index == 0" @click="addClick" size="mini" :disabled="ishow"></el-button>
                  <el-button type="danger" icon="el-icon-delete" style="position: relative; top: 0px;" v-else-if="index != 0" @click="deleteClick(index)" size="mini" :disabled="ishow"></el-button>
                </div>
              </td>
            </tr>
            <tr>
              <td class="listcss">限定人数：</td>
              <td colspan="3">
                <el-input-number v-model="form.xdrs" style="width: 100px" class="top-input" clearable controls-position="right" :min="form.minXdrs" :max="form.maxXdrs"></el-input-number>
              </td>
            </tr>
          </table>

          <div v-if="jcct == false">
            <p style="color:#F5222D;margin-bottom:5px">排课冲突提示：</p>
            <ul class="uldialog">
              <li v-for="(item, index) in jyctarr" :key="index">
                <span class="span">{{ index + 1 }}</span><span style="flex:5">{{ item.message }}</span>
              </li>
            </ul>
          </div>
          <span slot="footer" class="dialog-footer">
            <div style="text-align:center">
              <el-button @click="cancel">取 消</el-button>
              <el-button type="primary" @click="addaffirm('1')" v-if="jcct == true">确 定</el-button>
              <el-button type="primary" @click="addaffirm('0')" v-if="jcct == false">忽略保存</el-button>
            </div>
          </span>
        </el-dialog>
      </div>
      <manual v-if="$store.state.manualClass == true" :pksysteman="pksystem"></manual>
    </template>
    <el-dialog title="浙江财经大学可视化排课" :visible.sync="kshpk" center fullscreen :close-on-click-modal="false" @close="schedulingclose">
      <scheduling ref="scheduling"></scheduling>
    </el-dialog>
  </div>
</template>

<script>
import manual from "./formulate/manual";
import scheduling from "./formulate/scheduling";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "formulate",
  components: {
    manual,
    scheduling: scheduling,
    pagination: pagination,
    componment: componment
  },
  data() {
    return {
      pksystem: [
        {
          xq: "",
          kj: [],
          options: []
        }
      ],
      dialogVisiblePK: false,
      jcct: true,
      pyccm: "",
      pyccmList: [],
      kshpk: false,
      loading: false,
      weekList: [
        {
          value: "1",
          label: "每周"
        },
        {
          value: "2",
          label: "单周"
        },
        {
          value: "3",
          label: "双周"
        }
      ],
      dateList: [
        {
          value: "1",
          label: "周一"
        },
        {
          value: "2",
          label: "周二"
        },
        {
          value: "3",
          label: "周三"
        },
        {
          value: "4",
          label: "周四"
        },
        {
          value: "5",
          label: "周五"
        },
        {
          value: "6",
          label: "周六"
        },
        {
          value: "7",
          label: "周日"
        }
      ],
      options: [],
      myoptions: [],
      myoptions1: [],
      classroomList: [], // 教室列表
      form: {
        jszgh: [],
        classroomList: []
      },
      modificDialog: false, // 修改排课
      timeList: [], // 学年学期列表
      myclassList: [], // 年级列表
      teacherList: [], // 授课教师列表
      classList: [], // 教学班列表
      dialogVisible: false,
      currentPage: 1,
      searchField: "", // 搜索的数据
      activeName: "first", // 排课时间设置默认激活的tab
      dayList: {}, // 排课时间设置查看详情
      tableData: [],
      unitList: [], // 单位列表
      unit: "", // 选中单位
      major: "", // 选中专业
      majorList: [], // 全部专业列表
      grade: "", // 选中年级
      gradeList: [], // 全部年级列表
      level: "", // 选中培养层次
      levelList: [], // 全部培养层次列表
      total: 1, // 总数据条数
      pagesize: 1,
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      timeFrameList: [
        {
          value: "0",
          label: "上午"
        },
        {
          value: "1",
          label: "下午"
        },
        {
          value: "2",
          label: "晚上"
        }
      ],
      timeData1: [
        // {
        //   timeFrame: "",
        //   class: "第1节",
        //   classTime: [new Date(9, 10, 8, 30), new Date(9, 10, 9, 30)],
        //   className: "addBut"
        // }
      ],

      timeData2: [
        // {
        //   timeFrame: "",
        //   class: "第1节",
        //   classTime: [new Date(9, 10, 8, 30), new Date(9, 10, 9, 30)],
        //   className: "addBut"
        // }
      ],
      loading2: false,
      morning: ["08:00:00", "13:00:00"],
      noon: ["13:00:00", "19:00:00"],
      evening: ["19:00:00", "22:00:00"],
      smalltime: "",
      lasttime: "",
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      ishow: false,
      workKj: 0,
      restKj: 0,
      ckickout: "1",
      jyctarr: []
    };
  },
  filters: {
    classNames(val, val1) {
      if (val1 == 0) {
        return (val = "addBut");
      }
      return (val = "deleteBut");
    },
    sfmz(val) {
      // 1是每周,2单周,3双周
      if (val == "1") {
        return "每周";
      } else if (val == "2") {
        return "单周";
      } else if (val == "3") {
        return "双周";
      }
    },
    xq(val) {
      if (val == "1") {
        return (val = "一");
      } else if (val == "2") {
        return (val = "二");
      } else if (val == "3") {
        return (val = "三");
      } else if (val == "4") {
        return (val = "四");
      } else if (val == "5") {
        return (val = "五");
      } else if (val === "6") {
        return (val = "六");
      } else {
        return (val = "日");
      }
    }
  },
  methods: {
    xdrsChange() {
      var Aarr = [];
      this.form.xdrs = 0;
      if (this.form.pyPkkcSksjs.length == 1) {
        this.form.minXdrs = Number(0);
        this.form.maxXdrs = Number(
          this.form.classroomList.find(
            el => el.jsh === this.form.pyPkkcSksjs[0].skdd
          ).zws
        );
      } else {
        this.form.pyPkkcSksjs.map(v => {
          var temp = this.form.classroomList.find(el => el.jsh === v.skdd).zws;
          if (!temp) {
            return false;
          }
          Aarr.push(temp);
        });
        var arrayMin = this.arrayMin(Aarr);
        this.form.minXdrs = Number(0);
        this.form.maxXdrs = Number(arrayMin);
      }
    },
    pkSystem() {
      var obj = {};
      var arr = [];
      this.pksystem.forEach((item, index) => {
        this.$set(item, "kJ", "");
        item.kJ = item.kj[item.kj.length - 1];
        console.log(item.kj, item.kJ);
        obj = {
          kj: item.kJ,
          xq: item.xq
        };
        arr.push(obj);
      });
      this.$http.post("api/cultivate/kc/saveLimit", arr).then(res => {
        console.log(res);
        if (res.data.code == 200) {
          this.dialogVisiblePK = false;
          return this.$message.success(res.data.message);
        } else {
          this.$message.error(res.data.message);
        }
      });
      console.log(this.pksystem);
    },
    classTimePK() {
      this.pksystem = [];
      this.dialogVisiblePK = true;
      this.kjcaner(14);
      this.infoLimit();
      console.log(this.pksystem);
    },
    infoLimit() {
      this.pksystem = [];
      this.$http.get("api/cultivate/kc/infoLimit").then(res => {
        if (res.data.data.length == 0) {
          this.pksystem.push({ kj: [], xq: "", options: [...this.myoptions] });
        } else {
          res.data.data.forEach(element => {
            this.pksystem.push({
              kj: element.kj.split(","),
              xq: element.xq,
              options: [...this.myoptions]
            });
          });
        }
        console.log(res);
      });
    },

    zckjgg(val, item) {
      console.log(val, item);
      console.log(this.pkSystem);
      if (val <= 5) {
        this.kjcaner(this.workKj);
        item.myoptions = this.myoptions;
      }
      if (val > 5) {
        this.kjcaner(this.restKj);
        item.myoptions = this.myoptions;
      }
    },
    // 获取下拉属性
    getList() {
      this.$http.get("api/cultivate/kc/selectkkxq").then(res => {});
    },
    schedulingclose() {
      this.formset();
      this.takeList();
    },
    formset() {
      this.searchField = "";
      this.major = "";
      this.unit = "";
      this.grade = "";
    },
    scheduling() {
      // this.$router.push('/formulate/scheduling')
      this.kshpk = true;
    },
    remoteMethod1(val) {
      this.selectmethod(val);
    },
    selectmethod(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        res.data.data.length > 0
          ? (this.teacherList = res.data.data)
          : (this.teacherList = []);
      });
    },
    selectjs() {},
    jxbListVoss(val) {
      if (!Array.isArray(this.form.jxbListVos)) {
        this.$message.error({
          message: "教学班参数不正确"
        });
        return false;
      }
      if (this.form.skbj.length > 0) {
        this.form.skbj.map(v => {
          var jxbdisable = this.form.jxbListVos.find(el => el.bh == v).bjlx;
          this.form.jxbListVos.map(el => {
            if (el.bjlx == jxbdisable) {
              el.disabled = false;
            } else if (el.bjlx == "2") {
              el.disabled = true;
            } else {
              el.disabled = true;
            }
          });
        });
      }
      if (this.form.skbj.length == 0) {
        this.form.jxbListVos.map(el => {
          if (el.bjlx == "2") {
            el.disabled = true;
          } else {
            el.disabled = false;
          }
        });
      }
      this.form.pyPkkcSksjs.map(v => {
        v.skdd = "";
      });
      var arr = [];
      var zyList = [];
      var jsVoList = [];
      this.form.skbj.forEach(item => {
        var index = this.form.jxbListVos.find(el => el.bh === item);
        arr.push(index);
      });

      // console.log(arr);
      this.form.xdrs = arr
        .map(row => row.xdrs * 1)
        .reduce((acc, cur) => cur + acc, 0);
      arr.forEach(el => {
        zyList = zyList.concat(el.zyList.split(","));
        // jsVoList = jsVoList.concat(el.jsVoList);
        this.form.classroomList = el.jsVoList;
      });
      // console.log(zyList, jsVoList);
      let index = zyList.filter(function(element, index, self) {
        return self.indexOf(element) === index;
      });

      if (zyList.includes("全部专业")) {
        this.form.zy = "全部专业";
      } else {
        this.form.zy = index.toString();
      }
      // this.form.classroomList = jsVoList.filter(
      //   element => Number(element.zws) >= Number(this.form.xdrs)
      // );
      console.log(this.form.classroomList);
      // var list = this.form.classroomList;
      let obj = {};
      // let peon = list.reduce((cur, next) => {
      //   obj[next.jsh] ? "" : (obj[next.jsh] = true && cur.push(next));
      //   return cur;
      // }, []);
      // this.form.classroomList = peon;
    },
    pyJsjbxxbs() {
      this.$http.get("api/cultivate/kc/selectJsList").then(res => {
        console.log(res.data.data);
        this.classroomList = res.data.data;
      });
    },
    timerisk(row, index, val) {
      console.log(row, index, val);
      switch (row.timeFrame) {
        case "0":
          row.classTime = this.morning;
          break;
        case "1":
          row.classTime = this.noon;
          break;
        case "2":
          row.classTime = this.evening;
          break;
        default:
          break;
      }
    },
    suretime(row, index) {
      // console.log(row, index);
      // switch (row.timeFrame) {
      //   case "0":
      //     this.smalltime = this.morning[0];
      //     this.lasttime = this.morning[1];
      //     console.log("1100");
      //     break;
      //   case "1":
      //     console.log(11);
      //     // this.qujian(this.noon, row.classTime, row.timeFrame);
      //     break;
      //   case "2":
      //     console.log(33);
      //     // this.qujian(this.evening, row.classTime, row.timeFrame);
      //     break;
      //   default:
      //     break;
      // }
    },
    // timetypelist(val) {
    //   return new Promise((resolve, reject) => {
    //     resolve(
    //       Number(val.split(":")[0] * 3600) +
    //         Number(val.split(":")[1] * 60) +
    //         Number(val.split(":")[2])
    //     );
    //   });
    // },
    // qujian(val, index, timeFrame) {
    //   console.log(val, index, timeFrame);
    //   console.log(index[0], val[0], index[0], val[0]);
    //   if (
    //     index[0] * 1 >= val[0] * 1 &&
    //     index[0] * 1 <= index[1] * 1 &&
    //     index[1] * 1 <= val[1] * 1
    //   ) {
    //     switch (timeFrame) {
    //       case "0":
    //         console.log(111);

    //         this.$message.error({
    //           message: "不在上午选择的区间8:00:00 - 13:00:00"
    //         });
    //         index = this.morning;
    //         break;
    //       case "1":
    //         this.$message.error({
    //           message: "不在中午选择的区间13:00:00 - 19:00:00"
    //         });
    //         index = this.noon;
    //         break;
    //       case "2":
    //         this.$message.error({
    //           message: "不在中午选择的区间19:00:00 - 22:00:00"
    //         });
    //         index = this.evening;
    //         break;
    //       default:
    //         break;
    //     }
    //   }
    // },
    // 清除input
    clearinput() {
      this.searchField = "";
      this.takeList();
    },
    // 筛选select
    selectchange() {
      this.takeList();
    },
    // 排课时间设置tab切换
    tabClick() {},
    // 添加课程
    addClick() {
      const obj = {
        zc: "",
        xq: "",
        kj: "",
        sfmz: "",
        skdd: "",
        className: "deleteBut",
        myoptions: this.myoptions
      };
      this.form.pyPkkcSksjs.push(obj);
    },
    // 删除课程
    deleteClick(index) {
      this.form.pyPkkcSksjs.splice(index, 1);
      var Aarr = [];
      this.form.xdrs = 0;
      if (this.form.pyPkkcSksjs.length == 1) {
        this.form.minXdrs = Number(0);
        this.form.maxXdrs = Number(
          this.form.classroomList.find(
            el => el.jsh === this.form.pyPkkcSksjs[0].skdd
          ).zws
        );
      } else {
        this.form.pyPkkcSksjs.map(v => {
          var temp = this.form.classroomList.find(el => el.jsh === v.skdd).zws;
          if (!temp) {
            return false;
          }
          Aarr.push(temp);
        });
        var arrayMin = this.arrayMin(Aarr);
        this.form.minXdrs = Number(0);
        this.form.maxXdrs = Number(arrayMin);
      }
    },
    // 删除列表中数据
    addaffirm(valist) {
      if (this.form.skbj.length == 0) {
        return this.$message.error("教学班不能为空");
      }
      var arr = [];
      var arr2 = [];
      var flag = true;
      const formobj = JSON.parse(JSON.stringify(this.form)); // 防止拷贝
      formobj.pyPkkcSksjs.map((item, index, key) => {
        Object.keys(item).forEach(Element => {
          if (Element == "jsmc") return delete item.jsmc;
        });
        if (item.zc.length > 1) {
          formobj.pyPkkcSksjs[index].zc = item.zc[1];
        } else {
          formobj.pyPkkcSksjs[index - 1].zc = item.zc[0];
        }
        if (item.kj.length > 1) {
          formobj.pyPkkcSksjs[index].kj = item.kj[1];
        } else {
          formobj.pyPkkcSksjs[index - 1].kj = item.kj[0];
        }
      });
      formobj.pyPkkcSksjs.forEach(item => {
        if (flag) {
          if (!item.zc || !item.kj || !item.sfmz || !item.xq) {
            this.$message.error("请填写完整再提交");
            flag = false;
          }
        }
      });

      // 修改的数据
      const formobjchild = {
        id: formobj.id,
        jsgh: formobj.jszgh.toString(),
        jxb: formobj.skbj.toString(),
        kch: formobj.kch,
        nj: formobj.xknj,
        sksjdd: formobj.pyPkkcSksjs,
        xnxq: formobj.xnxq,
        xdrs: this.form.xdrs
      };
      if (flag) {
        this.$http
          .put("api/cultivate/kc/updte", {
            dto: formobjchild,
            lx: valist
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.message,
                type: "success"
              });
              this.modificDialog = false;
              this.takeList();
            } else if (res.data.code == 123456) {
              if (Array.isArray(res.data.data) && res.data.data.length > 0) {
                this.jcct = false;
                this.jyctarr = res.data.data;
              } else {
                this.jcct = true;
              }
            } else {
              this.$message.error({
                message: res.data.message
              });
            }
          });
      }
      console.log(formobj);
    },
    cancel() {
      this.modificDialog = false;
    },
    mydeleteHandle(row) {
      if (this.ishow) {
        return this.$message.warning("删除功能暂未开启！");
      }
      this.$confirm("删除该课程, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .delete("api/cultivate/kc/" + parseInt(row.id))
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: "删除成功",
                  type: "success"
                });
                this.takeList();
              } else {
                this.$message.error({
                  message: "删除失败"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // 取消设置时间
    timeCancel() {
      this.dialogVisible = false;
      this.timeData1 = [
        {
          timeFrame: "",
          class: "第1节",
          classTime: [new Date(9, 10, 8, 30), new Date(9, 10, 9, 30)],
          className: "addBut"
        }
      ];
      this.timeData2 = [
        {
          timeFrame: "",
          class: "第1节",
          classTime: [new Date(9, 10, 8, 30), new Date(9, 10, 9, 30)],
          className: "addBut"
        }
      ];
    },
    // 确认设置排课时间
    timeAffirm() {
      const myobj = [];
      this.timeData1.map((item, index) => {
        const obj = {
          kssj: item.classTime[0],
          jssj: item.classTime[1],
          kj: item.class,
          sfszlr: "0",
          sxw: item.timeFrame
        };
        myobj.push(obj);
      });
      this.timeData2.map((item, index) => {
        const obj = {
          kssj: item.classTime[0],
          jssj: item.classTime[1],
          kj: item.class,
          sfszlr: "1",
          sxw: item.timeFrame
        };
        myobj.push(obj);
      });
      console.log(myobj);
      this.$http.post("api/cultivate/kc/pksj", myobj).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: "设置成功",
            type: "success"
          });
          this.dialogVisible = false;
        } else {
          this.$message.error({
            message: "设置失败"
          });
        }
      });
    },
    // 获取列表
    takeList() {
      this.loading2 = true;
      var params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post(`api/cultivate/kc/query/${params.pageSize}/${params.pageNum}`, {
          dwh: this.unit,
          kcxz: "",
          nj: this.grade,
          query: this.searchField,
          xnxq: this.major,
          pyccm: this.pyccm
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    // 添加课程
    addHandle(row, index) {
      const number = parseInt(this.timeData1.length);
      const obj = {
        timeFrame: "0",
        class: `${this.timeData1.length + 1}`,
        classTime: ["08:00:00", "13:00:00"],
        className: "deleteBut"
      };
      this.timeData1.push(obj);
    },
    // 删除课程时间
    deleteHandle(row, index) {
      this.timeData1.splice(index, 1);
      this.timeData1.map((item, index) => {
        item.class = `${index + 1}`;
      });
    },
    // 添加课程
    addHandle2(row, index) {
      const number = parseInt(this.timeData2.length);
      const obj = {
        timeFrame: "0",
        class: `${this.timeData2.length + 1}`,
        classTime: ["08:00:00", "13:00:00"],
        className: "deleteBut"
      };
      this.timeData2.push(obj);
    },
    // 删除课程时间
    deleteHandle2(row, index) {
      this.timeData2.splice(index, 1);
      this.timeData2.map((item, index) => {
        item.class = `${index + 1}`;
      });
    },
    // 排课时间设置
    classTime() {
      this.getClassTime();
      this.dialogVisible = true;
    },
    // 排课时间设置查看详情
    getClassTime() {
      this.timeData1 = [];
      this.timeData2 = [];
      let obj = {
        timeFrame: "",
        class: "",
        classTime: [],
        className: ""
      };
      this.$http.get("/api/cultivate/kc/infoPksj").then(res => {
        const data = res.data.data;
        this.dayList = data;
        if (data.workDayList.length !== 0) {
          data.workDayList.map((v, index) => {
            obj = {
              timeFrame: v.sxw,
              class: v.kj,
              classTime: [v.kssj, v.jssj],
              className: index == 0 ? "addBut" : "deleteBut"
            };
            this.timeData1.push(obj);
          });
        } else {
          this.timeData1 = [
            {
              timeFrame: "0",
              class: "1",
              classTime: ["08:00:00", "13:00:00"],
              className: "addBut"
            }
          ];
        }
        if (data.restDayList.length !== 0) {
          data.restDayList.map((v, index) => {
            obj = {
              timeFrame: v.sxw,
              class: v.kj,
              classTime: [v.kssj, v.jssj],
              className: index == 0 ? "addBut" : "deleteBut"
            };
            this.timeData2.push(obj);
          });
        } else {
          this.timeData2 = [
            {
              timeFrame: "0",
              class: "1",
              classTime: ["08:00:00", "13:00:00"],
              className: "addBut"
            }
          ];
        }
      });
    },
    // 手动排课
    manualClass() {
      this.$store.state.manualClass = true;
    },
    arrayMin(arrs) {
      var min = arrs[0];
      for (var i = 1, ilen = arrs.length; i < ilen; i += 1) {
        if (arrs[i] < min) {
          min = arrs[i];
        }
      }
      return min;
    },
    // 修改课程
    modificHandle(row) {
      this.jcParams();
      this.jyctarr = [];
      this.jcct = true;
      this.form = {};
      this.modificDialog = true;
      this.$http.get("api/cultivate/kc/" + row.id).then(res => {
        this.form = res.data.data;
        console.log(this.form.jxbListVos);
        this.form.xdrs = res.data.data.xdrs;
        res.data.data.pyPkkcSksjs.map((item, index) => {
          const arr = [parseInt(item.zc.split("-")[0]), item.zc];
          this.form.pyPkkcSksjs[index].zc = arr;
          const arr2 = [parseInt(item.kj.split("-")[0]), item.kj];
          this.form.pyPkkcSksjs[index].kj = arr2;
        });

        this.form.pyPkkcSksjs.map(item => {
          if (parseInt(item.xq) <= 5) {
            this.kjcaner(this.workKj);
            this.$set(item, "myoptions", this.myoptions);
          }
          if (parseInt(item.xq) > 5) {
            this.kjcaners(this.restKj);
            this.$set(item, "myoptions", this.myoptions1);
          }
        });
        if (!Array.isArray(res.data.data.jxbListVos)) {
          this.$message.error({
            message: "教学班参数不正确"
          });
          return false;
        }
        this.form.skbj = res.data.data.skbj.split(",");
        this.form.jxbListVos.map(v => {
          this.$set(v, "disabled", false);
          if (v.bjlx == "2") {
            v.disabled = true;
          } else {
            v.disabled = false;
          }
          if (this.form.skbj.length > 0) {
            this.form.skbj.map(v => {
              var jxbdisable = this.form.jxbListVos.find(el => el.bh == v).bjlx;
              this.form.jxbListVos.map(el => {
                if (el.bjlx == jxbdisable) {
                  el.disabled = false;
                } else if (el.bjlx == "2") {
                  el.disabled = true;
                } else {
                  el.disabled = true;
                }
              });
            });
          }
          if (this.form.skbj.length == 0) {
            this.form.jxbListVos.map(el => {
              if (el.bjlx == "2") {
                el.disabled = true;
              } else {
                el.disabled = false;
              }
            });
          }
        });
        this.teacherList = res.data.data.jzgList;
        if (res.data.data.jszgh) {
          this.form.jszgh = res.data.data.jszgh.split(",");
        }
        var arr = [];
        var zyList = [];
        var jsVoList = [];
        this.form.skbj.forEach(item => {
          var index = res.data.data.jxbListVos.find(el => el.bh === item);
          arr.push(index);
        });
        // this.form.xdrs = arr
        //   .map(row => row.xdrs * 1)
        //   .reduce((acc, cur) => cur + acc, 0);
        arr.forEach(el => {
          zyList = zyList.concat(el.zyList.split(","));
          this.form.classroomList = el.jsVoList;
          // jsVoList = jsVoList.concat(el.jsVoList);
        });
        console.log(zyList);
        let index = zyList.filter(function(element, index, self) {
          return self.indexOf(element) === index;
        });
        if (zyList.includes("全部专业")) {
          this.form.zy = "全部专业";
        } else {
          this.form.zy = index.toString();
        }
        var Aarr = [];
        if (this.form.pyPkkcSksjs.length == 1) {
          this.form.minXdrs = Number(0);
          this.form.maxXdrs = Number(
            this.form.classroomList.find(
              el => el.jsh === this.form.pyPkkcSksjs[0].skdd
            ).zws
          );
        } else {
          this.form.pyPkkcSksjs.map(v => {
            var temp = this.form.classroomList.find(el => el.jsh === v.skdd)
              .zws;
            if (!temp) {
              return false;
            }
            Aarr.push(temp);
          });
          var arrayMin = this.arrayMin(Aarr);
          this.form.minXdrs = Number(0);
          this.form.maxXdrs = Number(arrayMin);
        }
        // if (this.form.type == "0") {
        //   this.form.classroomList = jsVoList;
        // } else {
        //   this.form.classroomList = jsVoList.filter(
        //     element => Number(element.zws) >= Number(this.form.xdrs)
        //   );
        // }
        console.log(this.form.classroomList);
        // var list = this.form.classroomList;
        // let obj = {};
        // let peon = list.reduce((cur, next) => {
        //   obj[next.jsh] ? "" : (obj[next.jsh] = true && cur.push(next));
        //   return cur;
        // }, []);
        // this.form.classroomList = peon;
      });
    },
    // 搜索数据方法
    searchData() {
      this.currentPage = 1;
      this.takeList();
    },
    handleClose(done) {
      done();
    },
    // 获取表格中需要下拉的数据
    getTableList() {
      this.majorList = [];
      this.$http.get("api/cultivate/kc/selectkkxq").then(res => {
        this.pyccmList = res.data.data.pyccm;
        this.pyccmList.unshift({ code: "", name: "全部培养层次" });
        this.pyccm = this.pyccmList[0].code;
        this.workKj = res.data.data.kjVO.workKj;
        this.restKj = res.data.data.kjVO.restKj;
        this.kjcaner(this.workKj);
        var count = res.data.data.zc;
        for (let i = 1; i <= count; i++) {
          const myobj = {
            value: i,
            label: i,
            children: []
          };
          for (let k = i; k <= count; k++) {
            const obj = {
              value: i + "-" + k,
              label: k
            };
            myobj.children.push(obj);
          }
          this.options.push(myobj);
        }
        if (res.data.data.kkxq.length == 0) {
          this.majorList = [];
        } else {
          // this.majorList.unshift({ value: "", label: "全部学年学期" });
          res.data.data.kkxq.map(v => {
            this.majorList.push({ value: v.value, label: v.label });
          });
          this.major = this.majorList[0].value;
        }
        this.takeList();
        if (res.data.data.nj.length > 1) {
          this.gradeList = res.data.data.nj;
          this.gradeList.unshift({ njKey: "", njValue: "全部年级" });
        } else {
          this.gradeList = res.data.data.nj;
        }
        if (res.data.data.dwList.length > 0) {
          this.unitList = res.data.data.dwList;
          this.unitList.unshift({ dwh: "", dwmc: "全部开课单位" });
        } else {
          this.unitList = res.data.data.dwList;
          this.unit = res.data.data.dwList[0].dwh;
        }
      });
    },
    kjcaner(val) {
      this.myoptions = [];
      for (let i = 1; i <= parseInt(val); i++) {
        const myobj = {
          value: i,
          label: i,
          children: []
        };
        for (let k = i; k <= parseInt(val); k++) {
          const obj = {
            value: i + "-" + k,
            label: k
          };
          myobj.children.push(obj);
        }
        this.myoptions.push(myobj);
      }
    },
    kjcaners(val) {
      this.myoptions1 = [];
      for (let i = 1; i <= parseInt(val); i++) {
        const myobj = {
          value: i,
          label: i,
          children: []
        };
        for (let k = i; k <= parseInt(val); k++) {
          const obj = {
            value: i + "-" + k,
            label: k
          };
          myobj.children.push(obj);
        }
        this.myoptions1.push(myobj);
      }
    },
    jcParams() {
      this.$http
        .get(`api/cultivate/pycssz/checkOpenMain?key=kkfazd`)
        .then(res => {
          if (res.data.code == 200) {
            if (res.data.data.isOpen == 1) {
              this.ishow = false;
            } else {
              this.ishow = true;
            }
          } else {
            this.$message.error(res.data.message);
          }
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.getTableList();
    this.jcParams();
    this.infoLimit();
    // this.getList();
  }
};
</script>

<style scoped lang="scss">
.formulate {
  width: 100%;
  padding-top: 7px;
  /deep/ .el-dialog__title {
    font-size: 20px;
  }

  .table {
    height: 500px;
    overflow: auto;
  }
  .uldialog {
    width: 100%;
    border-bottom: 1px solid #ccc;

    li {
      border: 1px solid #ccc;
      border-bottom: none;
      display: flex;
      line-height: 36px;
      padding-left: 5px;
      .span {
        flex: 0.5;
        border-right: 1px solid #ccc;
        text-align: center;
        margin-right: 10px;
      }
    }
  }
  table {
    // border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    // text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    // line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 150px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 150px;
    }
  }
}

.majorInformation /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}

.majorInformation /deep/ .dialog-footer button {
  margin: 0 20px;
}

.majorInformation /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}

.majorInformation /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
.deleteBut {
  height: 20px;
  width: 20px;
  outline: none;
  border: none;
  background: url("../../../../assets/img/delete.png") no-repeat;
}

.addBut {
  height: 20px;
  width: 20px;
  outline: none;
  border: none;
  background: url("../../../../assets/img/add.png") no-repeat;
}
</style>
