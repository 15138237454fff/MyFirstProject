<!-- 手动排课 -->
<template>
  <div class="manual">
    <div class="top-title">
      <el-row>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple-light" style="text-align: center;font-size:18px">
            <span style="margin-right:30px;color:#1890FF">已排课程：{{ ypkc }}</span><span style="color:#F5222D">未排课程：{{ wpkc }}</span>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <el-button type="primary" style="float: right; position: relative; top: 10px;" @click="saveData('1')">保存</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="select-form">
      <el-form :model="form" size="samll" :inline="true">
        <el-row style="overflow: auto;width:1690px">
          <el-col :span="24">
            <div class="grid-content bg-purple" style="height:45px;overflow:auto hidden;width:calc(100vw - 250px);padding-bottom:10px;">
              <el-form style="width: auto;white-space: nowrap;">
                <el-form-item label="学年学期:">
                  <el-select v-model="form.time" filterable placeholder="当前学年学期">
                    <el-option v-for="item in timeList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="开课单位:">
                  <el-select v-model="form.work" filterable placeholder="单位名称">
                    <el-option v-for="item in workList" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="年级:">
                  <el-select v-model="form.major" filterable placeholder="请选择" style="width:150px">
                    <el-option v-for="item in majorList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="培养层次:">
                  <el-select v-model="form.pyccm" filterable placeholder="请选择" style="width:150px">
                    <el-option v-for="item in pyccmList" :key="item.code" :label="item.name" :value="item.code">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="课程性质:">
                  <el-select v-model="form.nature" filterable placeholder="请选择" style="width:150px">
                    <el-option v-for="item in natureList" :key="item.code" :label="item.name" :value="item.code">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-button @click="searchClass">查询</el-button>
                </el-form-item>
              </el-form>
            </div>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="table">
      <el-table :data="tableData" border ref="multipleTable" style="width:100%;overflow:auto" :height="tableHeight" empty-text="暂无数据" v-loading="loadingtable" element-loading-text="正在查询中,请稍后.." element-loading-spinner="el-icon-loading" element-loading-background="#fff" :header-cell-style="$storage.tableHeaderColor">
        <el-table-column prop="kch" label="课程名称" width="150">
          <template slot-scope="scope">
            {{scope.row.kch}}{{scope.row.kcmc}}
          </template>
        </el-table-column>
        <!-- <el-table-column prop="kcmc" label="课程名称" width="150" show-overflow-tooltip>
        </el-table-column> -->
        <el-table-column prop="pyfazy" label="计划专业" width="200" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="jxb" label="教学班" width="150">
          <template slot-scope="scope">
            <div class="table_select">
              <el-select v-model="scope.row.jxb" placeholder="选择教学班" filterable @change="selectChange(scope.row)" @clear="selectClear(scope.row)" @focus="selectFocus1($event, scope.row)" multiple>
                <el-option v-for="item in scope.row.jxbList" :key="item.bh" :label="item.bjmc" :value="item.bh" :disabled="item.disabled">
                </el-option>
              </el-select>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="zymc" label="教学班专业" width="150" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column width="190px" label="授课教师">
          <template slot-scope="scope">
            <div class="table_select">
              <el-select v-model="scope.row.js" filterable multiple placeholder="选择授课教师" remote reserve-keyword :remote-method="remoteMethod1" :loading="loading" @focus="selectjs(scope.$index)">
                <el-option v-for="item in scope.row.semesterList1" :key="item.gh" :label="`${item.info}`" :value="item.gh">
                </el-option>
              </el-select>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="sksjdd" label="上课时间、地点" width="600">
          <template slot-scope="scope">
            <div v-for="(item, index) in scope.row.sksjdd" :key="index" style="margin-bottom:8px">
              <el-cascader style="width: 100px;" :options="options" separator="-" v-model="item.zc" @change="handleChange" placeholder="选择周次">
              </el-cascader>
              <span>周</span>
              <el-select v-model="item.xq" filterable placeholder="周一" style="width: 80px;" @change="zckjgg(item.xq, scope.$index,index)">
                <el-option v-for="item in dateList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
              <el-cascader style="width: 100px;" :options="scope.row.myoptions" separator="-" v-model="item.kj" @change="handleChange" placeholder="选择节次">
              </el-cascader>
              <span>节</span>
              <el-select v-model="item.sfmz" filterable style="width: 80px;">
                <el-option v-for="item in weekList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
              <el-select v-model="item.skdd" filterable placeholder="选择上课地点" style="width: 130px;" @change="xdrsChange(scope.row.sksjdd,scope.$index)">
                <el-option v-for="(item, index) in scope.row.classroomList" :key="index" :label="item.jsmc" :value="item.jsh">
                </el-option>
              </el-select>
              <button :class="item.className" @click="
                  item.className == 'addBut'
                    ? addHandle(scope.row, scope.$index)
                    : deleteHandle(scope.row, index,scope.$index)
                " style="position: relative; top: 5px; left: 10px;"></button>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="total" width="55px" label="计划人数">
        </el-table-column>
        <el-table-column prop="xdrs" width="100px" label="限定人数">
          <template slot-scope="scope">
            <el-input-number v-model="scope.row.xdrs" style="width: 90px" class="top-input" clearable controls-position="right" :min="scope.row.minXdrs" :max="scope.row.maxXdrs" :disabled="scope.row.xdisable"></el-input-number>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="95px">
          <template slot-scope="scope">
            <button class="addBut" @click="addClass(scope.row, scope.$index)" v-if="scope.row.isadd == 1"></button>
            <button class="deleteBut" @click="deleteClass(scope.row, scope.$index)" v-else-if="scope.row.isadd == 2"></button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <div class="block">
        <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
        </el-pagination>
      </div> -->
    </div>
    <el-dialog title="排课冲突提示" :visible.sync="jyct" width="30%" :close-on-click-modal="false">
      <ul class="uldialog">
        <li v-for="(item, index) in jyctarr" :key="index">
          <span class="span">{{ index + 1 }}</span><span style="flex:5">{{ item.message }}</span>
        </li>
      </ul>
      <div style="text-align:center;margin-top:15px">
        <span slot="footer" class="dialog-footer">
          <el-button @click="jyct = false">返回修改</el-button>
          <el-button type="primary" @click="saveData('0')">忽略保存</el-button>
        </span>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "manual",
  components: {
    searchcomponment: searchcomponment
  },
  props: ["pksysteman"],
  data() {
    return {
      jyctarr: [],
      jyct: false,
      loading: false,
      myList: [],
      checked: {},
      page: 0, // 当前页码
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      total: 0,
      currentPage: 1,
      pagesize: 10,
      classList: [], // 开课单位列表
      classroomList: [], // 教室列表
      form: {
        major: "",
        time: "",
        work: "",
        nature: "",
        pyccm: ""
      },
      pyccmList: [],
      weekList: [
        {
          value: "1",
          label: "每周"
        },
        {
          value: "2",
          label: "单周"
        },
        {
          value: "3",
          label: "双周"
        }
      ],
      dateList: [
        {
          value: "1",
          label: "周一"
        },
        {
          value: "2",
          label: "周二"
        },
        {
          value: "3",
          label: "周三"
        },
        {
          value: "4",
          label: "周四"
        },
        {
          value: "5",
          label: "周五"
        },
        {
          value: "6",
          label: "周六"
        },
        {
          value: "7",
          label: "周日"
        }
      ],
      timeList: [],
      workList: [],
      majorList: [],
      natureList: [],
      numberList: [], // 课程号 课程名称列表
      restaurants: [],
      timeout: null,
      teacherList: [], // 授课教师列表
      tableData: [],
      options: [],
      myoptions: [],
      tableindex: 0,
      formsub: ["jxb", "js", "zc", "xq", "sfmz"], // 校验字段
      flag: true,
      restKj: 0,
      workKj: 0,
      loadingtable: false
    };
  },
  computed: {
    ypkc() {
      if (this.tableData.length > 0) {
        return this.tableData.filter(el => el.jxb.length > 0).length;
      } else {
        return 0;
      }
    },
    wpkc() {
      if (this.tableData.length > 0) {
        return this.tableData.filter(el => el.jxb.length == 0).length;
      } else {
        return 0;
      }
    }
  },
  methods: {
    xdrsChange(val, index) {
      var arr = [];
      this.tableData[index].xdisable = false;
      if (val.length == 1) {
        this.tableData[index].minXdrs = Number(0);
        this.tableData[index].maxXdrs = Number(
          this.tableData[index].classroomList.find(el => el.jsh === val[0].skdd)
            .zws
        );
      } else {
        val.map(v => {
          var temp = this.tableData[index].classroomList.find(
            el => el.jsh === v.skdd
          ).zws;
          if (!temp) {
            return false;
          }
          arr.push(temp);
        });
        var arrayMin = this.arrayMin(arr);
        this.tableData[index].minXdrs = Number(0);
        this.tableData[index].maxXdrs = Number(arrayMin);
      }
    },
    arrayMin(arrs) {
      var min = arrs[0];
      for (var i = 1, ilen = arrs.length; i < ilen; i += 1) {
        if (arrs[i] < min) {
          min = arrs[i];
        }
      }
      return min;
    },
    zckjgg(val, $index, index) {
      console.log(this.pksysteman);
      console.log(val, $index);
      console.log(this.tableData);
      if (val <= 5) {
        this.kjcaner(this.workKj);
        this.tableData[$index].myoptions = this.myoptions;
      }
      if (val > 5) {
        this.kjcaner(this.restKj);
        this.tableData[$index].myoptions = this.myoptions;
      }
      this.tableData[$index].sksjdd[index].kj = [];
      if (this.pksysteman.find(el => el.xq === val)) {
        var str = this.pksysteman.find(el => el.xq === val).kj.toString();
        var b = str.indexOf("-");
        var start = str.slice(b - 1, 1);
        var end = str.slice(b + 1);

        console.log("开始" + start, "结束" + end);
        console.log(this.pksysteman.find(el => el.xq === val).kj.toString());
        let index = this.tableData[$index].myoptions.filter(x => {
          return (
            Number(start) <= Number(x.value) && Number(end) >= Number(x.value)
          );
        });
        index.map(v => {
          v.disabled = true;
          v.children.map(x => {
            x.disabled = true;
          });
        });
        this.tableData[$index].myoptions.map(v => {
          console.log(v.children);
          var child = v.children.filter(x => {
            return (
              Number(start) <= Number(x.label) && Number(end) >= Number(x.label)
            );
          });
          console.log(child);
          child.map(v => {
            v.disabled = true;
          });
        });
        console.log(this.tableData[$index].myoptions);
        console.log(index);
      }
    },
    remoteMethod1(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        res.data.data.length > 0
          ? (this.tableData[this.tableindex].semesterList1 = res.data.data)
          : this.tableData[this.tableindex].semesterList1;
      });
    },
    selectjs(val) {
      this.tableindex = val;
    },
    formresttype(item, flag) {
      Object.keys(item).forEach(child => {
        const i = this.formsub.find((item, index) => item == child);
        if (i) {
          const message = this.$stores.state.formlist.filter((item, index) => {
            return item.js == i;
          });
          if (!item[i].length || !item[i]) {
            if (flag) {
              this.$message.error({ message: message[0].message });
              flag = false;
            }
            return false;
          }
        }
      });
    },
    // 保存数据
    saveData(value) {
      if (value == "0") {
        this.jyct = false;
      }
      this.jyctarr = [];
      let foot = true;
      const arr = [];
      let flag = true;
      const table = JSON.parse(JSON.stringify(this.tableData)); // 防止拷贝
      if (this.tableData.length) {
        table.map((item, index) => {
          // Object.keys(item).forEach(child => {
          //   const i = this.formsub.find((item, index) => item == child);
          //   if (i) {
          //     const message = this.$stores.state.formlist.filter(
          //       (item, index) => {
          //         return item.js == i;
          //       }
          //     );
          //     if (!item[i].length || !item[i]) {
          //       if (flag) {
          //         this.$message.error({ message: message[0].message });
          //         flag = false;
          //       }
          //       return false;
          //     }
          //   }
          // });
          console.log(item);
          item.sksjdd.forEach(element => {
            if (item.jxb.length == 0) {
              element.sfmz = "";
              element.xq = "";
            }
            console.log(element);
            Object.keys(element).forEach(Element => {
              if (Element == "className") return delete element.className;
            });
            if (element.zc.length > 0) {
              element.zc = element.zc[1];
            } else {
              element.zc = "";
            }
            if (element.kj.length > 0) {
              element.kj = element.kj[1];
            } else {
              element.kj = "";
            }
            // element.zc = element.zc[1]; // 周次数组转化字符串
            // element.kj = element.kj[1]; // 课节数组转化字符串
            if (item.jxb.length > 0) {
              Object.keys(element).forEach(child => {
                const i = this.formsub.find((item, index) => item == child);
                if (i) {
                  const message = this.$stores.state.formlist.filter(
                    (item, index) => {
                      return item.js == i;
                    }
                  );
                  if (!element[i].length || !element[i]) {
                    if (foot) {
                      this.$message.error({ message: message[0].message });
                      foot = false;
                    }
                    return false;
                  }
                }
              });
            }
          });
          const submit = {
            jsgh: item.js.toString(), // 教师工号
            jxb: item.jxb.toString(), // 教学班
            kch: item.kch, // 课程号
            nj: this.form.major, // 年级
            xnxq: this.form.time, // 学年学期
            sksjdd: item.sksjdd, // 上课时间、地点
            pyccm: this.form.pyccm,
            xdrs: item.xdrs
          };
          arr.push(submit);
          console.log(submit);
        });
        if (flag && foot) {
          this.$http
            .post("api/cultivate/kc/save", {
              list: arr,
              lx: value
            })
            .then(res => {
              if (res.data.code == 200) {
                this.$message({ message: "添加成功", type: "success" });
                this.$store.state.manualClass = false;
                this.$parent.major = this.form.time;
                this.$parent.grade = this.form.major;
                this.$parent.unit = this.form.work;
                this.$parent.takeList();
              } else if (res.data.code == 1234) {
                this.$message.error({ message: res.data.message });
              } else if (res.data.code == 123456) {
                if (
                  Array.isArray(res.data.data) &&
                  res.data.data.length > 0 &&
                  value == "1"
                ) {
                  this.jyct = true;
                  this.jyctarr = res.data.data;
                }
                // console.log(this.jyctarr);
              } else {
                this.$message({ message: res.data.message, type: "error" });
              }
            });
        }
      } else {
        this.$message.error({
          message: "表格暂无数据无法提交"
        });
      }
    },
    searchClass() {
      this.pagesize = Math.floor(this.tableHeight / 57) - 1;
      this.takeList(1);
    },
    // 查找列表
    takeList(index) {
      this.tableData = [];
      this.loadingtable = true;
      this.$http
        .post("api/cultivate/kc/selectkc", {
          dwh: this.form.work,
          kcxz: this.form.nature,
          nj: this.form.major,
          query: "",
          xnxq: this.form.time,
          zyh: "",
          pyccm: this.form.pyccm
        })
        .then(res => {
          this.loadingtable = false;
          // setTimeout(() => {
          //   this.loadingtable = false;
          // }, 1000);
          if (res.data.data.length == 0) {
            return this.$message.error("当前查询结果无法进行排课,请重新选择");
          }
          this.tableData = [];
          this.myList = res.data.data;
          this.total = res.data.data.length;
          res.data.data.map((item, index) => {
            const obj = {
              minXdrs: 0,
              maxXdrs: 0,
              xdisable: true,
              kch: item.kch,
              kcmc: item.kcmc,
              zymc: "",
              zy: item.zy,
              xdrs: "",
              total: item.total,
              jxbList: item.jxbList,
              classroomList: [],
              pyfazy: item.pyfazy,
              jxb: [],
              js: item.jsList
                ? item.jsList.map(v => {
                    return v.gh;
                  })
                : "",
              sksjdd: [
                {
                  zc: [],
                  xq: "",
                  kj: [],
                  sfmz: "1",
                  skdd: "",
                  className: "addBut"
                }
              ],
              isadd: 1,
              semesterList1: item.jsList,
              myoptions: this.myoptions
            };
            this.tableData.push(obj);
          });
          this.tableData.map((item, index) => {
            if (item.jxbList.length == 1) {
              item.jxb = item.jxbList[0].bh;
            }
            if (item.jxbList.length > 1) {
              // $set触发视图更新
              this.$set(item, "jxb", item.jxbList[0].bh);
            }

            item.jxbList.map(v => {
              this.$set(v, " disabled", false);
              if (v.bjlx == "2") {
                v.disabled = true;
              } else {
                v.disabled = false;
              }
            });
          });
          console.log(this.tableData);
        })
        .catch(err => {
          console.log(err.message);
          this.loadingtable = false;
        });
    },
    // 选择课程获取焦点事件
    selectFocus1(val, row) {
      console.log(row);
    },
    // 教学班选择
    selectChange(row) {
      row.minXdrs = 0;
      row.maxXdrs = 0;
      row.xdisable = true;
      if (row.jxb.length > 0) {
        row.jxb.map(v => {
          var jxbdisable = row.jxbList.find(el => el.bh == v).bjlx;
          row.jxbList.map(el => {
            if (el.bjlx == jxbdisable) {
              el.disabled = false;
            } else if (el.bjlx == "2") {
              el.disabled = true;
            } else {
              el.disabled = true;
            }
          });
        });
      }
      if (row.jxb.length == 0) {
        row.jxbList.map(el => {
          if (el.bjlx == "2") {
            el.disabled = true;
          } else {
            el.disabled = false;
          }
        });
      }
      row.sksjdd.map(v => {
        v.skdd = "";
      });
      var arr = [];
      var zyList = [];
      // var jsVoList = [];
      row.jxb.forEach(item => {
        var index = row.jxbList.find(el => el.bh === item);
        arr.push(index);
      });
      // 限定人数
      // row.xdrs = arr
      //   .map(row => row.xdrs * 1)
      //   .reduce((acc, cur) => cur + acc, 0);
      arr.forEach(el => {
        zyList = zyList.concat(el.zyList.split(","));
        // jsVoList = jsVoList.concat(el.jsVoList);
        row.classroomList = el.jsVoList;
      });
      let index = zyList.filter(function(element, index, self) {
        return self.indexOf(element) === index;
      });
      if (zyList.includes("全部专业")) {
        row.zymc = "全部专业";
      } else {
        row.zymc = index.toString();
      }
      console.log(zyList);
      // row.classroomList = jsVoList.filter(
      //   element => Number(element.zws) >= Number(row.xdrs)
      // );
      // var list = row.classroomList;
      // let obj = {};
      // let peon = list.reduce((cur, next) => {
      //   obj[next.jsh] ? "" : (obj[next.jsh] = true && cur.push(next));
      //   return cur;
      // }, []);
      // row.classroomList = peon;
    },
    selectClear(row) {
      row.zymc = "";
      row.xdrs = "";
    },
    // 获取下拉属性
    getList() {
      this.$http.get("api/cultivate/kc/selectkkxq").then(res => {
        this.pyccmList = res.data.data.pyccm;
        this.form.pyccm = this.pyccmList[0].code;
        this.workKj = res.data.data.kjVO.workKj;
        console.log(res.data.data.kjVO);
        this.restKj = res.data.data.kjVO.restKj;
        this.kjcaner(this.workKj);
        const myRes = res.data.data;
        // 学年学期
        if (res.data.data.kkxq.length > 0) {
          this.timeList.push(res.data.data.kkxq[res.data.data.kkxq.length - 1]);
          this.form.time = this.timeList[0].value;
        } else {
          this.timeList = [];
          this.form.time = "";
        }

        // 单位名称
        myRes.dwList.map((item, index) => {
          const obj = {
            value: item.dwh,
            label: item.dwmc
          };
          this.workList.push(obj);
        });
        this.form.work = this.workList[0].value;
        // 年级
        this.majorList = myRes.nj;
        this.form.major = myRes.nj[0].njKey;
        // 课程性质
        this.natureList = myRes.kcsx;
        this.natureList.unshift({ code: "", name: "全部课程性质" });
        this.form.nature = myRes.kcsx[0].code;
        var count = res.data.data.zc;
        for (let i = 1; i <= count; i++) {
          const myobj = {
            value: i,
            label: i,
            children: []
          };
          for (let k = i; k <= count; k++) {
            const obj = {
              value: i + "-" + k,
              label: k
            };
            myobj.children.push(obj);
          }
          this.options.push(myobj);
        }
      });
    },
    changePage(index) {
      this.page = index - 1;
    },
    sizeChange(value) {
      this.pagesize = value;
    },
    // 获取表格中需要下拉的数据
    getTableList() {
      this.$http
        // .get("api/cultivate/kc/selectJxbLsJs")
        .get("api/cultivate/kc/selectTeaList")
        .then(res => {
          console.log(res.data.data);
          if (res.data.data.length > 0) {
            const myRes = res.data.data;
            if (myRes.skls.length > 0) {
              myRes.skls.map((item, index) => {
                const obj = {
                  value: item.gh,
                  label: item.dsxm
                };
                this.teacherList.push(obj);
              });
            }
          }
        });
    },
    pyJsjbxxbs() {
      this.$http.get("api/cultivate/kc/selectJsList").then(res => {
        console.log(res.data.data);
        this.classroomList = res.data.data;
      });
    },
    // 添加课程
    addClass(row, index) {
      let jxbList = JSON.parse(JSON.stringify(row.jxbList));
      jxbList.map(v => {
        if (v.bjlx == "2") {
          v.disabled = true;
        } else {
          v.disabled = false;
        }
      });
      const obj = {
        kch: row.kch,
        kcmc: row.kcmc,
        jxbList: jxbList.filter(item => item.bh !== row.jxb),
        zy: row.zy,
        xdrs: 0,
        xdisable: true,
        minXdrs: 0,
        maxXdrs: 0,
        total: row.total,
        jxb: "",
        js: row.js,
        zymc: "",
        pyfazy: row.pyfazy,
        classroomList: row.classroomList,
        sksjdd: [
          {
            zc: [],
            xq: "1",
            kj: [],
            sfmz: "1",
            skdd: "",
            className: "addBut"
          }
        ],
        semesterList1: row.semesterList1,
        isadd: 2,
        myoptions: this.myoptions
      };
      this.tableData.splice(index + 1, 0, obj);
      this.total = this.tableData.length;
    },
    addHandle(row, index) {
      console.log(row);

      const obj = {
        zc: [],
        xq: "1",
        kj: [],
        sfmz: "1",
        skdd: "",
        className: "deleteBut"
      };
      row.sksjdd.push(obj);
      row.xdrs = 0;
    },
    // 删除课程时间
    deleteHandle(row, index, $index) {
      row.xdrs = 0;
      row.sksjdd.splice(index, 1);
      var arr = [];
      if (
        row.sksjdd.length == 1 &&
        this.tableData[$index].classroomList.length > 0
      ) {
        this.tableData[$index].minXdrs = Number(0);
        this.tableData[$index].maxXdrs = Number(
          this.tableData[$index].classroomList.find(
            el => el.jsh === row.sksjdd[0].skdd
          ).zws
        );
      }
      if (
        row.sksjdd.length > 1 &&
        this.tableData[$index].classroomList.length > 0
      ) {
        row.sksjdd.map(v => {
          var temp = this.tableData[$index].classroomList.find(
            el => el.jsh === v.skdd
          ).zws;
          if (!temp) {
            return false;
          }
          arr.push(temp);
        });
        var arrayMin = this.arrayMin(arr);
        this.tableData[$index].minXdrs = Number(0);
        this.tableData[$index].maxXdrs = Number(arrayMin);
      }
    },
    // 删除课程
    deleteClass(row, index) {
      this.tableData.splice(index, 1);
      this.total = this.tableData.length;
    },
    exitList() {
      this.$store.state.manualClass = false;
      this.$parent.major = this.form.time;
      this.$parent.grade = this.form.major;
      this.$parent.unit = this.form.work;
      this.$parent.takeList();
      // this.$parent.getTableList();
    },
    handleChange(value) {
      // console.log(value);
    },
    kjcaner(val) {
      this.myoptions = [];
      for (let i = 1; i <= parseInt(val); i++) {
        const myobj = {
          value: i,
          label: i,
          disabled: false,
          children: []
        };
        for (let k = i; k <= parseInt(val); k++) {
          const obj = {
            value: i + "-" + k,
            label: k,
            disabled: false
          };
          myobj.children.push(obj);
        }
        this.myoptions.push(myobj);
      }
    }
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160);
      })();
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1;
    this.getList();
    console.log(this.pksysteman);
    this.getTableList();
    // this.pyJsjbxxbs();
  }
};
</script>

<style scoped lang="scss">
* {
  box-sizing: border-box;
}

.fr {
  float: right;
  position: relative;
  top: 3px;
}

.fl {
  float: left;
  width: 330px;
}

.manual {
  .uldialog {
    width: 100%;
    border-bottom: 1px solid #ccc;
    overflow: auto;
    overflow: hidden;
    li {
      border: 1px solid #ccc;
      border-bottom: none;
      display: flex;
      line-height: 36px;
      padding-left: 5px;
      .span {
        flex: 0.5;
        border-right: 1px solid #ccc;
        text-align: center;
        margin-right: 10px;
      }
    }
  }
  .table_select {
    padding-top: 7px;
    /deep/ .el-select__tags {
      width: 96% !important;
      max-width: none !important;
      // height: 100%;
      top: 3px;
      transform: none;
    }
    .el-select {
      overflow: auto;
      max-height: 90px;
      /deep/ .el-select__input {
        min-width: 30px;
      }
    }
    .el-select /deep/ .el-tag--small {
      height: auto;
      padding-right: 20px;
      position: relative;
      .el-select__tags-text {
        white-space: pre-wrap;
        display: inline-block;
        text-align: left;
      }
      .el-tag__close {
        display: inline-block;
        position: absolute;
        top: 50%;
        right: 3px;
        transform: scale(0.8) translate(0, -50%);
      }
    }
  }
  .top-title {
    padding-right: 15px;
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;

    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }

  .select-form {
    width: 100%;
    margin-bottom: 10px;
  }

  p.title {
    width: 100%;
    height: 50px;
    background: #429dff;
    padding: 2px 10px 0 10px;
  }

  p.title /deep/ .el-form-item__label {
    color: #fff;
  }

  .table {
    width: calc(100vw - 250px);
    overflow: auto;
  }
}

.manual /deep/ .el-radio {
  margin-right: 10px;
}

.deleteBut {
  height: 20px;
  width: 20px;
  outline: none;
  border: none;
  background: url("../../../../../assets/img/delete.png") no-repeat;
}

.addBut {
  height: 20px;
  width: 20px;
  outline: none;
  border: none;
  background: url("../../../../../assets/img/add.png") no-repeat;
}
</style>
<style lang="scss">
.el-scrollbar__wrap {
  max-height: 145px;
}
</style>
