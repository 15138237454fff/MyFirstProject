
<template>
  <div class="scheduling">
    <componment>
      <div slot="left">
        <el-form :model="form" size="samll" :inline="true" class="formclass">
          <el-form-item label="学年学期:">
            <el-select v-model="form.timeList" filterable placeholder="当前学年学期" style="width:140px">
              <el-option v-for="item in timeList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="开课单位:">
            <el-select v-model="form.work" filterable placeholder="单位名称" style="width:140px">
              <el-option v-for="item in workList" :key="item.dwh" :label="item.dwmc" :value="item.dwh">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="年级:">
            <el-select v-model="form.major" filterable placeholder="请选择" style="width:140px">
              <el-option v-for="item in majorList" :key="item.njKey" :label="item.njValue" :value="item.njKey">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="课程性质:">
            <el-select v-model="form.nature" filterable placeholder="请选择" style="width:140px">
              <el-option v-for="item in natureList" :key="item.code" :label="item.name" :value="item.code">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" plain @click="searchtable">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div slot="right">
        <el-button type="primary" @click="saveformlist">保存</el-button>
      </div>
    </componment>
    <div class="draggable" v-if="scheduling">
      <div class="draggable_left">
        <div class="top">
          <header><span>| </span>未排课程</header>
          <el-input v-model="form.nocourse" placeholder="搜索课程号或名称" style="width:170px;" suffix-icon="el-icon-search"></el-input>
          <section class="left_section">
            <draggable class="dragArea list-group" :list="newList" :group="{ name: 'people', pull: 'clone', put: false}" @change="log" :clone="cloneDog" :move='allow'>
              <li v-for="(element,index) in newList" :key="index" @mousemove="chickopen(element)">{{ element.kcmc }} ({{element.kch}})</li>
            </draggable>
          </section>
        </div>
        <div class="bottom">
          <header><span>| </span>已排课程</header>
          <section class="left_section ypclass">
            <li v-for="(element,index) in oldList" :key="index">{{ element.kcmc }} ({{element.kch}})</li>
          </section>
        </div>
      </div>
      <div class="draggable_right">
        <div class="header">
          <li v-for="(item,index) in weekarr">{{item.label}}</li>
        </div>
        <div class="right_bottom">
          <table align="center" border="1" cellspacing="0" cellpadding="0">
            <template v-for="(item,index) in gradearr">
              <tr align="center">
                <td class="listcss">第{{item.kj}}节</td>
                <td cowspan="7">
                  <table align="center" border="1" cellspacing="0" cellpadding="0" class="table_canter">
                    <tr>
                      <td v-for="(child,index) in  item.weekVoList">
                        <draggable class="dragArea list-group systemweekVoList" :list="child.kcList" :options="{ group: 'people',pull: 'clone',put: false }" @change="weekVoListlog($event,item,child,child.kcList)" :move='allowcopy'>
                          <div v-for="(childs,index1) in child.kcList" class="weekVoList" @click="hiddendialogshow(childs,index1,gradearr,child,item)" style="transform:none !important" @mousemove="chickopencopy(childs,index1,gradearr,child,item)">
                            <i class="el-icon-close iconx"></i>
                            <li class="weekVoList_li">{{childs.kch}}{{childs.kcmc}}</li>
                            <div class="weekVoListbjmc">
                              <li class="li" style="white-space: nowrap;width:20px;text-overflow:ellipsis;overflow:hidden">{{childs.bjmc}}</li>
                              <li class="li" style="white-space: nowrap;width:20px;text-overflow:ellipsis;overflow:hidden">{{childs.jsxm}}</li>
                              <li class="li">
                                <span v-for="(el,elindex) in  childs.sksjjd" :key="elindex" class="span0">{{el.zc[1]}}{{el.sfmz | sfmz}}{{el.jsmc}}</span>
                              </li>
                            </div>
                            <div class="hiddendialog" v-if="childs.hiddendialog">
                              <i class="el-icon-caret-left hiddendialogicon"></i>
                              <li><span>教学班：</span>
                                <el-select v-model="childs.bh" placeholder="请选择" @change="jxbsskd(childs)" multiple>
                                  <el-option v-for="(item,index) in childs.jxbList" :key="index" :label="item.bjmc" :value="item.bh">
                                  </el-option>
                                </el-select>
                              </li>
                              <li><span>授课教师：</span>
                                <el-select v-model="childs.jszgh" placeholder="请选择" filterable multiple remote reserve-keyword :remote-method="jszghfilter" :loading="loading" @focus="selectjs(index1,childs,item)">
                                  <el-option v-for="(item,index) in childs.jsList" :key="index" :label="item.xm" :value="item.gh">
                                  </el-option>
                                </el-select>
                              </li>
                              <li style="display:flex">
                                <span style="flex:1">时间地点：</span>
                                <div style="flex:3">
                                  <p v-for="(el,elindex) in  childs.sksjjdcopy">
                                    <el-cascader style="width: 90px;" :options="childs.options" separator="-" v-model="el.zc" @change="handleChange">
                                    </el-cascader> 周
                                    <el-select v-model="el.sfmz" filterable style="width: 75px;">
                                      <el-option v-for="item in childs.weekList" :key="item.value" :label="item.label" :value="item.value">
                                      </el-option>
                                    </el-select>
                                    <el-select v-model="el.skdd" filterable style="width: 110px;">
                                      <el-option v-for="(item,index) in childs.jsVoList" :key="index" :label="item.jsmc" :value="item.jsh">
                                      </el-option>
                                    </el-select>
                                    <i class="el-icon-remove" style="color:red" @click.stop="skddcancel(childs.sksjjdcopy,el,elindex)" v-if="elindex !== childs.sksjjdcopy.length-1"></i>
                                    <i class="el-icon-circle-plus" style="color:#409DFF" v-else @click.stop="skddadd(childs.sksjjdcopy,elindex)"></i>
                                  </p>
                                </div>
                              </li>
                              <div class="btnspan">
                                <el-button @click.stop="canceldialog(childs)">取消</el-button>
                                <el-button type="primary" @click.stop="savemit(childs)">确定</el-button>
                              </div>
                            </div>
                          </div>
                        </draggable>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </template>
          </table>
        </div>
      </div>
    </div>
    <div v-else>
      <img src="@/assets/paike.jpg" alt="" style="width:100%">
    </div>
  </div>
</template>

<script>
import draggable from "vuedraggable";
import componment from "@/components/searchcomponment";
export default {
  name: "scheduling",
  data() {
    return {
      timeList: [], // 学年学期
      form: {
        timeList: "",
        work: "",
        major: "",
        nature: "",
        nocourse: ""
      },
      workList: [], // 开课单位
      majorList: [], // 年级
      natureList: [], // 课程性质
      weekarr: [
        {
          value: "1",
          label: "星期一"
        },
        {
          value: "2",
          label: "星期二"
        },
        {
          value: "3",
          label: "星期三"
        },
        {
          value: "4",
          label: "星期四"
        },
        {
          value: "5",
          label: "星期五"
        },
        {
          value: "6",
          label: "星期六"
        },
        {
          value: "7",
          label: "星期日"
        }
      ],
      gradearr: [],
      newList: [],
      oldList: [],
      content1: [],
      scheduling: false,
      hiddendialog: false,
      weekList: [
        {
          value: "1",
          label: "每周"
        },
        {
          value: "2",
          label: "单周"
        },
        {
          value: "3",
          label: "双周"
        }
      ],
      loading: false,
      tableindex: 0, // 记录当前是哪个星期对应的哪节课
      historyrow: null,
      kjarr: null,
      draggableList: null,
      dragkclist: null,
      countlist: 0,
      copygreen: null,
      gragshow: false,
      everygrag: null
    };
  },
  components: {
    componment: componment,
    draggable: draggable
  },
  filters: {
    sfmz(val) {
      switch (val) {
        case "1":
          return "每周";
          break;
        case "2":
          return "单周";
          break;
        case "3":
          return "双周";
          break;
        default:
          break;
      }
    }
  },
  methods: {
    skddadd(val, index) {
      console.log(val, index);
      const obj = {
        jsmc: "",
        kj: "",
        sfmz: "",
        skdd: "",
        xq: "",
        zc: ""
      };
      val.push(obj);
    },
    skddcancel(val, row, index) {
      val.splice(val.findIndex(item => item === row), 1);
    },
    jszghfilter(val) {
      console.log(val);
      console.log(this.tableindex);
      console.log(this.historyrow);
      console.log(this.kjarr);
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        console.log(res);
        this.gradearr.map(v => {
          // 是否是同一课节
          if (v.kj === this.kjarr.kj) {
            if (v.weekVoList) {
              v.weekVoList.forEach(el => {
                if (el.kcList) {
                  el.kcList.forEach(element => {
                    if (element.hiddenId == this.historyrow.hiddenId) {
                      element.jsList = res.data.data;
                    }
                  });
                }
              });
            }
          }
        });
      });
    },
    selectjs(val, row, item) {
      console.log(val, row, item);
      this.tableindex = val;
      this.historyrow = row;
      this.kjarr = item;
    },
    formsave() {
      this.$http.get("api/cultivate/kc/selectkkxq").then(res => {
        const myRes = res.data.data;
        // 学年学期
        myRes.kkxq.map((item, index) => {
          const obj = {
            value: item.value,
            label: item.label
          };
          this.timeList.push(obj);
        });
        // this.form.time = this.timeList[0].value
        // 单位名称
        this.workList = myRes.dwList;
        // 年级
        this.majorList = myRes.nj;
        // this.form.major = myRes.nj[0].njKey
        // 课程性质
        this.natureList = myRes.kcsx;
        // this.form.nature = myRes.kcsx[0].code
      });
    },
    searchtable() {
      // 查询内容
      var flag = true;
      var form = ["timeList", "work", "major", "nature"];
      form.forEach(element => {
        if (flag) {
          if (!this.form[element]) {
            this.$message.error("排课时筛选条件不能为空");
            flag = false;
          }
        }
      });
      if (flag) {
        this.userlist();
      }
    },
    log(evt) {
      console.log(evt);
    },

    // cloneDogs({ kcList }) {
    //   var obj = {
    //     jsgh: [],
    //     kch: '54141'
    //   }
    //   return {
    //     kcList: [obj]
    //   }
    // },
    allow(ert) {
      // 当前移动未排课程的课程组
      // this.dragkclist = ert.draggedContext.element
    },
    allowcopy(ert) {
      console.log(ert.draggedContext.element);
      if (ert.draggedContext.element) {
        console.log(this.draggableList);
        console.log(this.everygrag);
        this.gradearr.forEach(el => {
          if (el.kj === this.draggableList.kj) {
            console.log("当前移动的课程课节是否相等");
            if (el.weekVoList) {
              el.weekVoList.map((v, indexofs) => {
                if (v.day === this.everygrag.day) {
                  console.log("当前移动的星期是否相等");
                  v.kcList.push(ert.draggedContext.element);
                }
              });
            }
          }
        });
      }
    },
    chickopencopy(childs, index1, gradearr, child, item) {
      // console.log(childs, index1, gradearr, child)
      this.everygrag = child;
      this.draggableList = item;
    },
    chickopen(val) {
      this.dragkclist = val;
    },
    cloneDog({ kcList }) {
      // 拖拽到右边区域的数据进行排课
      console.log(this.gradearr);
      console.log(1222);
      console.log(this.dragkclist);
      var obj = { jsmc: "", kj: "", sfmz: "", skdd: "", xq: "", zc: [] };
      var objset = { jsmc: "", kj: "", sfmz: "", skdd: "", xq: "", zc: [] };
      return {
        bh: "",
        bjmc: null,
        jsList: [],
        jsxm: null,
        jszgh: [],
        jxbList: this.dragkclist.jxbListVos,
        kch: this.dragkclist.kch,
        kcmc: this.dragkclist.kcmc,
        sksjjd: [obj],
        hiddenId: this.countlist++,
        options: this.optionsweeks,
        sksjjdcopy: [objset],
        weekList: this.weekList,
        jsVoList: []
      };
    },
    weekVoListlog(evt, val, row, list) {
      // console.log(evt, val)
      this.draggableList = val;
      this.gragshow = true;
      this.everygrag = row;
      console.log(evt);
      console.log(this.draggableList);
      console.log(evt, val, row, list);
    },
    optionsweek() {
      var options = [];
      for (let i = 1; i <= 16; i++) {
        const myobj = { value: i, label: i, children: [] };
        for (let k = i; k <= 16; k++) {
          const obj = { value: i + "-" + k, label: k };
          myobj.children.push(obj);
        }
        options.push(myobj);
      }
      this.optionsweeks = options;
    },
    userlist() {
      this.$http
        .post("api/cultivate/kc/selectkcByView", {
          dwh: this.form.work,
          kcxz: this.form.nature,
          sznj: this.form.major,
          xnxq: this.form.timeList
        })
        .then(res => {
          console.log(res);
          // 弹框上课周次
          this.optionsweek();
          // 未排课程
          if (!res.data.data.newList.length && !res.data.data.oldList.length) {
            this.$message.error(
              "当前没有课程可进行排课,请筛选正确的数据进行排课"
            );
            this.scheduling = false;
            return false;
          }
          this.newList = res.data.data.newList;
          console.log(this.newList);
          // 已排课程
          this.oldList = res.data.data.oldList;
          console.log(this.oldList);
          // 所有总的课表
          this.gradearr = res.data.data.list;
          console.log(this.gradearr);
          this.gradearr.forEach(el => {
            if (el.weekVoList) {
              el.weekVoList.forEach((weekVoList, index4) => {
                this.$set(weekVoList, "hiddenIds", index4);
                if (weekVoList.kcList) {
                  weekVoList.kcList.forEach((kcList, index) => {
                    // 弹框隐藏显示
                    this.$set(kcList, "hiddendialog", false);
                    // 每个课程的id
                    this.$set(kcList, "hiddenId", index);
                    // 上课是单周，每周，双周
                    this.$set(kcList, "options", this.optionsweeks);
                    var sksjjd = JSON.parse(JSON.stringify(kcList.sksjjd));
                    // 防止数据双向绑定的时候同时更改
                    this.$set(kcList, "sksjjdcopy", sksjjd);
                    // 教学班
                    this.$set(kcList, "weekList", this.weekList);
                    // 上课地点
                    this.$set(kcList, "jsVoList", []);

                    kcList.jxbList.map(f => {
                      kcList.jsVoList = f.jsVoList;
                    });
                    // 授课教师多选是数组
                    if (kcList.jszgh) {
                      kcList.jszgh = kcList.jszgh.split(",");
                    } else {
                      kcList.jszgh = [];
                    }
                    if (kcList.bh) {
                      kcList.bh = kcList.bh.split(",");
                    } else {
                      kcList.bh = [];
                    }
                    console.log(kcList.sksjjd);
                    if (kcList.sksjjd) {
                      kcList.sksjjd.map((vsksjjd, indexv) => {
                        if (vsksjjd.zc) {
                          vsksjjd.zc = [indexv, vsksjjd.zc];
                        } else {
                          vsksjjd.zc = [];
                        }
                      });
                    }
                  });
                }
              });
            }
          });
          this.scheduling = true;
        });
    },
    hiddendialogshow(childs, index1, val, row, kj) {
      console.log(childs, "总数据");
      console.log(index1, "点击当前的索引值");
      console.log(val, "当前的点击数据");
      console.log(row, "当前列数的数据");
      console.log(kj, "课节");

      // 总的数据 当前选中的节数
      val.forEach(el => {
        // console.log(el)
        if (el.weekVoList) {
          // 是否选中当前节数显示详情
          if (el.kj === kj.kj) {
            console.log("拖拽执行比较课节");
            // 课节相等的时候
            el.weekVoList.forEach((weekVoList, indexw) => {
              console.log(weekVoList, "看一下每周课节都存在哪些");
              // 当前节数的hiddenIds与 总数据的hiddenIds是否相等 (相等)
              if (
                weekVoList.day === row.day &&
                row.hiddenIds == weekVoList.hiddenIds
              ) {
                if (weekVoList.kcList) {
                  weekVoList.kcList.forEach((kcList, index) => {
                    this.$set(kcList, "hiddendialog", true);
                  });
                }
              } else {
                // 当前节数的hiddenIds与 总数据的hiddenIds是否相等 (不相等)其他的弹框隐藏
                if (weekVoList.kcList) {
                  weekVoList.kcList.forEach((kcList, index) => {
                    console.log(1115656363);
                    this.$set(kcList, "hiddendialog", false);
                  });
                }
              }
            });
          } else {
            console.log("拖拽执行比较课节");
            // 课节不相等的时候(除了选中的其他的弹框全部不选中)
            el.weekVoList.forEach((weekVoList, indexw) => {
              if (weekVoList.kcList) {
                weekVoList.kcList.forEach((kcList, index) => {
                  console.log(6256);
                  kcList.hiddendialog = false;
                });
              }
            });
          }
        }
      });
    },
    handleChange(val) {
      console.log(val);
    },
    savemit(val) {
      this.resetforms(val);
      // console.log(this.gradearr)
      console.log(val);
    },
    canceldialog(val) {
      this.resetforms(val);
      console.log(val);
    },
    // 校验数据是否存在异常,如果存在异常不能进行排课
    resetforms(val) {
      let flag = true;
      let sksj = true;
      if (val.jxbList.length == 0) {
        return this.$message.error("当前课程无法进行排课");
      }
      const form = ["bh", "bjmc", "jszgh"];
      form.forEach(index => {
        if (flag) {
          if (val[index] == "" || val[index] == []) {
            this.$message.error("请填写完整在关闭窗口");
            flag = false;
          } else {
            val.sksjjdcopy.map(el => {
              if (sksj) {
                if (!el.zc || !el.sfmz) {
                  this.$message.error("请填写完整在关闭窗口");
                  sksj = false;
                }
              }
            });
          }
        }
      });

      if (flag && sksj) {
        val.hiddendialog = !val.hiddendialog;
        val.bjmc = "";
        val.jsxm = "";
        var sksjjdcopy = JSON.parse(JSON.stringify(val.sksjjdcopy));
        val.sksjjd = sksjjdcopy;
        val.jxbList.forEach(g => {
          val.bh.map(vv => {
            if (g.bh == vv) {
              val.bjmc += g.bjmc;
            }
          });
        });
        val.jsList.forEach(g => {
          val.jszgh.map(vv => {
            if (g.gh == vv) {
              val.jsxm += g.xm;
            }
          });
        });
      }
    },
    jxbsskd(val) {
      console.log(val);
      val.jxbList.map(v => {
        if (v.bh == val.bh) {
          val.jsVoList = v.jsVoList;
        }
      });
    },
    saveformlist() {
      console.log(this.gradearr);
    }
  },
  mounted() {
    this.formsave();
    this.$log.DEBUG("5454");
    this.$log.INFO("475");
    this.$log.WARN("5875");
    this.$log.ERROR("585");
    this.$log.FATAL("75");
    this.$log.currentmethod(4);
  }
};
</script>

<style scoped lang="scss">
.scheduling {
  width: 100%;
  padding-top: 7px;
  .formclass {
    height: 34px;
  }
  .draggable {
    width: 100%;
    display: flex;
    height: 800px;
    margin-bottom: 20px;
    margin-top: 20px;
    .draggable_left {
      height: 100%;
      width: 200px;
      .top {
        width: 100%;
        margin-bottom: 10px;
        margin-top: 20px;
      }
      .bottom {
        width: 100%;
      }
      .top,
      .bottom {
        header {
          margin-bottom: 15px;
          font-size: 18px;
          font-weight: bold;
        }
        .left_section {
          width: 100%;
          padding: 10px 0;
          overflow-y: auto;
          height: 300px;
          li {
            width: 170px;
            height: 40px;
            background: rgba(210, 234, 255, 1);
            border-radius: 5px;
            text-align: center;
            line-height: 40px;
            color: #0086ff;
            margin-bottom: 10px;
            border: 1px solid #0086ff;
            cursor: pointer;
            font-size: 12px;
          }
        }
        .ypclass {
          li {
            background: rgba(242, 249, 239, 1);
            border: 1px solid rgba(103, 193, 61, 1);
            color: #67c13d;
          }
        }
      }
    }
    .draggable_right {
      padding-left: 5px;
      width: -moz-calc(100% - 150px);
      width: -webkit-calc(100% - 150px);
      width: calc(100% - 150px);
      overflow: auto;
      min-width: 1300px;
      .header {
        padding-left: 80px;
        height: 48px;
        width: calc(100% - 80px);
        background: #7ec2ff;
        display: flex;
        line-height: 48px;
        li {
          flex: 1;
          text-align: center;
          color: #ffffff;
          font-weight: bold;
          font-size: 14px;
        }
      }
      .right_bottom {
        width: 100%;
        height: -moz-calc(100% - 48px);
        height: -webkit-calc(100% - 48px);
        height: calc(100% - 48px);

        table {
          width: 100%;
          color: #444;
          font-size: 14px;
          white-space: nowrap;
          font-weight: 400;
          tr {
            border: 1px solid #e0e0e0;
          }
          th,
          td {
            border: 1px solid #e0e0e0;
            text-align: center;
            height: 150px;
          }
          .left_cont {
            text-align: left;
            padding-left: 10px;
            font-weight: bold;
          }
          .listcss {
            line-height: 150px;
            width: 40px;
            word-break: break-all;
          }
          .table_canter {
            width: 100%;
            color: #444;
            font-size: 14px;
            white-space: nowrap;
            font-weight: 400;
            th,
            td {
              text-align: center;
              width: 220px;
            }
            .left_cont {
              text-align: left;
              padding-left: 10px;
              font-weight: bold;
            }
            .listcss {
              line-height: 150px;
              width: 40px;
              word-break: break-all;
            }
            .weekVoList {
              background: #d2eaff;
              border: 1px solid #3ea1fc;
              border-radius: 5px;
              color: #0086ff;
              position: relative;
              font-size: 12px;
              height: 65px;
              width: 90%;
              margin: 10px auto;
              padding: 3px;
              cursor: pointer;
              .iconx {
                position: absolute;
                top: 0;
                right: 0;
                color: #000;
                cursor: pointer;
              }
              .hiddendialog {
                width: 450px;
                transform-origin: left center;
                z-index: 2074;
                position: absolute;
                top: -15px;
                right: -475px;
                height: 220px;
                border-radius: 8px;
                background: rgba(255, 255, 255, 1);
                box-shadow: 1px 1px 20px rgba(0, 0, 0, 0.18);
                padding: 10px 10px 10px;
                overflow: auto;
                .hiddendialogicon {
                  position: absolute;
                  top: 5%;
                  left: 0px;
                  z-index: 2080;
                  transform-origin: left center;
                  font-size: 28px;
                  color: #ccc;
                }
                li {
                  padding: 10px 10px 10px 30px;
                  text-align: left;
                  border-bottom: 1px solid rgba(219, 219, 219, 1);
                  color: #000;
                  span {
                    width: 75px;
                    display: inline-block;
                  }
                }
                .btnspan {
                  margin-top: 10px;
                  text-align: right;
                  padding-right: 10px;
                }
              }
              .weekVoList_li {
                margin: 5px 0;
                line-height: 24px;
                border-bottom: 1px dashed #3ea1fc;
              }
              .weekVoListbjmc {
                width: 100%;
                display: flex;
                text-overflow: ellipsis;
                overflow: hidden;
                overflow: auto;
                height: 30px;
                .li {
                  flex: 1;
                  border-right: 1px dashed #3ea1fc;
                  .span0 {
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    overflow: hidden;
                    display: block;
                  }
                }
                .li:last-child {
                  border-right: none;
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
