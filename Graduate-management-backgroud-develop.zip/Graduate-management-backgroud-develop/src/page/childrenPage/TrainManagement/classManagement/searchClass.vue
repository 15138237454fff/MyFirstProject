<!-- 课表查询 -->
<template>
  <div class="searchClass">
    <componment>
      <div slot="left">
        <el-input v-model="searchField" placeholder="请输入课程/教学班/教师" style="width: 240px" @keyup.enter.native="searchData" class="top-input" suffix-icon="el-icon-search" clearable @clear="clearinput"></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select v-model="time" filterable style="margin-left: 10px;" class="top-input" @change="selecttype">
          <el-option v-for="(item,index) in timeList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="work" filterable style="margin-left: 10px;" class="top-input" @change="collegeChange">
          <el-option v-for="(item,index) in workList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="major" filterable style="margin-left: 10px;" class="top-input" @change="selecttype">
          <el-option v-for="(item,index) in majorList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="pycc" filterable style="margin-left: 10px;" class="top-input" @change="selecttype">
          <el-option v-for="(item,index) in levelList" :key="index" :label="item.name" :value="item.code">
          </el-option>
        </el-select>
        <el-select v-model="grade" filterable style="margin-left: 10px;" class="top-input" @change="selecttype">
          <el-option v-for="(item,index) in gradeList" :key="index" :label="item.njValue" :value="item.njKey">
          </el-option>
        </el-select>
        <el-select v-model="classparams" filterable @change="selecttype">
          <el-option label="全部教室" value=""> </el-option>
          <el-option v-for="(item, index) in classList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
    </componment>
    <div class="tab">
      <el-button type="primary" @click="exportInfo" v-if="$btnAuthorityTest('searchClass:export')" class="btn">导出</el-button>
      <el-tabs v-model="activeName" class="top-nav" @tab-click="handleClick">
        <el-tab-pane label="列表展示" name="列表展示">
          <el-table :data="tableData" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading" element-loading-text="加载中">
            <el-table-column prop="kch" label="课程名称">
              <template slot-scope="scope">
                {{scope.row.kch}}{{scope.row.kcmc}}
              </template>
            </el-table-column>
            <el-table-column prop="dwmc" label="开课学院" width="120">
            </el-table-column>
            <el-table-column prop="pyccm" label="培养层次" width="100">
            </el-table-column>
            <el-table-column prop="xknj" label="年级" width="100">
            </el-table-column>
            <el-table-column prop="zy" label="专业" :show-overflow-tooltip="true">
            </el-table-column>
            <el-table-column prop="kkxnd" label="学年学期" width="180">
            </el-table-column>
            <el-table-column prop="bjmc" label="教学班" width="100" :show-overflow-tooltip="true">
            </el-table-column>
            <el-table-column prop="jsxm" label="授课教师" width="150" :show-overflow-tooltip="true">
            </el-table-column>
            <el-table-column prop="teacher" label="上课时间,地点" :show-overflow-tooltip="true">
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.pyPkkcSksjs" :key="index">
                  <span>{{ item.zc }}周</span>&nbsp;&nbsp;<span>({{ item.sfmz | sfmz }})</span>&nbsp;&nbsp;<span>星期{{ item.xq | xq }}</span>&nbsp;<span>{{ item.kj }}</span>节&nbsp;&nbsp;&nbsp;<span>{{ item.jsmc }}&nbsp;&nbsp;&nbsp;</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="xkrsxd" label="听课人数" width="60">
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="周次展示" name="周次展示">
          <lbzh :xnxq="this.time" ref="lbzh" :dwh="this.work" :jhnj="this.grade" :jsh="this.classparams" :pyccm="this.pycc" :query="this.searchField" :zyh="major"></lbzh>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
import lbzh from "./classSearchcom/lbzh";
export default {
  name: "searchClass",
  data() {
    return {
      loadingCl: false,
      activeName: "列表展示",
      pyccm: "",
      pageshow: true,
      searchField: "", // 搜索的数据
      tableData: [],
      timeList: [], // 学期列表
      time: "", // 选中学期
      work: "", // 选中的开课单位
      workList: [], // 开课单位列表
      grade: "", // 选中的年级
      gradeList: [], // 所有的年级列表
      level: "", // 选中的培养层次
      levelList: [], // 所有培养层次列表
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      loading: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      pyccList: [],
      // 培养层次
      pycc: "",
      classList: [],
      classparams: "",
      xnxqList: {},
      major: "",
      majorList: []
    };
  },
  filters: {
    xq(val) {
      if (val == 1) {
        return (val = "一");
      } else if (val == 2) {
        return (val = "二");
      } else if (val == 3) {
        return (val = "三");
      } else if (val == 4) {
        return (val = "四");
      } else if (val == 5) {
        return (val = "五");
      } else if (val == 6) {
        return (val = "六");
      } else {
        return (val = "日");
      }
    },
    sfmz(val) {
      // 1是每周,2单周,3双周
      if (val == "1") {
        return "每周";
      } else if (val == "2") {
        return "单周";
      } else if (val == "3") {
        return "双周";
      }
    }
  },
  components: {
    pagination: pagination,
    componment: componment,
    lbzh
  },
  methods: {
    collegeChange(val) {
      const temp = this.workList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.majorList = temp.children;
      this.fresh();
    },
    clearinput() {
      this.fresh();
    },
    selecttype() {
      this.fresh();
      this.$nextTick(res => {
        this.$refs.lbzh.kj();
      });
    },
    handleClick() {
      this.$nextTick(res => {
        this.$refs.lbzh.kj();
      });
    },
    fresh() {
      this.pageshow = false;
      setTimeout(() => {
        this.pageshow = true;
      }, 500);
      this.takeList();

      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    getTableList() {
      this.$http.get("api/cultivate/kc/selectkkxq").then(res => {
        // this.classList = res.data.data;
        if (res.data.data.nj.length > 1) {
          this.gradeList = res.data.data.nj;
          this.gradeList.unshift({ njKey: "", njValue: "全部年级" });
        } else {
          this.gradeList = res.data.data.nj;
        }
        // if (res.data.data.dwList.length > 1) {
        //   this.workList = res.data.data.dwList;
        //   this.workList.unshift({ dwh: "", dwmc: "全部学院" });
        // } else {
        //   this.workList = res.data.data.dwList;
        //   this.work = this.workList[0].dwh;
        // }
        if (res.data.data.pyccm.length > 1) {
          this.levelList = res.data.data.pyccm;
          this.levelList.unshift({ code: "", name: "全部培养层次" });
        } else {
          this.levelList = res.data.data.pyccm;
        }
      });
      this.$http.get("api/cultivate/classRoom/searchRoomList").then(res => {
        this.classList = res.data.data;
      });
      this.$http.get("api/cultivate/kc/selectDistinctTerm").then(res => {
        if (res.data.data.length == 0) {
          this.timeList = [];
        } else {
          this.timeList = res.data.data;
          this.time = res.data.data[0].value;
        }
      });
      this.getCollegeMajorData();
    },
    getCollegeMajorData() {
      this.$http.get("api/system/dict/select/college").then(res => {
        this.workList = res.data.data;
        this.majorList = this.workList[0].children;
      });
    },
    takeList() {
      console.log(this.xnxqList);
      this.loading = true;
      var params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/cultivate/kc/selectClassList", {
          dwh: this.work,
          jhnj: this.grade,
          query: this.searchField,
          xnxq: this.time,
          pyccm: this.pycc,
          jsh: this.classparams,
          zyh: this.major
        })
        .then(res => {
          this.loading = false;
          this.tableData = res.data.data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }, // 查询列表
    searchData() {
      this.fresh();
    }, // 搜索数据方法
    exportInfo() {
      console.log(this.$stores.state.tokenParams);
      var jsonString = JSON.stringify({
        zyh: this.major,
        dwh: this.work,
        jhnj: this.grade,
        query: this.searchField,
        xnxq: this.time,
        pyccm: this.pycc,
        jsh: this.classparams,
        lx: this.activeName == "列表展示" ? "0" : "1",
        dwlbm: this.$stores.state.tokenParams.dwlbm,
        userStatus: this.$stores.state.tokenParams.userStatus,
        deptNum: this.$stores.state.tokenParams.deptNum
      });
      window.location.href =
        "api/cultivate/kc/exportExcel?jsonString=" + encodeURI(jsonString);
    } // 导出数据
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.$http
      .get("api/cultivate/pycssz/acadmic")
      .then(res => {
        this.xnxqList = res.data.data;
        // this.time = `${this.xnxqList.main.year}-${this.xnxqList.main.semester}`;
        // console.log(this.time);
        this.takeList();
      })
      .catch(err => {
        console.log(err.message);
      });
    this.getTableList();
  },
  created() {}
};
</script>

<style scoped lang="scss">
.searchClass {
  width: 100%;
  padding-top: 7px;
  .tab {
    position: relative;
    border: 1px solid rgba(228, 228, 228, 1);
    .btn {
      position: absolute;
      top: 3px;
      right: 5px;
      z-index: 999;
    }
    .top-nav {
      /deep/ .el-tabs__nav-wrap {
        background: #fff;
      }
      /deep/ .el-tabs__nav {
        margin-left: 15px;
      }
      /deep/ .el-tabs__item {
        width: 150px;
        text-align: center;
      }
      /deep/ .el-tabs__header {
        margin: 0 0 7px;
      }
      /deep/ .el-tabs__active-bar {
        width: 130px !important;
      }
    }
  }
}
.searchClass /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.searchClass /deep/ .dialog-footer button {
  margin: 0 20px;
}
.searchClass /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.searchClass /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
</style>
