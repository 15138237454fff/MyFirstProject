<template>
  <div class="lbzh">
    <table v-if="selectClassListByWeek.length > 0">
      <tr>
        <td class="listcss" style="width:20px"></td>
        <td class="listcss" style="width:20px"></td>
        <td class="listcss" v-for="(item, index) in selectKbheaderlist.dayList" :key="index">
          星期{{ dateMap[item - 1] }}
        </td>
      </tr>
      <template v-for="(item, index) in selectClassListByWeek">
        <tr v-for="(child, childindex) in item.xskbWeekZcVo" :key="childindex">
          <td class="listcss" style="width:28px" :rowspan="item.xskbWeekZcVo.length" v-if="childindex == 0">
            <div style="width:20px;white-space:pre-wrap;">
              {{ item.sxw | sxw }}
            </div>
          </td>
          <td class="listcss" style="width:30px;height:150px;">
            <div style="width:22px;white-space:pre-wrap;">
              第{{ child.kj }}节
            </div>
          </td>
          <td v-for="(el, indexs) in child.weekVoList" :key="indexs">
            <div class="tableindex">
              <div class="tableindex_div" v-for="(element, elindex) in el.kcList" :key="elindex" v-if="el.kcList.length > 0">
                <div class="p1" style="margin-bottom:2px;">
                  <el-tooltip class="item" effect="dark" :content="`${element.kcmc}(${element.jsxm})`" placement="top-start">
                    <span>{{ element.kcmc }}({{ element.jsxm }})</span>
                  </el-tooltip>
                </div>
                <div class="p2" style="margin-bottom:2px;">
                  <p v-for="(x,indexx) in element.sksjjd" :key="indexx">{{ x.zc }}周({{ x.sfmz | sfmz }}){{
                    x.jsmc
                  }}</p>
                </div>
                <div class="p3">
                  <el-tooltip class="item" effect="dark" :content="element.bjmc" placement="top-start">
                    <span>{{ element.bjmc }}</span>
                  </el-tooltip>
                </div>
              </div>
            </div>
          </td>
        </tr>
      </template>
    </table>
  </div>
</template>
<script>
export default {
  props: ["xnxq", "dwh", "jhnj", "jsh", "pyccm", "query", "zyh"],
  name: "lbzh",
  data() {
    return {
      swlist: [
        {
          value: "1",
          span: "656546"
        }
      ],
      visible: false,
      selectKbheaderlist: {},
      selectClassListByWeek: [],
      dateMap: ["一", "二", "三", "四", "五", "六", "日"]
    };
  },
  methods: {
    selectKbheader() {
      this.$http.get("api/cultivate/xk/selectKbheader").then(res => {
        console.log(res.data.data);
        this.selectKbheaderlist = res.data.data;
      });
    },
    kj() {
      console.log(this.dwh);
      this.$http
        .post(`api/cultivate/kc/selectClassListByWeek`, {
          xnxq: this.xnxq,
          dwh: this.dwh,
          jhnj: this.jhnj,
          jsh: this.jsh,
          pyccm: this.pyccm,
          query: this.query,
          zyh: this.zyh
        })
        .then(res => {
          console.log(res.data.data);
          this.selectClassListByWeek = res.data.data;
        });
    }
  },
  mounted() {
    this.selectKbheader();
  },
  filters: {
    sxw(val) {
      var arr = ["上午", "下午", "晚上"];
      return arr[arr.findIndex((el, index) => index == val)];
    },
    sfmz(val) {
      // 1是每周,2单周,3双周
      if (val == "1") {
        return "每周";
      } else if (val == "2") {
        return "单周";
      } else if (val == "3") {
        return "双周";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.lbzh {
  height: 700px;
  overflow: hidden;
  overflow: auto;
  table {
    // border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    // text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    // line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      // line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 180px;
      .tableindex {
        width: 100%;
        overflow: hidden;
        overflow: auto;
        height: 150px;
        .tableindex_div {
          width: 80px;
          height: 60px;
          text-align: left;
          background: rgba(230, 247, 255, 1);
          color: #1890ff;
          border-radius: 10px;
          width: 90%;
          overflow: hidden;
          margin: 10px auto;
          border: 1px solid rgba(145, 213, 255, 1);
          padding: 5px;
          overflow: auto;
          .p3 {
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          .p1 {
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
      }
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
}
</style>
