<!-- 课程停开处理 -->
<template>
  <div class="classStop">
    <componment>
      <div slot="left">
        <el-input
          v-model="searchField"
          placeholder="请输入课程号/课程名称"
          style="width: 200px"
          clearable
          @keyup.enter.native="searchData"
          class="top-input"
          suffix-icon="el-icon-search"
          @clear="clearinput"
        ></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select
          v-model="time"
          filterable
          placeholder="全部学年学期"
          style="margin-left: 10px;"
          class="top-input"
          @change="xnxqselect"
        >
          <el-option
            v-for="(item, index) in timeList"
            :key="index"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
        <span style="font-size:16px">{{ message }}</span>
        <el-input
          type="number"
          style="width: 100px;"
          v-model="peopleNumber"
        ></el-input>
        <el-button @click="sruetable">确定</el-button>
      </div>
      <div slot="right">
        <el-button
          @click="stopX"
          type="primary"
          plain
          v-if="$btnAuthorityTest('classStop:set')"
          >课程停选设置</el-button
        >
        <el-button
          type="primary"
          @click="stopClass"
          v-if="$btnAuthorityTest('classStop:stop')"
          >课程停开</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%"
      @row-click="clickRow"
      @selection-change="mySelect"
      @select-all="allClick"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column
        :show-overflow-tooltip="true"
        type="selection"
        width="55"
      >
      </el-table-column>
      <el-table-column prop="kch" label="课程名称" width="200">
        <template slot-scope="scope">
          {{ scope.row.kch }}({{ scope.row.kcmc }})
        </template>
      </el-table-column>
      <el-table-column prop="kkdwh" label="开课单位" width="150">
      </el-table-column>
      <el-table-column
        prop="bjmc"
        label="教学班"
        width="280px"
        :show-overflow-tooltip="true"
      >
      </el-table-column>
      <el-table-column prop="jsxm" label="授课教师" width="280px">
      </el-table-column>
      <el-table-column
        prop="address"
        label="上课时间,地点"
        :show-overflow-tooltip="true"
      >
        <template slot-scope="scope">
          <div v-for="(item, index) in scope.row.pyPkkcSksjs" :key="index">
            <span>{{ item.zc }}周</span>&nbsp;&nbsp;<span
              >({{ item.sfmz | sfmz }})</span
            >&nbsp;&nbsp;<span>星期{{ item.xq | xq }}</span
            >&nbsp;<span>{{ item.kj }}</span
            >节&nbsp;&nbsp;&nbsp;<span>{{ item.jsmc }}&nbsp;&nbsp;&nbsp;</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="xkrsxd" label="听课人数" width="150">
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
      v-if="page"
    ></pagination>
    <el-dialog
      title="课程停选设置"
      :visible.sync="dialogVisible"
      width="750px"
      :close-on-click-modal="false"
    >
      <el-row style="margin-bottom:10px">
        <el-col :span="12"
          ><div class="grid-content bg-purple">
            <span>年级：</span>
            <el-select
              v-model="form.nj"
              filterable
              style="margin-left: 10px;width:150px"
              class="top-input"
              @change="kchListsh"
            >
              <el-option
                v-for="(item, index) in form.njList"
                :key="index"
                :label="item.njKey"
                :value="item.njValue"
              >
              </el-option>
            </el-select></div
        ></el-col>
        <el-col :span="12"
          ><div class="grid-content bg-purple-light">
            <span>培养层次：</span>
            <el-select
              v-model="form.pycc"
              filterable
              style="margin-left: 10px;width:120px"
              class="top-input"
              @change="kchListsh"
            >
              <el-option
                v-for="(item, index) in form.pyccmList"
                :key="index"
                :label="item.name"
                :value="item.code"
              >
              </el-option>
            </el-select></div
        ></el-col>
      </el-row>
      <el-row>
        <el-col :span="8"
          ><div class="grid-content bg-purple">
            <span>开课学院：</span>
            <el-select
              v-model="form.kkdw"
              filterable
              style="margin-left: 10px;width:150px"
              class="top-input"
              @change="kchListsh"
            >
              <el-option
                v-for="(item, index) in form.kkdwList"
                :key="index"
                :label="item.dwmc"
                :value="item.dwh"
              >
              </el-option>
            </el-select></div
        ></el-col>
        <el-col :span="12"
          ><div
            class="grid-content bg-purple-light"
            style="text-align: center;"
          >
            <span>停选课程：</span>
            <el-select
              v-model="form.kch"
              filterable
              style="margin-left: 10px;width:180px"
              class="top-input"
            >
              <el-option
                v-for="(item, index) in form.kchList"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select></div
        ></el-col>
        <el-col :span="4"
          ><div class="grid-content bg-purple">
            <el-button type="primary" style="margin-left:5px" @click="addlist"
              >添加</el-button
            >
          </div></el-col
        >
      </el-row>
      <div style="margin-bottom:15px;"></div>
      <table>
        <tr>
          <td
            class="listcss"
            colspan="8"
            style="text-align:left;font-weight:bold;background:#eee"
          >
            | 停选列表
          </td>
        </tr>
        <tr style="background:#eee">
          <td>年级</td>
          <td>培养层次</td>
          <td>开课学院</td>
          <td>课程</td>
          <td>操作</td>
        </tr>
        <tr v-for="(item, index) in form.list">
          <td>{{ item.nj }}级</td>
          <td>{{ item.pyccmc }}</td>
          <td>{{ item.dwmc }}</td>
          <td>{{ item.kcmc }}</td>
          <td>
            <i
              class="el-icon-remove"
              style="color:#F56C6C;font-size:24px;line-height:40px;"
              @click="form.list.splice(index, 1)"
            ></i>
          </td>
        </tr>
      </table>

      <span slot="footer" class="dialog-footer">
        <div style="text-align:center">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="saveTx">确 定</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "classStop",
  data() {
    return {
      form: {
        kkdw: "",
        kkdwList: [],
        timeList: [],
        nj: "",
        njList: [],
        pycc: "",
        pyccmList: [],
        kch: "",
        kchList: "",
        list: []
      },
      dialogVisible: false,
      page: true,
      peopleNumber: null,
      message: "听课人数<",
      searchField: "", // 搜索的数据
      tableData: [],
      timeList: [], // 开课单位列表
      time: "", // 选中开课单位
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      deleteList: [],
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  filters: {
    sfmz(val) {
      // 1是每周,2单周,3双周
      if (val == "1") {
        return "每周";
      } else if (val == "2") {
        return "单周";
      } else if (val == "3") {
        return "双周";
      }
    },
    xq(val) {
      if (val == 1) {
        return (val = "一");
      } else if (val == 2) {
        return (val = "二");
      } else if (val == 3) {
        return (val = "三");
      } else if (val == 4) {
        return (val = "四");
      } else if (val == 5) {
        return (val = "五");
      } else if (val == 6) {
        return (val = "六");
      } else {
        return (val = "日");
      }
    }
  },
  methods: {
    addlist() {
      if (
        !this.form.nj ||
        !this.form.kkdw ||
        !this.form.pycc ||
        !this.form.kch
      ) {
        return this.$message.error("不能进行添加");
      }
      var list = [];
      // this.form.kkdwList
      list = [...this.form.list];
      var index = list.find(x => x.kch === this.form.kch);
      if (index) {
        if (index.nj === this.form.nj || index.pycc === this.form.pycc) {
          return this.$message.error("同一年级、培养层次的停选课程不可重复！");
        }
      }
      // console.log(index);
      this.form.list.push({
        nj: this.form.nj,
        kkdw: this.form.kkdw,
        dwmc: this.form.kkdwList.find(el => el.dwh == this.form.kkdw).dwmc,
        pyccmc: this.form.pyccmList.find(el => el.code == this.form.pycc).name,
        pycc: this.form.pycc,
        kch: this.form.kch,
        kcmc: this.form.kchList.find(el => el.value == this.form.kch).label
      });
      // console.log(this.form.list)
    },
    kchListsh() {
      this.$http
        .post("api/cultivate/kc/selectByCollege", {
          kkdw: this.form.kkdw,
          nj: this.form.nj,
          pycc: this.form.pycc
        })
        .then(res => {
          // console.log(res.data);
          if (res.data.data && Array.isArray(res.data.data)) {
            this.form.kchList = res.data.data;
          } else {
            this.form.kchList = [];
            this.$message.error(res.data.message);
          }
          this.form.kch = "";
        });
    },
    saveTx() {
      let obj = [...this.form.list];
      if (obj.length == 0) return this.$message.error("提交内容不能为空!!");
      obj.forEach(x => {
        delete (x.dwmc, x.pyccmc, x.kcmc, x.kkdw);
      });
      this.$http.post("api/cultivate/kc/saveTx", obj).then(res => {
        if (res.data.code == 200) {
          this.dialogVisible = false;
          return this.$message.success(res.data.message);
        } else {
          return this.$message.error(res.data.message);
        }
      });
    },
    dialogList() {
      this.$http.get("api/cultivate/kc/selectLimit").then(res => {
        this.form.njList = res.data.data.nj;
        this.form.pyccmList = res.data.data.pyccm;
        this.form.kkdwList = res.data.data.dwList;
      });
    },
    infoList() {
      this.form.nj = "";
      this.form.kkdw = "";
      this.form.pycc = "";
      this.form.kch = "";
      this.$http.get("api/cultivate/kc/infoList").then(res => {
        this.form.list = res.data.data;
      });
    },
    stopX() {
      this.infoList();
      this.form.list = [];
      this.form.nj = this.form.njList[0].njValue;
      this.form.pycc = this.form.pyccmList[0].code;
      this.form.kkdw = this.form.kkdwList[0].dwh;
      this.kchListsh();
      setTimeout(() => {
        this.dialogVisible = true;
      }, 200);
    },
    clearinput() {
      this.fresh();
    },
    fresh() {
      this.page = false;
      setTimeout(() => {
        this.page = true;
      }, 500);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    takeList() {
      this.loading2 = true;
      var params = {};
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      var obj = {
        dwh: "",
        kcxz: "",
        nj: "",
        pyccm: "",
        query: this.searchField,
        xkrs: this.peopleNumber,
        xnxq: this.time,
        zyh: ""
      };
      this.$http
        .post(
          `api/cultivate/kc/selectKctk/${params.pageSize}/${params.pageNum}`,
          obj
        )
        .then(res => {
          this.loading2 = false;
          if (res.data.data.list.length > 0) {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          } else {
            this.tableData = [];
            this.total = 0;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    xnxqselect() {
      this.fresh();
    },
    searchData() {
      this.fresh();
    }, // 搜索数据方法
    stopClass() {
      this.deleteList.length == 0
        ? this.$message.error({
            message: "请勾选数据在进行课程停开"
          })
        : this.$confirm("是否确定停开该门课程?", "课程停开", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(() => {
              this.$http
                .put("api/cultivate/kc/Kctk/" + this.deleteList.join(","))
                .then(res => {
                  if (res.data.code == 200) {
                    this.$message({
                      message: "停开成功",
                      type: "success"
                    });
                    this.fresh();
                  } else {
                    this.$message.error({
                      message: "停开失败"
                    });
                  }
                });
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消课程停开"
              });
            });
    }, // 导出数据
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
    }, // 列表选择
    allClick(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
    },
    // 获取学年学期
    getyear() {
      this.$http.get("api/cultivate/kc/selectkkxq").then(res => {
        this.timeList = res.data.data.kkxq;
      });
    },
    sruetable() {
      const reg = /^[1-9]\d*$/g;
      if (!reg.test(this.peopleNumber)) {
        this.$message.error({
          message: "听课人数填写错误请重新填写!"
        });
        return false;
      }
      this.fresh();
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.getyear();
    this.dialogList();
  }
};
</script>

<style scoped lang="scss">
.classStop {
  width: 100%;
  padding-top: 7px;
  table {
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 36px;
      line-height: 36px;
      padding-left: 5px;
      text-align: center;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
  }
  .oldRegister /deep/ .el-dialog .el-dialog__footer {
    text-align: center;
    position: relative;
    top: -10px;
  }
  .oldRegister /deep/ .dialog-footer button {
    margin: 0 20px;
  }

  .oldRegister /deep/ .el-dialog__body {
    padding: 30px 20px 0px 20px;
  }

  .oldRegister /deep/ .el-dialog .el-dialog__body {
    padding: 20px 20px 15px 20px !important;
  }
}
</style>
