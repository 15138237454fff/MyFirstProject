<template>
  <div class="workloadManagement">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入工号/姓名"
          suffix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.xmmc"
          @keyup.enter.native="initLoadTable"
          style="width:200px;"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.ssyxh" @change="initLoadTable">
          <el-option label="全部学院" :value="null"></el-option>
          <el-option
            v-for="(item, index) in zyList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('workloadManagement:add')"
          >添加</el-button
        >
        <el-button
          @click="clickDelete"
          type="danger"
          v-if="$btnAuthorityTest('workloadManagement:delete')"
          >删除</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="selection"
          align="center"
          :width="50"
        ></el-table-column>
        <el-table-column prop="xm" label="教职工" align="center">
        </el-table-column>
        <el-table-column
          prop="dwmc"
          label="所属学院"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column label="学年学期" align="center" :width="200">
          <template slot-scope="scope">
            <span>{{
              `${scope.row.xn} ~ ${scope.row.xn + 1} ${scope.row.xq}`
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="kcjxgzl" label="课程教学工作量" align="center">
        </el-table-column>
        <el-table-column
          prop="yjszdgzl"
          label="研究生指导工作量"
          align="center"
        >
        </el-table-column>
        <el-table-column prop="fbdx" label="操作" align="center" :width="120">
          <template slot-scope="scope">
            <span
              class="orange under-line cursor-pointer"
              @click="clickToModify(scope.$index)"
              v-if="$btnAuthorityTest('workloadManagement:update')"
              >修改</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <table class="work-load-table">
          <tr>
            <td>教职工</td>
            <td>
              <el-select
                v-model="formData.jgh"
                filterable
                remote
                placeholder="请输入关键词"
                :remote-method="requireTeacherList"
                @change="handleTeacherChange"
                :loading="loading"
              >
                <el-option
                  v-for="(item, index) in teacherList"
                  :key="index"
                  :label="`${item.zdjsxm}(${item.zdjsgh})`"
                  :value="item.zdjsgh"
                >
                </el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td>
              所属学院
            </td>
            <td style="padding-left:5px">
              <span>{{ formData.ssyxmc }}</span>
            </td>
          </tr>
          <tr>
            <td>学年学期</td>
            <td class="xn-xq">
              <el-select v-model="formData.xn">
                <el-option
                  v-for="(item, index) in xnList"
                  :key="index"
                  :label="`${item} ~ ${item + 1}`"
                  :value="item"
                ></el-option>
              </el-select>
              <el-select v-model="formData.xq">
                <el-option label="春季学期" value="春季学期"></el-option>
                <el-option label="秋季学期" value="秋季学期"></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td>课程教学工作量</td>
            <td>
              <el-input-number
                v-model="formData.kcjxgzl"
                controls-position="right"
                placeholder="请输入"
                :min="0"
                :max="10000"
                :precision="1"
              ></el-input-number>
            </td>
          </tr>
          <tr>
            <td>研究生指导工作量</td>
            <td>
              <el-input-number
                v-model="formData.yjszdgzl"
                controls-position="right"
                placeholder="请输入"
                :min="0"
                :max="10000"
                :precision="1"
              ></el-input-number>
            </td>
          </tr>
        </table>
      </div>
      <div slot="footer">
        <el-button @click="clickCancel">取消</el-button>
        <el-button type="primary" @click="clickOk">确定</el-button>
      </div>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "workloadManagement",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        ssyxh: null
      },
      formData: {
        id: "",
        jgh: "",
        kcjxgzl: undefined,
        ssyxh: "",
        ssyxmc: "",
        xn: "",
        xq: "",
        yjszdgzl: undefined
      },
      loading: false,
      zyList: [],
      xnList: [],
      teacherList: [],
      selectedHistoryList: [],
      msgCount: 0,
      tableHeight: null,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-workload-management"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-modal": myModal
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    // 初始化学年学期
    this.initXnList();
    this.loadTable();
    this.requireZyList();
    this.requireTeacherList("");
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/cultivate/workManager/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击添加
    clickAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = `add`;
      this.modalOption.modalVisiabal = true;
    },
    handleAdd() {
      console.log("保存");
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/cultivate/workManager/save", this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("添加成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 点击删除
    clickDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleDelete,
        title: "删除信息",
        msgOne: "确定删除已选记录？",
        msgTwo: ""
      });
    },
    // 处理删除
    handleDelete() {
      console.log("处理删除");
      let ids = this.selectedHistoryList.map(el => el.id);
      this.$http
        .delete("/api/cultivate/workManager/delete", { data: ids })
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("删除成功");
          this.initLoadTable();
        })
        .catch(err => {
          console.log(err.message);
        });
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    clickToModify(index) {
      this.modalOption.title = `修改`;
      this.modalOption.key = `modify`;
      this.modalOption.modalVisiabal = true;
      this.dataCallBack(index);
    },
    dataCallBack(index) {
      let tmpObj = this.tableData[index];
      this.formData.id = tmpObj.id;
      this.formData.jgh = tmpObj.jgh;
      this.formData.ssyxh = tmpObj.ssyxh;
      this.formData.ssyxmc = tmpObj.dwmc;
      this.formData.kcjxgzl = tmpObj.kcjxgzl;
      this.formData.yjszdgzl = tmpObj.yjszdgzl;
      this.formData.xn = tmpObj.xn;
      this.formData.xq = tmpObj.xq;
    },
    handleModify() {
      console.log("修改");
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put("/api/cultivate/workManager/update", this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    clickOk() {
      let result = this.testFormData();
      if (!result.sign) {
        this.$message.error(result.msg);
        return;
      }
      if (this.modalOption.key === "add") {
        this.handleAdd();
      }
      if (this.modalOption.key === "modify") {
        this.handleModify();
      }
    },
    // 表单验证
    testFormData() {
      let sign = true,
        msg = "",
        testKeys = ["xq", "xn", "ssyxh", "jgh"];
      testKeys.forEach(key => {
        if (this.formData[key] === "") {
          msg = "请填写完整后再尝试保存";
          sign = false;
        }
      });
      if (
        this.formData.kcjxgzl === undefined ||
        this.formData.yjszdgzl === undefined
      ) {
        msg = "请填写完整后再尝试保存";
        sign = false;
      }
      return { sign, msg };
    },
    clickCancel() {
      this.modalOption.modalVisiabal = false;
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearFormData();
      }
    },
    clearFormData() {
      this.formData = {
        id: "",
        jgh: "",
        kcjxgzl: undefined,
        ssyxh: "",
        ssyxmc: "",
        xn: "",
        xq: "",
        yjszdgzl: undefined
      };
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val;
    },
    // 请求专业列表
    requireZyList() {
      this.$http.get(`/api/system/dict/select/education/major`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.zyList = data;
      });
    },
    // 请求教职工列表
    requireTeacherList(query) {
      this.loading = true;
      this.$http
        .get(`/api/baseservice/jzg/education/search`, {
          params: {
            query
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (!Array.isArray(data)) {
            console.error("教职工列表数据获取失败");
            return false;
          }
          this.teacherList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 处理教师选择改变
    handleTeacherChange(gh) {
      let tmpObj = this.teacherList.find(el => {
        return el.zdjsgh === gh;
      });
      if (!tmpObj) {
        return;
      }
      this.formData.ssyxh = tmpObj.ssyxh;
      this.formData.ssyxmc = tmpObj.ssyxmc;
    },
    // 初始化学年学期
    initXnList() {
      this.$http.get("/api/cultivate/pycssz/acadYearTermHisList").then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error("获取学年列表失败");
          return;
        }
        let tmpArr = data.data.map(el => {
          return parseInt(el.value.split("-")[0]);
        });
        this.xnList = Array.from(new Set(tmpArr));
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.workloadManagement {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-workload-management {
  width: 500px;
  .modal-content {
    padding: 10px;
    .work-load-table {
      width: 100%;
      td {
        border: 1px solid #e5e5e5;
        height: 40px;
      }
      td:first-child {
        background: #eee;
        padding-left: 5px;
        width: 150px;
      }
      .xn-xq {
        .el-select {
          &:first-child {
            width: 60%;
          }
          &:last-child {
            width: 38%;
          }
        }
      }

      td:last-child {
        padding: 0;
        & > div {
          width: 100%;
        }
        .el-input-number {
          width: 120px;
        }
      }
    }
  }
}
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
