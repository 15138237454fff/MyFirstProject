<!-- 学位点信息维护 -->
<template>
  <div class="degreeProgram">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="searchField"
          placeholder="请输入学位点名称"
          style="width: 200px"
          @keyup.enter.native="searchData"
          clearable
          @clear="clearinput"
          suffix-icon="el-icon-search"
        ></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select
          v-model="college"
          filterable
          placeholder="全部学院"
          style="margin-left: 10px;"
          @change="takeList()"
        >
          <el-option value="">全部学院</el-option>
          <el-option
            v-for="item in collegeList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('degreeProgram:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="deleteInfor"
          v-if="$btnAuthorityTest('degreeProgram:delete')"
          >删除</el-button
        >
        <el-button
          @click="exportInfo"
          v-if="$btnAuthorityTest('degreeProgram:export')"
          >导出</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%"
      @selection-change="mySelect"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column prop="zyh" label="学位点代码" width="150">
      </el-table-column>
      <el-table-column prop="zymc" label="学位点名称"> </el-table-column>
      <el-table-column prop="zyjc" label="学位点简称"> </el-table-column>
      <el-table-column prop="lx" label="学位点类型">
        <template slot-scope="scope">
          <span>{{ scope.row.lx | lx(getEnrList) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="xkmlmc" label="学科门类"> </el-table-column>
      <el-table-column prop="sqjbmc" label="授权级别"> </el-table-column>
      <el-table-column prop="dwmc" label="所属学院"> </el-table-column>
      <el-table-column
        prop="xwdfzrxm"
        label="学位点负责人"
        :show-overflow-tooltip="true"
      >
        <template slot-scope="scope">
          <span class="flltermore">{{ scope.row.xwdfzrxm }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="checkDetails(scope.row)"
            v-if="$btnAuthorityTest('degreeProgram:view')"
            >查看</span
          ><span> | </span
          ><span
            class="tablexg"
            @click="checkxg(scope.row)"
            v-if="$btnAuthorityTest('degreeProgram:update')"
            >修改</span
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
      v-if="pageshow"
    ></pagination>
    <el-dialog
      title="学位点详情"
      :visible.sync="detailsDialog"
      :before-close="handleClose"
      width="380px"
      class="detailsCheck"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form :model="detailsForm" label-width="125px" ref="detailsForm">
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点代码：" :required="true">
              <el-input
                style="width:200px"
                v-model="detailsForm.zyh"
                :disabled="true"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点名称：">
              <el-input
                style="width:200px"
                v-model="detailsForm.zymc"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点简称：">
              <el-input
                style="width:200px"
                v-model="detailsForm.zyjc"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点类型：">
              <el-radio-group v-model="detailsForm.lx">
                <el-radio
                  :label="item.code"
                  style="margin-right:5px"
                  v-for="item in getEnrList"
                  :key="item.code"
                  :disabled="true"
                  >{{ item.name }}</el-radio
                >
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学科门类：">
              <el-select
                v-model="detailsForm.xkmlm"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                :disabled="isShow"
              >
                <el-option
                  v-for="(item, index) in typeList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="授权级别：">
              <el-select
                v-model="detailsForm.sqjbm"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                :disabled="isShow"
              >
                <el-option
                  v-for="(item, index) in levelList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="所属学院：">
              <el-select
                v-model="detailsForm.dwh"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                :disabled="isShow"
              >
                <el-option
                  v-for="(item, index) in collegeList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-form-item label="学位点负责人：" :required="true">
            <el-select
              v-model="detailsForm.xwdfzr"
              filterable
              remote
              placeholder="请输入教职工姓名查询"
              :remote-method="queryTutorByName"
              :loading="tutorLoading"
              style="width:200px"
              @change="teacherSelectChange"
              :disabled="isShow"
            >
              <el-option
                v-for="(item, index) in teacherList"
                :key="index"
                :value="item.gh"
                :label="item.xm + item.gh"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-row>
      </el-form>
    </el-dialog>
    <el-dialog
      :title="additional"
      :visible.sync="addDialog"
      :before-close="handleClose"
      width="500px"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form :model="addForm" label-width="125px" ref="addForm">
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点代码：" :required="true">
              <el-input style="width:200px" v-model="addForm.zyh"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点名称：" :required="true">
              <el-input style="width:200px" v-model="addForm.zymc"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点简称：">
              <el-input style="width:200px" v-model="addForm.zyjc"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学位点类型：" :required="true">
              <div>
                <el-radio-group v-model="addForm.lx">
                  <el-radio
                    :label="item.code"
                    style="margin-right:5px"
                    v-for="item in getEnrList"
                    :key="item.code"
                    >{{ item.name }}</el-radio
                  >
                </el-radio-group>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="学科门类：" :required="true">
              <el-select
                v-model="addForm.xkmlm"
                filterable
                placeholder="请选择"
                style="width: 200px;"
              >
                <el-option
                  v-for="(item, index) in typeList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="授权级别：" :required="true">
              <el-select
                v-model="addForm.sqjbm"
                filterable
                placeholder="请选择"
                style="width: 200px;"
              >
                <el-option
                  v-for="(item, index) in levelList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="所属学院：" :required="true">
              <el-select
                v-model="addForm.dwh"
                filterable
                placeholder="请选择"
                style="width: 200px;"
              >
                <el-option
                  v-for="(item, index) in collegeList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-form-item label="学位点负责人：" :required="true">
            <el-select
              v-model="addForm.xwdfzr"
              filterable
              remote
              placeholder="请输入教职工姓名查询"
              :remote-method="queryTutorByName"
              :loading="tutorLoading"
              style="width:200px"
              @change="teacherSelectChange"
            >
              <el-option
                v-for="(item, index) in teacherList"
                :key="index"
                :value="item.gh"
                :label="item.xm + item.gh"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="addaffirm">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "degreeProgram",
  data() {
    return {
      tutorLoading: false,
      isShow: true,
      detailsForm: {
        zyh: "",
        zymc: "",
        xkmlm: "",
        sqjbm: "",
        dwh: "",
        xwdfzr: ""
      }, // 查看详情列表
      addForm: {
        zyh: "",
        zymc: "",
        xkmlm: "",
        sqjbm: "",
        dwh: "",
        xwdfzr: "",
        lx: "1"
      }, // 添加班级列表
      addDialog: false, // 添加班级
      detailsDialog: false, // 查看详情
      searchField: "", // 搜索的数据
      tableData: [],
      collegeList: [], // 单位列表
      typeList: [], // 学科门类列表
      levelList: [], // 授权级别列表
      teacherList: [],
      college: "", // 选中学院
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      deleteList: [],
      deleteDialog: false,
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      additional: "添加学位点",
      pageshow: true,
      getEnrList: []
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  filters: {
    lx(val, arr) {
      if (val && arr) {
        return (val = arr.find(v => v.code == val).name);
      }
    }
  },
  methods: {
    checkxg(row) {
      this.additional = "修改学位点";
      this.isShow = true;
      this.addDialog = true;
      var rowtable = JSON.parse(JSON.stringify(row));
      this.addForm = rowtable;
      this.rowid = rowtable.id;
      this.queryTutorByNameRemote(rowtable.xwdfzrxm);
    },
    teacherSelectChange() {},
    // 下拉框通过教师姓名查询教师信息
    queryTutorByName(query) {
      if (query !== "") {
        this.loading = true;
        setTimeout(() => {
          this.queryTutorByNameRemote(query);
        }, 200);
      } else {
        this.teacherList = [];
      }
    },
    freshform() {
      this.pageshow = false;
      setTimeout(() => {
        this.pageshow = true;
      }, 500);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    // 远程查询
    queryTutorByNameRemote(query) {
      this.$http
        .get("api/cultivate/teacher/selectByQuery/" + query)
        .then(res => {
          this.loading = false;
          if (res.data.code == 200) {
            this.teacherList = res.data.data;
          }
        });
    },
    clearinput() {
      this.searchField = "";
      this.freshform();
    },
    modifHandle() {
      this.isShow = false;
    },
    cancel() {
      this.addDialog = false;
      this.addForm = { lx: "1" };
    }, // 取消添加
    closeDia() {
      this.$http
        .delete("api/cultivate/enroll", { data: this.deleteList })
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "删除成功",
              type: "success"
            });
            this.deleteDialog = false;
            this.freshform();
          } else {
            this.$message.error({
              message: res.data.message
            });
          }
        });
    },
    addaffirm() {
      let flag = true;
      // 验证表单
      var formset = ["zyh", "zymc", "xkmlm", "sqjbm", "dwh", "xwdfzr"];
      formset.forEach(el => {
        if (flag) {
          if (this.addForm[el] == "") {
            this.$message({
              type: "error",
              message: "请将信息填写完整"
            });
            flag = false;
          }
        }
      });
      // 表单验证成功添加
      if (flag) {
        if (this.additional == "添加学位点") {
          this.$http.post("api/cultivate/enroll/", this.addForm).then(res => {
            if (res.data.code == 200) {
              this.$message({
                type: "success",
                message: "添加成功"
              });
              this.addDialog = false;
              this.freshform();
              this.empty();
            } else {
              this.$message.error(res.data.message);
            }
          });
        }
        if (this.additional == "修改学位点") {
          this.$http
            .put("api/cultivate/enroll/" + this.rowid, this.addForm)
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  type: "success",
                  message: "修改成功"
                });
                this.addDialog = false;
                this.freshform();
                this.empty();
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
    }, // 确认添加
    takeList() {
      this.xwdlx();
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/cultivate/enroll/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          collegeCode: this.college
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.info;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    mytakeList() {
      this.$http.get("api/system/dict/select/all").then(res => {
        this.typeList = res.data.data.xkml;
        this.levelList = res.data.data.sqjb;
      });
      this.$http.get("api/system/dept/select").then(res => {
        this.collegeList = res.data.data;
      });
    },
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.zyh);
      });
    }, // 列表选择
    searchData() {
      this.freshform();
    }, // 搜索数据方法
    addNew() {
      this.addDialog = true;
      this.additional = "添加学位点";
      this.empty();
    }, // 添加数据
    deleteInfor() {
      this.deleteList.length == 0
        ? this.$message.error({ message: "请选择数据！" })
        : (this.deleteDialog = true);
    }, // 删除数据
    exportInfo() {}, // 导出数据
    xwdlx() {
      this.$http.get("api/cultivate/enroll/getEnrList").then(res => {
        this.getEnrList = res.data.data;
      });
    },
    checkDetails(row) {
      this.isShow = true;
      this.detailsDialog = true;
      this.detailsForm.zyh = row.zyh;
      this.detailsForm.zymc = row.zymc;
      this.detailsForm.xkmlm = row.xkmlm;
      this.detailsForm.sqjbm = row.sqjbm;
      this.detailsForm.dwh = row.dwh;
      this.detailsForm.xwdfzr = row.xwdfzr;
      this.detailsForm.zyjc = row.zyjc;
      this.detailsForm.lx = row.lx;
      this.xwdlx();
      this.rowid = row.zyh;
      this.queryTutorByNameRemote(row.xwdfzrxm);
    }, // 查看详情
    handleClose(done) {
      done();
    }, // 关闭弹出框
    empty() {
      this.addForm = { lx: "1" };
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.mytakeList();
  }
};
</script>

<style scoped lang="scss">
.degreeProgram {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
  /deep/ .el-input.is-disabled .el-input__inner {
    background: #fff;
  }
}
</style>
