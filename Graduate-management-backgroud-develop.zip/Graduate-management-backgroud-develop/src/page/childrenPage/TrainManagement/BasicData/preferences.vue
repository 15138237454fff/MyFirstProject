<!-- 基础参数设置 -->
<template>
  <div class="preferences" v-loading="loading2" element-loading-text="加载中">
    <div class="title">
      <span class="span_container">{{ remark }}</span>
      <span class="span_container">{{ time }} {{ timezq }}</span>
      <el-button type="primary" @click="showAcademic">设置学年学期</el-button>
    </div>
    <div class="container">
      <el-form :model="addForm" label-width="150px" ref="form" v-if="addForm.lszc">
        <el-row>
          <el-form-item label="老生注册时间：">
            <el-radio-group v-model="addForm.lszc.isOpen" @change="
                (addForm.lszc.startTime = ''), (addForm.lszc.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.lszc.isOpen === 1">
              <el-date-picker v-model="addForm.lszc.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.lszc.startTime,
                    addForm.lszc.endTime,
                    '老生注册时间'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.lszc.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.lszc.startTime,
                    addForm.lszc.endTime,
                    '老生注册时间'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="制定专业培养方案：">
            <el-radio-group v-model="addForm.pyfazd.isOpen" @change="
                (addForm.pyfazd.startTime = ''), (addForm.pyfazd.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.pyfazd.isOpen === 1">
              <el-date-picker v-model="addForm.pyfazd.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.pyfazd.startTime,
                    addForm.pyfazd.endTime,
                    '制定专业培养方案'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.pyfazd.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.pyfazd.startTime,
                    addForm.pyfazd.endTime,
                    '制定专业培养方案'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="制定开课方案：">
            <el-radio-group v-model="addForm.kkfazd.isOpen" @change="
                (addForm.kkfazd.startTime = ''), (addForm.kkfazd.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.kkfazd.isOpen === 1">
              <el-date-picker v-model="addForm.kkfazd.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.kkfazd.startTime,
                    addForm.kkfazd.endTime,
                    '制定开课方案'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.kkfazd.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.kkfazd.startTime,
                    addForm.kkfazd.endTime,
                    '制定开课方案'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="制定个人培养计划：">
            <el-radio-group v-model="addForm.grxxjh.isOpen" @change="
                (addForm.grxxjh.startTime = ''), (addForm.grxxjh.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.grxxjh.isOpen == 1">
              <el-date-picker v-model="addForm.grxxjh.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.grxxjh.startTime,
                    addForm.grxxjh.endTime,
                    '制定个人培养计划'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.grxxjh.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.grxxjh.startTime,
                    addForm.grxxjh.endTime,
                    '制定个人培养计划'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="学生在线选课：">
            <el-radio-group v-model="addForm.xsxksj.isOpen" @change="
                (addForm.xsxksj.startTime = ''), (addForm.xsxksj.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.xsxksj.isOpen == 1">
              <el-date-picker v-model="addForm.xsxksj.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.xsxksj.startTime,
                    addForm.xsxksj.endTime,
                    '学生在线选课'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.xsxksj.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.xsxksj.startTime,
                    addForm.xsxksj.endTime,
                    '学生在线选课'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="学生在线退补选：">
            <el-radio-group v-model="addForm.tbxsj.isOpen" @change="
                (addForm.tbxsj.startTime = ''), (addForm.tbxsj.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.tbxsj.isOpen == 1">
              <el-date-picker v-model="addForm.tbxsj.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.tbxsj.startTime,
                    addForm.tbxsj.endTime,
                    '学生在线退补选'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.tbxsj.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.tbxsj.startTime,
                    addForm.tbxsj.endTime,
                    '学生在线退补选'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="在线录入成绩：">
            <el-radio-group v-model="addForm.cglrsj.isOpen" @change="
                (addForm.cglrsj.startTime = ''), (addForm.cglrsj.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.cglrsj.isOpen == 1">
              <el-date-picker v-model="addForm.cglrsj.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.cglrsj.startTime,
                    addForm.cglrsj.endTime,
                    '在线录入成绩'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.cglrsj.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.cglrsj.startTime,
                    addForm.cglrsj.endTime,
                    '在线录入成绩'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="四六级英语报名：">
            <el-radio-group v-model="addForm.cet.isOpen" @change="(addForm.cet.startTime = ''), (addForm.cet.endTime = '')">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.cet.isOpen == 1">
              <el-date-picker v-model="addForm.cet.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.cet.startTime,
                    addForm.cet.endTime,
                    '四六级英语报名'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.cet.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.cet.startTime,
                    addForm.cet.endTime,
                    '四六级英语报名'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="学生在线评教：">
            <el-radio-group v-model="addForm.jypjsj.isOpen" @change="
                (addForm.jypjsj.startTime = ''), (addForm.jypjsj.endTime = '')
              ">
              <el-radio :label="0">关闭</el-radio>
              <el-radio :label="1">开启</el-radio>
            </el-radio-group>
            <span v-if="addForm.jypjsj.isOpen == 1">
              <el-date-picker v-model="addForm.jypjsj.startTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" style="margin-left: 10px;" @change="
                  timeChange(
                    addForm.jypjsj.startTime,
                    addForm.jypjsj.endTime,
                    '学生在线评教'
                  )
                ">
              </el-date-picker>&nbsp;&nbsp;<span>-</span>&nbsp;&nbsp;
              <el-date-picker v-model="addForm.jypjsj.endTime" type="date" value-format="yyyy-MM-dd" placeholder="选择日期" @change="
                  timeChange(
                    addForm.jypjsj.startTime,
                    addForm.jypjsj.endTime,
                    '学生在线评教'
                  )
                ">
              </el-date-picker>
            </span>
            <el-button type="primary" @click="saveData" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
        <el-row>
          <el-form-item label="学期总周次设置：">
            <span style="margin-left:10px;">
              <el-input v-model.number="autumnNum" style="width:220px;margin-right:20px;" :min="1">
                <template slot="prepend">秋季学期</template>
                <template slot="append">周</template>
              </el-input>
              <el-input v-model.number="springNum" style="width:220px" :min="1">
                <template slot="prepend">春季学期</template>
                <template slot="append">周</template>
              </el-input>
            </span>
            <el-button type="primary" @click="autumnspringNum" class="saveForm">保存</el-button>
          </el-form-item>
        </el-row>
      </el-form>
    </div>
    <el-dialog title="设置学年学期" :visible.sync="dialogVisible" width="550px">
      <el-select v-model="form.xyxq" filterable placeholder="请选择" style="margin-left: 10px;">
        <el-option v-for="(item, index) in xyxqList" :key="index" :label="item.name" :value="item.code">
        </el-option>
      </el-select>
      <el-select v-model="form.xq" filterable placeholder="请选择" style="margin-left: 10px;">
        <el-option v-for="(item, index) in semesterList" :key="index" :label="item.name" :value="item.code">
        </el-option>
      </el-select>
      <span slot="footer" class="dialog-footer">
        <div class="footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="pycssz">确 定</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "preferences",
  data() {
    return {
      // 学年学期
      time: "",
      timezq: "",
      addForm: {},
      myyear: "", // 选中的年份
      semester: "", // 选中的学期
      key: "",
      loading2: false,
      dialogVisible: false,
      remark: "",
      form: {
        xyxq: "",
        xq: ""
      },
      autumnNum: null,
      springNum: null,
      xyxqList: [],
      semesterList: [] // 学期列表
    };
  },
  watch: {
    "form.xyxq": {
      handler: function(val) {
        const flag = this.xyxqList.filter(item => item.code === val);
        if (!flag) {
          return false;
        }
        this.semesterList = flag[0].list;
      }
    }
  },
  methods: {
    autumnspringNum() {
      if (!this.autumnNum || !this.springNum) {
        return this.$message.error("请完整填写学期总周次设置参数");
      }
      this.$http
        .put("api/cultivate/pycssz/putWeekNum", {
          autumnNum: this.autumnNum,
          springNum: this.springNum
        })
        .then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            this.getNumber();
            this.getYear();
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    pycssz() {
      if (!this.form.xyxq || !this.form.xq) {
        return this.$message.error("当前选项不能为空!");
      }
      this.$http
        .put("api/cultivate/pycssz", {
          key: "current_academic",
          main: {
            year: this.form.xyxq,
            semester: this.form.xq
          }
        })
        .then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            this.getNumber();
            this.getYear();
            this.dialogVisible = false;
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    timeChange(startTime, endTime, val) {
      this.getYearList().then(res => {
        if (startTime) {
          if (startTime < res) {
            return this.$message.error(`${val}不能小于当前日期`);
          }
        }
        if (startTime && endTime) {
          if (startTime > endTime) {
            return this.$message.error(`${val}开始日期不能大于结束日期`);
          }
        }
      });
    },
    getYearList() {
      return new Promise(function(resolve, reject) {
        var date = new Date();
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
          month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
        }
        var currentdate = year + seperator1 + month + seperator1 + strDate;
        resolve(currentdate);
      });
    },
    xnxqParams() {
      this.$http.get("api/cultivate/pycssz/acadYearTermList").then(res => {
        if (!Array.isArray(res.data.data)) {
          return this.$message.error("数据获取失败！");
        } else {
          this.xyxqList = res.data.data;
        }
      });
    },
    showAcademic() {
      this.dialogVisible = true;
    },
    getYear() {
      this.$http.get("api/cultivate/pycssz/acadmic").then(res => {
        this.loading2 = false;
        this.remark = res.data.data.remark;
        this.time = `${res.data.data.main.year}年`;
        this.form.xyxq = res.data.data.main.year;
        this.form.xq = res.data.data.main.semester;
        if (res.data.data.main.semester == "2") {
          this.timezq = "春季学期";
        }
        if (res.data.data.main.semester == "1") {
          this.timezq = "秋季学期";
        }
      });
      this.$http.get("api/cultivate/pycssz/zc").then(res => {
        this.autumnNum = res.data.data.main.autumnNum;
        this.springNum = res.data.data.main.springNum;
      });
    }, // 获取当前学年学期
    getNumber() {
      this.$http.get("api/cultivate/pycssz/pycs").then(res => {
        this.key = res.data.data.key;
        this.addForm = res.data.data.main;
      });
    }, // 获取当前参数信息
    saveData() {
      let main = this.addForm;
      Object.keys(main).forEach(key => {
        if (main[key].startTime !== "") {
          console.log(main[key].startTime);
          main[key].startTime =
            this.$tagTime(main[key].startTime, "yyyy-MM-dd") + " 00:00:00";
        }
        if (main[key].endTime !== "") {
          main[key].endTime =
            this.$tagTime(main[key].endTime, "yyyy-MM-dd") + " 23:59:59";
        }
      });
      const obj = {
        key: this.key,
        main
      };
      this.$http.put("api/cultivate/pycssz", obj).then(res => {
        console.log(res.data.code);
        if (res.data.code == 400) {
          this.$message({
            type: "success",
            message: res.data.message
          });
        } else {
          this.$message({
            type: "error",
            message: res.data.message
          });
        }
      });
    }
  },
  mounted() {
    this.loading2 = true;
    this.getYear();
    this.getNumber();
    this.xnxqParams();
    console.log();
    console.log();
  }
};
</script>

<style scoped lang="scss">
.preferences {
  width: 100%;
  position: relative;
  /deep/ .el-input-group__prepend {
    border: 1px solid #dcdfe6 !important;
  }
  /deep/ .el-form-item__content {
    line-height: none !important;
  }
  .title {
    width: 100%;
    height: 60px;
    padding: 10px 0 10px 15px;
    box-sizing: border-box;
    border-bottom: 1px solid #e4e4e4;
    border-top: 1px solid #e4e4e4;
    .span_container {
      font-family: "Microsoft Tai Le";
      font-weight: 400;
      font-style: normal;
      font-size: 14px;
      color: #1890ff;
    }
  }
  .container {
    height: 500px;
    position: absolute;
    left: 50%;
    margin-left: -400px;
    top: 100px;
    .saveForm {
      margin-left: 15px;
    }
  }
  .footer {
    text-align: center;
  }
}
</style>
