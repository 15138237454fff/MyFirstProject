<template>
  <div class="classInformation">
    <componment>
      <div slot="left" style="flex:1">
        <el-input v-model="searchField" placeholder="请输入班级名称" style="width: 200px" clearable suffix-icon="el-icon-search" @clear="reset"></el-input>
        <el-button style="margin-left:5px" @click="reset">查询</el-button>
        <el-select v-model="college" filterable placeholder="全部学院" style="margin-left: 10px;">
          <el-option v-for="(item, index) in collegeLists" :key="index" :label="item.dwmc" :value="item.dwh">
          </el-option>
        </el-select>
        <el-select v-model="major" filterable placeholder="全部专业" style="margin-left: 10px;">
          <el-option v-for="(item, index) in majorListlist" :key="index" :label="item.zymc" :value="item.zyh">
          </el-option>
        </el-select>
        <el-select v-model="classform" filterable style="margin-left: 10px;" class="top-input">
          <el-option v-for="(item, $index) in classList" :key="$index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right" style="flex:1">
        <el-button type="primary" @click="addClass" v-if="$btnAuthorityTest('classInformation:generate')">批量建班</el-button>
        <el-button type="primary" @click="addNew" v-if="$btnAuthorityTest('classInformation:add')">添加</el-button>
        <el-button type="danger" @click="deleteInfor" v-if="$btnAuthorityTest('classInformation:delete')">删除</el-button>
        <el-button @click="exportInfo" v-if="$btnAuthorityTest('classInformation:export')">导出</el-button>
      </div>
    </componment>
    <el-table :data="tableData" border ref="multipleTable" style="width: 100%" @selection-change="handleSelectionChange" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
      <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
      </el-table-column>
      <el-table-column prop="bh" label="班号" width="150"> </el-table-column>
      <el-table-column prop="bjmc" label="班级名称"> </el-table-column>
      <el-table-column prop="bjxz" label="班级性质"> </el-table-column>
      <el-table-column prop="ssxymc" label="所属学院">
        <template slot-scope="scope">
          <span class="flltermore">{{ scope.row.ssxymc }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="zymc" label="所属专业" :show-overflow-tooltip="true">
        <template slot-scope="scope">
          <span class="flltermore">{{ scope.row.zymc }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="pycc" label="培养层次"> </el-table-column>
      <el-table-column prop="nj" label="年级"> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span type="text" @click="checkDetails(scope.row)" class="tablexq" v-if="$btnAuthorityTest('classInformation:view')">查看</span>
          <span v-if="
              $btnAuthorityTest('classInformation:view') &&
                $btnAuthorityTest('classInformation:update')
            ">|</span>
          <span type="text" @click="modify(scope.row)" class="tablexg" v-if="$btnAuthorityTest('classInformation:update')">修改</span>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="tablelist" v-if="pageshow"></pagination>
    <el-dialog :title="titleshow" :visible.sync="addDialog" width="690px" :close-on-click-modal="false">
      <p class="hr"></p>
      <el-form :model="addForm" label-width="100px" ref="addForm">
        <el-row>
          <el-col :span="10">
            <el-form-item label="班级名称：" :required="true">
              <el-input style="width:200px" v-model="addForm.bjmc" :disabled="show"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="年级：" :required="true">
              <el-select v-model="addForm.nj" placeholder="请选择" style="width: 200px;" :disabled="ishow">
                <el-option v-for="(item, index) in yearList" :key="index" :label="item" :value="item">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="班级性质：" :required="true">
              <el-checkbox-group v-model="addForm.classNature" :disabled="ishow">
                <el-checkbox label="行政班"></el-checkbox>
                <el-checkbox label="教学班"></el-checkbox>
              </el-checkbox-group>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="培养层次：" :required="true">
              <el-select v-model="addForm.pycc" filterable placeholder="请选择" style="width: 200px;" :disabled="ishow">
                <el-option v-for="(item, index) in levelList" :key="index" :label="item.name" :value="item.code">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属学院：" :required="true">
              <el-select v-model="addForm.ssxydm" filterable placeholder="请选择" style="width: 200px;" :multiple="allselect" :disabled="show" @change="selectall">
                <el-option v-for="(item, index) in schoolList" :key="index" :label="item.dwmc" :value="item.dwh" :disabled="item.disabled">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="所属专业：" :required="true">
              <el-select v-model="addForm.zyh" filterable placeholder="请选择" style="width: 200px;" :multiple="allselect" :disabled="show">
                <el-option v-for="(item, index) in majorList" :key="index" :label="item.zymc" :value="item.zyh">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <!-- <el-col :span="10">
            <el-form-item label=" 限定人数：" v-if="classNatures.toString() == '教学班' ">
              <el-input style="width:200px" v-model="addForm.xdrs" :disabled="show"></el-input>
            </el-form-item>
          </el-col> -->
          <el-col :span="10">
            <el-form-item label="辅导员：" v-if="
                classNatures.toString() == '行政班' ||
                  classNatures.toString() == '行政班,教学班' ||
                  classNatures.toString() == '教学班,行政班'
              ">
              <el-select style="width:200px" v-model="addForm.fdygh" filterable remote reserve-keyword placeholder="辅导员选择" :remote-method="remoteMethod" :loading="loading" :disabled="show" suffix="el-icon-search">
                <el-option v-for="item in teacher" :key="item.value" :label="item.info" :value="item.gh">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-form-item label="关联课程：" v-if="classNatures.toString() == '教学班'" :required="true">
              <el-select style="width:200px" v-model="addForm.kch" filterable multiple remote reserve-keyword placeholder="请选择" :disabled="show" :remote-method="remoteMethods" suffix="el-icon-search" :loading="loadings">
                <el-option v-for="(item, index) in glkcList" :key="index" :label="item.info" :value="item.gh">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div style="text-align:center">
        <span slot="footer" class="dialog-footer" v-if="titleshow == '添加'">
          <el-button @click="addDialog = false">取 消</el-button>
          <el-button type="primary" @click="addforms">确 定</el-button>
        </span>
        <span slot="footer" class="dialog-footer" v-if="titleshow == '修改'">
          <el-button @click="addDialog = false">取 消</el-button>
          <el-button type="primary" @click="xgbtn">确 定</el-button>
        </span>
      </div>
    </el-dialog>
    <el-dialog title="批量建班" :visible.sync="addClassDialog" width="490px" :close-on-click-modal="false">
      <p class="hr"></p>
      <el-form :model="addClassForm" label-width="150px" ref="addForm">
        <el-form-item label="请选择年级：" :required="true">
          <el-select v-model="addClassForm.nj" placeholder="请选择" style="width: 200px;" @change="addClassForm.jxb = null">
            <el-option v-for="(item, index) in addClassForm.yearList" :key="index" :label="item" :value="item">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="请选择培养层次：" :required="true">
          <el-checkbox v-model="addClassForm.ss" label="硕士" @change="addClassForm.jxb = null"></el-checkbox>
          <el-checkbox v-model="addClassForm.bs" label="博士" @change="addClassForm.jxb = null"></el-checkbox>
        </el-form-item>
        <el-form-item label="是否为教学班：" :required="true">
          <el-radio-group v-model="addClassForm.jxb">
            <el-radio :label="true">是</el-radio>
            <el-radio :label="false">否</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div style="text-align:center">
        <span slot="footer" class="dialog-footer">
          <el-button @click="addClassDialog = false">取 消</el-button>
          <el-button type="primary" @click="addformClass" :disabled="checkBat">确 定</el-button>
        </span>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import "@/components/common/common.scss";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "classInformation",
  components: {
    pagination,
    componment
  },
  computed: {
    classNatures() {
      return [...this.addForm.classNature];
    }
  },
  watch: {
    college: {
      handler(val) {
        this.menu(val).then(res => {
          this.majorListlist = res;
        });
        this.reset();
      }
    },
    major: {
      handler() {
        this.reset();
      }
    },
    classform: {
      handler() {
        this.reset();
      }
    },
    "addForm.classNature": {
      handler(val) {
        if (this.titleshow == "查看") return false;
        if (this.titleshow == "修改") {
          this.firstShow = false;
          return false;
        }
        let schoolList = [...this.schoolList];
        var value = [...val];
        if (value.toString() == "教学班") {
          this.schoolList = [...this.bkxy];
          if (this.addForm.ssxydm) {
            this.addForm.ssxydm = [];
          }
          Object.keys(this.addForm).forEach(key => {
            this.$set(this.addForm, "ssxydm", ["all"]);
            this.$set(this.addForm, "zyh", ["all"]);
          });
          this.allselect = true;
          this.schoolList.filter(el => {
            if (el.dwh !== "all") {
              return (el.disabled = true);
            }
          });
        } else if (
          value.toString() == "行政班" ||
          value.toString() == "行政班,教学班" ||
          value.toString() == "教学班,行政班"
        ) {
          this.allselect = false;
          Object.keys(this.addForm).forEach(key => {
            this.$set(this.addForm, "ssxydm", "");
            this.$set(this.addForm, "zyh", "");
          });
          if (this.addForm.ssxydm) {
            this.addForm.ssxydm = "";
          }
          if (this.schoolList.length == 0) {
            this.schoolList = this.alllistxy;
          }
          this.schoolList.splice(
            schoolList.findIndex(item => item.dwh == "all"),
            1
          );
          this.schoolList.forEach(el => {
            el.disabled = false;
          });
        } else {
          this.allselect = false;
          Object.keys(this.addForm).forEach(key => {
            this.$set(this.addForm, "ssxydm", "");
            this.$set(this.addForm, "zyh", "");
          });
        }
      }
    },
    "addForm.ssxydm": {
      handler(val) {
        var value = val.toString();
        if (this.titleshow == "查看") return false;
        if (this.titleshow == "修改") {
          this.firstShow = false;
          return false;
        }
        if (this.addForm.classNature.length > 0) {
          if (this.addForm.classNature.toString() == "教学班") {
            if (this.addForm.ssxydm.includes("all")) {
              this.menu(this.addForm.ssxydm.toString()).then(res => {
                if (res.length == 0) {
                  this.majorList.unshift({ zyh: "all", zymc: "全部专业" });
                  this.addForm.zyh = ["all"];
                }
                if (res.length > 0) {
                  this.majorList = res;
                  this.addForm.zyh = [];
                }
              });
            } else {
              this.addForm.zyh = [];
              this.majorList = [];
            }
          } else if (
            this.addForm.classNature.toString() == "行政班" ||
            this.addForm.classNature.toString() == "行政班,教学班" ||
            this.addForm.classNature.toString() == "教学班,行政班"
          ) {
            this.addForm.zyh = "";
            this.menu(value).then(res => {
              if (res.length == 0) {
                this.majorList = [{ zyh: "all", zymc: "全部专业" }];
              }
              if (res.length > 0) {
                this.majorList = res;
              }
            });
          }
        }
      }
    },
    "addClassForm.jxb": {
      handler(val) {
        var ss = 0;
        var bs = 0;
        if (this.addClassForm.ss) {
          ss = 2;
        } else {
          ss = 0;
        }
        if (this.addClassForm.bs) {
          bs = 1;
        } else {
          bs = 0;
        }
        this.$http
          .get(
            `api/cultivate/class/checkBatchaInsert/${this.addClassForm.nj}/${ss}/${bs}`
          )
          .then(res => {
            console.log(res);
            if (res.data.code == 400) {
              this.checkBat = true;
              this.$message.error(res.data.message);
            } else {
              this.checkBat = false;
            }
          });
      }
    }
  },
  data() {
    return {
      glkcList: [],
      loadings: false,
      checkBat: true,
      addClassForm: {
        // 年级
        yearList: [],
        ss: false,
        bs: false,
        jxb: null
      },
      value: 0,
      collegeLists: [],
      majorListlist: [],
      classList: [],
      college: "",
      major: "",
      classform: "",
      tableData: [],
      loading2: false,
      tableHeight: null,
      searchField: "",
      total: 0,
      firstShow: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      titleshow: "添加",
      show: false,
      addForm: {
        bjmc: "",
        nj: "",
        pycc: "",
        fdygh: null,
        classNature: ["行政班"],
        kch: []
      },
      loading: false,
      teacher: [], // 辅导员
      // 弹框学院
      schoolList: [],
      // 弹框年级
      yearList: [],
      // 班级性质
      // 培养层次
      levelList: [],
      // 专业
      majorList: [],
      // 教学班是否支持多选
      allselect: false,
      addDialog: false,
      bkxy: [],
      alllistxy: [],
      multipleSelections: [],
      pageshow: true,
      rowid: "",
      ishow: false,
      addClassDialog: false
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    // 列表
    this.tablelist();
    // 筛选框
    this.getNumber();
    this.menu("").then(res => {
      this.majorListlist = res;
      this.majorListlist.unshift({ zyh: "", zymc: "全部专业" });
    });
  },
  methods: {
    addClass() {
      this.addClassDialog = true;
      this.addClassForm = {
        nj: "",
        ss: false,
        bs: false,
        jxb: null
      };
      this.checkBat = true;
      this.getNumber();
    },
    addformClass() {
      var ss,
        bs = 0;
      if (this.addClassForm.ss) {
        ss = 2;
      } else {
        ss = 0;
      }
      if (this.addClassForm.bs) {
        bs = 1;
      } else {
        bs = 0;
      }
      this.$http
        .post("api/cultivate/class/batchaInsert", {
          isjxb: this.addClassForm.jxb,
          nj: this.addClassForm.nj,
          pyccb: bs,
          pyccs: ss
        })
        .then(res => {
          if (res.data.code == 200) {
            this.addClassDialog = false;
            return this.$message.success(res.data.message);
          } else {
            return this.$message.error(res.data.message);
          }
        });
    },
    reset() {
      this.pageshow = false;
      setTimeout(() => {
        this.pageshow = true;
      }, 100);
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
      this.tablelist();
    },
    xgbtn() {
      let addForm = JSON.parse(JSON.stringify(this.addForm));
      var isjxb = false;
      var isxzb = false;
      if (addForm.classNature.toString() == "教学班") {
        isjxb = true;
        isxzb = false;
      }
      if (
        addForm.classNature.toString() == "行政班,教学班" ||
        addForm.classNature.toString() == "教学班,行政班" ||
        addForm.classNature.toString() == "行政班"
      ) {
        isxzb = true;
        isjxb = false;
      }
      if (addForm.ssxydm instanceof Array) {
        addForm.ssxydm = addForm.ssxydm.join(",");
      }
      if (addForm.zyh instanceof Array) {
        addForm.zyh = addForm.zyh.join(",");
      }
      if (addForm.ssxydm == " all") {
        addForm.zyh = "all";
      }
      var obj = {
        bjmc: addForm.bjmc,
        isxzb: isxzb,
        isjxb: isjxb,
        nj: addForm.nj,
        pycc: addForm.pycc,
        ssxydm: addForm.ssxydm,
        zyh: addForm.zyh,
        id: this.rowid,
        kch: addForm.kch.toString()
      };

      this.$http.put("api/cultivate/class", obj).then(res => {
        if (res.data.code == 200) {
          this.$message({
            type: "success",
            message: res.data.message
          });
          console.log(res);
          this.addDialog = false;
          this.reset();
          this.getNumber();
        } else {
          this.$message.error(res.data.message);
          this.addDialog = false;
          this.reset();
        }
      });
    },
    addforms() {
      let addForm = JSON.parse(JSON.stringify(this.addForm));
      var isjxb = false;
      var isxzb = false;
      if (addForm.classNature.toString() == "教学班") {
        isjxb = true;
        isxzb = false;
      }
      if (addForm.classNature.toString() == "行政班") {
        isxzb = true;
        isjxb = false;
      }
      if (
        addForm.classNature.toString() == "行政班,教学班" ||
        addForm.classNature.toString() == "教学班,行政班"
      ) {
        isxzb = true;
        isjxb = true;
      }
      if (addForm.ssxydm instanceof Array) {
        addForm.ssxydm = addForm.ssxydm.join(",");
      }
      if (addForm.zyh instanceof Array) {
        addForm.zyh = addForm.zyh.join(",");
      }
      if (addForm.ssxydm == " all") {
        addForm.zyh = "all";
      }
      var obj = {
        bjmc: addForm.bjmc,
        isxzb: isxzb,
        isjxb: isjxb,
        nj: addForm.nj,
        pycc: addForm.pycc,
        ssxydm: addForm.ssxydm,
        zyh: addForm.zyh,
        kch: addForm.kch.toString()
      };
      this.$http.post("api/cultivate/class/", obj).then(res => {
        if (res.data.code == 200) {
          this.$message({
            type: "success",
            message: res.data.message
          });
          this.addDialog = false;
          this.reset();
          this.getNumber();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    selectall(val) {
      let valobj = "";
      if (
        this.addForm.classNature.includes("教学班") &&
        this.addForm.classNature.length == 1
      ) {
        this.addForm.ssxydm.map(v => {
          this.schoolList.forEach(item => {
            // console.log(item);
            if (v == "all") {
              item.disabled = true;
            } else {
              item.disabled = false;
            }
          });
        });
        if (!this.addForm.ssxydm.includes("all")) {
          this.schoolList.find(el => el.dwh == "all").disabled = true;
        }
        if (this.addForm.ssxydm.length == 0) {
          this.schoolList.forEach(item => {
            item.disabled = false;
          });
        }
      }
      if (val instanceof Array) {
        valobj = val.toString();
      } else {
        valobj = val;
      }
      console.info("valobj=" + valobj);
      this.menu(valobj).then(value => {
        console.log(value.length);
        if (value.length === 0) {
          this.majorList = [{ zyh: "all", zymc: "全部专业" }];
        }
        if (value.length > 0) {
          this.majorList = value;
        }
        console.log(this.majorList);
      });
    },
    enryform() {
      this.addForm = {
        classNature: ["行政班"],
        bjmc: "",
        nj: "",
        pycc: "",
        fdygh: null,
        kch: []
      };
    },
    remoteMethod(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        this.teacher = res.data.data;
      });
    },
    remoteMethods(val) {
      this.$http.get(`api/cultivate/course/search?query=${val}`).then(res => {
        this.glkcList = res.data.data;
      });
    },
    // 学院对应的专业
    menu(val) {
      return new Promise((resolve, reject) => {
        this.$http
          .get("api/cultivate/class/getMajorByCollege?dwh=" + val)
          .then(res => {
            if (res.data.data == "数据为空") {
              resolve("");
            } else {
              resolve(res.data.data);
            }
          });
      });
    },
    modify(row) {
      this.xqxg(row);
      this.titleshow = "修改";
      this.addDialog = true;
      this.rowid = row.id;
      this.show = false;
      this.ishow = true;
      this.firstShow = true;
      this.enryform();
    },
    xqxg(row) {
      console.log(this.schoolList);
      console.log(this.alllistxy);
      console.log(this.bkxy);
      this.show = true;
      this.ishow = true;
      this.$http.get("api/cultivate/class/" + row.bh).then(res => {
        this.addForm = res.data.data;
        if (res.data.data.isxzb && res.data.data.isjxb) {
          console.log(111);
          this.allselect = false;
          this.schoolList = [...this.alllistxy];
          this.$set(this.addForm, "classNature", ["行政班", "教学班"]);
          this.$set(this.addForm, "ssxydm", res.data.data.ssxydm);
          this.$set(this.addForm, "zyh", res.data.data.zyh);
          // this.majorList = res.data.data.zyList;
          this.menu(res.data.data.ssxydm).then(value => {
            this.majorList = value;
            console.log(this.majorList);
          });
        } else if (res.data.data.isjxb && !res.data.data.isxzb) {
          console.log(222);
          this.allselect = true;
          this.glkcList = res.data.data.kcList;
          this.$set(this.addForm, "classNature", ["教学班"]);
          let ssxydm = res.data.data.ssxydm.toString();
          let zyh = res.data.data.zyh.toString();
          console.log(res.data.data.ssxydm, res.data.data.zyh);
          this.schoolList = [...this.bkxy];
          this.$set(this.addForm, "ssxydm", ssxydm.split(","));
          this.$set(this.addForm, "zyh", zyh.split(","));
          this.addForm.kch = res.data.data.kch.split(",");
          if (this.addForm.ssxydm.includes("all")) {
            this.majorList = [{ zyh: "all", zymc: "全部专业" }];
          } else {
            this.menu(res.data.data.ssxydm).then(value => {
              this.majorList = value;
              console.log(this.majorList);
            });
          }
        } else if (!res.data.data.isjxb && res.data.data.isxzb) {
          console.log(333);
          this.schoolList = [...this.alllistxy];
          this.$set(this.addForm, "classNature", ["行政班"]);
          this.allselect = false;
          this.$set(this.addForm, "ssxydm", res.data.data.ssxydm);
          this.$set(this.addForm, "zyh", res.data.data.zyh);
        } else {
          console.log(5555);
          this.allselect = false;
          this.schoolList = [...this.alllistxy];
          this.$set(this.addForm, "ssxydm", res.data.data.ssxydm);
          this.$set(this.addForm, "zyh", res.data.data.zyh);
        }
      });
    },
    checkDetails(row) {
      this.titleshow = "查看";
      this.addDialog = true;
      this.xqxg(row);
      this.enryform();
    },
    handleSelectionChange(rows) {
      this.multipleSelections = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelections.push(row.bh);
        });
      }
    },
    // 添加
    addNew() {
      this.addDialog = true;
      this.titleshow = "添加";
      this.enryform();
      this.show = false;
      this.ishow = false;
    },
    // 删除
    deleteInfor() {
      if (this.multipleSelections.length == 0) {
        this.$message.error("请勾选数据再进行删除!!");
        return false;
      }
      this.$confirm("删除该班级, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .delete("api/cultivate/class/" + this.multipleSelections.join(","))
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.reset();
              } else {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // 导出
    exportInfo() {},
    getNumber() {
      this.$http.get("api/cultivate/class/selectjh").then(res => {
        this.alllistxy = [...res.data.data.xxYxsdwjbsjbs];
        this.alllistxy.map(v => {
          this.$set(v, "disabled", false);
        });
        this.bkxy = [...res.data.data.xxYxsdwjbsjbs];
        this.bkxy.unshift({ dwh: "all", dwmc: "全部学院" });
        this.bkxy.map(v => {
          this.$set(v, "disabled", false);
        });
        this.selectmojor = res.data.data.pyZyxxbs;
        // 培养层次
        this.levelList = res.data.data.pycc;
        // 年级
        this.yearList = res.data.data.years;
        // 年份
        this.classList = res.data.data.njList;
        this.addClassForm.yearList = res.data.data.years;
        // 列表的学院下拉
        this.collegeLists = res.data.data.xxYxsdwjbsjbs;
        this.collegeLists.unshift({ dwh: "", dwmc: "全部学院" });
      });
    },
    tablelist() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/cultivate/class/list", {
          pageSize: params.pageSize,
          pageNum: params.pageNum,
          bjmc: this.searchField,
          ssxydm: this.college,
          zyh: this.major,
          nj: this.classform
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(error => {
          console.error(error.message);
          this.loading2 = false;
        });
    }
  }
};
</script>
<style scoped lang="scss">
.classInformation {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
}
</style>
