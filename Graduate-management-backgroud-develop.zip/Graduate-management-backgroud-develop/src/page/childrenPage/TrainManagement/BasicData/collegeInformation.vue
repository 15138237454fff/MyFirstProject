<!-- 学院信息管理 -->
<template>
  <div class="collegeInformation">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="searchField"
          placeholder="请输入学院名称"
          style="width: 200px"
          @keyup.enter.native="searchData"
          @clear="clearinput"
          clearable
          suffix-icon="el-icon-search"
        ></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          @click="exportInfo"
          v-if="$btnAuthorityTest('collegeInformation:export')"
          >导出</el-button
        >
      </div>
    </componment>
    <div class="table">
      <el-table
        :data="tableData"
        border
        ref="multipleTable"
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading2"
        element-loading-text="加载中"
      >
        <el-table-column prop="dwh" label="学院代码" width="150">
        </el-table-column>
        <el-table-column prop="dwmc" label="学院名称"> </el-table-column>
        <el-table-column prop="dwjc" label="学院简称"> </el-table-column>
        <el-table-column prop="xqm" label="所属校区"> </el-table-column>
      </el-table>
    </div>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
  </div>
</template>

<script>
import "@/components/common/common.scss";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "collegeInformation",
  data() {
    return {
      searchField: "", // 搜索的数据
      tableData: [],
      total: 0, // 总数据条数
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null
    };
  },
  components: {
    pagination: pagination, // 分页
    componment: componment
  },
  methods: {
    clearinput() {
      this.searchField = "";
      this.fresh();
    },
    fresh() {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post(
          `api/cultivate/academy/search/${params.pageNum}/${params.pageSize}?dwmc=${this.searchField}`
        )
        .then(res => {
          this.loading2 = false;
          const myRes = JSON.parse(res.data.data);
          this.tableData = myRes.list;
          this.total = myRes.total;
          console.log(this.tableData);
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    searchData() {
      this.takeList();
    }, // 搜索数据方法
    exportInfo() {} // 导出数据
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.collegeInformation {
  width: 100%;
  padding-top: 7px;

  .red {
    color: #f56c6c;
  }
  .table {
    width: 100%;
  }
}
</style>
