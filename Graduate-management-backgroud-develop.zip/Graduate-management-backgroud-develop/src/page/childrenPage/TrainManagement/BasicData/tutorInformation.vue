<!-- 导师信息维护 -->
<template>
  <div class="tutorInformation">
    <componment>
      <div slot="left" style="flex:2">
        <el-input v-model="searchField" placeholder="请输入导师工号/姓名" style="width: 200px" @keyup.enter.native="searchData" clearable @clear="clearinput" suffix-icon="el-icon-search"></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select v-model="work" filterable placeholder="全部单位" style="margin-left: 10px;" @change="searchData">
          <el-option value="" label="全部单位"></el-option>
          <el-option v-for="item in deptList" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right" style="flex:1">
        <el-button type="primary" @click="addNew" v-if="$btnAuthorityTest('tutorInformation:add')">添加</el-button>
        <el-button type="danger" @click="deleteInfor" v-if="$btnAuthorityTest('tutorInformation:delete')">删除</el-button>
        <el-button @click="exportInfo" v-if="$btnAuthorityTest('tutorInformation:export')">导出</el-button>
      </div>
    </componment>
    <el-table :data="tableData" border ref="multipleTable" style="width: 100%" @row-click="clickRow" @selection-change="mySelect" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
      <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
      </el-table-column>
      <el-table-column prop="gh" label="工号" width="150"> </el-table-column>
      <el-table-column prop="xm" label="姓名"> </el-table-column>
      <el-table-column prop="xbm" label="性别">
        <template slot-scope="scope">
          {{ getDictValue(scope.row.xbm, "sexCode") }}
        </template>
      </el-table-column>
      <el-table-column prop="dwmc" label="所属单位"> </el-table-column>
      <el-table-column prop="dslb" label="导师类别">
        <template slot-scope="scope">
          {{ getListValue(scope.row.dslb, typeList) }}
        </template>
      </el-table-column>
      <el-table-column prop="zdmc" label="指导专业" :show-overflow-tooltip="true">
        <template slot-scope="scope">
          <span class="flltermore">{{ scope.row.zdmc }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="jnzs" :label="this.nowDate + '是否招生'">
        <template slot-scope="scope">
          {{ getDictValue(scope.row.jnzs, "whether") }}
        </template>
      </el-table-column>
      <el-table-column prop="dqzt" label="当前状态"> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span class="tablexq" @click="checkDetails(scope.row)" v-if="$btnAuthorityTest('tutorInformation:view')">查看</span><span v-if="
              $btnAuthorityTest('tutorInformation:view') &&
                $btnAuthorityTest('tutorInformation:update')
            ">
            | </span><span class="tablexg" @click="teacherxg(scope.row)" v-if="$btnAuthorityTest('tutorInformation:update')">修改</span>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>

    <el-dialog :title="teacherdialog" :visible.sync="detailsDialog" :before-close="handleClose" width="750px" class="detailsCheck" :close-on-click-modal="false">
      <p class="hr"></p>
      <el-form :model="detailsForm" label-width="150px" ref="detailsForm">
        <el-row>
          <el-table :data="detailsForm.teachData" border ref="multipleTable1" style="width: 600px; margin: 0 10px 20px 17px;" :header-cell-style="$storage.tableHeaderColor">
            <el-table-column prop="gh" label="工号" width="150">
            </el-table-column>
            <el-table-column prop="xm" label="姓名" width="150">
            </el-table-column>
            <el-table-column prop="xbm" label="性别">
              <template slot-scope="scope">
                {{ getDictValue(scope.row.xbm, "sexCode") }}
              </template>
            </el-table-column>
            <el-table-column prop="dwmc" label="所属单位"> </el-table-column>
            <el-table-column prop="dqzt" label="当前状态"> </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="导师类别：">
              <el-select style="width:200px" v-model="detailsForm.dslb" :disabled="isShow">
                <el-option v-for="item in typeList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item :label="nowDate + '是否招生:'">
              <el-select style="width:200px" v-model="detailsForm.jnzs" :disabled="isShow">
                <el-option v-for="item in $dict.dict.whether" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="获得硕导年月：">
              <el-date-picker :disabled="isShow" style="width: 200px;" v-model="detailsForm.hsdny" type="date" placeholder="选择日期" value-format="yyyy-MM-dd">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="硕导证书号：">
              <el-input style="width:200px" v-model="detailsForm.sdzsh" :disabled="isShow" type="number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="获得博导年月：">
              <el-date-picker :disabled="isShow" style="width: 200px;" v-model="detailsForm.hbdny" type="date" placeholder="选择日期" value-format="yyyy-MM-dd">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="博导证书号：">
              <el-input style="width:200px" v-model="detailsForm.bdzsh" :disabled="isShow" type="number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="指导专业：">
              <el-select v-model="detailsForm.zddm" multiple placeholder="请选择" style="width: 525px;" :disabled="isShow" @change="majorDetailChange">
                <el-option v-for="item in majorList" :key="item.value + 'detail'" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="导师简介：">
              <el-input v-model="detailsForm.dsjj" type="textarea" :rows="2" style="width: 525px;" :disabled="isShow"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer" v-if="teacherdialog == '导师修改'">
        <el-button @click="detailsDialog = false">取 消</el-button>
        <el-button type="primary" @click="modificAffirm">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="添加导师" :visible.sync="addDialog" :before-close="handleClose" width="750px" :close-on-click-modal="false">
      <p class="hr"></p>
      <el-form :model="addForm" label-width="150px" ref="addForm">
        <el-row>
          <el-col :span="10">
            <el-form-item label="搜索导师姓名：" :required="true">
              <el-select v-model="addForm.gh" filterable remote placeholder="请输入教职工姓名查询" :remote-method="queryTutorByName" :loading="tutorLoading" style="width:300px" @change="teacherSelectChange">
                <el-option v-for="item in teacherList" :key="item.gh" :value="item.gh" :label="`${item.xm}(${item.gh})`">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-table :data="addForm.teachData" border ref="multipleTable2" style=" margin: 0 10px 20px 77px; width: 620px;" :header-cell-style="$storage.tableHeaderColor">
            <el-table-column prop="xm" label="姓名"> </el-table-column>
            <el-table-column prop="gh" label="工号"> </el-table-column>
            <el-table-column prop="xbm" label="性别"> </el-table-column>
            <el-table-column prop="dwmc" label="所属单位"> </el-table-column>
            <el-table-column prop="jzgdqztmc" label="当前状态">
            </el-table-column>
          </el-table>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="导师类别：" :required="true">
              <el-select v-model="addForm.dslb" filterable placeholder="请选择" style="width: 200px;">
                <el-option v-for="item in typeList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item :label="nowDate + '是否招生:'">
              <el-radio-group v-model="addForm.jnzs" style="width: 525px;">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="指导专业：" :required="true">
              <el-select v-model="addForm.zddm" multiple placeholder="请选择" style="width: 525px;" @change="majorSelectChange" filterable>
                <el-option v-for="item in majorList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="获得硕导年月：">
              <el-date-picker style="width: 200px;" v-model="addForm.hsdny" type="date" placeholder="选择日期" value-format="yyyy-MM-dd">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="硕导证书号：" prop="first_channel_code">
              <el-input style="width:200px;" v-model="addForm.sdzsh" type="number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="获得博导年月：">
              <el-date-picker style="width: 200px;" v-model="addForm.hbdny" type="date" placeholder="选择日期" value-format="yyyy-MM-dd">
              </el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="博导证书号：" prop="first_channel_code">
              <el-input style="width:200px" v-model="addForm.bdzsh" type="number"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="10">
            <el-form-item label="导师简介：">
              <el-input v-model="addForm.dsjj" type="textarea" :rows="2" style="width: 525px;"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addCancel">取 消</el-button>
        <el-button type="primary" @click="addSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "tutorInformation",
  data() {
    return {
      tutorLoading: false,
      isShow: true,
      detailsForm: {
        number: "",
        teachData: [], // 详情导师表
        type: "",
        nature: "",
        sdTime: "",
        sdNumber: "",
        bdTime: "",
        bdNumber: "",
        trick: "",
        major: "",
        intro: ""
      }, // 查看详情列表
      addForm: {
        number: "",
        teachData: [], // 详情导师表
        type: "",
        nature: "",
        sdTime: "",
        sdNumber: "",
        bdTime: "",
        bdNumber: "",
        trick: 0,
        major: [],
        intro: ""
      }, // 添加班级列表
      addDialog: false, // 添加班级
      detailsDialog: false, // 查看详情
      searchField: "", // 搜索的数据
      tableData: [],
      majorList: [], // 开课学期列表
      work: "", // 选中单位
      typeList: [], // 导师类别列表
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      deptList: [],
      deleteList: [], // 删除的数据
      loading2: false,
      nowDate: "",
      teacherList: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      teacherdialog: "导师详情"
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  methods: {
    teacherxg(row) {
      this.teacherdialog = "导师修改";
      this.detailsDialog = true;
      this.isShow = false;
      this.detailsForm = Object.assign({}, row);
      this.detailsForm.teachData = [];
      this.detailsForm.teachData.push(this.detailsForm);
      if (this.isEmpty(this.detailsForm.zddm)) {
        this.$set(this.detailsForm, "zddm", this.detailsForm.zddm.split(","));
        this.$set(this.detailsForm, "zdmc", this.detailsForm.zdmc.split(","));
      } else {
        this.$set(this.detailsForm, "zddm", null);
        this.$set(this.detailsForm, "zdmc", null);
      }
    },
    // 下拉框通过教师姓名查询教师信息
    queryTutorByName(query) {
      if (query !== "") {
        this.loading = true;
        setTimeout(() => {
          this.queryTutorByNameRemote(query);
        }, 200);
      } else {
        this.teacherList = [];
      }
    },
    // 远程查询
    queryTutorByNameRemote(query) {
      this.$http
        .get("api/cultivate/teacher/selectByQuery/" + query)
        .then(res => {
          this.loading = false;
          if (res.data.code == 200) {
            this.teacherList = res.data.data;
          }
        });
    },
    clearinput() {
      this.searchField = "";
      this.searchData();
    },
    // 查看详情专业改变事件
    majorDetailChange(val) {
      this.detailsForm.zdmc = [];
      val.forEach(element => {
        const obj = this.majorList.find(item => {
          // 这里的userList就是上面遍历的数据源
          return item.value === element; //筛选出匹配数据
        });
        this.detailsForm.zdmc.push(obj.label);
      });
    },
    // 专业改变事件
    majorSelectChange(val) {
      this.addForm.zdmc = [];
      val.forEach(element => {
        const obj = this.majorList.find(item => {
          // 这里的userList就是上面遍历的数据源
          return item.value === element; //筛选出匹配数据
        });
        this.addForm.zdmc.push(obj.label);
      });
    },
    modificAffirm() {
      if (this.isShow) {
        this.detailsDialog = false;
        return;
      }
      var obj = {
        id: this.detailsForm.id,
        dslb: this.detailsForm.dslb,
        jnzs: this.detailsForm.jnzs,
        hsdny: this.detailsForm.hsdny,
        sdzsh: this.detailsForm.sdzsh,
        hbdny: this.detailsForm.hbdny,
        bdzsh: this.detailsForm.bdzsh,
        zddm: this.isEmpty(this.detailsForm.zddm)
          ? this.detailsForm.zddm.join(",")
          : null,
        zdmc: this.isEmpty(this.detailsForm.zdmc)
          ? this.detailsForm.zdmc.join(",")
          : null,
        dsjj: this.detailsForm.dsjj
      };
      this.$http.put("api/cultivate/teacher", obj).then(res => {
        if (res.data.code == 200) {
          this.$message({
            type: "success",
            message: "修改成功"
          });
          this.detailsDialog = false;
          this.takeList();
        } else {
          this.$message.error("修改失败");
        }
      });
    }, // 修改提交
    modificHandle() {
      this.isShow = false;
    }, // 点击修改
    addSubmit() {
      this.addForm.dslb == "" || this.addForm.zddm.length == 0
        ? this.$message.error("提交内容不能为空")
        : this.$http
            .post("api/baseservice/teacher/save", this.addForm)
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  type: "success",
                  message: "添加成功"
                });
                this.addDialog = false;
                this.searchData();
              } else {
                this.$message.error(res.data.message);
              }
            });
    }, // 确认添加
    addCancel() {
      this.addDialog = false;
      this.addForm.teachData = [];
      this.addempty();
    }, // 取消添加
    addempty() {
      this.addForm = {};
    }, // 添加清空
    teacherSelectChange(item) {
      this.addForm.teachData = [];
      var teacher = this.teacherList.find(temp => {
        return temp.gh == item;
      });
      this.addForm.teachData.push(teacher);
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post(
          `api/cultivate/teacher/${params.pageNum}/${params.pageSize}?dwh=${this.work}&query=${this.searchField}`
        )
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查询所有列表
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.gh);
      });
    }, // 列表选择
    searchData() {
      this.listQuery.queryPage.pageNum = 1;
      this.takeList();
    }, // 搜索数据方法
    addNew() {
      this.addDialog = true;
      this.addForm = { jnzs: 1 };
    }, // 添加数据
    deleteInfor() {
      if (this.deleteList.length == 0) {
        this.$message({
          message: "请勾选在进行删除",
          type: "error"
        });
        return false;
      }
      this.$confirm("删除该导师, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .delete("api/cultivate/teacher/" + this.deleteList.join(","))
            .then(res => {
              this.listQuery.queryPage.pageNum = 1;
              this.takeList();
              if (res.data.code != 200) {
                this.$message.error(res.data.message);
              } else if (res.data.code == 200) {
                this.$message({
                  message: "删除成功",
                  type: "success"
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }, // 删除数据
    exportInfo() {}, // 导出数据
    checkDetails(row) {
      this.teacherdialog = "导师详情";
      this.isShow = true;
      this.detailsDialog = true;
      this.detailsForm = Object.assign({}, row);
      this.detailsForm.teachData = [];
      this.detailsForm.teachData.push(this.detailsForm);
      if (this.isEmpty(this.detailsForm.zddm)) {
        this.$set(this.detailsForm, "zddm", this.detailsForm.zddm.split(","));
        this.$set(this.detailsForm, "zdmc", this.detailsForm.zdmc.split(","));
      } else {
        this.$set(this.detailsForm, "zddm", null);
        this.$set(this.detailsForm, "zdmc", null);
      }
    }, // 查看详情
    handleClose(done) {
      this.addempty();
      this.detailsForm.teachData = [];
      this.addForm.teachData = [];
      done();
    }, // 关闭弹出框
    loadDeptSelect() {
      this.$http.get("api/system/dept/selectAll").then(res => {
        this.deptList = res.data.data;
      });
    },
    loadDslbDict() {
      this.$http.get("api/system/dict/select/dslb").then(res => {
        this.typeList = res.data.data;
      });
    },
    loadMajorInfo() {
      this.$http.get("api/system/dict/select/majorFormat").then(res => {
        this.majorList = res.data.data;
      });
    }
  },
  created() {
    const nowDate = new Date();
    this.nowDate = nowDate.getFullYear();
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    if (this.typeList != []) {
      this.takeList();
    }
    this.loadDeptSelect();
    // 导师类别
    this.loadDslbDict();
    // 专业信息
    this.loadMajorInfo();
  }
};
</script>

<style scoped lang="scss">
.tutorInformation {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
}
</style>
