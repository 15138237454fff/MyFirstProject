<!-- 课程信息维护 -->
<template>
  <div class="courseInformation">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="searchField"
          placeholder="请输入课程号/名称"
          style="width: 200px"
          @keyup.enter.native="searchData"
          clearable
          @clear="clearinput"
          suffix-icon="el-icon-search"
        ></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select
          v-model="work"
          filterable
          placeholder="全部开课单位"
          style="margin-left: 10px;"
          @change="takeList()"
        >
          <el-option value="">全部单位</el-option>
          <el-option
            v-for="(item, index) in workList"
            :key="index"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('courseInformation:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="deleteInfor"
          v-if="$btnAuthorityTest('courseInformation:delete')"
          >删除</el-button
        >
        <el-button
          @click="exportInfo"
          v-if="$btnAuthorityTest('courseInformation:export')"
          >导出</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%"
      @selection-change="mySelect"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column
        :show-overflow-tooltip="true"
        type="selection"
        width="55"
      >
      </el-table-column>
      <el-table-column prop="kch" label="课程号" width="150"> </el-table-column>
      <el-table-column prop="kcmc" label="课程名称"> </el-table-column>
      <el-table-column prop="kkdwh" label="开课单位">
        <template slot-scope="scope">
          <span>{{ getListValue(scope.row.kkdwh, workList) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="xf" label="学分"> </el-table-column>
      <el-table-column prop="zxs" label="学时"> </el-table-column>
      <el-table-column prop="kczt" label="课程状态">
        <template slot-scope="scope">
          <span>{{ scope.row.kczt | kczt }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="checkDetails(scope.row)"
            v-if="$btnAuthorityTest('courseInformation:view')"
            >查看</span
          ><span
            v-if="
              $btnAuthorityTest('courseInformation:view') &&
                $btnAuthorityTest('courseInformation:update')
            "
          >
            | </span
          ><span
            class="tablexg"
            @click="coursexg(scope.row)"
            v-if="$btnAuthorityTest('courseInformation:update')"
            >修改</span
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <el-dialog
      :title="courseDetails"
      :visible.sync="detailsDialog"
      :before-close="handleClose"
      width="690px"
      class="detailsCheck"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form :model="detailsForm" label-width="100px" ref="detailsForm">
        <el-row>
          <el-col :span="10">
            <el-form-item label="课程号：" :required="true">
              <el-input
                style="width:200px"
                v-model="detailsForm.kch"
                disabled
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="课程名称：" :required="true">
              <el-input
                style="width:200px"
                v-model="detailsForm.kcmc"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="课程简称：">
              <el-input
                style="width:200px"
                v-model="detailsForm.kcjc"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="开课单位：" :required="true">
              <el-select
                v-model="detailsForm.kkdwh"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                :disabled="isShow"
              >
                <el-option
                  v-for="item in myworkList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="课程性质：" :required="true">
              <el-select
                v-model="detailsForm.kcxzh"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                :disabled="isShow"
              >
                <el-option
                  v-for="item in natureList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="考试形式：" :required="true">
              <el-select
                v-model="detailsForm.ksxs"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                :disabled="isShow"
              >
                <el-option
                  v-for="item in wayList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="学分：" :required="true">
              <el-input
                style="width:200px"
                v-model="detailsForm.xf"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="学时：" :required="true">
              <el-input
                style="width:200px"
                v-model="detailsForm.zxs"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="授课教师：">
              <el-select
                v-model="detailsForm.skjs"
                multiple
                filterable
                remote
                reserve-keyword
                placeholder="请选择"
                :remote-method="remoteMethod1"
                :loading="loading"
                :disabled="isShow"
                style="width:500px"
              >
                <el-option
                  v-for="item in semesterList1"
                  :key="item.gh"
                  :label="`${item.info}`"
                  :value="item.gh"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="22">
            <el-form-item label="课程状态：">
              <el-radio-group v-model="detailsForm.kczt" :disabled="isShow">
                <el-radio :label="1">正常</el-radio>
                <el-radio :label="2">停开</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="课程简介：">
              <el-input
                v-model="detailsForm.kcjj"
                type="textarea"
                :rows="2"
                :disabled="isShow"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span
        slot="footer"
        class="dialog-footer"
        v-if="courseDetails == '课程修改'"
      >
        <el-button @click="detailsDialog = false">取消</el-button>
        <el-button type="primary" @click="modifaffirm">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="添加课程"
      :visible.sync="addDialog"
      :before-close="handleClose"
      width="690px"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form :model="addForm" label-width="100px" ref="addForm">
        <el-row>
          <el-col :span="10">
            <el-form-item label="课程号：" :required="true">
              <el-input style="width:200px" v-model="addForm.kch"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="课程名称：" :required="true">
              <el-input style="width:200px" v-model="addForm.kcmc"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="课程简称：">
              <el-input style="width:200px" v-model="addForm.kcjc"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="开课单位：" :required="true">
              <el-select
                v-model="addForm.kkdwh"
                filterable
                placeholder="请选择"
                style="width: 200px;"
              >
                <el-option
                  v-for="item in myworkList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="课程性质：" :required="true">
              <el-select
                v-model="addForm.kcxzh"
                filterable
                placeholder="请选择"
                style="width: 200px;"
              >
                <el-option
                  v-for="item in natureList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="考试形式：" :required="true">
              <el-select
                v-model="addForm.ksxs"
                filterable
                placeholder="请选择"
                style="width: 200px;"
              >
                <el-option
                  v-for="item in wayList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="学分：" :required="true">
              <el-input style="width:200px" v-model="addForm.xf"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="学时：" :required="true">
              <el-input style="width:200px" v-model="addForm.zxs"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="授课教师：">
              <el-select
                v-model="addForm.skjs"
                multiple
                filterable
                remote
                reserve-keyword
                placeholder="请选择"
                :remote-method="remoteMethod"
                :loading="loading"
                style="width:500px"
              >
                <el-option
                  v-for="item in semesterList"
                  :key="item.gh"
                  :label="`${item.info}`"
                  :value="item.gh"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="22">
            <el-form-item label="课程状态：">
              <el-radio-group v-model="addForm.kczt">
                <el-radio :label="1">正常</el-radio>
                <el-radio :label="2">停开</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="课程简介：">
              <el-input
                v-model="addForm.kcjj"
                type="textarea"
                :rows="2"
                style="width: 525px;"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialog = false">取 消</el-button>
        <el-button type="primary" @click="addaffirm">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "courseInformation",
  data() {
    return {
      loading: false,
      deleteDialog: false,
      isShow: true, // 修改参数
      detailsForm: {
        number: "",
        name: "",
        shortName: "",
        school: "",
        type: "",
        nature: "",
        startGrade: "",
        endGrade: "",
        credit: "",
        time: "",
        semester: "",
        way: "",
        status: 0,
        intro: "",
        kcxzh: "",
        skjs: ""
      }, // 查看详情列表
      addForm: {
        number: "",
        name: "",
        shortName: "",
        mywork: "",
        type: "",
        nature: "",
        startGrade: "",
        endGrade: "",
        credit: "",
        time: "",
        way: "",
        isValid: 0,
        semester: [],
        intro: "",
        kcxzh: "",
        skjs: ""
      }, // 添加班级列表
      addDialog: false, // 添加班级
      detailsDialog: false, // 查看详情
      searchField: "", // 搜索的数据
      tableData: [],
      workList: [], // 单位列表
      semesterList: [], // 开课学期列表
      work: "", // 选中单位
      myworkList: [], // 开课单位列表
      typeList: [], // 课程属性列表
      natureList: [], // 课程性质列表
      wayList: [], // 考核方式列表
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      deleteList: [],
      loading2: false,
      semesterList1: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      btyz: ["kch", "kcmc", "kkdwh", "kcxzh", "ksxs", "zxs", "xf"],
      courseDetails: "课程详情"
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  filters: {
    kczt(val) {
      if (val) {
        if (val == "1") {
          return "正常";
        }
        if (val == "2") {
          return "停开";
        }
      }
    }
  },
  methods: {
    coursexg(row) {
      this.courseDetails = "课程修改";
      this.detailsDialog = true;
      this.isShow = false;
      this.$http.get("api/cultivate/course/" + row.kch).then(res => {
        this.detailsForm = res.data.data.pyKcsjb;
        this.semesterList1 = res.data.data.list;
        if (this.detailsForm.skjs) {
          this.detailsForm.skjs = res.data.data.pyKcsjb.skjs.split(",");
        }
      });
    },
    clearinput() {
      this.searchField = "";
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    },
    addaffirm() {
      var flag = true;
      this.btyz.map(v => {
        if (flag) {
          if (this.addForm[v] == "" || this.addForm[v] == []) {
            this.$message.error("请将信息填写完整");
            flag = false;
          }
        }
      });
      if (flag) {
        this.addForm.skjs = this.addForm.skjs.toString();
        this.$http.post("api/cultivate/course", this.addForm).then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "添加成功"
            });
            this.addDialog = false;
            this.takeList();
            this.listQuery.queryPage.pageNum = 1;
            this.empty();
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
    },
    modifaffirm() {
      console.log(this.detailsForm.skjs);
      this.detailsForm.skjs = this.detailsForm.skjs.toString();
      this.$http.put("api/cultivate/course", this.detailsForm).then(res => {
        if (res.data.code == 200) {
          this.$message({
            type: "success",
            message: "修改成功"
          });
          this.detailsDialog = false;
          this.takeList();
          this.listQuery.queryPage.pageNum = 1;
          this.empty();
        } else {
          this.$message.error("修改失败");
        }
      });
    }, // 确认修改
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .get(
          `api/cultivate/course/search/${params.pageNum}/${params.pageSize}?query=${this.searchField}&kkdwh=${this.work}`
        )
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.list;
          this.total = res.data.total;
          this.isShow = true;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    takeNumber() {
      this.$http.get("api/cultivate/course/selectkkdwksxz").then(res => {
        res.data.data.kcxz.map((item, index) => {
          const obj = {
            value: item.code,
            label: item.name
          };
          this.natureList.push(obj);
        });
        res.data.data.ksxz.map((item, index) => {
          const obj = {
            value: item.code,
            label: item.name
          };
          this.wayList.push(obj);
        });
      });
    },
    remoteMethod(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        this.semesterList = res.data.data;
      });
    },
    remoteMethod1(val) {
      this.$http.get("api/cultivate/kc/selectTeaList?xm=" + val).then(res => {
        this.semesterList1 = res.data.data;
      });
    },
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.kch);
      });
    }, // 列表选择
    searchData() {
      this.takeList();
    }, // 搜索数据方法
    addNew() {
      this.addDialog = true;
      this.addForm.kczt = 1;
      this.empty();
    }, // 添加数据
    deleteInfor() {
      this.deleteList.length == 0
        ? this.$message.error({ message: "请选择一条数据！" })
        : (this.deleteDialog = true);
    }, // 删除数据
    closeDia() {
      this.$http
        .delete("api/cultivate/course/" + this.deleteList.toString())
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "删除成功"
            });
            this.deleteDialog = false;
            this.takeList();
            this.listQuery.queryPage.pageNum = 1;
          } else {
            this.$message.error(res.data.message);
          }
        });
    }, // 确认删除
    exportInfo() {}, // 导出数据
    checkDetails(row) {
      this.courseDetails = "课程详情";
      this.detailsDialog = true;
      this.isShow = true;
      this.$http.get("api/cultivate/course/" + row.kch).then(res => {
        this.detailsForm = res.data.data.pyKcsjb;
        this.semesterList1 = res.data.data.list;
        if (this.detailsForm.skjs) {
          this.detailsForm.skjs = res.data.data.pyKcsjb.skjs.split(",");
        }
      });
    }, // 查看详情
    empty() {
      (this.addForm = {}), (this.detailsForm = {});
      this.addForm = { skjs: [], kcxzh: "" };
      this.detailsForm = { skjs: [], kcxzh: "" };
    },
    // 部门下拉框
    loadDeptSelect() {
      this.$http.get("api/system/dept/select").then(res => {
        this.workList = res.data.data;
        this.myworkList = res.data.data;
      });
    },
    handleClose(done) {
      this.addForm = {};
      this.isShow = true;
      done();
    } // 关闭弹出框
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.takeNumber();
    this.loadDeptSelect();
  }
};
</script>

<style scoped lang="scss">
.courseInformation {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
}
</style>
