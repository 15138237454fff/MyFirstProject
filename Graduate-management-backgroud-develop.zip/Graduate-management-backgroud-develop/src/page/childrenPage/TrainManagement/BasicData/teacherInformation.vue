<!-- 教室信息维护 -->
<template>
  <div class="teacherInformation">
    <componment>
      <div slot="left" style="flex:2">
        <el-input v-model="searchField" placeholder="请输入教室名称" style="width: 200px" @keyup.enter.native="searchData" clearable @clear="clearinput" suffix-icon="el-icon-search"></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select v-model="tower" filterable style="margin-left: 10px;" clearable @change="loudong">
          <el-option label="全部楼栋" value="">
          </el-option>
          <el-option v-for="(item, $index) in towerList" :key="$index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right" style="flex:1">
        <el-button type="primary" @click="addNew" v-if="$btnAuthorityTest('teacherInformation:add')">添加</el-button>
        <el-button type="danger" @click="deleteInfor" v-if="$btnAuthorityTest('teacherInformation:delete')">删除</el-button>
        <el-button @click="exportInfo" v-if="$btnAuthorityTest('teacherInformation:export')">导出</el-button>
      </div>
    </componment>
    <el-table :data="tableData" border ref="multipleTable" style="width: 100%" @selection-change="mySelect" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
      <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
      </el-table-column>
      <el-table-column prop="jsh" label="教室号" width="150"> </el-table-column>
      <el-table-column prop="jsmc" label="教室名称"> </el-table-column>
      <el-table-column prop="jslb" label="教室类型">
        <template slot-scope="scope">
          <span>{{ scope.row.jslxm | jslb(typeList) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="jxlh" label="所属楼栋"> </el-table-column>
      <el-table-column prop="zws" label="座位数"> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span class="tablexq" @click="checkDetails(scope.row)" v-if="$btnAuthorityTest('teacherInformation:view')">查看</span>
          <span v-if="
              $btnAuthorityTest('teacherInformation:view') &&
                $btnAuthorityTest('teacherInformation:update')
            ">|</span>
          <span class="tablexg" @click="tablexg(scope.row)" v-if="$btnAuthorityTest('teacherInformation:update')">修改</span>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList" v-if="freshpag"></pagination>
    <el-dialog title="教室详情" :visible.sync="detailsDialog" :before-close="handleClose" width="720px" class="detailsCheck" :close-on-click-modal="false">
      <p class="hr"></p>
      <el-form :model="detailsForm" label-width="130px" ref="detailsForm" :rules="rules">
        <el-row>
          <el-col :span="10">
            <el-form-item label="教室号：">
              <span>{{ detailsForm.jsh }}</span>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="教室名称：">
              <span>{{ detailsForm.jsmc }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10" :offset="2">
            <el-form-item label="楼栋：">
              <span>{{ detailsForm.jxlh | jxlh(towerListxq) }}</span>
            </el-form-item>
          </el-col>
          <el-col :span="10">
            <el-form-item label="教室类型：">
              <span>{{ detailsForm.jslxm | jslb(typeList) }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10" :offset="2">
            <el-form-item label="座位数：">
              <span>{{ detailsForm.zws }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="考试座位数：">
              <span>{{ detailsForm.kszws }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <el-form-item label="教室占用情况：">
              <el-table :data="jstable" border style="width: 90%">
                <el-table-column prop="date" label="周次"> </el-table-column>
                <el-table-column prop="name" label="节次"> </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-dialog>
    <el-dialog :title="addclass" :visible.sync="addDialog" :before-close="handleClose" width="730px" :close-on-click-modal="false">
      <p class="hr"></p>
      <el-form :model="addForm" label-width="130px" ref="addForm" :rules="rules">
        <el-row>
          <el-col :span="10">
            <el-form-item label="教室号：" prop="jsh">
              <el-input style="width:200px" v-model="addForm.jsh" :disabled="jshxg"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="教室名称：" prop="jsmc">
              <el-input style="width:200px" v-model="addForm.jsmc"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属楼栋：" prop="jxlh">
              <el-select v-model="addForm.jxlh" filterable placeholder="请选择" style="width: 200px;">
                <el-option v-for="(item, index) in towerList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="教室类型：" prop="jslxm">
              <el-select v-model="addForm.jslxm" filterable placeholder="请选择" style="width: 200px;">
                <el-option v-for="item in typeList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="考试座位数：">
              <el-input style="width:200px" v-model.number="addForm.kszws" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="座位数：" prop="zws">
              <el-input style="width:200px" v-model.number="addForm.zws" autocomplete="off"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <el-form-item label="教室占用情况：">
              <el-table :data="jstable" border style="width: 90%">
                <el-table-column prop="date" label="周次"> </el-table-column>
                <el-table-column prop="name" label="节次"> </el-table-column>
              </el-table>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div style="text-align: center">
          <el-button @click="addcencal('addForm')">取 消</el-button>
          <el-button type="primary" @click="addaffirm('addForm')">确 定</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "teacherInformation",
  data() {
    return {
      jstable: [],
      rules: {
        jsh: [{ required: true, message: "请输入教室号", trigger: "blur" }],
        jsmc: [{ required: true, message: "请输入教室名称", trigger: "blur" }],
        jslxm: [
          { required: true, message: "请选择教室类型", trigger: "change" }
        ],
        jxlh: [
          { required: true, message: "请选择所属楼栋", trigger: "change" }
        ],
        zws: [
          { required: true, message: "请输入座位数", trigger: "blur" },
          { type: "number", message: "座位数必须为数字值" }
        ],
        kszws: [
          { required: true, message: "请输入考试座位数", trigger: "blur" },
          { type: "number", message: "考试座位数必须为数字值" }
        ]
      },
      cancelshow: true,
      cancelshows: false,
      isShow: true,
      typeList: [],
      detailsForm: {
        number: "",
        name: "",
        college: "",
        tower: "",
        type: "",
        seatNum: "",
        ksseatNum: ""
      }, // 查看详情列表
      addForm: {
        number: "",
        name: "",
        college: "",
        tower: "",
        type: "",
        seatNum: "",
        ksseatNum: ""
      }, // 添加班级列表
      addDialog: false, // 添加班级
      detailsDialog: false, // 查看详情
      searchField: "", // 搜索的数据
      tableData: [],
      towerList: [], // 单位列表
      collegeList: [], // 所属校区列表
      schoolList: [], // 所属学院列表
      majorList: [], // 所属专业列表
      gradeList: [], // 年级列表
      eductionalList: [], // 学制列表
      tower: "", // 选中楼栋
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      rowid: "",
      loading2: false,
      multipleTable: [],
      towerListxq: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      addclass: "添加教室",
      freshpag: true,
      jshxg: false
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  filters: {
    jxlh(val, row) {
      if (val && row) {
        const valindex = row.find((el, index) => el.ldh === val);
        if (valindex) {
          return valindex.ldmc;
        } else {
          return "";
        }
      }
    },
    jslb(val, row) {
      if (val && row) {
        const valindex = row.find((el, index) => el.value === val);
        if (valindex) {
          return valindex.label;
        } else {
          return "";
        }
      }
    }
  },
  methods: {
    tablexg(row) {
      this.jshxg = true;
      this.addclass = "修改教室";
      this.$http.get("api/cultivate/classRoom/" + row.jsh).then(res => {
        this.addForm = res.data.data;
        this.addDialog = true;
      });
    },
    loudong() {
      this.freshform();
    },
    clearinput() {
      this.searchField = "";
      this.freshform();
    },
    addcencal(formName) {
      this.$refs[formName].resetFields();
      this.addDialog = false;
      this.addForm = {
        number: "",
        name: "",
        college: "",
        tower: "",
        type: "",
        seatNum: "",
        ksseatNum: ""
      };
    },
    addaffirm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.addclass === "添加教室") {
            this.$http
              .post("api/cultivate/classRoom", this.addForm)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    type: "success",
                    message: res.data.message
                  });
                  this.addDialog = false;
                  this.$refs[formName].resetFields();
                  this.freshform();
                } else {
                  this.$message.error(res.data.message);
                }
              });
          }
          if (this.addclass === "修改教室") {
            this.$http
              .put("api/cultivate/classRoom", this.addForm)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    type: "success",
                    message: res.data.message
                  });
                  this.$refs[formName].resetFields();
                  this.addDialog = false;
                  this.freshform();
                } else {
                  this.$message.error(res.data.messsage);
                }
              });
          }
        } else {
          return false;
        }
      });
    }, // 确认添加
    freshform() {
      this.addForm = {
        number: "",
        name: "",
        college: "",
        tower: "",
        type: "",
        seatNum: "",
        ksseatNum: ""
      };
      this.freshpag = false;
      setTimeout(() => {
        this.freshpag = true;
      }, 500);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post(
          `api/cultivate/classRoom/search/${params.pageNum}/${params.pageSize}`,
          {
            jsmc: this.searchField,
            jxlh: this.tower
          }
        )
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    takeSelectList() {
      this.$http.get("api/cultivate/classRoom/selectxqld/").then(res => {
        if (res.data.data.xtLds.length == 0) {
          this.towerList = [];
          this.towerListxq = [];
        } else {
          res.data.data.xtLds.map((item, index) => {
            const obj = {
              value: item.ldh,
              label: item.ldmc
            };
            this.towerList.push(obj);
          });
          this.towerListxq = res.data.data.xtLds;
        }
        if (res.data.data.jslbs.length == 0) {
          this.typeList = [];
        } else {
          res.data.data.jslbs.map((item, index) => {
            const obj = {
              value: item.code,
              label: item.name
            };
            this.typeList.push(obj);
          });
        }
        if (res.data.data.xxXqjbsjbs.length == 0) {
          this.collegeList = [];
        } else {
          res.data.data.xxXqjbsjbs.map((item, index) => {
            const obj = {
              value: item.xqh,
              label: item.xqm
            };
            this.collegeList.push(obj);
          });
        }
      });
    },
    mySelect(selection) {
      this.multipleTable = [];
      selection.forEach(element => {
        this.multipleTable.push(element.id);
      });
    }, // 列表选择
    searchData() {
      this.freshform();
    }, // 搜索数据方法
    addNew() {
      this.addDialog = true;
      this.jshxg = false;
      this.addclass = "添加教室";
    }, // 添加数据
    deleteInfor() {
      if (this.multipleTable.length == 0) {
        this.$message({
          type: "error",
          message: "请勾选在进行删除"
        });
        return false;
      }
      this.$confirm("删除该教室, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .delete("api/cultivate/classRoom/" + this.multipleTable)
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  type: "error",
                  message: res.data.message
                });
              } else {
                this.$message({
                  type: "success",
                  message: "删除成功!"
                });
                this.freshform();
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }, // 删除数据
    exportInfo() {
      window.location.href = "api/cultivate/classRoom/export";
    }, // 导出数据
    checkDetails(row) {
      this.detailsDialog = true;
      this.isShow = true;
      this.$http.get("api/cultivate/classRoom/" + row.jsh).then(res => {
        this.detailsForm = res.data.data;
      });

      this.rowid = row.id;
    }, // 查看详情
    handleClose(done) {
      this.isShow = true;
      done();
      this.addForm = {
        number: "",
        name: "",
        college: "",
        tower: "",
        type: "",
        seatNum: "",
        ksseatNum: ""
      };
    }, // 关闭弹出框
    empty() {
      this.addForm = {};
      this.detailsForm = {};
      this.isShow = true;
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeSelectList();
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.teacherInformation {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
}
</style>
