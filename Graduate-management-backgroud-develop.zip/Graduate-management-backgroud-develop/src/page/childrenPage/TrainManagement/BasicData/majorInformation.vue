<!-- 专业信息管理 -->
<template>
  <div class="majorInformation">
    <componment>
      <div slot="left" style="flex:2">
        <el-input v-model="searchField" placeholder="请输入专业名称" style="width: 200px" @keyup.enter.native="searchData" clearable @clear="clearinput" suffix-icon="el-icon-search"></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select v-model="unit" filterable style="margin-left: 10px;" @change="takeList()">
          <el-option value="" label="全部学院"></el-option>
          <el-option v-for="item in deptList" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right" style="flex:1">
        <el-button @click="szxz" type="primary" v-if="$btnAuthorityTest('majorInformation:set')">设置学制</el-button>
        <el-button @click="exportInfo" v-if="$btnAuthorityTest('majorInformation:export')">导出</el-button>
      </div>
    </componment>
    <el-table :data="tableData" border ref="multipleTable" style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中" @selection-change="handleSelectionChange">
      <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
      </el-table-column>
      <el-table-column prop="zyh" label="专业代码" width="150">
      </el-table-column>
      <el-table-column prop="zymc" label="专业名称"> </el-table-column>
      <el-table-column prop="zyjc" label="专业简称"> </el-table-column>
      <el-table-column prop="dwmc" label="所属学院"> </el-table-column>
      <el-table-column prop="pyccmc" label="培养层次"> </el-table-column>
      <el-table-column prop="xzmc" label="学制"> </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
    <el-dialog title="提示" :visible.sync="dialogVisible" width="350px">
      <el-form ref="form" :model="sizeForm" label-width="120px" size="mini">
        <el-form-item label="硕士学制：">
          <el-input-number v-model="sizeForm.ss" controls-position="right" :min="1" :max="10" :precision="1"></el-input-number><span style="margin-left:5px">年</span>
        </el-form-item>
        <el-form-item label="博士学制：">
          <el-input-number v-model="sizeForm.bs" controls-position="right" :min="1" :max="10" :precision="1"></el-input-number><span style="margin-left:5px">年</span>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div style="text-align:center">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="szxzconfig">确 定</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import "@/components/common/common.scss";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "majorInformation",
  data() {
    return {
      searchField: "", // 搜索的数据
      tableData: [], // 单位列表
      deptList: [],
      unit: "", // 选中单位
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      loading2: false,
      dialogVisible: false,
      sizeForm: {
        ss: null,
        bs: null
      },
      multipleSelections: []
    };
  },
  components: {
    componment: componment,
    pagination: pagination
  },
  methods: {
    szxz() {
      if (this.multipleSelections.length == 0) {
        return this.$message.error("请勾选数据再进行设置学制");
      }
      this.dialogVisible = true;
      this.sizeForm = {
        ss: null,
        bs: null
      };
    },
    szxzconfig() {
      this.$http
        .put("api/cultivate/major/setLength", {
          xz: `${this.sizeForm.ss},${this.sizeForm.bs}`,
          list: this.multipleSelections
        })
        .then(res => {
          if (res.data.code == 200) {
            this.fresh();
            this.dialogVisible = false;
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    clearinput() {
      this.searchField = "";
      this.fresh();
    },
    fresh() {
      this.listQuery.queryPage.pageNum = 1;
      this.takeList();
    },
    handleSelectionChange(rows) {
      this.multipleSelections = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelections.push(row.id);
        });
      }
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/cultivate/major/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          collegeCode: this.unit
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.list;
          this.total = res.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查看专业列表
    searchData() {
      this.fresh();
    }, // 搜索数据方法
    exportInfo() {}, // 导出数据
    // 机构下拉
    loadDeptSelect() {
      this.$http.get("api/system/dept/select").then(res => {
        this.deptList = res.data.data;
        this.fresh();
      });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.loadDeptSelect();
  }
};
</script>

<style lang="scss">
.majorInformation {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
}
</style>
