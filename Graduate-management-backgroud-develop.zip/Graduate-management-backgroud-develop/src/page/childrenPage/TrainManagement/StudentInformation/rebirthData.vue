<!-- 新生数据维护 -->
<template>
  <div class="rebirthData">
    <div
      class="container"
      v-if="
        $store.state.rebirthInfor == false &&
          $store.state.teachDistribution == false &&
          $store.state.classDistribution == false
      "
    >
      <div class="header-left">
        <el-input
          v-model="searchField"
          placeholder="请输入考生编号/姓名"
          style="width: 200px"
          @keyup.enter.native="searchData"
          class="top-input"
          clearable
          @clear="clearinput"
        ></el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
        <el-select
          v-model="college"
          filterable
          placeholder="全部学院"
          style="margin-left: 10px;"
          class="top-input"
          @change="collegeChange"
        >
          <el-option
            v-for="(item, index) in collegeList"
            :key="index"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
        <el-select
          v-model="major"
          filterable
          placeholder="全部专业"
          style="margin-left: 10px;"
          class="top-input"
        >
          <el-option
            v-for="(item, index) in majorList"
            :key="index"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          @click="synchronizedClick"
          v-if="$btnAuthorityTest('rebirthData:sync')"
          >同步考生数据</el-button
        >
        <el-button
          type="primary"
          @click="stuClick"
          v-if="$btnAuthorityTest('rebirthData:set')"
          >编学号</el-button
        >
        <el-button
          type="primary"
          @click="teachClick"
          v-if="$btnAuthorityTest('rebirthData:disds')"
          >分导师</el-button
        >
        <el-button
          type="primary"
          @click="classClick"
          v-if="$btnAuthorityTest('rebirthData:disclass')"
          >分班</el-button
        >
        <el-button
          type="primary"
          @click="oneKeyPass"
          v-if="$btnAuthorityTest('rebirthData:import')"
          >转入正式表</el-button
        >
        <!--<el-button type="primary">导出</el-button>-->
      </div>
      <div class="table">
        <el-table
          v-loading="loading2"
          element-loading-text="加载中"
          :data="tableData"
          border
          ref="multipleTable"
          style="width: 100%; margin-top: 15px;"
          :cell-style="cellStyle"
          :header-cell-style="$storage.tableHeaderColor"
          :height="tableHeight"
          border
          fit
          highlight-current-row
        >
          <!--<el-table-column :show-overflow-tooltip="true" type="selection" width="55">-->
          <!--</el-table-column>-->
          <el-table-column label="序号" type="index" width="55" align="center">
            <template slot-scope="scope">
              <span>{{ (currentPage - 1) * pageSize + scope.$index + 1 }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="zkzh" label="考生编号" width="150">
          </el-table-column>
          <el-table-column prop="xm" label="姓名"> </el-table-column>
          <el-table-column prop="xbm" label="性别"> </el-table-column>
          <el-table-column prop="xy" label="所属学院"> </el-table-column>
          <el-table-column prop="zy" label="所属专业"> </el-table-column>
          <el-table-column prop="xh" label="学号" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="bj" label="班级" show-overflow-tooltip>
          </el-table-column>
          <el-table-column prop="ds" label="导师" show-overflow-tooltip>
          </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                type="text"
                @click="checkDetails(scope.row)"
                v-if="$btnAuthorityTest('rebirthData:view')"
                >查看详情</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <div class="block">
          <el-pagination
            :current-page.sync="currentPage"
            :page-sizes="[15, 25, 50, 100]"
            :page-size="pageSize"
            class="import"
            layout="total, sizes, prev, pager, next, jumper"
            @current-change="changePage"
            :total="total"
            @size-change="sizeChange"
          >
          </el-pagination>
        </div>
      </div>
    </div>
    <rebDetails
      v-if="$store.state.rebirthInfor == true"
      :zkzh="zkzh"
    ></rebDetails>
    <teach v-if="$store.state.teachDistribution == true"></teach>
    <myClass v-if="$store.state.classDistribution == true"></myClass>
    <el-dialog
      title="编学号"
      :visible.sync="stuDialog"
      :before-close="myhandleClose"
      width="420px"
      :close-on-click-modal="false">
      <p class="hr"></p>
      <div
        class="numAddress"
        v-loading="createNumLoading"
        element-loading-text="学号生成中,请等待!"
      >
        <el-row
          v-for="(item, index) in stunumList"
          :key="'info2-' + index"
          style="margin-bottom: 20px;"
        >
          <!--{{item.startnumber}} ~-->
          <!--<el-input style="width: 50px; margin: 0 50px 0 20px;" v-model.number="item.endnumber" type="number"-->
          <!--maxlength="2" @change="((value)=>{changeInput(value, index)})">-->
          <!--</el-input>-->
          <!--位-->
          <el-select
            v-model="item.rule"
            filterable
            style="margin-left: 10px; width: 200px;"
            class="top-input"
            @change="
              value => {
                changeStatus(value, index);
              }
            "
          >
            <el-option
              v-for="_item in item.ruleList"
              :key="_item.key"
              :label="_item.label"
              :value="_item.value"
            >
            </el-option>
          </el-select>
          取
          <el-select
            v-model="item.access"
            style="margin-left: 10px; width: 60px;"
            class="top-input"
          >
            <!--@change="((value)=>{changeNumber(value, index, item)})">-->
            <el-option
              v-for="_item in item.accessList"
              :key="_item.key"
              :label="_item.label"
              :value="_item.value"
            >
            </el-option>
          </el-select>
          位
          <button
            class="deleteBut"
            @click="deleteClass(index)"
            v-show="index + 1 == stunumList.length"
          ></button>
        </el-row>
      </div>
      <el-button @click="addNumber">增加编号栏目</el-button>
      <span slot="footer" class="dialog-footer">
        <el-button @click="stuDialog = false">取 消</el-button>
        <el-button type="primary" @click="numberAffirm">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="同步考生数据"
      :visible.sync="synchronizedDialog"
      width="400px"
    >
      <p class="hr"></p>
      录取年份：
      <el-select
        v-model="time"
        filterable
        placeholder="请选择"
        style="margin-left: 10px;"
        class="top-input"
      >
        <el-option
          v-for="item in timeList"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      <!--<span style="text-align: center; width: 400px; float: left">入学年份：{{this.time_year}}</span>-->
      <span slot="footer" class="dialog-footer">
        <el-button @click="synchronizedDialog = false">取 消</el-button>
        <el-button type="primary" @click="studentHandle">开始同步</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import rebDetails from "./rebcomponents/rebDetails";
import teach from "./rebcomponents/teachDistribution";
import myClass from "./rebcomponents/classDistribution";
import { setTimeout } from "timers";

export default {
  name: "rebirthData",
  data() {
    return {
      zkzh: "", // 准考证号
      totalList: [
        "学生类别",
        "录取类别",
        "录取年份",
        "学院代码",
        "专业代码",
        "校区代码",
        "流水号"
      ], // 所有类别的列表
      typeList: [
        {
          key: 1,
          value: "学生类别",
          label: "学生类别",
          length: 2
        },
        {
          key: 2,
          value: "录取类别",
          label: "录取类别",
          length: 2
        },
        {
          key: 3,
          value: "录取年份",
          label: "录取年份",
          length: 4
        },
        {
          key: 4,
          value: "学院代码",
          label: "学院代码",
          length: 3
        },
        {
          key: 5,
          value: "专业代码",
          label: "专业代码",
          length: 6
        },
        {
          key: 6,
          value: "校区代码",
          label: "校区代码",
          length: 2
        },
        {
          key: 7,
          value: "流水号",
          label: "流水号",
          length: 3
        }
      ],
      stunumList: [
        {
          startnumber: 1,
          endnumber: "",
          rule: "学生类别",
          ruleList: [],
          access: 1,
          accessList: []
        },
        {
          startnumber: 2,
          endnumber: "",
          rule: "录取类别",
          ruleList: [],
          access: 1,
          accessList: []
        },
        {
          startnumber: 3,
          endnumber: "",
          rule: "录取年份",
          ruleList: [],
          access: 1,
          accessList: []
        },
        {
          startnumber: 4,
          endnumber: "",
          rule: "学院代码",
          ruleList: [],
          access: 1,
          accessList: []
        },
        {
          startnumber: 5,
          endnumber: "",
          rule: "流水号",
          ruleList: [],
          access: 1,
          accessList: []
        }
      ],
      access: 1, // 取数规则
      rule: "",
      stuForm: [{}],
      number: 1,
      synchronizedDialog: false,
      stuDialog: false,
      tableData: [],
      time: 0,
      timeList: [],
      searchField: "", // 搜索的数据
      college: "", // 选中的学院
      collegeList: [], // 学院列表
      major: "", // 选中的专业
      majorList: [], // 专业列表
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      currentPage: 1,
      total: 1, // 总数据条数
      pageSize: 15,
      timer: null, // 学院，专业下拉框
      loading2: false,
      createNumLoading: false
    };
  },
  watch: {
    college(val) {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.takeList(1);
      }, 1500);
    },
    major(val) {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.takeList(1);
      }, 1500);
    }
  },
  beforeDestroy() {
    clearTimeout(this.timer);
  },
  methods: {
    timeFormate(timeStamp) {
      this.time_year = new Date(timeStamp).getFullYear();
    },

    clearinput() {
      this.searchField = "";
      this.currentPage = 1;
      this.takeList(1);
    },
    // 学院修改事件
    collegeChange(val) {
      const temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.majorList = temp.children;
    },
    numberAffirm() {
      const numberArr = [];
      this.stunumList.map((item, index) => {
        this.typeList.map((_item, _index) => {
          if (item.rule == _item.value) {
            console.log(
              "item.rule=" + item.rule + " _item.value=" + _item.value,
              " _item.key=" + _item.key + " item.access=" + item.access
            );
            let obj = {
              gz: _item.key,
              // jsw: item.endnumber,
              // qsw: item.startnumber,
              qscd: item.access,
              id: _item.key
            };
            numberArr.push(obj);
          }
        });
      });
      this.createNumLoading = true;
      this.$http
        .put("api/cultivate/newStudent/insertXh", numberArr)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "编学号成功"
            });
            this.stuDialog = false;
          } else {
            this.$message.error({ message: "编学号失败" });
          }
          this.loading2 = true;
          this.takeList(1);
          this.createNumLoading = false;
        })
        .catch(function(err) {
          console.log(err);
        });
    }, // 确认编学号
    changeNumber(value, index, item) {
      // console.log("value=" + value + " index=" + index + " item=" + item);
      // if (value == 1) {
      //   this.typeList.map((_item, index) => {
      //     if (item.student == _item.value) {
      //       item.endnumber = item.startnumber + _item.length - 1;
      //     }
      //   });
      // } else if (value == 2) {
      //   this.stunumList[index + 1].startnumber =
      //     this.stunumList[index].endnumber + 1;
      // }
      // for (let i = 1; i < this.stunumList.length - index; i++) {
      //   this.stunumList[index + i].startnumber =
      //     this.stunumList[index].endnumber + i;
      // }
    }, // 修改参数
    deleteClass(index) {
      this.stunumList.map((item, index) => {
        item.ruleList = [];
        item.accessList = [];
      });
      this.stunumList.splice(index, 1);
      this.stuNumHandle();
    }, // 删除编学号规则
    oneKeyPass() {
      console.log("转入正式库");
      this.$http
        .post("api/cultivate/newStudent/insertToFormality")
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: res.data.message
            });
          } else {
            this.$message.error({ message: res.data.message });
          }
        })
        .catch(function(err) {
          console.log(err);
        });
      this.takeList();
    }, // 转入正式表
    studentHandle() {
      console.log(this.time);
      this.$http
        .get("api/cultivate/newStudent/selectAll/" + this.time)
        .then(res => {
          console.info(res.data);
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: res.data.message
            });
          } else {
            this.$message.error({ message: res.data.message });
          }
        })
        .catch(function(err) {
          console.log(err);
        });
      this.takeList();
      this.synchronizedDialog = false;
    }, // 同步考生数据
    cellStyle(row, column, rowIndex, columnIndex) {
      // console.log(row);
      // console.log(row.column);
      if (
        (row.column.label === "学号" && row.row.xh === "待分配") ||
        (row.column.label === "班级" && row.row.bj === "待分配") ||
        (row.column.label === "导师" && row.row.ds === "待分配")
      ) {
        return "color:orange";
      }
    },
    takeList() {
      this.loading2 = true;
      this.$http
        .post("api/cultivate/newStudent/query", {
          query: this.searchField,
          pageNum: this.currentPage,
          pageSize: this.pageSize,
          xy: this.college,
          zy: this.major
        })
        .then(res => {
          this.loading2 = false;
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 500);
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 获取列表

    empty() {
      this.stunumList[0].rule = "学生类别";
      this.stunumList[1].rule = "录取类别";
      this.stunumList[2].rule = "录取年份";
      this.stunumList[3].rule = "学院代码";
      this.stunumList[4].rule = "流水号";
      this.stunumList.splice(5, this.stunumList.length - 5);
      this.stunumList.map((item, index) => {
        item.ruleList = [];
        item.accessList = [];
      });
    },
    changeStatus(value, index) {
      this.stunumList[index].rule = value;
      this.clearRuleList();
      this.stuNumHandle();
      // console.log(this.stunumList)
    }, // 切换select选项
    clearRuleList() {
      this.stunumList.map((item, index) => {
        item.ruleList = [];
        item.accessList = [];
      });
    },
    handleClose(done) {
      done();
    },
    myhandleClose(done) {
      this.empty();
      done();
    },
    addNumber() {
      // console.log(this.stunumList[0].rule)
      if (this.stunumList.length >= this.totalList.length) return;
      let obj = {
        rule: "",
        ruleList: [],
        accessList: []
      };
      this.stunumList.push(obj);
      this.clearRuleList();
      // this.totalList.map((item, index) => {
      //   let canAdd = true;
      //   for (let i = 0; i < this.stunumList.length; i++) {
      //     // console.log("item="+item+" this.stunumList[i].rule="+this.stunumList[i].rule)
      //     if (item == this.stunumList[i].rule) {
      //       canAdd = false;
      //       continue;
      //     }
      //   }
      //   if(canAdd){
      //     let ruleObj = {
      //       key: this.stunumList.length,
      //       value: item,
      //       label: item
      //     };
      //     obj.ruleList.push(ruleObj);
      //   }
      // })
      // obj.rule = obj.ruleList[0].value;
      // console.log("obj.ruleList.length="+obj.ruleList.length)

      this.stuNumHandle();
      obj.ruleList.splice(0, 1);
    }, // 增加编号栏目
    synchronizedClick() {
      this.synchronizedDialog = true;
      this.time = new Date().getFullYear();
      let obj = {
        value: this.time - 1,
        label: this.time - 1
      };
      let obj1 = {
        value: this.time,
        label: this.time
      };
      let obj2 = {
        value: this.time + 1,
        label: this.time + 1
      };
      this.timeList = [obj, obj1, obj2];
    }, // 同步
    stuClick() {
      this.stuDialog = true;
      this.stunumList.map((item, index) => {
        item.ruleList = [];
        item.accessList = [];
      });
      this.stuNumHandle();
    }, // 分编学号
    stuNumHandle() {
      const arr = [];

      // 添加位数列表
      this.stunumList.map((item, index) => {
        console.log("item.rule=" + item.rule);
        arr.push(item.rule);
        this.typeList.map((type_item, type_index) => {
          if (item.rule == type_item.value) {
            for (let i = 0; i < type_item.length; i++) {
              const obj = {
                key: i + 1,
                value: i + 1,
                label: i + 1
              };
              console.log("添加位数列表=" + obj.value);
              item.accessList.push(obj);
            }
            item.access = type_item.length;
          }
        });
      });

      // 判断剩余规则列表
      let list = [];
      this.totalList.map((item, index) => {
        let count = true;
        for (let i = 0; i < arr.length; i++) {
          console.log("arr[" + i + "] = " + arr[i]);
          const element = arr[i];
          if (element == item) {
            count = false;
            continue;
          }
        }
        if (count) {
          console.log("判断剩余规则列表 item = " + item);
          list.push(item);
        }
        console.log("index = " + index + " listlength=" + list.length);
      });

      // 添加规则列表
      this.stunumList.map((item, index) => {
        const myArr = [];
        let totalArr = [];
        console.log("item.rule = " + item.rule);
        myArr.push(item.rule);
        totalArr = myArr.concat(list);
        totalArr.map((_item, _index) => {
          const obj = {
            key: _index,
            value: _item,
            label: _item
          };
          console.log("添加规则列表index=" + index + "value= " + obj.value);
          item.ruleList.push(obj);
        });
      });
    },

    searchData() {
      this.takeList(1);
    }, // 查看数据
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {
      console.log(selection);
    }, // 列表选择
    allClick(selection) {
      console.log(selection);
    }, // 列表全选
    checkDetails(row) {
      this.$store.state.rebirthInfor = true;
      this.zkzh = row.zkzh;
    },
    teachClick() {
      this.$store.state.teachDistribution = true;
    }, // 分导师
    classClick() {
      this.$store.state.classDistribution = true;
    },
    changePage(val) {
      this.takeList(val);
    }, // 切换页码
    sizeChange(val) {
      this.pageSize = val;
      this.takeList(1);
    }, // 改变一页的条数
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    // 学院专业联调数据
    getCollegeMajorData() {
      console.log("获取学院专业数据");
      this.$http.get("api/system/dict/select/college").then(res => {
        this.collegeList = res.data.data;
        this.majorList = this.collegeList[0].children;
      });
    }
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 170);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 170);
      })();
    };
    // this.pageSize = Math.floor(this.tableHeight / 57);
    this.takeList(1);
    this.timeFormate(new Date());
    // 学院专业联调数据
    this.getCollegeMajorData();
  },
  components: {
    rebDetails,
    teach,
    myClass
  }
};
</script>

<style scoped lang="scss">
.rebirthData {
  width: 100%;
  height: 100%;

  .container {
    width: 100%;
    height: 100%;

    .header-left {
      margin-top: 7px;
      float: left;
      margin-bottom: 10px;

      @media screen and (max-width: 1500px) {
        .top-input {
          width: 150px;
        }
      }
    }
    .header-right {
      margin-top: 7px;
      float: right;
      margin-right: 10px;
      margin-bottom: 10px;
    }

    .table {
      width: 100%;
    }
  }
  .numAddress {
    height: 300px;
    overflow: auto;
  }
}
.deleteBut {
  height: 20px;
  width: 20px;
  outline: none;
  border: none;
  background: url("../../../../assets/img/delete.png") no-repeat;
}

.rebirthData /deep/ input::-webkit-outer-spin-button,
.rebirthData /deep/ input::-webkit-inner-spin-button {
  -webkit-appearance: none;
}

.rebirthData /deep/ input[type="number"] {
  -moz-appearance: textfield !important;
}

.rebirthData /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}

.rebirthData /deep/ .dialog-footer button {
  margin: 0 20px;
  margin-top: 20px;
}

.rebirthData /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}

.rebirthData /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
</style>
