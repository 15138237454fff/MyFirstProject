<template>
  <div class="basicDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
      <el-button type="primary" @click="saveClick" class="fr">保存</el-button>
    </div>
    <table>
      <tr>
        <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 基本信息</td>
        <td rowspan="4">
          <img :src="resetForm.zp" alt="" style="width:100px;height:100px;display: inline;">
        </td>
      </tr>
      <tr>
        <td class="listcss">学号</td>
        <td>{{form.xh}}</td>
        <td class="listcss">姓名</td>
        <td>{{form.xsxm}}</td>
        <td class="listcss">姓名拼音</td>
        <td>{{resetForm.xmpy}}</td>
      </tr>
      <tr>
        <td class="listcss">性别</td>
        <td>{{resetForm.xbm | xbm}}</td>
        <td class="listcss">民族</td>
        <td>{{resetForm.mzm}}</td>
        <td class="listcss">出生日期</td>
        <td>{{resetForm.csrq}}</td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>婚姻状况</td>
        <td>
          <el-select v-model="resetForm.hyzkm" placeholder="未知">
            <el-option v-for="(item,index) in this.dict.hyzk" :value="item.value" :label="item.label" :key="index" />
          </el-select>
        </td>
        <td class="listcss">政治面貌</td>
        <td>{{resetForm.zzmmm}}</td>
        <td class="listcss"><span style="color:red">*</span>健康状况</td>
        <td>
          <el-select v-model="resetForm.jkzkm" placeholder="未知">
            <el-option v-for="(item,index) in this.dict.jkzk" :value="item.value" :label="item.label" :key="index" />
          </el-select>
        </td>
      </tr>
      <tr>
        <td class="listcss">国籍</td>
        <td>{{resetForm.gjmc}}</td>
        <td class="listcss">证件类型</td>
        <td>{{resetForm.sfzjlxm}}</td>
        <td class="listcss">证件号码</td>
        <td colspan="2">{{resetForm.sfzh}}</td>
      </tr>
      <tr>
        <td class="listcss">籍贯</td>
        <td>{{resetForm.jgmc}}</td>
        <td class="listcss">出生地</td>
        <td>{{resetForm.csdmc}}</td>
        <td class="listcss"><span style="color:red">*</span>户口所在地</td>
        <td colspan="2">
          <el-cascader :options="nativeList" v-model="resetForm.hkszd" style="width:400px" filterable :props="{ checkStrictly: true }" clearable></el-cascader>
        </td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>户口详细地址</td>
        <td colspan="6">
          <el-input v-model="resetForm.hkxxdz"></el-input>
        </td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>移动电话</td>
        <td>
          <el-input v-model="resetForm.yddh"></el-input>
        </td>
        <td class="listcss">固定电话</td>
        <td>
          <el-input v-model="resetForm.dh"></el-input>
        </td>
        <td class="listcss"><span style="color:red">*</span>电子邮箱</td>
        <td colspan="2">
          <el-input v-model="resetForm.dzxx"></el-input>
        </td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>邮政编码</td>
        <td>
          <el-input v-model="resetForm.yzbm"></el-input>
        </td>
        <td class="listcss">通讯地址</td>
        <td colspan="4">
          <el-input v-model="resetForm.txdz"></el-input>
        </td>
      </tr>
    </table>
    <table>
      <tr>
        <td class="listcss" colspan="8" style="text-align:left;font-weight:bold">| 学籍信息</td>
      </tr>
      <tr>
        <td class="listcss">学生类别</td>
        <td>{{form.xslbmc}}</td>
        <td class="listcss">学习方式</td>
        <td>{{form.xxfsmc}}</td>
        <td class="listcss">培养层次</td>
        <td colspan="4">{{form.pyccmc}}</td>
      </tr>
      <tr>
        <td class="listcss">入学年月</td>
        <td>{{form.rxny}}</td>
        <td class="listcss">年级</td>
        <td>{{form.sznj}}</td>
        <td class="listcss">学制</td>
        <td colspan="4">{{form.xz}}</td>
      </tr>
      <tr>
        <td class="listcss">所属学院</td>
        <td>{{form.ssyxmc}}</td>
        <td class="listcss">所属专业</td>
        <td>{{form.zy}}</td>
        <td class="listcss">研究方向</td>
        <td colspan="4">{{form.yjfx}}</td>
      </tr>
      <tr>
        <td class="listcss">班级</td>
        <td>{{form.bjmc}}</td>
        <td class="listcss">导师</td>
        <td>{{form.dsxm}}</td>
        <td class="listcss"><span style="color:red">*</span>当前状态</td>
        <td style="border:none">
          <el-select v-model="form.xsdqztm" placeholder="请选择">
            <el-option v-for="(item,index) in jzgzt" :value="item.value" :label="item.label" :key="index" />
          </el-select>
        </td>
        <td style="border:none;border-right:1px solid #e0e0e0"></td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>是否跨学科</td>
        <td colspan="6">
          <el-radio-group v-model="form.sfkk">
            <el-radio label="1">是</el-radio>
            <el-radio label="0">否</el-radio>
          </el-radio-group>
        </td>
      </tr>
    </table>
    <table>
      <tr>
        <td class="listcss" colspan="8" style="text-align:left;font-weight:bol  d">| 其他信息</td>
      </tr>
      <tr>
        <td class="listcss">
          <p>何时何地何原因受</p>
          <p>过何种奖励或处分</p>
        </td>
        <td colspan="7">
          <el-input v-model="resetForm.jcnr" type="textarea" :rows="3"></el-input>
        </td>
      </tr>
      <tr>
        <td class="listcss" :rowspan="resetForm.qtList.length+1"><span style="color:red">*</span>学习和工作经历</td>
        <td class="listcss" colspan="2">起止时间</td>
        <td class="listcss" colspan="2">学习或工作单位</td>
        <td class="listcss" colspan="2">职务</td>
        <td class="listcss">操作</td>
      </tr>
      <template v-for="(item,index) in resetForm.qtList">
        <tr>
          <td colspan="2">
            <el-date-picker v-model="item.kssj" type="date" placeholder="选择日期" format="yyyy-MM-dd">
            </el-date-picker>
            -
            <el-date-picker v-model="item.jssj" type="date" placeholder="选择日期" format="yyyy-MM-dd">
            </el-date-picker>
          </td>
          <td colspan="2">
            <el-input v-model="item.gzdw"></el-input>
          </td>
          <td colspan="2">
            <el-input v-model="item.zw"></el-input>
          </td>
          <td>
            <i class="el-icon-circle-plus" style="color:#409eff" @click="qtListadd(item,index)" v-if="index===resetForm.qtList.length-1"></i>
            <i class="el-icon-remove" style="color:#f56c6c" v-if="index!==resetForm.qtList.length-1" @click="qtListdelet(item,index)"></i>
          </td>
        </tr>
      </template>
      <tr>
        <td class="listcss" :rowspan="resetForm.jtcy.length+1"><span style="color:red">*</span>家庭主要成员</td>
        <td class="listcss">姓名</td>
        <td class="listcss">关系</td>
        <td class="listcss" colspan="2">工作单位</td>
        <td class="listcss">职务</td>
        <td class="listcss">联系方式</td>
        <td class="listcss">操作</td>
      </tr>
      <template v-for="(item,index) in resetForm.jtcy">
        <tr>
          <td>
            <el-input v-model="item.cyxm"></el-input>
          </td>
          <td>
            <el-select v-model="item.gxm" placeholder="请选择">
              <el-option v-for="(item,index) in jtgxlist" :value="item.value" :label="item.label" :key="index" />
            </el-select>
          </td>
          <td colspan="2">
            <el-input v-model="item.gzdw"></el-input>
          </td>
          <td>
            <el-select v-model="item.zy" placeholder="请选择">
              <el-option v-for="(item,index) in zw" :value="item.value" :label="item.label" :key="index" />
            </el-select>
          </td>
          <td>
            <el-input v-model="item.lxfs"></el-input>
          </td>
          <td>
            <i class="el-icon-circle-plus" style="color:#409eff" @click="jtcyadd(item,index)" v-if="index===resetForm.jtcy.length-1"></i>
            <i class="el-icon-remove" style="color:#f56c6c" v-if="index!==resetForm.jtcy.length-1" @click="jtcydelet(item,index)"></i>
          </td>
        </tr>
      </template>
    </table>
  </div>
</template>

<script>
export default {
  name: "basicDetails",
  props: ["xh1"],
  data() {
    return {
      dict: {},
      form: {
        jttx: {},
        xxgzjl: []
      },
      resetForm: {
        qtList: [],
        jtcy: [],
        hyzkm: "",
        jkzkm: "",
        hkszd: "",
        hkxxdz: "",
        yddh: "",
        dzxx: "",
        yzbm: ""
      },
      jtgxlist: [],
      jzgzt: [],
      nativeList: [],
      zw: [],
      hkszd: ""
    };
  },
  filters: {
    xbm(val) {
      switch (val) {
        case "1":
          return "男";
        case "2":
          return "女";
        case "0":
          return "未知性别";
        case "9":
          return "未说明性别";
        default:
          break;
      }
    }
  },
  methods: {
    // 学习和工作经历增加
    qtListadd(val, index) {
      const obj = {
        kssj: "",
        jssj: "",
        gzdw: "",
        zw: "",
        xh: this.xh1
      };
      this.resetForm.qtList.push(obj);
    },
    // 学习和工作经历删除
    qtListdelet(val, index) {
      this.resetForm.qtList.splice(
        this.resetForm.qtList.findIndex(item => item === val),
        1
      );
    },
    // 家庭主要成员添加
    jtcyadd(val, index) {
      const obj = {
        cyxm: "",
        gxm: "",
        lxfs: "",
        gzdw: "",
        zy: ""
      };
      this.resetForm.jtcy.push(obj);
    },
    // 家庭主要成员删除
    jtcydelet(val, index) {
      this.resetForm.jtcy.splice(
        this.resetForm.jtcy.findIndex(item => item === val),
        1
      );
    },
    // 数据列表
    takeList() {
      this.$http.get("api/cultivate/stu/xjsj/" + this.xh1).then(res => {
        if (!res.data.data) {
          this.$message.error({
            message: "数据为空"
          });
          this.$store.state.studInformation = false;
        } else {
          this.form = res.data.data;

          this.$storage.addObjectKey(res.data.data, this.form);
        }
      });
      this.$http.get("api/cultivate/stu/jbxx/" + this.xh1).then(res => {
        if (!res.data.data) {
          this.$message.error({
            message: "数据为空"
          });
          this.$store.state.studInformation = false;
        } else {
          this.resetForm = res.data.data;
          // 学习和工作经历
          if (this.resetForm.qtList.length == 0) {
            const obj = { kssj: "", jssj: "", gzdw: "", zw: "", xh: this.xh1 };
            this.resetForm.qtList.push(obj);
          }
          // 家庭主要成员
          if (this.resetForm.jtcy.length == 0) {
            const obj = { cyxm: "", gxm: "", lxfs: "", gzdw: "", zy: "" };
            this.resetForm.jtcy.push(obj);
          }
          this.resetForm.hkszd = this.resetForm.hkszd.split(",");
          this.$storage.addObjectKey(res.data.data, this.resetForm);
          this.$http.get("api/system/dict/select/all").then(res => {
            // 关系
            this.jtgxlist = res.data.data.jtgx;
            this.zw = res.data.data.zw;
            this.jzgzt = res.data.data.xszt;
            // 政治面貌
            this.resetForm.zzmmm = res.data.data.zzmm.find(
              (el, index) => el.value === this.resetForm.zzmmm
            ).label;
            this.resetForm.sfzjlxm = res.data.data.zjlx.find(
              (el, index) => el.value === this.resetForm.sfzjlxm
            ).label;
            // 民族
            this.resetForm.mzm = res.data.data.mz.find(
              (el, index) => el.value == this.resetForm.mzm
            ).label;
          });
          this.$http.get("api/system/dict/select/origoLevelThree").then(res => {
            this.nativeList = res.data.data;
          });
        }
      });
    },
    exitList() {
      this.$store.state.studInformation = false;
    },
    saveClick() {
      var paramsYz = [
        "hyzkm",
        "jkzkm",
        "hkszd",
        "hkxxdz",
        "yddh",
        "dzxx",
        "yzbm"
      ];
      paramsYz.forEach(el => {
        if (!this.resetForm[el]) {
          this.$message.error("必填项不能为空!!");
          return false;
        }
      });
      this.resetForm.hyzkmc = this.dict.hyzk.find(
        (el, index) => el.value === this.resetForm.hyzkm
      ).label;
      this.resetForm.jkzkmc = this.dict.jkzk.find(
        (el, index) => el.value === this.resetForm.jkzkm
      ).label;
      if (this.form.xsdqztm) {
        this.resetForm.xsdqztmc = this.jzgzt.find(
          (el, index) => el.value === this.form.xsdqztm
        ).label;
      }
      // 筛选3级
      let hkszd = "";
      const hk =
        this.resetForm.hkszd.length == 1
          ? this.resetForm.hkszd.toString()
          : this.resetForm.hkszd[this.resetForm.hkszd.length - 1];
      this.nativeList.map(v => {
        if (v.value === hk) {
          hkszd = v.label;
        } else {
          if (v.children) {
            v.children.map(vv => {
              if (vv.value === hk) {
                hkszd = `${v.label}/${vv.label}`;
              } else {
                if (vv.children) {
                  vv.children.map(f => {
                    if (f.value === hk) {
                      hkszd = `${v.label}/${vv.label}/${f.label}`;
                    }
                  });
                }
              }
            });
          }
        }
      });
      if (!this.form.sfkk) {
        return this.$message.error("是否跨学科是必填项");
      }
      const formSubmit = {
        // 后台正常修改
        type: 0,
        studentBasicDTO: { 
          // 固定电话
          dh: this.resetForm.dh,
          // 电子信箱
          dzxx: this.resetForm.dzxx,
          // 户口所在地编码
          hkszd: hk,
          // 户口详细地址
          hkxxdz: this.resetForm.hkxxdz,
          // 婚姻状况码
          hyzkm: this.resetForm.hyzkm,
          hyzk: this.resetForm.hyzkmc,
          // 奖惩内容
          jcnr: this.resetForm.jcnr,
          // 健康状况码
          jkzkm: this.resetForm.jkzkm,
          jkzkmc: this.resetForm.jkzkmc,
          // 户口所在地名称
          hkszdmc: hkszd,
          // 通信地址
          txdz: this.resetForm.txdz,
          // 学号
          xh: this.form.xh,
          // 学生当前状态码
          xsdqztm: this.form.xsdqztm,
          // 学籍表中的学生当前状态名称
          xsdqztmc: this.resetForm.xsdqztmc,
          // 移动电话
          yddh: this.resetForm.yddh,
          // 邮政编码
          yzbm: this.resetForm.yzbm,
          sfkk: this.form.sfkk
        },
        jtcy: this.resetForm.jtcy,
        qtList: this.resetForm.qtList
      };
      this.$http.put("api/cultivate/stu", formSubmit).then(res => {
        this.$message({
          message: res.data.message,
          type: res.data.code == 200 ? "success" : "error"
        });
        if (res.data.code == 200) {
          this.$store.state.studInformation = false;
        }
      });
    },
    // 加载数据字典
    loadDict() {
      this.$http.get("api/system/dict/select/all").then(res => {
        this.dict = res.data.data;
      });
    }
  },
  mounted() {
    this.takeList();
    this.loadDict();
  }
};
</script>

<style scoped lang="scss">
.el-select {
  width: 90%;
  padding-left: 15px;
}

.fr {
  float: right;
  margin: 10px 15px 0 0;
}

.fl {
  float: left;
}

.basicDetails {
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }

  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;

    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }

  table {
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 150px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 150px;
    }
  }

  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
}

.basicDetails /deep/ .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}

.basicDetails /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}

.basicDetails /deep/ .el-form-item__label {
  text-align: center;
}
</style>
