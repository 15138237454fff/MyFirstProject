<template>
  <div class="basicDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <table>
      <tr>
        <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 基本信息</td>
        <td rowspan="4">
          <img :src="resetForm.zp" alt="" style="width:100px;height:100px;display: inline;">
        </td>
      </tr>
      <tr>
        <td class="listcss">学号</td>
        <td>{{form.xh}}</td>
        <td class="listcss">姓名</td>
        <td>{{form.xsxm}}</td>
        <td class="listcss">姓名拼音</td>
        <td>{{resetForm.xmpy}}</td>
      </tr>
      <tr>
        <td class="listcss">性别</td>
        <td>{{resetForm.xbmc}}</td>
        <td class="listcss">民族</td>
        <td>{{resetForm.mzm}}</td>
        <td class="listcss">出生日期</td>
        <td>{{resetForm.csrq}}</td>
      </tr>
      <tr>
        <td class="listcss">婚姻状况</td>
        <td>{{resetForm.hyzkm}}</td>
        <td class="listcss">政治面貌</td>
        <td>{{resetForm.zzmmm}}</td>
        <td class="listcss">健康状况</td>
        <td>{{resetForm.jkzkm}}</td>
      </tr>
      <tr>
        <td class="listcss">国籍</td>
        <td>{{resetForm.gjmc}}</td>
        <td class="listcss">证件类型</td>
        <td>{{resetForm.sfzjlxm}}</td>
        <td class="listcss">证件号码</td>
        <td colspan="2">{{resetForm.sfzh}}</td>
      </tr>
      <tr>
        <td class="listcss">籍贯</td>
        <td>{{resetForm.jgmc}}</td>
        <td class="listcss">出生地</td>
        <td>{{resetForm.csdmc}}</td>
        <td class="listcss">户口所在地</td>
        <td colspan="2">
          {{resetForm.hkszdmc}}
        </td>
      </tr>
      <tr>
        <td class="listcss">户口详细地址</td>
        <td colspan="6">{{resetForm.hkxxdz}}</td>
      </tr>
      <tr>
        <td class="listcss">移动电话</td>
        <td>{{resetForm.yddh}}</td>
        <td class="listcss">固定电话</td>
        <td>{{resetForm.dh}}</td>
        <td class="listcss">电子邮箱</td>
        <td colspan="2">{{resetForm.dzxx}}</td>
      </tr>
      <tr>
        <td class="listcss">邮政编码</td>
        <td>{{resetForm.yzbm}}</td>
        <td class="listcss">通讯地址</td>
        <td colspan="4">{{resetForm.txdz}}</td>
      </tr>
    </table>
    <table>
      <tr>
        <td class="listcss" colspan="8" style="text-align:left;font-weight:bold">| 学籍信息</td>
      </tr>
      <tr>
        <td class="listcss">学生类别</td>
        <td>{{form.xslbmc}}</td>
        <td class="listcss">学习方式</td>
        <td>{{form.xxfsmc}}</td>
        <td class="listcss">培养层次</td>
        <td colspan="4">{{form.pyccmc}}</td>
      </tr>
      <tr>
        <td class="listcss">入学年月</td>
        <td>{{form.rxny}}</td>
        <td class="listcss">年级</td>
        <td>{{form.sznj}}</td>
        <td class="listcss">学制</td>
        <td colspan="4">{{form.xz}}</td>
      </tr>
      <tr>
        <td class="listcss">所属学院</td>
        <td>{{form.ssyxmc}}</td>
        <td class="listcss">所属专业</td>
        <td>{{form.zy}}</td>
        <td class="listcss">研究方向</td>
        <td colspan="4">{{form.yjfx}}</td>
      </tr>
      <tr>
        <td class="listcss">班级</td>
        <td>{{form.bjmc}}</td>
        <td class="listcss">导师</td>
        <td>{{form.dsxm}}</td>
        <td class="listcss">当前状态</td>
        <td style="border:none">{{form.xsdqztmc}}</td>
        <td style="border:none;border-right:1px solid #e0e0e0"></td>
      </tr>
      <tr>
        <td class="listcss">是否跨学科</td>
        <td colspan="6" style="text-align:left;padding-left:150px">{{form.sfkkmc}}</td>
      </tr>
    </table>
    <table>
      <tr>
        <td class="listcss" colspan="8" style="text-align:left;font-weight:bold">| 其他信息</td>
      </tr>
      <tr>
        <td class="listcss">
          <p>何时何地何原因受</p>
          <p>过何种奖励或处分</p>
        </td>
        <td colspan="7">{{resetForm.jcnr}}</td>
      </tr>
      <tr>
        <td class="listcss" :rowspan="resetForm.qtList.length+1">学习和工作经历</td>
        <td class="listcss" colspan="2">起止时间</td>
        <td class="listcss" colspan="2">学习或工作单位</td>
        <td class="listcss" colspan="2">职务</td>
      </tr>
      <template v-for="(item,index) in resetForm.qtList">
        <tr>
          <td colspan="2">{{item.kssj | kssj}}至{{item.jssj | jssj}}</td>
          <td colspan="2">{{item.gzdw}}</td>
          <td colspan="2">{{item.zw}}</td>
        </tr>
      </template>
      <tr>
        <td class="listcss" :rowspan="resetForm.jtcy.length+1">家庭主要成员</td>
        <td class="listcss">姓名</td>
        <td class="listcss">关系</td>
        <td class="listcss">工作单位</td>
        <td class="listcss">职务</td>
        <td class="listcss">联系方式</td>
      </tr>
      <template v-for="(item,index) in resetForm.jtcy">
        <tr>
          <td>{{item.cyxm}}</td>
          <td><span v-if="resetForm.jtcy.length">{{item.gxm | jtgxlist(jtgxlist)}}</span><span v-else>未知</span></td>
          <td>{{item.gzdw}}</td>
          <td><span v-if="resetForm.jtcy.length">{{item.zy | zygxlist(zwlist)}}</span><span v-else>未知</span></td>
          <td colspan="2">{{item.lxfs}}</td>
        </tr>
      </template>
    </table>
  </div>
</template>
<script>
export default {
  filters: {
    xbm(val) {
      switch (parseInt(val)) {
        case "1":
          return "男";
        case "2":
          return "女";
        case "0":
          return "未知性别";
        case "9":
          return "未说明性别";
        default:
          break;
      }
    },
    kssj(val) {
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jssj(val) {
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jtgxlist(val, index) {
      if (val && index) {
        const valindex = index.find((el, index) => el.value === val);
        if (valindex) {
          return valindex.label;
        } else {
          return "";
        }
      }
    },
    zygxlist(val, index) {
      if (val && index) {
        const valindex = index.find((el, index) => el.value === val);
        if (valindex) {
          return valindex.label;
        } else {
          return "";
        }
      }
    }
  },
  name: "basicDetails",
  props: ["xh2"],
  data() {
    return {
      form: {},
      resetForm: {
        qtList: [],
        jtcy: []
      },
      jtgxlist: [],
      nativeList: [],
      hkszd: "",
      zwlist: []
    };
  },
  methods: {
    takeList() {
      this.$http.get("api/cultivate/stu/xjsj/" + this.xh2).then(res => {
        if (!res.data.data) {
          this.$message.error({
            message: "数据为空"
          });
          this.$store.state.schoolRoll = false;
        } else {
          this.form = res.data.data;
          this.$storage.addObjectKey(res.data.data, this.form);
        }
      });
      this.$http.get("api/cultivate/stu/jbxx/" + this.xh2).then(res => {
        if (!res.data.data) {
          this.$message.error({
            message: "数据为空"
          });
          this.$store.state.schoolRoll = false;
        } else {
          this.resetForm = res.data.data;
          this.$storage.addObjectKey(res.data.data, this.resetForm);
          this.$http.get("api/system/dict/select/origoLevelThree").then(res => {
            this.nativeList = res.data.data;
          });
          this.$http.get("api/system/dict/select/all").then(res => {
            // 关系
            this.jtgxlist = res.data.data.jtgx;
            // 关系
            this.zwlist = res.data.data.zw;
            // 婚姻状况
            if (this.resetForm.hyzkm) {
              this.resetForm.hyzkm = res.data.data.hyzk.find(
                (el, index) => el.value == this.resetForm.hyzkm
              ).label;
            }
            // 政治面貌
            if (this.resetForm.zzmmm) {
              this.resetForm.zzmmm = res.data.data.zzmm.find(
                (el, index) => el.value == this.resetForm.zzmmm
              ).label;
            }
            // 民族
            if (this.resetForm.mzm) {
              this.resetForm.mzm = res.data.data.mz.find(
                (el, index) => el.value == this.resetForm.mzm
              ).label;
            }
            // 健康状况
            if (this.resetForm.jkzkm) {
              this.resetForm.jkzkm = res.data.data.jkzk.find(
                (el, index) => el.value == this.resetForm.jkzkm
              ).label;
            }
            // 证件类型
            if (this.resetForm.sfzjlxm) {
              this.resetForm.sfzjlxm = res.data.data.zjlx.find(
                (el, index) => el.value == this.resetForm.sfzjlxm
              ).label;
            }
          });
        }
      });
    },
    exitList() {
      this.$store.state.schoolRoll = false;
    }
  },
  created() {},
  mounted() {
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.basicDetails {
  table {
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 150px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 150px;
    }
  }
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
}

.basicDetails /deep/ .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.basicDetails /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.basicDetails /deep/ .el-form-item__label {
  text-align: center;
}
</style>
