// 结业
<template>
  <div class="audit6">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="personal-details">
      <el-form :model="form" label-width="200px" ref="form" class="myform">
        <el-row>
          <el-col :span="24">
            <p class="title">
              <span :class="{yes1: auditStatus == '成功',back1: auditStatus == '退回' || auditStatus == '失败',audit1: auditStatus == '审核中'}" style="display: inline-block; position: absolute; height: 100%; width: 120px; transform: skew(-30deg); left: 12px;">
                <span class="on-mystatus">{{auditStatus}}</span>
              </span>
              浙江财经大学研究生结业申请表
            </p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="姓名">
              <el-input v-model="form.xm" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学号">
              <el-input v-model="form.xh" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="性别">
              <el-input v-model="form.xbm" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="学院">
              <el-input v-model="form.yxsh" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="专业">
              <el-input v-model="form.zy" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="年级">
              <el-input v-model="form.sznj" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="班级">
              <el-input v-model="form.szbh" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="出生日期">
              <el-input v-model="form.csrq" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="籍贯">
              <el-input v-model="form.jgmc" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="height: 200px;" class="myrow">
          <el-col :span="24" style="height: 100%;">
            <el-form-item label="申请理由" style="height: 100%; line-height: 200px; padding-right: 20px;" :required="true">
              <el-input v-model="form.reason" type="textarea" :rows="8" style="margin-top: 10px; margin-left: 10px;" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="border-bottom: 1px solid #eee;">
          <el-col :span="24">
            <el-form-item label="家长意见" :required="true">

              <el-button type="text" v-for="(item, index) in fileList" :key="index" @click="open(item.url)">{{item.fileName}}</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="step">
      <el-steps :active="list.length" :space="200">
        <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
          <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
          <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
          <span slot="description" class="comment">{{item.endTime}}</span>
          <div slot="description" class="comment">{{item.comment}}</div>
        </el-step>
      </el-steps>
    </div>
  </div>
</template>

<script>
export default {
  props: ['rowid6'],
  name: 'audit6',
  data() {
    return {
      form: {},
      bottomform: {
        audit: '通过'
      },
      fileList: [],
      list: [],
      auditStatus: ''
    }
  },
  methods: {
    open(val) {
      window.location.href = val
    },
    exitList() {
      this.$store.state.audit06 = false
      this.$parent.freshform()
    },
    handleSuccess(response, file, fileList) {
      console.log(file.response.url)
      this.fileName = file.response.url
    },
    handleSuccess2(response, file, fileList) {
      console.log(file.response.url)
      this.fileName = file.response.url
    },
    open(val) {
      window.open(val)
    },
    takeList() {
      this.$http
        .get(
          'api/backgroudpage/xjydsq/jysqInfoByLcid?lcid=' +
            this.rowid6.processInstanceId
        )
        .then(res => {
          console.log(res.data.xsXjydsqJysqVo)
          this.form = res.data.data.xsXjydsqJysqVo
          this.form.reason = res.data.data.pyXjydb.ydsm
          this.fileList = res.data.data.pyXjydb.firstfj
          this.list = res.data.data.list
          this.auditStatus =
            res.data.data.pyXjydb.zt == '0'
              ? '失败'
              : res.data.data.pyXjydb.zt == '1'
              ? '成功'
              : res.data.data.pyXjydb.zt == '2'
              ? '审核中'
              : res.data.data.pyXjydb.zt == '4'
              ? '退回'
              : '';
        })
        .catch(function(err) {
          console.log(err)
        })
    }
  },
  mounted() {
    this.takeList()
  }
}
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
.on-mystatus {
  display: inline-block;
  transform: skew(30deg);
  color: #fff;
}
.audit6 {
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .personal-details,
  .family-information {
    width: 100%;
    margin-top: 15px;
    .el-row {
      // height: 50px;
      width: 100%;
      .el-col {
        // height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
    .title {
      font-size: 20px;
      font-weight: bold;
      text-align: center;
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
  .step {
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .submitButton {
    margin-top: 15px;
    position: absolute;
    left: 50%;
    margin-left: -20px;
  }
}

.audit6 /deep/ .myform .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.audit6 /deep/ .myrow .el-form-item__label {
  line-height: 200px;
}
.audit6 /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.audit6 /deep/ .el-form-item__label {
  text-align: center;
}
</style>
