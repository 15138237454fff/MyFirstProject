<template>
  <div class="basicDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList"
        >返回列表</el-button
      >
    </div>
    <table>
      <tr>
        <td
          class="listcss"
          colspan="6"
          style="text-align:left;font-weight:bold"
        >
          | 基本信息
        </td>
        <td rowspan="4">
          <img
            :src="form.zp"
            alt=""
            style="width:100px;height:100px;display: inline;"
          />
        </td>
      </tr>
      <tr>
        <td class="listcss">考生编号</td>
        <td>{{ form.ksbh }}</td>
        <td class="listcss">姓名</td>
        <td>{{ form.xm }}</td>
        <td class="listcss">姓名拼音</td>
        <td>{{ form.xmpy }}</td>
      </tr>
      <tr>
        <td class="listcss">性别</td>
        <td>{{ form.xbm }}</td>
        <td class="listcss">民族</td>
        <td>{{ form.mzm }}</td>
        <td class="listcss">出生日期</td>
        <td>{{ form.csrq }}</td>
      </tr>
      <tr>
        <td class="listcss">婚姻状况</td>
        <td>{{ form.hyzkm }}</td>
        <td class="listcss">政治面貌</td>
        <td>{{ form.zzmmm }}</td>
        <td class="listcss">健康状况</td>
        <td>{{ form.jkzkm }}</td>
      </tr>
      <tr>
        <td class="listcss">国籍</td>
        <td>{{ form.gjm }}</td>
        <td class="listcss">证件类型</td>
        <td>{{ form.zjlx }}</td>
        <td class="listcss">证件号码</td>
        <td colspan="2">{{ form.zjhm }}</td>
      </tr>
      <tr>
        <td class="listcss">籍贯</td>
        <td>{{ form.jgszdm }}</td>
        <td class="listcss">出生地</td>
        <td>{{ form.csdm }}</td>
        <td class="listcss">户口所在地</td>
        <td colspan="2">{{ form.hkszdm }}</td>
      </tr>
      <tr>
        <td class="listcss">户口详细地址</td>
        <td colspan="6">{{ form.hkszdxxdz }}</td>
      </tr>
      <tr>
        <td class="listcss">移动电话</td>
        <td>{{ form.yddh }}</td>
        <td class="listcss">固定电话</td>
        <td>{{ form.lxdh }}</td>
        <td class="listcss">电子邮箱</td>
        <td colspan="2">{{ form.dzxx }}</td>
      </tr>
      <tr>
        <td class="listcss">邮政编码</td>
        <td>{{ form.yzbm }}</td>
        <td class="listcss">通讯地址</td>
        <td colspan="4">{{ form.txdz }}</td>
      </tr>
    </table>

    <table>
      <tr>
        <td
          class="listcss"
          colspan="8"
          style="text-align:left;font-weight:bold"
        >
          | 学籍信息
        </td>
      </tr>
      <tr>
        <td class="listcss">学号</td>
        <td>{{ form.xh }}</td>
        <td class="listcss">录取类别</td>
        <td>{{ form.lqlbm }}</td>
        <td class="listcss">学习方式</td>
        <td colspan="4">{{ form.bkxxfs }}</td>
      </tr>
      <tr>
        <td class="listcss">学生类别</td>
        <td>{{ form.xslbm }}</td>
        <td class="listcss">培养层次</td>
        <td>{{ form.pyccm }}</td>
        <td class="listcss">学制</td>
        <td colspan="4">{{ form.xz }}</td>
      </tr>
      <tr>
        <td class="listcss">所属学院</td>
        <td>{{ form.bkyxsm }}</td>
        <td class="listcss">所属专业</td>
        <td>{{ form.bkzydm }}</td>
        <td class="listcss">研究方向</td>
        <td colspan="4">{{ form.yjfxm }}</td>
      </tr>
      <tr>
        <td class="listcss">班级</td>
        <td>{{ form.bj }}</td>
        <td class="listcss">导师</td>
        <td>{{ form.ds }}</td>
        <td></td>
        <td class="" colspan="3"></td>
      </tr>
    </table>

    <table>
      <tr>
        <td
          class="listcss"
          colspan="8"
          style="text-align:left;font-weight:bold"
        >
          | 其他信息
        </td>
      </tr>
      <tr>
        <td class="listcss">
          <p>何时何地何原因受</p>
          <p>过何种奖励或处分</p>
        </td>
        <td colspan="7">{{ form.jlcf }}</td>
      </tr>
      <tr>
        <td
          class="listcss"
          :rowspan="form.xxgzjlList && form.xxgzjlList.length + 1"
        >
          学习和工作经历
        </td>
        <td class="listcss" colspan="2">起止时间</td>
        <td class="listcss" colspan="2">学习或工作单位</td>
        <td class="listcss" colspan="2">职务</td>
      </tr>
      <template v-for="(item, index) in form.xxgzjlList">
        <tr>
          <td colspan="2">{{ item.qzsj }}</td>
          <td colspan="2">{{ item.gzdw }}</td>
          <td colspan="2">{{ item.zw }}</td>
        </tr>
      </template>
      <tr>
        <td
          class="listcss"
          :rowspan="form.jtcyList && form.jtcyList.length + 1"
        >
          家庭主要成员
        </td>
        <td class="listcss">姓名</td>
        <td class="listcss">关系</td>
        <td class="listcss">工作单位及职务</td>
        <td class="listcss" colspan="2">联系方式</td>
      </tr>
      <template v-for="(item, index) in form.jtcyList">
        <tr :key="index">
          <td>{{ item.cyxm }}</td>
          <td>
            <span v-if="form.jtcyList.length">{{
              item.gxm | jtgxlist(jtgxlist)
            }}</span
            ><span v-else>未知</span>
          </td>
          <td>{{ item.gzdw }}</td>
          <td colspan="2">{{ item.lxfs }}</td>
        </tr>
      </template>
    </table>
  </div>
</template>

<script>
export default {
  name: "basicDetails",
  props: ["zkzh"],
  data() {
    return {
      form: {}
    };
  },
  methods: {
    exitList() {
      this.$store.state.rebirthInfor = false;
    },
    takeList() {
      this.$http
        .get("api/cultivate/newStudent/selectXsxx/" + this.zkzh)
        .then(res => {
          if (!res.data.data) {
            this.$message.error({
              message: "数据异常"
            });
            this.$store.state.rebirthInfor = false;
          } else {
            this.form = res.data.data;
          }
        });
    }
  },
  mounted() {
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
.basicDetails {
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid#f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .personal-details,
  .family-information {
    width: 100%;
    .el-row {
      height: 50px;
      width: 100%;
      .el-col {
        height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
  table {
    // border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    // text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    // line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 150px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 150px;
    }
  }
}

.basicDetails /deep/ .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.basicDetails /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.basicDetails /deep/ .el-form-item__label {
  text-align: center;
}
</style>
