<!--分导师-->
<template>
  <div class="teachDistribution">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="header-left">
      <el-form :model="form" label-width="90px" ref="form">
        <el-row>
          <el-form-item label="选择学院：" class="fl">
            <el-select v-model="form.college" filterable placeholder="请选择" style="margin-left: 10px;" class="top-input" @change="collegeChange">
              <el-option v-for="item in this.collegeList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择专业：" class="fl">
            <el-select v-model="form.major" filterable placeholder="请选择" style="margin-left: 10px;" class="top-input">
              <el-option v-for="item in this.majorList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="学生类别：" class="fl">
            <el-select v-model="form.studentType" filterable placeholder="请选择" style="margin-left: 10px;" class="top-input">
              <el-option v-for="item in this.studentTypeList" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-button type="primary" @click="teachSearch">确定</el-button>
        </el-row>
      </el-form>
    </div>

    <div class="main-container">
      <el-button style="float: right" type="primary" @click="addTutor">分配学生名单</el-button>
      <div class="table-container">
        <div class="myTable">
          <el-col :span="24">
            <el-tabs style="margin-bottom: -16px;" v-model="activeTab" type="card" @tab-click="handleClick">
              <!-- <el-tab-pane label="班级一" name="first"></el-tab-pane>
                      <el-tab-pane label="班级二" name="second"></el-tab-pane>
                      <el-tab-pane label="班级三" name="third"></el-tab-pane> -->
              <el-tab-pane v-for="(item,index) in tutorList" :key="item.jobId" :label="item.dsmczh" :name="item.jobId"></el-tab-pane>
            </el-tabs>
          </el-col>

          <el-table :data="tableData" border ref="multipleTable" :header-cell-style="tableHeaderColor" :height="tableHeight">
            <el-table-column prop="zkzh" label="考生编号">
            </el-table-column>
            <el-table-column prop="xm" label="姓名">
            </el-table-column>
            <el-table-column prop="sex" label="性别">
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-popover placement="right" width="60" trigger="click" ref="popover2" v-model="scope.row.visible2">
                  <div>
                    <el-button type="text" v-for="(item,index) in tutorList" :key="index" @click="adjustTutor(scope.row, item)">{{item.name}}
                    </el-button>
                    <el-button style="color: #ff2000" type="text" @click="deleteStudent(scope.row,scope.row.visible2)">
                      删除学生 <i class="el-icon-delete"></i></el-button>
                  </div>
                  <el-button type="text" slot="reference">调整</el-button>
                </el-popover>
              </template>
            </el-table-column>
          </el-table>
          <div class="block" style="margin-bottom: 35px;">
            <el-pagination :current-page.sync="currentPage" :page-sizes="[15, 25, 50, 100]" :page-size="pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange" style="top: 15px;">
            </el-pagination>
          </div>
        </div>
      </div>
    </div>

    <!-- 分学生 -->
    <el-dialog title="添加学生名单" :visible.sync="addDialog" :before-close="handleClose" width="690px">
      <p class="hr"></p>
      <div class="table" style="margin-top: -20px;" v-loading="dialogLoading" element-loading-text="导师分配中">
        <div class="dialog-left" style="float: left;">
          <span>{{row.gh}}</span>&nbsp;&nbsp;
          导师姓名：<span>{{currentTutor.name}}</span>
        </div>
        <div class="dialog-right" style="float: right;">
          已选学生：<span>{{boyCount+girlCount+otherCount}}</span>&nbsp;&nbsp;
          <!--男生：<span>{{boyCount}}</span>&nbsp;&nbsp;-->
          <!--女生：<span>{{girlCount}}</span>&nbsp;&nbsp;-->
          <!--未知性别：<span>{{otherCount}}</span>-->
        </div>

        <!--@selection-change="mySelect"-->
        <el-table v-loading="loading" element-loading-text="加载中" :data="addData" border ref="stuMultipleTable" style="width: 100%; position: relative; top: 15px;" @select-all="handleCheckBox" @select="handleCheckBox" :header-cell-style="tableHeaderColor" height="241">
          <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
          </el-table-column>
          <el-table-column prop="zkzh" label="考生编号">
          </el-table-column>
          <el-table-column prop="xm" label="姓名">
          </el-table-column>
          <el-table-column prop="sex" label="性别">
          </el-table-column>
        </el-table>
      </div>
      <div class="block" style="margin-bottom: 35px;">
        <el-pagination :current-page.sync="findStuCurrentPage" :page-sizes="[15, 25, 50, 100]" :page-size="myPageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="mychangePage" :total="myTotal" @size-change="mysizeChange" style="top: 45px;">
        </el-pagination>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addDialog = false">取 消</el-button>
        <el-button type="primary" @click="addHandle" :disabled="this.numberList.length== 0 ? true : false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "teachDistribution",
  data() {
    return {
      addData: [],
      addDialog: false,
      loading: false,
      dialogLoading: false,
      tableData: [],
      form: {
        college: "",
        major: "",
        time: ""
      },
      collegeList: [
        {
          value: "01",
          label: "化学工程学院"
        }
      ], // 学院列表
      majorList: [], // 专业列表
      studentTypeList: [],
      timeList: [
        {
          value: "2019",
          label: "2019"
        }
      ], // 入学年份列表
      activeTab: "",
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      currentPage: 1,
      findStuCurrentPage: 1, // 当前页
      total: 1, // 总数据条数
      pageSize: 1,
      myTotal: 1,
      myPageSize: 5,
      majorNum: "", // 专业号
      row: "",
      selectDataLength: 0, // 选中数据长度
      deleteList: [],
      selectData: [], // 选中列表
      currentPageSelectList: [], // 当前页选择列表
      allSelectList: [], // 全部选中列表
      boyCount: 0,
      girlCount: 0,
      otherCount: 0,
      currentTutor: [],
      tutorList: [],
      numberList: []
    };
  },
  methods: {
    deleteStudent(row, visible2) {
      console.log("准考证号=" + row.zkzh);
      // row.visible2 = false;
      this.$set(row, "visible2", false);
      this.$http
        .put("api/cultivate/newStudent/deleteXsByDs/" + row.zkzh)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "删除成功",
              type: "success"
            });
            this.takeTutorStudent();
          } else {
            this.$message.error({ message: "删除失败" });
          }
        })
        .catch(function(err) {
          console.log(err);
        });
    }, // 导师删除学生
    adjustTutor(row, item) {
      console.log(row.zkzh, item.jobId);
      // console.log(item.slice(-5, -1))
      this.$http
        .put("api/cultivate/newStudent/tzDs/" + row.zkzh + "/" + item.jobId)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "修改导师成功",
              type: "success"
            });
            this.takeTutorStudent();
          } else {
            this.$message.error({ message: "修改导师失败" });
          }
        })
        .catch(function(err) {
          console.log(err);
        });
    }, // 调整导师

    addHandle() {
      console.log(
        "currentTutor=" + this.currentTutor + " id=" + this.currentTutor.jobId
      );
      this.dialogLoading = true;
      this.$http
        .put("api/cultivate/newStudent/updateXsByDs", {
          tutorId: this.currentTutor.jobId,
          stuExamId: this.numberList
        })
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "分导师成功",
              type: "success"
            });
            this.addDialog = false;
            this.dialogLoading = false;
            this.teachSearch();
          } else {
            this.$message.error({
              message: "分导师失败"
            });
            this.dialogLoading = false;
          }
        })
        .catch(function(err) {
          console.log(err);
        });
    }, // 确认添加学生
    teachSearch() {
      console.log(
        "this.form.major=" +
          this.form.major +
          " this.form.time=" +
          this.form.time
      );
      if (this.form.major == "") {
        this.$message.warning("请选择专业");
      } else {
        this.$http
          .get("api/cultivate/newStudent/selectDsByZy/" + this.form.major)
          .then(res => {
            this.tutorList = [];
            console.log("data=" + res.data.data);
            if (res.data.data == "") {
              this.currentTutor = [];
              this.$message.info("没有找到相关的导师");
            }
            res.data.data.map((item, index) => {
              let obj = {
                jobId: item.jobId,
                name: item.name,
                zyh: item.zyh,
                dsmczh: item.name + "(" + item.jobId + ")"
              };
              console.log(
                "导师ID=" +
                  obj.jobId +
                  " 导师名=" +
                  obj.name +
                  " this.currentTutor=" +
                  this.currentTutor
              );
              if (index == 0) {
                if (this.currentTutor == null || this.currentTutor == "") {
                  this.currentTutor = obj;
                }
                this.takeTutorStudent();
              }
              this.tutorList.push(obj);
            });
            console.log(this.tutorList);
          })
          .catch(function(err) {
            console.log(err);
          });
      }
    }, // 根据专业号查找导师
    // +this.currentPage+"/"+this.pageSize+"?"+this.form.major+"/")
    takeTeachList() {
      if (this.form.major == "") {
        this.$message.warning("请选择专业");
      } else {
        this.$http
          .get("api/cultivate/newStudent/selectDsByZy/" + this.form.major)
          .then(res => {
            this.tutorList = [];
            console.log("data=" + res.data.data);
            if (res.data.data == "") {
              this.currentTutor = [];
              this.$message.info("没有找到相关专业的导师");
            }
            res.data.data.map((item, index) => {
              let obj = {
                jobId: item.jobId,
                name: item.name,
                zyh: item.zyh,
                dsmczh: item.name + "(" + item.jobId + ")"
              };
              console.log("导师ID=" + obj.jobId + " 导师名=" + obj.name);
              if (index == 0) {
                if (this.currentTutor == null || this.currentTutor == "") {
                  this.currentTutor = obj;
                }
                this.takeTutorStudent();
              }
              this.tutorList.push(obj);
            });
            console.log(
              this.tutorList + " this.tutorList.length=" + this.tutorList.length
            );
          })
          .catch(function(err) {
            console.log(err);
          });
      }
      // this.$http
      //   .post("api/cultivate/newStudent/selectDsByZy", {
      //     pageNum: this.currentPage,
      //     pageSize: this.pageSize,
      //     zyh: this.form.major
      //   })
      //   .then(res => {
      //     console.log(res.data.data.list);
      //     this.tableData = res.data.data.list;
      //     this.total = res.data.data.total;
      //   })
      //   .catch(function (err) {
      //     console.log(err)
      //   })
    },
    // +this.form.time+"/"+this.form.major+"/"+index+"/"+5)
    takeStudList(index) {
      console.log(
        "获取学生列表页码=" +
          index +
          " pageSize=" +
          this.myPageSize +
          " 专业号=" +
          this.form.major
      );
      this.loading = true;
      this.findStuCurrentPage = index;
      this.$http
        .post("api/cultivate/newStudent/selectFdsXs", {
          pageNum: index,
          pageSize: this.myPageSize,
          xslb: this.form.studentType,
          zyh: this.form.major
        })
        .then(res => {
          this.addData = res.data.data.list;
          this.myTotal = res.data.data.total;
          res.data.data.list.map((item, _index) => {
            // console.log("item.xbm=" + item.xbm);
            let sex = "";
            switch (item.xbm) {
              case "1":
                sex = "男";
                break;
              case "2":
                sex = "女";
                break;
              case "9":
                sex = "未说明的性别";
                break;
              default:
                sex = "未知性别";
                break;
            }
            this.addData[_index].sex = sex;
          });
          /*
           * 当前页码，具体由自己写的组件取值
           */
          let curpage = this.findStuCurrentPage;
          console.log("curpage=" + curpage);
          /*
           * 每页数变化/页面变化，调整selectData的每个页码下的已选行数据
           */
          this.addData.forEach((item, index) => {
            for (let key in this.selectData) {
              this.selectData[key].forEach((value, ind, arr) => {
                /*
                 * key/1,curpage/1转为数值，避免是字符串的影响
                 * 当单前页的表格数据有已选数据，且该已选数据所在的对象的key不是当前页码，
                 * 就调到当前页码的key的数组值中存储
                 */
                if (value.zkzh === item.zkzh && key / 1 !== curpage / 1) {
                  // console.log("value.zkzh="+value.zkzh+" item.zkzh"+item.zkzh);
                  // 当前页码对象不存在时，创建空数组
                  this.selectData[curpage]
                    ? this.selectData[curpage]
                    : (this.selectData[curpage] = []);
                  this.selectData[curpage].push(value);
                  console.log("curpage=" + curpage + "  value=" + value);
                  arr.splice(ind, 1); // 删除数组中该项
                }
              });
            }
          });
          // 已选行数据和表格数据对比，相同则显示勾选，否则清除勾选
          let curSelectData = this.selectData[curpage];
          this.addData.forEach(item => {
            if (curSelectData && curSelectData.length > 0) {
              this.selectData[curpage].forEach(row => {
                if (row.zkzh === item.zkzh) {
                  // console.log("value.zkzh=" + row.zkzh + " item.zkzh" + item.zkzh);
                  this.$nextTick(function() {
                    this.$refs.stuMultipleTable.toggleRowSelection(item);
                  });
                }
              });
            } else {
              // console.log("clearSelection");
              this.$nextTick(function() {
                this.$refs.stuMultipleTable.clearSelection();
              });
            }
          });
          this.loading = false;
        })
        .catch(function(err) {
          console.log(err);
        });
    }, // 查询学生列表
    collegeChange(val) {
      let temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.majorList = temp.children;
    }, // 学院修改事件
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    changePage() {
      this.takeTeachList();
    }, // 切换页码
    sizeChange(value) {
      this.pageSize = value;
      this.takeTeachList();
    }, // 改变一页的条数
    mychangePage(index) {
      this.currentPageSelectList = [];
      this.takeStudList(index);
    }, // 切换页码
    mysizeChange(value) {
      this.myPageSize = value;
      this.takeStudList(this.findStuCurrentPage);
    }, // 改变一页的条数
    handleClose(done) {
      done();
    },
    exitList() {
      this.$store.state.teachDistribution = false;
    }, // 退回列表
    addTutor() {
      if (this.form.major == "") {
        this.$message.warning("请选择专业");
      } else if (this.currentTutor == null || this.currentTutor == "") {
        this.$message.warning("请先搜索导师");
      } else {
        this.addDialog = true;
        this.takeStudList(1);
        this.boyCount = 0;
        this.girlCount = 0;
        this.otherCount = 0;
        this.selectData = [];
        this.numberList = [];
      }
      // this.addDialog = true
      // this.takeStudList(1)
      // this.currentTutor = row
      // console.log("currentTutor=" + this.currentTutor + " id=" + this.currentTutor.jobId + " name=" + this.currentTutor.name)
      // this.boyCount = 0
      // this.girlCount = 0
      // this.otherCount = 0
      // this.selectData = []
      // this.numberList = []
    }, // 分学生
    handleClick(tab, event) {
      this.tutorList.forEach(item => {
        if (item.jobId == this.activeTab) {
          this.currentTutor = item;
        }
      });
      this.takeTutorStudent();
      // this.
      // this.currentClass = this.activeTab
      // this.takeClass()
    }, // 切换tab方法
    takeTutorStudent() {
      if (this.currentTutor != null) {
        if (this.currentTutor.jobId != "" && this.currentTutor.jobId != null) {
          console.log("查询当前导师号=" + this.currentTutor.jobId);
          this.$http
            .post("api/cultivate/newStudent/selectFdsXs", {
              pageNum: this.currentPage,
              pageSize: this.pageSize,
              zyh: this.currentTutor.zyh,
              tutorId: this.currentTutor.jobId
            })
            .then(res => {
              this.tableData = res.data.data.list;
              this.total = res.data.data.total;
              res.data.data.list.map((item, _index) => {
                console.log("item.xbm=" + item.xbm + " item.name=" + item.name);
                let sex = "";
                switch (item.xbm) {
                  case "1":
                    sex = "男";
                    break;
                  case "2":
                    sex = "女";
                    break;
                  case "9":
                    sex = "未说明的性别";
                    break;
                  default:
                    sex = "未知性别";
                    break;
                }
                this.tableData[_index].sex = sex;
              });
              this.tableData.map(v => {
                this.$set(v, "visible2", false);
              });
            })
            .catch(function(err) {
              console.log(err);
            });
        }
      }
    }, // 查找班级
    clickRow(row, column, event) {
      console.log("选择row=" + row.zkzh);
      this.$refs.stuMultipleTable.toggleRowSelection(row);
    }, // 列表选择

    handleCheckBox(rows) {
      // rows是数组，返回是当前页已选是数据 [ { .. } , { ... }, .. ]
      this.loading = true;
      let curpage = this.findStuCurrentPage; // 当前页码，具体由自己写的组件取值
      console.log("handleCheckBox curpage=" + curpage);
      this.selectData[curpage] = [];
      if (rows.length > 0) {
        rows.forEach(item => {
          if (item && item.zkzh !== undefined) {
            // 确保返回的已选数据有效，至于是否用id判断由具体的数据决定
            this.selectData[curpage].push(item);
          }
        });
      }
      this.handleSelectDataLength(); // 该方法是计算一共选择的数据条数
      this.loading = false;
    },

    handleSelectDataLength() {
      this.selectDataLength = 0;
      this.selectRows = [];
      this.boyCount = 0;
      this.girlCount = 0;
      this.otherCount = 0;
      for (let key in this.selectData) {
        if (this.selectData.hasOwnProperty(key)) {
          // 避免原型属性影响
          this.selectDataLength += this.selectData[key].length / 1;
          // “length/1” 除以1，转化为数值，避免字符串的影响
          console.log("this.selectDataLength=" + this.selectDataLength);
          this.selectData[key].forEach(item => {
            this.selectRows.push(item); // 将所有选择的行数据，存到selectRows数组中
          });
        }
      }
      this.selectRows.forEach(item => {
        this.numberList.push(item.zkzh);
        if (item.sex == "男") {
          this.boyCount++;
        } else if (item.sex == "女") {
          this.girlCount++;
        } else {
          this.otherCount++;
        }
      });
      console.log("数据长度=" + this.selectRows.length);
    },

    // 学院专业联调数据
    getCollegeMajorData() {
      console.log("获取学院专业数据");
      this.$http.get("api/system/dict/select/college").then(res => {
        this.collegeList = res.data.data;
        this.majorList = this.collegeList[0].children;
      });
    },
    getStudentTypeData() {
      this.$http.get("api/system/dict/studentType").then(res => {
        this.studentTypeList = res.data.data;
      });
    } // 学生类别数据
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 170);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 170);
      })();
    };
    this.getCollegeMajorData();
    this.getStudentTypeData();
    this.pageSize = Math.floor(this.tableHeight / 57);
  }
};
</script>

<style scoped lang="scss">
.fl {
  float: left;
  margin-right: 20px;
}

.teachDistribution {
  .top-title {
    width: 100%;
    height: 60px;
    background: #f2f2f2;
    line-height: 60px;

    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .header-left {
    /*width: 100%;*/
    /*margin-top: 15px;*/
    float: left;
    /*margin-bottom: 15px;*/
  }

  .table {
    width: 100%;
    margin-top: 15px;
  }

  .hr {
    width: 100%;
    border-bottom: 1px solid #f4f4f4;
    padding-bottom: 10px;
    margin: 0;
    position: relative;
    top: -30px;
  }

  .main-container {
    /*position: absolute;*/
    margin-top: 0px;
    left: 0;
    width: 100%;
    bottom: 0;
    border-top: none;

    .main-right {
      float: right;
      width: 126px;
      right: 0px;

      .table-container {
        width: 100%;
        left: 0px;
        /*height: calc(100% - 62px);*/
        border: 1px solid #ddd;
        position: relative;

        /*top: 162px;*/
        .myTable {
          position: absolute;
          top: 800px;
          left: 15px;
          right: 15px;
          bottom: 70px;
        }
      }
    }
  }
}

.classDistribution /deep/ .el-tabs__item {
  background: #f5f5f5;
  border: 1px solid #ddd;
  margin-right: 3px;
}

.classDistribution
  /deep/
  .el-tabs--card
  > .el-tabs__header
  .el-tabs__item.is-active {
  color: #e64545 !important;
}

.classDistribution /deep/ .el-tabs--card > .el-tabs__header .el-tabs__nav {
  border: none;
}

.teachDistribution /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
}

.teachDistribution /deep/ .dialog-footer button {
  margin: 0 20px;
}

.teachDistribution /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}

.teachDistribution /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
</style>
