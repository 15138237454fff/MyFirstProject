<!-- 老生批量注册 -->
<template>
  <div class="oldRegister">
    <componment>
      <div slot="left">
        <el-input v-model="searchField" placeholder="请输入学号/姓名" style="width: 200px" @keyup.enter.native="searchData"></el-input>
        <el-button @click="searchData">查询</el-button>
        <el-select v-model="college" filterable placeholder="全部学院" @change="collegeChange">
          <el-option v-for="(item, index) in collegeList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="major" filterable placeholder="全部专业" @change="zylsit">
          <el-option v-for="(item, index) in majorList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="status" filterable placeholder="全部状态">
          <el-option v-for="(item, index) in statusList" :key="index" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button type="primary" @click="registerInfor" v-if="$btnAuthorityTest('oldRegister:import')">批量注册</el-button>
      </div>
    </componment>
    <el-table :data="tableData" border ref="multipleTable" style="width: 100%" @row-click="clickRow" @selection-change="mySelect" @select-all="allClick" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
      <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
      </el-table-column>
      <el-table-column prop="xh" label="学号" width="150"> </el-table-column>
      <el-table-column prop="xm" label="姓名"> </el-table-column>
      <el-table-column prop="xslbmc" label="学生类别"> </el-table-column>
      <el-table-column prop="xy" label="学院"> </el-table-column>
      <el-table-column prop="zy" label="专业"> </el-table-column>
      <el-table-column prop="nj" label="年级"> </el-table-column>
      <el-table-column prop="status" label="注册状态">
        <template slot-scope="scope">
          <span>{{ scope.row.zczk | status }}</span>
        </template>
      </el-table-column>
    </el-table>
    <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "oldRegister",
  data() {
    return {
      searchField: "", // 搜索的数据
      tableData: [],
      collegeList: [], // 单位列表
      major: "",
      majorList: [],
      status: "",
      statusList: [
        {
          value: "选项1",
          label: "全部状态"
        }
      ],
      college: "", // 选中单位
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      deleteList: [],
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  components: {
    componment: componment,
    pagination: pagination
  },
  filters: {
    status(val) {
      switch (val) {
        case "0":
          return "未注册";
          break;
        case "1":
          return "已注册";
          break;
        default:
          break;
      }
    }
  },
  methods: {
    collegeChange(val) {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      const temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.majorList = temp.children;
    },
    zylsit() {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/cultivate/lszc/search", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          xy: this.college,
          zczk: this.status,
          zy: this.major
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 获取列表
    searchData() {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    }, // 搜索数据方法
    registerInfor() {
      this.$http
        .put("api/cultivate/Lszc/lsplzc/" + this.deleteList.join(","))
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "注册成功",
              type: "success"
            });
            this.takeList();
            this.listQuery.queryPage.pageNum = 1;
          } else {
            this.$message.error({
              message: "注册失败"
            });
          }
        });
    }, // 导出数据
    changePage() {}, // 切换页码
    sizeChange() {}, // 改变一页的条数
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.xy);
      });
    }, // 列表选择
    allClick(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.xy);
      });
    },
    getCollegeMajorData() {
      this.$http.get("api/system/dict/select/college").then(res => {
        this.collegeList = res.data.data;
        this.majorList = this.collegeList[0].children;
      });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.getCollegeMajorData();
  }
};
</script>

<style scoped lang="scss">
.oldRegister {
  width: 100%;
  padding-top: 7px;
}
</style>
