<!-- 学生信息审核管理 -->
<template>
  <div class="rollAudit">
    <div
      class="container"
      v-if="
        $store.state.audit1 == false &&
          $store.state.audit2 == false &&
          $store.state.audit3 == false &&
          $store.state.audit4 == false &&
          $store.state.audit5 == false &&
          $store.state.audit6 == false &&
          $store.state.audit7 == false &&
          $store.state.audit8 == false &&
          $store.state.audit9 == false &&
          $store.state.audit0 == false &&
          $store.state.audit01 == false &&
          $store.state.audit02 == false &&
          $store.state.audit03 == false &&
          $store.state.audit04 == false &&
          $store.state.audit05 == false &&
          $store.state.audit06 == false &&
          $store.state.audit07 == false &&
          $store.state.audit08 == false &&
          $store.state.audit09 == false &&
          $store.state.audit00 == false
      "
    >
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="tabChangeClick">
          <el-tab-pane label="待审核" name="first"></el-tab-pane>
          <el-tab-pane label="已审核" name="second"></el-tab-pane>
        </el-tabs>
      </div>
      <componment>
        <div slot="left">
          <el-input
            v-model="searchField"
            placeholder="请输入学号/姓名"
            @keyup.enter.native="searchData"
            style="width: 200px;"
            clearable
            @clear="clearinput"
          ></el-input>
          <el-button @click="searchData" style="margin-left:5px"
            >查询</el-button
          >
          <el-select
            v-model="type"
            filterable
            placeholder="全部申请类别"
            style="margin-left: 10px;"
            class="top-input"
            @change="mychange"
          >
            <el-option
              v-for="item in typeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
      </componment>
      <div class="table" v-if="activeName == 'first'">
        <el-table
          :data="tableData"
          border
          ref="multipleTable"
          style="width: 100%"
          :header-cell-style="$storage.tableHeaderColor"
          :height="tableHeight"
          v-loading="loading2"
          element-loading-text="加载中"
        >
          <el-table-column prop="processDefinitionName" label="申请类别">
          </el-table-column>
          <el-table-column prop="xh" label="学号" width="150">
          </el-table-column>
          <el-table-column prop="xm" label="姓名"> </el-table-column>
          <el-table-column prop="xslb" label="学生类别"> </el-table-column>
          <el-table-column prop="xy" label="学院"> </el-table-column>
          <el-table-column prop="zy" label="专业"> </el-table-column>
          <el-table-column prop="nj" label="年级"> </el-table-column>
          <el-table-column prop="createTime" label="申请时间">
          </el-table-column>
          <el-table-column label="当前审核环节">
            <template slot-scope="scope">
              <el-button
                type="text"
                @click="aduit(scope.row)"
                v-if="$btnAuthorityTest('rollAudit:audit')"
                >{{ scope.row.name }}</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <pagination
          :total="total"
          :page.sync="listQuery.queryPage.pageNum"
          :limit.sync="listQuery.queryPage.pageSize"
          class="pagination-content"
          @pagination="takeList"
        ></pagination>
      </div>
      <div class="table" v-if="activeName == 'second'">
        <el-table
          :data="tableData2"
          border
          ref="multipleTable"
          style="width: 100%"
          :header-cell-style="$storage.tableHeaderColor"
          :height="tableHeight"
          v-loading="loading3"
          element-loading-text="加载中"
        >
          <el-table-column prop="processDefinitionName" label="申请类别">
          </el-table-column>
          <el-table-column prop="xh" label="学号"> </el-table-column>
          <el-table-column prop="xm" label="姓名"> </el-table-column>
          <el-table-column prop="xslb" label="学生类别"> </el-table-column>
          <el-table-column prop="xy" label="学院"> </el-table-column>
          <el-table-column prop="zy" label="专业"> </el-table-column>
          <el-table-column prop="nj" label="年级"> </el-table-column>
          <el-table-column prop="endTime" label="申请时间"> </el-table-column>
          <el-table-column label="审核状态">
            <template slot-scope="scope">
              <el-button
                type="text"
                @click="checkDetails(scope.row)"
                v-if="$btnAuthorityTest('rollAudit:view')"
                >{{ scope.row.buttonType }}</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <pagination
          :total="total"
          :page.sync="listQuery.queryPage.pageNum"
          :limit.sync="listQuery.queryPage.pageSize"
          class="pagination-content"
          @pagination="takeList"
          v-if="showpage"
        ></pagination>
      </div>
    </div>
    <audit0 v-else-if="$store.state.audit0 == true" :rowid0="rowid0"></audit0>
    <audit1 v-else-if="$store.state.audit1 == true" :rowid1="rowid1"></audit1>
    <audit2 v-else-if="$store.state.audit2 == true" :rowid2="rowid2"></audit2>
    <audit3 v-else-if="$store.state.audit3 == true" :rowid3="rowid3"></audit3>
    <audit4 v-else-if="$store.state.audit4 == true" :rowid4="rowid4"></audit4>
    <audit5 v-else-if="$store.state.audit5 == true" :rowid5="rowid5"></audit5>
    <audit6 v-else-if="$store.state.audit6 == true" :rowid6="rowid6"></audit6>
    <audit7 v-else-if="$store.state.audit7 == true" :rowid7="rowid7"></audit7>
    <audit8 v-else-if="$store.state.audit8 == true" :rowid8="rowid8"></audit8>
    <audit9 v-else-if="$store.state.audit9 == true" :rowid9="rowid9"></audit9>
    <audit00
      v-else-if="$store.state.audit00 == true"
      :rowid0="rowid0"
    ></audit00>
    <audit01
      v-else-if="$store.state.audit01 == true"
      :rowid1="rowid1"
    ></audit01>
    <audit02
      v-else-if="$store.state.audit02 == true"
      :rowid2="rowid2"
    ></audit02>
    <audit03
      v-else-if="$store.state.audit03 == true"
      :rowid3="rowid3"
    ></audit03>
    <audit04
      v-else-if="$store.state.audit04 == true"
      :rowid4="rowid4"
    ></audit04>
    <audit05
      v-else-if="$store.state.audit05 == true"
      :rowid5="rowid5"
    ></audit05>
    <audit06
      v-else-if="$store.state.audit06 == true"
      :rowid6="rowid6"
    ></audit06>
    <audit07
      v-else-if="$store.state.audit07 == true"
      :rowid7="rowid7"
    ></audit07>
    <audit08
      v-else-if="$store.state.audit08 == true"
      :rowid8="rowid8"
    ></audit08>
    <audit09
      v-else-if="$store.state.audit09 == true"
      :rowid9="rowid9"
    ></audit09>
  </div>
</template>

<script>
import audit0 from "./rollAudit/audit0";
import audit1 from "./rollAudit/audit1";
import audit2 from "./rollAudit/audit2";
import audit3 from "./rollAudit/audit3";
import audit4 from "./rollAudit/audit4";
import audit5 from "./rollAudit/audit5";
import audit6 from "./rollAudit/audit6";
import audit7 from "./rollAudit/audit7";
import audit8 from "./rollAudit/audit8";
import audit9 from "./rollAudit/audit9";
import audit00 from "./alreadyAudit/audit0";
import audit01 from "./alreadyAudit/audit1";
import audit02 from "./alreadyAudit/audit2";
import audit03 from "./alreadyAudit/audit3";
import audit04 from "./alreadyAudit/audit4";
import audit05 from "./alreadyAudit/audit5";
import audit06 from "./alreadyAudit/audit6";
import audit07 from "./alreadyAudit/audit7";
import audit08 from "./alreadyAudit/audit8";
import audit09 from "./alreadyAudit/audit9";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "rollAudit",
  data() {
    return {
      showpage: true,
      tableData: [],
      searchField: "",
      tableData2: [],
      currentPage: 1,
      pagesize: 15,
      total: 1,
      activeName: "first",
      type: "", // 申请类别
      typeList: [
        {
          value: "stuInfo",
          label: "全部申请类别"
        },
        {
          value: "stuInfoReplaceCardApply",
          label: "研究生证补办"
        },
        {
          value: "stuInfoServiceChangeTeacherApply",
          label: "学生更换导师申请"
        },
        {
          value: "stuInfoServiceDelayGraduateApply",
          label: "学生延迟毕业申请"
        },
        {
          value: "stuInfoServiceDoctorAndMesterApply",
          label: "学生硕博连读申请"
        },
        {
          value: "stuInfoServiceDropOutApply",
          label: "学生退学申请"
        },
        {
          value: "stuInfoServiceFinishGraduateApply",
          label: "学生结业申请"
        },
        {
          value: "stuInfoServiceGoBackSchoolApply",
          label: "学生复学申请"
        },
        {
          value: "stuInfoServiceQuitSchoolApply",
          label: "学生休学申请"
        },
        {
          value: "stuInfoServiceSwitchMajorApply",
          label: "学生转专业申请"
        },
        {
          value: "stuInfoServiceYiYeApply",
          label: "学生肄业申请"
        }
      ], // 申请类别列表
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      rowid0: "",
      rowid1: "",
      rowid2: "",
      rowid3: "",
      rowid4: "",
      rowid5: "",
      rowid6: "",
      rowid7: "",
      rowid8: "",
      rowid9: "",
      loading2: false,
      loading3: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      stuInfos: "stuInfo"
    };
  },
  methods: {
    freshform() {
      this.showpage = false;
      setTimeout(() => {
        this.showpage = true;
      }, 500);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    clearinput() {
      this.searchField = "";
      this.takeList();
    },
    mychange(value) {
      this.stuInfos = value;
      this.takeList();
    }, // 申请类别筛选
    takeList() {
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      if (this.activeName == "first") {
        this.loading2 = true;
        this.$http
          .get(
            `api/backgroudpage/activity/taskStuInfoList?definitionKeyLike=${this.stuInfos}&pageNum=${params.pageNum}&pageSize=${params.pageSize}&type=1&query=${this.searchField}`
          )
          .then(res => {
            this.loading2 = false;
            // setTimeout(() => {
            //   this.loading2 = false;
            // }, 500);
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          })
          .catch(err => {
            console.log(err.message);
            this.loading2 = false;
          });
      } else if (this.activeName == "second") {
        this.loading3 = true;
        this.$http
          .get(
            `api/backgroudpage/activity/getHistoryAudit?pageNum=${params.pageNum}&pageSize=${params.pageSize}&processKey=${this.stuInfos}&query=${this.searchField}`
          )
          .then(res => {
            // setTimeout(() => {
            //   this.loading3 = false;
            // }, 500);
            this.loading3 = false;
            this.tableData2 = res.data.data.list;
            res.data.data.list.map((item, index) => {
              this.tableData2[index].buttonType =
                item.state == "0"
                  ? "不通过"
                  : item.state == "1"
                  ? "通过"
                  : item.state == "2"
                  ? "退回"
                  : "";
            });
            this.total = res.data.data.total;
          })
          .catch(err => {
            console.log(err.message);
            this.loading3 = false;
          });
      }
    },
    searchData() {
      this.takeList();
    },
    tabChangeClick() {
      this.searchField = "";
      this.type = "";
      this.takeList();
    }, // 切换tab
    aduit(row) {
      this.$stores.commit("assignee", row);
      if (row.processDefinitionName == "学生退学申请") {
        this.rowid3 = row;
        this.$store.state.audit3 = true;
      } else if (row.processDefinitionName == "学生转专业申请") {
        this.rowid0 = row;
        this.$store.state.audit0 = true;
      } else if (row.processDefinitionName == "学生肄业申请") {
        this.rowid5 = row;
        this.$store.state.audit5 = true;
      } else if (row.processDefinitionName == "学生休学申请") {
        this.rowid4 = row;
        this.$store.state.audit4 = true;
      } else if (row.processDefinitionName == "学生结业申请") {
        this.rowid6 = row;
        this.$store.state.audit6 = true;
      } else if (row.processDefinitionName == "学生复学申请") {
        this.rowid2 = row;
        this.$store.state.audit2 = true;
      } else if (row.processDefinitionName == "学生延迟毕业申请") {
        this.rowid1 = row;
        this.$store.state.audit1 = true;
      } else if (row.processDefinitionName == "学生硕博连读申请") {
        this.rowid9 = row;
        this.$store.state.audit9 = true;
      } else if (row.processDefinitionName == "学生更换导师申请") {
        this.rowid8 = row;
        this.$store.state.audit8 = true;
      } else if (row.processDefinitionName == "研究生证补办") {
        this.rowid7 = row;
        this.$store.state.audit7 = true;
      }
    }, // 审核
    checkDetails(row) {
      if (row.processDefinitionName == "学生退学申请") {
        this.rowid3 = row;
        this.$store.state.audit03 = true;
      } else if (row.processDefinitionName == "学生转专业申请") {
        this.rowid0 = row;
        this.$store.state.audit00 = true;
      } else if (row.processDefinitionName == "学生肄业申请") {
        this.rowid5 = row;
        this.$store.state.audit05 = true;
      } else if (row.processDefinitionName == "学生休学申请") {
        this.rowid4 = row;
        this.$store.state.audit04 = true;
      } else if (row.processDefinitionName == "学生结业申请") {
        this.rowid6 = row;
        this.$store.state.audit06 = true;
      } else if (row.processDefinitionName == "学生复学申请") {
        this.rowid2 = row;
        this.$store.state.audit02 = true;
      } else if (row.processDefinitionName == "学生延迟毕业申请") {
        this.rowid1 = row;
        this.$store.state.audit01 = true;
      } else if (row.processDefinitionName == "学生硕博连读申请") {
        this.rowid9 = row;
        this.$store.state.audit09 = true;
      } else if (row.processDefinitionName == "学生更换导师申请") {
        this.rowid8 = row;
        this.$store.state.audit08 = true;
      } else if (row.processDefinitionName == "研究生证补办") {
        this.rowid7 = row;
        this.$store.state.audit07 = true;
      }
    } // 查看详情
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 266;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 266;
      })();
    };
    this.takeList();
  },
  components: {
    audit0,
    audit1,
    audit2,
    audit3,
    audit4,
    audit5,
    audit6,
    audit7,
    audit8,
    audit9,
    audit00,
    audit01,
    audit02,
    audit03,
    audit04,
    audit05,
    audit06,
    audit07,
    audit08,
    audit09,
    pagination,
    componment
  }
};
</script>

<style scoped lang="scss">
.rollAudit {
  width: 100%;
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      background: #fff;
    }
    /deep/ .el-tabs__nav {
      margin-left: 15px;
    }
    /deep/ .el-tabs__item {
      width: 100px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 7px;
    }
  }
}
</style>

<style>
.yes {
  color: #409eff;
}
.back {
  color: #f56c6c;
}
.audit {
  color: #febc5a;
}
.yes1 {
  background: #409eff;
}
.back1 {
  background: #f56c6c;
}
.audit1 {
  /* background: #febc5a; */
}
.time {
  margin-left: 15px;
  color: #909399;
  font-size: 13px;
}
.comment {
  margin-top: 8px;
  color: #909399;
  font-size: 13px;
}
.mytext {
  color: #333 !important;
}
</style>
