<!-- 学生信息管理 -->
<template>
  <div class="studentInformation">
    <template v-if="
        $store.state.studInformation == false &&
          $store.state.schoolRoll == false
      ">
      <componment>
        <div slot="left" style="flex:1">
          <el-input v-model="searchField" placeholder="请输入学号/姓名" @keyup.enter.native="searchData" style="width: 200px" clearable @clear="clearinput" suffix-icon="el-icon-search"></el-input>
          <el-button @click="searchData" style="margin-left:5px">查询</el-button>
          <el-select v-model="college" filterable placeholder="全部学院" style="margin-left: 10px;" class="top-input" @change="collegeChange" >
            <el-option v-for="(item, $index) in collegeList" :key="$index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="major" filterable placeholder="全部专业" style="margin-left: 10px;" class="top-input" >
            <el-option v-for="(item, $index) in majorList" :key="$index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="classform" filterable placeholder="全部年级" style="margin-left: 10px;" class="top-input"  @change="zychanges">
            <el-option v-for="(item, $index) in classList" :key="$index" :label="item.njValue" :value="item.njKey">
            </el-option>
          </el-select>
        </div>
        <div slot="right" style="flex:1">
          <el-button type="primary" @click="settingField" v-if="$btnAuthorityTest('studentInformation:set')">设置可修改字段</el-button>
          <el-button @click="recoverClick" type="primary" style="background:#fff;color:#409EFF" v-if="$btnAuthorityTest('studentInformation:updatehisrory')">修改记录</el-button>
          <el-dropdown>
            <el-button type="primary" v-if="
                $btnAuthorityTest('studentInformation:export') ||
                  $btnAuthorityTest('studentInformation:generatesign') ||
                  $btnAuthorityTest('studentInformation:generateorign')
              ">
              批量操作<i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-if="$btnAuthorityTest('studentInformation:export')">导出学生信息</el-dropdown-item>
              <el-dropdown-item v-if="$btnAuthorityTest('studentInformation:generatesign')">生成入学登记卡</el-dropdown-item>
              <el-dropdown-item v-if="$btnAuthorityTest('studentInformation:generateorign')">生成学籍卡</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </componment>
      <el-table :data="tableData.info" border ref="multipleTable" style="width: 100%;" @row-click="clickRow" @selection-change="mySelect" @select-all="allClick" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading2" element-loading-text="加载中">
        <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
        </el-table-column>
        <el-table-column prop="xh" label="学号" width="150"> </el-table-column>
        <el-table-column prop="xsxm" label="姓名"> </el-table-column>
        <el-table-column prop="xslbmc" label="学生类别"> </el-table-column>
        <el-table-column prop="ssyxmc" label="所属学院"> </el-table-column>
        <el-table-column prop="zymc" label="所属专业"> </el-table-column>
        <el-table-column prop="sznj" label="年级"> </el-table-column>
        <el-table-column prop="bjmc" label="班级"> </el-table-column>
        <el-table-column prop="dsxm" label="导师"> </el-table-column>
        <el-table-column prop="xsdqztmc" label="当前状态"> </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <span class="tablexq" @click="checkDetails2(scope.row)" v-if="$btnAuthorityTest('studentInformation:view')">查看</span>
            <span v-if="
                $btnAuthorityTest('studentInformation:view') &&
                  $btnAuthorityTest('studentInformation:update')
              ">|</span>
            <span class="tablexg" @click="checkDetails1(scope.row)" v-if="$btnAuthorityTest('studentInformation:update')">修改</span>
          </template>
        </el-table-column>
      </el-table>
      <pagination :total="total" :page.sync="listQuery.queryPage.pageNum" :limit.sync="listQuery.queryPage.pageSize" class="pagination-content" @pagination="takeList"></pagination>
    </template>
    <el-dialog title="设置可修改字段" :visible.sync="settingDialog" :before-close="handleClose" width="1050px" :close-on-click-modal="false" v-if="form.main">
      <szkxgzd ref="szkxgzd"></szkxgzd>
      <span slot="footer" class="dialog-footer">
        <div style="text-align:center">
          <el-button @click="settingDialog = false">取 消</el-button>
          <el-button type="primary" @click="affirmHandle">确 定</el-button>
        </div>
      </span>
    </el-dialog>
    <el-dialog title="修改记录" :visible.sync="recoverDialog" :before-close="handleClose" width="690px" :close-on-click-modal="false">
      <p class="hr"></p>
      <div class="table" style="margin-top: -20px;">
        <el-table :data="history.info" border ref="multipleTable" style="width: 100%; position: relative; top: 15px;" highlight-current-row @current-change="handleCurrentChange" :header-cell-style="$storage.tableHeaderColor" height="241" @selection-change="mySelects" @select-all="allClicks">
          <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
          </el-table-column>
          <el-table-column prop="cjr" label="操作人"> </el-table-column>
          <el-table-column label="修改内容">
            <template slot-scope="scope">
              <el-popover placement="top-start" width="250" trigger="hover">
                <div v-html="scope.row.gxnr"></div>
                <span slot="reference" v-html="scope.row.gxnr.substr(0, 30) + '...'"></span>
              </el-popover>
            </template>
          </el-table-column>
          <el-table-column prop="cjsj" label="操作时间"> </el-table-column>
        </el-table>
      </div>
      <div class="block" style="margin-top: 35px;">
        <el-pagination :current-page.sync="history.pageNum" :page-sizes="[15, 25, 50, 100]" :page-size="history.pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="historyPageChange" :total="history.total" @size-change="historySizeChange">
        </el-pagination>
      </div>
      <span slot="footer" class="dialog-footer">
        <div style="text-align:center">
          <el-button @click="recoverDialog = false">取 消</el-button>
          <el-button type="primary" @click="confirmBack">撤回修改</el-button>
        </div>
      </span>
    </el-dialog>
    <basic v-if="$store.state.studInformation == true" :xh1="xh1"></basic>
    <roll v-if="$store.state.schoolRoll == true" :xh2="xh2"></roll>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
import basic from "./studentcomponents/basicDetails.vue";
import roll from "./studentcomponents/schoolRoll.vue";
import szkxgzd from "./szkxgzd";
export default {
  name: "studentInformation",
  data() {
    return {
      peopleForm: {
        infor: 1
      },
      form: {},
      settingDialog: false, // 设置可修改字段弹出框
      total: 0, // 总数据条数
      myStatus: 0,
      activeName: "first",
      recoverDialog: false, // 恢复数据弹出框
      tableHeight: null, // 表格高度
      searchField: "", // 搜索的数据
      college: "", // 选择的学院
      collegeList: [], // 学院列表
      major: "", // 选择的专业
      majorList: [], // 专业列表
      tableData: [],
      tableData1: [],
      selection: [], // 选中数据
      xh1: "",
      xh2: "",
      mykey: "",
      loading2: false,
      history: [], // 修改历史
      historyQuery: {
        pageNum: 1,
        pageSize: 5
      }, // 修改历史记录查询参数
      historyInfo: {}, // 修改历史记录选中行
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      xglist: {},
      classList: [],
      classform: "",
      chxg: []
    };
  },
  watch: {
    major(val) {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.takeList();
      }, 1000);
    }
  },
  beforeDestroy() {
    clearTimeout(this.timer);
  },
  methods: {
    clearinput() {
      this.searchField = "";
      this.takeList();
    },
    mySelects(selection) {
      this.chxg = [];
      this.chxg = selection;
    },
    allClicks() {},
    // 学院修改事件
    collegeChange(val) {
      this.takeList();
      const temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.majorList = temp.children;
    },
    zychanges() {
      this.takeList();
    },
    affirmHandle() {
      this.$http.put("api/cultivate/pycssz", this.xglist).then(res => {
        this.$message({
          type: res.data.code == 200 ? "success" : "error",
          message: res.data.message
        });
        this.settingDialog = false;
      });
    },
    getNumber() {
      this.$http.get("api/cultivate/pycssz").then(res => {
        this.form = res.data.data;
      });
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/cultivate/stu/stuList", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          collegeCode: this.college,
          majorCode: this.major,
          grade: this.classform
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    sizeChange(value) {
      this.pagesize = value;
      this.takeList();
    },
    mysizeChange(value) {
      this.pagesize = value;
      this.takeList();
    },
    // 恢复列表当前页修改
    historyPageChange(index) {
      this.historyQuery.pageNum = index;
      this.loadHistoryList();
    },
    // 恢复列表页面大小修改
    historySizeChange(size) {
      this.historyQuery.pageSize = size;
      this.loadHistoryList();
    },
    recoverClick() {
      if (this.selection.length == 0 || this.selection.length > 1) {
        this.$message.error("请选择一条数据!");
        return false;
      }
      this.historyQuery = {
        pageNum: 1,
        pageSize: 5
      };
      this.loadHistoryList();
    }, // 恢复数据
    handleCurrentChange(currentRow) {
      this.historyInfo = currentRow;
    },
    // 确认恢复
    confirmBack() {
      if (this.chxg.length == 0) {
        this.$message.error("请选择一条数据!");
        return false;
      }
      const selection = [];
      this.chxg.forEach(element => {
        return selection.push(element.id);
      });
      this.$http
        .put("api/cultivate/stu/back/" + selection.toString())
        .then(res => {
          this.$message({
            message: res.data.message,
            type: res.data.code == 200 ? "success" : "error"
          });
          this.recoverDialog = false;
          this.takeList();
        });
    },
    // 查询修改历史
    loadHistoryList() {
      this.$http
        .post(
          "api/cultivate/stu/history/" + this.selection[0].xh,
          this.historyQuery
        )
        .then(res => {
          this.recoverDialog = true;
          this.history = res.data.data;
        });
    },
    checkDetails1(row) {
      this.$store.state.studInformation = true;
      this.xh1 = row.xh;
    },
    checkDetails2(row) {
      this.$store.state.schoolRoll = true;
      this.xh2 = row.xh;
    },
    searchData() {
      this.takeList();
    }, // 搜索数据方法
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {
      this.selection = [];
      this.selection = selection;
    }, // 列表选择
    allClick(selection) {
      this.selection = [];
      this.selection = selection;
    }, // 列表全选
    clickRow1(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect1(selection) {}, // 列表选择
    allClick1(selection) {}, // 列表全选
    handleClose(done) {
      done();
    },
    // 学院专业联调数据
    getCollegeMajorData() {
      this.$http.get("api/system/dict/select/college").then(res => {
        this.collegeList = res.data.data;
        this.majorList = this.collegeList[0].children;
      });
    },
    settingField() {
      this.settingDialog = true;
      this.$nextTick(() => {
        this.xglist = this.$refs.szkxgzd.form;
        this.$refs.szkxgzd.getNumber();
      });
    }, // 设置字段
    getnj() {
      this.$http.get(`api/cultivate/pyfa/selectNjList`).then(res => {
        if (res.data.data.length > 1) {
          this.classList = res.data.data;
          this.classList.unshift({ njKey: "", njValue: "全部年级" });
        } else {
          this.classList = res.data.data;
        }
      });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.getNumber();
    this.getnj();
    // 学院专业联调数据
    this.getCollegeMajorData();
  },
  components: {
    basic,
    roll,
    componment,
    pagination,
    szkxgzd
  }
};
</script>

<style scoped lang="scss">
.studentInformation {
  width: 100%;
  padding-top: 7px;
  overflow: hidden;
}
</style>
