<!-- 首页 -->
<template>
  <div class="szkxgzd">
    <table>
      <tr>
        <td class="right">婚姻状况</td>
        <td class="left">
          <el-radio-group v-model="form.main.marray" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right">健康状况</td>
        <td class="left">
          <el-radio-group v-model="form.main.jkzk" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
      </tr>
      <tr>
        <td class="right">户口所在地</td>
        <td class="left">
          <el-radio-group v-model="form.main.hkszd" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right">户口详细地址</td>
        <td class="left">
          <el-radio-group v-model="form.main.xxdz" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
      </tr>
      <tr>
        <td class="right">移动电话</td>
        <td class="left">
          <el-radio-group v-model="form.main.yddh" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right">固定电话</td>
        <td class="left">
          <el-radio-group v-model="form.main.gddh" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
      </tr>
      <tr>
        <td class="right">电子邮箱</td>
        <td class="left">
          <el-radio-group v-model="form.main.email" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right">邮政编码</td>
        <td class="left">
          <el-radio-group v-model="form.main.mycode" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
      </tr>
      <tr>
        <td class="right">通讯地址</td>
        <td class="left">
          <el-radio-group v-model="form.main.mailingAddress" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right">学习和工作经历</td>
        <td class="left">
          <el-radio-group v-model="form.main.xxgzjl" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
      </tr>
      <tr>
        <td class="right">何时何地何原因受过何种奖励或处分</td>
        <td class="left">
          <el-radio-group v-model="form.main.jlcf" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right">家庭主要成员</td>
        <td class="left">
          <el-radio-group v-model="form.main.infor" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
      </tr>
      <tr>
        <td class="right">是否跨学科</td>
        <td class="left">
          <el-radio-group v-model="form.main.sfkxk" class="in-select">
            <el-radio :label="0">只读</el-radio>
            <el-radio :label="1">可修改</el-radio>
          </el-radio-group>
        </td>
        <td class="right"></td>
        <td class="left">
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: "szkxgzd",
  data() {
    return {
      form: {
        main: {
          marray: 0,
          jkzk: 1,
          hkszd: 0,
          xxdz: 1,
          yddh: 0,
          gddh: 1,
          email: 0,
          mycode: 1,
          mailingAddress: 0,
          xxgzjl: 1,
          jlcf: 0,
          infor: 1,
          sfkxk: 0
        },
        createTime: "",
        createUser: "",
        id: "",
        key: "",
        remark: "",
        updateTime: "",
        updateUser: ""
      },
      peopleForm: {
        infor: 1
      }
    };
  },
  methods: {
    getNumber() {
      this.$http.get("api/cultivate/pycssz").then(res => {
        this.form.main = res.data.data.main;
        this.form.createTime = res.data.data.createTime;
        this.form.createUser = res.data.data.createUser;
        this.form.id = res.data.data.id;
        this.form.key = res.data.data.key;
        this.form.remark = res.data.data.remark;
        this.form.updateTime = res.data.data.updateTime;
        this.form.updateUser = res.data.data.updateUser;
      });
    }
  },
  mounted() {
    this.getNumber();
  }
};
</script>

<style scoped lang="scss">
.szkxgzd {
  width: 100%;
  table {
    // border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    // text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    // line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
}
</style>
