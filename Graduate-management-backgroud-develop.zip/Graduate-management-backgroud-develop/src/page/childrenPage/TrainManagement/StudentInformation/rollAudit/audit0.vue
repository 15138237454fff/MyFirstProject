// 转专业
<template>
  <div class="audit0">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="personal-details">
      <el-form :model="form" label-width="200px" ref="form" class="myform">
        <el-row>
          <el-col :span="24">
            <p class="title">浙江财经大学研究生转专业申请表</p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="姓名">
              <el-input v-model="form.xm" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学号">
              <el-input v-model="form.xh" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="性别">
              <el-input v-model="form.xbm" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="入学年月">
              <el-input v-model="form.rxny" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="学生类别">
              <el-input v-model="form.xslbmc" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="培养方式">
              <el-input v-model="form.pyfsm" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="height: 120px;" class="myrow">
          <el-col style="height: 100%;" :span="24">
            <el-form-item label="现所学专业情况" style="height: 100%; line-height: 120px; padding-right: 20px;">
              <el-row style="height: 60px;">
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="原学院" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <el-input v-model="form.yxsh" style="width: 100%; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="原专业" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <el-input v-model="form.zy" style="width: 200px; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row style="height: 60px;">
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="原导师" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <el-input v-model="form.dsxm" style="width: 100%; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="" style="height: 60px; line-height: 60px; padding-right: 20px;">
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="height: 120px;" class="myrow">
          <el-col style="height: 100%;" :span="24">
            <el-form-item label="拟转入专业情况" style="height: 100%; line-height: 120px; padding-right: 20px;" :required="true">
              <el-row style="height: 60px;">
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="新学院" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <el-input v-model="form.xxy" style="width: 100%; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="新专业" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <el-input v-model="form.xzy" style="width: 200px; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row style="height: 60px;">
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="新导师" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <el-input v-model="form.xds" style="width: 100%; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input>
                  </el-form-item>
                </el-col>
                <el-col style="height: 60px;" :span="12">
                  <el-form-item label="" style="height: 60px; line-height: 60px; padding-right: 20px;">
                    <!-- <el-input v-model="form.xyjxk" style="width: 200px; margin: 5px 0 0 1%;" class="lookOnly" :readonly="true"></el-input> -->
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="height: 200px;" class="myrow">
          <el-col :span="24" style="height: 100%;">
            <el-form-item label="申请理由" style="height: 100%; line-height: 200px; padding-right: 20px;" :required="true">
              <el-input v-model="form.reason" type="textarea" :rows="8" style="margin-top: 10px; margin-left: 10px;" class="lookOnly" :readonly="true"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="border-bottom: 1px solid #eee;">
          <el-col :span="24">
            <el-form-item label="证明材料：" :required="true">
              <el-button type="text" v-for="(item, index) in fileList" :key="index" @click="open(item.url)">{{item.fileName}}</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="step">
      <el-steps :active="list.length" :space="200">
        <el-step v-for="(item,index) in list" :key="index" :icon="item.state == '1' || item.state == null ? 'el-icon-circle-check' : item.state == '2' ? 'el-icon-d-arrow-left' : 'el-icon-close'">
          <div slot="title" class="mytext">{{item.name + "("+item.assignee+")"}}</div>
          <span slot="description" :class="{yes:item.state == '1',back:item.state == '2' || item.state == '0'}">{{item.state == '1' ? '通过' : item.state == '0' ? '不通过' : item.state == '2' ? '退回' : ''}}</span>&nbsp;&nbsp;
          <span slot="description" class="comment">{{item.endTime}}</span>
          <div slot="description" class="comment">{{item.comment}}</div>
        </el-step>
      </el-steps>
    </div>
    <el-form :model="bottomform" label-width="200px" ref="bottomform" style="margin-top: 20px;">
      <el-row>
        <el-col :span="24">
          <el-form-item label="审核：">
            <el-radio-group v-model="bottomform.audit">
              <el-radio-button :label="0" v-if="zfshow">转发</el-radio-button>
              <el-radio-button :label="1" v-if="pass">通过</el-radio-button>
              <el-radio-button :label="2" v-if="pass">不通过</el-radio-button>
            </el-radio-group>
            <el-select v-model="value" placeholder="请选择" v-if="zfshow">
              <el-option v-for="(item,$index) in options" :key="$index" :label="item.name" :value="item.userName">
              </el-option>
            </el-select>
            <el-button type="primary" @click="submitHandle" v-if="zfshow">提交</el-button>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="height: 200px;margin:10px 0px" class="myrow">
        <el-col :span="24" style="height: 100%;" v-if="pass">
          <el-form-item label="审核意见：" style="height: 100%; line-height: 200px;" :required="true">
            <el-input v-model="bottomform.idea" type="textarea" :rows="8" style="width:90%"></el-input>
            <el-button type="primary" @click="submitHandle">提交</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <!-- v-if="taskDefinitionKey =='wmCheckBeforeAdmin' || 'wmCheckLaterAdmin'" -->
  </div>
</template>

<script>
export default {
  props: ["rowid0"],
  name: "audit0",
  data() {
    return {
      form: {},
      bottomform: {
        audit: "",
        idea: " "
      },
      fileList: [],
      list: [],
      taskDefinitionKey: "", // 审核状态
      options: [],
      value: "",
      deptNum: "",
      zfshow: false,
      pass: false
    };
  },
  methods: {
    open(val) {
      window.open(val);
    },
    submitHandle() {
      // 通过
      if (this.bottomform.audit == "1") {
        this.$http
          .post("api/backgroudpage/activity/saveOrder", {
            check: 1,
            comment: this.bottomform.idea,
            taskId: this.rowid0.id,
            taskKey: this.rowid0.taskDefinitionKey
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "提交成功",
                type: "success"
              });
              this.$store.state.audit0 = false;
              this.$parent.freshform();
            } else {
              this.$message.error({
                message: "提交失败"
              });
            }
          });
        // 不通过
      } else if (this.bottomform.audit == "2") {
        if (this.bottomform.idea == "") {
          this.$message({
            message: "请输入审核内容",
            type: "error"
          });
          return false;
        }
        this.$http
          .post("api/backgroudpage/activity/saveOrder", {
            check: 0,
            comment: this.bottomform.idea,
            taskId: this.rowid0.id,
            taskKey: this.rowid0.taskDefinitionKey
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "提交成功",
                type: "success"
              });
              this.$store.state.audit0 = false;
              this.$parent.freshform();
            } else {
              this.$message.error({
                message: "提交失败"
              });
            }
          });
      } else if (this.bottomform.audit == "0") {
        if (this.value == "") {
          this.$message({
            message: "请选择审核状态",
            type: "error"
          });
          return false;
        }
        this.$http
          .put("api/backgroudpage/activity/stuSaveOrder2", {
            taskCheck: 1,
            taskId: this.$stores.state.assignee.id,
            taskUser: this.value,
            type: '1'
          })
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "指定成功",
                type: "success"
              });
              this.$store.state.audit0 = false;
              this.$parent.freshform();
            } else {
              this.$message.error({
                message: "指定失败"
              });
            }
          });
      } else {
      }
    }, // 提交
    exitList() {
      this.$store.state.audit0 = false;
      this.$parent.freshform();
    },
    handleSuccess(response, file, fileList) {
      this.fileName = file.response.url;
    },
    takeList() {
      this.$http
        .get(
          "api/backgroudpage/xjydsq/zzysqInfoByLcid?lcid=" +
            this.rowid0.processInstanceId
        )
        .then(res => {
          this.form = res.data.data.xsXjydsqZzysqVo;
          this.form.reason = res.data.data.pyXjydb.ydsm;
          this.form.xxy = res.data.data.pyXjydb.xyxsh;
          this.form.xzy = res.data.data.pyXjydb.xzym;
          this.form.xds = res.data.data.pyXjydb.xdsh;
          this.form.xyjxk = res.data.data.pyXjydb.xyjxk;
          this.fileList = res.data.data.pyXjydb.firstfj;
          this.list = res.data.data.list;
        });
    },
    selectLeadList() {
      this.$http
        .get(
          `/api/backgroudpage/activity/selectLeadList?deptNum=` + this.deptNum
        )
        .then(res => {
          this.options = res.data.data;
        });
    }
  },
  mounted() {
    this.takeList();
    this.taskDefinitionKey = this.$stores.state.assignee.taskDefinitionKey; // 判断学院秘书审核流程
    this.taskDefinitionKey == "wmCheckBeforeAdmin" ||
    this.taskDefinitionKey == "wmCheckLaterAdmin"
      ? ((this.zfshow = true),
        (this.pass = false),
        (this.bottomform.audit = "0"))
      : ((this.pass = true),
        (this.zfshow = false),
        (this.bottomform.audit = "1"));
    switch (this.$stores.state.assignee.taskDefinitionKey) {
      case "wmCheckBeforeAdmin":
        this.deptNum = this.$stores.state.assignee.processVariables.deptId; // 原秘书院审核
        break;
      case "wmCheckLaterAdmin":
        this.deptNum = this.$stores.state.assignee.processVariables.newDeptId; // 新秘书院审核
        break;
      default:
        break;
    }
    this.selectLeadList();
    // this.processDefinitionId = this.$stores.state.assignee.processDefinitionId; //判断学院秘书审核流程
  }
};
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
.audit0 {
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .personal-details,
  .family-information {
    width: 100%;
    margin-top: 15px;
    .el-row {
      // height: 50px;
      width: 100%;
      .el-col {
        // height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
    .title {
      font-size: 20px;
      font-weight: bold;
      text-align: center;
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
  .step {
    margin-top: 20px;
  }
}

.audit0 /deep/ .myform .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.audit0 /deep/ .myrow > .el-form-item__label {
  line-height: 120px;
}
.audit0 /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.audit0 /deep/ .el-form-item__label {
  text-align: center;
}
</style>
