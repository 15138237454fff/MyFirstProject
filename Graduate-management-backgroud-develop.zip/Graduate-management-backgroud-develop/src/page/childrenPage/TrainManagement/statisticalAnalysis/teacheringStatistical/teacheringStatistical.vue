<template>
  <div class="teacheringStatistical">
    <my-breadcrumb>
      <div slot="left">
        <el-select v-model="limitQuery.year">
          <el-option
            v-for="(item, index) in xnList"
            :key="index"
            :label="`${item} - ${item + 1}`"
            :value="`${item}-${item + 1}`"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.xq">
          <el-option label="春季学期" :value="2"></el-option>
          <el-option label="秋季学期" :value="1"></el-option>
        </el-select>
        <el-select v-model="limitQuery.xy" @change="limitQuery.zy = ''">
          <el-option
            v-for="(item, index) in xyList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.zy">
          <el-option
            v-for="(item, index) in zyList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.sznj">
          <el-option
            v-for="(item, index) in njList"
            :key="index"
            :label="item.label + ' 年'"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select
          v-model="limitQuery.kc"
          filterable
          remote
          :remote-method="requireKcList"
          :loading="remoteLoading"
        >
          <el-option label="全部课程" :value="null"></el-option>
          <el-option
            v-for="(item, index) in kcList"
            :key="index"
            :label="`${item.kcmc}(${item.kch})`"
            :value="item.kch"
          ></el-option>
        </el-select>
        <el-button @click="initLoadData" type="primary">搜索</el-button>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <el-tabs
      v-model="activeName"
      style="border:1px solid #e4e4e4"
      @tab-click="loadData"
    >
      <el-tab-pane label="成绩分布" name="spread" style="height:100%;">
        <div class="echarts-area">
          <div class="left">
            <span>成绩分数占比统计</span>
            <div ref="echartPip" style="width:100%;height:100%;"></div>
          </div>
          <div class="right">
            <span>成绩分数数量统计</span>
            <div ref="echartBar" style="width:100%;height:100%;"></div>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="成绩榜单" name="list"
        ><div class="box">
          <el-table
            :data="tableData"
            border
            style="width: 100%"
            :header-cell-style="$storage.tableHeaderColor"
            :height="tableHeight"
            v-loading="loading"
            element-loading-text="加载中"
            element-loading-spinner="el-icon-loading"
            ref="box"
          >
            <el-table-column
              type="index"
              label="排名"
              align="center"
              :width="80"
            >
            </el-table-column>
            <el-table-column
              prop="xh"
              label="学号"
              align="center"
              show-overflow-tooltip
            >
            </el-table-column>
            <el-table-column
              label="姓名"
              align="center"
              :width="200"
              prop="xsxm"
            >
            </el-table-column>
            <el-table-column prop="xymc" label="所在学院" align="center">
            </el-table-column>
            <el-table-column prop="zy" label="所在专业" align="center">
            </el-table-column>
            <el-table-column prop="sznj" label="年级" align="center">
            </el-table-column>
            <el-table-column prop="pscj" label="平时成绩" align="center">
            </el-table-column>
            <el-table-column prop="kccj" label="期末成绩" align="center">
            </el-table-column>
            <el-table-column prop="kccj" label="最终成绩" align="center">
            </el-table-column>
          </el-table></div
      ></el-tab-pane>
    </el-tabs>
    <!-- 分页 -->
    <!-- <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination> -->
  </div>
</template>

<script>
var echarts = require("echarts");
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "teacheringStatistical",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        xq: 1,
        xy: "",
        zy: "",
        year: `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`,
        sznj: null,
        kc: null,
        nj: null
      },
      loading: false,
      remoteLoading: false,
      activeName: "spread",
      xyList: [],
      xnList: [],
      kcList: [],
      njList: [],
      result: [],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 274;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 390;
      })();
    };
    this.requireKcList("");
    // 初始化学年学期
    this.initXnList();
    this.requireXyZyList();
    this.requireNjList();
    this.loadData();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let { xq, xy, zy, year, sznj, kc, pageNum, pageSize } = this.limitQuery,
        tmpObj = {
          collegeCode: xy,
          courseNumber: kc,
          pageNum,
          pageSize,
          majorCode: zy,
          schoolYear: year,
          semester: xq,
          sznj: sznj
        };
      // 发送请求列表数据的请求
      this.$http
        .post("/api/cultivate/statistic/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadData() {
      if (this.activeName === "spread") {
        this.requireDetail();
      } else {
        this.loadTable();
      }
    },
    initLoadData() {
      if (this.activeName === "spread") {
        this.requireDetail();
      } else {
        this.initLoadTable();
      }
    },
    requireDetail() {
      let { xq, xy, zy, year, sznj, kc } = this.limitQuery,
        tmpObj = {
          collegeCode: xy,
          courseNumber: kc,
          majorCode: zy,
          schoolYear: year,
          semester: xq,
          sznj: sznj
        };
      this.$http.post("/api/cultivate/statistic/score", tmpObj).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        this.result = data.data;
        this.drawPip();
        this.drawBar();
      });
    },
    drawPip() {
      let myChart = echarts.init(this.$refs.echartPip);
      let result = this.result.map(el => {
        if (el === 0) {
          return null;
        } else {
          return el;
        }
      });
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c}人 ({d}%)"
        },
        legend: {
          x: "center",
          data: [
            "其他",
            " < 60分",
            "60 - 69分",
            "70 - 79分",
            "80 - 89分",
            "90 - 100分"
          ],
          bottom: 0
        },
        color: [
          "#c6e3ff",
          "#71b8ff",
          "#4da6ff",
          "#178bff",
          "#0061c1",
          "#005097"
        ],
        series: [
          {
            name: "成绩统计",
            type: "pie",
            radius: "55%",
            center: ["50%", "50%"],
            roseType: "radius",
            label: {
              formatter: "{c|· }{a|{b}}    {b||  {d}%}",
              rich: {
                a: {
                  color: "#000"
                },
                b: {
                  color: "#aaa"
                },
                c: {
                  color: "#7dd451",
                  fontWeight: "bolder",
                  fontSize: "24"
                }
              }
            },
            labelLine: {
              normal: {
                lineStyle: {
                  color: "rgba(0, 0, 0, 0.3)"
                },
                length: 10
              }
            },
            data: [
              { value: result[0], name: "其他" },
              { value: result[1], name: " < 60分" },
              { value: result[2], name: "60 - 69分" },
              { value: result[3], name: "70 - 79分" },
              { value: result[4], name: "80 - 89分" },
              { value: result[5], name: "90 - 100分" }
            ],
            animationType: "scale",
            animationEasing: "elasticOut",
            animationDelay: function(idx) {
              return Math.random() * 200;
            }
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    drawBar() {
      let myChart = echarts.init(this.$refs.echartBar);
      const option = {
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "line" // 默认为直线，可选为：'line' | 'shadow'
          },
          formatter: "{b}: {c}人"
        },
        legend: {
          orient: "vertical",
          x: "right",
          data: []
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        color: [
          "#c6e3ff",
          "#71b8ff",
          "#4da6ff",
          "#178bff",
          "#0061c1",
          "#005097"
        ],
        xAxis: [
          {
            type: "value",
            splitLine: {
              show: false
            },
            show: false
          }
        ],
        yAxis: [
          {
            type: "category",
            data: [
              "其他",
              " < 60分",
              "60 - 69分",
              "70 - 79分",
              "80 - 89分",
              "90 - 100分"
            ],
            // axisLabel: {
            //   interval: 0,
            //   rotate: 30
            // },
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "成绩统计",
            type: "bar",
            stack: "chart",
            label: {
              color: ["#000000"],
              show: true,
              position: "right",
              formatter: "{c}人"
            },
            itemStyle: {
              // 通常情况下：
              normal: {
                // 每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                color: function(params) {
                  var colorList = [
                    "#c6e3ff",
                    "#71b8ff",
                    "#4da6ff",
                    "#178bff",
                    "#0061c1",
                    "#005097"
                  ];
                  return colorList[params.dataIndex];
                }
              }
            },
            data: [
              { value: this.result[0], name: "其他" },
              { value: this.result[1], name: " < 60分" },
              { value: this.result[2], name: "60 - 69分" },
              { value: this.result[3], name: "70 - 79分" },
              { value: this.result[4], name: "80 - 89分" },
              { value: this.result[5], name: "90 - 100分" }
            ]
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    // 请求学院专业列表
    requireXyZyList() {
      this.$http.get(`/api/system/dict/noPermission`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.xyList = data;
      });
    },
    requireNjList() {
      this.$http.get("/api/cultivate/sac/select/grade").then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("年级列表数据获取失败");
          return false;
        }
        this.njList = data;
      });
    },
    // 请求课程列表
    requireKcList(query) {
      this.remoteLoading = true;
      this.$http
        .get(`/api/cultivate/course/search/1/10`, {
          params: {
            query
          }
        })
        .then(res => {
          let data = res.data.list;
          this.remoteLoading = false;
          if (!Array.isArray(data)) {
            this.$message.error("课程列表获取失败");
            return;
          }
          this.kcList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.remoteLoading = false;
        });
    },
    // 初始化学年学期
    initXnList() {
      this.$http.get("/api/cultivate/pycssz/acadYearTermHisList").then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error("获取学年列表失败");
          return;
        }
        let tmpArr = data.data.map(el => {
          return parseInt(el.value.split("-")[0]);
        });
        this.xnList = Array.from(new Set(tmpArr));
      });
    }
  },
  computed: {
    zyList() {
      let tmpObj = this.xyList.find(el => {
        return el.value === this.limitQuery.xy;
      });
      if (!tmpObj) {
        return [];
      }
      return tmpObj.children;
    }
  }
};
</script>

<style lang="scss" scoped>
.teacheringStatistical {
  padding-top: 10px;
  .echarts-area {
    height: 95%;
    margin-bottom: 10px;
    font-weight: bold;
    font-size: 14px;
    display: flex;
    padding: 20px;
    & > div {
      flex: 1;
      padding: 10px;
      margin-right: 20px;
      &:not(:last-child) {
        border-right: 2px dashed #e4e4e4;
      }
    }
  }
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
/deep/ .el-tabs__header {
  margin: 0;
}
/deep/ .el-tabs__nav-wrap {
  padding-left: 10px;
}
/deep/ .el-tabs__content {
  height: calc(100vh - 272px);
  padding: 20px;
  // overflow: auto;
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
