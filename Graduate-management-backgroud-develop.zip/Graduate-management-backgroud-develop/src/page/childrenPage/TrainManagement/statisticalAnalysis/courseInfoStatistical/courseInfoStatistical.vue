<template>
  <div class="courseInfoStatistical">
    <my-breadcrumb>
      <div slot="left">
        <el-select v-model="limitQuery.year">
          <el-option
            v-for="(item, index) in xnList"
            :key="index"
            :label="`${item} - ${item + 1}`"
            :value="`${item}-${item + 1}`"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.xq">
          <el-option label="春季学期" :value="2"></el-option>
          <el-option label="秋季学期" :value="1"></el-option>
        </el-select>
        <el-select v-model="limitQuery.xy">
          <el-option
            v-for="(item, index) in xyList"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-button @click="clickSearch" type="primary">搜索</el-button>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="echarts-area">
      <course-card
        title="公共基础课"
        :scale="courseCount"
        :count="courseDetailList[0]"
      ></course-card>
      <course-card
        title="学科基础课"
        :scale="courseCount"
        :count="courseDetailList[1]"
      ></course-card>
      <course-card
        title="专业课"
        :scale="courseCount"
        :count="courseDetailList[2]"
      ></course-card>
    </div>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column prop="kch" label="课程号" align="center">
        </el-table-column>
        <el-table-column
          prop="kcmc"
          label="课程名称"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          label="开课单位"
          align="center"
          :width="200"
          prop="xymc"
        >
        </el-table-column>
        <el-table-column prop="xm" label="授课教师" align="center">
        </el-table-column>
        <el-table-column prop="xf" label="学分" align="center">
        </el-table-column>
        <el-table-column prop="zxs" label="学时" align="center">
        </el-table-column>
        <el-table-column prop="yjszdgzl" label="排课详情" align="center">
          <template slot-scope="scope">
            <span v-html="computedCourseDetailList[scope.$index]"></span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import courseCard from "./courseCard";
export default {
  name: "courseInfoStatistical",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        xy: "",
        xq: 2,
        year: `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`
      },
      loading: false,
      xyList: [],
      xnList: [],
      statusMap: {
        "1": "星期一",
        "2": "星期二",
        "3": "星期三",
        "4": "星期四",
        "5": "星期五",
        "6": "星期六",
        "7": "星期日"
      },
      selectedHistoryList: [],
      courseDetailList: [],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "course-card": courseCard
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 390;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 390;
      })();
    };
    // 初始化学年学期
    this.initXnList();
    this.loadTable();
    this.requireXyZyList();
    this.requireDetail();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      let { xq, xy, year, pageNum, pageSize } = this.limitQuery,
        tmpObj = {
          pageNum,
          pageSize,
          collegeCode: xy,
          schoolYear: year,
          semester: xq
        };
      // 发送请求列表数据的请求
      this.$http
        .post("/api/cultivate/statistic/course/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    clickSearch() {
      this.requireDetail();
      this.initLoadTable();
    },
    requireDetail() {
      let { xq, xy, year } = this.limitQuery,
        tmpObj = {
          collegeCode: xy,
          schoolYear: year,
          semester: xq
        };
      this.$http.post("/api/cultivate/statistic/course", tmpObj).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        this.courseDetailList = data.data;
      });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 请求学院专业列表
    requireXyZyList() {
      this.$http.get(`/api/system/dict/noPermission`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.xyList = data;
      });
    },
    // 初始化学年学期
    initXnList() {
      this.$http.get("/api/cultivate/pycssz/acadYearTermHisList").then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error("获取学年列表失败");
          return;
        }
        let tmpArr = data.data.map(el => {
          return parseInt(el.value.split("-")[0]);
        });
        this.xnList = Array.from(new Set(tmpArr));
      });
    }
  },
  computed: {
    zyList() {
      let tmpObj = this.xyList.find(el => {
        return el.value === this.limitQuery.xy;
      });
      if (!tmpObj) {
        return [];
      }
      return tmpObj.children;
    },
    courseCount() {
      return this.courseDetailList.reduce((prev, el) => {
        return prev + el;
      }, 0);
    },
    computedCourseDetailList() {
      let tmpArr = this.tableData.map(item => {
        if (!item.detail) {
          return "";
        }
        return item.detail
          .map(el => {
            return `${el.zc}周（${
              el.sfmz === 1 ? "每周" : el.sfmz === 2 ? "单周" : "双周"
            }） ${this.statusMap[el.xq]} ${el.kj}节`;
          })
          .join("<br/>");
      });
      return tmpArr;
    }
  }
};
</script>

<style lang="scss" scoped>
.courseInfoStatistical {
  padding-top: 10px;
  .echarts-area {
    margin-bottom: 10px;
    display: flex;
    padding: 20px;
    border: 1px solid #e4e4e4;
    & > div {
      flex: 1;
      &:not(:last-child) {
        border-right: 1px solid #e4e4e4;
      }
    }
  }
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
