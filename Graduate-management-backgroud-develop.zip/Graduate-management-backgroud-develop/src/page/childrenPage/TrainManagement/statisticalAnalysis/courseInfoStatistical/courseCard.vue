<template>
  <div class="courseCard">
    <div class="text">
      <div class="title">{{ title }}</div>
      <div class="scale" v-if="scale > 0">
        {{ ((count / scale) * 100).toFixed(0) }}%
      </div>
      <div>
        <span class="count">{{ count }}</span>
        <span>门</span>
      </div>
    </div>
    <div ref="echart" style="width:100px;height:100px"></div>
  </div>
</template>
<script>
var echarts = require("echarts");
export default {
  name: "courseCard",
  props: {
    title: {},
    count: {},
    scale: {}
  },
  mounted() {
    this.draw();
  },
  methods: {
    draw() {
      let myChart = echarts.init(this.$refs.echart);
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c} ({d}%)"
        },
        legend: {
          orient: "vertical",
          x: "right",
          data: []
        },
        color: ["#409dff", "#cccccc"],
        series: [
          {
            name: "课程统计",
            type: "pie",
            radius: ["50%", "70%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: false,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: [
              { value: this.count, name: "公共基础课" },
              {
                value: (this.count / this.scale) * 100 - this.count,
                name: "其他课程"
              }
            ]
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.courseCard {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-around;
  font-size: 14px;
  .text {
    .title {
      color: #999;
      margin-bottom: 20px;
    }
    .scale {
      color: #409dff;
    }
    .count {
      font-size: 24px;
    }
  }
}
</style>
