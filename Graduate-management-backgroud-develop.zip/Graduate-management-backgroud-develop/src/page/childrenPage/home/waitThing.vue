<template>
  <div class="noticeList">
    <div class="title">
      <div class="back">
        <i class="el-icon-d-arrow-left"></i>
        <el-button @click="goBack">返回</el-button>
      </div>
    </div>
    <div class="box">
      <div class="box-title">待办事项</div>
      <ul class="box-content" v-loading="loading">
        <li
          class="msgItem"
          v-for="(item, index) of msgList"
          :key="index"
          @click="goDetail(item)"
        >
          <span class="content"
            >您有1条{{ item.xm }}的{{ item.processDefinitionName }}</span
          >
          <span class="time">{{ item.createTime | toDate }}</span>
        </li>
      </ul>
      <!-- 分页 -->
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="newCount"
      ></my-pagination>
    </div>
  </div>
</template>
<script>
import myPagination from "@/components/skb/myPagination";
export default {
  name: "noticeList",
  data() {
    return {
      // 分页查询参数
      limitQuery: {
        pageNum: 1,
        pageSize: 10,
        zt: 1,
        query: ""
      },
      // 通知消息列表
      msgList: [],
      // 通知消息总条数
      newCount: 0,
      loading: false
    };
  },
  mounted() {
    this.requireMsgList();
  },
  components: {
    "my-pagination": myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.requireMsgList();
    },
    // 请求通知公告消息列表
    requireMsgList() {
      this.loading = true;
      this.$http
        .get(
          `/api/system/dbsx/selectRuTaskList/${this.limitQuery.pageNum}/${this.limitQuery.pageSize}`,
          {
            params: {
              type: 1
            }
          }
        )
        .then(result => {
          this.loading = false;
          const list = result.data.data.list;
          // 对通知消息进行格式验证
          if (!Array.isArray(list)) {
            this.$message.error("通知公告参数格式不正确");
            return false;
          }
          this.msgList = list;
          this.newCount = result.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 后退
    goBack() {
      this.$router.go(-1);
    },
    // 前往对应通知详情
    goDetail(item) {
      let routerPath = this.$stores.state.newsRouterMap[
        item.processDefinitionId.split(":")[0]
      ];
      if (routerPath) {
        this.$router.push(routerPath);
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.noticeList {
  flex-wrap: wrap;
  .title {
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: 44px;
    margin-bottom: 12px;
    .back {
      font-weight: 400;
      line-height: 44px;
      .el-button,
      i {
        border: none;
        outline: none;
        font-size: 14px;
        color: #1890ff;
        padding: 0;
        &:hover {
          background: #fff;
        }
      }
    }
  }
  .box {
    padding: 20px;
    border: 1px solid #ddd;
    font-size: 14px;
    .box-title {
      font-size: 16px;
      color: #1e1e1e;
      font-weight: 700;
      border-bottom: 1px solid #ddd;
      height: 44px;
      line-height: 24px;
    }
    .box-content {
      height: calc(100vh - 324px);
      overflow: auto;
    }
    .msgItem {
      border-bottom: 1px dashed #ddd;
      display: flex;
      justify-content: space-between;
      height: 44px;
      line-height: 44px;
      padding: 0 10px;
      cursor: pointer;
      .content {
        font-weight: 700;
      }
      .time {
        font-size: 12px;
      }
    }
  }
}
</style>
