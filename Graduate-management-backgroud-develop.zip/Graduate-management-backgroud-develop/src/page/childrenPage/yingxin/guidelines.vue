<template>
  <div class="guidelines">
    <template
      v-if="
        $store.state.addguidelines == false &&
          $store.state.addnotificlist == false
      "
    >
      <div class="studentmessage_box">
        <el-input
          v-model="search"
          placeholder="请输入标题"
          style="width: 200px"
          @keyup.enter.native="handleFind"
          @clear="clearinput"
          clearable
          suffix-icon="el-icon-search"
        >
        </el-input>
        <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        <el-button
          type="primary"
          style="float:right;margin-top:10px;"
          @click="delrelease"
          v-if="$btnAuthorityTest('guidelines:publish')"
          >取消发布</el-button
        >
        <el-button
          type="primary"
          style="float:right;margin-top:10px;margin-right:4px"
          @click="release"
          v-if="$btnAuthorityTest('guidelines:publish')"
          >发布</el-button
        >
        <el-button
          type="danger"
          style="float:right;margin-top:10px;"
          @click="del"
          v-if="$btnAuthorityTest('guidelines:delete')"
          >删除</el-button
        >
        <el-button
          type="primary"
          style="float:right;margin-top:10px;"
          @click="add"
          v-if="$btnAuthorityTest('guidelines:add')"
          >添加</el-button
        >
      </div>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        v-loading="loading2"
        ref="multipleTable"
        style="width: 100%;"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        @row-click="clickRow"
        @select-all="allClick"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="bt" label="标题"></el-table-column>
        <el-table-column prop="cjsj" label="创建时间"></el-table-column>
        <el-table-column label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.zt == '1'">已发布</span>
            <span v-if="scope.row.zt == '0'">未发布</span>
          </template>
        </el-table-column>
        <el-table-column prop="id" label="操作">
          <template slot-scope="scope">
            <el-button
              style="color:#409eff;text-decoration:underline"
              type="text"
              @click="Checkdetails(scope.row.id)"
              v-if="$btnAuthorityTest('guidelines:view')"
              >查看详情</el-button
            >
          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          :current-page.sync="currentPage"
          :page-sizes="[15, 25, 50, 100]"
          :page-size="pagesize"
          class="import"
          layout="total, sizes, prev, pager, next, jumper"
          @current-change="changePage"
          :total="total"
          @size-change="sizeChange"
          background
        ></el-pagination>
      </div>
    </template>
    <addnotifics v-else-if="$store.state.addguidelines == true"></addnotifics>
    <addnotificlist
      v-else-if="$store.state.addnotificlist == true"
      :id="id"
    ></addnotificlist>
  </div>
</template>

<script>
import addnotifics from "../yingxin/addnotifics";
import addnotificlist from "./addnotificlist";
import { constants } from "fs";
export default {
  name: "guidelines",
  data() {
    return {
      search: "",
      upmodel: "",
      upmodels: "",
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 5,
      currentPage: 1,
      total: 0,
      tableData: [],
      loading2: false,
      multipleTables: [],
      releaselist: [],
      noreleaselist: [],
      releaselists: [],
      noreleaselists: [],
      id: ""
    };
  },
  components: {
    addnotifics,
    addnotificlist
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    allClick(selection) {
      console.log(selection);
    }, // 列表全选
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    clearinput() {
      this.search = "";
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    excel() {},
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.multipleTables = [];
        this.releaselist = [];
      } else {
        this.multipleTables = selection.map(item => {
          return item.id;
        });
        this.releaselist = selection.map(item => {
          return item.id;
        });
        this.releaselists = selection.map(item => {
          return item;
        });
        this.noreleaselist = selection.map(item => {
          return item.id;
        });
        this.noreleaselists = selection.map(item => {
          return item;
        });
      }
    },
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    add() {
      this.$store.state.addguidelines = true;
    },
    del() {
      let foot = true;
      if (this.multipleTables.length == 0) {
        this.$message({
          message: "请勾选在进行删除",
          type: "error"
        });
        return false;
      } else {
        this.$confirm("是否执行删除操作, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.releaselists.map(v => {
              if (foot) {
                if (v.zt == "1") {
                  this.$message({
                    message: "已发布的不能进行删除",
                    type: "error"
                  });
                  foot = false;
                  return false;
                }
              }
            });
            if (foot == true) {
              this.$http
                .delete("api/orientation/yxbd/" + this.multipleTables)
                .then(res => {
                  if (res.data.code == 400) {
                    this.$message({
                      message: res.data.data.message,
                      type: "error"
                    });
                  } else {
                    this.$message({
                      message: res.data.message,
                      type: "删除成功"
                    });
                    this.currentPage = 1;
                    this.userlist();
                  }
                });
            }
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      }
    },
    release() {
      let foot = true;
      if (this.releaselist.length == 0) {
        this.$message({
          message: "请勾选再进行发布",
          type: "error"
        });
        return false;
      } else {
        this.releaselists.forEach(v => {
          if (foot) {
            if (v.zt == "1") {
              this.$message({
                message: "已发布的不能重新发布",
                type: "error"
              });
              foot = false;
            }
          }
        });
        if (foot == true) {
          this.$http
            .put("api/orientation/yxbd/cancel/" + this.releaselist + "/" + "1")
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: "发布成功",
                  type: "success"
                });
                this.currentPage = 1;
                this.userlist();
              }
            });
        }
      }
    },
    delrelease() {
      let foot = true;
      if (this.releaselist.length == 0) {
        this.$message({
          message: "请勾选再进行取消发布",
          type: "error"
        });
        return false;
      } else {
        this.releaselists.forEach(v => {
          if (foot) {
            if (v.zt == "0") {
              this.$message({
                message: "未发布的不能取消发布",
                type: "error"
              });
              foot = false;
            }
          }
        });
        if (foot == true) {
          this.$http
            .put("api/orientation/yxbd/cancel/" + this.releaselist + "/" + "0")
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: "取消发布成功",
                  type: "success"
                });
                this.currentPage = 1;
                this.userlist();
              }
            });
        }
      }
    },
    Checkdetails(id) {
      this.$store.state.addnotificlist = true;
      this.id = id;
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .get(
          "api/orientation/yxbd/list?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pagesize +
            "&query=" +
            this.search
        )
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160);
        this.pagesize = Math.floor(this.tableHeight / 57) - 1;
      })();
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1;
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.guidelines {
  width: 100%;
  .studentmessage_box {
    width: 100%;
    height: 60px;
    line-height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
