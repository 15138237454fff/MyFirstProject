<template>
  <div class="newstudentmessage">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="retrunnewstudent">返回列表</el-button>
    </div>
    <div class="newstudentmessage_box">

      <table align="center" border="1" cellspacing="0" cellpadding="0">
        <tr align="center">
          <td class="listcss" colspan="6" style="text-align:left;">|基本信息</td>
          <td rowspan="4">
            <img :src="datalist.zp" alt="" style="width:100px;height:100px;display: inline;" v-if="datalist.zp">
          </td>
        </tr>
        <tr align="center">
          <td class="listcss">学号</td>
          <td>{{datalist.xh}}</td>
          <td class="listcss">姓名</td>
          <td>{{datalist.xsxm}}</td>
          <td class="listcss">性别</td>
          <td>{{datalist.xbm}}</td>
        </tr>
        <tr align="center">
          <td class="listcss">年级</td>
          <td>{{datalist.sznj}}</td>
          <td class="listcss">学院</td>
          <td>{{datalist.xy}}</td>
          <td class="listcss">专业</td>
          <td>{{datalist.zy}}</td>
        </tr>
        <tr align="center">
          <td class="listcss">研究方向</td>
          <td>{{datalist.yjfx}}</td>
          <td class="listcss">学生类别</td>
          <td>{{datalist.xslbmc}}</td>
          <td class="listcss">培养层次</td>
          <td>{{datalist.pycc}}</td>
        </tr>
        <tr align="center">
          <td class="listcss">导师</td>
          <td>{{datalist.dsxm}}</td>
          <td class="listcss">学位证</td>
          <td style="color:#409eff" @click="open(datalist.xwz)">{{datalist.xwz}}</td>
          <td class="listcss">毕业证</td>
          <td colspan="2" style="color:#409eff" @click="openbyz(datalist.byz)">{{datalist.byz}}</td>
        </tr>
        <tr align="center">
          <td class="listcss">民族</td>
          <td>{{datalist.mz}}</td>
          <td class="listcss">证件类型</td>
          <td>{{datalist.sfzjlxmc}}</td>
          <td class="listcss">证件号码</td>
          <td colspan="2">{{datalist.sfzh}}</td>
        </tr>
        <tr style="margin-bottom:10px" align="center">
          <td class="listcss">联系电话</td>
          <td>{{datalist.dh}}</td>
          <td class="listcss">电子邮箱</td>
          <td>{{datalist.dzxx}}</td>
          <td class="listcss">家庭地址</td>
          <td colspan="2">{{datalist.jtzz}}</td>
        </tr>
      </table>
      <table border="1" cellspacing="0" cellpadding="0">
        <tr>
          <td class="listcss" colspan="8" style="text-align:left">| 家庭成员信息</td>
        </tr>
        <tr>
          <el-table :data="datalist.jtcy" border>
            <el-table-column prop="cyxm" label="姓名"></el-table-column>
            <el-table-column prop="gxmc" label="与本人关系"></el-table-column>
            <el-table-column prop="lxfs" label="联系方式"></el-table-column>
            <el-table-column prop="gzdw" label="工作单位"></el-table-column>
            <el-table-column prop="zymc" label="职业"></el-table-column>
          </el-table>
        </tr>
      </table>

    </div>
  </div>
  </div>
</template>

<script>
export default {
  name: 'newstudentmessage',
  props: {
    id: String
  },
  data() {
    return {
      xh: '',
      tableData: [],
      datalist: {}
    }
  },
  methods: {
    retrunnewstudent() {
      this.$store.state.newstudentmessages = false
    },
    open(val) {
      window.open(val)
    },
    openbyz(val) {
      window.open(val)
    },
    userlist() {
      this.$http.get('api/orientation/nic/' + this.xh).then(res => {
        if (res.data.code == 400 || !res.data.data) {
          this.$message({
            message: '数据异常，请刷新',
            type: 'error'
          })
        } else {
          this.datalist = res.data.data
        }
      })
    }
  },
  mounted() {
    this.xh = this.id
    this.userlist()
  }
}
</script>

<style scoped lang="scss">
.newstudentmessage {
  width: 100%;
  font-family: "Arial Normal", "Arial";
  font-weight: 400;
  font-style: normal;
  font-size: 13px;
  color: #333333;
  .top-title {
    width: 100%;
    height: 60px;
    line-height: 60px;
    border-bottom: 1px solid rgba(242, 242, 242, 1);
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .newstudentmessage_box {
    width: 90%;
    margin: 0 auto;
    padding-top: 20px;
  }
  table {
    // border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    // text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    // line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
}
</style>
