<template>
  <div class="dormitory">
    <div class="studentmessage_box">
      <el-row :gutter="20">
        <el-col :span="16">
          <div class="grid-content bg-purple">
            <el-input
              v-model="search"
              placeholder="请输入学号/姓名"
              style="width: 200px"
              @keyup.enter.native="handleFind"
              @clear="clearinput"
              clearable
              suffix-icon="el-icon-search"
            >
            </el-input>
            <el-button @click="handleFind" style="margin-left:5px"
              >查询</el-button
            >
            <template v-if="optionsadd">
              <el-select
                v-model="upmodel"
                placeholder="请选择校区"
                
                filterable
                @change="changeselect"
              >
                <el-option
                  v-for="(item, $index) in optionsadd"
                  :key="$index"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </template>
            <template v-if="optionsadds">
              <el-select
                v-model="upmodels"
                placeholder="请选择楼栋"
                
                filterable
                @change="changeselectupmodels"
              >
                <el-option
                  v-for="(item, $index) in optionsadds"
                  :key="$index"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </template>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-right">
            <el-upload
              class="upload-demo"
              :action="upload"
              :data="uploadData"
              :limit="1"
              :before-upload="handlebefore"
              :on-success="handleSuccess"
              ref="uploadcsv"
              style="float:right;margin-left:15px"
            >
              <el-button
                type="primary"
                v-if="$btnAuthorityTest('dormitory:import')"
                >批量导入</el-button
              >
            </el-upload>
            <el-button
              type="primary"
              @click="excel"
              v-if="$btnAuthorityTest('dormitory:export')"
              >下载模板</el-button
            >
          </div>
        </el-col>
      </el-row>
    </div>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      ref="multipleTable"
      style="width: 100%;"
      v-loading="loading2"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="tableHeaderColor"
    >
      <el-table-column type="index" label="序号" width="100"></el-table-column>
      <el-table-column prop="xh" label="学号"></el-table-column>
      <el-table-column prop="xsxm" label="姓名"></el-table-column>
      <el-table-column prop="pycc" label="培养层次"></el-table-column>
      <el-table-column prop="xy" label="学院"></el-table-column>
      <el-table-column prop="zy" label="专业"></el-table-column>
      <el-table-column prop="xq" label="校区"></el-table-column>
      <el-table-column prop="ld" label="楼栋"></el-table-column>
      <el-table-column prop="ss" label="宿舍"></el-table-column>
      <el-table-column prop="cw" label="床位"></el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page.sync="currentPage"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="pagesize"
        class="import"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="changePage"
        :total="total"
        @size-change="sizeChange"
        background
      ></el-pagination>
    </div>
  </div>
</template>

<script>
import { constants } from "fs";
export default {
  name: "dormitory",
  data() {
    return {
      upload: "/api/orientation/dac/import",
      uploadData: {
        file: ""
      },
      csvfile: "",
      search: "",
      upmodel: null,
      upmodels: null,
      optionsadd: [],
      optionsadds: [],
      tableHeight: null,
      loading2: false,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 5,
      currentPage: 1,
      total: 0,
      tableData: []
    };
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    handlebefore(file) {
      this.uploadData.file = file.name;
    },
    //csv文件上传成功
    handleSuccess(file, fileList) {
      if (file.code == 400) {
        this.$message({
          message: file.message,
          type: "error"
        });
        this.$refs.uploadcsv.clearFiles();
      } else {
        this.$message({
          message: file.message,
          type: "success"
        });
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles();
        }, 1000);
      }
    },
    clearinput() {
      this.search = "";
      this.currentPage = 1;
      this.userlist();
    },
    changeselect() {
      setTimeout(() => {
        this.currentPage = 1;
        this.userlist();
      }, 1000);
      if (this.optionsadd.length == 0) {
        this.optionsadds = [];
      } else {
        this.optionsadd.map(v => {
          if (this.upmodel === v.value) {
            this.optionsadds = v.children;
          }
        });
      }
    },
    changeselectupmodels() {
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    excel() {
      window.location.href = "/api/orientation/dac/down";
    },
    excelxiazai() {},
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    semesters() {
      this.$http.get("api/orientation/dac/select").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          console.log(res.data.data);
          this.optionsadd = res.data.data;
        }
      });
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/orientation/dac/list", {
          campus: this.upmodel,
          ban: this.upmodels,
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.search
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.semesters();
    this.userlist();
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160);
        this.pagesize = Math.floor(this.tableHeight / 57) - 1;
      })();
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1;
  }
};
</script>

<style scoped lang="scss">
.dormitory {
  width: 100%;
  .studentmessage_box {
    width: 100%;
    height: 60px;
    line-height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    .bg-right {
      text-align: right;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
