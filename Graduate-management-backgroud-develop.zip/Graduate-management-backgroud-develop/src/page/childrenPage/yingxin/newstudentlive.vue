<template>
  <div class="newstudentmessage">
    <div class="top-title">
      请扫描新生的报到二维码完成新生报到注册！
      <el-button @click="retrunnewstudent" style="float:right;margin-top:10px;margin-right:30px">身份证报到</el-button>
    </div>
    <div class="left">
      <table>
        <tr>
          <td class="listcss" colspan="6" style="text-align:left">|基本信息</td>
          <td rowspan="4">
            <img :src="datalist.zp" alt="" style="width:100px;height:100px;display: inline;">
          </td>
        </tr>
        <tr>
          <td class="listcss">学号</td>
          <td>{{datalist.xh}}</td>
          <td class="listcss">姓名</td>
          <td>{{datalist.xsxm}}</td>
          <td class="listcss">性别</td>
          <td>{{datalist.xbm}}</td>
        </tr>
        <tr>
          <td class="listcss">年级</td>
          <td>{{datalist.sznj}}</td>
          <td class="listcss">学院</td>
          <td>{{datalist.xy}}</td>
          <td class="listcss">专业</td>
          <td>{{datalist.zy}}</td>
        </tr>
        <tr>
          <td class="listcss">研究方向</td>
          <td>{{datalist.yjfx}}</td>
          <td class="listcss">学生类别</td>
          <td>{{datalist.xslbmc}}</td>
          <td class="listcss">培养层次</td>
          <td>{{datalist.pycc}}</td>
        </tr>
        <tr>
          <td class="listcss">导师</td>
          <td>{{datalist.dsxm}}</td>
          <td class="listcss">学位证</td>
          <td>{{datalist.xwz}}</td>
          <td class="listcss">毕业证</td>
          <td colspan="2">{{datalist.byz}}</td>
        </tr>
        <tr>
          <td class="listcss">民族</td>
          <td>{{datalist.mz}}</td>
          <td class="listcss">证件类型</td>
          <td>{{datalist.sfzjlxmc}}</td>
          <td class="listcss">证件号码</td>
          <td colspan="2">{{datalist.sfzh}}</td>
        </tr>
        <tr style="margin-bottom:10px">
          <td class="listcss">联系电话</td>
          <td>{{datalist.dh}}</td>
          <td class="listcss">电子邮箱</td>
          <td>{{datalist.dzxx}}</td>
          <td class="listcss">家庭地址</td>
          <td colspan="2">{{datalist.jtzz}}</td>
        </tr>
      </table>
      <table>
        <tr>
          <td class="listcss" colspan="4" style="text-align:left">|缴费信息</td>
        </tr>
        <tr>
          <td class="listcss">应缴费用</td>
          <td>{{datalist.yjfy}}</td>
          <td class="listcss">实缴费用</td>
          <td>{{datalist.sjfy}}</td>
        </tr>
      </table>
      <table>
        <tr>
          <td class="listcss" colspan="8" style="text-align:left">|宿舍信息</td>
        </tr>
        <tr>
          <td class="listcss">校区</td>
          <td>{{datalist.xq}}</td>
          <td class="listcss">楼栋</td>
          <td>{{datalist.ld}}</td>
          <td class="listcss">宿舍</td>
          <td>{{datalist.ss}}</td>
          <td class="listcss">床位</td>
          <td>{{datalist.cw}}</td>
        </tr>
      </table>
      <el-button @click="retrunnewstudents" style="width:100%;margin-top:10px" type="primary">确认</el-button>
    </div>
    <div class="newleft">
      <p class="newleft_p1">{{objlist.yxsmc}}</p>
      <p class="newleft_p2">{{objlist.currentYear}} 迎新报到情况</p>
      <div class="newleft_p3">
        <li class="percent-list" v-for="(item, index) in percentData" :key="index">
          <div class="wrap">
            <!--大于180，则class=clip-auto circle，否则：circle-->
            <div :class="item.value > 50 ? 'clip-auto circle' : 'circle'">
              <!--度数为：当前进度*3.6-->
              <div class="percent left" :style="`-webkit-transform:rotate(${360*(item.value/100)}deg);`"></div>
              <!--大于180，则class=percent right，否则为percent right wth0-->
              <div :class="item.value > 50 ? 'percent right' : 'percent right wth0'"></div>
            </div>
            <div class="inside-round">{{ item.data + '%' }}</div>
          </div>
        </li>
      </div>
      <p class="newleft_p4" style="font-size:18px">应报到人数：{{objlist.headcount}}</p>
      <p class="newleft_p5" style="font-size:18px">已报到人数：<span style="color:#409eff;">{{objlist.arrived}}</span></p>
    </div>
    <el-dialog title="身份证报到" :visible.sync="centerDialogVisible" width="30%" center>
      <el-form :model="ruleForm" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="身份证报到" prop="name">
          <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="srue">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "newstudentmessage",
  props: {
    id: String
  },
  data() {
    return {
      ruleForm: {
        name: ""
      },
      centerDialogVisible: false,
      percentData: [
        {
          number: "123213",
          data: "",
          value: "60"
        }
      ],
      tableData: [],
      datalist: {},
      objlist: {},
      keycode: "",
      lastTime: "",
      lastCode: "",
      code: ""
    };
  },
  methods: {
    cancel() {
      this.centerDialogVisible = false;
      this.ruleForm.name = "";
    },
    srue() {
      this.$http
        .get("api/orientation/regist/" + this.ruleForm.name)
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.datalist = res.data.data;
            this.centerDialogVisible = false;
          }
        });
    },
    retrunnewstudents() {
      if (!this.datalist.xh) {
        this.$message({
          message: "当前数据异常，请稍后再试",
          type: "error"
        });
        return false;
      }
      this.$http
        .get("api/orientation/regist/report" + this.datalist.xh)
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
            this.datalist = {};
          } else {
            this.datalist = {};
          }
        });
    },
    retrunnewstudent() {
      this.centerDialogVisible = true;
    },
    userlist() {
      var keycode = "";
      var lastTime = null,
        nextTime;
      var lastCode = null,
        nextCode;
      this.$http.get("api/orientation/regist/info").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          if (!res.data.data) {
            this.$message({
              message: "当前数据为空，请进行新生报到二维码操作",
              type: "error"
            });
          } else {
            this.objlist = res.data.data;
            this.percentData[0].value =
              (this.objlist.headcount + this.objlist.arrived) /
              this.objlist.arrived;
            this.percentData[0].data = `报到率${(this.objlist.headcount +
              this.objlist.arrived) /
              this.objlist.arrived}`;
          }
        }
      });
    }
  },
  mounted() {
    this.userlist();
  },
  created() {
    window.onload = e => {
      document.onkeydown = e => {
        let nextCode,
          nextTime = "";
        let lastTime = this.lastTime;
        let code = this.code; //扫描枪拿到的字符长度加上键盘编码的一个字符长度
        if (window.event) {
          // IE
          nextCode = e.keyCode;
        } else if (e.which) {
          // Netscape/Firefox/Opera
          nextCode = e.which;
        }
        nextTime = new Date().getTime();
        //字母上方 数字键0-9 对应键码值 48-57; 数字键盘 数字键0-9 对应键码值 96-105
        if (
          (nextCode >= 48 && nextCode <= 57) ||
          (nextCode >= 96 && nextCode <= 105)
        ) {
          let codes = {
            "48": 48,
            "49": 49,
            "50": 50,
            "51": 51,
            "52": 52,
            "53": 53,
            "54": 54,
            "55": 55,
            "56": 56,
            "57": 57,
            "96": 48,
            "97": 49,
            "98": 50,
            "99": 51,
            "100": 52,
            "101": 53,
            "102": 54,
            "103": 55,
            "104": 56,
            "105": 57
          };
          nextCode = codes[nextCode];
          nextTime = new Date().getTime();
        }
        // 第二次输入延迟两秒，删除之前的数据重新计算
        if (nextTime && lastTime && nextTime - lastTime > 2000) {
          code = String.fromCharCode(nextCode);
        } else {
          code += String.fromCharCode(nextCode);
        }
        console.log(code);
        // 保存数据
        this.nextCode = nextCode;
        this.lastTime = nextTime;
        this.code = code;
        // 键入Enter
        if (e.which == 13) {
          if (this.code.length - 1 == 18) {
            this.$http.get("api/orientation/regist/" + this.code).then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              } else {
                this.datalist = res.data.data;
              }
            });
          }
          this.code = "";
          return false;
        }
      };
    };
  }
};
</script>

<style scoped lang="scss">
.newstudentmessage {
  width: 100%;
  font-family: "Arial Normal", "Arial";
  font-weight: 400;
  font-style: normal;
  font-size: 14px;
  color: #333333;
  .top-title {
    width: 100%;
    height: 60px;
    line-height: 60px;
    border-bottom: 1px solid rgba(242, 242, 242, 1);
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .left {
    width: 80%;
    float: left;
    height: 100%;
  }
  .newleft {
    float: right;
    height: 620px;
    width: 18%;
    border: 1px solid rgba(228, 228, 228, 1);
    text-align: center;
    padding-top: 30px;
    .newleft_p1 {
      font-size: 32px;
      margin-bottom: 15px;
    }
    .newleft_p2 {
      font-size: 24px;
      margin-bottom: 45px;
    }
    .newleft_p3 {
      margin-bottom: 80px;
      .percent-list {
        .wrap {
          background-color: #ff2000;
          position: relative;
          width: 150px;
          height: 150px;
          border-radius: 50%;
          margin: 0 auto;
          .circle {
            box-sizing: border-box;
            border: 1px solid #ffffff;
            clip: rect(0, 150px, 150px, 75px);
            position: absolute;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            .percent {
              box-sizing: border-box;
              top: -1px;
              left: -1px;
              position: absolute;
              width: 150px;
              height: 150px;
              border-radius: 50%;
            }
            .left {
              border: 20px solid rgb(136, 199, 255);
              clip: rect(0, 75px, 150px, 0);
            }
            .right {
              border: 20px solid rgb(136, 199, 255);
              clip: rect(0, 150px, 150px, 75px);
            }
            .wth0 {
              width: 0;
            }
          }
          .clip-auto {
            clip: rect(auto, auto, auto, auto);
          }
          .inside-round {
            position: absolute;
            width: 110px;
            height: 110px;
            background: #fff;
            border-radius: 50%;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            margin: auto;
            text-align: center;
            line-height: 110px;
          }
        }
      }
    }
  }
  table {
    // border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    // text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    // line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
      height: 48px;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      line-height: 48px;
      padding-left: 5px;
      text-align: center;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
}
</style>
