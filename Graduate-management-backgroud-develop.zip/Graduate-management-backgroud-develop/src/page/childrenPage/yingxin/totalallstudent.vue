<template>
  <div class="resultssummary">
    <h6>2019级新生入学报到统计</h6>
    <div class="studentmessage_boxs">
      <li>
        新生总人数：<span style="color:#1890FF">{{
          beforeRate.nonArrival + beforeRate.arrived
        }}</span>
      </li>
      <li>
        报道人数：<span style="color:#1890FF">{{ beforeRate.arrived }}</span>
      </li>
      <li>
        报到率：<span style="color:#1890FF">{{ beforeRate.yieldRate }}%</span>
      </li>
      <li>
        未报到人数：<span style="color:#FF0000">{{
          beforeRate.nonArrival
        }}</span>
      </li>
      <li style="border-right:none">
        未报到率：<span style="color:#FF0000"
          >{{ beforeRate.beforeRate }}%</span
        >
      </li>
    </div>
    <div class="studentmessage_box">
      <template v-if="optionsadd">
        <el-select
          v-model="upmodel"
          placeholder="请选择学院"
          
          filterable
          @change="changeselect"
        >
          <el-option
            v-for="(item, $index) in optionsadd"
            :key="$index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </template>
      <template v-if="optionsadds">
        <el-select
          v-model="upmodels"
          placeholder="请选择专业"
          
          filterable
          @change="changeselectupmodels"
        >
          <el-option
            v-for="(item, $index) in optionsadds"
            :key="$index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </template>
      <el-button
        type="primary"
        style="float:right;margin-top:10px;margin-right:20px"
        @click="excel"
        v-if="$btnAuthorityTest('totalallstudent:export')"
        >导出</el-button
      >
    </div>
    <el-table
      :data="tableData3"
      style="width: 100%"
      tooltip-effect="dark"
      border
      ref="multipleTable"
      :height="tableHeight"
      v-loading="loading2"
      @selection-change="handleSelectionChange"
    >
      <el-table-column prop="xy" label="学院"> </el-table-column>
      <el-table-column prop="zy" label="专业"> </el-table-column>
      <el-table-column label="全日制报到情况">
        <el-table-column prop="qrzzrs" label="全日制总人数"> </el-table-column>
        <el-table-column label="全日制报到人数" prop="qrz"> </el-table-column>
      </el-table-column>
      <el-table-column label="非全日制报到情况">
        <el-table-column prop="fqrzzrs" label="非全日制总人数">
        </el-table-column>
        <el-table-column label="非全日制报到人数" prop="fqrz">
        </el-table-column>
      </el-table-column>
      <el-table-column label="博士报到情况">
        <el-table-column prop="bszrs" label="博士总人数"> </el-table-column>
        <el-table-column label="博士报到人数" prop="bs"> </el-table-column>
      </el-table-column>
      <el-table-column label="硕士报到情况">
        <el-table-column prop="sszrs" label="硕士总人数"> </el-table-column>
        <el-table-column label="硕士报到人数" prop="ss"> </el-table-column>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page.sync="currentPage"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="pagesize"
        class="import"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="changePage"
        :total="total"
        @size-change="sizeChange"
        background
      ></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "Financialpayment",
  data() {
    return {
      search: "",
      upmodel: undefined,
      upmodels: "",
      upmodeloptions: "",
      upmodelclass: "",
      optionsadd: [],
      optionsadds: [],
      options: [],
      optionsclass: [],
      tableHeight: null,
      clientHeight: 0,
      loading2: false,
      offsetTop: 0,
      pagesize: 5,
      currentPage: 1,
      total: 0,
      tableData: [
        {
          id: 1
        }
      ],
      tableData3: [],
      beforeRate: {}
    };
  },
  methods: {
    changeselectupmodels() {
      this.currentPage = 1;
      this.userlist();
    },
    changeselect() {
      if (this.optionsadd.length == 0) {
        this.optionsadds = [];
      } else {
        this.optionsadd.map(v => {
          if (this.upmodel === v.value) {
            this.optionsadds = v.children;
          }
        });
      }
      setTimeout(() => {
        this.currentPage = 1;
        this.userlist();
      }, 1000);
    },
    clearinput() {
      this.search = "";
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    excel() {},
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    semesters() {
      this.$http
        .get("api/cultivate/sac/select/academic")
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.options = res.data.data;
          }
        })
        .catch(function(err) {
          console.log(err);
        });
      this.$http
        .get("api/system/dict/select/college")
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            console.log(res.data.data);
            this.optionsadd = res.data.data;
          }
        })
        .catch(function(err) {
          console.log(err);
        });
      this.$http
        .get("api/cultivate/sac/select/grade")
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            console.log(res.data.data);
            this.optionsclass = res.data.data;
          }
        })
        .catch(function(err) {
          console.log(err);
        });
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/orientation/nsc/list", {
          collegeCode: this.upmodel,
          majorCode: this.upmodels,
          pageNum: this.currentPage,
          pageSize: this.pagesize
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData3 = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    list() {
      this.$http.get("api/orientation/nsc/info").then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          console.log(res);
          this.beforeRate = res.data.data;
        }
      });
    }
  },
  created() {
    this.userlist();
    this.list();
  },
  mounted() {
    this.semesters();
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160);
        this.pagesize = Math.floor(this.tableHeight / 57) - 1;
      })();
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1;
  }
};
</script>

<style scoped lang="scss">
.resultssummary {
  width: 100%;
  overflow: hidden;
  h6 {
    line-height: 60px;
    text-align: center;
    font-size: 22px;
  }
  .studentmessage_box {
    width: 100%;
    height: 60px;
    background: #f2f2f2;
    line-height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
  }
  .studentmessage_boxs {
    width: 100%;
    height: 60px;
    background: #f2f2f2;
    // line-height: 60px;
    // padding-left: 10px;
    margin-bottom: 10px;
    display: flex;
    padding: 10px 0;
    li {
      flex: 1;
      text-align: center;
      border-right: 1px #cccccc dashed;
      line-height: 60px;
      -webkit-box-align: center;
      -moz-box-align: center;
      /*混合版本语法*/
      -ms-flex-align: center;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
