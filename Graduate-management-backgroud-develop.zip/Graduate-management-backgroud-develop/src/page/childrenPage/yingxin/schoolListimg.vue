<template>
  <div class="schoolListimg">
    <div class="imgbox">
      <header>
        <div class="left">
          请在已上传照片中选取校园风采展示并发布（已选择
          <span style="color:#46A6FF">{{ count }}</span> 张）
        </div>
        <div class="right">
          <el-button type="danger" @click="cancel()" style="background:#fa5555" v-if="$btnAuthorityTest('schoolListimg:delete')">删除</el-button>
          <template v-if="$btnAuthorityTest('schoolListimg:publish')">
            <el-button type="primary" @click="release">发布</el-button>
            <el-button type="primary" @click="cancelRelease">取消发布</el-button>
          </template>
        </div>
      </header>
      <div class="imgup">
        <el-upload class="upload-demo" drag :action="upload" :headers="myHeaders" :data="uploadData" :limit="5" :before-upload="handlebefore" :on-success="handleSuccess" ref="uploadcsv" accept="image/jpeg,image/png,image/gif">
          <i class="el-icon-plus uploadicon"></i>
          <div class="el-upload__text">支持常规图片格式，推荐16×9规格</div>
          <div class="el-upload__text">最大支持图片大为2M</div>
        </el-upload>
        <div class="uploadlist" v-for="(item, index) in fileList" :key="index">
          <div class="uploadlist_div">
            <img :src="item.url" alt="" class="img" />
            <img src="./images/未发布.png" alt="" class="spanLIst" v-if="item.zt == 0" />
            <img src="./images/已发布.png" alt="" class="spanLIst" v-else />
            <el-checkbox v-model="item.checked" @change="checkupload(item, index)" class="check"></el-checkbox>
            <input type="text" v-model="item.fileName" placeholder="请输入内容" maxlength="20" class="input_list" v-if="item.zt == 0" @keyup.enter="loginCLick(item)" />
            <input type="text" v-model="item.fileName" placeholder="请输入内容" maxlength="20" class="input_list" style="border:none" v-if="item.zt == 1" :readonly="item.zt == 1" @keyup.enter="loginCLick(item)" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "schoolListimg",
  data() {
    return {
      count: 0,
      upload: "/api/orientation/csc",
      uploadData: {
        file: ""
      },
      fileList: [],
      myHeaders: {
        userToken: this.$stores.state.token
      },
      checked: false,
      cancelId: []
    };
  },
  mounted() {
    this.imgurl();
  },
  methods: {
    loginCLick(val) {
      console.log(val);
      this.$http
        .put(`api/orientation/csc/update/${val.id}?fileName=${val.fileName}`)
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          } else {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.imgurl();
          }
        });
    },
    commonid() {
      this.cancelId = [];
      let indexof = this.fileList.filter(item => item.checked == true);
      indexof.map(v => {
        this.cancelId.push(v.id);
      });
    },
    release() {
      // 发布--已发布的不能重新发布
      let flag = true;
      this.commonid();
      if (this.fileList.filter(item => item.checked == true).length == 0) {
        this.$message({
          message: "请勾选在进行发布",
          type: "error"
        });
        return false;
      } else {
        this.cancelId.map(v => {
          const i = this.fileList.find(item => item.id === v);
          if (flag) {
            if (i.zt == 1) {
              this.$message({
                message: "已发布的不能重新发布",
                type: "error"
              });
              flag = false;
            }
          }
        });
        if (flag == true) {
          this.$http.put("api/orientation/csc", this.cancelId).then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.message,
                type: "error"
              });
            } else {
              this.$message({
                message: res.data.message,
                type: "success"
              });
              this.imgurl();
            }
          });
        }
      }
    },
    cancelRelease() {
      // 取消发布--未发布不能再进行取消发布
      let flag = true;
      this.commonid();
      if (this.fileList.filter(item => item.checked == true).length == 0) {
        this.$message({
          message: "请勾选在进行取消发布",
          type: "error"
        });
        return false;
      } else {
        this.cancelId.map(v => {
          const i = this.fileList.find(item => item.id === v);
          if (flag) {
            if (i.zt == 0) {
              this.$message({
                message: "未发布不能再进行取消发布",
                type: "error"
              });
              flag = false;
            }
          }
        });
        if (flag == true) {
          this.$http
            .put("api/orientation/csc/unpublish", this.cancelId)
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: "取消发布成功",
                  type: "success"
                });
                this.imgurl();
              }
            });
        }
      }
    },
    cancel() {
      // 删除---已发布不能再进行删除
      let flag = true;
      this.commonid();
      if (this.fileList.filter(item => item.checked == true).length == 0) {
        this.$message({
          message: "请勾选在进行删除",
          type: "error"
        });
        return false;
      } else {
        this.cancelId.map(v => {
          const i = this.fileList.find(item => item.id === v);
          if (flag) {
            if (i.zt == 1) {
              this.$message({
                message: "已发布不能再进行删除",
                type: "error"
              });
              flag = false;
            }
          }
        });
        if (flag == true) {
          this.$http
            .delete("api/orientation/csc", {
              data: this.cancelId
            })
            .then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.imgurl();
              }
            });
        }
      }
    },
    handlebefore(file) {
      this.uploadData.file = file.name;
    },
    checkupload(val, index) {
      this.count = this.fileList.filter(item => item.checked == true).length; // 已选择张数
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      if (file.code == 400) {
        this.$message({
          message: "上传失败，请重新上传",
          type: "error"
        });
        this.$refs.uploadcsv.clearFiles(); // 清除upload
      } else {
        this.$message({
          message: "上传成功",
          type: "success"
        });
        this.imgurl();
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles();
        }, 500);
      }
    },
    imgurl() {
      this.$http.get("api/orientation/csc").then(res => {
        // 验证表格数据是否是数组类型和为空
        if (!Array.isArray(res.data.data) || !res.data.data) {
          this.$message.error({
            message: "数据验证失败请刷新"
          });
        } else {
          this.fileList = res.data.data; // 图片列表
          this.fileList.map(v => {
            this.$set(v, "checked", false);
          }); // checked属性
          this.count = this.fileList.filter(
            item => item.checked == true
          ).length; // 已选择张数
        }
      });
    }
  }
};
</script>

<style scoped lang="scss">
.schoolListimg {
  width: 100%;
  padding-top: 20px;
  .imgbox {
    width: 100%;
    height: 700px;
    border: 1px solid rgba(204, 204, 204, 1);
    margin: 0 auto;
    header {
      padding: 10px 15px 10px 30px;
      font-size: 16px;
      color: #767676;
      display: flex;
      line-height: 38px;
      background: #f2f2f2;
      border-bottom: rgba(204, 204, 204, 1) 1px solid;
      .left {
        flex: 1;
      }
      .right {
        flex: 1;
        text-align: right;
      }
    }
    .imgup {
      padding: 50px;
      .uploadicon {
        font-size: 67px;
        color: #c0c4cc;
        margin: 40px 0 16px;
        line-height: 50px;
      }
      .upload-demo {
        width: 220px;
        height: 180px;
        display: inline-block;
        float: left;
        margin-right: 30px;
        margin-bottom: 20px;
        /deep/ .el-upload-dragger {
          width: 220px;
          padding: 10px;
        }
        /deep/ .el-upload__text {
          font-size: 12px;
        }
      }
      .uploadlist {
        display: inline-block;
        width: 220px;
        height: 180px;
        float: left;
        margin-right: 30px;
        margin-bottom: 20px;
        text-align: center;
        position: relative;
        .spanLIst {
          position: absolute;
          top: 0px;
          left: 0px;
          width: 75px;
          height: 30px;
        }
        .check {
          position: absolute;
          bottom: 5px;
          left: 0px;
        }
        .uploadlist_div {
          width: 100%;
          .img {
            width: 100%;
            height: 140px;
          }
          .input_list {
            -webkit-appearance: none;
            background-color: #fff;
            background-image: none;
            border-radius: 4px;
            border: 1px solid #dcdfe6;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            color: #333333;
            display: inline-block;
            font-size: inherit;
            height: 28px;
            line-height: 28px;
            outline: 0;
            padding: 0 15px;
            -webkit-transition: border-color 0.2s
              cubic-bezier(0.645, 0.045, 0.355, 1);
            transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
            width: 92%;
            font-size: 14px;
            margin-left: 20px;
            border-color: #b4bbc5;
          }
        }
      }
    }
  }
  .el-input__inner {
    line-height: 32px !important;
  }
}
</style>
<style scoped>
.el-upload-dragger {
  width: 220px !important;
}
</style>
