<template>
  <div class="addnotific">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
      <el-button type="primary" style="float: right; margin: 10px 10px 0 0;" @click="saveData" :disabled="isShow">保 存</el-button>
    </div>
    <el-form ref="form" :model="form" label-width="100px">
      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple-dark">
            <el-form-item label="标题：" :required="true">
              <el-input v-model="form.title" :disabled="disable"></el-input>
            </el-form-item>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple-dark">
            <el-form-item label="正文：" :required="true">
              <quill-editor ref="myTextEditor" v-model="content" :options="editorOption" @blur="onEditorBlur($event)" @focus="onEditorFocus($event)" @ready="onEditorReady($event)" :disabled="disable">
              </quill-editor>
            </el-form-item>
          </div>
        </el-col>
      </el-row>
      <div style="height:100px"></div>
      <el-row>
        <el-col :span="24">
          <el-form-item label="相关附件：">
            <el-upload class="upload-demo" :action='upload' :disabled="disable" :data="uploadData" :limit="5" :before-upload="handlebefore" :on-success="handleSuccess" ref="uploadcsv" accept="">
              <el-button style="border-color:rgba(24, 144, 255, 1);color:#1890FF;width:350px" :disabled="disable">点击上传</el-button><span style="margin-left:20px;color:red" slot="tip" class="el-upload__tip">请上传10M以内的附件</span>
            </el-upload>
            <div>
              <li v-for="(item,index) in  fileList"><i class="el-icon-document"></i><span style="margin-right:20px;margin-left:10px" @click="open(item.url)">{{item.fileName}}</span><i class="el-icon-close" @click="cancelupload(index,item.filename)" v-if="!disable"></i></li>
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { quillEditor } from 'vue-quill-editor';
export default {
  name: 'addnotificlist',
  props: {
    id: Number
  },
  data() {
    return {
      upload: '/api/system/notice/uploadFile',
      uploadData: {
        file: ''
      },
      fileList: [],
      form: {
        sendPeople: 0,
        choose: [],
        department: 1,
        title: ''
      },
      content: '',
      chooseList: [], // 选项列表
      departmentList: [
        {
          value: 1,
          label: '全部用户'
        },
        {
          value: 2,
          label: '按角色发送'
        },
        {
          value: 3,
          label: '按部门发送'
        }
      ], // 选项列表,
      isShow: false,
      editorOption: {
        theme: 'snow',
        boundary: document.body,
        modules: {
          toolbar: [
            ['bold', 'italic', 'underline', 'strike'],
            ['blockquote', 'code-block'],
            [{ header: 1 }, { header: 2 }],
            [{ list: 'ordered' }, { list: 'bullet' }],
            [{ script: 'sub' }, { script: 'super' }],
            [{ indent: '-1' }, { indent: '+1' }],
            [{ direction: 'rtl' }],
            [{ size: ['small', false, 'large', 'huge'] }],
            [{ header: [1, 2, 3, 4, 5, 6, false] }],
            [{ color: ['red', 'blue', 'green'] }, { background: [] }],
            [{ font: [] }],
            [{ align: [] }],
            ['clean'],
            ['link', 'image', 'video']
          ]
        },
        placeholder: 'Insert text here ...',
        readOnly: false
      },
      disable: false
    }
  },
  methods: {
    saveData() {
      if (this.form.title == '') {
        this.$message({
          message: '标题为必填项',
          type: 'error'
        })
        return false
      }
      if (this.content == '') {
        this.$message({
          message: '正文为必填项',
          type: 'error'
        })
        return false
      }
      const arr = []
      let objlist = {}
      let filelist = JSON.parse(JSON.stringify(this.fileList))
      if (filelist.length > 0) {
        filelist.map(v => {
          objlist = {
            fileName: v.fileName,
            url: v.url
          }
          arr.push(objlist)
        })
      }
      const obj = {
        bt: this.form.title,
        fj: arr,
        zw: this.content,
        id: this.$route.query.id
      }
      this.$http.post('api/orientation/yxbd/update', obj).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: '修改成功',
            type: 'success'
          })
          this.$store.state.addnotificlist = false
        } else {
          this.$message.error({ message: res.data.message })
        }
      })
    }, // 保存
    changeHandle(value) {
      this.chooseList = []
      this.form.choose = []
      this.$http.get('api/system/notice/selectbyfsdx/' + value).then(res => {
        if (res.data.data != []) {
          res.data.data.map((item, index) => {
            if (item.name != undefined) {
              const obj = {
                value: item.id,
                label: item.name
              }
              this.chooseList.push(obj)
            } else if (item.dwmc != undefined) {
              const obj = {
                value: item.id,
                label: item.dwmc
              }
              this.chooseList.push(obj)
            }
          })
        }
      })
    }, // 切换发送对象
    cancelupload(index, id) {
      this.fileList.splice(
        this.fileList.findIndex(item => item.fileName === id),
        1
      )
    },
    handleRemove(file, fileList) {},
    handlePreview(file) {},
    handlebefore(file) {
      this.uploadData.file = file.name
    },
    open(val) {
      window.open(val)
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      this.fileList.push(file.data)
      if (file.code == 400) {
        this.$message({
          message: '上传失败，请重新上传',
          type: 'error'
        })
        this.$refs.uploadcsv.clearFiles()
      } else {
        this.$message({
          message: '上传成功',
          type: 'success'
        })
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles()
        }, 500)
      }
    },
    exitList() {
      this.$store.state.addnotificlist = false
    },
    onEditorBlur(editor) {},
    onEditorFocus(editor) {},
    onEditorReady(editor) {},
    onEditorChange({ editor, html, text }) {
      this.content = html
    },
    userlist() {
      this.$http.get('api/orientation/yxbd/info?id=' + this.id).then(res => {
        if (res.data.code == 200) {
          const obj = {}
          this.form.title = res.data.data.bt
          this.content = res.data.data.zw
          this.fileList = res.data.data.fj
          if (res.data.data.zt == '0') {
            this.isShow = false
            this.disable = false
          } else {
            this.isShow = true
            this.disable = true
          }
        } else {
          this.$message.error({ message: res.data.message })
        }
      })
    }
  },
  mounted() {
    this.userlist()
  },
  comments: {
    quillEditor
  }
}
</script>

<style scoped>
.quill-editor {
  height: 200px;
}
.fl {
  font-size: 14px;
  margin-left: 30px;
  color: #606266;
  float: left;
}
.list:after {
  clear: both;
}
.list {
  height: 300px;
}
.top-title {
  width: 100%;
  height: 60px;
  background: #f2f2f2;
  line-height: 60px;
}
.diyButton {
  background: none;
  border: none;
  color: #2779e3;
}
.addnotificlist /deep/ .el-form {
  margin-top: 15px;
}
</style>
