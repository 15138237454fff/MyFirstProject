<template>
  <div class="jccs">
    <el-form :inline="true" :model="formInline" class="demo-form-inline">
      <el-form-item label="设置迎新年度：">
        <!-- <el-select v-model="formInline.region" placeholder="请选择">
          <el-option :label="item.label" :value="item.value" v-for="(item,index) in time" :key="index"></el-option>
        </el-select> -->
        <span>{{formInline.region}}</span>
      </el-form-item>
      <!-- <el-form-item>
        <el-button type="primary" @click="onSubmit">保存</el-button>
      </el-form-item> -->
    </el-form>
  </div>
</template>

<script>
export default {
  name: "jccs",
  data() {
    return {
      time: [],
      formInline: {
        region: ""
      }
    };
  },
  mounted() {
    var date = new Date();
    var year = date.getFullYear();
    this.formInline.region = `${year}年`;
    this.time.push({
      value: `${year}年`,
      label: `${year}年`
    });
  },
  methods: {
    onSubmit() {}
  }
};
</script>

<style scoped lang="scss">
.jccs {
  width: 100%;
  height: calc(100% - 70px);
  display: table;
  .demo-form-inline {
    height: 50px;
    display: table-cell;
    vertical-align: middle;
    text-align: center;
  }
}
</style>
