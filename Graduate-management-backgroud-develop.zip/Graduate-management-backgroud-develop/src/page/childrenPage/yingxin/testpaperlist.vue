<template>
  <div class="testpaper">
    <div class="studentmessage_box">
      <div class="top-title">
        <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
      </div>
    </div>
    <template v-if="list.length!==0">
      <div class="testpaper_form" v-for="(all,$index) in list">
        <div class="testpaper_form_left">
          <div style="margin-bottom:20px;">
            <img src="./images/error.png" alt="" style="width:24px;" v-if="all.jg =='0'">
            <img src="./images/right.png" alt="" style="width:24px" v-if="all.jg=='1'">
            <el-button type="text" style="color:#000;font-size:14px;">
              {{$index + 1}}.(<span v-if="all.lx =='0'">单选</span><span v-if="all.lx =='1'">多选</span>)
            </el-button>
            <el-input v-model="all.tm" style="width:725px;" disabled>
            </el-input>
          </div>
          <ul class="testpaper_form_left_ul">
            <li class="li_right" v-for="(second,$index1) in  all.nrList" :key="$index1">
              <el-radio v-model="all.secondradio" :label="second.xx" disabled v-if="all.lx =='0'"></el-radio>
              <el-checkbox v-model="second.secondcheckbox" disabled v-if="all.lx =='1'">{{second.xx}}</el-checkbox>
              <el-input v-model="second.xxnr" style="width:300px;" disabled></el-input>
            </li>
          </ul>
        </div>

        <div class="testpaper_form_right">
          <el-form ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="正确答案">
              <el-input v-model="all.trueAnswer" style="width:100px;" disabled></el-input>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </template>

  </div>
  </div>
</template>

<script>
export default {
  name: 'testpaper',
  props: {
    xh: String
  },
  data() {
    return {
      secondradio: 'A',
      color3: '#409EFF',
      statusbtn: false,
      status: '',
      sizename: '',
      centerDialogVisibles: false,
      radiooorcheckbox: false,
      radiooorcheckboxs: false,
      textarea: 'A',
      gridData: [
        {
          xx: 'A',
          xxnr: '',
          label: 'A',
          duoxuan: false,
          zqda: ''
        },
        {
          xx: 'B',
          xxnr: '',
          label: 'B',
          duoxuan: false,
          zqda: ''
        },
        {
          xx: 'C',
          xxnr: '',
          label: 'C',
          duoxuan: false,
          zqda: ''
        },
        {
          xx: 'D',
          xxnr: '',
          label: 'D',
          duoxuan: false,
          zqda: ''
        }
      ],
      zimu: ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
      hdmc: '',
      tmlx: '',
      dialogVisible: false,
      zero: '0',
      one: '1',
      selectvalue: undefined,
      tableData: [],
      list: [
        {
          textarea2: '',
          labelPosition: '',
          score: '',
          options: [
            {
              value: '1',
              label: 'A'
            },
            {
              value: '2',
              label: 'B'
            },
            {
              value: '3',
              label: 'C'
            },
            {
              value: '4',
              label: 'D'
            }
          ],
          role: [
            {
              label: 'A',
              textarea: ''
            },
            {
              label: 'B',
              textarea: ''
            },
            {
              label: 'C',
              textarea: ''
            },
            {
              label: 'D',
              textarea: ''
            }
          ],
          titlefalse: '添加',
          danxuantable: [],
          duoxuantable: [],
          xiugau_id: ''
        }
      ]
    }
  },
  mounted() {
    this.list.map(v => {
      this.$set(v, 'multiple', false)
      if (v.labelPosition == 0) {
        this.$set(v, 'selectvalue', '')
      }
      if (v.labelPosition == 1) {
        this.$set(v, 'selectvalue', [])
      }
    })
    this.zimu.map((v, index) => {
      this.gridData.map((vv, index1) => {
        if (index === index1) {
          vv.xx == v
        }
      })
    })
  },
  methods: {
    exitList() {
      this.$store.state.testpaperlist = false
    },
    deltable(row) {
      this.$confirm('此操作将永久删除该选项, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.$http.delete('api/orientation/yxcswj/' + row.id).then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.data.message,
                type: 'error'
              })
            } else {
              console.log(res)
              this.dialogVisible = false
              this.uselist()
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    cel() {
      this.centerDialogVisibles = false
      this.sizename = '';
    },
    centercancel() {
      this.hdmc = '';
      this.tmlx = '';
      this.textarea = `A`
      let obj = [
        {
          xx: 'A',
          xxnr: '',
          label: 'A',
          duoxuan: false,
          zqda: ''
        },
        {
          xx: 'B',
          xxnr: '',
          label: 'B',
          duoxuan: false,
          zqda: ''
        },
        {
          xx: 'C',
          xxnr: '',
          label: 'C',
          duoxuan: false,
          zqda: ''
        },
        {
          xx: 'D',
          xxnr: '',
          label: 'D',
          duoxuan: false,
          zqda: ''
        }
      ]
      this.gridData = obj
      this.dialogVisible = false
      this.radiooorcheckbox = false
      this.radiooorcheckboxs = false
    },
    xiugai(id) {
      this.xiugau_id = id
      this.gridData = []
      this.$http.get('api/orientation/yxcswj/info?id=' + id).then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: 'error'
          })
        } else {
          console.log(res)
          this.dialogVisible = true
          this.titlefalse = '修改题目';
          this.hdmc = res.data.data.tm
          this.tmlx = parseInt(res.data.data.lx)
          this.gridData = res.data.data.nrList
          this.gridData.map(v => {
            this.$set(v, 'label', v.xx)
            this.$set(v, 'duoxuan', false)
          })
          if (this.tmlx == 0) {
            this.radiooorcheckbox = true
            this.radiooorcheckboxs = false
            this.gridData.map(v => {
              if (v.zqda == '1') {
                this.textarea = `${v.xx}`
              }
            })
          }
          if (this.tmlx == 1) {
            this.radiooorcheckbox = false
            this.radiooorcheckboxs = true
            this.gridData.map(v => {
              if (v.zqda == '1') {
                v.duoxuan = true
              }
            })
          }
        }
      })
    },
    sumbit() {
      this.danxuantable = []
      this.duoxuantable = []
      let nrList = []
      let obj = {}
      if (this.tmlx == 0) {
        this.gridData.map(v => {
          if (v.label === this.textarea) {
            v.zqda = '1';
          } else {
            v.zqda = '0';
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          }
          this.danxuantable.push(obj)
        })
        nrList = this.danxuantable
      }
      if (this.tmlx == 1) {
        this.gridData.map(v => {
          if (v.duoxuan) {
            v.zqda = '1';
          } else {
            v.zqda = '0';
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          }
          this.duoxuantable.push(obj)
        })
        nrList = this.duoxuantable
      }
      this.$http
        .post('api/orientation/yxcswj/save', {
          tm: this.hdmc,
          nrList: nrList,
          lx: this.tmlx
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            console.log(res)
            this.dialogVisible = false
            this.uselist()
          }
        })
    },
    sumbitxiugai() {
      this.danxuantable = []
      this.duoxuantable = []
      let nrList = []
      let obj = {}
      if (this.tmlx == 0) {
        this.gridData.map(v => {
          if (v.label === this.textarea) {
            v.zqda = '1';
          } else {
            v.zqda = '0';
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          }
          this.danxuantable.push(obj)
        })
        nrList = this.danxuantable
      }
      if (this.tmlx == 1) {
        this.gridData.map(v => {
          if (v.duoxuan) {
            v.zqda = '1';
          } else {
            v.zqda = '0';
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          }
          this.duoxuantable.push(obj)
        })
        nrList = this.duoxuantable
      }
      this.$http
        .post('api/orientation/yxcswj/update', {
          tm: this.hdmc,
          nrList: nrList,
          lx: this.tmlx,
          id: this.xiugau_id
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            console.log(res)
            this.dialogVisible = false
            this.uselist()
          }
        })
    },
    tmlxradio() {
      if (this.tmlx == 0) {
        this.radiooorcheckbox = true
        this.radiooorcheckboxs = false
      }
      if (this.tmlx == 1) {
        this.radiooorcheckbox = false
        this.radiooorcheckboxs = true
      }
    },
    handleClose() {},
    release() {
      console.log(this.list)
      this.centerDialogVisibles = true
    },
    centerDialogVisibleslist() {
      this.$http
        .put('api/orientation/yxcswj/cancel/' + this.sizename + '/' + '1')
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            console.log(res)
            this.centerDialogVisibles = false
            this.uselist()
          }
        })
    },
    delrelease() {
      this.$http
        .put('api/orientation/yxcswj/cancel/' + 0 + '/' + '0')
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            console.log(res)
            this.centerDialogVisibles = false
            this.uselist()
          }
        })
    },
    delcheange(val) {
      if (val.labelPosition == 0) {
        val.multiple = false
        val.selectvalue = '';
      }
      if (val.labelPosition == 1) {
        val.multiple = true
        val.selectvalue = []
      }
      console.log(val)
    },
    delxx(val) {
      this.gridData.splice(this.gridData.findIndex(item => item === val), 1)
      this.zimu.map((v, index) => {
        this.gridData.map((vv, index1) => {
          if (index === index1) {
            vv.xx = v
            vv.label = v
          }
        })
      })
      this.textarea = 'A';
    },
    adds() {
      let obj
      if (this.gridData.length > this.zimu.length - 1) {
        this.$message({
          message: '添加选项过多',
          type: 'error'
        })
        return false
      } else {
        this.zimu.map((v, index) => {
          this.gridData.map((vv, index1) => {
            if (index === index1) {
              obj = {
                xx: this.zimu[index + 1],
                xxnr: '',
                label: this.zimu[index + 1],
                duoxuan: false,
                zqda: ''
              }
            }
          })
        })
        this.gridData.push(obj)
      }
    },
    add() {
      this.dialogVisible = true
      this.titlefalse = '添加题目';
      if (this.list.length >= 20) {
        return false
      } else {
        let obj = {}
        this.list.map(v => {
          obj = {
            textarea2: '',
            labelPosition: '',
            score: '',
            selectvalue: '',
            options: [
              {
                value: '1',
                label: 'A'
              },
              {
                value: '2',
                label: 'B'
              },
              {
                value: '3',
                label: 'C'
              },
              {
                value: '4',
                label: 'D'
              }
            ],
            role: [
              {
                label: 'A',
                textarea: ''
              },
              {
                label: 'B',
                textarea: ''
              },
              {
                label: 'C',
                textarea: ''
              },
              {
                label: 'D',
                textarea: ''
              }
            ]
          }
        })

        this.list.push(obj)
      }
    },
    del(val, index) {
      this.list.splice(this.list.findIndex(item => item === val), 1)
    },
    uselist() {
      let stuAnswer = '';
      this.$http
        .get('api/orientation/yxcswj/selectAnswerInfo?xh=' + this.xh)
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: 'error'
            })
          } else {
            this.list = res.data.data
            this.list.map(v => {
              if (v.lx == '0') {
                this.$set(v, 'secondradio', v.stuAnswer)
              }
              if (v.lx == '1') {
                v.nrList.map((vv, index) => {
                  this.$set(vv, 'secondcheckbox', false)
                  stuAnswer = v.stuAnswer.split(',')
                  if (stuAnswer.indexOf(vv.xx) > -1) {
                    vv.secondcheckbox = true
                  }
                })
              }
            })
          }
        })
    }
  },
  mounted() {
    this.uselist()
    console.log(11)
  }
}
</script>

<style scoped lang="scss">
.testpaper {
  width: 100%;
  .studentmessage_box {
    height: 60px;
    background: #f2f2f2;
    line-height: 60px;
    padding-left: 10px;
    .top-title {
      width: 100%;
      height: 60px;
      background: #f2f2f2;
      line-height: 60px;
    }
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .testpaper_form {
    padding-left: 100px;
    padding-right: 200px;
    padding-top: 10px;
    // background: rgb(242, 242, 242);
    border-bottom: 1px solid rgb(215, 215, 215);
    display: flex;
    margin: 20px auto 20px;
    .testpaper_form_left {
      flex: 2;
      .testpaper_form_left_ul {
        width: 100%;
      }
      .testpaper_form_left_ul:after {
        display: block;
        clear: both;
        content: "";
        visibility: hidden;
        height: 0;
      }
      .testpaper_form_left_ul {
        zoom: 1;
      }
      .li_right {
        float: left;
        width: 440px;
        margin-bottom: 8px;
      }
    }
    .testpaper_form_right {
      flex: 1;
    }
  }
}
</style>
