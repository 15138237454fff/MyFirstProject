<template>
  <div class="reportedinformation">
    <div class="studentmessage_box">
      <el-input
        v-model="search"
        placeholder="请输入学号/姓名"
        style="width: 200px"
        @keyup.enter.native="handleFind"
        @clear="clearinput"
        clearable
        suffix-icon="el-icon-search"
      >
      </el-input>
      <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
      <template v-if="optionsadd">
        <span class="span">是否按时报到：</span>
        <el-select
          v-model="upmodels"
          placeholder="请选择"
          
          filterable
          style="width:150px"
          @change="yes"
        >
          <el-option
            v-for="(item, $index) in optionsadd"
            :key="$index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </template>
    </div>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      v-loading="loading2"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="tableHeaderColor"
    >
      <el-table-column type="index" label="序号" width="100"></el-table-column>
      <el-table-column prop="zyh" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="xymc" label="学院"></el-table-column>
      <el-table-column prop="zyh" label="专业"></el-table-column>
      <el-table-column prop="status" label="是否按时报到">
        <template slot-scope="scope">
          <span v-if="scope.row.status == '1'">是</span>
          <span v-if="scope.row.status == '0'">否</span>
        </template>
      </el-table-column>
      <el-table-column prop="time" label="报道日期"></el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        :current-page.sync="currentPage"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="pagesize"
        class="import"
        layout="total, sizes, prev, pager, next, jumper"
        @current-change="changePage"
        :total="total"
        @size-change="sizeChange"
        background
      ></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: "reportedinformation",
  data() {
    return {
      search: "",
      upmodel: "",
      upmodels: "1",
      optionsadds: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      pagesize: 5,
      currentPage: 1,
      loading2: false,
      total: 0,
      tableData: [],
      optionsadd: [
        {
          label: "是",
          value: "1"
        },
        {
          label: "否",
          value: "0"
        }
      ]
    };
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    clearinput() {
      this.search = "";
      this.currentPage = 1;
      this.userlist();
    },
    handleFind() {
      this.currentPage = 1;
      this.userlist();
    },
    yes() {
      this.currentPage = 1;
      this.userlist();
    },
    handleSelectionChange() {},
    changePage(val) {
      this.currentPage = val;
      this.userlist();
    },
    sizeChange(val) {
      this.pagesize = val;
      this.userlist();
    },
    userlist() {
      this.loading2 = true;
      this.$http
        .post("api/orientation/infoCollect/list", {
          status: this.upmodels,
          pageNum: this.currentPage,
          pageSize: this.pagesize,
          query: this.search
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list;
            this.total = res.data.data.total;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 160);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 160);
        this.pagesize = Math.floor(this.tableHeight / 57) - 1;
      })();
    };
    this.pagesize = Math.floor(this.tableHeight / 57) - 1;
    this.userlist();
  }
};
</script>

<style scoped lang="scss">
.reportedinformation {
  width: 100%;
  .studentmessage_box {
    width: 100%;
    height: 60px;
    line-height: 60px;
    padding-left: 10px;
    margin-bottom: 10px;
    .span {
      margin-left: 15px;
      font-weight: 500;
      color: #606266;
      font-family: verdana, arial, sans-serif;
      font-size: 14px;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
}
</style>
