<template>
  <div class="testpaper">
    <div class="studentmessage_box">
      <template v-if="$btnAuthorityTest('testpaper:publish')">
        <el-button type="primary" style="float:right;margin-top:10px;" @click="delrelease" v-if="status=='1'">取消发布</el-button>
        <el-button type="primary" style="float:right;margin-top:10px;margin-right:10px" @click="release" v-if="status=='0'">发布</el-button>
      </template>
      <el-button type="primary" style="float:right;margin-top:10px;margin-right:4px" @click="add" :disabled="statusbtn" v-if="$btnAuthorityTest('testpaper:add')">添加</el-button>
    </div>
    <el-table :data="tableData" border style="width: 100%" :header-cell-style="tableHeaderColor" v-loading="loading2">
      <el-table-column type="index" label="序号" width="100">
      </el-table-column>
      <el-table-column label="题目类型">
        <template slot-scope="scope">
          <span v-if="scope.row.lx =='0'">单选</span>
          <span v-if="scope.row.lx =='1'">多选</span>
        </template>
      </el-table-column>
      <el-table-column prop="tm" label="题目">
      </el-table-column>
      <el-table-column prop="xx" label="选项">
      </el-table-column>
      <el-table-column prop="zqda" label="正确答案">
      </el-table-column>
      <el-table-column prop="address" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="xiugai(scope.row.id)" :disabled="statusbtn" v-if="$btnAuthorityTest('testpaper:update')">修改</el-button>
          <span style="color:#409EFF" v-if="$btnAuthorityTest('testpaper:update') && $btnAuthorityTest('testpaper:delete')">|</span>
          <el-button type="text" size="small" style="color:red" :disabled="statusbtn" @click="deltable(scope.row)" v-if="$btnAuthorityTest('testpaper:delete')">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :title="titlefalse" :visible.sync="dialogVisible" width="800px" :before-close="handleClose" center :close-on-click-modal="false">
      <el-form ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="题目名称">
          <el-input v-model="hdmc" maxlength="50"></el-input>
        </el-form-item>
        <el-form-item label="题目类型">
          <el-radio-group v-model="tmlx" @change="tmlxradio">
            <el-radio :label="0">单选题</el-radio>
            <el-radio :label="1">多选题</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <el-table :data="gridData" style="width: 100%" border>
        <el-table-column label="选项" width="50">
          <template slot-scope="scope">
            <span>{{scope.row.xx}}</span>
          </template>
        </el-table-column>
        <el-table-column label="选项内容">
          <template slot-scope="scope">
            <el-input v-model="scope.row.xxnr" placeholder="请输入选项内容" maxlength="30"></el-input>
          </template>
        </el-table-column>
        <el-table-column label="正确答案">
          <template slot-scope="scope">
            <el-radio v-model="textarea" :label="scope.row.label" v-if="radiooorcheckbox"></el-radio>
            <el-checkbox v-model="scope.row.duoxuan" v-if="radiooorcheckboxs">{{scope.row.label}}</el-checkbox>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100">
          <template slot-scope="scope">
            <el-button type="text" size="small" v-if="scope.$index===gridData.length-1" @click="adds">添加</el-button>
            <el-button type="text" size="small" style="color:red" v-if="scope.$index >1 && scope.$index!==gridData.length-1" @click="delxx(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <span slot="footer" class="dialog-footer">
        <el-button @click="centercancel">取 消</el-button>
        <el-button type="primary" @click="sumbit" v-if="titlefalse =='添加题目'">确 定</el-button>
        <el-button type="primary" @click="sumbitxiugai" v-if="titlefalse =='修改题目'">保存</el-button>
      </span>
    </el-dialog>
    <el-dialog title="发布试卷" :visible.sync="centerDialogVisibles" width="350px" center>
      <el-form ref="form" label-width="200px" size="mini">
        <el-form-item label="请设置随机分配题目数量：">
          <el-input v-model="sizename" maxlength="4"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cel">取 消</el-button>
        <el-button type="primary" @click="centerDialogVisibleslist">确 定</el-button>
      </span>
    </el-dialog>

  </div>
  </div>
</template>

<script>
export default {
  name: "testpaper",
  data() {
    return {
      statusbtn: false,
      status: "",
      sizename: "",
      centerDialogVisibles: false,
      radiooorcheckbox: false,
      radiooorcheckboxs: false,
      textarea: "A",
      gridData: [
        {
          xx: "A",
          xxnr: "",
          label: "A",
          duoxuan: false,
          zqda: ""
        },
        {
          xx: "B",
          xxnr: "",
          label: "B",
          duoxuan: false,
          zqda: ""
        },
        {
          xx: "C",
          xxnr: "",
          label: "C",
          duoxuan: false,
          zqda: ""
        },
        {
          xx: "D",
          xxnr: "",
          label: "D",
          duoxuan: false,
          zqda: ""
        }
      ],
      zimu: ["A", "B", "C", "D", "E", "F", "G"],
      hdmc: "",
      tmlx: "",
      dialogVisible: false,
      loading2: false,
      zero: "0",
      one: "1",
      selectvalue: undefined,
      tableData: [],
      titlefalse: "添加题目"
    };
  },
  mounted() {
    this.zimu.map((v, index) => {
      this.gridData.map((vv, index1) => {
        if (index === index1) {
          vv.xx == v;
        }
      });
    });
    this.uselist();
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    deltable(row) {
      this.$confirm("删除该选项, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http.delete("api/orientation/yxcswj/" + row.id).then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.data.message,
                type: "error"
              });
            } else {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.dialogVisible = false;
              this.uselist();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    cel() {
      this.centerDialogVisibles = false;
      this.sizename = "";
    },
    centercancel() {
      this.hdmc = "";
      this.tmlx = "";
      this.textarea = `A`;
      let obj = [
        {
          xx: "A",
          xxnr: "",
          label: "A",
          duoxuan: false,
          zqda: ""
        },
        {
          xx: "B",
          xxnr: "",
          label: "B",
          duoxuan: false,
          zqda: ""
        },
        {
          xx: "C",
          xxnr: "",
          label: "C",
          duoxuan: false,
          zqda: ""
        },
        {
          xx: "D",
          xxnr: "",
          label: "D",
          duoxuan: false,
          zqda: ""
        }
      ];
      this.gridData = obj;
      this.dialogVisible = false;
      this.radiooorcheckbox = false;
      this.radiooorcheckboxs = false;
    },
    xiugai(id) {
      this.xiugau_id = id;
      this.gridData = [];
      this.$http.get("api/orientation/yxcswj/info?id=" + id).then(res => {
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          this.dialogVisible = true;
          this.titlefalse = "修改题目";
          this.hdmc = res.data.data.tm;
          this.tmlx = parseInt(res.data.data.lx);
          this.gridData = res.data.data.nrList;
          this.gridData.map(v => {
            this.$set(v, "label", v.xx);
            this.$set(v, "duoxuan", false);
          });
          if (this.tmlx == 0) {
            this.radiooorcheckbox = true;
            this.radiooorcheckboxs = false;
            this.gridData.map(v => {
              if (v.zqda == "1") {
                this.textarea = `${v.xx}`;
              }
            });
          }
          if (this.tmlx == 1) {
            this.radiooorcheckbox = false;
            this.radiooorcheckboxs = true;
            this.gridData.map(v => {
              if (v.zqda == "1") {
                v.duoxuan = true;
              }
            });
          }
        }
      });
    },
    sumbit() {
      if (this.hdmc == "") {
        this.$message({
          message: "题目名称必填",
          type: "error"
        });
        return false;
      }
      console.log(this.tmlx);
      this.danxuantable = [];
      this.duoxuantable = [];
      let nrList = [];
      let obj = {};
      if (this.tmlx == 0) {
        this.gridData.map(v => {
          if (v.label === this.textarea) {
            v.zqda = "1";
          } else {
            v.zqda = "0";
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          };
          this.danxuantable.push(obj);
        });
        nrList = this.danxuantable;
      }
      if (this.tmlx == 1) {
        this.gridData.map(v => {
          if (v.duoxuan) {
            v.zqda = "1";
          } else {
            v.zqda = "0";
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          };
          this.duoxuantable.push(obj);
        });
        nrList = this.duoxuantable;
      }
      this.$http
        .post("api/orientation/yxcswj/save", {
          tm: this.hdmc,
          nrList: nrList,
          lx: this.tmlx
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.dialogVisible = false;
            this.uselist();
          }
        });
    },
    sumbitxiugai() {
      if (this.hdmc == "") {
        this.$message({
          message: "题目名称必填",
          type: "error"
        });
        return false;
      }
      this.danxuantable = [];
      this.duoxuantable = [];
      let nrList = [];
      let obj = {};
      if (this.tmlx == 0) {
        this.gridData.map(v => {
          if (v.label === this.textarea) {
            v.zqda = "1";
          } else {
            v.zqda = "0";
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          };
          this.danxuantable.push(obj);
        });
        nrList = this.danxuantable;
      }
      if (this.tmlx == 1) {
        this.gridData.map(v => {
          if (v.duoxuan) {
            v.zqda = "1";
          } else {
            v.zqda = "0";
          }
          obj = {
            xx: v.xx,
            xxnr: v.xxnr,
            zqda: v.zqda
          };
          this.duoxuantable.push(obj);
        });
        nrList = this.duoxuantable;
      }
      this.$http
        .post("api/orientation/yxcswj/update", {
          tm: this.hdmc,
          nrList: nrList,
          lx: this.tmlx,
          id: this.xiugau_id
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            console.log(res);
            this.dialogVisible = false;
            this.uselist();
          }
        });
    },
    tmlxradio() {
      if (this.tmlx == 0) {
        this.radiooorcheckbox = true;
        this.radiooorcheckboxs = false;
      }
      if (this.tmlx == 1) {
        this.radiooorcheckbox = false;
        this.radiooorcheckboxs = true;
      }
    },
    handleClose() {
      this.dialogVisible = false;
    },
    release() {
      this.centerDialogVisibles = true;
    },
    centerDialogVisibleslist() {
      if (this.sizename == "") {
        this.$message({
          message: "请填写随机分配题目数量",
          type: "error"
        });
        return false;
      }
      this.$http
        .put("api/orientation/yxcswj/cancel/" + this.sizename + "/" + "1")
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.centerDialogVisibles = false;
            this.uselist();
          }
        });
    },
    delrelease() {
      this.$http
        .put("api/orientation/yxcswj/cancel/" + 0 + "/" + "0")
        .then(res => {
          if (res.data.code == 400) {
            this.$message({
              message: res.data.data.message,
              type: "error"
            });
          } else {
            this.$message({
              message: "取消发布成功",
              type: "success"
            });
            this.centerDialogVisibles = false;
            this.uselist();
          }
        });
    },
    delcheange(val) {
      if (val.labelPosition == 0) {
        val.multiple = false;
        val.selectvalue = "";
      }
      if (val.labelPosition == 1) {
        val.multiple = true;
        val.selectvalue = [];
      }
    },
    delxx(val) {
      this.gridData.splice(this.gridData.findIndex(item => item === val), 1);
      this.zimu.map((v, index) => {
        this.gridData.map((vv, index1) => {
          if (index === index1) {
            vv.xx = v;
            vv.label = v;
          }
        });
      });
      this.textarea = "A";
    },
    adds() {
      let obj;
      if (this.gridData.length > this.zimu.length - 1) {
        this.$message({
          message: "添加选项过多",
          type: "error"
        });
        return false;
      } else {
        this.zimu.map((v, index) => {
          this.gridData.map((vv, index1) => {
            if (index === index1) {
              obj = {
                xx: this.zimu[index + 1],
                xxnr: "",
                label: this.zimu[index + 1],
                duoxuan: false,
                zqda: ""
              };
            }
          });
        });
        this.gridData.push(obj);
      }
    },
    add() {
      this.dialogVisible = true;
      this.titlefalse = "添加题目";
    },
    del(val, index) {
      this.list.splice(this.list.findIndex(item => item === val), 1);
    },
    uselist() {
      this.loading2 = true
      this.$http.get("api/orientation/yxcswj/list").then(res => {
        this.loading2 = false;
        if (res.data.code == 400) {
          this.$message({
            message: res.data.data.message,
            type: "error"
          });
        } else {
          this.status = res.data.data.zt;
          if (res.data.data.zt == "1") {
            this.statusbtn = true;
          } else {
            this.statusbtn = false;
          }
          this.tableData = res.data.data.sjList;
        }
      }).catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
};
</script>

<style scoped lang="scss">
.testpaper {
  width: 100%;
  .studentmessage_box {
    height: 60px;
    line-height: 60px;
    padding-left: 10px;
  }
  .testpaper_form {
    padding-left: 100px;
    padding-right: 200px;
    padding-top: 10px;
    background: rgb(242, 242, 242);
    display: flex;
    margin: 20px auto 0;
    .testpaper_form_left {
      flex: 2;
      .testpaper_form_left_ul {
        width: 100%;
      }
      .testpaper_form_left_ul:after {
        display: block;
        clear: both;
        content: "";
        visibility: hidden;
        height: 0;
      }
      .testpaper_form_left_ul {
        zoom: 1;
      }
      .li_right {
        float: left;
        width: 440px;
        margin-bottom: 8px;
      }
    }
    .testpaper_form_right {
      flex: 1;
    }
  }
}
</style>
