<!-- 教职工信息管理 -->
<template>
  <div class="staffManagement">
    <template v-if="!staffInfor && !staffDetails && !staffxgs">
      <div class="container">
        <componment>
          <div slot="left" style="flex:1">
            <el-input
              v-model="searchField"
              placeholder="请输入工号/姓名"
              style="width: 200px"
              @keyup.enter.native="searchData"
              clearable
              @clear="clearinput"
              ><i class="el-icon-search el-input__icon" slot="suffix"> </i
            ></el-input>
            <el-button @click="searchData">查询</el-button>
            <el-select
              v-model="work"
              filterable
              placeholder="全部单位"
              @change="deptSelectChange"
            >
              <el-option value="">全部</el-option>
              <el-option
                v-for="item in deptList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </div>
          <div slot="right" style="flex:1">
            <el-button
              type="primary"
              @click="addNew"
              v-if="$btnAuthorityTest('staffManagement:add')"
              >添加</el-button
            >
            <el-button
              type="danger"
              @click="deleteInfor"
              v-if="$btnAuthorityTest('staffManagement:delete')"
              >删除</el-button
            >
            <el-button
              @click="exportInfo"
              v-if="$btnAuthorityTest('staffManagement:export')"
              >导出</el-button
            >
          </div>
        </componment>
        <el-table
          :data="tableData"
          border
          ref="multipleTable"
          style="width: 100%"
          @row-click="clickRow"
          @selection-change="mySelect"
          @select-all="allClick"
          :header-cell-style="$storage.tableHeaderColor"
          :height="tableHeight"
          v-loading="loading2"
          element-loading-text="加载中"
        >
          <el-table-column
            :show-overflow-tooltip="true"
            type="selection"
            width="55"
          >
          </el-table-column>
          <el-table-column prop="gh" label="工号" width="150">
          </el-table-column>
          <el-table-column prop="xm" label="姓名"> </el-table-column>
          <el-table-column prop="xbm" label="性别">
            <template slot-scope="scope">
              <span>{{ getDictValue(scope.row.xbm, "sexCode") }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="mzmc" label="民族"> </el-table-column>
          <el-table-column prop="ssyxmc" label="所属单位"> </el-table-column>
          <el-table-column prop="bzlbmc" label="编制类别"> </el-table-column>
          <el-table-column prop="dqztmc" label="当前状态"> </el-table-column>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <span
                @click="checkDetails(scope.row)"
                class="tablexq"
                v-if="$btnAuthorityTest('staffManagement:view')"
                >查看</span
              ><span
                v-if="
                  $btnAuthorityTest('staffManagement:view') &&
                    $btnAuthorityTest('staffManagement:update')
                "
              >
                | </span
              ><span
                class="tablexg"
                @click="xg(scope.row)"
                v-if="$btnAuthorityTest('staffManagement:update')"
                >修改</span
              >
            </template>
          </el-table-column>
        </el-table>
        <pagination
          :total="total"
          :page.sync="listQuery.queryPage.pageNum"
          :limit.sync="listQuery.queryPage.pageSize"
          class="pagination-content"
          @pagination="takeList"
        ></pagination>
      </div>
    </template>
    <staff v-if="staffInfor" :deptList="deptList" @staffadd="staffadd"></staff>
    <mydetails
      v-if="staffDetails"
      :gh="gh"
      :deptList="deptList"
      @staffCk="staffCk"
    ></mydetails>
    <staffxg
      v-if="staffxgs"
      :gh="gh"
      :deptList="deptList"
      @staffs="staffs"
    ></staffxg>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import staff from "./staffInformation/addstaffDetails";
import mydetails from "./staffInformation/staffDetails";
import staffxg from "./staffInformation/staffxg";
import componment from "@/components/searchcomponment";
export default {
  name: "staffManagement",
  data() {
    return {
      staffInfor: false,
      staffDetails: false,
      staffxgs: false,
      addDialog: false, // 添加班级
      detailsDialog: false, // 查看详情
      searchField: "", // 搜索的数据
      tableData: [],
      deptList: [],
      collegeList: [], // 所属校区列表
      work: "", // 选中单位
      total: 0, // 总数据条
      tableHeight: null, // 表格高度
      clientHeight: 0,
      offsetTop: 0,
      gh: "",
      ghs: [],
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  methods: {
    searchFieldlist() {
      this.searchField = "";
      this.work = "";
    },
    staffadd(val) {
      // 添加
      this.staffInfor = val;
    },
    staffCk(val) {
      // 查看详情
      this.staffDetails = val;
    },
    staffs(val) {
      // 修改
      this.staffxgs = val;
    },
    clearinput() {
      this.searchField = "";
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    },
    // 部门下拉框选择改变事件
    deptSelectChange() {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    },
    takeList() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      this.$http
        .post("api/system/jzg/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          collegeCode: this.work
        })
        .then(res => {
          this.loading2 = false;
          console.log("加载成功");
          this.tableData = res.data.data.info;
          this.total = res.data.data.total;
          res.data.data.info.map((item, index) => {
            if (item.dqztm == 1) {
              this.tableData[index].dqztm = "在职";
            } else if (item.dqztm == 2) {
              this.tableData[index].dqztm = "离职";
            }
          });
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查看教职工列表
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    }, // 列表选择
    mySelect(selection) {
      if (selection.length == 0) {
        this.ghs = [];
      } else {
        this.ghs = selection.map(item => {
          return item.gh;
        });
      }
    }, // 列表选择
    allClick(selection) {}, // 列表全选
    searchData() {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
    }, // 搜索数据方法
    addNew() {
      this.staffInfor = true;
      this.searchFieldlist();
      this.mystatus = "添加";
    }, // 添加数据
    deleteInfor() {
      if (this.ghs.length < 1) {
        this.$message.error({ message: "请选择数据!" });
        return;
      }
      this.$confirm("删除教职工, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        center: true
      })
        .then(() => {
          this.deleteTeacherInfo();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }, // 删除数据
    // 删除数据提交
    deleteTeacherInfo() {
      this.$http.delete("api/baseservice/jzg", { data: this.ghs }).then(res => {
        this.$message({
          type: res.data.code == 200 ? "success" : "error",
          message: res.data.message
        });
        this.takeList();
        this.listQuery.queryPage.pageNum = 1;
      });
    },
    exportInfo() {}, // 导出数据
    checkDetails(row) {
      this.staffDetails = true;
      this.mystatus = "查看";
      this.gh = row.gh;
    }, // 查看详情
    xg(row) {
      this.staffxgs = true;
      this.mystatus = "修改";
      this.gh = row.gh;
      this.searchFieldlist();
    },
    loadDeptSelect() {
      this.$http.get("api/system/dept/selectAll").then(res => {
        this.deptList = res.data.data;
      });
    },
    handleClose(done) {
      done();
    } // 关闭弹出框
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    // 加载所属单位下拉框
    this.loadDeptSelect();
  },
  components: {
    staff,
    mydetails,
    pagination,
    staffxg: staffxg,
    componment: componment
  }
};
</script>

<style scoped lang="scss">
.staffManagement {
  width: 100%;
  padding-top: 7px;
}
.staffManagement /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.staffManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
.staffManagement /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.staffManagement /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar {
  //设置整个滚动条宽高
  width: 6px;
  height: 100%;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-thumb {
  //设置滑块
  width: 6px;
  height: 60px;
  background-color: #ccc;
  border-radius: 3px;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-track {
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.5); //设置背景透明
}
</style>

<style>
.detailsCheck input {
  /* border: none !important; */
}
</style>
