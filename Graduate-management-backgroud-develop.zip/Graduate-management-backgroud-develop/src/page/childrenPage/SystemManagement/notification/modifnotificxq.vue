<template>
  <div class="modifnotific" v-loading="loading" element-loading-text="加载中">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList"
        >返回列表</el-button
      >
    </div>
    <el-form ref="form" :model="form" label-width="100px">
      <el-row>
        <el-col :span="15">
          <el-form-item label="标题：" :required="true">
            <span>{{ form.title }}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="15">
          <el-form-item label="发送对象：" :required="true">
            <span>{{ form.department | departments(departmentList) }}</span>
            <span>{{ form.choose | chooseLists(chooseList) }}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="margin-bottom:50px">
        <el-col :span="20">
          <el-form-item label="正文：" :required="true">
            <span v-html="content"></span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="20">
          <el-form-item label="相关附件：" :required="true">
            <div>
              <li
                v-for="(item, index) in fileList"
                style="color:#1890FF;text-decoration:underline"
              >
                <i class="el-icon-document"></i
                ><span
                  style="margin-right:20px;margin-left:10px"
                  @click="open(item.url)"
                  >{{ item.fileName }}</span
                >
              </li>
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { quillEditor } from "vue-quill-editor";

export default {
  filters: {
    departments(val, row) {
      const valindex = row.find((el, index) => el.code === val);
      if (valindex) {
        return valindex.name;
      } else {
        return "";
      }
    },
    chooseLists(val, row) {
      const arr = [];
      if (val.length && row.length) {
        val.map(v => {
          const valindex = row.find((el, index) => el.jsid === v);
          arr.push(valindex.name);
        });
        return arr.toString();
      } else {
        return "未知";
      }
    }
  },
  props: ["rowid"],
  name: "modifnotificxq",
  data() {
    return {
      isShow: true,
      fileList: [],
      form: {
        title: "",
        sendPeople: 0,
        choose: [
          {
            value: "",
            label: ""
          }
        ],
        department: [
          {
            value: "",
            label: ""
          }
        ]
      },
      id: 0,
      content: "",
      chooseList: [], // 选项列表
      loading: false,
      departmentList: [] // 选项列表
    };
  },
  methods: {
    open(val) {
      window.open(val);
    },
    exitList() {
      this.$emit("returnparents", false);
    },
    changeHandle(value) {
      this.chooseList = [];
      this.form.choose = [];
      this.$http.get("api/system/notice/selectbyfsdx/" + value).then(res => {
        if (res.data.data) {
          this.chooseList = res.data.data;
        }
      });
    }
  },
  mounted() {
    this.loading = true;
    let temp = "";
    let numtemp = [];
    let myarr = [];
    this.$http.get("api/system/notice/selectUp/" + this.rowid).then(res => {
      this.id = res.data.data.id;
      this.form.title = res.data.data.bt;
      this.form.department = res.data.data.fsdx;
      this.content = res.data.data.zw;
      temp = res.data.data.fsdxs;
      this.changeHandle(res.data.data.fsdx);
      numtemp = temp.split(",");
      numtemp.forEach(function(item, index) {
        myarr.push(item);
      });
      this.form.choose = myarr;
      this.loading = false;
      this.fileList = res.data.data.xtWjscjlbVos;
    });
    this.$http.get("api/system/notice/selectfsdx").then(res => {
      this.departmentList = res.data.data;
    });
  },
  comments: {
    quillEditor
  }
};
</script>

<style scoped lang="scss">
.quill-editor {
  height: 200px;
}

.fl {
  float: left;
  font-size: 14px;
  margin-left: 45px;
  color: #606266;
}
/deep/ .el-form-item__content {
  font-size: 14px;
  color: #606266;
}
.top-title {
  width: 100%;
  height: 60px;
  border-bottom: 1px solid #f2f2f2;
  line-height: 60px;
}

.diyButton {
  background: none;
  border: none;
  color: #2779e3;
}

.modifnotific /deep/ .el-form {
  margin-top: 15px;
}
</style>
