<template>
  <div class="modifnotific" v-loading="loading" element-loading-text="加载中">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList"
        >返回列表</el-button
      >
      <el-button
        type="primary"
        style="float: right; margin: 10px 10px 0 0;"
        @click="updateData"
        >保存</el-button
      >
    </div>
    <el-form ref="form" :model="form" label-width="100px">
      <el-row>
        <el-col :span="15">
          <el-form-item label="标题：" :required="true">
            <el-input v-model="form.title"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="15">
          <el-form-item label="发送对象：" :required="true">
            <el-select
              v-model="form.department"
              placeholder="请选择"
              style="width: 49%; float: left;"
              @change="changeHandle"
            >
              <el-option
                v-for="item in departmentList"
                :key="item.code"
                :label="item.name"
                :value="item.code"
              >
              </el-option>
            </el-select>
            <el-select
              style="width: 49%; float: right;"
              v-model="form.choose"
              multiple
              v-show="form.department == '4' || form.department == '5'"
              filterable
              allow-create
              default-first-option
              placeholder="请选择"
            >
              <el-option
                v-for="(item, index) in chooseList"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="margin-bottom:100px">
        <el-col :span="20">
          <el-form-item label="正文：" :required="true">
            <quill-editor
              ref="myTextEditor"
              v-model="content"
              :options="editorOption"
              @blur="onEditorBlur($event)"
              @focus="onEditorFocus($event)"
              @ready="onEditorReady($event)"
            >
            </quill-editor>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="20">
          <el-form-item label="相关附件：">
            <el-upload
              class="upload-demo"
              :action="upload"
              :data="uploadData"
              :limit="5"
              :before-upload="handlebefore"
              :on-success="handleSuccess"
              ref="uploadcsv"
              accept=""
              :headers="headtoken"
            >
              <el-button
                style="border-color:rgba(24, 144, 255, 1);color:#1890FF;width:350px"
                >点击上传</el-button
              ><span
                style="margin-left:20px;color:red"
                slot="tip"
                class="el-upload__tip"
                >请上传10M以内的附件</span
              >
            </el-upload>
            <div>
              <li v-for="(item, index) in fileList" :key="index">
                <i class="el-icon-document"></i
                ><span
                  style="margin-right:20px;margin-left:10px"
                  @click="open(item.url)"
                  >{{ item.fileName }}</span
                ><i
                  class="el-icon-close"
                  @click="cancelupload(index, item.id)"
                ></i>
              </li>
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
import { quillEditor } from "vue-quill-editor";

export default {
  props: ["rowid"],
  name: "modifnotific",
  data() {
    return {
      headtoken: {
        userToken: this.$stores.state.token
      },
      upload: "/api/system/notice/uploadFile",
      uploadData: {
        file: ""
      },
      isShow: true,
      fileList: [],
      form: {
        title: "",
        sendPeople: 0,
        choose: [
          {
            value: "",
            label: ""
          }
        ],
        department: [
          {
            value: "",
            label: ""
          }
        ]
      },
      id: 0,
      content: "",
      chooseList: [], // 选项列表
      loading: false,
      departmentList: [], // 选项列表
      editorOption: {
        theme: "snow",
        boundary: document.body,
        modules: {
          toolbar: [
            ["bold", "italic", "underline", "strike"],
            ["blockquote", "code-block"],
            [{ header: 1 }, { header: 2 }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ script: "sub" }, { script: "super" }],
            [{ indent: "-1" }, { indent: "+1" }],
            [{ direction: "rtl" }],
            [{ size: ["small", false, "large", "huge"] }],
            [{ header: [1, 2, 3, 4, 5, 6, false] }],
            [{ color: ["red", "blue", "green"] }, { background: [] }],
            [{ font: [] }],
            [{ align: [] }],
            ["clean"],
            ["link", "image", "video"]
          ]
        },
        placeholder: "Insert text here ...",
        readOnly: false
      }
    };
  },
  methods: {
    cancelupload(index, id) {
      this.fileList.splice(
        this.fileList.findIndex(item => item.id === id),
        1
      );
    },
    handlebefore(file) {
      this.uploadData.file = file.name;
    },
    open(val) {
      window.open(val);
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      var fileobj = file.data;
      this.fileList.push(fileobj);
      if (file.code == 400) {
        this.$message({
          message: "上传失败，请重新上传",
          type: "error"
        });
        this.$refs.uploadcsv.clearFiles();
      } else {
        this.$message({
          message: "上传成功",
          type: "success"
        });
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles();
        }, 500);
      }
    },
    exitList() {
      this.$store.state.modifnotific = false;
    },
    onEditorBlur(editor) {},
    onEditorFocus(editor) {},
    onEditorReady(editor) {},
    onEditorChange({ editor, html, text }) {
      this.content = html;
    },
    changeHandle(value) {
      this.chooseList = [];
      this.form.choose = [];
      this.$http.get("api/system/notice/selectbyfsdx/" + value).then(res => {
        if (this.form.department == "4") {
          if (res.data.data) {
            res.data.data.forEach(el => {
              this.chooseList.push({ value: el.jsid, label: el.name });
            });
          }
        } else if (this.form.department == "5") {
          if (res.data.data) {
            res.data.data.forEach(el => {
              this.chooseList.push({ value: el.dwh, label: el.dwmc });
            });
          }
        } else {
          this.chooseList = [];
        }
      });
    }, // 切换发送对象
    updateData() {
      let arr = [];
      if (this.form.title == "") {
        this.$message.error({ message: "请填写标题" });
        return false;
      } else if (this.content == "") {
        this.$message.error({ message: "请填写正文" });
        return false;
      }
      if (this.fileList) {
        var fileList = JSON.parse(JSON.stringify(this.fileList));
        if (fileList.length > 0) {
          fileList.map(v => {
            arr.push(v.id);
          });
        } else {
          arr = [];
        }
      }
      var myarr = [];
      if (this.form.choose != []) {
        myarr = this.form.choose.join(",");
      }
      const obj = {
        id: this.id,
        bt: this.form.title,
        fsdx: this.form.department,
        fsdxs: myarr,
        zw: this.content,
        fileName: arr.toString()
      };
      this.$http.put("api/system/notice", obj).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: res.data.message,
            type: "success"
          });
          this.$parent.takeList();
          this.$store.state.modifnotific = false;
        } else {
          this.$message.error({ message: res.data.message });
        }
      });
    } // 保存
  },
  mounted() {
    this.loading = true;
    let temp = "";
    let numtemp = [];
    let myarr = [];
    this.$http.get("api/system/notice/selectUp/" + this.rowid).then(res => {
      this.id = res.data.data.id;
      this.form.title = res.data.data.bt;
      temp = res.data.data.fsdxs;
      numtemp = temp.split(",");
      numtemp.forEach(function(item, index) {
        myarr.push(item);
      });
      this.form.department = res.data.data.fsdx;
      this.content = res.data.data.zw;
      this.changeHandle(res.data.data.fsdx);
      this.form.choose = myarr;
      this.loading = false;
      if (res.data.data.xtWjscjlbVos !== null) {
        this.fileList = res.data.data.xtWjscjlbVos;
      }
    });
    this.$http.get("api/system/notice/selectfsdx").then(res => {
      this.departmentList = res.data.data;
    });
  },
  comments: {
    quillEditor
  }
};
</script>

<style scoped lang="scss">
.quill-editor {
  height: 200px;
}

.fl {
  float: left;
  font-size: 14px;
  margin-left: 45px;
  color: #606266;
}

.top-title {
  width: 100%;
  height: 60px;
  border-bottom: 1px solid #f2f2f2;
  line-height: 60px;
}

.diyButton {
  background: none;
  border: none;
  color: #2779e3;
}

.modifnotific /deep/ .el-form {
  margin-top: 15px;
}
</style>
