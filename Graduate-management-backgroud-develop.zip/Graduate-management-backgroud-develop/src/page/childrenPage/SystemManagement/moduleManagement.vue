<!-- 通知公告 -->
<template>
  <div class="moduleManagement">
    <componment>
      <div slot="left">
        <el-input
          v-model="searchField"
          placeholder="请输入模块名称"
          style="width:200px"
          @keyup.enter.native="searchData"
          clearable
          @clear="clearinput"
          suffix-icon="el-icon-search"
        ></el-input>
        <el-button @click="searchData">查询</el-button>
        <el-select
          v-model="selectvalue"
          placeholder="请选择菜单"
          filterable
          
          @change="selectchange"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('moduleManagement:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="deleteInfor"
          v-if="$btnAuthorityTest('moduleManagement:delete')"
          >删除</el-button
        >
      </div>
    </componment>
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      border
      :header-cell-style="$storage.tableHeaderColor"
      style="width: 100%"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      v-loading="loading"
      element-loading-text="加载中"
      @select-all="allClick"
      @row-click="clickRow"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="gncdmc" label="模块名称"></el-table-column>
      <el-table-column prop="menuSort" label="排序"></el-table-column>
      <el-table-column prop="menuType" label="模块类型">
        <template slot-scope="scope">
          <span>{{ scope.row.menuType | menuType }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="sjcdmc" label="上级模块"> </el-table-column>
      <el-table-column prop="zt" label="状态">
        <template slot-scope="scope">
          <span>{{ scope.row.isValid | zt }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="checkInfor(scope.row)"
            v-if="$btnAuthorityTest('moduleManagement:view')"
            >查看</span
          ><span
            v-if="
              $btnAuthorityTest('moduleManagement:view') &&
                $btnAuthorityTest('moduleManagement:update')
            "
          >
            | </span
          ><span
            class="tablexg"
            @click="menuTypexg(scope.row)"
            v-if="$btnAuthorityTest('moduleManagement:update')"
            >修改</span
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      v-if="freshpag"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <el-dialog
      :title="addmodel"
      :visible.sync="centerDialogVisible"
      :close-on-click-modal="false"
      :before-close="addmodelclose"
    >
      <el-form ref="form" label-width="100px" :rules="rules" :model="form">
        <el-form-item label="模块类型：">
          <el-radio-group
            v-model="form.menuType"
            @change="radioMenu"
            :disabled="isshow"
          >
            <el-radio
              :label="item.value"
              v-for="(item, index) in modeltypetype"
              :key="index"
              >{{ item.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="模块名称：" prop="gncdmc">
          <el-input
            v-model="form.gncdmc"
            placeholder="请输入模块名称"
            :disabled="isshow"
          ></el-input>
        </el-form-item>
        <el-form-item label="上级模块：" v-if="form.menuType">
          <el-select
            v-model="form.sjcdid"
            placeholder="请选择上级模块"
            :disabled="showselect"
            :readonly="readonly"
            filterable
          >
            <el-option
              v-for="(item, $index) in optionsadd"
              :key="$index"
              :label="item.gncdmc"
              :value="item.gncdid"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="排序号：" prop="menuSort">
          <el-input
            v-model.number="form.menuSort"
            placeholder="请输入数字"
            maxlength="3"
            :disabled="isshow"
          ></el-input>
        </el-form-item>
        <el-form-item label="菜单ID：" prop="gncdid">
          <el-input
            v-model.number="form.gncdid"
            placeholder="请输入数字"
            maxlength="3"
            :disabled="isshow"
          ></el-input>
        </el-form-item>
        <el-form-item label="icon：">
          <el-input
            v-model="form.menuIcon"
            placeholder="请输入fa fa-"
            :disabled="isshow"
            ><i class="el-icon-view" slot="suffix" @click="handleIconClick"></i
          ></el-input>
        </el-form-item>
        <el-form-item label="模块URL：">
          <el-input
            v-model="form.url"
            placeholder="请输入模块URL"
            :disabled="isshow1"
          ></el-input>
        </el-form-item>
        <el-form-item label="授权标识：">
          <el-input
            v-model="form.menuUuid"
            placeholder="请输入授权标识"
            :disabled="isshow"
          >
          </el-input>
        </el-form-item>
        <el-form-item label="状态：" prop="isValid">
          <el-radio v-model="form.isValid" label="0" :disabled="isshow"
            >无效</el-radio
          >
          <el-radio v-model="form.isValid" label="1" :disabled="isshow"
            >有效</el-radio
          >
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div class="foots" v-if="addmodel == '功能模块添加'">
          <el-button type="primary" @click="canceldialog('form')"
            >取消</el-button
          >
          <el-button type="primary" @click="submitForm('form')">确定</el-button>
        </div>
        <div class="foots" v-if="addmodel == '修改功能模块'">
          <el-button type="primary" @click="canceldialog('form')"
            >取消</el-button
          >
          <el-button type="primary" @click="submitForm('form')"
            >保 存</el-button
          >
        </div>
      </span>
    </el-dialog>
    <el-dialog
      title="选择icon名称"
      :visible.sync="centerDialogVisibles"
      :close-on-click-modal="false"
    >
      <div class="icon">
        <icon></icon>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import icon from "./icon";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "moduleManagement",
  components: {
    icon,
    pagination: pagination,
    componment: componment
  },
  data() {
    return {
      searchField: "", // 搜索
      selectvalue: "",
      options: [
        {
          value: "",
          label: "全部菜单"
        },
        {
          value: "1",
          label: "一级菜单"
        },
        {
          value: "2",
          label: "二级菜单"
        },
        {
          value: "3",
          label: "三级菜单"
        },
        {
          value: "4",
          label: "按钮"
        }
      ], // 请选择菜单
      tableHeight: null,
      tableData: [],
      total: 0,
      addmodel: "功能模块添加",
      form: {
        menuType: "1",
        isValid: "1"
      },
      centerDialogVisible: false,
      centerDialogVisibles: false,
      optionsadd: [],
      modeltypetype: [
        {
          value: "1",
          label: "一级菜单"
        },
        {
          value: "2",
          label: "二级菜单"
        },
        {
          value: "3",
          label: "三级菜单"
        },
        {
          value: "4",
          label: "按钮"
        }
      ],
      showselect: true,
      readonly: true,
      rules: {
        gncdmc: [{ required: true, message: "请输入模块名称" }],
        menuSort: [
          { required: true, message: "排序号不能为空" },
          { type: "number", message: "排序号必须为数字值" }
        ],
        gncdid: [
          { required: true, message: "菜单ID不能为空" },
          { type: "number", message: "菜单ID必须为数字值" }
        ],
        isValid: [{ required: true, message: "请选择状态", trigger: "change" }]
      },
      multipleSelection: [],
      dislogid: "",
      isshow: false,
      isshow1: false,
      loading: false,
      listQuery: {
        queryPage: {
          pageSize: 15,
          pageNum: 1
        }
      },
      freshpag: true
    };
  },

  filters: {
    menuType(val) {
      if (val == "1") {
        return "一级菜单";
      } else if (val == "2") {
        return "二级菜单";
      } else if (val == "3") {
        return "三级菜单";
      } else if (val == "4") {
        return "按钮";
      }
    },
    zt(val) {
      if (val == "0") {
        return "无效";
      } else if (val == "1") {
        return "有效";
      }
    }
  },
  created() {},
  methods: {
    menuTypexg(row) {
      this.addmodel = "修改功能模块";
      this.centerDialogVisible = true;
      this.dislogid = row.id;
      this.isshow = false;
      this.isshow1 = true;
      this.$http.get("api/system/gnmk/" + row.id).then(res => {
        this.form = res.data.data;
        if (this.form.menuType == "1") {
          this.showselect = true;
        } else {
          this.showselect = false;
        }
        this.form.menuSort = parseInt(res.data.data.menuSort);
        this.form.gncdid = parseInt(res.data.data.gncdid);
      });
    },
    resetform() {
      this.form = {
        menuType: "1", // 模块类型
        isValid: "1", // 状态
        gncdmc: "", // 模块名称
        sjcdid: "0", // 请选择上级模块
        menuSort: "", // 排序号
        gncdid: "", // 菜单id
        menuIcon: "", // icon
        url: "", // 模块url
        menuUuid: "" // 授权标识
      };
    },
    allClick(row) {},
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    xiugai(formName) {
      this.addmodel = "修改功能模块";
      this.isshow = false;
      if (this.form.menuType == "1") {
        this.showselect = true;
      } else {
        this.showselect = false;
      }
    },
    addmodelclose() {
      this.$nextTick(() => {
        this.$refs.form.resetFields();
      });
      this.centerDialogVisible = false;
      this.resetform();
    },
    xqsure(formName) {
      this.centerDialogVisible = false;
      this.resetform();
      this.showselect = true;
      this.$refs[formName].resetFields();
    },
    canceldialog(formName) {
      this.centerDialogVisible = false;
      this.resetform();
      this.$refs[formName].resetFields();
    },
    handleIconClick() {
      this.centerDialogVisibles = true;
    },

    formsubmit() {
      this.$http.post("api/system/gnmk", this.form).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: res.data.message,
            type: "success"
          });
          this.fresh();
          this.centerDialogVisible = false;
          this.$refs[formName].resetFields();
        } else {
          this.$message.error({ message: res.data.message });
        }
      });
    },
    submitForm(formName) {
      if (this.addmodel == "功能模块添加") {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.formsubmit();
          } else {
            return false;
          }
        });
      } else {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.$http.put("api/system/gnmk", this.form).then(res => {
              if (res.data.code == 400) {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              } else {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.$refs[formName].resetFields();
                this.centerDialogVisible = false;
                this.fresh();
              }
            });
          } else {
            return false;
          }
        });
      }
    },
    searchData() {
      this.fresh();
    },
    selectchange() {
      this.fresh();
    },
    clearinput() {
      this.searchField = "";
      this.fresh();
    },
    // 删除
    deleteInfor() {
      if (this.multipleSelection.length == 0) {
        this.$message({
          type: "error",
          message: "请勾选进行删除"
        });
        return false;
      }
      this.$confirm("功能模块删除, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http
            .delete("api/system/gnmk/" + this.multipleSelection.join(","))
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.fresh();
              } else {
                this.$message.error({
                  message: res.data.message
                });
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // 添加
    addNew() {
      this.centerDialogVisible = true;
      this.resetform();
      this.showselect = true;
      this.isshow = false;
      this.isshow1 = false;
      this.addmodel = "功能模块添加";
    },
    radioMenu(val) {
      console.log(this.form);
      if (val == "1") {
        this.readonly = true;
        this.showselect = true;
        this.form.sjcdid = "0";
      } else {
        this.getBysjid();
        this.readonly = false;
        this.showselect = false;
      }
    },
    qthid() {
      if (this.menuType == "1") {
        this.form.sjcdid = "0";
      } else {
        this.getBysjid();
      }
    },
    // 查看详情
    checkInfor(row) {
      this.dislogid = row.id;
      this.centerDialogVisible = true;
      this.isshow = true;
      this.isshow1 = true;
      this.showselect = true;
      this.addmodel = "功能模块详情";
      this.$http.get("api/system/gnmk/" + row.id).then(res => {
        this.form = res.data.data;
        this.form.menuSort = parseInt(res.data.data.menuSort);
        this.form.gncdid = parseInt(res.data.data.gncdid);
        if (res.data.data.menuType !== "1") {
          this.getBysjid();
        }
      });
    },
    // 表格勾选
    handleSelectionChange(val) {
      this.toggleSelection(val);
    },
    toggleSelection(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    getBysjid() {
      this.$http
        .get("api/system/gnmk/getBysjid/" + `${this.form.menuType}`)
        .then(res => {
          this.optionsadd = res.data.data;
          this.form.sjcdid = res.data.data[0].gncdid;
        });
    },
    fresh() {
      this.freshpag = false;
      setTimeout(() => {
        this.freshpag = true;
      }, 500);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    takeList() {
      this.loading = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 1000);
      this.$http
        .post("api/system/gnmk/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          menuType: this.selectvalue,
          query: this.searchField
        })
        .then(res => {
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
          this.loading = false;
          // setTimeout(() => {
          //   this.loading = false;
          // }, 500);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
  }
};
</script>

<style scoped>
.moduleManagement {
  width: 100%;
  padding-top: 7px;
}
.icon {
  height: 400px;
  overflow: hidden;
  overflow-x: hidden;
  overflow-y: auto;
}
</style>
