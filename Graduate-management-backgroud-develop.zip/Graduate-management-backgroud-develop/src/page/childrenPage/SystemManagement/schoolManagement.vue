<!-- 校区信息管理 -->
<template>
  <div class="schoolManagement">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="searchField"
          placeholder="请输入校区号/名称"
          style="width: 180px"
          @keyup.enter.native="searchData"
          @clear="clearinput"
          clearable
          ><i class="el-icon-search el-input__icon" slot="suffix"> </i
        ></el-input>
        <el-button @click="searchData">查询</el-button>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('schoolManagement:add')"
          >添加</el-button
        >
      </div>
    </componment>
    <div class="table">
      <el-table
        :data="tableData"
        border
        ref="multipleTable"
        style="width: 100%;margin-top:10px"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading2"
        element-loading-text="加载中"
      >
        <el-table-column prop="xqh" label="校区号" width="150">
        </el-table-column>
        <el-table-column prop="xqm" label="校区名称"> </el-table-column>
        <el-table-column prop="xqdz" label="校区地址"> </el-table-column>
        <el-table-column prop="xqym" label="校区邮编"> </el-table-column>
        <el-table-column prop="handle" label="操作">
          <template slot-scope="scope">
            <span
              class="tablexg"
              @click="modificationData(scope.row)"
              v-if="$btnAuthorityTest('schoolManagement:update')"
              >修改</span
            ><span
              v-if="
                $btnAuthorityTest('schoolManagement:update') &&
                  $btnAuthorityTest('schoolManagement:delete')
              "
            >
              | </span
            ><span
              @click="deleteData(scope.row)"
              class="tablesc"
              v-if="$btnAuthorityTest('schoolManagement:delete')"
              >删除</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog
      title="添加校区"
      :visible.sync="addDialog"
      :before-close="handleClose"
      width="400px"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form ref="form" :model="form" label-width="100px">
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区号：" :required="true">
              <el-input
                v-model="form.xqh"
                style="width:200px"
                placeholder="请输入"
                type="number"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区名称：" :required="true">
              <el-input
                v-model="form.xqm"
                style="width:200px"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区邮码：">
              <el-input
                v-model="form.xqym"
                style="width:200px"
                placeholder="请输入"
                type="number"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区地址：">
              <el-input
                v-model="form.xqdz"
                type="textarea"
                :rows="2"
                style="width: 200px;"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="addaffirm">保存</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="修改校区"
      :visible.sync="detailsDialog"
      :before-close="handleClose"
      width="400px"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form ref="form" :model="detailsform" label-width="100px">
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区号：" :required="true">
              <el-input
                v-model="detailsform.xqh"
                style="width:200px"
                :disabled="true"
                placeholder="请输入"
                type="number"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区名称：" :required="true">
              <el-input
                v-model="detailsform.xqm"
                style="width:200px"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区邮码：">
              <el-input
                v-model="detailsform.xqym"
                style="width:200px"
                placeholder="请输入"
                type="number"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="校区地址：">
              <el-input
                v-model="detailsform.xqdz"
                type="textarea"
                :rows="2"
                style="width: 200px;"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="detailsDialog = false">取 消</el-button>
        <el-button type="primary" @click="modifaffirm">保存</el-button>
      </span>
    </el-dialog>
    <pagination
      :total="total"
      ref="block"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
  </div>
</template>

<script>
import componment from "@/components/searchcomponment";
import pagination from "@/components/pagination";
export default {
  name: "schoolManagement",
  data() {
    return {
      form: {},
      detailsform: {},
      addDialog: false,
      detailsDialog: false,
      searchField: "", // 搜索的数据
      tableData: [],
      total: 0, // 总数据条数
      rowid: "",
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null
    };
  },
  components: {
    pagination: pagination,
    componment: componment
  },
  methods: {
    clearinput() {
      this.searchField = "";
      this.listQuery.queryPage.pageNum = 1;
      this.takeList();
    },
    modifaffirm() {
      if (this.detailsform.xqm == "") {
        this.$message.error({
          message: "校区号不能为空"
        });
        return false;
      }
      this.$http
        .put("api/system/xxxq/" + this.rowid, this.detailsform)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "修改成功",
              type: "success"
            });
            this.detailsDialog = false;
            this.takeList();
            this.listQuery.queryPage.pageNum = 1;
          } else {
            this.$message.error({
              message: "修改失败"
            });
          }
        });
    }, // 确认添加
    addaffirm() {
      this.$http.post("api/system/xxxq/", this.form).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: "添加成功",
            type: "success"
          });
          this.addDialog = false;
          this.listQuery.queryPage.pageNum = 1;
          this.takeList();
          this.form = {};
        } else {
          this.$message.error({
            message: res.data.message
          });
        }
      });
    }, // 确认添加
    cancel() {
      this.addDialog = false;
      this.form = {};
    }, // 添加
    addNew() {
      this.addDialog = true;
      this.form = {};
    }, // 校区列表
    takeList() {
      this.loading2 = true;
      const params = {};
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/system/xxxq/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.data.info.length > 0 && res.data.code == 200) {
            this.tableData = res.data.data.info;
            this.total = res.data.data.total;
          } else {
            this.$message.error({
              message: res.data.message
            });
            this.tableData = [];
            this.total = 1;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查看校区列表
    searchData() {
      this.listQuery.queryPage.pageNum = 1;
      this.takeList();
    }, // 搜索数据方法
    modificationData(row) {
      this.detailsDialog = true;
      var details = JSON.parse(JSON.stringify(row));
      this.detailsform = details;
      this.rowid = row.id;
    }, // 修改当列数据
    deleteData(row) {
      this.$confirm("删除该校区, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http.delete("api/system/xxxq/" + row.id).then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.takeList();
              this.listQuery.queryPage.pageNum = 1;
            } else {
              this.$message.error({
                message: "删除失败"
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "error",
            message: "已取消删除"
          });
        });
    }, // 删除当列数据
    handleClose(done) {
      this.empty();
      done();
    },
    empty() {
      this.form = {};
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
  }
};
</script>

<style scoped lang="scss">
.schoolManagement {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
  .add {
    text-align: right;
  }
  .table {
    width: 100%;
  }
}
.schoolManagement /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.schoolManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
.schoolManagement /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.schoolManagement /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar {
  //设置整个滚动条宽高
  width: 6px;
  height: 100%;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-thumb {
  //设置滑块
  width: 6px;
  height: 60px;
  background-color: #ccc;
  border-radius: 3px;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-track {
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.5); //设置背景透明
}
</style>
