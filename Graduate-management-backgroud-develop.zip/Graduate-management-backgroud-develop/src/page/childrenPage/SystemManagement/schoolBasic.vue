<template>
  <div class="enrolBasicParams">
    <div class="header">
      <el-row>
        <el-col :span="12">
          <div class="grid-content bg-purple" style="font-size:16px">
            | 学校参数个性化设置
          </div>
        </el-col>
        <el-col :span="12">
          <div
            class="grid-content bg-purple-light"
            style="text-align:right"
          ></div>
        </el-col>
      </el-row>
    </div>
    <div style="display: flex;">
      <div class="box">
        <el-form
          :model="paramsForm"
          ref="ruleForm"
          label-width="100px"
          class="demo-ruleForm"
          style="width:400px;margin:100px auto"
        >
          <el-form-item label="学校代码：" :required="true">
            <el-input v-model="paramsForm.xxdm" :maxlength="5"></el-input>
          </el-form-item>
          <el-form-item label="学校名称：" :required="true">
            <el-input v-model="paramsForm.xxmc"></el-input>
          </el-form-item>
          <el-form-item label="英文名称：">
            <el-input v-model="paramsForm.xxywmc"></el-input>
          </el-form-item>
          <el-form-item label="学校地址：">
            <el-input v-model="paramsForm.xxdz"></el-input>
          </el-form-item>
          <el-form-item label="邮政编码：">
            <el-input v-model="paramsForm.yzbm" :maxlength="6"></el-input>
          </el-form-item>
          <el-form-item label="校 庆 日：">
            <el-date-picker
              v-model="paramsForm.xqr"
              type="date"
              placeholder="选择日期"
              style="width:100%;"
              format="MM-dd"
            ></el-date-picker>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="save" style="width:100%"
              >保存</el-button
            >
          </el-form-item>
        </el-form>
      </div>
      <div class="right">
        <el-form
          :model="paramsForm"
          ref="ruleForm"
          label-width="150px"
          class="demo-ruleForm"
          style="width:700px;margin:40px auto"
        >
          <el-form-item
            :label="item.title"
            v-for="(item, index) in uploadcomponent"
            :key="index"
          >
            <div class="rightimg">
              <div>
                <p>{{ item.content }}</p>
                <p>{{ item.kb }}</p>
                <el-upload
                  class="upload-demo"
                  :action="upload"
                  :data="uploadData"
                  :before-upload="handlebefore"
                  :on-success="handleSuccess"
                  :limit="1"
                  :ref="'uploadcsv' + indexof"
                  accept="image/*"
                  :headers="headtoken"
                  :on-exceed="handleExceed"
                >
                  <el-button
                    style="border-color:rgba(24, 144, 255, 1);color:#1890FF;width:100%"
                    @click="uploadbtn(item, index)"
                    >更换图片</el-button
                  >
                </el-upload>
              </div>
              <div style="margin:10px auto;width:250px;height:120px">
                <img :src="item.url" alt="" style="width:250px;height:120px" />
              </div>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
import { constants } from "fs";
export default {
  name: "schoolBasic",
  data() {
    return {
      // 待提交的基础参数表单数据
      paramsForm: {
        xxdm: "",
        xxmc: "",
        xxywmc: "",
        xxdz: "",
        xqr: "",
        yzbm: "",
        // 服务端登录背景图
        fudlbjt: "",
        // 管理端登录背景图
        gldlbjt: "",
        logo: ""
      },
      formset: null,
      upload: "api/system/upload",
      uploadData: {
        file: ""
      },
      headtoken: {
        userToken: this.$stores.state.token
      },
      uploadcomponent: [
        {
          title: "校园LOGO：",
          content: "请上传格式为.png背景为透明的图片",
          kb: "图片大小需小于200KB",
          url: "",
          id: 1
        },
        {
          title: "管理端登录背景图：",
          content: "请上传图片比例为1920*969像素",
          kb: "图片大小需小于500KB",
          url: "",
          id: 2
        },
        {
          title: "服务端登录背景图：",
          content: "请上传图片比例为1920*969像素",
          kb: "图片大小需小于500KB",
          url: "",
          id: 3
        }
      ],
      indexof: 0
    };
  },
  mounted() {
    this.$http.get("api/system/xxinfo/getInfo").then(res => {
      this.formset = res.data.data;
      if (this.formset == 0) {
        this.paramsForm = {};
      } else {
        this.paramsForm = res.data.data;
        this.$stores.commit("loGogh", this.paramsForm.logo);
        this.uploadcomponent[0].url = this.paramsForm.logo;
        this.uploadcomponent[1].url = this.paramsForm.gldlbjt;
        this.uploadcomponent[2].url = this.paramsForm.fudlbjt;
      }
    });
  },
  methods: {
    handleExceed() {
      this.$message.error("最多只能上传一张图片");
    },
    uploadbtn(val, index) {
      this.indexof = index;
    },
    handlebefore(file) {
      this.uploadData.file = file.name;
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      console.log(file, fileList);
      this.uploadcomponent[this.indexof].url = file.data.url;
      if (file.code == 400) {
        this.$message({
          message: "上传失败，请重新上传",
          type: "error"
        });
        this.$refs["uploadcsv" + this.indexof][this.indexof].clearFiles();
        // this.$refs["uploadcsv" + this.indexof].clearFiles();
        // this.$refs.uploadcsv + this.indexof.clearFiles();
      } else {
        this.$message({
          message: "上传成功",
          type: "success"
        });
        this.save();
        setTimeout(() => {
          this.$refs["uploadcsv" + this.indexof][this.indexof].clearFiles();
          // this.$refs["uploadcsv" + this.indexof].clearFiles();
        }, 500);
      }
    },
    save() {
      if (!this.paramsForm.xxdm || !this.paramsForm.xxmc) {
        return this.$message.error("请将数据填写完整再提交");
      }
      this.paramsForm.logo = this.uploadcomponent[0].url;
      this.$stores.commit("loGogh", this.paramsForm.logo);
      this.paramsForm.gldlbjt = this.uploadcomponent[1].url;
      this.paramsForm.fudlbjt = this.uploadcomponent[2].url;
      if (this.formset == 0) {
        this.$http.post("api/system/xxinfo/save", this.paramsForm).then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
          } else {
            this.$message.error(res.data.message);
          }
        });
      } else {
        this.$http.put("api/system/xxinfo/update", this.formset).then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
    }
  },
  computed: {}
};
</script>
<style lang="scss" scoped>
.enrolBasicParams {
  padding-top: 20px;
  width: 100%;
  .header {
    background: rgba(242, 242, 242, 1);
    line-height: 36px;
    padding: 10px;
  }
  // height: 80vh;
  // display: flex;
  // justify-content: center;
  // align-items: center;
  .box {
    font-size: 14px;
    border: 1px solid rgba(228, 228, 228, 1);
    flex: 1;
    width: 50%;
    .save {
      text-align: center;
    }
    .save-time,
    .set-year {
      display: flex;
      justify-content: space-between;
    }
  }
  .right {
    font-size: 14px;
    width: 50%;
    flex: 1;
    border: 1px solid rgba(228, 228, 228, 1);
    .rightimg {
      display: flex;
    }
  }
}
</style>
