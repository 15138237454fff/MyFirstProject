<!-- 角色权限管理 -->
<template>
  <div class="roleManagement">
    <div
      class="container"
      v-if="$store.state.addtree == false && $store.state.roledata == false"
    >
      <componment>
        <div slot="left" style="flex:1">
          <el-input
            v-model.trim="search"
            placeholder="请输入角色名称"
            style="width: 200px"
            @keyup.enter.native="handleFind"
            @clear="clearinput"
            clearable
            suffix-icon="el-icon-search"
          >
          </el-input>
          <el-button @click="handleFind">查询</el-button>
        </div>
        <div slot="right" style="flex:1">
          <el-button
            type="primary"
            @click="addNewall"
            v-if="$btnAuthorityTest('roleManagement:add')"
            >添加</el-button
          >
          <el-button
            type="danger"
            @click="deltab"
            v-if="$btnAuthorityTest('roleManagement:delete')"
            >删除</el-button
          >
        </div>
      </componment>
      <el-table
        :data="tableData"
        tooltip-effect="dark"
        border
        ref="multipleTable"
        style="width: 100%;"
        @select-all="allClick"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        @row-click="clickRow"
        v-loading="loading"
        element-loading-text="加载中"
        :header-cell-style="$storage.tableHeaderColor"
      >
        <el-table-column
          type="selection"
          width="55"
          :show-overflow-tooltip="true"
        ></el-table-column>
        <el-table-column prop="jsid" label="角色ID"></el-table-column>
        <el-table-column prop="name" label="角色名称"></el-table-column>
        <el-table-column label="功能模块权限">
          <template slot-scope="scope">
            <el-button
              style="color:#409eff;border-color:#409eff"
              v-if="$btnAuthorityTest('roleManagement:limit')"
              @click="addNewxg(scope.row.id, scope.row)"
              >功能模块权限</el-button
            >
          </template>
        </el-table-column>
        <el-table-column label="关联用户">
          <template slot-scope="scope">
            <el-button
              style="color:#409eff;border-color:#409eff"
              v-if="$btnAuthorityTest('roleManagement:connect')"
              @click="userxl(scope.row.id, scope.row)"
              >关联用户</el-button
            >
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <span
              @click="addNew(scope.row.id, scope.row)"
              class="tablexq"
              v-if="$btnAuthorityTest('roleManagement:view')"
              >查看</span
            ><span
              v-if="
                $btnAuthorityTest('roleManagement:view') &&
                  $btnAuthorityTest('roleManagement:update')
              "
            >
              | </span
            ><span
              class="tablexg"
              @click="rolexg(scope.row.id, scope.row)"
              v-if="$btnAuthorityTest('roleManagement:update')"
              >修改</span
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="rolelist"
        v-if="pageshow"
      ></pagination>
    </div>
    <mytree
      v-else-if="$store.state.addtree == true"
      :username="nameuser"
    ></mytree>
    <roledata
      v-else-if="$store.state.roledata == true"
      :username="nameuser"
    ></roledata>
    <el-dialog
      :title="dialogtitle"
      :visible.sync="centerDialogVisible"
      width="400px"
      @close="showdialog"
      :close-on-click-modal="false"
    >
      <el-form ref="form" label-width="100px">
        <el-row>
          <el-col :span="20">
            <el-form-item label="角色ID：" :required="true">
              <el-input
                v-model="jsid"
                placeholder="请输入"
                :disabled="jsidshow"
                type="number"
              ></el-input>
            </el-form-item>
            <el-form-item label="角色名称：" :required="true">
              <el-input v-model="detailsform" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div class="foots">
          <el-button @click="addcancel">取 消</el-button>
          <el-button type="primary" @click="addsure">确 定</el-button>
        </div>
      </span>
    </el-dialog>
    <el-dialog
      title="关联用户"
      :visible.sync="userdialog"
      width="600px"
      :close-on-click-modal="false"
    >
      <div>
        <p class="dialog_p">角色ID：{{ glId }}</p>
        <p class="dialog_p">角色名称：{{ glname }}</p>
        <div class="userdialog">
          <ul class="top">
            <li class="top_li">
              待选用户<span style="color:#409EFF"
                >({{ this.data.length }})</span
              >
            </li>
            <li class="top_li">操作</li>
            <li class="top_li">
              已关联用户<span style="color:#409EFF"
                >({{ this.selectedUsers.length }})</span
              >
            </li>
          </ul>
        </div>
        <div class="diaologbotm">
          <ul class="botm">
            <li class="botm_li" v-loading="loadings">
              <el-input
                placeholder="请输入姓名/用户名"
                v-model.trim="dialogsearch"
                
                style="width:150px;"
                @input="loadsearch(dialogsearch)"
              >
              </el-input>
              <div class="p_li">
                <p v-for="(item, index) in data" style="margin-bottom:15px">
                  <el-checkbox
                    v-model="item.check"
                    @change="checkboxcheck(item, item.value)"
                    >{{ item.label }}</el-checkbox
                  >
                </p>
              </div>
            </li>
            <li class="botm_li" style="padding-top:130px">
              <p style="margin-bottom:15px">
                <el-button plain :disabled="checkdisableds" @click="ybyd"
                  ><i class="el-icon-arrow-left"></i> 到左边</el-button
                >
              </p>
              <p>
                <el-button plain :disabled="checkdisabled" @click="leftcheck"
                  >到右边 <i class="el-icon-arrow-right"></i
                ></el-button>
              </p>
            </li>
            <li class="botm_li">
              <div class="p_li">
                <p
                  v-for="(item, index) in selectedUsers"
                  style="margin-bottom:15px"
                >
                  <el-checkbox
                    v-model="item.check"
                    @change="rightxz(item, item.value)"
                    >{{ item.label }}</el-checkbox
                  >
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <div class="foots">
          <el-button @click="userdialog = false">取 消</el-button>
          <el-button type="primary" @click="glyhsave">保存</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import mytree from "./roleManage/mytree";
import roledata from "./roleManage/roledata";
import componment from "@/components/searchcomponment";
export default {
  name: "roleManagement",
  data() {
    return {
      data: [],
      dialogtitle: "添加",
      search: "", // 搜索的数据
      tableData: [], // 表格数据
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      total: 0,
      currentPage: 1,
      pagesize: 10,
      centerDialogVisible: false,
      detailsform: "",
      radio: "1",
      detailsforms: "",
      radios: "1",
      multipleSelection: [],
      loading: false,
      nameuser: {
        name: "",
        jsid: ""
      },
      jsid: "",
      listQuery: {
        queryPage: {
          pageSize: 15,
          pageNum: 1
        }
      },
      userdialog: false, // 关联用户
      userData: [],
      jsidshow: false,
      jsidlist: "",
      glId: "",
      glname: "",
      direction: "",
      movedKeys: [],
      pageshow: true,
      loadings: false,
      dialogsearch: "",
      checked: false,
      checkdisabled: true,
      checkdisableds: true,
      leftgx: [],
      rightgx: [],
      selectedUsers: [],
      zsinput: [],
      state: "",
      timeout: null,
      direct: ""
    };
  },
  filters: {},
  methods: {
    checkboxcheck(val, id) {
      this.leftgx = [];
      this.data.forEach(el => {
        if (el.check) {
          this.leftgx.push(el.value);
        } else {
          this.leftgx.splice(el.value, 1);
        }
      });
      this.leftgx.length == 0
        ? (this.checkdisabled = true)
        : (this.checkdisabled = false);
    },
    rightxz(val, id) {
      this.rightgx = [];
      this.selectedUsers.forEach(el => {
        if (el.check) {
          this.rightgx.push(el.value);
        } else {
          this.rightgx.splice(el.value, 1);
        }
      });
      this.rightgx.length == 0
        ? (this.checkdisableds = true)
        : (this.checkdisableds = false);
    },
    leftcheck() {
      this.direct = "right";
      var data = JSON.parse(JSON.stringify(this.data));
      data.forEach(el => {
        var indexof = this.leftgx.find(els => els == el.value);
        if (indexof) {
          this.selectedUsers.unshift(el);
          this.data.splice(
            this.data.findIndex(item => item.value === el.value),
            1
          );
          this.zsinput.splice(
            this.zsinput.findIndex(item => item.value === el.value),
            1
          );
        }
      });
      this.selectedUsers.forEach(Element => {
        Element.check = false;
      });
      this.checkdisabled = true;
      this.checkdisableds = true;
      this.rightgx = [];
    },
    ybyd() {
      this.direct = "left";
      var data = JSON.parse(JSON.stringify(this.selectedUsers));
      data.forEach(el => {
        var indexof = this.rightgx.find(els => els == el.value);
        if (indexof) {
          this.data.unshift(el);
          this.selectedUsers.splice(
            this.selectedUsers.findIndex(item => item.value === el.value),
            1
          );
        }
      });
      this.data.forEach(Element => {
        Element.check = false;
      });
      this.checkdisabled = true;
      this.checkdisableds = true;
      this.leftgx = [];
    },
    loadsearch(queryString) {
      this.loadings = true;
      setTimeout(() => {
        this.loadings = false;
      }, 1500);
      var Newitems = [];
      var data = [...this.data];
      data.map(el => {
        if (el.label.search(queryString) != -1) {
          Newitems.push(el);
        }
      });
      queryString ? (this.data = Newitems) : (this.data = this.zsinput);
      console.log(this.zsinput);
    },
    glyhsave() {
      if (this.direct == "") return this.$message.error("请进行用户关联勾选");
      const movedKeys = this.leftgx;
      if (this.direct == "right") {
        this.$http
          .post(
            `api/system/role/saveConnectUser/${movedKeys.toString()}/${
              this.glId
            }`
          )
          .then(res => {
            res.data.code == 200
              ? this.$message.success({
                  message: res.data.message
                })
              : this.$message.error({
                  message: res.data.message
                });
            this.usergllist();
            if (res.data.code == 200) {
              this.fresh();
              this.userdialog = false;
              this.leftgx = [];
              this.direct = "";
            }
          });
      }
      const movedKey = this.rightgx;
      if (this.direct == "left") {
        this.$http
          .delete(
            `api/system/role/delConnectUser/${movedKey.toString()}/${this.glId}`
          )
          .then(res => {
            res.data.code == 200
              ? this.$message.success({
                  message: res.data.message
                })
              : this.$message.error({
                  message: res.data.message
                });
            this.usergllist();
            if (res.data.code == 200) {
              this.fresh();
              this.userdialog = false;
              this.rightgx = [];
              this.direct = "";
            }
          });
      }
    },
    // 删除
    deltab() {
      this.multipleSelection.length === 0
        ? this.$message({
            type: "error",
            message: "请勾选进行删除"
          })
        : this.$confirm("该角色删除, 是否继续?", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(() => {
              this.$http
                .delete(`api/system/role/${this.multipleSelection.join(",")}`)
                .then(res => {
                  if (res.data.code == 200) {
                    this.$message.success({ message: "删除成功" });
                    this.fresh();
                  } else {
                    this.$message.error({ message: res.data.message });
                  }
                });
            })
            .catch(() => {
              this.$message.error({ message: "已取消删除" });
            });
    },
    // 刷新列表
    fresh() {
      this.pageshow = false;
      setTimeout(() => {
        this.pageshow = true;
      }, 500);
      this.rolelist();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    // 查询表单清除
    clearinput() {
      this.search = "";
      this.fresh();
    },
    // 修改
    rolexg(id, row) {
      this.jsidlist = id;
      this.centerDialogVisible = true;
      this.dialogtitle = "修改";
      this.$http.get("api/system/role/" + id).then(res => {
        this.jsid = res.data.data.jsid;
        this.detailsform = res.data.data.name;
        this.jsidshow = true;
      });
    },
    userxl(id, row) {
      this.glId = row.jsid;
      this.glname = row.name;
      this.usergllist();
      // 关联用户
      this.userdialog = true;
      this.checkdisabled = true;
      this.checkdisableds = true;
      this.leftgx = [];
      this.rightgx = [];
      this.dialogsearch = "";
    },
    usergllist() {
      this.userData = [];
      this.data = [];
      this.selectedUsers = [];
      this.$http
        .post("api/system/role/getConnectUser", {
          jsid: this.glId,
          name: this.glname,
          query: ""
        })
        .then(res => {
          if (res.data.data) {
            this.userData = [...res.data.data.countUsers];
            this.userData.forEach((el, index) => {
              this.data.push({
                value: el.id,
                label: `${el.name}(${el.userName})`,
                check: false
              });
            });
            this.zsinput = [...this.data];
            res.data.data.selectedUsers.forEach(el => {
              this.selectedUsers.push({
                value: el.id,
                label: `${el.name}(${el.userName})`,
                check: false
              });
            });
          } else {
            this.$message.error({
              message: "关联数据异常,请刷新"
            });
            this.userdialog = false;
          }
        });
    },
    showdialog() {
      this.formreset();
    },
    addcancel() {
      this.centerDialogVisible = false;
    },
    formreset() {
      this.detailsform = "";
      this.jsid = "";
      this.jsidshow = false;
    },
    addsure() {
      if (!this.jsid) {
        this.$message({
          message: "不能为空",
          type: "error"
        });
        return false;
      }
      if (!this.detailsform) {
        this.$message({
          message: "不能为空",
          type: "error"
        });
        return false;
      }
      if (this.dialogtitle === "添加") {
        this.$http
          .post("api/system/role/save", {
            name: this.detailsform,
            jsid: this.jsid
          })
          .then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.message,
                type: "error"
              });
            } else {
              this.centerDialogVisible = false;
              this.fresh();
              this.formreset();
            }
          });
      }
      if (this.dialogtitle === "修改") {
        this.$http
          .put("api/system/role/", {
            name: this.detailsform,
            jsid: this.jsid,
            id: this.jsidlist
          })
          .then(res => {
            if (res.data.code == 400) {
              this.$message({
                message: res.data.message,
                type: "error"
              });
            } else {
              this.centerDialogVisible = false;
              this.fresh();
              this.formreset();
            }
          });
      }
    },
    addcancels() {
      this.centerDialogVisibles = false;
      this.detailsforms = "";
    },
    handleFind() {
      this.fresh();
    },
    // 选择时触发
    handleSelect(selection, row) {},
    // 点击列表选中
    clickRow(row) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    // 选择列表
    handleSelectionChange(val) {
      this.toggleSelection(val);
    },
    toggleSelection(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.jsid);
        });
      }
    },
    allClick(selection) {}, // 改变一页的条数
    addNew(id, row) {
      this.nameuser.name = row.name;
      this.nameuser.jsid = row.jsid;
      this.$store.state.roledata = true;
      localStorage.setItem("mokuaiid", row.jsid);
      localStorage.setItem("roleids", row.id);
    },
    addNewxg(id, row) {
      this.nameuser.name = row.name;
      this.nameuser.jsid = row.jsid;
      this.$store.state.addtree = true;
      localStorage.setItem("mokuaiid", row.jsid);
      localStorage.setItem("roleids", row.id);
    },
    addNews(id) {
      this.$store.state.roledata = true;
      localStorage.setItem("dataid", id);
    },
    addNewall() {
      this.dialogtitle = "添加";
      this.centerDialogVisible = true;
    },
    rolelist() {
      this.loading = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 1000);
      this.$http
        .post("api/system/role/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.search,
          manage: ""
        })
        .then(res => {
          this.loading = false;
          // 校验接口异常报错
          if (!Array.isArray(res.data.data.list) && !res.data.data.list) {
            return this.$message({
              type: "error",
              message: "数据异常,请刷新重试"
            });
          }
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.rolelist();
  },
  components: {
    mytree,
    pagination,
    componment,
    roledata
  }
};
</script>

<style scoped lang="scss">
.el-dialog .el-dialog__header {
  border-bottom: 1px solid #dcdfe6 !important;
}
.foots {
  text-align: center !important;
}
.roleManagement {
  width: 100%;
  padding-top: 7px;
  .dialog_p {
    margin-bottom: 10px;
  }
  .userdialog {
    width: 100%;
    margin-top: 20px;
    .top {
      display: flex;
      border-right: 1px solid rgba(204, 204, 204, 1);
      background: #f2f2f2;
      .top_li {
        flex: 1;
        text-align: center;
        border: 1px solid rgba(204, 204, 204, 1);
        line-height: 36px;
        border-right: none;
      }
    }
  }
  .diaologbotm {
    height: 400px;
    width: 100%;
    .botm {
      display: flex;
      border-right: 1px solid rgba(204, 204, 204, 1);
      .botm_li {
        flex: 1;
        border: 1px solid rgba(204, 204, 204, 1);
        text-align: center;
        border-right: none;
        border-top: none;
        padding-top: 20px;
        .p_li {
          margin-top: 15px;
          width: 180px;
          height: 300px;
          overflow: hidden;
          overflow: auto;
          font-size: 14px;
          text-align: left;
          padding-left: 5px;
          margin-bottom: 5px;
        }
      }
    }
  }
}
</style>
