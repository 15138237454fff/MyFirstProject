<!-- 通知公告 -->
<template>
  <div class="notification">
    <template
      v-if="
        $store.state.addnotific == false &&
          $store.state.modifnotific == false &&
          !returnparent
      "
    >
      <componment>
        <div slot="left">
          <el-input
            v-model="searchField"
            placeholder="请输入标题"
            style="width:200px"
            @keyup.enter.native="searchData"
            clearable
            @clear="clearinput"
            suffix-icon="el-icon-search"
          ></el-input>
          <el-button @click="searchData">查询</el-button>
          <el-select
            v-model="status"
            filterable
            placeholder="请选择"
            style="width: 200px;"
            @change="selectchange"
            
          >
            <el-option
              v-for="(item, index) in statusList"
              :key="index"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div slot="right">
          <el-button
            type="primary"
            @click="addNew"
            v-if="$btnAuthorityTest('notification:add')"
            >添加</el-button
          >
          <el-button
            type="danger"
            @click="deleteInfor"
            v-if="$btnAuthorityTest('notification:delete')"
            >删除</el-button
          >
          <el-button
            type="primary"
            @click="handlePublish"
            plain
            v-if="$btnAuthorityTest('notification:publish')"
            >{{ fbxq }}</el-button
          >
        </div>
      </componment>
      <el-table
        v-loading="loading"
        element-loading-text="加载中"
        @selection-change="mySelect"
        @select-all="allClick"
        @row-click="clickRow"
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        border
        :header-cell-style="$storage.tableHeaderColor"
        style="width: 100%;"
        :height="tableHeight"
      >
        <el-table-column
          :show-overflow-tooltip="true"
          type="selection"
          width="55"
        >
        </el-table-column>
        <el-table-column prop="bt" label="标题">
          <template slot-scope="scope">
            <div>
              <img
                src="@/assets/zd.png"
                alt=""
                v-if="scope.row.zt == '1' && scope.row.ggzd == '1'"
                class="img"
              /><span>{{ scope.row.bt }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="发送对象">
          <template slot-scope="scope">
            <span v-if="scope.row.fsdx == 4 || scope.row.fsdx == 5">
              {{ scope.row.fsdxsmc }}
            </span>
            <span v-else>{{ scope.row.fsdxmc }}</span>
          </template>
        </el-table-column>
        <el-table-column
          :show-overflow-tooltip="true"
          prop="cjrgh"
          label="创建人"
        >
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" label="发布时间">
          <template slot-scope="scope">
            <span v-if="scope.row.zt == '1'">
              {{ scope.row.noticeUdate }}
            </span>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="zt" label="状态">
          <template slot-scope="scope">
            <span v-if="scope.row.zt == '0'" style="color:#ff9a32">
              未发布
            </span>
            <span v-if="scope.row.zt == '1'" style="color:#52C41A">
              已发布
            </span>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <span
              class="tablexq"
              @click="xgInfor(scope.row)"
              v-if="$btnAuthorityTest('notification:view')"
              >查看</span
            >
            <!-- <span
              v-if="
                (scope.row.zt == '0' ||
                  (scope.row.zt == '1' &&
                    (scope.row.ggzd == '1' || scope.row.ggzd == '0'))) &&
                  $btnAuthorityTest('notification:update') &&
                  $btnAuthorityTest('notification:top')
              "
            >
              |
            </span> -->
            <span
              class="tablexg"
              v-if="
                scope.row.zt == '0' && $btnAuthorityTest('notification:update')
              "
              @click="checkInfor(scope.row)"
              >修改</span
            >
            <span
              class="tablezd"
              v-if="
                scope.row.zt == '1' &&
                  scope.row.ggzd == '1' &&
                  $btnAuthorityTest('notification:top')
              "
              @click="zdcz(scope.row)"
              >取消置顶</span
            >
            <span
              class="tableqxzd"
              v-if="
                scope.row.zt == '1' &&
                  scope.row.ggzd == '0' &&
                  $btnAuthorityTest('notification:top')
              "
              @click="qxcz(scope.row)"
              >置顶</span
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="takeList"
      ></pagination>
      <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
        <p class="hr"></p>
        <span>确定删除已选记录</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="deleteDialog = false">取 消</el-button>
          <el-button type="primary" @click="closeDia">确 定</el-button>
        </span>
      </el-dialog>
    </template>
    <addnotific v-else-if="$store.state.addnotific == true"></addnotific>
    <modifnotific
      v-else-if="$store.state.modifnotific == true"
      :rowid="rowid"
    ></modifnotific>
    <modifnotificxq
      v-else-if="returnparent"
      @returnparents="returnparenting"
      :rowid="rowid"
    ></modifnotificxq>
  </div>
</template>
<script>
import addnotific from "./notification/addnotific";
import modifnotific from "./notification/modifnotific";
import modifnotificxq from "./notification/modifnotificxq";
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "notification",
  data() {
    return {
      returnparent: false,
      deleteDialog: false,
      status: null,
      statusList: [], // 状态列表
      total: 0, // 总条数
      currentPage: 1,
      pagesize: 10,
      searchField: "", // 查看数据搜索参数
      tableData: [],
      tableHeight: null,
      clientHeight: 0,
      offsetTop: 0,
      deleteList: [],
      loading: false,
      listQuery: {
        queryPage: {
          pageSize: 15,
          pageNum: 1
        }
      },
      fbxq: "发布"
    };
  },
  methods: {
    xgInfor(row) {
      console.log(row);
      this.returnparent = true;
      this.rowid = row.id;
    },
    returnparenting(val) {
      this.returnparent = val;
      console.log(val);
    },
    zdcz(row) {
      this.$http.put("api/system/notice/qxzd/" + row.id).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: res.data.message,
            type: "success"
          });
        } else {
          this.$message.error({
            message: res.data.message
          });
        }
        this.fresh();
      });
    },
    qxcz(row) {
      this.$http.put("api/system/notice/zd/" + row.id).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: res.data.message,
            type: "success"
          });
        } else {
          this.$message.error({
            message: res.data.message
          });
        }
        this.fresh();
      });
    },
    fresh() {
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.fbxq = "发布";
    },
    selectchange() {
      this.fresh();
    },
    clearinput() {
      this.searchField = "";
      this.fresh();
    },
    deleteInfor() {
      this.deleteList.length != 0
        ? (this.deleteDialog = true)
        : this.$message.error({ message: "请选择数据！" });
    }, // 删除数据
    closeDia() {
      this.$http
        .delete("api/system/notice/" + this.deleteList.toString())
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.deleteDialog = false;
            this.fresh();
          } else {
            this.$message.error({
              message: res.data.message
            });
          }
        });
    }, // 确认删除
    takeList() {
      this.loading = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 1000);
      this.$http
        .post("api/system/notice/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField,
          zt: this.status
        })
        .then(res => {
          this.loading = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }, // 查询通知公告列表
    searchData() {
      this.fresh();
    }, // 搜索数据
    addNew() {
      this.$store.state.addnotific = true;
    }, // 新增
    deleteInfo() {}, // 删除
    handlePublish() {
      var flag = true;
      console.log(this.deleteList);
      if (this.deleteList.length == 0) {
        this.$message.error({ message: "请选择一条数据！" });
        return "";
      }
      if (this.fbxq === "发布") {
        this.$http
          .put("api/system/notice/fb/" + this.deleteList.toString())
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "发布成功",
                type: "success"
              });
              this.fresh();
            } else {
              this.$message.error({ message: res.data.message });
            }
          });
      }

      if (this.fbxq === "取消发布") {
        this.tableData.forEach(el => {
          this.deleteList.forEach(element => {
            if (flag) {
              if (el.id === element) {
                if (el.zt == 0) {
                  this.$message.error({
                    message: "发布与取消发布不能同时操作"
                  });
                  flag = false;
                }
              }
            }
          });
        });
        if (flag) {
          this.$http
            .put("api/system/notice/qxfb/" + this.deleteList.toString())
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: "取消发布成功",
                  type: "success"
                });
              } else {
                this.$message.error({ message: res.data.message });
              }
              this.fresh();
            });
        }
      }
    }, // 发布
    checkInfor(row) {
      this.rowid = row.id;
      this.$store.state.modifnotific = true;
    }, // 查看详情
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    mySelect(selection) {
      if (selection.length == 0) {
        this.fbxq = "发布";
      } else {
        if (selection[0].zt == "0") {
          this.fbxq = "发布";
        }
        if (selection[0].zt == "1") {
          this.fbxq = "取消发布";
        }
      }
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
    }, // 用户勾选table中的某一项
    allClick(selection) {},
    handleClose(done) {
      done();
    },
    userlist() {
      const arr = [
        {
          value: null,
          label: "全部状态"
        },
        {
          value: "0",
          label: "未发布"
        },
        {
          value: "1",
          label: "已发布"
        }
      ];
      this.statusList = arr;
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.userlist();
  },
  components: {
    addnotific,
    modifnotific,
    pagination,
    componment,
    modifnotificxq
  }
};
</script>

<style scoped lang="scss">
.notification {
  width: 100%;
  padding-top: 7px;
  .el-table .cell {
    line-height: 15px;
  }
  .tablexq:not(:last-child) {
    padding-right: 5px;
    border-right: 1px solid #666;
  }
  .img {
    position: absolute;
    top: 0;
    width: 30px;
    height: 30px;
    left: 0;
  }
}
</style>
