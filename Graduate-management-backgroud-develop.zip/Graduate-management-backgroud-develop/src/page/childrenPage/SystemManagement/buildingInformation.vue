<!-- 楼栋信息管理 -->
<template>
  <div class="buildingInformation">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="searchField"
          placeholder="请输入楼栋名称"
          style="width: 200px"
          @keyup.enter.native="searchData"
          @click="searchData"
          clearable
          @clear="searchData"
        >
          <i class="el-icon-search el-input__icon" slot="suffix"> </i>
        </el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('buildingInformation:add')"
          >添加</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column prop="ldh" label="楼栋号" width="150"> </el-table-column>
      <el-table-column prop="ldmc" label="楼栋名称"> </el-table-column>
      <el-table-column prop="ssdwMc" label="所属单位"> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexg"
            @click="modificHandle(scope.row)"
            v-if="$btnAuthorityTest('buildingInformation:update')"
            >修改</span
          ><span
            v-if="
              $btnAuthorityTest('buildingInformation:update') &&
                $btnAuthorityTest('buildingInformation:delete')
            "
          >
            | </span
          ><span
            @click="deleteHandle(scope.row)"
            class="tablesc"
            v-if="$btnAuthorityTest('buildingInformation:delete')"
            >删除</span
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <el-dialog
      :title="userTitle"
      :visible.sync="addDialog"
      :before-close="handleClose"
      width="380px"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form ref="numberValidateForm" :model="form" label-width="100px">
        <el-row>
          <el-col :span="20">
            <el-form-item label="楼栋号：" :required="true">
              <el-input
                v-model="form.ldh"
                style="width:200px"
                :disabled="addShow == false"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="楼栋名称：" :required="true">
              <el-input
                v-model="form.ldmc"
                style="width:200px"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="所属单位：" :required="true">
              <el-select
                v-model="form.ssdw"
                filterable
                placeholder="请选择"
                style="width: 200px;"
                multiple
                
              >
                <el-option
                  v-for="item in worksList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer" v-show="modificationShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="modificationNew">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-show="addShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="affirmNew">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import componment from "@/components/searchcomponment";
export default {
  name: "buildingInformation",
  data() {
    return {
      form: {
        ssdw: [],
        ldh: "",
        ldmc: ""
      },
      addDialog: false,
      addShow: true,
      modificationShow: false,
      userTitle: "添加楼栋",
      searchField: "", // 搜索的数据
      tableData: [],
      worksList: [], // 所属单位列表
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      rowid: "",
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      }
    };
  },
  components: {
    pagination,
    componment
  },
  methods: {
    takeList() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/system/xtld/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField
        })
        .then(res => {
          this.loading2 = false;
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 500);
          if (res.data.code == 200 && res.data.data.info.length > 0) {
            this.tableData = res.data.data.info;
            this.total = res.data.data.total;
          } else {
            this.tableData = [];
            this.total = 1;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查看校区列表
    takeList3() {
      this.$http.get("api/system/dept/selectAll").then(res => {
        this.worksList = res.data.data;
      });
    }, // 获取组织机构
    modificHandle(row) {
      this.addDialog = true;
      this.userTitle = "修改楼栋";
      this.modificationShow = true;
      this.addShow = false;
      this.form = row;
      this.form.ssdw = JSON.parse(JSON.stringify(row.ssdw)).split(",");
      // this.form = JSON.parse(JSON.stringify(row));
      this.rowid = this.form.id;
      this.takeList3();
    }, // 点击修改按钮
    deleteHandle(row) {
      this.$confirm("删除该楼栋, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http.delete("api/system/xtld/" + row.id).then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.takeList();
            } else {
              this.$message.error({
                message: "删除失败"
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }, // 点击删除按钮
    searchData() {
      this.takeList();
    }, // 搜索数据方法
    addNew() {
      console.log(this.form);
      // this.form.ssdw = [];
      this.addDialog = true;
      this.userTitle = "添加楼栋";
      this.modificationShow = false;
      this.addShow = true;
      this.takeList3();

      console.log(this.form.ssdw);
    }, // 添加信息
    modificationNew() {
      this.form.ssdw = this.form.ssdw.toString();
      this.$http.put("api/system/xtld/" + this.rowid, this.form).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: "修改成功",
            type: "success"
          });
          this.addDialog = false;
          this.takeList();
          this.empty();
        } else {
          this.$message.error({
            message: res.data.message
          });
          this.empty();
        }
      });
    }, // 确认修改
    affirmNew() {
      this.form.ssdw = this.form.ssdw.toString();
      this.$http.post("api/system/xtld/", this.form).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: "添加成功",
            type: "success"
          });
          this.addDialog = false;
          this.takeList();
          this.empty();
        } else {
          this.$message.error({
            message: res.data.message
          });
          this.empty();
        }
      });
    }, // 确认添加
    cancel() {
      this.addDialog = false;
    }, // 取消添加或修改
    changePage(index) {
      this.takeList(index);
    }, // 切换页码
    sizeChange(value) {
      this.pagesize = value;
      this.takeList(1);
    }, // 改变一页的条数
    handleClose(done) {
      this.empty();
      done();
    }, // 关闭弹出框
    empty() {
      this.form = { ssdw: [] };
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.takeList3();
  }
};
</script>

<style scoped lang="scss">
.buildingInformation {
  width: 100%;
  padding-top: 7px;
}
.buildingInformation /deep/ .el-dialog__body {
  padding: 20px 20px;
  color: #606266;
  font-size: 14px;
  word-break: break-all;
}
.buildingInformation /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.buildingInformation /deep/ .dialog-footer button {
  margin: 0 20px;
}
.buildingInformation /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
.buildingInformation /deep/ .el-dialog__body {
  padding: 20px 20px;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar {
  //设置整个滚动条宽高
  width: 6px;
  height: 100%;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-thumb {
  //设置滑块
  width: 6px;
  height: 60px;
  background-color: #ccc;
  border-radius: 3px;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-track {
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.5); //设置背景透明
}
</style>
