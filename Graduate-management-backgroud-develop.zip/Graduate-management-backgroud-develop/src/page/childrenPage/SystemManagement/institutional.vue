<!-- 组织机构管理 -->
<template>
  <div class="institutional">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="searchField"
          placeholder="请输入机构名称"
          style="width: 200px"
          @keyup.enter.native="searchData"
          @clear="clearinput"
          clearable
        >
          <i class="el-icon-search el-input__icon" slot="suffix"> </i>
        </el-input>
        <el-button @click="searchData" style="margin-left:5px">查询</el-button>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('institutional:add')"
          >添加</el-button
        >
        <el-button
          @click="exportInfo"
          class="nobackground"
          v-if="$btnAuthorityTest('institutional:export')"
          >导出</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column prop="dwh" label="机构代码" width="150">
      </el-table-column>
      <el-table-column prop="dwmc" label="机构名称"> </el-table-column>
      <el-table-column prop="dwjc" label="机构简称"> </el-table-column>
      <el-table-column prop="lsdwmc" label="所属单位"> </el-table-column>
      <el-table-column prop="dwlbmc" label="单位类别">
        <template slot-scope="scope">
          {{ getDictValue(scope.row.dwlbm, "dwlb") }}
        </template>
      </el-table-column>
      <el-table-column prop="ssxqmc" label="所属校区"> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexg"
            @click="modificHandle(scope.row)"
            v-if="$btnAuthorityTest('institutional:update')"
            >修改</span
          ><span
            v-if="
              $btnAuthorityTest('institutional:update') &&
                $btnAuthorityTest('institutional:delete')
            "
          >
            | </span
          ><span
            @click="deleteHandle(scope.row)"
            class="tablesc"
            v-if="$btnAuthorityTest('institutional:delete')"
            >删除</span
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
      ref="pagination"
      v-if="sonRefresh"
    ></pagination>
    <el-dialog
      :title="userTitle"
      :visible.sync="addDialog"
      :before-close="handleClose"
      :close-on-click-modal="false"
    >
      <p class="hr"></p>
      <el-form ref="numberValidateForm" :model="form" label-width="100px">
        <el-row>
          <el-col :span="10">
            <el-form-item label="机构代码：" :required="true">
              <el-input
                v-model="form.dwh"
                :disabled="userTitle != '添加组织机构'"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="机构名称：" :required="true">
              <el-input v-model="form.dwmc" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="机构简称：">
              <el-input v-model="form.dwjc" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="所属校区：" :required="true">
              <el-select
                v-model="form.ssxqdm"
                filterable
                placeholder="请选择"
                
              >
                <el-option
                  v-for="item in ssxqdmeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="10" :offset="2">
            <el-form-item label="英文名称：">
              <el-input v-model="form.dwywmc" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col> -->
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属机构：">
              <el-select
                v-model="form.lsdwm"
                filterable
                placeholder="请选择"
                
              >
                <el-option
                  v-for="item in organizationList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="单位类别：" :required="true">
              <el-select
                v-model="form.dwlbm"
                filterable
                placeholder="请选择"
                
              >
                <el-option
                  v-for="item in typeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer" v-show="modificationShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="modificationNew">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-show="addShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="affirmNew">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import "@/components/common/buttoncommon.css";
import componment from "@/components/searchcomponment";
export default {
  name: "institutional",
  data() {
    return {
      form: {
        // dwyxbs: 1,
        dwh: "",
        dwmc: "",
        ssxqdm: "",
        dwlbm: ""
      },
      addDialog: false,
      addShow: true,
      modificationShow: false,
      userTitle: "添加组织机构",
      searchField: "", // 搜索的数据
      tableData: [],
      typeList: [],
      organizationList: [], // 所属机构
      total: 0, // 总数据条数
      tableHeight: null, // 表格高度
      rowid: "",
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      sonRefresh: true,
      ssxqdmeList: []
    };
  },
  components: { pagination: pagination, componment: componment },
  methods: {
    clearinput() {
      this.searchField = "";
      this.paginationfresh();
    },
    paginationfresh() {
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
      this.sonRefresh = false;
      this.$nextTick(() => {
        this.sonRefresh = true;
      });
      this.takeList();
    },
    takeList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 500);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/system/dept/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.searchField
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 200) {
            this.tableData = res.data.data.info;
            this.total = res.data.data.total;
          } else {
            this.tableData = [];
            this.total = 1;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }, // 查看校区列表
    takeList2() {
      this.$http.get("api/system/dept/select/lb").then(res => {
        this.typeList = res.data.data;
      });
      this.$http.get("api/system/xxxq/list").then(res => {
        this.ssxqdmeList = res.data.data;
      });
    }, // 获取单位类别
    takeList3() {
      this.$http.get("api/system/dept/selectAll").then(res => {
        this.organizationList = res.data.data;
      });
    }, // 获取组织机构
    modificHandle(row) {
      this.addDialog = true;
      this.userTitle = "修改组织机构";
      this.modificationShow = true;
      this.addShow = false;
      this.$http.get("api/system/dept/obj/" + row.dwh).then(res => {
        this.form = res.data.data;
        // this.form.dwyxbs = parseInt(res.data.data.dwyxbs)
      });
      this.rowid = row.id;
    }, // 点击修改按钮
    deleteHandle(row) {
      this.$confirm("删除该机构, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$http.delete("api/system/dept/" + row.id).then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.paginationfresh();
            } else {
              this.$message.error({
                message: res.data.message
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }, // 点击删除按钮
    searchData() {
      this.paginationfresh();
    }, // 搜索数据方法
    addNew() {
      this.addDialog = true;
      this.userTitle = "添加组织机构";
      this.modificationShow = false;
      this.addShow = true;
      this.empty();
    }, // 添加信息
    modificationNew() {
      var flag = true;
      let dwh = ["dwh", "dwlbm", "dwmc", "ssxqdm"];
      dwh.map(v => {
        if (flag) {
          if (!this.form[v]) {
            this.$message.error("请添加完整在提交");
            flag = false;
          }
        }
      });
      if (flag) {
        this.$http.put("api/system/dept/" + this.rowid, this.form).then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "修改成功",
              type: "success"
            });
            this.addDialog = false;
            this.paginationfresh();
            this.empty();
          } else {
            this.$message.error({
              message: "修改失败"
            });
          }
        });
      }
    }, // 确认修改
    // 表单验证
    formValidation() {},
    affirmNew() {
      var flag = true;
      let dwh = ["dwh", "dwlbm", "dwmc", "ssxqdm"];
      dwh.map(v => {
        if (flag) {
          if (!this.form[v]) {
            this.$message.error("请添加完整在提交");
            flag = false;
          }
        }
      });
      if (flag) {
        this.$http.post("api/system/dept/", this.form).then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "添加成功",
              type: "success"
            });
            this.paginationfresh();
            this.addDialog = false;
            this.empty();
            this.takeList2();
            this.takeList3();
          } else {
            this.$message.error({
              message: res.data.message
            });
          }
        });
      }
    }, // 确认添加
    cancel() {
      this.addDialog = false;
    }, // 取消添加或修改
    exportInfo() {}, // 导出数据
    empty() {
      this.form = {
        dwh: "",
        dwmc: "",
        ssxqdm: "",
        dwlbm: ""
      };
    },
    handleClose(done) {
      this.empty();
      done();
    } // 关闭弹出框
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.takeList2();
    this.takeList3();
  }
};
</script>

<style scoped lang="scss">
.institutional {
  width: 100%;
  padding-top: 7px;
  .red {
    color: #f56c6c;
  }
}
.institutional /deep/ .el-dialog__body {
  padding: 20px 20px;
  color: #606266;
  font-size: 14px;
  word-break: break-all;
}
.institutional /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.institutional /deep/ .dialog-footer button {
  margin: 0 20px;
}
.institutional /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.institutional /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar {
  //设置整个滚动条宽高
  width: 6px;
  height: 100%;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-thumb {
  //设置滑块
  width: 6px;
  height: 60px;
  background-color: #ccc;
  border-radius: 3px;
}
.el-table /deep/ .el-table__body-wrapper::-webkit-scrollbar-track {
  border-radius: 10px;
  background-color: rgba(255, 255, 255, 0.5); //设置背景透明
}
</style>
