<template>
  <div class="addstaffDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
      <el-button type="primary" @click="saveData" style="float: right; margin: 10px 10px 0 0;">保存</el-button>
    </div>
    <div class="teacher-details">
      <el-form :model="form" label-width="200px" ref="form">
        <table>
          <tr>
            <td class="listcss"><span style="color:red">*</span>工号：</td>
            <td>
              <el-input v-model="form.gh" style="width:200px"></el-input>
            </td>
            <td class="listcss"><span style="color:red">*</span>姓名：</td>
            <td>
              <el-input v-model="form.xm" style="width:200px"></el-input>
            </td>
            <td class="listcss"> 英文名：</td>
            <td>
              <el-input v-model="form.ywxm" style="width:200px"></el-input>
            </td>
            <td rowspan="3"><img :src="form.zp" alt="" style="width:60px;height:60px;border:none"></td>
          </tr>
          <tr>
            <td class="listcss"><span style="color:red">*</span>性别：</td>
            <td>
              <el-select v-model="form.xbm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in sexList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>民族：</td>
            <td>
              <el-select v-model="form.mzm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in nationList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span> 出生年月:</td>
            <td>
              <el-date-picker v-model="form.csrq" value-format="yyyy-MM-dd" type="date" placeholder="选择日期" style="width:200px">
              </el-date-picker>
            </td>
          </tr>
          <tr>
            <td class="listcss"><span style="color:red">*</span>婚姻状况：</td>
            <td>
              <el-select v-model="form.hyzkm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in marryList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>健康状况：</td>
            <td>
              <el-select v-model="form.jkzkm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in healthList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>政治面貌：</td>
            <td>
              <el-select v-model="form.zzmmm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in politicsList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="listcss"><span style="color:red">*</span>移动电话：</td>
            <td>
              <el-input v-model="form.yddh" style="width:200px"></el-input>
            </td>
            <td class="listcss">办公室电话：</td>
            <td>
              <el-input v-model="form.bgsdh" style="width:200px"></el-input>
            </td>
            <td class="listcss"><span style="color:red">*</span>电子邮箱：</td>
            <td colspan="2">
              <el-input v-model="form.dzyx"></el-input>
            </td>
          </tr>
          <tr>
            <td class="listcss"><span style="color:red">*</span>国籍：</td>
            <td>
              <el-select v-model="form.gjdqm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in countryList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>证件类型：</td>
            <td>
              <el-select v-model="form.sfzjlxm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in voucherTypeList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>证件号码：</td>
            <td colspan="2">
              <el-input v-model="form.sfzjh"></el-input>
            </td>
          </tr>
          <tr>
            <td class="listcss">籍贯：</td>
            <td>
              <el-cascader v-model="form.jg" :options="nativeList" :props="{ emitPath:false,expandTrigger: 'hover' }"></el-cascader>
            </td>
            <td class="listcss">职务：</td>
            <td>
              <el-select v-model="form.zw" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in dutyList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss">职称：</td>
            <td colspan="2">
              <el-input v-model="form.zc"></el-input>
            </td>
          </tr>
          <tr>
            <td class="listcss"><span style="color:red">*</span>所属单位：</td>
            <td>
              <el-select v-model="form.ssyxh" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in deptList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>教职工类别：</td>
            <td>
              <el-select v-model="form.jzglbm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in teacherTypeList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>编制类别：</td>
            <td colspan="2">
              <el-select v-model="form.bzlbm" filterable placeholder="请选择" clearable>
                <el-option v-for="(item,index) in typeList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="listcss">参加工作年月日：</td>
            <td>
              <el-date-picker v-model="form.cjgzny" value-format="yyyy-MM-dd" type="date" placeholder="选择日期">
              </el-date-picker>
            </td>
            <td class="listcss">最高学历：</td>
            <td>
              <el-select v-model="form.zgxlm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in educationList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
            <td class="listcss"><span style="color:red">*</span>当前状态：</td>
            <td colspan="2">
              <el-select v-model="form.dqztm" filterable placeholder="请选择" style="width: 200px;" clearable>
                <el-option v-for="(item,index) in statusList" :key="index" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </td>
          </tr>
        </table>
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  name: "addstaffDetails",
  props: ["deptList"],
  data() {
    return {
      form: {
        gh: "",
        xm: "",
        xbm: "",
        mzm: "",
        csrq: "",
        hyzkm: "",
        jkzkm: "",
        zzmmm: "",
        yddh: "",
        dzyx: "",
        gjdqm: "",
        sfzjlxm: "",
        sfzjh: "",
        ssyxh: "",
        jzglbm: "",
        bzlbm: "",
        dqztm: ""
      },
      sexList: [
        {
          value: 1,
          label: "男"
        },
        {
          value: 2,
          label: "女"
        },
        {
          value: 0,
          label: "未知性别"
        },
        {
          value: 9,
          label: "未说明的性别"
        }
      ], // 性别列表
      nationList: [], // 民族列表
      marryList: [], // 婚姻状况列表
      healthList: [], // 健康状况列表
      politicsList: [], // 政治面貌列表
      countryList: [], // 国籍列表
      voucherTypeList: [], // 证件类型列表
      nativeList: [], // 籍贯列表
      dutyList: [], // 职务列表
      works: [], // 所属单位列表
      teacherTypeList: [], // 教职工类别列表
      typeList: [], // 编制类别列表
      educationList: [], // 最高学历列表
      statusList: [], // 当前状态列表
      worksList: [] // 所属单位列表
    };
  },
  methods: {
    saveData() {
      const form = this.form;
      let flag = true;
      Object.keys(form).forEach(el => {
        if (flag) {
          if (!this.form[el]) {
            this.$message.error("请完整填写内容在提交");
            flag = false;
          }
        }
      });
      if (flag) {
        this.$http.post("api/system/jzg/save", this.form).then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "保存成功"
            });
            this.$emit("staffadd", false);
            this.$parent.takeList();
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
    }, // 保存
    exitList() {
      this.$emit("staffadd", false);
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    takeList() {
      this.$http.get("api/system/dict/select/all").then(res => {
        this.typeList = res.data.data.bzlb;
        this.marryList = res.data.data.hyzk;
        this.nationList = res.data.data.mz;
        this.healthList = res.data.data.jkzk;
        this.voucherTypeList = res.data.data.zjlx;
        this.dutyList = res.data.data.zw;
        this.teacherTypeList = res.data.data.jzglb;
        this.educationList = res.data.data.xl;
        this.politicsList = res.data.data.zzmm;
        this.statusList = res.data.data.jzgzt;
        this.countryList = res.data.data.sjgg;
      });
    },
    // 籍贯数据
    getOrigoList() {
      this.$http
        .get("api/system/dict/select/origo")
        .then(res => {
          this.nativeList = res.data.data;
        })
        .catch(function(err) {
          console.log(err);
        });
    }
  },
  mounted() {
    // 获取全部数据字典
    this.takeList();
    // 获取籍贯数据
    this.getOrigoList();
  }
};
</script>

<style scoped lang="scss">
.fr {
  float: right;
  margin: 10px 15px 0 0;
}
.fl {
  float: left;
}
.addstaffDetails {
  .top-title {
    width: 100%;
    height: 60px;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  p.title {
    margin: 0;
    padding: 0;
    height: 50px;
    color: #333;
    line-height: 50px;
    width: 100%;
    span.circle {
      color: #2779e3;
      margin-right: 5px;
    }
  }
  .teacher-details {
    width: 100%;
    margin-top: 50px;
    .el-row {
      height: 50px;
      width: 100%;
      .el-col {
        height: 100%;
        border: 1px solid #eee;
        border-bottom: none;
        .el-input,
        .el-select {
          width: 90% !important;
          margin-left: 5%;
          position: relative;
          top: 4px;
        }
        .lookOnly /deep/ .el-input__inner {
          background: none;
          border: none;
        }
      }
    }
  }
  .hadleButton {
    width: 10%;
    float: left;
    position: relative;
    top: 23px;
    left: 15px;
  }
}

.addstaffDetails /deep/ .el-form-item__label {
  line-height: 50px;
  border-right: 1px solid #eee;
  height: 100%;
  background: #f5f5f5;
}
.addstaffDetails /deep/ .el-form-item {
  margin-bottom: 0;
  height: 100%;
}
.addstaffDetails /deep/ .el-form-item__label {
  text-align: center;
}
table {
  border-collapse: collapse;
  width: 100%;
  color: #444;
  font-size: 14px;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 400;
  margin-bottom: 20px;
  line-height: 48px;

  thead {
    height: 60px !important;
    border: 1px solid #e0e0e0;
  }
  tr {
    border: 1px solid #e0e0e0;
  }
  th,
  td {
    border: 1px solid #e0e0e0;
    height: 48px;
    padding-left: 5px;
    text-align: center;
  }
  .left_cont {
    text-align: left;
    padding-left: 10px;
    font-weight: bold;
  }
  .listcss {
    width: 180px;
    background: #f5f5f5;
  }
}
</style>
