<!-- 用户信息管理 -->
<template>
  <div class="userManagement">
    <componment>
      <div slot="left" style="flex:1">
        <el-input
          v-model="search"
          placeholder="请输入用户名/姓名"
          @keyup.enter.native="handleFind"
          clearable
          @clear="clearinput"
          style="width:200px"
          suffix-icon="el-icon-search"
        ></el-input>
        <el-button @click="handleFind">查询</el-button>
        <el-select v-model="role" placeholder="请选择角色" @change="takeList()">
          <el-option
            v-for="item in roleList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
        <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
          <p class="hr"></p>
          <span>确定删除已选用户信息</span>
          <span slot="footer" class="dialog-footer">
            <el-button @click="deleteDialog = false">取 消</el-button>
            <el-button type="primary" @click="closeDia">确 定</el-button>
          </span>
        </el-dialog>
      </div>
      <div slot="right" style="flex:1">
        <el-button
          @click="synchroniz"
          style="border:1px solid #409dff;color:#409dff"
          v-if="$btnAuthorityTest('userManagement:sync')"
          >同步用户数据</el-button
        >
        <el-button
          type="primary"
          @click="addNew"
          v-if="$btnAuthorityTest('userManagement:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="deleteHandle"
          v-if="$btnAuthorityTest('userManagement:delete')"
          >删除</el-button
        >
        <el-button
          @click="resetHandle"
          v-if="$btnAuthorityTest('userManagement:init')"
          >密码初始化</el-button
        >
      </div>
    </componment>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      ref="multipleTable"
      :header-cell-style="$storage.tableHeaderColor"
      style="width: 100%;"
      @selection-change="handleSelectionChange"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
      class="table"
    >
      <el-table-column
        type="selection"
        width="55"
        :show-overflow-tooltip="true"
      >
      </el-table-column>
      <el-table-column prop="userName" label="用户名"> </el-table-column>
      <el-table-column prop="name" label="姓名"> </el-table-column>
      <el-table-column
        prop="deptName"
        label="所属机构"
        :show-overflow-tooltip="true"
      >
        <template slot-scope="scope">
          <span class="filtermore">{{ scope.row.deptName }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="roleName"
        label="所属角色"
        :show-overflow-tooltip="true"
      >
      </el-table-column>
      <el-table-column prop="status" label="账号状态" width="200px">
        <template slot="header" slot-scope="scope">
          <el-dropdown trigger="click" @command="handleCommand">
            <span>
              账号状态<i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="">全部</el-dropdown-item>
              <el-dropdown-item command="1">正常</el-dropdown-item>
              <el-dropdown-item command="2">锁定</el-dropdown-item>
              <el-dropdown-item command="0">失效</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </template>
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.flag"
            class="demo"
            active-color="#409EFF"
            active-text="正常"
            inactive-color="#ff4949"
            inactive-text="锁定"
            v-if="
              scope.row.status !== 0 &&
                $btnAuthorityTest('userManagement:state')
            "
            @change="switchchange(scope.row)"
          />
          <el-button
            size="mini"
            round
            v-else
            type="info"
            style="padding:3px 12px"
            >{{ scope.row.status | userstatus }}</el-button
          >
        </template>
      </el-table-column>
      <el-table-column prop="handle" label="操作">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="xqlook(scope.row)"
            v-if="$btnAuthorityTest('userManagement:view')"
            >查看</span
          ><span
            v-if="
              $btnAuthorityTest('userManagement:view') &&
                $btnAuthorityTest('userManagement:update')
            "
          >
            | </span
          ><span
            class="tablexg"
            @click="checkdetails(scope.row)"
            v-if="$btnAuthorityTest('userManagement:update')"
            >修改</span
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <el-dialog
      :title="digtitle"
      :visible.sync="addDialog"
      :before-close="handleClose"
      :close-on-click-modal="false"
      width="700px"
    >
      <el-form ref="form" :model="form" label-width="100px">
        <table>
          <tr>
            <td>
              <el-form-item label="用户名：" :required="true">
                <el-input
                  v-model="form.userName"
                  :disabled="shows"
                  style="width:200px"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="姓名：" :required="true">
                <el-input
                  v-model="form.name"
                  style="width:200px"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="性别：" :required="true">
                <el-select
                  v-model="form.sex"
                  placeholder="请选择"
                  style="width:200px"
                >
                  <el-option
                    v-for="item in sexList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="密码：" :required="true">
                <el-input
                  v-model.trim="form.password"
                  style="width:200px"
                  :type="password"
                  :disabled="shows"
                ></el-input>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="所属机构：" :required="true">
                <el-select
                  v-model="form.deptNum"
                  multiple
                  placeholder="请选择"
                  filterable
                  
                  style="width:200px"
                >
                  <el-option
                    v-for="item in organizationList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="所属角色：" :required="true">
                <el-select
                  v-model="form.roleIds"
                  multiple
                  filterable
                  allow-create
                  default-first-option
                  placeholder="请选择"
                  style="width:200px"
                >
                  <el-option
                    v-for="item in roleList"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="身份证号：" :required="true">
                <el-input
                  v-model="form.idCard"
                  style="width:200px"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="手机号码：" :required="true">
                <el-input
                  v-model="form.phone"
                  style="width:200px"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="电子邮箱：" :required="true">
                <el-input
                  v-model="form.email"
                  style="width:200px"
                  placeholder="请输入"
                ></el-input>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="账号状态：">
                <el-radio-group v-model="form.status">
                  <el-radio :label="1">正常</el-radio>
                  <el-radio :label="2">锁定</el-radio>
                </el-radio-group>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="有效期：">
                <el-radio-group v-model="form.valid">
                  <el-radio :label="1">永久</el-radio>
                  <el-radio :label="2">临时</el-radio>
                </el-radio-group>
              </el-form-item>
            </td>
            <td>
              <el-form-item>
                <el-date-picker
                  v-model="time"
                  v-show="form.valid == 2"
                  type="daterange"
                  value-format="yyyy-MM-dd"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  style="width:250px"
                >
                </el-date-picker>
              </el-form-item>
            </td>
          </tr>
        </table>
      </el-form>
      <span slot="footer" class="dialog-footer" v-if="digtitle == '添加用户'">
        <el-button @click="cancel('form')">取 消</el-button>
        <el-button type="primary" @click="addaffirm('form')">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-if="digtitle == '修改用户'">
        <el-button @click="cancel('form')">取 消</el-button>
        <el-button type="primary" @click="addaffirm('form')">保存</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="详情"
      :visible.sync="xqtk"
      :close-on-click-modal="false"
      width="700px"
    >
      <el-form
        ref="form"
        :model="formxq"
        label-width="100px"
        class="demoform"
        style="text-align:left"
      >
        <table>
          <tr>
            <td>
              <el-form-item label="用户名：" style="width:250px">
                <span>{{ formxq.userName }}</span>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="姓名：" style="width:250px">
                <span>{{ formxq.name }}</span>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="性别：" style="width:250px">
                <span>{{ formxq.sex | sexFilter }}</span>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="所属机构：" style="width:250px">
                <div style="width:150px;" class="filtermore">
                  {{ formxq.deptNum | organization(organizationList) }}
                </div>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="所属角色：" style="width:250px">
                <div style="width:150px;" class="filtermore">
                  {{ formxq.roleName }}
                </div>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="身份证号：" style="width:250px">
                <span>{{ formxq.idCard }}</span>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="手机号码：" style="width:250px">
                <span>{{ formxq.phone }}</span>
              </el-form-item>
            </td>
            <td>
              <el-form-item label="电子邮箱：" style="width:250px">
                <span>{{ formxq.email }}</span>
              </el-form-item>
            </td>
          </tr>
          <tr>
            <td>
              <el-form-item label="账号状态：">
                <span>{{ formxq.status | userstatus }}</span>
              </el-form-item>
            </td>
            <td></td>
          </tr>
          <tr>
            <td>
              <el-form-item label="有效期：">
                <span>{{ formxq.valid | valid }}</span>
                <span v-show="formxq.valid == 2"
                  >{{ time[0] | time }}至{{ time[1] | time }}</span
                >
              </el-form-item>
            </td>
          </tr>
        </table>
      </el-form>
    </el-dialog>
    <el-dialog
      title="同步用户数据"
      :visible.sync="userVisible"
      width="450px"
      :before-close="handleClose"
      :close-on-click-modal="false"
    >
      <div style="margin-bottom:50px;margin-top:40px;">
        <div style="padding-left:50px">
          <span>请选择同步的数据：</span>
          <!-- 1 -->
          <el-checkbox v-model="checkedth">教职工信息</el-checkbox>
        </div>
        <div style="padding-left:180px;margin-top:20px;">
          <!-- 2 -->
          <el-checkbox v-model="checkedst">学生信息</el-checkbox>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="userVisible = false">取 消</el-button>
        <el-button type="primary" @click="startopen">开始同步</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import componment from "@/components/searchcomponment";
import pagination from "@/components/pagination";
export default {
  components: {
    componment: componment,
    pagination: pagination
  },
  name: "userManagement",
  data() {
    return {
      checkedth: false,
      checkedst: false,
      userVisible: false,
      xqtk: false,
      digtitle: "添加用户",
      isShow: true,
      opneswitch: "正常",
      closeswitch: "锁定",
      detailsform: {},
      deleteList: [],
      detailsDialog: false, // 删除弹出框参数
      deleteDialog: false,
      addDialog: false,
      shows: false,
      search: "", // 搜索参数
      role: null, // 当前选中的角色
      roleList: [], // 所有的角色列表
      tableData: [],
      tableHeight: null,
      total: 0,
      form: {
        valid: 1,
        status: 1,
        startTime: "",
        endTime: ""
      },
      sexList: [
        {
          value: 1,
          label: "男"
        },
        {
          value: 2,
          label: "女"
        },
        {
          value: 0,
          label: "未知性别"
        },
        {
          value: 9,
          label: "未说明的性别"
        }
      ], // 性别列表
      organizationList: [], // 所属机构列
      loading2: false,
      queryStatus: "",
      time: [],
      show: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      password: "text",
      formxq: {}
    };
  },
  filters: {
    userstatus(val) {
      switch (val) {
        case 0:
          return "失效";
        case 1:
          return "正常";
        case 2:
          return "锁定";
        default:
          break;
      }
    },
    xqsex(val) {
      switch (parseInt(val)) {
        case "1":
          return "男";
        case "2":
          return "女";
        case "0":
          return "未知性别";
        case "9":
          return "未说明性别";
        default:
          break;
      }
    },
    valid(val) {
      switch (val) {
        case 1:
          return "永久";
        case 2:
          return "临时";
        default:
          break;
      }
    },
    time(val) {
      var data = new Date(val);
      return (
        data.getFullYear() + "-" + (data.getMonth() + 1) + "-" + data.getDate()
      );
    },
    // 所属机构过滤
    organization(val, index) {
      var arr = [];
      if (val) {
        val.map(v => {
          const valindex = index.find((el, index) => el.value === v);
          if (valindex && valindex.label) {
            arr.push(valindex.label);
          } else {
            arr = [];
          }
        });
        return arr.toString();
      } else {
        return "未知";
      }
    },
    // 所属角色过滤
    roleListfilter(val, index) {
      var arr = [];
      if (val) {
        val.map(v => {
          const valindex = index.find((el, index) => el.value === v);
          if (valindex && valindex.label) {
            arr.push(valindex.label);
          } else {
            arr = [];
          }
        });
        return arr.toString();
      } else {
        return "未知";
      }
    }
  },
  methods: {
    startopen() {
      var value = 1;
      if (this.checkedth) {
        value = 2;
        this.$message({
          type: "success",
          message: "数据正在同步中请稍后"
        });
      }
      if (this.checkedst) {
        value = 1;
        this.$message({
          type: "success",
          message: "数据正在同步中请稍后"
        });
      }
      if (this.checkedth && this.checkedst) {
        value = `${1},${2}`;
        this.$message({
          type: "success",
          message: "数据正在同步中请稍后"
        });
      }
      this.$http.get("api/system/user/synchronUser/" + value).then(res => {
        if (res.data.code == 200) {
          if (this.checkedth) {
            setTimeout(() => {
              this.takeList();
              this.$message({ type: "success", message: res.data.message });
              this.userVisible = false;
            }, 10000);
          }
          if (this.checkedst) {
            setTimeout(() => {
              this.takeList();
              this.$message({ type: "success", message: res.data.message });
              this.userVisible = false;
            }, 20000);
          }
          if (this.checkedth && this.checkedst) {
            setTimeout(() => {
              this.takeList();
              this.$message({ type: "success", message: res.data.message });
              this.userVisible = false;
            }, 40000);
          }
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 同步用户数据
    synchroniz() {
      this.userVisible = true;
      this.checkedth = false;
      this.checkedst = false;
    },
    xqlook(row) {
      this.xqtk = true;
      this.takeOrganizationList();
      this.$http.get("api/system/user/getById/" + row.id).then(res => {
        console.log(res.data.data);
        this.formxq = res.data.data;
        this.formxq.valid == 2
          ? (this.time = [res.data.data.startTime, res.data.data.endTime])
          : (this.time = []);

        if (res.data.data.roleIds) {
          this.formxq.roleIds = res.data.data.roleIds.split(",");
        } else {
          this.formxq.roleIds = [];
        }
        if (this.formxq.deptNum) {
          this.formxq.deptNum = res.data.data.deptNum.split(",");
        } else {
          this.formxq.deptNum = [];
        }
      });
    },
    switchchange(val) {
      if (val.status == 1) {
        this.$http.post("api/system/user/lock/" + val.id).then(res => {
          if (res.data.code == 200) {
            this.$message({ type: "success", message: "锁定成功" });
            this.takeList();
          } else {
            this.$message.error({ message: res.data.message });
          }
        });
      }
      if (val.status == 2) {
        this.$http.post("api/system/user/unLock/" + val.id).then(res => {
          if (res.data.code == 200) {
            this.$message({ type: "success", message: "解锁成功" });
            this.takeList();
          } else {
            this.$message.error({ message: res.data.message });
          }
        });
      }
    },
    resetFormlist() {
      this.form = {
        userName: "", // 用户名
        name: "", // 姓名：
        sex: 0, // 性别
        password: "", // 密码
        deptNum: [], // 所属机构：
        roleIds: [], // 所属角色：
        phone: "", // 手机号码：
        idCard: "", // 身份证号：
        status: 1, // 账号状态：
        valid: 1, // 有效期：
        startTime: "", // 开始时间
        endTime: "", // 结束时间
        email: "" // 邮箱
      };
    },
    changeselect(val) {
      this.roleList = [];
      this.form = Object.assign({}, this.form, { roleIds: [] });
      this.takeRoleList();
    },
    // 清除input
    clearinput() {
      this.search = "";
      this.takeList();
    },
    resetHandle() {
      if (this.deleteList.length == 0) {
        this.$message.error({ message: "请勾选再进行密码初始化" });
        return false;
      }
      this.$http.post("api/system/user/reset", this.deleteList).then(res => {
        if (res.data.code == 200) {
          this.$message({ type: "success", message: "密码初始化成功" });
          this.takeList();
        } else {
          this.$message.error({ message: "密码初始化失败" });
        }
      });
    }, // 密码初始化
    modificHandle() {
      this.isShow = false;
    }, // 点修改
    checkdetails(row) {
      this.addDialog = true;
      this.$nextTick(() => {
        this.$refs.form.resetFields();
      });
      this.password = "password";
      this.show = true;
      this.shows = true;
      this.digtitle = "修改用户";
      this.takeOrganizationList();
      this.$http.get("api/system/user/getById/" + row.id).then(res => {
        this.form = res.data.data;
        this.form.valid == 2
          ? (this.time = [res.data.data.startTime, res.data.data.endTime])
          : (this.time = []);
        if (res.data.data.roleIds) {
          this.form.roleIds = res.data.data.roleIds.split(",");
        } else {
          this.form.roleIds = [];
        }
        if (this.form.deptNum) {
          this.form.deptNum = res.data.data.deptNum.split(",");
        } else {
          this.form.deptNum = [];
        }
      });
    }, // 查看详情
    closeDia() {
      this.$http
        .delete("api/system/user/", { data: this.deleteList })
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: res.data.message,
              type: "success"
            });
            this.takeList();
          } else {
            this.$message.error({ message: res.data.message });
          }
        });
      this.deleteDialog = false;
    }, // 确认删除

    deleteHandle() {
      this.deleteList.length != 0
        ? (this.deleteDialog = true)
        : this.$message.error({ message: "请选择一条数据！" });
    },
    // 列表
    takeList() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/system/user/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.search,
          roleId: this.role,
          queryStatus: this.queryStatus,
          manage: ""
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.tableData.forEach(element => {
            this.$set(element, "flag", true);
            if (element.status == 1) {
              element.flag = true;
            } else {
              element.flag = false;
            }
          });
          this.total = res.data.data.total;
        })
        .catch(res => {
          this.loading2 = false;
        });
    }, // 查询用户列表
    takeRoleList() {
      this.$http.get("api/system/role/select").then(res => {
        let data = res.data.data;
        data.unshift({ label: "全部角色", value: null });
        this.roleList = data;
      });
    }, // 查询角色列表
    takeOrganizationList() {
      this.$http.get("api/system/dept/selectAll").then(res => {
        this.organizationList = res.data.data;
      });
    }, // 查询机构列表
    handleClose(done) {
      this.isShow = true;
      done();
    },
    handleCommand(val) {
      this.queryStatus = val;
      this.takeList();
    },
    // 添加
    addaffirm(formName) {
      if (this.form.valid == "2") {
        this.form.startTime = this.time[0];
        this.form.endTime = this.time[1];
      }
      var form = JSON.parse(JSON.stringify(this.form));
      let show = true;
      var formyz = [
        "userName",
        "name",
        "password",
        "deptNum",
        "roleIds",
        "idCard",
        "phone",
        "email"
      ];
      this.$refs[formName].validate(valid => {
        if (valid) {
          if (this.digtitle == "添加用户") {
            formyz.forEach(el => {
              if (show) {
                if (!form[el] || form[el].length == 0) {
                  this.$message.error("请填写完整在提交");
                  show = false;
                }
              }
            });
            if (show) {
              form.deptNum = form.deptNum.toString();
              form.roleIds = form.roleIds.toString();
              this.$http.post("api/system/user", form).then(res => {
                if (res.data.code == 200) {
                  this.$message({ type: "success", message: res.data.message });
                  this.takeList();
                  this.addDialog = false;
                } else {
                  this.$message.error({ message: res.data.message });
                }
              });
            }
          } else {
            form.deptNum = form.deptNum.join(",");
            form.roleIds = form.roleIds.join(",");
            console.log(form);
            this.$http.put("api/system/user", form).then(res => {
              if (res.data.code == 200) {
                this.$message({ type: "success", message: res.data.message });
                this.addDialog = false;
                this.takeList();
              } else {
                this.$message.error({ message: res.data.message });
              }
            });
          }
        } else {
          return false;
        }
      });
    }, // 新增确定
    cancel(formName) {
      this.addDialog = false;
      this.$refs[formName].resetFields();
    }, // 新增取消
    addNew() {
      this.addDialog = true;
      this.show = false;
      this.shows = false;
      this.digtitle = "添加用户";
      this.form = {};
      this.resetFormlist();
      this.$nextTick(() => {
        this.$refs.form.resetFields();
      });
      this.takeOrganizationList();
    },
    // 添加用户
    handleFind() {
      this.takeList();
    }, // 搜索的方法
    // 点击列表选中
    clickRow(row) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    // 选择列表
    handleSelectionChange(selection) {
      this.deleteList = [];
      this.modificData = selection[0];
      selection.map((item, index) => {
        this.deleteList.push(item.id);
      });
    },
    allClick(selection) {}
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
    this.takeRoleList();
  }
};
</script>

<style scoped lang="scss">
.userManagement {
  width: 100%;
  padding-top: 7px;
  .demoform {
    /deep/ .el-form-item__label {
      text-align: left;
    }
  }
  .table {
    /deep/ .demo .el-switch__label {
      position: absolute;
      display: none;
      color: #fff;
    }
    /*打开时文字位置设置*/
    /deep/ .demo .el-switch__label--right {
      z-index: 1;
      right: -3px;
    }
    /*关闭时文字位置设置*/
    /deep/ .demo .el-switch__label--left {
      z-index: 1;
      left: 19px;
    }
    /*显示文字*/
    /deep/ .demo .el-switch__label.is-active {
      display: inline;
      margin-right: 20px;
    }
    /deep/ .demo.el-switch .el-switch__core,
    .el-switch .el-switch__label {
      width: 50px !important;
    }
  }
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    line-height: 48px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      // border: 1px solid #e0e0e0;
    }
    th,
    td {
      // border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 5px;
      text-align: center;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
  }
  .bg-purple-light {
    text-align: right;
    float: right;
  }
}
/deep/ .el-form-item__content {
  text-align: left;
}
.userManagement /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.userManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
.userManagement /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.userManagement /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 15px 20px !important;
}
</style>
