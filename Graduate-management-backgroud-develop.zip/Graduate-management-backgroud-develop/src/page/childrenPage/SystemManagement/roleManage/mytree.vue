<template>
  <div class="addtree" v-loading="loading" element-loading-text="加载中">
    <div class="top-title">
      <el-row>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <el-button
              icon="el-icon-refresh-left"
              class="diyButton"
              @click="exitList"
              >返回列表</el-button
            >
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple-light">
            <el-button type="text"
              >{{ username.jsid }} 角色名称：{{ username.name }}</el-button
            >
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purples">
            <el-button @click="dianji" type="primary" class="btnright"
              >确定</el-button
            >
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="main-container">
      <div class="table-container">
        <div class="table">
          <template>
            <el-tabs v-model="activeName">
              <el-tab-pane
                :label="item.gncdmc"
                :name="item.gncdid"
                v-for="(item, $index) in list"
                :key="$index"
              >
                <ul class="containerrole">
                  <li class="containerrole_lis">
                    <div style="width:150px;">
                      <el-checkbox
                        :value="item.checked"
                        :indeterminate="item.isIndeterminate"
                        @change="allcheckouted(item)"
                      ></el-checkbox>
                    </div>
                    <div class="div_one">功能模块</div>
                    <div class="div_one">菜单类型</div>
                    <div class="div_one" style="flex:3">操作按钮</div>
                  </li>
                  <li
                    class="containerrole_lis li_two"
                    v-for="(items, $index1) in item.children"
                    :key="$index1"
                  >
                    <div
                      class="containerrole_left containerrole_lefts"
                      style="width:150px;"
                    >
                      <el-checkbox
                        :value="items.checked"
                        :indeterminate="items.isIndeterminate"
                        @change="rolesecond(item.groupId, items)"
                      ></el-checkbox>
                    </div>
                    <div class="div_one">{{ items.gncdmc }}</div>
                    <div class="div_one" v-if="items.menuType == 1">
                      一级菜单
                    </div>
                    <div class="div_one" v-if="items.menuType == 2">
                      二级菜单
                    </div>
                    <div class="div_one" v-if="items.menuType == 3">
                      三级菜单
                    </div>
                    <div class="div_one" v-if="items.menuType == 4">按钮</div>
                    <div class="div_one" v-if="items.menuType == null">无</div>
                    <div class="div_one" style="flex:3;text-align:left;">
                      <div
                        v-for="(item1, $index2) in items.children"
                        :key="$index2"
                        v-show="items.children"
                        class="for_typebtn"
                      >
                        <el-checkbox
                          v-model="item1.checked"
                          @change="
                            rolebtn($event, item1.checked, item1, item1.sjcdid)
                          "
                          :disabled="!items.checked && !items.isIndeterminate"
                          >{{ item1.gncdmc }}</el-checkbox
                        >
                      </div>
                    </div>
                  </li>
                </ul>
              </el-tab-pane>
            </el-tabs>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import system from "./system.json";
export default {
  name: "addtree",
  props: {
    username: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  data() {
    return {
      list: [],
      system: system,
      activeName: "101",
      form: {},
      spanArr: [],
      position: 0,
      loading: false
    };
  },
  methods: {
    //  一级菜单勾选
    allcheckouted(items) {
      // 根据原先的勾选状态，赋予新值
      if (items.isIndeterminate) {
        items.checked = true;
        items.isIndeterminate = false;
      } else if (items.checked) {
        items.checked = false;
      } else {
        items.checked = true;
      }
      if (Array.isArray(items.children)) {
        // 根据新的勾选状态给二级菜单和按钮修改勾选状态
        items.children.forEach(item => {
          item.checked = items.checked;
          item.isIndeterminate = false;
          if (Array.isArray(item.children)) {
            item.children.forEach(obj => {
              obj.checked = items.checked;
            });
          }
        });
      }
    },
    // 二级菜单勾选
    rolesecond(group, items) {
      // 根据原先的勾选状态，赋予新值
      if (items.isIndeterminate) {
        items.checked = true;
        items.isIndeterminate = false;
      } else if (items.checked) {
        items.checked = false;
      } else {
        items.checked = true;
      }
      if (Array.isArray(items.children)) {
        // 根据新的勾选状态给按钮修改勾选状态
        items.children.forEach(el => {
          el.checked = items.checked;
        });
      }
      // 给当前页一级菜单修改勾选状态
      this.currentMenu.checked = this.currentMenu.children.every(
        el => el.checked
      );
      this.currentMenu.isIndeterminate =
        !this.currentMenu.checked &&
        this.currentMenu.children.some(el => el.checked || el.isIndeterminate);
    },
    rolebtn(e, val, item, sjcdid) {
      let tmp = this.currentMenu.children.find(el => el.gncdid === sjcdid);
      if (tmp) {
        // 给当前页二级菜单修改勾选状态
        tmp.checked = tmp.children.every(el => el.checked);
        tmp.isIndeterminate =
          !tmp.checked && tmp.children.some(el => el.checked);
      }
      // 给当前页一级菜单修改勾选状态
      this.currentMenu.checked = this.currentMenu.children.every(
        el => el.checked
      );
      this.currentMenu.isIndeterminate =
        !this.currentMenu.checked &&
        this.currentMenu.children.some(el => el.checked || el.isIndeterminate);
    },
    exitList() {
      this.$store.state.addtree = false;
      this.$parent.rolelist();
    },
    dianji() {
      const id = localStorage.getItem("mokuaiid");
      let checkId = [];
      // checkId = [];
      // 取出所有勾选半勾选状态的id
      this.list.map(v => {
        if (v.isIndeterminate || v.checked) {
          checkId.push(v.gncdid);
        }
        if (v.children !== null) {
          v.children.map((vv, index) => {
            if (vv.checked || vv.isIndeterminate) {
              checkId.push(vv.gncdid);
            }
            if (vv.children !== null) {
              vv.children.map((vvv, index2) => {
                if (vvv.checked) {
                  checkId.push(vvv.gncdid);
                }
              });
            }
          });
        }
      });
      let roleMenu = checkId.toString();
      this.$http
        .post("api/system/role/grant", {
          roleId: id,
          roleMenu: roleMenu
        })
        .then(res => {
          this.exitList();
        });
    },
    // 请求所有菜单
    modeldata() {
      this.loading = true;
      const id = localStorage.getItem("roleids");
      this.$http
        .get("api/system/role/getGnmkFirst/" + id)
        .then(res => {
          this.loading = false;
          if (res.data.code == 200 && Array.isArray(res.data.data.children)) {
            this.list = res.data.data.children;
            this.activeName = this.list[0].gncdid;
            this.checkthe();
          } else {
            this.$message.error("数据异常");
            this.exitList();
          }
        })
        .catch(error => {
          this.loading = false;
          console.error(error.message);
        });
    },
    // 获取授权的数据
    checkthe() {
      const mokuaiid = localStorage.getItem("mokuaiid");
      this.$http
        .post("api/system/role/getGrant", {
          roleId: mokuaiid,
          roleType: "1",
          menuId: this.activeName
        })
        .then(res => {
          let data = res.data.data;
          // 清空所有勾选
          this.clearMenuCheck();
          if (Array.isArray(data) && data.length) {
            // 取出授权的列表
            let checkId = data[0].roleMenu.split(",");
            this.list.map((v, index) => {
              // 一级菜单
              if (Array.isArray(v.children) && v.children.length !== 0) {
                // 二级菜单
                v.children.map((vv, index1) => {
                  if (Array.isArray(vv.children) && vv.children.length !== 0) {
                    vv.children.map((vvv, index) => {
                      if (checkId.indexOf(vvv.gncdid) !== -1) {
                        // 按钮勾选
                        vvv.checked = true;
                      }
                    });
                    // 二级菜单状态赋值
                    vv.checked = vv.children.every(el => el.checked);
                    vv.isIndeterminate =
                      !vv.checked && vv.children.some(el => el.checked);
                  } else {
                    // 无子按钮的二级菜单勾选
                    if (checkId.indexOf(vv.gncdid) !== -1) {
                      vv.checked = true;
                    }
                  }
                });
                // 一级菜单状态赋值
                v.checked = v.children.every(el => el.checked);
                v.isIndeterminate =
                  !v.checked && v.children.some(el => el.checked);
              } else {
                // 无子菜单的一级菜单勾选
                if (checkId.indexOf(v.gncdid) !== -1) {
                  v.checked = true;
                }
              }
            });
          }
        });
    },
    // 清空所有勾选
    clearMenuCheck() {
      this.list.map((v, index) => {
        this.$set(v, "isIndeterminate", false);
        this.$set(v, "checked", false);
        if (Array.isArray(v.children)) {
          v.children.map((vv, index1) => {
            this.$set(vv, "checked", false);
            this.$set(vv, "isIndeterminate", false);
            if (Array.isArray(vv.children)) {
              vv.children.map((vvv, index2) => {
                this.$set(vvv, "checked", false);
              });
            }
          });
        }
      });
    }
  }, // 相同一级菜单合并行
  mounted() {
    this.modeldata();
  },
  computed: {
    currentMenu() {
      let tmp = this.list.find(el => el.gncdid === this.activeName);
      if (tmp) {
        return tmp;
      } else {
        return {};
      }
    }
  }
};
</script>

<style scoped lang="scss" src="./mytree.scss"></style>
<style>
.addtree {
  height: 100%;
}
</style>
