<template>
  <div class="timecommon">
    <img src="./images/year.png" alt="" srcset="" style="display:inline;float:left;margin-right:10px;width:32px">
    <span style="float:right">当前招生年度：{{year}}年</span>
  </div>
</template>
<script>
export default {
  props: ["year"],
  name: "timecommon",
  data() {
    return {};
  },
  mounted() {},
  methods: {},
  computed: {}
};
</script>
<style lang="scss" scoped>
.timecommon {
  position: fixed;
  left: 250px;
  bottom: 20px;
  line-height: 40px;
  font-family: "Arial Negreta", "Arial Normal", "Arial";
  font-weight: 700;
  font-style: normal;
  color: #1890ff;
  font-size: 14px;
}
</style>


