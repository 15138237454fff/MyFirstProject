<template>
  <div class="interviewTable">
    <template>
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="待确认" name="first"></el-tab-pane>
          <el-tab-pane label="已确认" name="second"></el-tab-pane>
        </el-tabs>
      </div>

    </template>
    <interviewList v-if="activeName=='first'"></interviewList>
    <interviewRow v-if="activeName=='second'"></interviewRow>
  </div>
</template>
<script>
import interviewList from './componments/interviewList';
import interviewRow from './componments/interviewRow';
export default {
  name: 'interviewTable',
  components: {
    interviewList: interviewList,
    interviewRow: interviewRow
  },
  data() {
    return {
      activeName: 'first'
    }
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    }
  }
}
</script>
<style scoped lang="scss">
.addmissProposed {
  width: 100%;
}
.tabs {
  /deep/ .el-tabs__nav-wrap {
    background: #ffffff;
  }
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
}
</style>