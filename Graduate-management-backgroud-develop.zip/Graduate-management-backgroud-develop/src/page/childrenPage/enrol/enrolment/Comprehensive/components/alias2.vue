<template>
  <div class="enrolBasicParams">
    <div class="box">
      4444
      <div class="save">
        <el-button type="primary" @click="uploadForm">返回</el-button>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "perFormance",
  data() {
    return {
      //待提交的基础参数表单数据
      paramsForm: {
        // 招生年度
        zsnd: "",
        //是否开启成绩录入
        isOpen: 0,
        //开始日期
        startTime: "",
        //结束日期
        endTime: ""
      }
    };
  },
  mounted() {
    // this.requireCurrentYear();
    // console.log(this.currentYear);
  },
  methods: {
    uploadForm() {
      this.$router.go(-1);
    }
  },
  computed: {}
};
</script>
<style lang="scss" scoped>
.enrolBasicParams {
  width: 100%;
  height: 80vh;
  display: flex;
  justify-content: center;
  align-items: center;
  .box {
    font-size: 14px;
    width: 800px;
    height: 200px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .save {
      text-align: center;
    }
  }
}
</style>