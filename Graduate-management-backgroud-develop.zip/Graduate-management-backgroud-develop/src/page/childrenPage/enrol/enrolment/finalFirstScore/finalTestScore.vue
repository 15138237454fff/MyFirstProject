<template>
  <div class="finalFirstScore">
    <template>
      <div class="tabs">
        <el-tabs v-model="activeName">
          <el-tab-pane label="成绩校验" name="first"></el-tab-pane>
          <el-tab-pane label="最终成绩" name="second"></el-tab-pane>
        </el-tabs>
      </div>
      <score-check-list v-if="activeName==='first'"></score-check-list>
      <final-score-list v-if="activeName==='second'"></final-score-list>
    </template>
  </div>
</template>
<script>
import finalScoreList from "./components/finalScoreList";
import scoreCheckList from "./components/scoreCheckList";
export default {
  name: "finalTestScore",
  components: {
    "final-score-list": finalScoreList,
    "score-check-list": scoreCheckList
  },
  data() {
    return {
      activeName: "first"
    };
  },
  methods: {}
};
</script>
<style lang="scss" scoped>
.finalFirstScore {
  width: 100%;
}
.tabs {
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
}
</style>

