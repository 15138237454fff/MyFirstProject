<template>
  <div class="finalScoreList">
    <div class="header">
      <div class="header-left">
        <el-input
          suffix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考生编号/姓名"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select
          v-model="limitQuery.bkxy"
          @change="handleXyChange"
          filterable
        >
          <el-option label="全部学院" :value="null"></el-option>
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.bkzy" @change="loadTable" filterable>
          <el-option label="全部专业" :value="null"></el-option>
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
    </div>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$storage.tableHeaderColor"
      :default-sort="{ prop: 'ksbh', order: 'ascending' }"
    >
      <el-table-column prop="ksbh" label="考生编号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="bkxy" label="报考学院"></el-table-column>
      <el-table-column prop="bkzy" label="报考专业"></el-table-column>
      <el-table-column prop="xxfs" label="学习方式">
        <template slot-scope="scope">
          {{ scope.row.xxfs | xxfsFilter(1) }}
        </template>
      </el-table-column>
      <el-table-column prop="wgy" label="外国语"></el-table-column>
      <el-table-column prop="ywk1" label="业务课一"></el-table-column>
      <el-table-column prop="ywk2" label="业务课二"></el-table-column>
      <el-table-column prop="zf" label="初试总分"></el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>
<script>
import timecommon from "../../../componments/timecommon";
export default {
  name: "finalScoreList",
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 分页查询的参数
      limitQuery: {
        // 报考学院
        bkxy: null,
        // 报考专业
        bkzy: null,
        query: "",
        pageSize: 10,
        pageNum: 1,
        xslb: "0",
        fszt: "0",
        year: null
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      tableHeight: null
    };
  },
  components: {
    timecommon
  },
  created() {
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    // 请求学院专业信息
    this.requireXY();
    this.zyList(null);
    this.loadTable();
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 290;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 290;
      })();
    };
  },
  methods: {
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      this.loading = true;
      this.$http
        .post("/api/doctorate/masterResult/checkEnd", this.limitQuery)
        .then(res => {
          let data = res.data;
          this.loading = false;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },

    // 获取学院和专业的可选列表
    requireXY() {
      this.$http.post("/api/doctorate/bsOption/bkyxOption", {}).then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        }
        // 保存学院的待选列表
        this.xyOptions = data;
      });
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
      });
    },
    zyList(val) {
      this.$http
        .post(`/api/doctorate/bsOption/bkzyOption`, { yxdm: val })
        .then(res => {
          this.zyOptions = res.data.data;
          this.limitQuery.bkzy = null;
        });
    },
    handleXyChange(val) {
      console.log(val);
      this.zyList(val);
      this.loadTable();
    }
  },
  watch: {
    $route(to) {
      if (to.name === "finalTestScore") {
        this.loadTable();
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.finalScoreList {
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 3;
      .el-select {
        width: 140px;
      }
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 2;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button,
    .el-select {
      margin-left: 0px;
    }
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    padding: 0;
  }
  /deep/ .el-table td {
    padding: 0 !important;
    height: 50px;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
