<template>
  <div class="scoreCheckList">
    <div class="header">
      <div class="header-left">
        <el-input
          suffix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考生编号/姓名"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select v-model="limitQuery.bkxy" @change="loadTable" filterable>
          <el-option label="全部学院" :value="null"></el-option>
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.bkzy" @change="loadTable" filterable>
          <el-option label="全部专业" :value="null"></el-option>
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.kmlb" @change="loadTable" filterable>
          <el-option label="全部科目类别" :value="null"></el-option>
          <el-option
            v-for="(item, index) in kmOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.kskm" @change="loadTable">
          <el-option label="全部考试科目" :value="null"></el-option>
          <el-option
            v-for="(item, index) in ksOptions"
            :key="index"
            :label="item.kmmc"
            :value="item.kmmc"
          ></el-option>
        </el-select>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          plain
          @click="checkClick"
          v-if="$btnAuthorityTest('finalTestScore:test')"
          :disabled="checkButton"
          >成绩校验</el-button
        >
        <el-button
          type="primary"
          @click="submitClick"
          v-if="$btnAuthorityTest('finalTestScore:submit')"
          :disabled="checkButton"
          >提交</el-button
        >
      </div>
    </div>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      ref="multipleTable"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$storage.tableHeaderColor"
      @selection-change="handleSelectionChange"
      :row-class-name="tableRowClassName"
    >
      <el-table-column type="selection"></el-table-column>
      <el-table-column prop="ksbh" label="考生编号" width="180px">
        <template slot-scope="scope">
          <img
            src="../../../../../../assets/img/error.png"
            class="error-icon"
            v-if="scope.row.checkStatus === '1'"
          />
          <span>{{ scope.row.ksbh }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column
        prop="bkxy"
        label="报考学院"
        width="180px"
      ></el-table-column>
      <el-table-column prop="bkzy" label="报考专业"></el-table-column>
      <el-table-column label="科目类别">
        <template slot-scope="scope">
          <span>{{ scope.row.kmlb | kmlbFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="kmmc" label="考试科目"></el-table-column>
      <el-table-column prop="cscjlr1" label="登分一"></el-table-column>
      <el-table-column prop="cscjlr2" label="登分二"></el-table-column>
      <el-table-column label="最终初试成绩">
        <template slot-scope="scope">
          <el-input
            v-model="scope.row.zzcscj"
            @keyup.enter.native="jumpInput(scope.$index)"
            :ref="'scopeInput' + scope.$index"
            :disabled="scope.row.checkStatus !== '1'"
            v-if="$btnAuthorityTest('finalTestScore:input')"
          ></el-input>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>
<script>
import timecommon from "../../../componments/timecommon";
export default {
  name: "scoreCheckList",
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // 报考学院
          bkxy: "",
          // 报考专业
          bkzy: "",
          // 成绩录入
          cjlr: "",
          // 登分成绩人员1id
          cscjjs1: "",
          // 登分成绩人员2id
          cscjjs2: "",
          // 初始成绩录入1
          cscjlr1: "",
          // 初始成绩录入2
          cscjlr2: "",
          id: "",
          // 科目类别
          kmlb: "",
          // 考试科目
          kmmc: "",
          // 考生编号
          ksbh: "11111",
          // 考生姓名
          xm: "",
          // 学习方式
          xxfs: "",
          // 最终初试成绩
          zzcscj: ""
        }
      ],
      // 科目的待选列表
      kmOptions: [
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywke" },
        { label: "业务课二", value: 4, name: "ywky" }
      ],
      // 考试科目的待选列表
      ksOptions: [],
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 勾选的记录
      historySelect: [],
      // 分页查询的参数
      limitQuery: {
        // 考试科目
        kskm: null,
        // 当前用户角色id
        jsid: this.$stores.state.roleid_tole,
        // 报考学院
        bkxy: null,
        // 报考专业
        bkzy: null,
        // 科目类别
        kmlb: null,
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: null
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 是否可写
      writeable: false,
      tableHeight: null,
      checkButton: false
    };
  },
  components: {
    timecommon
  },
  created() {
    // 请求学院专业信息
    this.requireXY();
    this.zyList(null);
    this.loadTable();
    // 请求考试科目可选列表
    this.requireKSKM(0);
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    this.checkButtonList();
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 290;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 290;
      })();
    };
  },
  methods: {
    checkButtonList() {
      this.$http.get(`/api/doctorate/masterResult/checkButton`).then(res => {
        const data = res.data;
        if (data.data == 0) {
          this.checkButton = true;
        } else {
          this.checkButton = false;
        }
      });
    },
    // 返回表格一列的颜色
    tableRowClassName({ row }) {
      // console.log(row);
      if (row.checkStatus === "1") {
        return "error-test";
      }
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 成绩校验的方法
    checkClick() {
      // 验证角色id，如果不是
      this.loading = true;
      this.$http
        .post("/api/doctorate/masterResult/check", this.limitQuery)
        .then(res => {
          const data = res.data.data;
          this.loading = false;
          // 如果data为空 或者 list 不是一个数组
          if (!data || !Array.isArray(data.list)) {
            this.$message.error("获取成绩校验列表失败，请重试");
            return;
          }
          this.tableData = data.list;
          this.newsCount = data.total;
          // 可写状态
          this.writeable = true;
          // dom操作放入nextTick,如果存在输入框
          this.$nextTick(() => {
            if (this.$refs.scopeInput0) {
              // 第一个输入框获取焦点
              this.$refs.scopeInput0.focus();
            }
          });
          this.$message.success("核对无误成绩已进入最终成绩列表");
        });
    },

    // 提交的方法
    submitClick() {
      console.log("提交");
      let test = true;
      // 如果用户未勾选数据
      if (this.historySelect.length === 0) {
        this.$message.warning("请先勾选记录后，再尝试提交");
        return;
      }
      // 如果用户提交的数据包含未填写的记录
      this.historySelect.forEach(el => {
        if (el.zzcscj === "" || el.zzcscj === null) {
          test = false;
          return;
        }
      });
      // 提示部分数据未提交
      if (!test) {
        this.$message.warning("需要录入最终成绩后再尝试提交");
      }
      // 调用提交的方法
      this.saveData();
    },
    // 最终成绩录入
    saveData() {
      // 放入待提交的表单对象中
      const uploadForm = [];
      // 准备要提交的数组对象
      this.historySelect.forEach(el => {
        // 如果填写过最终成绩
        if (el.zzcscj) {
          // 保存到待提交的列表
          uploadForm.push({
            id: el.id,
            zzcscj: el.zzcscj,
            ksbh: el.ksbh,
            kmlb: el.kmlb
          });
        }
      });
      // 发送请求提交成绩
      this.$http
        .post(`/api/doctorate/masterResult/firstEndUpdate`, {
          masterResultZzCjDtos: uploadForm
        })
        .then(res => {
          const data = res.data;
          if (data.code === 200) {
            this.$message.success("提交成功");
            // 重新加载列表
            this.loadTable();
          } else {
            this.$message.error(data.message);
          }
        });
      // 清空待提交的列表
      this.uploadForm = [];
    },
    // 请求列表数据的方法
    loadTable() {
      this.loading = true;
      this.$http
        .post("/api/doctorate/masterResult/endList", this.limitQuery)
        .then(res => {
          let data = res.data;
          this.loading = false;
          // setTimeout(() => {
          //   this.loading = false;
          // }, 1000);
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          this.tableData = data.list;
          this.newsCount = data.total;
          // 根据返回的记录的校验状态判断是否校验过
          if (this.tableData[0] && this.tableData[0].checkStatus === "1") {
            this.writeable = true;
            // dom操作放入nextTick,如果存在输入框
            this.$nextTick(() => {
              if (this.$refs.scopeInput0) {
                // 第一个输入框获取焦点
                this.$refs.scopeInput0.focus();
              }
            });
          } else {
            this.writeable = false;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 切换输入框的方法
    jumpInput(index) {
      // 获取下一个输入框下标
      let nextIndex = index + 1,
        // 获取下一个输入框
        nextInput = this.$refs["scopeInput" + nextIndex];
      // 如果这个输入框存在
      if (nextInput) {
        // 激活下一个输入框
        nextInput.focus();
      }
      // 如果已经是最后一个输入框
      else {
        // 这个输入框失去焦点
        this.$refs["scopeInput" + index].blur();
      }
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http.post("/api/doctorate/bsOption/bkyxOption", {}).then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        }
        // 保存学院的待选列表
        this.xyOptions = data;
        // // 取第一个学院为默认选中
        // this.limitQuery.bkxy = data[0].value;
        // // 取出可选的专业待选列表
        // this.zyOptions = this.xyOptions[0].children;
      });
    },
    // 根据科目类型请求对应的考试科目
    requireKSKM(kmlb) {
      this.$http
        .post("/api/doctorate/masterResult/getTree", { kmlb })
        .then(res => {
          const data = res.data.data;
          // 验证消息格式
          // 保存新的考试科目可选列表
          this.ksOptions = data;
          // 重置考试科目的所选值
          this.limitQuery.kskm = null;
        });
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
      });
    },
    // 勾选时将选中的列表保存起来
    handleSelectionChange(selection) {
      this.historySelect = selection;
    },
    zyList(val) {
      this.$http
        .post(`/api/doctorate/bsOption/bkzyOption`, { yxdm: val })
        .then(res => {
          this.zyOptions = res.data.data;
          this.limitQuery.bkzy = null;
        });
    }
  },
  watch: {
    $route(to) {
      if (to.name === "finalTestScore") {
        this.loadTable();
      }
    },
    // 监听学院下拉选则的数据
    "limitQuery.bkxy": {
      handler(val) {
        this.zyList(val);
        this.loadTable();
      }
    },
    // 监听科目类别的变化
    "limitQuery.kmlb": {
      handler(val) {
        // 重新请求考试科目数据
        this.requireKSKM(val);
      }
    }
  },
  filters: {
    // 过滤科目类别
    kmlbFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 2:
          return "外国语";
        case 3:
          return "业务课一";
        case 4:
          return "业务课二";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.scoreCheckList {
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .error-icon {
    display: none;
  }
  /deep/ .el-table .error-test {
    background: #ffeded;
    color: #ff4a4a;
    position: relative;
    .error-icon {
      width: 20px;
      height: 20px;
      vertical-align: top;
      position: absolute;
      left: 10px;
      display: block;
    }
    .el-input__inner {
      background: #ffeded;
    }
  }
  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 3;
      .el-select {
        width: 140px;
      }
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button,
    .el-select {
      margin-left: 0px;
    }
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    padding: 0;
  }
  /deep/ .el-table td {
    padding: 0 !important;
    height: 50px;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
