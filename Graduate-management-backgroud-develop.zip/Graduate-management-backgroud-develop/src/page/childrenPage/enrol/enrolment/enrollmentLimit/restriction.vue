<template>
  <div class="limit">
    <searchcomponment>
      <div slot="left">
        <el-input
          v-model="formInline.user"
          placeholder="请输入学院代码/名称"
          suffix-icon="el-icon-search"
          clearable
          style="width:200px"
          @clear="clearinput"
        ></el-input>
        <el-button @click="onSubmit">查询</el-button>
      </div>
      <div slot="right">
        <el-button
          plain
          @click="onSave('0')"
          :disabled="isshow"
          v-if="$btnAuthorityTest('restriction:save')"
          >保存</el-button
        >
        <el-button
          type="primary"
          @click="onSave('1')"
          :disabled="isshow"
          v-if="$btnAuthorityTest('restriction:submit')"
          >提交</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column prop="xydm" label="学院代码"> </el-table-column>
      <el-table-column prop="xymc" label="学院名称"> </el-table-column>
      <el-table-column label="全日制招生名额">
        <template slot-scope="scope">
          <el-input-number
            v-model="scope.row.qrzme"
            controls-position="right"
            placeholder="请输入内容"
            :min="1"
            :precision="0"
            v-if="!isshow"
          ></el-input-number>
          <span v-else>{{ scope.row.qrzme }}</span>
        </template>
      </el-table-column>
      <el-table-column label="非全日制招生名额">
        <template slot-scope="scope">
          <el-input-number
            v-model="scope.row.fqrzme"
            controls-position="right"
            placeholder="请输入内容"
            :min="1"
            :precision="0"
            v-if="!isshow"
          ></el-input-number>
          <span v-else>{{ scope.row.fqrzme }}</span>
        </template>
      </el-table-column>
    </el-table>
    <timecommon :year="formInline.year"></timecommon>
  </div>
</template>
<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../componments/timecommon";
export default {
  name: "restriction",
  data() {
    return {
      formInline: {
        user: "",
        year: 2019
      },
      loading2: false,
      tableHeight: null,
      tableData: [],
      isshow: false
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.requireCurrentYear();
  },
  methods: {
    clearinput() {
      this.formInline.user = "";
      this.fresh();
    },
    onSubmit() {
      this.fresh();
    },
    fresh() {
      this.loadTable();
    },
    onSave(val) {
      if (val == "1") {
        this.$http.put("api/doctorate/limited").then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            this.fresh();
            this.paramsaform();
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
      if (val == "0") {
        var tableData = [...this.tableData];
        var formsubmit = [];
        var flag = true;
        tableData.forEach(Element => {
          if (val == "0") {
            if (flag) {
              if (!Element.fqrzme && !Element.qrzme) {
                this.$message.error("请填写完整在保存");
                flag = false;
              }
            }
          }
          formsubmit.push({
            id: Element.id,
            fqrzme: Element.fqrzme,
            qrzme: Element.qrzme
          });
        });
        if (flag) {
          this.$http.post("api/doctorate/limited", formsubmit).then(res => {
            if (res.data.code == 200) {
              this.$message.success(res.data.message);
              this.fresh();
              this.paramsaform();
            } else {
              this.$message.error(res.data.message);
            }
          });
        }
      }
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.formInline.year = res.data.data;
        this.loadTable();
      });
      this.paramsaform();
    },
    paramsaform() {
      this.$http.get("/api/doctorate/limited/status").then(res => {
        if (res.data.code == 200) {
          if (res.data.data == true) {
            this.isshow = true;
          } else {
            this.isshow = false;
          }
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    loadTable() {
      this.loading2 = true;
      this.$http
        .post("api/doctorate/limited/list", {
          query: this.formInline.user,
          pageNum: 1,
          pageSize: 20
        })
        .then(res => {
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 1000);
          this.loading2 = false;
          this.tableData = res.data.data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    } // 查看校区列表
  },
  computed: {},
  components: {
    searchcomponment: searchcomponment,
    timecommon
  }
};
</script>
<style lang="scss" scoped>
.limit {
  width: 100%;
  padding-top: 7px;
  .bg-purple-light {
    text-align: right;
  }
  .demo-form-inline {
    height: 56px !important;
  }
}
</style>
