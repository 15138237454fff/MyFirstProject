<template>
  <div class="reportQuota">
    <searchcomponment>
      <div slot="left">
        <el-input
          v-model="formInline.user"
          placeholder="请输入专业代码/名称"
          suffix-icon="el-icon-search"
          clearable
          style="width:200px;"
          @clear="freshsubmit"
        ></el-input>
        <el-button @click="onSubmit">查询</el-button>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="add"
          v-if="$btnAuthorityTest('reQuota:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="delist"
          v-if="$btnAuthorityTest('reQuota:delete')"
          >删除</el-button
        >
        <el-button
          @click="sbsave"
          plain
          type="primary"
          v-if="$btnAuthorityTest('reQuota:report')"
          >上报</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column prop="zydm" label="专业代码"> </el-table-column>
      <el-table-column prop="zymc" label="专业名称"> </el-table-column>
      <el-table-column label="所属学院" prop="xymc"></el-table-column>
      <el-table-column label="学习方式" prop="xxfs">
        <template slot-scope="scope">
          <span> {{ scope.row.xxxs | xxfsFilter(0) }} </span>
        </template>
      </el-table-column>
      <el-table-column label="审核状态">
        <template slot-scope="scope">
          <span :class="scope.row.zt | shztcolor">
            {{ scope.row.zt | shzt }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="tablexq(scope.row)"
            v-if="$btnAuthorityTest('reQuota:view')"
            >查看</span
          ><span
            v-if="
              $btnAuthorityTest('reQuota:view') &&
                $btnAuthorityTest('reQuota:update')
            "
          >
            |
          </span>
          <template v-if="$btnAuthorityTest('reQuota:update')">
            <span
              class="tablexg"
              @click="tablexg(scope.row)"
              v-if="scope.row.zt == '4' || scope.row.zt == '2'"
              >修改</span
            >
            <span
              v-if="scope.row.zt == '1' || scope.row.zt == '3'"
              style="color:#CCCCCC"
              >修改</span
            >
          </template>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      v-if="pageshow"
      ref="block"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <!-- 添加与详情 -->
    <el-dialog
      :title="dialogtitle"
      :visible.sync="dialogVisible"
      width="700px"
      :before-close="handleClose"
      :close-on-click-modal="false"
    >
      <quotAdd
        ref="quotAdd"
        v-if="dialogtitle == '添加'"
        :visibles="visibles"
        :fresh="freshsubmit"
      ></quotAdd>
      <quotxq v-if="dialogtitle == '详情'" ref="quotxq" :status="ztz"></quotxq>
    </el-dialog>
    <!-- 修改 -->
    <el-dialog
      title="修改"
      :visible.sync="dialogVisibles"
      width="700px"
      :before-close="handleClose"
      :close-on-click-modal="false"
    >
      <quotxg ref="quotxg" :visiblesd="visiblesd" :fresh="freshsubmit"></quotxg>
    </el-dialog>
    <timecommon :year="selectvalue"></timecommon>
  </div>
</template>

<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../componments/timecommon";
import pagination from "@/components/pagination";
import quotAdd from "./quotAdd";
import quotxq from "./quotxq";
import quotxg from "./quotxg";
export default {
  name: "reportQuota",
  data() {
    return {
      // 可选的年度列表
      yearOptions: [
        { label: "2019年", value: 2019 },
        { label: "2020年", value: 2020 }
      ],
      formInline: {
        user: ""
      },
      loading2: false,
      tableHeight: null,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      total: 0,
      multipleSelection: [],
      dialogVisible: false,
      selectvalue: null, // 年份
      dialogtitle: "添加",
      adddia: true,
      dialogVisibles: false,
      zyzsxy: [],
      yjfxxy: [],
      idlist: null,
      pageshow: true,
      ztz: "2"
    };
  },
  filters: {
    shzt(val) {
      switch (val) {
        case 4:
          return (val = "未上报");
        case 2:
          return (val = "退回");
        case 3:
          return (val = "审核中");
        case 1:
          return (val = "通过");
        default:
          break;
      }
    },
    shztcolor(val) {
      switch (val) {
        case 4:
          return "bule";
        case 2:
          return "red";
        case 3:
          return "warn";
        case 1:
          return "green";
        default:
          break;
      }
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.requireCurrentYear();
    this.getZyTree();
    this.enrollmentReport();
  },
  methods: {
    visiblesd(val) {
      this.dialogVisibles = val;
    },
    freshsubmit() {
      this.pageshow = false;
      setTimeout(() => {
        this.pageshow = true;
      }, 100);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    getZyTree() {
      this.$http
        .get(
          `api/enroll/enrollmentReport/getZyTree/${this.$stores.state.roleid_tole}`
        )
        .then(res => {
          // 校验数据异常
          if (!Array.isArray(res.data.data)) {
            // this.$message.error("数据异常");
          } else {
            this.zyzsxy = res.data.data;
          }
        });
    },
    // 获取学院与其相对的专业
    enrollmentReport() {
      this.$http
        .get(
          `api/enroll/enrollmentReport/getYjTree/${this.$stores.state.roleid_tole}`
        )
        .then(res => {
          // 校验数据异常
          if (!Array.isArray(res.data.data)) {
            // this.$message.error("数据异常");
          } else {
            this.yjfxxy = res.data.data;
          }
        });
    },
    visibles(val) {
      this.dialogVisible = val;
    },
    add() {
      this.dialogtitle = "添加";
      this.visibles(true);
      this.$nextTick(() => {
        this.$refs.quotAdd.zyzsxyshow = true;
        this.$refs.quotAdd.yjfxxyshow = true;
        this.$refs.quotAdd.freshform();
      });
    },
    sbsave() {
      this.multipleSelection.length == 0
        ? this.$message.error("请勾选数据在进行上报!")
        : this.$confirm("是否进行上报操作?", "上报", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(() => {
              this.$http
                .put("api/doctorate/quota/reported", this.multipleSelection)
                .then(res => {
                  if (res.data.code == 200) {
                    this.$message.success(res.data.message);
                    this.freshsubmit();
                  } else {
                    this.$message.error(res.data.message);
                  }
                });
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消上报"
              });
            });
    },
    tablexg(row) {
      this.idlist = row;
      var data = [];
      this.dialogVisibles = true;
      this.$http.get(`api/doctorate/quota/${row.id}`).then(res => {
        if (res.data.code == 400) {
          this.$message.error(res.data.message);
        } else {
          if (res.data.data.status == 0) {
            data = this.zyzsxy;
          } else {
            data = this.yjfxxy;
          }
          let result = res.data.data;
          result.sbxx = result.sbxx.filter(item => {
            return item.zsme !== 0 && item.khzrs !== 0;
          });
          this.$bus.$emit("formxg", { datatype: result, xy: data });
        }
      });
    },
    tablexq(row) {
      this.ztz = row.zt;
      this.dialogVisible = true;
      this.dialogtitle = "详情";
      this.$http.get(`api/doctorate/quota/${row.id}`).then(res => {
        if (res.data.code == 400) {
          this.$message.error(res.data.message);
        } else {
          let data = res.data.data;
          data.sbxx = data.sbxx.filter(item => {
            return item.zsme !== 0 && item.khzrs !== 0;
          });
          this.$bus.$emit("formxq", data);
          this.$http.get(`api/doctorate/eqrac/${row.id}`).then(res => {
            if (res.data.data.length > 0) {
              this.$refs.quotxq.shr = res.data.data[0].auditor;
              this.$refs.quotxq.shsj = res.data.data[0].verifytime;
              this.$refs.quotxq.opinion = res.data.data[0].comment;
            }
          });
        }
      });
    },
    formsavexg() {
      this.$nextTick(() => {});
    },
    handleClose() {
      this.dialogVisible = false;
      this.dialogVisibles = false;
    },
    handleSelectionChange(val) {
      this.toggleSelection(val);
    },
    toggleSelection(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    delist() {
      this.multipleSelection.length == 0
        ? this.$message.error("请勾选数据在进行删除!")
        : this.$confirm("是否进行删除操作?", "删除", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(() => {
              this.$http
                .delete("api/doctorate/quota", {
                  data: this.multipleSelection
                })
                .then(res => {
                  if (res.data.code == 200) {
                    this.$message.success(res.data.message);
                    this.freshsubmit();
                  } else {
                    this.$message.error(res.data.message);
                  }
                });
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: "已取消删除"
              });
            });
    },
    onSubmit() {
      this.freshsubmit();
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.yearOptions = res.data.data;
      });
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.selectvalue = res.data.data;
        this.takeList();
      });
    },
    takeList() {
      this.loading2 = true;

      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/doctorate/quota/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          year: this.selectvalue
        })
        .then(res => {
          // setTimeout(() => {
          //   this.loading2 = false;
          // }, 1000);
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    } // 查看校区列表
  },
  computed: {},
  components: {
    pagination: pagination,
    searchcomponment: searchcomponment,
    quotAdd: quotAdd,
    quotxq: quotxq,
    quotxg: quotxg,
    timecommon
  }
};
</script>
<style lang="scss" scoped>
.reportQuota {
  width: 100%;
  padding-top: 7px;
  .bg-purple-light {
    text-align: right;
  }
  .bule {
    color: #1890ff;
  }
  .red {
    color: #f56c6c;
  }
  .warn {
    color: #ff9a32;
  }
  .green {
    color: #66cc00;
  }
  table.gridtable {
    font-family: verdana, arial, sans-serif;
    font-size: 11px;
    color: #333333;
    border-width: 1px;
    border-color: #e5e5e5;
    border-collapse: collapse;
    width: 100%;
  }
  table.gridtable th {
    border-width: 1px;
    padding: 8px;
    border-style: solid;
    border-color: #e5e5e5;
    // background-color: #f2f2f2;
  }
  table.gridtable td {
    border-width: 1px;
    padding: 8px;
    border-style: solid;
    border-color: #e5e5e5;
    background-color: #f2f2f2;
    text-align: center;
    color: #333333;
    width: 180px;
  }
  table.gridtable .noneback {
    background: #fff;
  }
  .dialog-footers {
    text-align: center;
  }
  .demo-form-inline {
    height: 56px !important;
  }
}
</style>
