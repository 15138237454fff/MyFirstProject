<template>
  <div class="quotxq">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="按专业招生" name="0" v-if="zyzsxyshow">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <span>{{ form.optionxy }}</span>
          </el-form-item>
          <el-form-item label="选择专业：">
            <span>{{ form.optionzy }}</span>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>学习方式</td>
            <td>专业招生名额</td>
            <td>考核制人数</td>
          </tr>
          <tr v-for="(item, index) in sbxxzy">
            <td>
              <span v-if="item.xxfs == 1">全日制</span>
              <span v-if="item.xxfs == 2">非全日制</span>
            </td>
            <td class="noneback">
              <span>{{ item.zsme }}</span>
            </td>
            <td class="noneback">
              <span>{{ item.khzrs }}</span>
            </td>
          </tr>
        </table>
      </el-tab-pane>
      <el-tab-pane label="按研究方向招生" name="1" v-if="yjfxxyshow">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <span>{{ form.optionyjxy }}</span>
          </el-form-item>
          <el-form-item label="选择专业：">
            <span>{{ form.optionyjzy }}</span>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>方向代码</td>
            <td>研究方向</td>
            <td>学习方式</td>
            <td>方向招生名额</td>
            <td>考核制人数</td>
          </tr>
          <template>
            <tr v-for="(item, index) in sbxxyj">
              <td>
                <div
                  style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:150px"
                >
                  {{ item.dm }}
                </div>
              </td>
              <td>
                <div
                  style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:150px"
                >
                  {{ item.mc }}
                </div>
              </td>
              <td>
                <span v-if="item.xxfs == 1">全日制</span>
                <span v-if="item.xxfs == 2">非全日制</span>
              </td>
              <td class="noneback">
                <span>{{ item.zsme }}</span>
              </td>
              <td class="noneback">
                <span>{{ item.khzrs }}</span>
              </td>
            </tr>
          </template>
        </table>
      </el-tab-pane>
    </el-tabs>
    <div class="retrun" v-if="status == '2'">
      <li style="margin-bottom:10px;margin-left:100px">
        <span style="font-weight:600">研究生院审核（{{ shr }}） </span
        ><span>{{ shsj }}</span>
      </li>
      <p style="margin-left:100px">退回原因：{{ opinion }}</p>
    </div>
  </div>
</template>
<script>
export default {
  props: ["status"],
  name: "quotxq",
  data() {
    return {
      zyzsxyshow: false,
      yjfxxyshow: false,
      activeName: "0",
      selectvalue: "",
      form: {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      },
      shr: "",
      shsj: "",
      opinion: "",
      sbxxzy: [],
      sbxxyj: []
    };
  },
  mounted() {
    // 获取学院与其相对的专业
    this.$bus.$on("formxq", msg => {
      if (msg.zslb == "0") {
        this.zyzsxyshow = true;
        this.yjfxxyshow = false;
        this.activeName = "0";
        this.form.optionxy = msg.xymc;
        this.form.optionzy = msg.zymc;
        this.sbxxzy = msg.sbxx;
      }
      if (msg.zslb == "1") {
        this.zyzsxyshow = false;
        this.yjfxxyshow = true;
        this.activeName = "1";
        this.form.optionyjxy = msg.xymc;
        this.form.optionyjzy = msg.zymc;
        this.sbxxyj = msg.sbxx;
      }
    });
  },
  methods: {
    // tab切换
    handleClick() {},
    freshform() {}
  }
};
</script>
<style lang="scss" scoped>
table.gridtable {
  font-family: verdana, arial, sans-serif;
  font-size: 11px;
  color: #333333;
  border-width: 1px;
  border-color: #e5e5e5;
  border-collapse: collapse;
  width: 100%;
}
table.gridtable th {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  // background-color: #f2f2f2;
}
table.gridtable td {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  background-color: #f2f2f2;
  text-align: center;
  color: #333333;
  width: 180px;
}
table.gridtable .noneback {
  background: #fff;
}
.dialog-footers {
  text-align: center;
}
.demo-form-inline {
  height: 56px !important;
}
.retrun {
  background: url("image/返回.png") no-repeat;
  width: 100%;
  height: 60px;
  background-size: 10%;
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 10px;
  // text-align: center;
  padding-top: 30px;
  background-position: center left;
}
</style>
