<template>
  <div class="quotAdd">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="按专业招生" name="0">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <el-select v-model="form.optionxy" placeholder="选择学院">
              <el-option
                v-for="(item, index) in form.zyzsxy"
                :key="index"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择专业：">
            <el-select v-model="form.optionzy" placeholder="选择专业">
              <el-option
                v-for="(item, index) in form.zyzszy"
                :key="index"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>学习方式</td>
            <td>专业招生名额</td>
            <td>考核制人数</td>
          </tr>
          <tr v-if="qrzshow == '1' || qrzshow == '1,2'">
            <td>全日制</td>
            <td class="noneback">
              <!-- <el-input
                v-model="qrz[0].zsme"
                placeholder="请输入"
                
                type="number"
                :min="1"
              ></el-input> -->
              <el-input-number
                v-model="qrz[0].zsme"
                controls-position="right"
                placeholder="请输入内容"
                :min="1"
                :precision="0"
              ></el-input-number>
            </td>
            <td class="noneback">
              <!-- <el-input
                v-model="qrz[0].khzrs"
                placeholder="请输入"
                
                type="number"
                :min="1"
              ></el-input> -->
              <el-input-number
                v-model="qrz[0].khzrs"
                controls-position="right"
                placeholder="请输入内容"
                :min="1"
                :precision="0"
              ></el-input-number>
            </td>
          </tr>
          <tr v-if="qrzshow == '2' || qrzshow == '1,2'">
            <td>非全日制</td>
            <td class="noneback">
              <!-- <el-input
                v-model="fqrz[0].zsme"
                placeholder="请输入"
                clearable
                type="number"
                :min="1"
              ></el-input> -->
              <el-input-number
                v-model="fqrz[0].zsme"
                controls-position="right"
                placeholder="请输入内容"
                :min="1"
                :precision="0"
              ></el-input-number>
            </td>
            <td class="noneback">
              <!-- <el-input
                v-model="fqrz[0].khzrs"
                placeholder="请输入"
                
                type="number"
                :min="1"
              ></el-input> -->
              <el-input-number
                v-model="fqrz[0].khzrs"
                controls-position="right"
                placeholder="请输入内容"
                :min="1"
                :precision="0"
              ></el-input-number>
            </td>
          </tr>
        </table>
      </el-tab-pane>
      <el-tab-pane label="按研究方向招生" name="1">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <el-select
              v-model="form.optionyjxy"
              placeholder="选择学院"
              @change="selectoptionyjxy"
            >
              <el-option
                v-for="(item, index) in form.yjfxxy"
                :key="index"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择专业：">
            <el-select
              v-model="form.optionyjzy"
              placeholder="选择专业"
              @change="selectoptionyjzy"
            >
              <el-option
                v-for="(item, index) in form.yjfxzy"
                :key="index"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>方向代码</td>
            <td>研究方向</td>
            <td>学习方式</td>
            <td>方向招生名额</td>
            <td>考核制人数</td>
          </tr>
          <template>
            <tr v-for="(item, index) in qrzs">
              <td>{{ item.dm }}</td>
              <td>
                <div
                  style="overflow: hidden;text-overflow:ellipsis;white-space: nowrap;width:150px"
                >
                  {{ item.mc }}
                </div>
              </td>
              <td>
                <span v-if="item.xxfs == 1">全日制</span>
                <span v-if="item.xxfs == 2">非全日制</span>
              </td>
              <td class="noneback">
                <!-- <el-input
                  v-model="item.zsme"
                  placeholder="请输入"
                  clearable
                  type="number"
                  style="width:150px"
                  :min="1"
                ></el-input> -->
                <el-input-number
                  v-model="item.zsme"
                  controls-position="right"
                  placeholder="请输入内容"
                  style="width:150px"
                  :min="1"
                  :precision="0"
                ></el-input-number>
              </td>
              <td class="noneback">
                <!-- <el-input
                  v-model="item.khzrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                  style="width:150px"
                  :min="1"
                ></el-input> -->
                <el-input-number
                  v-model="item.khzrs"
                  controls-position="right"
                  placeholder="请输入内容"
                  style="width:150px"
                  :min="1"
                  :precision="0"
                ></el-input-number>
              </td>
            </tr>
          </template>
        </table>
      </el-tab-pane>
    </el-tabs>
    <div class="dialog__footer">
      <el-button @click="cancel">取消</el-button>
      <el-button type="primary" @click="formsave">保存</el-button>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    visibles: {
      type: Function,
      required: true
    },
    fresh: { type: Function, required: true }
  },
  name: "quotAdd",
  data() {
    return {
      zyzsxyshow: true,
      yjfxxyshow: true,
      activeName: "0",
      selectvalue: "",
      form: {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      },
      fqrz: [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "2"
        }
      ],
      qrz: [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "1"
        }
      ],
      fqrzs: [],
      qrzs: [],
      qrzshow: "",
      zyxymcA: "",
      zyxymcB: "",
      zyxymcC: "",
      zyxymcD: ""
    };
  },
  mounted() {
    // 获取学院与其相对的专业
    this.getZyTree();
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.optionxy": {
      handler: function(val) {
        const tmp = this.form.zyzsxy.find(el => {
          return el.value === val;
        });
        if (!tmp) {
          return;
        }
        // 专业方向的学院名称
        this.zyxymcA = tmp.label;
        this.form.zyzszy = tmp.children;
        this.form.optionzy = this.form.zyzszy[0].value;
        // 专业方向的专业名称
        this.zyxymcB = this.form.zyzszy[0].label;
        this.qrzshow = this.form.zyzszy[0].xxxs.sort().toString();
      }
    },
    "form.optionzy": {
      handler: function(val) {
        const tmp = this.form.zyzszy.find(el => el.value === val);
        if (!tmp) {
          return;
        }
        this.zyxymcB = tmp.label;
        this.qrzshow = tmp.xxxs.sort().toString();
        this.freshselect();
      }
    }
  },
  methods: {
    cancel() {
      this.visibles(false);
    },
    formsave() {
      var obj = {};
      if (this.activeName == "0") {
        if (!this.form.optionxy || !this.form.optionzy) {
          return this.$message.error("请填写完整再提交");
        }
        let sbxx = [];
        if (this.qrzshow.includes("1")) {
          sbxx = sbxx.concat(this.qrz);
        }
        if (this.qrzshow.includes("2")) {
          sbxx = sbxx.concat(this.fqrz);
        }
        obj = {
          xydm: this.form.optionxy,
          zydm: this.form.optionzy,
          xymc: this.zyxymcA,
          zymc: this.zyxymcB,
          zslb: this.activeName,
          sbxx
        };
      }
      if (this.activeName == "1") {
        if (!this.form.optionyjxy || !this.form.optionyjzy) {
          return this.$message.error("请填写完整再提交");
        }
        obj = {
          xydm: this.form.optionyjxy,
          zydm: this.form.optionyjzy,
          xymc: this.zyxymcC,
          zymc: this.zyxymcD,
          zslb: this.activeName,
          sbxx: this.qrzs
        };
      }
      this.$http.post("api/doctorate/quota", obj).then(res => {
        if (res.data.code == 400) {
          this.$message.error(res.data.message);
        } else {
          this.$message.success(res.data.message);
          this.visibles(false);
          this.fresh();
        }
      });
    },
    // 获取学院与其相对的专业
    getZyTree() {
      this.$http.get(`api/doctorate/pdac/quota`).then(res => {
        // 校验数据异常
        if (!Array.isArray(res.data.data)) {
          this.$message.error("数据异常");
        } else {
          // 按照专业招生进行学院筛选
          console.log(res.data.data, "博士招生新的接口");
          this.form.zyzsxy = res.data.data;
          this.form.yjfxxy = [...res.data.data];
        }
      });
    },
    // 获取学院与其相对的专业
    enrollmentReport() {},
    // tab切换
    handleClick() {
      this.form = {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      };
      this.fqrz = [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "2"
        }
      ];
      this.qrz = [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "1"
        }
      ];
      this.qrzs = [];
      this.getZyTree();
      this.qrzshow = "";
    },
    freshform() {
      this.form = {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      };
      this.fqrz = [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "2"
        }
      ];
      this.qrz = [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "1"
        }
      ];
      this.qrzs = [];
      this.getZyTree();
      this.zyzsxyshow = true;
      this.yjfxxyshow = true;
      this.activeName = "0";
      this.qrzshow = "";
    },
    freshselect() {
      this.fqrz = [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "2"
        }
      ];
      this.qrz = [
        {
          // 考核制人数
          khzrs: 0,
          // 招生名额
          zsme: 0,
          dm: "",
          mc: "",
          xxfs: "1"
        }
      ];
      this.qrzs = [];
    },
    selectoptionyjxy() {
      this.qrzs = [];
      // 按研究方向招生学院筛选专业
      const yjZy = this.form.yjfxxy.find(
        el => el.value === this.form.optionyjxy
      );
      if (yjZy.children.length && yjZy.children !== null) {
        this.zyxymcC = yjZy.label;
        this.form.yjfxzy = yjZy.children;
        this.form.optionyjzy = this.form.yjfxzy[0].value;
        this.zyxymcD = this.form.yjfxzy[0].label;
        if (
          this.form.yjfxzy[0].yjfx !== null &&
          this.form.yjfxzy[0].yjfx.length
        ) {
          this.qrzs = this.form.yjfxzy[0].yjfx;
        } else {
          this.$message.warning("当前无研究方向,请重新选择");
        }
      } else {
        this.form.optionyjzy = "";
        this.form.yjfxzy = [];
        this.zyxymcD = "";
        this.$message.error("当前学院所对应的专业不存在");
      }
    },
    selectoptionyjzy() {
      this.qrzs = [];
      const yjZy = this.form.yjfxzy.find(
        el => el.value === this.form.optionyjzy
      );
      if (!yjZy) {
        return;
      }
      if (!yjZy.yjfx) {
        this.$message.warning("当前无研究方向,请重新选择");
      } else {
        this.qrzs = yjZy.yjfx;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
table.gridtable {
  font-family: verdana, arial, sans-serif;
  font-size: 11px;
  color: #333333;
  border-width: 1px;
  border-color: #e5e5e5;
  border-collapse: collapse;
  width: 100%;
}
table.gridtable th {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  // background-color: #f2f2f2;
}
table.gridtable td {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  background-color: #f2f2f2;
  text-align: center;
  color: #333333;
  width: 180px;
}
table.gridtable .noneback {
  background: #fff;
}
.dialog-footers {
  text-align: center;
}
.demo-form-inline {
  height: 56px !important;
}
.dialog__footer {
  margin-top: 32px;
  padding: 10px 20px 20px;
  text-align: center;
}
</style>
