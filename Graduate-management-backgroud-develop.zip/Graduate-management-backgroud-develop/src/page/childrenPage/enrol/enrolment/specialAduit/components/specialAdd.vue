<template>
  <div class="specialAdd">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          @click="passClick"
          v-if="!writeable && status == 3"
          >通过</el-button
        >
        <el-button
          type="danger"
          @click="backClick"
          v-if="!writeable && status == 3"
          >退回</el-button
        >
      </div>
    </div>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="2" class="table-one">
        <tbody>
          <th colspan="6"><span>|</span> 招生专业信息</th>
          <tr>
            <td>学院名称</td>
            <td colspan="5">
              <span style="margin-left:10px;">{{ specialForm.xymc }}</span>
            </td>
          </tr>
          <tr>
            <td>专业名称</td>
            <td colspan="5">
              <span style="margin-left:10px;">{{ specialForm.zymc }}</span>
            </td>
          </tr>
          <tr>
            <td>学习方式</td>
            <td colspan="5">
              <span style="margin-left:10px;">{{
                specialForm.xxxs
                  .map(el => {
                    return el === 1 ? "全日制" : "非全日制";
                  })
                  .join(", ")
              }}</span>
            </td>
          </tr>
          <tr>
            <td>研究方向</td>
            <td colspan="5">
              <div
                v-for="(item, index) of specialForm.yjfx"
                :key="index"
                class="yjfx-row"
              >
                <span style="margin-left:10px;">{{
                  `${item.dm} ${item.mc} ${
                    item.xxfs === 1
                      ? "全日制"
                      : item.xxfs === 2
                      ? "非全日制"
                      : ""
                  }`
                }}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>联系人</td>
            <td colspan="5">
              <span style="margin-left:10px;">{{ specialForm.lxr }}</span>
            </td>
          </tr>
          <tr>
            <td>联系方式</td>
            <td colspan="5">
              <span style="margin-left:10px;">{{ specialForm.lxfs }}</span>
            </td>
          </tr>
          <tr>
            <td>学位点简介</td>
            <td colspan="5">
              <span style="margin-left:10px;">{{ specialForm.xwdjj }}</span>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-ones">
        <tbody>
          <th colspan="6"><span v-if="!writeable">|</span>博导与研究方向</th>
        </tbody>
        <tr class="onestd">
          <td>博导工号（姓名）</td>
          <td>博导属性</td>
          <td>研究方向</td>
          <td>证件类型</td>
          <td>证件号码</td>
        </tr>
        <tr
          class="twotd"
          v-for="(bdyjfx, index) in specialForm.bdyyjfx"
          :key="'bkbd' + index"
        >
          <td>
            <span style="margin-left:10px;">{{
              `${bdyjfx.xm}(${bdyjfx.gh})`
            }}</span>
          </td>
          <td>
            <span style="margin-left:10px;">{{
              getListValue(bdyjfx.dslb, bdsxarr)
            }}</span>
          </td>
          <td>
            <span style="margin-left:10px;">{{ bdyjfx.yjfx }}</span>
          </td>
          <td>
            <span>{{ bdyjfx.sfzjlxmc }}</span>
          </td>
          <td>
            <span>{{ bdyjfx.sfzjh }}</span>
          </td>
        </tr>
      </table>

      <table border="1" cellspacing="0" cellpadding="2" class="table-two">
        <tbody>
          <th colspan="6"><span>|</span>拟招生人数</th>
          <tr>
            <td>全日制人数</td>
            <td>
              <span style="margin-left:10px;">{{ specialForm.qrzrs }}人</span>
            </td>
            <td>非全日制人数</td>
            <td>
              <span style="margin-left:10px;">{{ specialForm.fqrzrs }}人</span>
            </td>
          </tr>
          <tr>
            <td>
              全日制申请考核制人数（全日制）
            </td>
            <td>
              <span style="margin-left:10px;">{{ specialForm.qrzkhrs }}人</span>
            </td>
            <td>
              非全日制申请考核制人数（非全日制）
            </td>
            <td>
              <span style="margin-left:10px;"
                >{{ specialForm.fqrzkhrs }}人</span
              >
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-three">
        <tbody>
          <th colspan="6"><span>|</span>初试考试科目</th>
          <tr class="td-header">
            <td>科目类别</td>
            <td>科目代码</td>
            <td>科目名称</td>
          </tr>
          <tr>
            <td>外国语</td>
            <td>
              <div v-for="(item, index) of specialForm.wgy" :key="index">
                <span>{{ item.dm }}</span>
              </div>
            </td>
            <td>
              <div v-for="(item, index) of specialForm.wgy" :key="index">
                <span>{{ item.mc }}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>业务课一</td>
            <td>
              <div v-for="(item, index) of specialForm.ywky" :key="index">
                <span>{{ item.dm }}</span>
              </div>
            </td>
            <td>
              <div v-for="(item, index) of specialForm.ywky" :key="index">
                <span>{{ item.mc }}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>业务课二</td>
            <td>
              <div v-for="(item, index) of specialForm.ywke" :key="index">
                <span>{{ item.dm }}</span>
              </div>
            </td>
            <td>
              <div v-for="(item, index) of specialForm.ywke" :key="index">
                <span>{{ item.mc }}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-four">
        <tbody>
          <tr>
            <td>初试参考书目</td>
            <td colspan="5">
              <pre>{{ specialForm.cscksm }}</pre>
            </td>
          </tr>
          <tr>
            <td>复试科目及参考书</td>
            <td colspan="5">
              <pre style="margin-left:10px;">{{ specialForm.fskmjcks }}</pre>
            </td>
          </tr>
          <tr>
            <td>同等学力加试科目及参考书</td>
            <td colspan="5">
              <pre style="margin-left:10px;">{{
                specialForm.tdlxjskmjcks
              }}</pre>
            </td>
          </tr>
          <tr>
            <td>备注</td>
            <td colspan="5">
              <pre style="margin-left:10px;">{{ specialForm.bz }}</pre>
            </td>
          </tr>
        </tbody>
      </table>
      <el-dialog
        title="退回"
        :visible.sync="dialogVisible"
        width="380px"
        top="31vh"
      >
        <p>是否不通过该条记录？</p>
        <p class="required">请输入不通过原因：</p>
        <div>
          <textarea
            style="width:100%;height:60px;"
            v-model="comment"
          ></textarea>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="confirmBack">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
export default {
  name: "specialAdd",
  data() {
    return {
      specialForm: {
        // 学习形式
        xxxs: [],
        // 研究方向
        yjfx: [{ dm: "", mc: "", xxfx: "" }],
        // 非全日制人数
        fqrzrs: 0,
        // 复试科目及参考书
        fskmjcks: "",
        // 港澳台招生人数
        gatzsrs: 0,
        // 联系方式
        lxfs: "",
        // 联系人
        lxr: "",
        // 全日制人数
        qrzrs: 0,
        // 是否港澳台招生
        sfgatzs: 0,
        // 是否推免生招生
        sftmszs: 0,
        // 思想政治理论
        sxzzll: [{ dm: "", mc: "" }],
        // 外国语
        wgy: [{ dm: "", mc: "" }],
        // 业务课一
        ywky: [{ dm: "", mc: "" }],
        // 业务课二
        ywke: [{ dm: "", mc: "" }],
        // 同等学力加试科目及参考书
        tdlxjskmjcks: "",
        // 推免生人数
        tmsrs: 0,
        // 学位点简介
        xwdjj: "",
        // 学院代码
        xydm: "",
        // 专业代码
        zydm: "",
        zymc: "",
        xymc: "",
        bdyyjfx: [],
        qrzkhrs: 0,
        fqrzkhrs: 0,
        bz: "",
        cscksm: ""
      },
      // //是否可写
      // writeable: true,
      // 审核状态
      status: "",
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 退回的原因
      comment: "",
      // 一键退回对话框可见性
      dialogVisible: false,
      bdsxarr: []
    };
  },
  mounted() {
    this.$http.get("/api/system/dict/select/all").then(res => {
      this.bdsxarr = res.data.data.dslb;
    });
  },
  created() {
    // 请求学院专业信息
    // this.requireXY();
    // 如果是查看页面
    if (this.id == 3) {
      // 回显数据
      this.dataBack();
    }
  },
  computed: {
    // 根据路由信息返回是否可写
    writeable() {
      if (this.$route.query.id != 3) {
        return true;
      } else {
        return false;
      }
    },
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  filters: {
    dslb(val, bdsxarr) {
      if (val && bdsxarr) {
        var flag = bdsxarr.find(el => el.value == val);
        if (!flag) {
          return false;
        }
        return flag.label;
      }
    }
  },
  methods: {
    // 回显历史的申请记录
    dataBack() {
      this.$http.get(`/api/doctorate/pdc/${this.specialId}`).then(res => {
        const data = res.data.data;
        console.log(data);
        // 非空验证
        if (!data) {
          this.$message.error("获取历史上报记录失败，请重试");
          return;
        }
        // 保存请求获取的表单值
        Object.keys(this.specialForm).forEach(key => {
          this.specialForm[key] = data[key];
        });
        this.specialForm.zymc = data.zymc;
        // 保存审核状态
        this.status = data.zt;
      });
    },
    // 点击一键通过的出现对话框方法
    passClick() {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmPass,
        title: "通过",
        msgOne: "是否通过该条记录？",
        msgTwo: " "
      });
    },
    // 确认通过的方法
    confirmPass() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
      this.$http
        .post("/api/doctorate/pdac/audit", {
          ids: [this.specialId],
          comment: "",
          status: 1
        })
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("通过成功");
            // 返回列表页
            this.$router.go(-1);
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    // 点击一键退回出现对话框的方法
    backClick() {
      // 清空意见
      this.comment = "";
      // 呼出对话框
      this.dialogVisible = true;
    },
    // 确认一键退回的方法
    confirmBack() {
      if (this.comment === "") {
        this.$message.error("请填写审核意见");
        return;
      }
      // 关闭对话框
      this.dialogVisible = false;
      this.$http
        .post("/api/doctorate/pdac/audit", {
          ids: [this.specialId],
          comment: this.comment,
          status: 2
        })
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("退回成功");
            // 返回列表页
            this.$router.go(-1);
          } else {
            this.$message.error(res.data.message);
          }
        });
    }
    // 获取学院和专业的可选列表
    // requireXY() {
    //   this.$http.post("/api/doctorate/bsOption/bkyxOption", {}).then(res => {
    //     const data = res.data.data;
    //     // 验证列表数据格式是否正确
    //     if (!Array.isArray(data)) {
    //       this.$message.error("获取学院和专业信息失败，请重试");
    //       return;
    //     }
    //     // 保存学院的待选列表
    //     this.xyOptions = data;
    //     const tmp = this.xyOptions.filter(el => {
    //       return el.value === this.specialForm.xydm;
    //     });
    //     if (!tmp[0]) {
    //       return;
    //     }
    //     this.zyOptions = tmp[0].children;
    //     this.specialForm.xymc = tmp[0].label;
    //   });
    // }
  }
  // watch: {
  //   "specialForm.xydm": {
  //     handler(val) {
  //       const tmp = this.xyOptions.filter(el => {
  //         return el.value === val;
  //       });
  //       if (!tmp[0]) {
  //         return;
  //       }
  //       this.specialForm.xymc = tmp[0].label;
  //       this.zyOptions = tmp[0].children;
  //       this.specialForm.zydm = this.zyOptions[0].value;
  //     }
  //   }
  // }
};
</script>
<style lang="scss" scoped>
.specialAdd {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;

    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .box {
    // border: 1px solid rgba(228, 228, 228, 1);
    font-size: 14px;
    background-color: #fff;
    padding: 20px;
    margin-top: 10px;
    margin-bottom: 0;
    min-height: 73vh;
    table {
      width: 100%;
      border: 1px solid rgba(228, 228, 228, 1);
      border-collapse: collapse;
      color: #333;
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
      }
      td {
        width: 200px;
        height: 40px;
        border: 1px solid #e5e5e5;
      }
    }
    .table-one {
      margin-bottom: 10px;
      td {
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
          text-align: center;
        }
        &:nth-child(even) {
          text-align: left;
          background: #fafafa;
        }
        .el-checkbox-group {
          padding-left: 20px;
        }
      }
    }
    .table-ones {
      margin-bottom: 10px;
      .onestd {
        background: #f2f2f2;
        padding-left: 10px;
        text-align: center;
        .el-checkbox-group {
          padding-left: 20px;
        }
      }
      .twotd {
        text-align: center;
        .el-checkbox-group {
          padding-left: 20px;
        }
      }
    }
    .table-two {
      margin-top: 20px;
      td {
        text-align: center;
        position: relative;
      }
      /deep/ .my-switch {
        position: absolute;
        top: 50%;
        left: 50%;
        margin-left: -90px;
        margin-top: -10px;
        .el-switch__label {
          position: absolute;
          display: none;
          color: #fff;
        }
        .el-switch__label--left {
          z-index: 9;
          left: 20px;
        }
        .el-switch__label--right {
          z-index: 9;
          left: -4px;
        }
        .el-switch__label.is-active {
          display: block;
        }
        .el-switch .el-switch__core,
        .el-switch .el-switch__label {
          width: 50px !important;
        }
      }
    }
    .table-three {
      margin-top: 20px;
      td {
        text-align: center;
      }
      .td-header {
        background: #f0f2f5;
      }
    }
    .table-four {
      margin-top: 20px;
      td:nth-child(odd) {
        background: #f2f2f2;
        text-align: center;
      }
      .td-header {
        background: #f0f2f5;
      }
    }
    .add {
      &.el-button {
        padding: 0 10px;
      }
      font-size: 24px;
      color: #1e6fd9;
      border-radius: 50%;
      padding-left: 10px;
      background: #fff;
      outline: none;
      border: none;
    }
    .yjfx-row {
      width: 60%;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      align-items: center;
      .el-input:first-child {
        flex: 1;
      }
      .el-input:nth-child(2) {
        flex: 2;
        margin-left: 5px;
      }
    }
    .danwei {
      line-height: 40px;
      margin-right: 5px;
      color: #ccc;
      font-style: normal;
    }
    .mc {
      width: 100%;
      display: flex;
      flex-wrap: nowrap;
      align-items: center;
    }
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
