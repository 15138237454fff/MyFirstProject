<template>
  <div class="stuInfoDetail">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
    </div>
    <!-- 基本信息 -->
    <table>
      <tr>
        <td class="listcss" colspan="7" style="text-align:left;font-weight:bold">| 基本信息</td>
      </tr>
      <tr>
        <td class="listcss">学号</td>
        <td colspan="2">{{datalist.zcxh}}</td>
        <td class="listcss">姓名拼音</td>
        <td colspan="2">{{datalist.xmpy}}</td>
        <td rowspan="5" style="width:150px;height:100px">
          <!-- <img :src="datalist.zp" alt="" style="width:100%;display: inline;"> -->
        </td>
      </tr>
      <tr>
        <td class="listcss">证件类型</td>
        <td colspan="2">{{datalist.zjlx}}</td>
        <td class="listcss">证件号码</td>
        <td colspan="2">{{datalist.zjhm}}</td>
      </tr>
      <tr>
        <td class="listcss">出生日期</td>
        <td colspan="2">{{datalist.csrq}}</td>
        <td class="listcss">出生所在地</td>
        <td colspan="2">{{datalist.csdm}}</td>
      </tr>
      <tr>
        <td class="listcss">民族</td>
        <td colspan="2">{{datalist.mzm}}</td>
        <td class="listcss">性别</td>
        <td colspan="2">{{datalist.xbm}}</td>
      </tr>
      <tr>
        <td class="listcss">婚姻状况</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">政治面貌</td>
        <td colspan="2">{{datalist.zzmmm}}</td>
      </tr>
      <tr>
        <td class="listcss">现役军人</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">籍贯</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">户口所在地</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">通讯地址</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">邮政编码</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">固定电话</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">移动电话</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">电子信箱</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">现在学习或工作单位</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">现在学习或工作单位性质</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">考生来源</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">档案所在地</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">档案所在单位名称</td>
        <td colspan="2">{{datalist.xh}}</td>
        <td class="listcss">档案所在单位邮编</td>
        <td colspan="3">{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">档案所在单位地址</td>
        <td colspan="6">{{datalist.xh}}</td>
      </tr>
    </table>
    <!-- 个人经历 -->
    <table>
      <tr>
        <td class="listcss" colspan="7" style="text-align:left;font-weight:bold">| 个人经历</td>
      </tr>
      <tr>
        <td class="listcss" rowspan="2">何时何地何原因受过何种奖励或处分</td>
        <td>时间</td>
        <td>地点</td>
        <td>奖惩项目</td>
        <td>奖惩名称</td>
      </tr>
      <tr>
        <td>时间</td>
        <td>地点</td>
        <td>奖惩项目</td>
        <td>奖惩名称</td>
      </tr>
      <tr>
        <td class="listcss" rowspan="2">家庭主要成员</td>
        <td>姓名</td>
        <td>与本人关系</td>
        <td>联系电话</td>
        <td>在何单位工作/任何职务</td>
      </tr>
      <tr>
        <td>时间</td>
        <td>地点</td>
        <td>奖惩项目</td>
        <td>奖惩名称</td>
      </tr>
      <tr>
        <td class="listcss" rowspan="2">学习与工作经历(请从高中学习经历填起)</td>
        <td>起止年月</td>
        <td>学习或工作单位</td>
        <td colspan="2">任何职务</td>
      </tr>
      <tr>
        <td>地点</td>
        <td>奖惩项目</td>
        <td colspan="2">奖惩名称</td>
      </tr>
      <tr>
        <td class="listcss" rowspan="2">发表的主要学术论文和著作</td>
        <td>发表时间</td>
        <td colspan="3">论文中文题目</td>
      </tr>
      <tr>
        <td>地点</td>
        <td colspan="3">奖惩名称</td>
      </tr>
    </table>
    <!-- 学位学历信息 -->
    <table>
      <tr>
        <td class="listcss" colspan="7" style="text-align:left;font-weight:bold">| 学位学历信息</td>
      </tr>
      <tr>
        <td class="listcss">获学士学位单位</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">获学士学位专业</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">获学士学位年月</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">本科毕业单位</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">本科毕业专业</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">本科毕业年月</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">获硕士学位单位</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">获硕士学位专业</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">获硕士学位年月</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">硕士毕业单位</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">硕士毕业专业</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">硕士毕业专业</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">学士学位证书编号</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">本科毕业证书编号</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">最后学历</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">硕士学位证书编号</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">硕士毕业证书编号</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">最后学位</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">取得本科学历学习形式</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">获硕士学位方式</td>
        <td>{{datalist.xsxm}}</td>
        <td class="listcss">在校生注册学号</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
    </table>
    <!-- 报考信息 -->
    <table>
      <tr>
        <td class="listcss" colspan="7" style="text-align:left;font-weight:bold">| 报考信息</td>
      </tr>
      <tr>
        <td class="listcss">报考院系</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">报考专业</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">研究方向</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">报考学习方式</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">报考博导</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">博导属性</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">考试方式</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">报考类别</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">专项计划</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">是否申请考核</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">定向就业单位</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">定向就业单位所在地</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">外国语</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">业务课一</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
      <tr>
        <td class="listcss">业务课二</td>
        <td colspan="4">{{datalist.xh}}</td>
      </tr>
    </table>
    <!-- 推荐人信息 -->
    <table>
      <tr>
        <td class="listcss" colspan="7" style="text-align:left;font-weight:bold">| 推荐人信息</td>
      </tr>
      <tr>
        <td class="listcss">推荐人姓名</td>
        <td>{{datalist.xh}}</td>
        <td class="listcss">推荐人性别</td>
        <td>{{datalist.xsxm}}</td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: "stuInfoDetail",
  data() {
    return {
      datalist: {}
    };
  },

  created() {
    // 如果是查看页面
    if (this.id == 3) {
      // 回显数据
      this.dataBack();
    }
  },
  computed: {
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  filters: {
    // sfyx(val) {
    //   switch (val) {
    //     case "1":
    //       return "是";
    //     case "0":
    //       return "否";
    //     default:
    //       break;
    //   }
    // },
    // // 证件类型
    // zjlxFilter(val) {
    //   switch (val) {
    //     case "01":
    //       return "居民身份证";
    //     case "03":
    //       return "港澳台身份证";
    //     case "04":
    //       return "华侨身份证件";
    //     default:
    //       return " ";
    //   }
    // },
    // // 婚姻状况
    // hfmFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "未婚";
    //     case "2":
    //       return "已婚";
    //     case "3":
    //       return "丧偶";
    //     case "4":
    //       return "离婚";
    //     case "9":
    //       return "其他";
    //     default:
    //       return " ";
    //   }
    // },
    // // 现役军人
    // xyjrmFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "军队在职干部";
    //     case "2":
    //       return "军校应届本科毕业生";
    //     case "3":
    //       return "国防生";
    //     case "0":
    //       return "非军人";
    //     default:
    //       return " ";
    //   }
    // },
    // // 考生来源码
    // kslymFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "科学研究人员";
    //     case "2":
    //       return "高等教育教师";
    //     case "3":
    //       return "中等教育教师";
    //     case "4":
    //       return "其他在职人员";
    //     case "5":
    //       return "普通全日制应届本科毕业生";
    //     case "6":
    //       return "成人应届本科毕业生";
    //     case "7":
    //       return "其他人员";
    //     default:
    //       return " ";
    //   }
    // },
    // // 取得最后学历的学习形式
    // xxxsFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "普通全日制";
    //     case "2":
    //       return "成人教育";
    //     case "3":
    //       return "自学考试";
    //     case "4":
    //       return "网络教育";
    //     case "5":
    //       return "获境外学历或学位证书者";
    //     case "6":
    //       return "其他";
    //     default:
    //       return " ";
    //   }
    // },
    // // 最后学历
    // xlmFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "研究生";
    //     case "2":
    //       return "本科毕业";
    //     case "3":
    //       return "本科结业";
    //     case "4":
    //       return "高职高专";
    //     default:
    //       return " ";
    //   }
    // },
    // // 最后学位
    // xwmFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "博士学位";
    //     case "2":
    //       return "硕士学位";
    //     case "3":
    //       return "学士学位";
    //     case "4":
    //       return "无";
    //     default:
    //       return " ";
    //   }
    // },
    // // 考试方式
    // ksfsmFilter(val) {
    //   switch (val) {
    //     case "21":
    //       return "全国统考";
    //     case "23":
    //       return "单独考试";
    //     case "25":
    //       return "管理类联考";
    //     case "26":
    //       return "法硕联考";
    //     case "27":
    //       return "强军计划";
    //     case "28":
    //       return "援藏计划";
    //     default:
    //       return " ";
    //   }
    // },
    // // 专项计划
    // zxjhFilter(val) {
    //   switch (val) {
    //     case "1":
    //       return "强军计划";
    //     case "2":
    //       return "援藏计划";
    //     case "4":
    //       return "少数民族骨干计划";
    //     case "7":
    //       return "退役大学生计划";
    //     case "0":
    //       return "无专项计划";
    //     default:
    //       return " ";
    //   }
    // },
    // // 报考类别
    // bklbmFilter(val) {
    //   switch (val) {
    //     case "11":
    //       return "非定向就业";
    //     case "12":
    //       return "定向就业";
    //     default:
    //       return " ";
    //   }
    // },
    // bkxxfs(val) {
    //   switch (val) {
    //     case "1":
    //       return "全日制";
    //     case "2":
    //       return "非全日制";
    //     case "1,2":
    //       return "全日制,非全日制";
    //     default:
    //       return " ";
    //   }
    // }
  },
  methods: {
    // 回显历史的申请记录
    dataBack() {
      // 如果id为空不请求数据
      if (!this.specialId) {
        return;
      }
      this.$http.get(`/api/doctorate/doctoral/${this.specialId}`).then(res => {
        const data = res.data.data;
        console.log(data);
        // 非空验证
        if (!data) {
          this.$message.error("获取历史上报记录失败，请重试");
          return;
        }
        // 保存请求获取的表单值
        this.datalist = Object.assign({}, this.datalist, data);
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.stuInfoDetail {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
  }
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    line-height: 36px;

    thead {
      height: 60px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 36px;
      padding-left: 5px;
      text-align: center;
      width: 150px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      width: 180px;
      background: #f5f5f5;
    }
  }
}
</style>

