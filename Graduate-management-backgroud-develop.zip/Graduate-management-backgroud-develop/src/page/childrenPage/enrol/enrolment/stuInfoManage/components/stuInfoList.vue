<template>
  <div class="stuInfoList">
    <searchcomponment>
      <div slot="left">
        <el-input
          suffix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考生编号/姓名"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select
          v-model="limitQuery.collegeCode"
          style="width:150px;"
          filterable
        >
          <el-option label="全部学院" :value="null"></el-option>
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select
          v-model="limitQuery.majorCode"
          style="width:150px;"
          filterable
        >
          <el-option label="全部专业" :value="null"></el-option>
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="genarateClick"
          v-if="$btnAuthorityTest('SubjectManage:generate')"
          >生成考生编号</el-button
        >
        <el-button
          type="primary"
          @click="cskcap"
          v-if="$btnAuthorityTest('SubjectManage:arrange')"
          >初试考场安排</el-button
        >
        <el-button
          type="primary"
          plain
          @click="outputClick"
          v-if="$btnAuthorityTest('SubjectManage:export')"
          >导出</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
    >
      <el-table-column type="index" width="55" label="序号"></el-table-column>
      <el-table-column prop="ksbh" label="考生编号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="xbm" label="性别">
        <template slot-scope="scope">
          <span>{{ scope.row.xbm | xmbFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="bkyxsmc" label="报考学院"></el-table-column>
      <el-table-column prop="bkzymc" label="报考专业"></el-table-column>
      <el-table-column label="学习方式">
        <template slot-scope="scope">
          <span>{{ scope.row.bkxxfs | xxfsFilter(1) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="初试场地(外国语)" prop="cscd2"></el-table-column>
      <el-table-column
        label="初试场地(业务课一)"
        prop="cscd3"
      ></el-table-column>
      <el-table-column
        label="初试场地(业务课二)"
        prop="cscd4"
      ></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click="goDetail(scope.$index)"
            type="text"
            size="small"
            class="under-line"
            v-if="$btnAuthorityTest('SubjectManage:view')"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <el-dialog
      title="初试考场安排"
      :visible.sync="dialogVisible"
      width="350px"
      :close-on-click-modal="false"
    >
      <el-form ref="form" :model="sizeForm" label-width="80px" size="mini">
        <el-form-item label="科目类别" :required="true">
          <el-select v-model="sizeForm.subjectArea" @change="dialogform">
            <el-option
              v-for="item in kmOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="报考学院" :required="true">
          <el-select v-model="sizeForm.collegeCode" @change="handleXyChange">
            <el-option
              v-for="item in bkxyArr"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="报考专业" :required="true">
          <el-select v-model="sizeForm.majorCode" @change="dialogform">
            <el-option
              v-for="item in bkzyArr"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="初试场地" :required="true">
          <el-select v-model="sizeForm.ldh">
            <el-option
              v-for="item in cscdArr"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="configForm">确 定</el-button>
      </span>
    </el-dialog>
    <timecommon :year="year"></timecommon>
  </div>
</template>

<script>
import timecommon from "../../../componments/timecommon";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "stuInfoList",
  components: {
    searchcomponment: searchcomponment,
    timecommon
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // 报考院校
          bkxy: "",
          // 报考专业
          bkzy: "",
          // 考生报名点名称
          bmdmc: "",
          // id
          id: "",
          // 考生编号
          ksbh: "",
          // 考生姓名
          xm: "",
          // 学习方式
          ksxxfs: "",
          // 性别
          xbm: ""
        }
      ],
      // 分页查询的参数
      limitQuery: {
        //	院校
        collegeCode: null,
        majorCode: null,
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 学院的待选列表
      xyOptions: [],
      zyOptions: [],
      // 勾选的列
      selectRowList: [],
      tableHeight: null,
      dialogVisible: false,
      sizeForm: {
        subjectArea: 2,
        majorCode: "",
        ldh: "",
        collegeCode: "",
        cdmc: ""
      },
      // 考试类别
      kmlbArr: [],
      // 报考学院
      bkxyArr: [],
      // 报考专业
      bkzyArr: [],
      // 初试场地
      cscdArr: [],
      year: 2019,
      kmOptions: [
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywke" },
        { label: "业务课二", value: 4, name: "ywky" }
      ],
      bkzycopy: []
    };
  },
  filters: {
    xmbFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "男";
        case 2:
          return "女";
        case 0:
          return "未知性别";
        case 9:
          return "未说明性别";
        default:
          break;
      }
    }
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.zylist(this.limitQuery.collegeCode);
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    // 获取可选学院列表
    this.requireXY();
    this.doctorateXy();
  },
  watch: {
    $route(to) {
      if (to.name === "SubjectManage") {
        this.loadTable();
      }
    },
    "limitQuery.collegeCode": {
      handler: function(val) {
        this.zylist(val);
        this.loadTable();
      },
      deep: true // 对象内部的属性监听，也叫深度监听
    },
    "limitQuery.majorCode": {
      handler: function() {
        this.loadTable();
      }
    },
    "sizeForm.collegeCode": {
      handler: function(val) {
        console.log(this.bkzyArr);
        // var xystring = this.bkxyArr.find(el => el.value == val);
        // if (!xystring) {
        //   return false;
        // }
        // this.bkzyArr = JSON.parse(JSON.stringify(xystring.children));
        // this.bkzycopy = JSON.parse(JSON.stringify(xystring.children));
      },
      deep: true // 对象内部的属性监听，也叫深度监听
    },
    "sizeForm.ldh": {
      handler: function(val) {
        var xystring = this.cscdArr.find(el => el.value == val);
        if (!xystring) {
          return false;
        }
        this.sizeForm.cdmc = xystring.label;
      },
      deep: true // 对象内部的属性监听，也叫深度监听
    }
  },
  methods: {
    zylist(val) {
      this.$http
        .post(`/api/doctorate/bsOption/bkzyOption`, { yxdm: val })
        .then(res => {
          let result = res.data;
          if (result.code == 200) {
            this.zyOptions = res.data.data;
            this.limitQuery.majorCode = null;
          } else {
            this.$message.error(result.message);
          }
        });
    },
    // 添加初试场地
    configForm() {
      this.$http.post("/api/doctorate/doctoral", this.sizeForm).then(res => {
        let result = res.data;
        if (result.code == 200) {
          this.dialogVisible = false;
          this.loadTable();
        } else {
          this.$message.error(result.message);
        }
      });
    },
    // 初试考场安排
    cskcap() {
      this.sizeForm = {
        subjectArea: 2,
        majorCode: "",
        ldh: "",
        collegeCode: "",
        cdmc: ""
      };
      this.dialogVisible = true;
    },
    handleXyChange() {
      this.sizeForm.majorCode = "";
      var xystring = this.bkxyArr.find(
        el => el.value == this.sizeForm.collegeCode
      );
      if (!xystring) {
        return false;
      }
      this.bkzyArr = JSON.parse(JSON.stringify(xystring.children));
      this.bkzycopy = JSON.parse(JSON.stringify(xystring.children));
      this.dialogform();
    },
    // 根据科目代码，学院代码，专业代码查询初试考场安排信息
    dialogform() {
      this.xtld();
      this.$http
        .post("/api/doctorate/doctoral/query", {
          collegeCode: this.sizeForm.collegeCode,
          majorCode: this.sizeForm.majorCode,
          subjectArea: this.sizeForm.subjectArea
        })
        .then(res => {
          let result = res.data;
          if (result.code == 200) {
            if (result.data.arrange) {
              // zydm
              if (this.bkzyArr.length) {
                var bkzyArr = this.bkzyArr.find(
                  el => el.value == result.data.zydm
                );
                bkzyArr.label = `${
                  this.bkzycopy.find(el => el.value == result.data.zydm).label
                }(已安排)`;
                console.log(this.bkzycopy);
                this.sizeForm.ldh = result.data.ldh;
                this.sizeForm.cdmc = result.data.cdmc;
              }
            } else {
              this.doctorateXy();
              this.sizeForm.collegeCode = result.data.xydm;
              this.sizeForm.majorCode = result.data.zydm;
              this.sizeForm.ldh = this.sizeForm.cdmc = "";
            }
          }
        });
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      this.loading = true;
      this.$http
        .post("/api/doctorate/doctoral/list", this.limitQuery)
        .then(res => {
          // setTimeout(() => {
          //   this.loading = false;
          // }, 1000);
          this.loading = false;
          let data = res.data;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 查看详情
    goDetail(index) {
      this.$router.push({
        path: "/SubjectManage",
        query: { id: 3, specialId: this.tableData[index].id }
      });
    },
    // 点击生成考生编号的方法
    genarateClick() {
      this.$http.put("/api/doctorate/doctoral").then(res => {
        if (res.data.code == 200) {
          this.$message.success(res.data.message);
          this.loadTable();
        } else {
          this.$message.success(res.data.message);
        }
      });
      // this.$message.warning("当前功能暂未开放");
    },
    // 点击导出的方法
    outputClick() {
      this.$http.get("/api/doctorate/doctoralExport/checkKs").then(res => {
        let data = res.data.data;
        if (data > 0) {
          window.location.href = "/api/doctorate/doctoralExport/exportDocter";
        } else {
          this.$message.error("暂无可导出的考生数据");
        }
      });
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.year = res.data.data;
        this.loadTable();
      });
    },
    // 获取学院的可选列表
    requireXY() {
      // system/dict/select/enroll/local/college
      this.$http.post("/api/doctorate/bsOption/bkyxOption", {}).then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        } // 保存学院的待选列表
        this.xyOptions = data;
      });
    }, // 文件导入按钮触发的方法
    // 查询所有已通过的学院和专业信息【初试考场安排】
    doctorateXy() {
      this.$http.get("/api/doctorate/pdac").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        } // 保存学院的待选列表
        this.bkxyArr = data;
        // this.bkzyArr = this.bkxyArr[0].children;
      });
    },
    xtld() {
      this.$http.get("/api/system/xtld/select").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        } // 保存学院的待选列表
        this.cscdArr = data;
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.stuInfoList {
  padding-top: 7px;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  /deep/ .el-date-editor {
    margin-left: 10px;
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
