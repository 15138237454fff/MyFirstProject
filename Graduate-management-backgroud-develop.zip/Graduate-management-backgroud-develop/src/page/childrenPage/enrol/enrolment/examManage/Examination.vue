<template>
  <div class="examManage">
    <searchcomponment>
      <div slot="left">
        <el-input
          suffix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入科目代码/名称"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select
          v-model="limitQuery.kmlb"
          @change="loadTable"
          style="width:30%;"
          filterable
        >
          <el-option label="全部科目类型" :value="null"></el-option>
          <el-option
            v-for="(item, index) in kmOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="kssjClick"
          v-if="$btnAuthorityTest('Examination:settime')"
          >设置考试时间</el-button
        >
        <el-button
          type="primary"
          @click="clickOutput"
          plain
          v-if="$btnAuthorityTest('Examination:export')"
          >导出</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$storage.tableHeaderColor"
      :default-sort="{ prop: 'kmdm', order: 'ascending' }"
    >
      <el-table-column type="index" width="55" label="序号"></el-table-column>
      <el-table-column prop="kmdm" label="科目代码"></el-table-column>
      <el-table-column prop="kmmc" label="科目名称"></el-table-column>
      <el-table-column label="科目类别">
        <template slot-scope="scope">
          <span>{{ scope.row.kmlb | kmlbFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column label="考试时间">
        <template slot-scope="scope">
          <span
            >{{ scope.row.ksrq }} {{ scope.row.jtkssj }}-{{
              scope.row.jtjssj
            }}</span
          >
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click="goModify(scope.row)"
            type="text"
            size="small"
            class="under-line"
            v-if="$btnAuthorityTest('Examination:update')"
            >修改</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <slot-dialog
      title="设置考试时间"
      ref="kssjDialog"
      :callback="confirmKSSJ"
      btnName="确定"
      :widthpx="'700px'"
    >
      <table class="slot-kssj">
        <tr>
          <th>科目类别</th>
          <th>考试时间</th>
        </tr>
        <tr v-for="(item, index) of kmOptions" :key="index">
          <td>{{ item.label }}</td>
          <td>
            <div>
              <el-date-picker
                v-model="kssjForm[item.name].ksrq"
                type="date"
                placeholder="选择日期"
                style="width:180px;"
                format="yyyy.MM.dd"
              ></el-date-picker>
              <el-time-picker
                v-model="kssjForm[item.name].jtkssj"
                placeholder="开始"
                style="width:120px"
                format="HH:mm"
              >
              </el-time-picker>
              <span>至</span>
              <el-time-picker
                v-model="kssjForm[item.name].jtjssj"
                placeholder="结束"
                style="width:120px"
                format="HH:mm"
              >
              </el-time-picker>
            </div>
          </td>
        </tr>
      </table>
    </slot-dialog>
    <slot-dialog
      title="修改"
      ref="modifyDialog"
      :callback="confirmModify"
      btnName="保存"
      :widthpx="'550px'"
    >
      <div class="slot-box">
        <div>
          科目代码：
          <span>{{ modifyForm.kmdm }}</span>
        </div>
        <div>
          科目名称：
          <span>{{ modifyForm.kmmc }}</span>
        </div>
        <div>
          科目类别：
          <span>{{ modifyForm.kmlb | kmlbFilter }}</span>
        </div>
        <div>
          考试时间：
          <el-date-picker
            v-model="modifyForm.ksrq"
            type="date"
            placeholder="选择日期"
            style="width:150px;"
            format="yyyy.MM.dd"
          ></el-date-picker>
          <el-time-picker
            v-model="modifyForm.jtkssj"
            placeholder="开始"
            style="width:100px"
            format="HH:mm"
          >
          </el-time-picker>
          <span>至</span>
          <el-time-picker
            v-model="modifyForm.jtjssj"
            placeholder="结束"
            style="width:100px"
            format="HH:mm"
          >
          </el-time-picker>
        </div>
      </div>
    </slot-dialog>
    <timecommon :year="limitQuery.nf"></timecommon>
  </div>
</template>
<script>
import timecommon from "../../componments/timecommon";
import slotDialog from "@/components/skb/slotDialog";
import searchcomponment from "@/components/searchcomponment";
export default {
  name: "Examination",
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 分页查询的参数
      limitQuery: {
        // 学院代码
        kmlb: null,
        query: "",
        pageSize: 15,
        pageNum: 1,
        nf: null
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 科目的待选列表
      kmOptions: [
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywke" },
        { label: "业务课二", value: 4, name: "ywky" }
      ],
      kssjForm: {
        // 外国语
        wgy: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课二
        ywke: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课一
        ywky: { jtkssj: "", jtjssj: "", ksrq: "" }
      },
      tableHeight: null,
      formpass: false,
      // 待提交的修改表单
      modifyForm: {
        // ID
        id: "",
        // 具体时间 1:上午 2：下午
        jtsj: 1,
        // 科目代码
        kmdm: "",
        // 科目类别 1:政治思想理论 2：外国语 3：业务课一 4，业务课二
        kmlb: "",
        // 科目名称
        kmmc: "",
        // 考试时间
        ksrq: "",
        jtkssj: "",
        jtjssj: ""
      }
    };
  },
  components: {
    "slot-dialog": slotDialog,
    searchcomponment: searchcomponment,
    timecommon
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.requireCurrentYear();
    // 请求当前的招生年度
  },
  watch: {
    $route(to) {
      if (to.name === "examManage") {
        this.loadTable();
      }
    },
    formpass(val) {
      return val;
    }
  },
  methods: {
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.nf = res.data.data;
        this.loadTable();
      });
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      this.loading = true;
      this.$http
        .post("/api/doctorate/examManager/list", this.limitQuery)
        .then(res => {
          this.loading = false;
          let data = res.data;
          // setTimeout(() => {
          //   this.loading = false;
          // }, 1000);
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 点击修改的出现对话框方法
    goModify(row) {
      console.log(`点击修改条数据`, row);
      // 呼出对话框
      this.$refs.modifyDialog.openDialog();
      // 根据当前科目数据显示修改详情
      Object.keys(this.modifyForm).forEach(key => {
        this.modifyForm[key] = row[key];
      });
      this.modifyForm.jtjssj = `${this.modifyForm.ksrq} ${this.modifyForm.jtjssj}:00`;
      this.modifyForm.jtkssj = `${this.modifyForm.ksrq} ${this.modifyForm.jtkssj}:00`;
    },
    // 点击设置考试时间的出现对话框方法
    kssjClick() {
      console.log("点击设置考试时间");
      // 将下拉框设为默认值
      this.kssjForm = {
        // 外国语
        wgy: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课二
        ywke: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课一
        ywky: { jtkssj: "", jtjssj: "", ksrq: "" }
      };
      // 呼出对话框
      this.$refs.kssjDialog.openDialog();
    },
    // 确认修改
    confirmModify() {
      let tmpObj = { ...this.modifyForm };
      tmpObj.ksrq = this.$tagTime(tmpObj.ksrq, "yyyy-MM-dd");
      tmpObj.jtjssj = this.$tagTime(tmpObj.jtjssj, "HH:mm");
      tmpObj.jtkssj = this.$tagTime(tmpObj.jtkssj, "HH:mm");
      this.$http
        .put("/api/doctorate/examManager/update", tmpObj)
        .then(res => {
          if (res.data.code == 200) {
            this.$message.success("修改成功");
            // 重新请求列表
            this.$refs.modifyDialog.dialogVisible = false;
            this.loadTable();
          } else {
            this.$message.error(res.data.message);
            this.$refs.modifyDialog.dialogVisible = true;
          }
        })
        .catch(err => {
          this.$message.error(err.response.data.message);
        });
    },
    confirmKSSJ() {
      var flag = true;
      var keyValue = ["wgy", "ywke", "ywky"];
      let tmpObj = this.kssjForm;
      keyValue.forEach(element => {
        if (flag) {
          if (
            !tmpObj[element].ksrq ||
            !tmpObj[element].jtkssj ||
            !tmpObj[element].jtjssj
          ) {
            this.$message.error("具体时间不能为空");
            flag = false;
          } else {
            tmpObj[element].ksrq = this.$tagTime(
              tmpObj[element].ksrq,
              "yyyy-MM-dd"
            );

            tmpObj[element].jtkssj = this.$tagTime(
              tmpObj[element].jtkssj,
              "HH:mm"
            );

            tmpObj[element].jtjssj = this.$tagTime(
              tmpObj[element].jtjssj,
              "HH:mm"
            );
          }
        }
      });
      if (flag) {
        this.$http
          .put("/api/doctorate/examManager/updateTime", tmpObj)
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("修改成功");
              this.$refs.kssjDialog.dialogVisible = false;
              // 重新请求列表
              this.loadTable();
            } else {
              this.$message.error(res.data.message);
              this.$refs.kssjDialog.dialogVisible = true;
            }
          })
          .catch(err => {
            this.$message.error(err.response.data.message);
          });
      }
    },
    clickOutput() {
      // 点击导出的方法
      this.$http.get("/api/doctorate/doctoralExport/checkKM").then(res => {
        let data = res.data;
        if (data.data > 0) {
          window.location.href = "/api/doctorate/doctoralExport/exportKM";
        } else {
          this.$message.error(data.message);
        }
      });
    }
  },
  filters: {
    // 过滤科目类别
    kmlbFilter(val) {
      switch (val) {
        case 2:
          return "外国语";
        case 3:
          return "业务课一";
        case 4:
          return "业务课二";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.examManage {
  padding-top: 7px;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button,
    .el-select {
      margin-left: 0px;
    }
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
