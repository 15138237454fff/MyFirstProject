<template>
  <div class="reviewof">
    <searchcomponment>
      <div slot="left">
        <el-input
          v-model="formInline.user"
          placeholder="请输入专业代码/名称"
          suffix-icon="el-icon-search"
          style="width:200px;"
          clearable
          @clear="freshForm"
        ></el-input>
        <el-button @click="onSubmit">查询</el-button>
        <el-select
          v-model="listQuery.queryPage.xydm"
          placeholder="选择学院"
          @change="freshForm"
          style="width:220px"
        >
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="pass"
          v-if="$btnAuthorityTest('reviewsh:allPass')"
          >一键通过</el-button
        >
        <el-button
          type="danger"
          @click="onpass"
          v-if="$btnAuthorityTest('reviewsh:allBack')"
          >一键退回</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"> </el-table-column>
      <el-table-column prop="zydm" label="专业代码"> </el-table-column>
      <el-table-column prop="zymc" label="专业名称"> </el-table-column>
      <el-table-column label="所属学院" prop="xymc"></el-table-column>
      <el-table-column label="学习方式" prop="xxfs">
        <template slot-scope="scope">
          <span> {{ scope.row.xxxs | xxfs }} </span>
        </template>
      </el-table-column>
      <el-table-column label="审核状态">
        <template slot-scope="scope">
          <span :class="scope.row.zt | shztcolor">
            {{ scope.row.zt | shzt }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="listmore(scope.row)"
            v-if="$btnAuthorityTest('reviewsh:view')"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      ref="block"
      v-if="pageshow"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <!-- 通过 -->
    <el-dialog title="一键通过" :visible.sync="centerDialogVisible" width="15%">
      <p style="text-align:center">是否通过所有已选记录?</p>
      <span slot="footer" class="dialog-footer">
        <div class="dialog-footers">
          <el-button @click="centerDialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="savesub">确 定</el-button>
        </div>
      </span>
    </el-dialog>
    <!-- 退回 -->
    <el-dialog
      title="一键退回"
      :visible.sync="centerDialogVisibles"
      width="15%"
    >
      <span>是否不通过所有已选记录？</span>
      <el-form ref="ruleForm" class="demo-ruleForm">
        <el-form-item label="请输入不通过原因：" :required="true">
        </el-form-item>
        <el-input type="textarea" v-model="desc"></el-input>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <div class="dialog-footers">
          <el-button @click="canceldia">取 消</el-button>
          <el-button type="primary" @click="returnsubmit">确 定</el-button>
        </div>
      </span>
    </el-dialog>
    <!-- 详情 -->
    <el-dialog title="详情" :visible.sync="list" width="700px">
      <reviewofxq ref="reviewofxq"></reviewofxq>
      <span slot="footer" class="dialog-footer">
        <div
          class="dialog-footers"
          v-if="this.tablerow.zt == '2' || this.tablerow.zt == '3'"
        >
          <el-button @click="returnsave" type="danger">退回</el-button>
          <el-button type="primary" @click="passsubmit">通过</el-button>
        </div>
      </span>
    </el-dialog>
    <timecommon :year="selectvalue"></timecommon>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import timecommon from "../../componments/timecommon";
import searchcomponment from "@/components/searchcomponment";
import reviewofxq from "./reviewofxq";
export default {
  name: "reviewof",
  data() {
    return {
      formInline: {
        user: ""
      },
      loading2: false,
      tableHeight: null,
      tableData: [],
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15, // 每页显示条数
          xydm: null
        }
      },
      // 学院的待选列表
      xyOptions: [],
      total: 0,
      centerDialogVisible: false,
      centerDialogVisibles: false,
      desc: "",
      list: false,
      selectvalue: null,
      tgthid: "",
      tablerow: {},
      pageshow: true,
      tgshow: false,
      thshow: false,
      multipleSelection: []
    };
  },
  filters: {
    shzt(val) {
      switch (val) {
        case 4:
          return (val = "未上报");
        case 2:
          return (val = "退回");
        case 3:
          return (val = "审核中");
        case 1:
          return (val = "通过");
        default:
          break;
      }
    },
    shztcolor(val) {
      switch (val) {
        case 4:
          return "bule";
        case 2:
          return "red";
        case 3:
          return "warn";
        case 1:
          return "green";
        default:
          break;
      }
    },
    xxfs(val) {
      var key = val.toString();
      switch (key) {
        case "1":
          return "全日制";
        case "2":
          return "非全日制";
        case "1,2":
          return "全日制,非全日制";
        default:
          break;
      }
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    // 获取可选学院列表
    this.requireXY();
    this.requireCurrentYear();
  },
  methods: {
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.selectvalue = res.data.data;
        this.takeList();
      });
    },
    canceldia() {
      this.centerDialogVisibles = false;
      this.desc = "";
    },
    pass() {
      this.thshow = false;
      this.tgshow = false;
      this.multipleSelection.length == 0
        ? this.$message.error("请勾选数据")
        : (this.centerDialogVisible = true);
    },
    onpass() {
      var flag = true;
      this.thshow = false;
      this.tgshow = false;
      if (this.multipleSelection.length == 0) {
        return this.$message.error("请勾选数据");
      }
      this.multipleSelection.forEach(el => {
        if (flag) {
          var index = this.tableData.find(item => item.id == el);
          if (index.zt == "1") {
            this.$message.error("通过状态的不能退回");
            flag = false;
          }
        }
      });
      if (flag) {
        this.centerDialogVisibles = true;
      }
    },
    returnsave() {
      this.centerDialogVisibles = true;
      this.thshow = true;
    },
    // 获取学院的可选列表
    requireXY() {
      this.$http.post("/api/doctorate/bsOption/bkyxOption", {}).then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        }
        // 保存学院的待选列表
        this.xyOptions = data;
        this.xyOptions.unshift({
          label: "全部学院",
          value: null
        });
        // 取第一个学院为默认选中
        this.listQuery.queryPage.xydm = data[0].value;
      });
    },
    returnsubmit() {
      var ids = [];
      if (this.thshow) {
        ids = [this.tablerow.id];
      } else {
        ids = this.multipleSelection;
      }
      if (this.desc == "") {
        return this.$message.error("请填写退回原因");
      }
      this.$http
        .post("api/doctorate/eqrac/audit", {
          comment: this.desc,
          status: "2",
          ids: ids
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message.error(res.data.message);
          } else {
            this.$message.success(res.data.message);
            this.centerDialogVisibles = false;
            this.desc = "";
            this.list = false;
            this.freshForm();
          }
        });
    },
    passsubmit() {
      this.centerDialogVisible = true;
      this.thshow = true;
    },
    savesub() {
      var ids = [];
      if (this.tgshow) {
        ids = [this.tablerow.id];
      } else {
        ids = this.multipleSelection;
      }
      this.$http
        .post("api/doctorate/eqrac/audit", {
          status: "1",
          ids: ids
        })
        .then(res => {
          if (res.data.code == 400) {
            this.$message.error(res.data.message);
          } else {
            this.$message.success(res.data.message);
            this.centerDialogVisible = false;
            this.list = false;
            this.freshForm();
          }
        });
    },
    freshForm() {
      this.pageshow = false;
      setTimeout(() => {
        this.pageshow = true;
      }, 100);
      this.takeList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    listmore(row) {
      this.tablerow = row;
      this.tgthid = row.id;
      setTimeout(() => {
        this.list = true;
      }, 100);
      this.$http.get(`api/doctorate/quota/${row.id}`).then(res => {
        if (res.data.code == 400) {
          this.$message.error(res.data.message);
        } else {
          this.$bus.$emit("formxq", res.data.data);
        }
      });
    },
    handleSelectionChange(val) {
      this.toggleSelection(val);
    },
    toggleSelection(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    onSubmit() {
      this.freshForm();
    },
    takeList() {
      this.loading2 = true;
      const params = {};
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      params.xydm = this.listQuery.queryPage.xydm;
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/doctorate/eqrac/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          year: this.selectvalue,
          college: params.xydm
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    } // 查看校区列表
  },
  computed: {},
  components: {
    pagination: pagination,
    searchcomponment: searchcomponment,
    reviewofxq: reviewofxq,
    timecommon
  }
};
</script>
<style lang="scss" scoped>
.reviewof {
  width: 100%;
  padding-top: 7px;
  .bg-purple-light {
    text-align: right;
  }
  .bule {
    color: #1890ff;
  }
  .red {
    color: #f56c6c;
  }
  .warn {
    color: #ff9a32;
  }
  .green {
    color: #66cc00;
  }
  .dialog-footers {
    text-align: center;
  }
  table.gridtable {
    font-family: verdana, arial, sans-serif;
    font-size: 11px;
    color: #333333;
    border-width: 1px;
    border-color: #e5e5e5;
    border-collapse: collapse;
    width: 100%;
  }
  table.gridtable th {
    border-width: 1px;
    padding: 8px;
    border-style: solid;
    border-color: #e5e5e5;
    // background-color: #f2f2f2;
  }
  table.gridtable td {
    border-width: 1px;
    padding: 8px;
    border-style: solid;
    border-color: #e5e5e5;
    background-color: #f2f2f2;
    text-align: center;
    color: #333333;
    width: 180px;
  }
  table.gridtable .noneback {
    background: #fff;
  }
}
</style>
