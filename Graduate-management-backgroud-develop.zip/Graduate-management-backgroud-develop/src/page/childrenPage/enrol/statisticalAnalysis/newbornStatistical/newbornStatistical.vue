<template>
  <div class="newbornStatistical">
    <my-breadcrumb>
      <div slot="left">
        <el-input placeholder="请输入考生编号/姓名" prefix-icon="el-icon-search" clearable @clear="loadTable" v-model="limitQuery.query" @keyup.enter.native="initLoadTable"></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.year" @change="initLoadTable">
          <el-option v-for="(item, index) in yearList" :key="index" :label="item + ' 年'" :value="item"></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table :data="tableData" border style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading" element-loading-text="加载中" element-loading-spinner="el-icon-loading" ref="box">
        <el-table-column prop="ksbh" label="考生编号" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="xm" label="姓名" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="xymc" label="录取学院" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="zymc" label="录取专业" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="xxfs" label="学习方式" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <span>{{ scope.row.xxfs | xxxsFilter }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="nums" label="收集点赞次数" align="center" show-overflow-tooltip>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination @paginate="handlePaginate" :pageSize="limitQuery.pageSize" :pageNum="limitQuery.pageNum" :msgCount="msgCount"></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "newbornStatistical",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        year: null
      },
      loading: false,
      yearList: [],
      selectedHistoryList: [],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.requireYearList()
      .then(this.requireYear)
      .then(this.initLoadTable);
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let { pageNum, pageSize, year, query } = this.limitQuery,
        tmpObj = {
          pageNum,
          pageSize,
          query,
          nf: year
        };
      // 发送请求列表数据的请求
      this.$http
        .post("/api/system/xsdz/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 请求学年列表
    requireYearList() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("/api/enroll/psc/getYear")
          .then(res => {
            this.yearList = res.data.data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    requireYear() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("/api/enroll/psc/annual")
          .then(res => {
            this.limitQuery.year = res.data.data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    }
  },
  filters: {
    xxxsFilter(val) {
      if (val === "1") {
        return "全日制";
      }
      if (val === "2") {
        return "非全日制";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.newbornStatistical {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
