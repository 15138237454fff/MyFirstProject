<template>
  <div class="estimatedEnrollStatistical">
    <my-breadcrumb>
      <div slot="left">
        <el-select v-model="limitQuery.year" @change="initLoadTable">
          <el-option v-for="(item, index) in yearList" :key="index" :label="item + ' 年'" :value="item"></el-option>
        </el-select>
        <el-select v-model="limitQuery.xy" @change="initLoadTable">
          <el-option v-for="(item, index) in xyList" :key="index" :label="item.label" :value="item.value"></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <span class="blue">预计报名数量：{{ msgCount }}</span>
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table :data="tableData" border style="width: 100%" :header-cell-style="$storage.tableHeaderColor" :height="tableHeight" v-loading="loading" element-loading-text="加载中" element-loading-spinner="el-icon-loading" ref="box">
        <el-table-column prop="xm" label="姓名" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="xbm" label="性别" align="center" :width="80" show-overflow-tooltip>
          <template slot-scope="scope">
            <span>{{ scope.row.xbm | sexFilter}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="symc" label="生源" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="dqszd" label="当前所在地" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="zgxl" label="最高学历" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="xxfs" label="学习方式" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <span>{{ scope.row.xxfs | xxxsFilter }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="jddx" label="就读大学" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="type" label="计划报考研究生类型" align="center" show-overflow-tooltip>
          <template slot-scope="scope">
            <span>{{ scope.row.type === "1" ? "学术型" : "专业学位" }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="bkxymc" label="计划报考学院" align="center" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="bkzymc" label="计划报考专业" align="center" show-overflow-tooltip>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination @paginate="handlePaginate" :pageSize="limitQuery.pageSize" :pageNum="limitQuery.pageNum" :msgCount="msgCount"></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "estimatedEnrollStatistical",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        year: null,
        xy: ""
      },
      count: 0,
      loading: false,
      yearList: [],
      xyList: [],
      selectedHistoryList: [],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.requireYearList()
      .then(this.requireYear)
      .then(this.initLoadTable);
    this.requireXyList();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let { pageNum, pageSize, year, query, xy } = this.limitQuery,
        tmpObj = {
          pageNum,
          pageSize,
          query,
          nf: year,
          xydm: xy
        };
      // 发送请求列表数据的请求
      this.$http
        .post("/api/system/xbsj/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 请求学院列表
    requireXyList() {
      this.$http.get(`/api/system/dict/select/enroll/academy`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("学院列表数据获取失败");
          return false;
        }
        this.xyList = data;
      });
    },
    // 请求学年列表
    requireYearList() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("/api/enroll/psc/getYear")
          .then(res => {
            this.yearList = res.data.data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    requireYear() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("/api/enroll/psc/annual")
          .then(res => {
            this.limitQuery.year = res.data.data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    }
  },
  filters: {
    xxxsFilter(val) {
      if (val === "1") {
        return "全日制";
      }
      if (val === "2") {
        return "非全日制";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.estimatedEnrollStatistical {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
