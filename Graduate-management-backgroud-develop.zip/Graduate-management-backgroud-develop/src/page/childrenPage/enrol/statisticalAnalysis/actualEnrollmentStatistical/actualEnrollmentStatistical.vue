<template>
  <div class="newbornStatistical">
    <my-breadcrumb>
      <div slot="left">
        <el-select v-model="limitQuery.year">
          <el-option
            v-for="(item, index) in yearList"
            :key="index"
            :label="item + ' 年'"
            :value="item"
          ></el-option>
        </el-select>
        <el-radio-group v-model="limitQuery.pycc" type="primary" size="small">
          <el-radio-button :label="null">全部</el-radio-button>
          <el-radio-button :label="2">硕士</el-radio-button>
          <el-radio-button :label="1">博士</el-radio-button>
        </el-radio-group>
        <el-button @click="clickSearch" type="primary">搜索</el-button>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <span style="font-weight:bold;"
          >总人数：{{ sexStatistical.man + sexStatistical.women }}</span
        >
      </div>
    </my-breadcrumb>
    <div class="top-area">
      <div>
        <div class="enroll-zy">
          <span class="title">招生专业（{{ limitQuery.year }}年）</span>
          <div>
            <span class="num">{{ zyStatistical.dqzs }}</span>
            <div>
              <span>年增长</span>
              <span
                class="el-icon-caret-top green"
                v-if="zyStatistical.dqzs - zyStatistical.qynzs >= 0"
              ></span>
              <span class="el-icon-caret-bottom red" v-else></span>
              <span>{{ computedZyDiff }}%</span>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div class="enroll-xxfs">
          <span class="title">学习方式</span>
          <div ref="xxfs" style="height:100px;width:100%"></div>
        </div>
      </div>
      <div>
        <div class="enroll-nnbl">
          <span class="title">男女比例</span>
          <div>
            <div>
              <span class="blue">{{ sexStatistical.man }}</span>
              <span class="orange">{{ sexStatistical.women }}</span>
            </div>
            <div>
              <span>{{ computedManScale }}%</span>
              <span>{{ 100 - computedManScale }}%</span>
            </div>
            <div>
              <img src="@/assets/mail.png" alt="" />
              <img src="@/assets/femail.png" alt="" />
            </div>
            <el-progress
              :percentage="computedManScale"
              :show-text="false"
              stroke-linecap="butt"
            ></el-progress>
          </div>
        </div>
      </div>
    </div>
    <div class="bottom-area">
      <el-tabs v-model="activeName" @tab-click="handleTabClick">
        <el-tab-pane label="历年招生统计" name="history">
          <div class="history" v-if="activeName === 'history'">
            <div class="left" ref="history"></div>
            <div class="right">
              <div>
                <span style="font-size:20px;font-weight:bold">招生年度</span>
                <span class="grey">硕士</span>
                <span class="grey">博士</span>
              </div>
              <div
                v-for="(item, index) of historyStatistical.filter(el => el.nf)"
                :key="index"
              >
                <span>{{ item.nf }}</span>
                <span>{{ item.mast }}</span>
                <span>{{ item.doct }}</span>
              </div>
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="考生生源地分析" name="student">
          <div
            ref="chinaMap"
            v-loading="loading"
            style="width:100%;height:100%"
            v-if="activeName === 'student'"
          ></div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
let echarts = require("echarts");
import data from "../../../../../../static/china.json";
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "newbornStatistical",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        year: null,
        pycc: null
      },
      zyStatistical: { dqzs: "", qynzs: "" },
      xxfsStatistical: {
        // 非全日制人数
        fqrz: "",
        // 全日制人数
        qrz: ""
      },
      sexStatistical: {
        man: 0,
        women: 0
      },
      mapTotal: 0,
      mapList: [],
      historyStatistical: [],
      loading: false,
      yearList: [],
      count: 0,
      selectedHistoryList: [],
      activeName: "history",
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.requireYearList()
      .then(this.requireYear)
      .then(this.clickSearch);
  },
  methods: {
    // 培养方式
    drawXxfs() {
      let myChart = echarts.init(this.$refs.xxfs);
      let data = [
        { value: this.xxfsStatistical.qrz, name: "全日制" },
        {
          value: this.xxfsStatistical.fqrz,
          name: "非全日制"
        }
      ];
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c} ({d}%)"
        },
        legend: {
          orient: "vertical",
          x: "left",
          data: ["全日制", "非全日制"],
          formatter: name => {
            let tmpObj = data.find(el => {
              return el.name === name;
            });
            if (!tmpObj) {
              return name;
            }
            return `${name} : ${tmpObj.value}`;
          }
        },
        color: ["#007bea", "#ffcc00"],
        series: [
          {
            name: "课程统计",
            type: "pie",
            center: ["70%", "50%"],
            radius: ["60%", "80%"],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: "center"
              },
              emphasis: {
                show: false,
                textStyle: {
                  fontSize: "14",
                  fontWeight: "bold"
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    drawHistory() {
      let myChart = echarts.init(this.$refs.history);
      const option = {
        tooltip: {
          trigger: "item",
          formatter: "{b}: {c} ({d}%)"
        },
        legend: {
          data: ["硕士", "博士"],
          right: "10%"
        },
        grid: {
          left: 50
        },
        dataZoom: [
          {
            type: "slider",
            show: true,
            xAxisIndex: [0],
            start: 1,
            end: 100
          },
          {
            type: "inside",
            xAxisIndex: [0],
            start: 1,
            end: 100
          }
        ],
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: this.yearList
        },
        yAxis: {
          type: "value",
          name: "招生人数/人"
        },
        color: ["#007bea", "#ff9a32"],
        series: [
          {
            name: "硕士",
            type: "line",
            data: this.historyStatistical.map(el => el.mast)
          },
          {
            name: "博士",
            type: "line",
            data: this.historyStatistical.map(el => el.doct)
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    drawMap() {
      console.log(data);
      echarts.registerMap("china", data);
      let myChart = echarts.init(this.$refs.chinaMap);
      const option = {
        tooltip: {
          trigger: "item",
          formatter: params => {
            return `<span style="margin-right:50px;font-size:18px;">${
              params.name
            }</span> ${((params.value / this.mapTotal) * 100).toFixed(
              0
            )}%<hr /><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#409dff;margin-right:5px;"></span>硕士招生：${
              params.data.mast
            }<br /><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#FF9A32;margin-right:5px;"></span>博士招生：${
              params.data.doct
            }`;
          },
          extraCssText: "box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);",
          backgroundColor: "#fff",
          padding: 20,
          textStyle: {
            color: "#333",
            fontSize: 14
          }
        },
        visualMap: {
          min: Math.min(
            ...this.mapList.map(el => {
              return el.mast + el.doct;
            })
          ),
          max: Math.max(
            ...this.mapList.map(el => {
              return el.mast + el.doct;
            })
          ),
          text: ["高", "低"],
          realtime: false,
          calculable: true,
          inRange: {
            color: ["lightskyblue", "yellow", "orangered"]
          }
        },
        series: [
          {
            type: "map",
            map: "china",
            zoom: 1.7,
            top: "30%",
            label: {
              fontSize: 12,
              color: "#333",
              formatter: params => {
                return params.name.replace(
                  /省|市|自治区|回族|维吾尔|特别行政区|壮族/g,
                  ""
                );
              },
              show: true
            },
            data: this.mapList.map(el => {
              return {
                name: el.sfmc,
                value: el.doct + el.mast,
                doct: el.doct,
                mast: el.mast
              };
            }),
            itemStyle: {
              normal: {
                borderColor: "rgba(0, 0, 0, 0.2)"
              },
              emphasis: {
                areaColor: "#F3B329", // 鼠标选择区域颜色
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 10,
                borderWidth: 0,
                shadowColor: "rgba(0, 0, 0, 0.5)"
              }
            }
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    },
    clickSearch() {
      this.requireData();
      this.handleTabClick();
    },
    handleTabClick() {
      this.$nextTick(() => {
        if (this.activeName === "history") {
          this.requireHistory();
        } else {
          this.requireSource();
        }
      });
    },
    // 请求基本数据
    requireData() {
      this.requireZyStatistical();
      this.requireXxfsStatistical();
      this.requireSexStatistical();
    },
    // 请求专业统计数据
    requireZyStatistical() {
      this.$http
        .post("/api/enroll/statis/zyStatis", {
          nf: this.limitQuery.year,
          pyccm: this.limitQuery.pycc
        })
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.zyStatistical = data.data;
        });
    },
    // 请求学习方式统计数据
    requireXxfsStatistical() {
      this.$http
        .post("/api/enroll/statis/xxfsStatis", {
          nf: this.limitQuery.year,
          pyccm: this.limitQuery.pycc
        })
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.xxfsStatistical = data.data;
          this.drawXxfs();
        });
    },
    // 请求男女比例统计数据
    requireSexStatistical() {
      this.$http
        .post("/api/enroll/statis/sexStatis", {
          nf: this.limitQuery.year,
          pyccm: this.limitQuery.pycc
        })
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.sexStatistical = data.data;
        });
    },
    // 请求历年招生数据
    requireHistory() {
      this.$http.get("/api/enroll/statis/hisStatis").then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        data.data = this.yearList.map(el => {
          let tmpObj = data.data.find(obj => {
            return obj.nf === el;
          });
          if (!tmpObj) {
            return { nf: null, mast: null, doct: null };
          } else {
            return { nf: tmpObj.nf, mast: tmpObj.mast, doct: tmpObj.doct };
          }
        });
        this.historyStatistical = data.data;
        this.drawHistory();
      });
    },
    // 请求生源地数据
    requireSource() {
      this.loading = true;
      this.$http
        .get(`/api/enroll/statis/studentArea/${this.limitQuery.year}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.mapTotal = data.data.zs;
          this.mapList = data.data.chilren;
          this.drawMap();
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求学年列表
    requireYearList() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("/api/enroll/psc/getYear")
          .then(res => {
            this.yearList = res.data.data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    requireYear() {
      return new Promise((resolve, reject) => {
        this.$http
          .get("/api/enroll/psc/annual")
          .then(res => {
            this.limitQuery.year = res.data.data;
            resolve();
          })
          .catch(err => {
            reject(err);
          });
      });
    }
  },
  computed: {
    computedZyDiff() {
      let { dqzs, qynzs } = this.zyStatistical;
      if (!qynzs) {
        return 0;
      }
      return (((dqzs - qynzs) / qynzs) * 100).toFixed(0);
    },
    computedManScale() {
      let { man, women } = this.sexStatistical,
        total = man + women;
      if (!total) {
        return 100;
      }
      return parseInt(((man / total) * 100).toFixed(0));
    }
  }
};
</script>

<style lang="scss" scoped>
.newbornStatistical {
  padding-top: 10px;
  .top-area {
    margin-bottom: 10px;
    display: flex;
    justify-content: space-around;
    padding: 20px;
    border: 1px solid #e4e4e4;
    & > div {
      flex: 1;
      &:not(:last-child) {
        border-right: 1px solid #e4e4e4;
      }
      & > div {
        font-size: 14px;
        padding: 0 40px;
        width: 300px;
        margin: 0 auto;
        .title {
          margin-bottom: 20px;
          font-size: 20px;
          display: inline-block;
        }
        &.enroll-zy {
          & > div {
            color: #999;
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 80px;
            .num {
              font-weight: bold;
              font-size: 34px;
              color: #000;
              // margin-left: 70px;
            }
          }
        }
        &.enroll-xxfs {
          & > div {
            height: 100px;
          }
        }
        &.enroll-nnbl {
          & > div {
            height: 80px;
            & > div {
              display: flex;
              justify-content: space-between;
              &:first-child {
                font-weight: bolder;
                font-size: 18px;
              }
              &:nth-child(2) {
                color: #999;
                margin-bottom: 10px;
              }
              &:nth-child(3) {
                img {
                  width: 30px;
                  height: 30px;
                }
              }
              /deep/ .el-progress-bar__outer {
                background-color: #ff9a32;
                border-radius: 0px;
              }
              /deep/ .el-progress-bar__inner {
                border-radius: 0px;
              }
            }
          }
        }
      }
    }
  }
  .bottom-area {
    border: 1px solid #e4e4e4;
    .history {
      display: flex;
      height: 100%;
      .left {
        height: 100%;
        flex: 1;
      }
      .right {
        width: 400px;
        height: 100%;
        overflow: auto;
        & > div {
          display: flex;
          align-items: center;
          margin-bottom: 20px;
          font-size: 14px;
          & > span {
            flex: 1;
          }
        }
      }
    }
  }
  /deep/ .el-tabs__header {
    margin: 0;
  }
  /deep/ .el-tabs__nav-wrap {
    padding-left: 10px;
  }
  /deep/ .el-tabs__content {
    .el-tab-pane {
      height: 100%;
    }
    height: calc(100vh - 462px);
    padding: 20px;
    // overflow: auto;
  }
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
    .el-radio-button--small .el-radio-button__inner {
      padding: 10px 12px;
    }
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
