<template>
  <div class="zymlglxq">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="returnList">返回列表</el-button>
      </div>
    </div>
    <table>
      <tr>
        <td class="listcss" colspan="4" style="text-align: left;">| 招生专业信息</td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>学院名称</td>
        <td colspan="3">{{parentParams.xymc}}</td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>专业名称</td>
        <td colspan="3">{{parentParams.zymc}}</td>
      </tr>
      <tr>
        <td class="listcss"><span style="color:red">*</span>学习方式 </td>
        <td colspan="3">{{parentParams.xxxs | xxfsFilter(0)}}</td>
      </tr>
      <template>
        <tr>
          <td class="listcss">研究方向</td>
          <td>
            <p v-for="item in parentParams.yjfx">{{item.dm}} {{item.mc}}</p>
          </td>
        </tr>
      </template>
      <tr>
        <td class="listcss">联系人</td>
        <td>{{parentParams.lxr}}</td>
      </tr>
      <tr style="height:120px;overflow:auto">
        <td class="listcss">联系方式</td>
        <td>{{parentParams.lxfs}}</td>
      </tr>
      <tr style="height:120px;overflow:auto">
        <td class="listcss">学位点简介</td>
        <td>{{parentParams.xwdjj}}</td>
      </tr>
      <tr style="height:120px;overflow:auto">
        <td class="listcss">复试科目及参考</td>
        <td>{{parentParams.fskmjcks}}</td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: "zymlglxq",
  props: ["parentParams"],
  data() {
    return {
      content: {}
    };
  },
  methods: {
    returnList() {
      this.$emit("zymlglzj", false);
    }
  }
};
</script>
<style lang="scss" scoped>
.zymlglxq {
  width: 100%;
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;
    margin-bottom: 20px;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
      text-align: center;
    }
    .ss1 {
      color: red;
    }
    .ss2 {
      color: rgb(255, 153, 0);
    }
    .ss3 {
      color: rgb(102, 204, 51);
    }
  }
}
</style>
