<template>
  <div class="ksxigl">
    <template v-if="!zymlg">
      <searchcomponment>
        <div slot="left">
          <el-input
            v-model="formInline.user"
            placeholder="请输入考生编号/姓名"
            suffix-icon="el-icon-search"
            clearable
            @clear="fresh"
            style="width:200px"
          ></el-input>
          <el-button @click="fresh">查询</el-button>
          <el-select
            v-model="formInline.school"
            filterable
            
            @change="fresh"
          >
            <el-option
              v-for="(item, index) in collegeList"
              :key="index"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div slot="right">
          <el-button
            @click="comprehensive"
            type="primary"
            v-if="$btnAuthorityTest('ksxigl:generate')"
            >生成考生编号</el-button
          >
          <el-button
            @click="comprehensive"
            type="primary"
            v-if="$btnAuthorityTest('ksxigl:import')"
            plain
            >导入</el-button
          >
          <el-button
            @click="outputClick"
            type="primary"
            plain
            v-if="$btnAuthorityTest('ksxigl:export')"
            >导出</el-button
          >
        </div>
      </searchcomponment>
      <el-table
        :data="tableData"
        border
        ref="multipleTable"
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading2"
        element-loading-text="加载中"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          type="index"
          label="序号"
          width="100px"
        ></el-table-column>
        <el-table-column prop="ksbh" label="考生编号"> </el-table-column>
        <el-table-column prop="xm" label="姓名"> </el-table-column>
        <el-table-column prop="xbm" label="性别"> </el-table-column>
        <el-table-column prop="bmdmc" label="报名点名称"> </el-table-column>
        <el-table-column prop="bkxy" label="报考学院"> </el-table-column>
        <el-table-column prop="bkzy" label="报考专业"> </el-table-column>
        <el-table-column prop="ksxxfs" label="学习方式">
          <template slot-scope="scope">
            {{ scope.row.ksxxfs | xxfsFilter(1) }}
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <span
              class="tablexq"
              @click="tablexq(scope.row)"
              v-if="$btnAuthorityTest('ksxigl:view')"
              >查看详情</span
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="tableList"
        v-if="pageshow"
      ></pagination>
      <timecommon :year="year"></timecommon>
    </template>
    <ksxiglxq v-else @zymlglzj="zymlglzj" :specialId="specialId"></ksxiglxq>
  </div>
</template>
<script>
import searchcomponment from "@/components/searchcomponment";
import pagination from "@/components/pagination";
import timecommon from "../componments/timecommon";
import ksxiglxq from "./ksxiglxq";
export default {
  name: "ksxigl",
  data() {
    return {
      formInline: {
        user: "", // 请输入考生编号/姓名
        school: "", // 全部学院
        zy: "" // 全部专业
      },
      collegeList: [],
      zyList: [],
      tableData: [],
      loading2: false,
      year: null,
      total: 0,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      pageshow: true,
      zymlg: false,
      specialId: ""
    };
  },
  mounted() {
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.tableList();
    this.selectList();
  },
  methods: {
    outputClick() {
      window.location.href = "/api/enroll/masterStudent/downloadFile";
    },
    handleSelectionChange() {},
    tablexq(row) {
      this.specialId = row.id;
      this.zymlg = true;
    },
    zymlglzj(val) {
      this.zymlg = val;
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.year = res.data.data;
      });
    },
    fresh() {
      this.pageshow = true;
      setTimeout(() => {
        this.pageshow = false;
      }, 100);
      this.tableList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    comprehensive() {
      this.$http.get("api/enroll/masterPush/generate").then(res => {
        // 学院
        if (res.data.code == 200) {
          this.$message.success(res.data.message);
          this.fresh();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    selectList() {
      this.$http.get("api/system/dict/select/enroll/academy").then(res => {
        // 学院
        this.collegeList = res.data.data;
      });
    },
    tableList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false; // 动画
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterPush/studentList", {
          xydm: this.formInline.school,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: "数据异常,请刷新",
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list; // 表格数据
            this.total = res.data.data.total; // 总条数
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  components: {
    pagination,
    searchcomponment,
    timecommon,
    ksxiglxq
  }
};
</script>
<style lang="scss" scoped>
.ksxigl {
  padding-top: 7px;
}
</style>
