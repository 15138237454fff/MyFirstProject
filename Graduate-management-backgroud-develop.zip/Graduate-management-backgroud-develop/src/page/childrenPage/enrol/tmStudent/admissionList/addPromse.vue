<template>
  <div class="addmissProposed">
    <template>
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="拟录取名单" name="first"></el-tab-pane>
          <el-tab-pane label="录取名单" name="second"></el-tab-pane>
        </el-tabs>
      </div>

    </template>
    <addmissonTable v-if="activeName=='first'"></addmissonTable>
    <proposedTable v-if="activeName=='second'"></proposedTable>
  </div>
</template>
<script>
import addmissonTable from "./components/addmissonTable";
import proposedTable from "./components/proposedTable";
export default {
  name: "addmissProposed",
  components: {
    addmissonTable: addmissonTable,
    proposedTable: proposedTable
  },
  data() {
    return {
      activeName: "first"
    };
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    }
  }
};
</script>
<style scoped lang="scss">
.addmissProposed {
  width: 100%;
}
.tabs {
  /deep/ .el-tabs__nav-wrap {
    background: #fff;
  }
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
}
</style>