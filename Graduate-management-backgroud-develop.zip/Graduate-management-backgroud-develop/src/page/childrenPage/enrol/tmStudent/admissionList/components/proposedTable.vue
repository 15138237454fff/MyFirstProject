<template>
  <div class="perFormance">
    <template>
      <div class="container">
        <div class="left">
          <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item>
              <el-input
                v-model="formInline.user"
                placeholder="请输入考生编号/姓名"
                suffix-icon="el-icon-search"
                clearable
                @clear="clearinput"
              ></el-input>
            </el-form-item>
            <el-form-item>
              <el-button @click="searchBtn">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-select
                v-model="formInline.school"
                filterable
                placeholder="全部学院"
                @change="collegeChange"
                
              >
                <el-option
                  v-for="(item, index) in collegeList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-select
                v-model="formInline.zy"
                filterable
                placeholder="全部专业"
                
                @change="selectchange"
              >
                <el-option
                  v-for="(item, index) in zyList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
        </div>
        <div class="right">
          <!-- <el-button type="primary" @click="endwork">结束录取工作</el-button>
          <el-button type="primary" plain>导出</el-button> -->
        </div>
      </div>
      <div class="table">
        <el-table
          :data="tableData"
          border
          ref="multipleTable"
          style="width: 100%"
          :header-cell-style="$storage.tableHeaderColor"
          :height="tableHeight"
          v-loading="loading2"
          element-loading-text="加载中"
          @selection-change="handleSelectionChange"
          @row-click="clickRow"
          @select-all="allClick"
        >
          <el-table-column type="index" label="序号" width="80">
          </el-table-column>
          <el-table-column prop="ksbh" label="考生编号"> </el-table-column>
          <el-table-column prop="xm" label="姓名"> </el-table-column>
          <el-table-column prop="bkyxsmc" label="报考学院"> </el-table-column>
          <el-table-column prop="bkzymc" label="报考专业"> </el-table-column>
          <el-table-column prop="bkxxfs" label="学习方式">
            <template slot-scope="scope">
              {{ scope.row.bkxxfs | xxfsFilter(1) }}
            </template>
          </el-table-column>
          <el-table-column prop="zhcj" label="综合成绩"> </el-table-column>
        </el-table>
        <pagination
          :total="total"
          :page.sync="listQuery.queryPage.pageNum"
          :limit.sync="listQuery.queryPage.pageSize"
          class="pagination-content"
          @pagination="tableList"
        ></pagination>
      </div>
    </template>
    <timecommon :year="formInline.class"></timecommon>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import timecommon from "../../../componments/timecommon";
export default {
  name: "perFormance",
  data() {
    return {
      formInline: {
        user: "", // 请输入考生编号/姓名
        school: "", // 全部学院
        zy: "", // 全部专业
        class: "" // 年级
      },
      gradeList: [],
      zyList: [],
      collegeList: [],
      tableData: [],
      loading2: false,
      total: 0,
      tableHeight: null,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      multipleSelection: []
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    this.selectList();
  },
  methods: {
    searchBtn() {
      this.fresh();
    },
    // 结束录取工作
    endwork() {
      this.$confirm("确认结束当前招生年度博士录取工作？", "结束录取工作", {
        confirmButtonText: "确定",
        cancelButtonText: "取消"
      }).then(() => {
        this.$http
          .put("api/doctorate/admission/over", this.multipleSelection)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.message,
                type: "success"
              });
              this.fresh();
            } else {
              this.$message({
                message: res.data.message,
                type: "error"
              });
            }
          });
      });
    },
    // 导出
    submit() {},
    clearinput() {
      this.formInline.user = "";
      this.fresh();
    },
    fresh() {
      this.listQuery.queryPage.pageNum = 1;
      this.tableList();
    },
    uploadForm() {},
    selectchange() {
      this.fresh();
    },
    collegeChange(val) {
      const temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.zyList = temp.children;
      this.fresh();
    },
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    allClick() {},
    selectList() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.gradeList = res.data.data;
      });
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.formInline.class = res.data.data;
        this.tableList();
      });
      this.$http.get("api/system/dict/select/enroll/college").then(res => {
        this.collegeList = res.data.data; // 学院
        this.zyList = this.collegeList[0].children; // 专业
      });
    },
    tableList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false; // 动画
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterPush/confirmed/list", {
          collegeCode: this.formInline.school,
          majorCode: this.formInline.zy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: "数据异常,请刷新",
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list; // 表格数据
            this.total = res.data.data.total; // 总条数
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  components: {
    pagination,
    timecommon
  }
};
</script>
<style lang="scss" scoped>
.perFormance {
  width: 100%;
  position: relative;
  .container {
    display: flex;
    height: 48px; /* 48/16 */
    .left {
      flex: 2;
    }
    .right {
      flex: 1;
      text-align: right;
    }
    .demo-form-inline {
      height: 48px;
    }
  }
  .table {
    width: 100%;
  }
}
</style>
