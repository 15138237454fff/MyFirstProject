<template>
  <div class="firstScoreInput" v-if="isOpen">
    <searchcomponment>
      <div slot="left">
        <el-input
          suffix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考生编号/姓名"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select v-model="limitQuery.bkxy" @change="loadTable">
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.bkzy" @change="loadTable">
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$storage.tableHeaderColor"
      :default-sort="{ prop: 'ksbh', order: 'ascending' }"
    >
      <el-table-column prop="ksbh" label="考生编号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="bkxy" label="报考学院"></el-table-column>
      <el-table-column prop="bkzy" label="报考专业"></el-table-column>
      <el-table-column label="学习方式">
        <template slot-scope="scope">
          <span> {{ scope.row.xxfs | xxfsFilter(1) }} </span>
        </template>
      </el-table-column>
      <el-table-column label="复试成绩">
        <template slot-scope="scope">
          <el-input-number
            v-model="scope.row.fscj"
            controls-position="right"
            @keyup.enter.native="saveData(scope.$index)"
            :ref="'scopeInput' + scope.$index"
            :min="-1"
            :max="150"
            v-if="$btnAuthorityTest('fscjlr:input')"
          ></el-input-number>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="year"></timecommon>
  </div>
  <my-blank v-else msg="成绩录入功能暂未开启！"></my-blank>
</template>
<script>
import timecommon from "../componments/timecommon";
import searchcomponment from "@/components/searchcomponment";
import blank from "@/components/blank";
export default {
  name: "fscjlr",
  components: {
    searchcomponment: searchcomponment,
    timecommon,
    "my-blank": blank
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 科目的待选列表
      kmOptions: [
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywke" },
        { label: "业务课二", value: 4, name: "ywky" }
      ],
      // 考试科目的待选列表
      ksOptions: [],
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 分页查询的参数
      limitQuery: {
        // 考试科目
        kskm: null,
        // 报考学院
        bkxy: "",
        // 当前用户角色id
        jsid: this.$stores.state.roleid_tole,
        // 报考专业
        bkzy: "",
        // 科目类别
        kmlb: null,
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      newsCount: 0,
      isOpen: window.sessionStorage.getItem("enrollInputIsOpen"),
      // 是否正在加载数据
      loading: false,
      tableHeight: null,
      year: 2019
    };
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    // 请求学院专业信息
    this.requireXY();
    this.loadTable();
    // 请求考试科目可选列表
    this.requireKSKM(null);
    this.requireCurrentYear();
    this.requireTime();
  },
  methods: {
    requireTime() {
      this.$http.get("/api/enroll/psc/entry/time").then(res => {
        const data = res.data.data;
        if (!data) {
          return this.$message.error("获取成绩录入时间失败，请重试");
        }
        let now = this.$tagTime(new Date(), "yyyy-MM-dd"),
          start = this.$tagTime(new Date(data.startTime), "yyyy-MM-dd"),
          end = this.$tagTime(new Date(data.endTime), "yyyy-MM-dd");
        this.isOpen = data.isOpen === 1 && now <= end && now >= start;
        window.sessionStorage.setItem("enrollInputIsOpen", this.isOpen);
      });
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 成绩录入
    saveData(index) {
      let tmpRow = this.tableData[index];
      if (tmpRow.fscj === "") {
        this.$message.warning("填写成绩后再尝试提交");
        return;
      }
      // 放入待提交的表单对象中
      const uploadForm = {
        id: tmpRow.id,
        // 成绩录入
        fscj: tmpRow.fscj
      };
      // 发送请求提交成绩
      this.$http
        .post(`/api/enroll/masterPush/save/${tmpRow.id}/${tmpRow.fscj}`)
        .then(res => {
          const data = res.data;
          if (data.code === 200) {
            // 切换到下一个输入框
            this.jumpInput(index);
          } else {
            this.$message.error(data.message);
            this.tableData[index].fscj = "";
          }
        });
    },
    // 请求列表数据的方法
    loadTable() {
      this.loading = true;
      this.$http
        .post("/api/enroll/masterPush/reexamineList", {
          xydm: this.limitQuery.bkxy,
          zydm: this.limitQuery.bkzy,
          query: this.limitQuery.query,
          pageNum: this.limitQuery.pageNum,
          pageSize: this.limitQuery.pageSize
        })
        .then(res => {
          let data = res.data;
          this.loading = false;
          // setTimeout(() => {
          //   this.loading = false;
          // }, 1000);
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (data && !Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          this.tableData = data.list;
          this.newsCount = data.total;
          // dom操作放入nextTick,如果存在输入框
          this.$nextTick(() => {
            if (this.$refs.scopeInput0) {
              // 第一个输入框获取焦点
              this.$refs.scopeInput0.focus();
            }
          });
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 切换输入框的方法
    jumpInput(index) {
      // 获取下一个输入框下标
      let nextIndex = index + 1,
        // 获取下一个输入框
        nextInput = this.$refs["scopeInput" + nextIndex];
      // 如果这个输入框存在
      if (nextInput) {
        // 激活下一个输入框
        nextInput.focus();
      }
      // 如果已经是最后一个输入框
      else {
        // 这个输入框失去焦点
        this.$refs["scopeInput" + index].blur();
      }
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http.get("/api/system/dict/select/enroll/college").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        }
        // 保存学院的待选列表
        this.xyOptions = data;
        // 取第一个学院为默认选中
        this.limitQuery.bkxy = data[0].value;
        // 取出可选的专业待选列表
        this.zyOptions = this.xyOptions[0].children;
      });
    },
    // 根据科目类型请求对应的考试科目
    requireKSKM(kmlb) {
      this.$http
        .post("/api/doctorate/masterResult/getTree", { kmlb })
        .then(res => {
          const data = res.data.data;
          // 验证消息格式
          // 保存新的考试科目可选列表
          this.ksOptions = data;
          // 重置考试科目的所选值
          this.limitQuery.kskm = null;
        });
    },
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.year = res.data.data;
      });
    }
  },
  watch: {
    $route(to) {
      if (to.name === "fscjlr") {
        this.loadTable();
      }
    },
    "limitQuery.bkxy": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        this.limitQuery.bkzy = this.zyOptions[0].value;
      }
    },
    "limitQuery.kmlb": {
      handler(val) {
        // 请求考试科目可选列表
        this.requireKSKM(val);
      }
    }
  },
  filters: {
    // 过滤科目类别
    kmlbFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 2:
          return "外国语";
        case 3:
          return "业务课一";
        case 4:
          return "业务课二";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.firstScoreInput {
  padding-top: 7px;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 36px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 36px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      text-align: center;
      background: #f2f2f2;
      width: 100px;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    padding: 0;
  }
  /deep/ .el-table td {
    padding: 0 !important;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
