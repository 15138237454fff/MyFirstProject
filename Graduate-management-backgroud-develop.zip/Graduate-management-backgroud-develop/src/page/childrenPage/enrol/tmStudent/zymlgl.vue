<template>
  <div class="zymlgl">
    <template v-if="!zymlg">
      <searchcomponment>
        <div slot="left">
          <el-input
            v-model="formInline.user"
            placeholder="请输入专业代码/名称"
            suffix-icon="el-icon-search"
            clearable
            @clear="fresh"
            style="width:200px"
          ></el-input>
          <el-button @click="fresh">查询</el-button>
          <el-select
            v-model="formInline.school"
            filterable
            
            @change="fresh"
          >
            <el-option
              v-for="(item, index) in collegeList"
              :key="index"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div slot="right">
          <el-button
            @click="comprehensive"
            type="primary"
            plain
            v-if="$btnAuthorityTest('zymlgl:export')"
            >导出</el-button
          >
        </div>
      </searchcomponment>
      <el-table
        :data="tableData"
        border
        ref="multipleTable"
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading2"
        element-loading-text="加载中"
      >
        <el-table-column
          type="index"
          label="序号"
          width="100px"
        ></el-table-column>
        <el-table-column prop="zydm" label="专业代码"> </el-table-column>
        <el-table-column prop="zymc" label="专业名称"> </el-table-column>
        <el-table-column prop="dwmc" label="所属学院"> </el-table-column>
        <el-table-column prop="xxxs" label="学习方式">
          <template slot-scope="scope">
            {{ scope.row.xxxs | xxfsFilter(0) }}
          </template>
        </el-table-column>
        <el-table-column prop="tmsrs" label="推免生招生人数"> </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <span
              class="tablexq"
              @click="tablexq(scope.row)"
              v-if="$btnAuthorityTest('zymlgl:view')"
              >查看详情</span
            >
          </template>
        </el-table-column>
      </el-table>
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="tableList"
        v-if="pageshow"
      ></pagination>
      <timecommon :year="year"></timecommon>
    </template>
    <zymlglxq
      v-else
      @zymlglzj="zymlglzj"
      :parentParams="parentParams"
    ></zymlglxq>
  </div>
</template>
<script>
import searchcomponment from "@/components/searchcomponment";
import pagination from "@/components/pagination";
import timecommon from "../componments/timecommon";
import zymlglxq from "./zymlglxq";
export default {
  name: "zymlgl",
  data() {
    return {
      formInline: {
        user: "", // 请输入考生编号/姓名
        school: "", // 全部学院
        zy: "" // 全部专业
      },
      collegeList: [],
      zyList: [],
      tableData: [],
      loading2: false,
      year: null,
      total: 0,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      pageshow: true,
      zymlg: false,
      parentParams: {}
    };
  },
  mounted() {
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.tableList();
    this.selectList();
  },
  methods: {
    tablexq(row) {
      this.$http
        .get(`/api/enroll/masterPush/disciplineInfo/${row.id}`)
        .then(res => {
          if (res.data.data && res.data.code == 200) {
            this.parentParams = res.data.data;
            this.zymlg = true;
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    zymlglzj(val) {
      this.zymlg = val;
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.year = res.data.data;
      });
    },
    fresh() {
      this.pageshow = true;
      setTimeout(() => {
        this.pageshow = false;
      }, 100);
      this.tableList();
      this.listQuery.queryPage.pageNum = 1;
      this.listQuery.queryPage.pageSize = 15;
    },
    comprehensive() {
      this.$http
        .get("/api/enroll/mbac/export/check")
        .then(res => {
          if (res.data.code === 200) {
            window.location.href = "/api/enroll/mbac";
          } else {
            this.$message.error(res.data.message);
          }
        })
        .catch(err => {
          this.$message.error(err.response.data.message);
        });
    },
    selectList() {
      this.$http.get("api/system/dict/select/enroll/academy").then(res => {
        // 学院
        this.collegeList = res.data.data;
      });
    },
    tableList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false; // 动画
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterPush/disciplineList", {
          xydm: this.formInline.school,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: "数据异常,请刷新",
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list; // 表格数据
            this.total = res.data.data.total; // 总条数
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  components: {
    pagination,
    searchcomponment,
    timecommon,
    zymlglxq
  }
};
</script>
<style lang="scss" scoped>
.zymlgl {
  padding-top: 7px;
}
</style>
