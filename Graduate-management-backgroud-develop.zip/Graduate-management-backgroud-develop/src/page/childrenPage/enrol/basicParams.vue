<template>
  <div class="enrolBasicParams">
    <div class="box">
      <div class="set-year">
        <div>
          设置招生年度：
          <el-date-picker
            v-model="zsnd"
            type="year"
            placeholder="选择年度"
          ></el-date-picker>
        </div>
        <el-button type="primary" @click="uploadYear">保存</el-button>
      </div>
      <div class="save-time">
        <div>
          成绩录入时间：
          <el-radio-group v-model="paramsForm.isOpen" @change="changeInput">
            <el-radio :label="0">关闭</el-radio>
            <el-radio :label="1">开启</el-radio>
          </el-radio-group>
          <el-date-picker
            v-model="paramsForm.startTime"
            type="date"
            placeholder="选择日期"
            v-if="paramsForm.isOpen == 1"
          ></el-date-picker
          >&nbsp;
          <el-date-picker
            v-model="paramsForm.endTime"
            type="date"
            placeholder="选择日期"
            v-if="paramsForm.isOpen == 1"
          ></el-date-picker>
        </div>
        <el-button type="primary" @click="uploadForm">保存</el-button>
      </div>
      <div class="save-time">
        <div>
          博士报名起止日期：
          <!-- <el-radio v-model="paramsBs.isOpen" :label="0">关闭</el-radio>
          <el-radio v-model="paramsBs.isOpen" :label="1">开启</el-radio> -->
          <el-radio-group v-model="paramsBs.isOpen" @change="changeSignUp">
            <el-radio :label="0">关闭</el-radio>
            <el-radio :label="1">开启</el-radio>
          </el-radio-group>
          <el-date-picker
            v-model="paramsBs.startTime"
            type="date"
            placeholder="选择日期"
            v-if="paramsBs.isOpen == 1"
            value-format="yyyy-MM-dd"
          ></el-date-picker
          >&nbsp;
          <el-date-picker
            v-model="paramsBs.endTime"
            type="date"
            placeholder="选择日期"
            v-if="paramsBs.isOpen == 1"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </div>
        <el-button type="primary" @click="uploadForm('0')">保存</el-button>
      </div>
      <div class="save"></div>
    </div>
  </div>
</template>
<script>
export default {
  name: "enrolBasicParams",
  data() {
    return {
      // 待提交的基础参数表单数据
      paramsForm: {
        // 是否开启成绩录入
        isOpen: 0,
        // 开始日期
        startTime: "",
        // 结束日期
        endTime: ""
      }, // 待提交的基础参数表单数据
      paramsBs: {
        // 是否开启成绩录入
        isOpen: 0,
        // 开始日期
        startTime: "",
        // 结束日期
        endTime: ""
      },
      // 招生年度
      zsnd: 2019
    };
  },
  mounted() {
    // 请求招生年度
    this.requireCurrentYear();
    // 请求招生参数
    this.requireCurrentParams();
  },
  methods: {
    uploadForm(val) {
      console.log(this.paramsBs, this.paramsForm);
      if (val == "0") {
        let start = this.$tagTime(this.paramsBs.startTime, "yyyy-MM-dd");
        let end = this.$tagTime(this.paramsBs.endTime, "yyyy-MM-dd");
        console.log(start, end);
        if (this.paramsBs.isOpen === 1) {
          if (!start || !end) {
            return this.$message.error("请选择博士报名起止日期");
          }
          if (start > end) {
            return this.$message.error("开始时间不能大于结束时间");
          }
          if (end < this.$tagTime(new Date(), "yyyy-MM-dd")) {
            return this.$message.error("结束时间不能早于当前日期");
          }
        }
        this.$http
          .put("/api/enroll/psc/update/doctor/time", this.paramsBs)
          .then(res => {
            const data = res.data;
            if (data.code == 200) {
              this.$message.success("修改博士报名起止日期成功");
            } else {
              this.$message.error(data.message);
            }
            this.requireCurrentParams();
          });
      } else {
        let start = this.$tagTime(this.paramsForm.startTime, "yyyy-MM-dd");
        let end = this.$tagTime(this.paramsForm.endTime, "yyyy-MM-dd");
        console.log(start, end);
        if (this.paramsForm.isOpen === 1) {
          if (!start || !end) {
            return this.$message.error("请选择成绩录入时间");
          }
          if (start > end) {
            return this.$message.error("开始时间不能大于结束时间");
          }
          if (end < this.$tagTime(new Date(), "yyyy-MM-dd")) {
            return this.$message.error("结束时间不能早于当前日期");
          }
        }
        this.$http
          .put("/api/enroll/psc/update/entry/time", this.paramsForm)
          .then(res => {
            const data = res.data;
            if (data.code == 200) {
              this.$message.success("修改成绩录入时间成功");
            } else {
              this.$message.error(data.message);
            }
            this.requireCurrentParams();
          });
      }
    },
    uploadYear() {
      // 对时间做一下处理只保留年份
      if (!this.zsnd) {
        return this.$message.error("请设置招生年度");
      }
      const zsnd = this.zsnd.getFullYear();
      this.$http.put("/api/enroll/psc/update/" + zsnd).then(res => {
        const data = res.data;
        if (data.code == 200) {
          this.$message.success("修改招生年度成功");
        } else {
          this.$message.error(data.message);
        }
        this.requireCurrentYear();
      });
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.zsnd = new Date("" + res.data.data);
      });
    },
    // 请求当前参数
    requireCurrentParams() {
      this.$http.get("/api/enroll/psc/entry/time").then(res => {
        const data = res.data.data;
        if (!data) {
          return this.$message.error("获取成绩录入时间失败，请重试");
        }
        // 保存历史的参数
        Object.keys(this.paramsForm).forEach(key => {
          this.paramsForm[key] = data[key];
        });
      });
      this.$http.get("/api/enroll/psc/doctor/time").then(res => {
        const data = res.data.data;
        if (!data) {
          return this.$message.error("获取成绩录入时间失败，请重试");
        }
        // 保存历史的参数
        Object.keys(this.paramsBs).forEach(key => {
          this.paramsBs[key] = data[key];
        });
      });
    },
    changeInput() {
      this.paramsForm.startTime = "";
      this.paramsForm.endTime = "";
    },
    changeSignUp() {
      this.paramsBs.startTime = "";
      this.paramsBs.endTime = "";
    }
  },
  computed: {}
};
</script>
<style lang="scss" scoped>
.enrolBasicParams {
  width: 100%;
  height: 80vh;
  display: flex;
  justify-content: center;
  align-items: center;
  .box {
    font-size: 14px;
    width: 900px;
    min-width: 800px;
    height: 200px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .save {
      text-align: center;
    }
    .save-time,
    .set-year {
      display: flex;
      justify-content: space-between;
      line-height: 34px;
    }
  }
  .el-radio-group {
    .el-radio {
      margin-right: 20px;
    }
  }
}
</style>
