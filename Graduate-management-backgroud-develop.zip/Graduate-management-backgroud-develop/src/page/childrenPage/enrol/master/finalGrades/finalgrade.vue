<template>
  <div class="finalgrade">
    <template>
      <searchcomponment>
        <div slot="left">
          <el-input
            v-model="formInline.user"
            placeholder="请输入考生编号/姓名"
            suffix-icon="el-icon-search"
            clearable
            @clear="inputclear"
            style="width:200px"
          ></el-input>
          <el-button @click="searchbtn">查询</el-button>
          <el-select
            v-model="formInline.school"
            filterable
            placeholder="全部学院"
            @change="collegeChange"
            
          >
            <el-option
              v-for="item in collegeList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
          <el-select
            v-model="formInline.zy"
            filterable
            placeholder="全部专业"
            
            @change="selectchange"
          >
            <el-option
              v-for="item in zyList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div slot="right">
          <el-button
            @click="comprehensive"
            type="primary"
            v-if="$btnAuthorityTest('finalgrade:generate')"
            >生成综合成绩</el-button
          >
        </div>
      </searchcomponment>
      <el-table
        :data="tableData"
        border
        ref="multipleTable"
        style="width: 100%"
        :row-class-name="tableRowClassName"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading2"
        element-loading-text="加载中"
        @selection-change="handleSelectionChange"
        @row-click="clickRow"
        @select-all="allClick"
      >
        <el-table-column prop="ksbh" label="考生编号" width="150">
        </el-table-column>
        <el-table-column prop="xm" label="姓名"> </el-table-column>
        <el-table-column prop="bkxy" label="报考学院"> </el-table-column>
        <el-table-column prop="bkzy" label="报考专业"> </el-table-column>
        <el-table-column label="初试总分" prop="zf"> </el-table-column>
        <el-table-column label="复试成绩" prop="fscj"> </el-table-column>
        <el-table-column label="综合成绩" prop="zhcj"> </el-table-column>
        <!-- <el-table-column label="复试成绩">
            <template slot-scope="scope">
              <input v-focus v-model="scope.row.state" placeholder="请输入内容" @keyup.enter="onSubmit(scope.$index)" :id="'fouce'+scope.$index" :ref="'fouce'+scope.$index" class="input">
            </template>
          </el-table-column> -->
      </el-table>
      <!-- https://www.jianshu.com/p/cd03674e92b1 -->
      <pagination
        :total="total"
        :page.sync="listQuery.queryPage.pageNum"
        :limit.sync="listQuery.queryPage.pageSize"
        class="pagination-content"
        @pagination="tableList"
      ></pagination>
    </template>
    <timecommon :year="formInline.class"></timecommon>
  </div>
</template>
<script>
import searchcomponment from "@/components/searchcomponment";
import pagination from "@/components/pagination";
import timecommon from "../../componments/timecommon";
export default {
  name: "perFormance",
  data() {
    return {
      formInline: {
        user: "", // 请输入考生编号/姓名
        school: "", // 全部学院
        zy: "", // 全部专业
        class: ""
      },
      collegeList: [],
      zyList: [],
      tableData: [],
      loading2: false,
      pagesize: 10,
      currentPage: 1,
      total: 0,
      upload: "/api/orientation/fpc/import",
      uploadData: {
        file: ""
      },
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null
    };
  },
  filters: {
    xxfs(val) {
      switch (val) {
        case 1:
          return (val = "全日制");
        case 2:
          return (val = "非全日制");
        default:
          break;
      }
    }
  },
  mounted() {
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.tableList();
    this.tableData.forEach((Element, index) => {
      this.$set(Element, "focusIndex", index);
    });
    this.selectList();
  },
  directives: {
    focus: {
      // 指令的定义
      inserted: function(el) {
        document.getElementById("fouce0").focus();
      }
    }
  },
  methods: {
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.formInline.class = res.data.data;
      });
    },
    searchbtn() {
      this.fresh();
    },
    fresh() {
      this.tableList();
      this.listQuery.queryPage.pageNum = 1;
    },
    inputclear() {
      this.formInline.user = "";
      this.fresh();
    },
    comprehensive() {
      this.$http.get("api/enroll/masterResultZh/generateZhcj/1").then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: "综合成绩生成成功",
            type: "success"
          });
          this.fresh();
        } else {
          this.$message({
            message: "数据异常,请刷新再试",
            type: "error"
          });
        }
      });
    },
    collegeChange(val) {
      const temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.zyList = temp.children;
      this.formInline.zy = "";
      this.fresh();
    },
    selectList() {
      this.$http.get("api/system/dict/select/enroll/college").then(res => {
        // 学院
        this.collegeList = res.data.data;
        // 专业
        this.zyList = this.collegeList[0].children;
      });
    },
    selectchange() {
      this.fresh();
    },
    tableRowClassName({ row, rowIndex }) {},
    handlebefore(file) {
      this.uploadData.file = file.name;
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      if (file.code == 400) {
        this.$message({
          message: file.message,
          type: "error"
        });
        this.$refs.uploadcsv.clearFiles();
      } else {
        this.$message({
          message: file.message,
          type: "success"
        });
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles();
        }, 1000);
      }
    },
    uploadForm() {},
    onSubmit(index) {
      const fouce = `fouce${index + 1}`;
      console.log(this.tableData.length);
      if (index === this.tableData.length - 1) {
        this.$message({
          message: "下面没有填写了,请从第一个开始",
          type: "error"
        });
        document.getElementById("fouce0").focus();
      } else {
        document.getElementById(fouce).focus();
      }

      //   this.$router.push("/perFormance/alias2");
    },
    handleSizeChange() {},
    handleCurrentChange() {},
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.taskId);
        });
      }
    },
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    allClick() {},
    tableList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false; // 动画
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterResultZh/list", {
          bkxy: this.formInline.school,
          bkzy: this.formInline.zy,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          xslb: "1"
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: "数据异常,请刷新",
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list; // 表格数据
            this.total = res.data.data.total; // 总条数
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  components: {
    pagination,
    searchcomponment,
    timecommon
  },
  watch: {
    //    this.$stores.getters.Height
    // $route(to) {
    //   if (to.path === "/perFormance/alias2") {
    //     this.loadTable();
    //     this.paramsForm.isOpen = 1;
    //   }
    // }
  }
};
</script>
<style lang="scss" scoped>
.finalgrade {
  width: 100%;
  padding-top: 7px;
  .container {
    display: flex;
    height: 48px; /* 48/16 */
    .left {
      flex: 2;
    }
    .right {
      flex: 1;
      text-align: right;
    }
    .demo-form-inline {
      height: 48px;
    }
  }
  .table {
    width: 100%;
  }
}
</style>
<style>
.el-table .warning-row {
  background: #f39b9b;
  color: #ff0000;
}

.el-table .success-row {
  background: #f39b9b;
  color: #ff0000;
}
.input {
  -webkit-appearance: none;
  background-color: #fff;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  width: 100%;
}
</style>
