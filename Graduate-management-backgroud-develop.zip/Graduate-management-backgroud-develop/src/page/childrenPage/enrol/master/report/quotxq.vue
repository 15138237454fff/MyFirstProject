<template>
  <div class="quotxq">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="按专业招生" name="0" v-if="zyzsxyshow">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <span>{{form.optionxy}}</span>
          </el-form-item>
          <el-form-item label="选择专业：">
            <span>{{form.optionzy}}</span>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>学习方式</td>
            <td>专业招生名额</td>
            <td>专业免推生人数</td>
            <td>专业一志愿复试人数</td>
          </tr>
          <tr>
            <td>全日制</td>
            <td class="noneback">
              <span>{{qrz[0].zyrs}}</span>
            </td>
            <td class="noneback">
              <span>{{qrz[0].zymtsrs}}</span>
            </td>
            <td class="noneback">
              <span>{{qrz[0].zyzyfsrs}}</span>
            </td>
          </tr>
          <tr>
            <td>非全日制</td>
            <td class="noneback">
              <span>{{fqrz[0].zyrs}}</span>
            </td>
            <td class="noneback">
              <span>{{fqrz[0].zymtsrs}}</span>
            </td>
            <td class="noneback">
              <span>{{fqrz[0].zyzyfsrs}}</span>
            </td>
          </tr>
        </table>
      </el-tab-pane>
      <el-tab-pane label="按研究方向招生" name="1" v-if="yjfxxyshow">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <span>{{form.optionyjxy}}</span>
          </el-form-item>
          <el-form-item label="选择专业：">
            <span>{{form.optionyjzy}}</span>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>方向代码</td>
            <td>研究方向</td>
            <td>学习方式</td>
            <td>方向招生名额</td>
            <td>方向推免生人数</td>
            <td>方向一志愿复试人数</td>
          </tr>
          <template>
            <tr v-for="(item,index) in qrzs">
              <td>{{item.yjdm}}</td>
              <td>{{item.yjmc}}</td>
              <td>全日制</td>
              <td class="noneback">
                <span>{{item.zyrs}}</span>
              </td>
              <td class="noneback">
                <span>{{item.zymtsrs}}</span>
              </td>
              <td class="noneback">
                <span>{{item.zyzyfsrs}}</span>
              </td>
            </tr>
          </template>
          <template>
            <tr v-for="(item,index) in fqrzs">
              <td>{{item.yjdm}}</td>
              <td>{{item.yjmc}}</td>
              <td>非全日制</td>
              <td class="noneback">
                <span>{{item.zyrs}}</span>
              </td>
              <td class="noneback">
                <span>{{item.zymtsrs}}</span>
              </td>
              <td class="noneback">
                <span>{{item.zyzyfsrs}}</span>
              </td>
            </tr>
          </template>
        </table>
      </el-tab-pane>
    </el-tabs>
    <div class="retrun" v-if="status =='2'">
      <li style="margin-bottom:10px;margin-left:100px"><span style="font-weight:600">研究生院审核（{{shr}}） </span><span>{{shsj}}</span></li>
      <p style="margin-left:100px">退回原因：{{opinion}}</p>
    </div>
  </div>
</template>
<script>
export default {
  props: ['status'],
  name: 'quotxq',
  data() {
    return {
      zyzsxyshow: false,
      yjfxxyshow: false,
      activeName: '0',
      selectvalue: '',
      form: {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: '',
        // 按专业招生专业
        optionzy: '',
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: '',
        // 按研究方向招生专业
        optionyjzy: ''
      },
      fqrz: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ],
      qrz: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ],

      shr: '',
      shsj: '',
      opinion: '',
      fqrzs: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: '',
          yjmc: ''
        }
      ],
      qrzs: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: '',
          yjmc: ''
        }
      ]
    }
  },
  mounted() {
    // 获取学院与其相对的专业
    // this.getZyTree()
    this.$bus.$on('formxq', msg => {
      if (msg.status == '0') {
        this.zyzsxyshow = true
        this.yjfxxyshow = false
        this.activeName = '0';
        this.form.optionxy = msg.xymc
        this.form.optionzy = msg.zymc
        this.fqrz = msg.fqrz
        this.qrz = msg.qrz
      }
      if (msg.status == '1') {
        this.zyzsxyshow = false
        this.yjfxxyshow = true
        this.activeName = '1';
        this.form.optionyjxy = msg.xymc
        this.form.optionyjzy = msg.zymc
        this.fqrzs = msg.fqrz
        this.qrzs = msg.qrz
      }
      console.log(msg)
    })
  },
  methods: {
    // 获取学院与其相对的专业
    getZyTree() {
      this.$http
        .get(
          `api/enroll/enrollmentReport/getZyTree/${this.$stores.state.roleid_tole}`
        )
        .then(res => {
          // 校验数据异常
          if (!Array.isArray(res.data.data)) {
            this.$message.error('数据异常')
          } else {
            this.form.zyzsxy = this.form.yjfxxy = res.data.data
          }
        })
    },
    // tab切换
    handleClick() {},
    freshform() {}
  }
}
</script>
<style lang="scss" scoped>
table.gridtable {
  font-family: verdana, arial, sans-serif;
  font-size: 11px;
  color: #333333;
  border-width: 1px;
  border-color: #e5e5e5;
  border-collapse: collapse;
  width: 100%;
}
table.gridtable th {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  // background-color: #f2f2f2;
}
table.gridtable td {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  background-color: #f2f2f2;
  text-align: center;
  color: #333333;
  width: 180px;
}
table.gridtable .noneback {
  background: #fff;
}
.dialog-footers {
  text-align: center;
}
.demo-form-inline {
  height: 56px !important;
}
.retrun {
  background: url("image/返回.png") no-repeat;
  width: 100%;
  height: 60px;
  background-size: 10%;
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 10px;
  // text-align: center;
  padding-top: 30px;
  background-position: center left;
}
</style>


