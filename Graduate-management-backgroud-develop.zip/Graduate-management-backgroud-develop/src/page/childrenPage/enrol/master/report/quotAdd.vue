<template>
  <div class="quotAdd">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="按专业招生" name="0">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <el-select v-model="form.optionxy" placeholder="选择学院">
              <el-option
                v-for="(item, index) in form.zyzsxy"
                :key="index"
                :label="item.xymc"
                :value="item.xydm"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择专业：">
            <el-select v-model="form.optionzy" placeholder="选择专业">
              <el-option
                v-for="(item, index) in form.zyzszy"
                :key="index"
                :label="item.zymc"
                :value="item.zydm"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>学习方式</td>
            <td>专业招生名额</td>
            <td>专业免推生人数</td>
            <td>专业一志愿复试人数</td>
          </tr>
          <tr v-if="qrzshow == '1' || fqqrall == '1,2'">
            <td>全日制</td>
            <td class="noneback">
              <el-input
                v-model="qrz[0].zyrs"
                placeholder="请输入"
                clearable
                type="number"
              ></el-input>
            </td>
            <td class="noneback">
              <el-input
                v-model="qrz[0].zymtsrs"
                placeholder="请输入"
                clearable
                type="number"
              ></el-input>
            </td>
            <td class="noneback">
              <el-input
                v-model="qrz[0].zyzyfsrs"
                placeholder="请输入"
                clearable
                type="number"
              ></el-input>
            </td>
          </tr>
          <tr v-if="fqrzshow == '2' || fqqrall == '1,2'">
            <td>非全日制</td>
            <td class="noneback">
              <el-input
                v-model="fqrz[0].zyrs"
                placeholder="请输入"
                clearable
                type="number"
              ></el-input>
            </td>
            <td class="noneback">
              <el-input
                v-model="fqrz[0].zymtsrs"
                placeholder="请输入"
                clearable
                type="number"
              ></el-input>
            </td>
            <td class="noneback">
              <el-input
                v-model="fqrz[0].zyzyfsrs"
                placeholder="请输入"
                clearable
                type="number"
              ></el-input>
            </td>
          </tr>
        </table>
      </el-tab-pane>
      <el-tab-pane label="按研究方向招生" name="1">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <el-select
              v-model="form.optionyjxy"
              placeholder="选择学院"
              @change="selectoptionyjxy"
            >
              <el-option
                v-for="(item, index) in form.yjfxxy"
                :key="index"
                :label="item.xymc"
                :value="item.xydm"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="选择专业：">
            <el-select
              v-model="form.optionyjzy"
              placeholder="选择专业"
              @change="selectoptionyjzy"
            >
              <el-option
                v-for="(item, index) in form.yjfxzy"
                :key="index"
                :label="item.zymc"
                :value="item.zydm"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>方向代码</td>
            <td>研究方向</td>
            <td>学习方式</td>
            <td>方向招生名额</td>
            <td>方向推免生人数</td>
            <td>方向一志愿复试人数</td>
          </tr>
          <template>
            <tr v-for="(item, index) in qrzs" :key="2 * index + 1">
              <td>{{ item.yjdm }}</td>
              <td>{{ item.yjmc }}</td>
              <td>全日制</td>
              <td class="noneback">
                <el-input
                  v-model="item.zyrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                ></el-input>
              </td>
              <td class="noneback">
                <el-input
                  v-model="item.zymtsrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                ></el-input>
              </td>
              <td class="noneback">
                <el-input
                  v-model="item.zyzyfsrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                ></el-input>
              </td>
            </tr>
          </template>
          <template>
            <tr v-for="(item, index) in fqrzs" :key="2 * index">
              <td>{{ item.yjdm }}</td>
              <td>{{ item.yjmc }}</td>
              <td>非全日制</td>
              <td class="noneback">
                <el-input
                  v-model="item.zyrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                ></el-input>
              </td>
              <td class="noneback">
                <el-input
                  v-model="item.zymtsrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                ></el-input>
              </td>
              <td class="noneback">
                <el-input
                  v-model="item.zyzyfsrs"
                  placeholder="请输入"
                  clearable
                  type="number"
                ></el-input>
              </td>
            </tr>
          </template>
        </table>
      </el-tab-pane>
    </el-tabs>
    <div class="dialog__footer">
      <el-button @click="cancel">取消</el-button>
      <el-button type="primary" @click="formsave">保存</el-button>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    visibles: {
      type: Function,
      required: true
    },
    fresh: { type: Function, required: true }
  },
  name: "quotAdd",
  data() {
    return {
      zyzsxyshow: true,
      yjfxxyshow: true,
      activeName: "0",
      selectvalue: "",
      form: {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      },
      fqrz: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ],
      qrz: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ],
      fqrzs: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: "",
          yjmc: ""
        }
      ],
      qrzs: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: "",
          yjmc: ""
        }
      ],
      qrzshow: "1",
      fqrzshow: "2",
      fqqrall: "1,2"
    };
  },
  mounted() {
    // 获取学院与其相对的专业
    this.getZyTree();
    this.enrollmentReport();
  },
  watch: {
    // 监听学院下拉选则的数据
    "form.optionxy": {
      handler: function(val) {
        const tmp = this.form.zyzsxy.find(el => {
          return el.xydm === val;
        });
        if (!tmp) {
          return;
        }
        this.form.zyzszy = tmp.zyTreesList;
        this.form.optionzy = this.form.zyzszy[0].zydm;
        this.qrzshow = this.fqrzshow = this.fqqrall = this.form.zyzszy[0].xxfs
          .sort()
          .toString();
      }
    },
    "form.optionzy": {
      handler: function(val) {
        const tmp = this.form.zyzszy.find(el => el.zydm === val);
        if (!tmp) {
          return;
        }
        this.qrzshow = this.fqrzshow = this.fqqrall = tmp.xxfs
          .sort()
          .toString();
        this.freshselect();
      }
    }
  },
  methods: {
    cancel() {
      this.visibles(false);
    },
    formsave() {
      var obj = {};
      var xydm;
      if (this.activeName == "0") {
        if (!this.form.optionxy || !this.form.optionzy) {
          return this.$message.error("请填写完整再提交");
        }
        xydm = this.form.optionxy;
        obj = {
          xydm: this.form.optionxy,
          zydm: this.form.optionzy,
          status: this.activeName,
          fqrz: this.fqrz,
          qrz: this.qrz
        };
      }
      if (this.activeName == "1") {
        if (!this.form.optionyjxy || !this.form.optionyjzy) {
          return this.$message.error("请填写完整再提交");
        }
        xydm = this.form.optionyjxy;
        obj = {
          xydm: this.form.optionyjxy,
          zydm: this.form.optionyjzy,
          status: this.activeName,
          fqrz: this.fqrzs,
          qrz: this.qrzs
        };
      }
      this.$http
        .get(`api/enroll/enrollmentReport/checkMe/${xydm}`)
        .then(res => {
          if (res.data.code == 400) {
            this.$message.error(res.data.message);
          } else {
            this.$http
              .post("api/enroll/enrollmentReport/save", obj)
              .then(res => {
                if (res.data.code == 400) {
                  this.$message.error(res.data.message);
                } else {
                  this.$message.success(res.data.message);
                  this.visibles(false);
                  this.fresh();
                }
              });
          }
        });
    },
    // 获取学院与其相对的专业
    getZyTree() {
      this.$http
        .get(
          `api/enroll/enrollmentReport/getZyTree/${this.$stores.state.roleid_tole}`
        )
        .then(res => {
          // 校验数据异常
          if (!Array.isArray(res.data.data)) {
            this.$message.error("数据异常");
          } else {
            // 按照专业招生进行学院筛选
            this.form.zyzsxy = res.data.data;
            console.log(this.form.zyzsxy);
          }
        });
    },
    // 获取学院与其相对的专业
    enrollmentReport() {
      this.$http
        .get(
          `api/enroll/enrollmentReport/getYjTree/${this.$stores.state.roleid_tole}`
        )
        .then(res => {
          console.log(res.data.data);
          // 校验数据异常
          if (!Array.isArray(res.data.data)) {
            this.$message.error("数据异常");
          } else {
            this.form.yjfxxy = res.data.data;
            console.log(this.form.yjfxxy);
          }
        });
    },
    // tab切换
    handleClick() {
      this.form = {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      };
      this.fqrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ];
      this.qrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ];
      this.fqrzs = [];
      this.qrzs = [];
      this.getZyTree();
      this.enrollmentReport();
      this.qrzshow = "1";
      this.fqrzshow = "2";
      this.fqqrall = "1,2";
    },
    freshform() {
      this.form = {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: "",
        // 按专业招生专业
        optionzy: "",
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: "",
        // 按研究方向招生专业
        optionyjzy: ""
      };
      this.fqrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ];
      this.qrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ];
      this.fqrzs = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: "",
          yjmc: ""
        }
      ];
      this.qrzs = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: "",
          yjmc: ""
        }
      ];
      this.getZyTree();
      this.zyzsxyshow = true;
      this.yjfxxyshow = true;
      this.activeName = "0";
      this.qrzshow = "1";
      this.fqrzshow = "2";
      this.fqqrall = "1,2";
    },
    freshselect() {
      this.fqrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ];
      this.qrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ];
      this.fqrzs = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: "",
          yjmc: ""
        }
      ];
      this.qrzs = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0,
          yjdm: "",
          yjmc: ""
        }
      ];
    },
    selectoptionyjxy() {
      this.qrzs = [];
      this.fqrzs = [];
      // 按研究方向招生学院筛选专业
      const yjZy = this.form.yjfxxy.find(
        el => el.xydm === this.form.optionyjxy
      );
      if (yjZy.yjZyTreesList.length && yjZy.yjZyTreesList !== null) {
        this.form.yjfxzy = yjZy.yjZyTreesList;
        this.form.optionyjzy = this.form.yjfxzy[0].zydm;
        if (
          this.form.yjfxzy[0].yjfxTreeList !== null &&
          this.form.yjfxzy[0].yjfxTreeList.length
        ) {
          this.form.yjfxzy[0].yjfxTreeList.forEach(element => {
            var obj = {
              zymtsrs: 0,
              zyrs: 0,
              zyzyfsrs: 0,
              yjdm: element.dm,
              yjmc: element.mc
            };
            if (
              element.xxfs
                .split(",")
                .sort()
                .toString() == "1"
            ) {
              this.qrzs.push(obj);
            }
            if (
              element.xxfs
                .split(",")
                .sort()
                .toString() == "2"
            ) {
              this.fqrzs.push(obj);
            }
            if (
              element.xxfs
                .split(",")
                .sort()
                .toString() == "1,2"
            ) {
              this.qrzs.push(JSON.parse(JSON.stringify(obj)));
              this.fqrzs.push(JSON.parse(JSON.stringify(obj)));
            }
          });
        }
      } else {
        this.form.optionyjzy = "";
        this.form.yjfxzy = [];
        this.$message.error("当前学院所对应的专业不存在");
      }
    },
    selectoptionyjzy() {
      this.qrzs = [];
      this.fqrzs = [];
      const yjZy = this.form.yjfxzy.find(
        el => el.zydm === this.form.optionyjzy
      );
      if (!yjZy) {
        return;
      }
      yjZy.yjfxTreeList.forEach(element => {
        var obj = {
          zymtsrs: 0,
          zyrs: 0,
          zyzyfsrs: 0,
          yjdm: element.dm,
          yjmc: element.mc
        };
        if (element.xxfs.sort().toString() == "1") {
          this.qrzs.push(obj);
        }
        if (element.xxfs.sort().toString() == "2") {
          this.fqrzs.push(obj);
        }
        if (element.xxfs.sort().toString() == "1,2") {
          this.qrzs.push(JSON.parse(JSON.stringify(obj)));
          this.fqrzs.push(JSON.parse(JSON.stringify(obj)));
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
table.gridtable {
  font-family: verdana, arial, sans-serif;
  font-size: 11px;
  color: #333333;
  border-width: 1px;
  border-color: #e5e5e5;
  border-collapse: collapse;
  width: 100%;
}
table.gridtable th {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  // background-color: #f2f2f2;
}
table.gridtable td {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  background-color: #f2f2f2;
  text-align: center;
  color: #333333;
  width: 180px;
}
table.gridtable .noneback {
  background: #fff;
}
.dialog-footers {
  text-align: center;
}
.demo-form-inline {
  height: 56px !important;
}
.dialog__footer {
  margin-top: 32px;
  padding: 10px 20px 20px;
  text-align: center;
}
</style>
