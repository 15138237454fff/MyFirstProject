<template>
  <div class="quotAdd">
    <el-tabs type="border-card" v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="按专业招生" name="0" v-if="zyzsxyshow">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <span>{{form.optionxy}}</span>
          </el-form-item>
          <el-form-item label="选择专业：">
            <span>{{form.optionzy}}</span>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>学习方式</td>
            <td>专业招生名额</td>
            <td>专业免推生人数</td>
            <td>专业一志愿复试人数</td>
          </tr>
          <tr v-if="qrzshow == '1' || fqqrall=='1,2'">
            <td>全日制</td>
            <td class="noneback">
              <el-input v-model="qrz[0].zyrs" placeholder="请输入" clearable type="number"></el-input>
            </td>
            <td class="noneback">
              <el-input v-model="qrz[0].zymtsrs" placeholder="请输入" clearable type="number"></el-input>
            </td>
            <td class="noneback">
              <el-input v-model="qrz[0].zyzyfsrs" placeholder="请输入" clearable type="number"></el-input>
            </td>
          </tr>
          <tr v-if="fqrzshow == '2' || fqqrall=='1,2'">
            <td>非全日制</td>
            <td class="noneback">
              <el-input v-model="fqrz[0].zyrs" placeholder="请输入" clearable type="number"></el-input>
            </td>
            <td class="noneback">
              <el-input v-model="fqrz[0].zymtsrs" placeholder="请输入" clearable type="number"></el-input>
            </td>
            <td class="noneback">
              <el-input v-model="fqrz[0].zyzyfsrs" placeholder="请输入" clearable type="number"></el-input>
            </td>
          </tr>
        </table>
      </el-tab-pane>
      <el-tab-pane label="按研究方向招生" name="1" v-if="yjfxxyshow">
        <el-form ref="form" label-width="100px" style="margin-top:20px">
          <el-form-item label="选择学院：">
            <span>{{form.optionxy}}</span>
          </el-form-item>
          <el-form-item label="选择专业：">
            <span>{{form.optionzy}}</span>
          </el-form-item>
        </el-form>
        <table class="gridtable">
          <tr>
            <td>方向代码</td>
            <td>研究方向</td>
            <td>学习方式</td>
            <td>方向招生名额</td>
            <td>方向推免生人数</td>
            <td>方向一志愿复试人数</td>
          </tr>
          <template>
            <tr v-for="(item,index) in qrzs">
              <td>{{item.yjdm}}</td>
              <td>{{item.yjmc}}</td>
              <td>全日制</td>
              <td class="noneback">
                <el-input v-model="item.zyrs" placeholder="请输入" clearable type="number"></el-input>
              </td>
              <td class="noneback">
                <el-input v-model="item.zymtsrs" placeholder="请输入" clearable type="number"></el-input>
              </td>
              <td class="noneback">
                <el-input v-model="item.zyzyfsrs" placeholder="请输入" clearable type="number"></el-input>
              </td>
            </tr>
          </template>
          <template>
            <tr v-for="(item,index) in fqrzs">
              <td>{{item.yjdm}}</td>
              <td>{{item.yjmc}}</td>
              <td>非全日制</td>
              <td class="noneback">
                <el-input v-model="item.zyrs" placeholder="请输入" clearable type="number"></el-input>
              </td>
              <td class="noneback">
                <el-input v-model="item.zymtsrs" placeholder="请输入" clearable type="number"></el-input>
              </td>
              <td class="noneback">
                <el-input v-model="item.zyzyfsrs" placeholder="请输入" clearable type="number"></el-input>
              </td>
            </tr>
          </template>
        </table>
      </el-tab-pane>
    </el-tabs>
    <div class="dialog__footer">
      <el-button @click="cancel">取消</el-button>
      <el-button type="primary" @click="formsavexg">保存</el-button>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    visiblesd: {
      type: Function,
      required: true
    },
    fresh: { type: Function, required: true }
  },
  name: 'quotxg',
  data() {
    return {
      zyzsxyshow: false,
      yjfxxyshow: false,
      activeName: '0',
      selectvalue: '',
      form: {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: '',
        // 按专业招生专业
        optionzy: '',
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: '',
        // 按研究方向招生专业
        optionyjzy: ''
      },
      fqrz: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ],
      qrz: [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ],
      fqrzs: [],
      qrzs: [],
      qrzshow: '1',
      fqrzshow: '2',
      fqqrall: '1,2',
      xydmlist: '',
      zydmlist: '',
      id: ''
    }
  },
  mounted() {},
  created() {
    // 获取学院与其相对的专业
    this.$bus.$on('formxg', msg => {
      this.form.optionxy = msg.datatype.xymc
      this.form.optionzy = msg.datatype.zymc
      if (msg.datatype.status == '0') {
        this.zyzsxyshow = true
        this.yjfxxyshow = false
        this.fqrz = msg.datatype.fqrz
        this.qrz = msg.datatype.qrz
        this.activeName = '0';
        this.id = msg.datatype.id
        this.xyzy(msg.xy)
      }
      if (msg.datatype.status == '1') {
        this.zyzsxyshow = false
        this.yjfxxyshow = true
        this.activeName = '1';
        this.fqrzs = msg.datatype.fqrz
        this.qrzs = msg.datatype.qrz
        this.id = msg.datatype.id
        this.yjfx(msg.xy)
      }
    })
  },
  methods: {
    formsavexg() {
      var obj = {}
      console.log(this.xydmlist)
      this.$http
        .get(`api/enroll/enrollmentReport/checkMe/${this.xydmlist}`)
        .then(res => {
          if (res.data.code == 400) {
            this.$message.error(res.data.message)
          } else {
            if (this.activeName == '0') {
              // this.xyzy()
              obj = {
                xydm: this.xydmlist,
                zydm: this.zydmlist,
                status: this.activeName,
                fqrz: this.fqrz,
                qrz: this.qrz,
                id: this.id
              }
            }
            if (this.activeName == '1') {
              // this.yjfx()
              obj = {
                xydm: this.xydmlist,
                zydm: this.zydmlist,
                status: this.activeName,
                fqrz: this.fqrzs,
                qrz: this.qrzs,
                id: this.id
              }
            }
            this.$http
              .put('api/enroll/enrollmentReport/update', obj)
              .then(res => {
                if (res.data.code == 400) {
                  this.$message.error(res.data.message)
                } else {
                  this.$message.success(res.data.message)
                  this.fresh()
                  this.cancel()
                }
              })
          }
        })
    },
    cancel() {
      this.visiblesd(false)
    },
    xyzy(val) {
      const list = val.find(el => el.xymc == this.form.optionxy)
      if (list) {
        this.xydmlist = list.xydm
        const zy = list.zyTreesList.find(
          item => item.zymc == this.form.optionzy
        )
        if (zy) {
          this.zydmlist = zy.zydm
        }
      }
    },
    yjfx(val) {
      const yjZy = val.find(el => el.xymc === this.form.optionxy)
      if (yjZy) {
        this.xydmlist = yjZy.xydm
        const zy = yjZy.yjZyTreesList.find(
          item => item.zymc == this.form.optionzy
        )
        if (zy) {
          this.zydmlist = zy.zydm
        }
      }
    },
    // 获取学院与其相对的专业
    // tab切换
    handleClick() {},
    freshform() {
      this.form = {
        // 按专业招生学院下拉
        zyzsxy: [],
        // 按专业招生专业下拉
        zyzszy: [],
        // 按专业招生学院
        optionxy: '',
        // 按专业招生专业
        optionzy: '',
        // 按研究方向招生学院下拉
        yjfxxy: [],
        // 按研究方向招生专业下拉
        yjfxzy: [],
        // 按研究方向招生学院
        optionyjxy: '',
        // 按研究方向招生专业
        optionyjzy: ''
      }
      this.fqrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ]
      this.qrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ]
      this.fqrzs = []
      this.qrzs = []
      this.zyzsxyshow = true
      this.yjfxxyshow = true
      this.activeName = '0';
      this.qrzshow = '1';
      this.fqrzshow = '2';
      this.fqqrall = '1,2';
      this.xydmlist = '';
      this.zydmlist = '';
      this.id = '';
    },
    freshselect() {
      this.fqrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ]
      this.qrz = [
        {
          // 专业免推生人数
          zymtsrs: 0,
          // 专业招生人数
          zyrs: 0,
          // 专业志愿复试人数
          zyzyfsrs: 0
        }
      ]
      this.fqrzs = []
      this.qrzs = []
    }
  }
}
</script>
<style lang="scss" scoped>
table.gridtable {
  font-family: verdana, arial, sans-serif;
  font-size: 11px;
  color: #333333;
  border-width: 1px;
  border-color: #e5e5e5;
  border-collapse: collapse;
  width: 100%;
}
table.gridtable th {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  // background-color: #f2f2f2;
}
table.gridtable td {
  border-width: 1px;
  padding: 8px;
  border-style: solid;
  border-color: #e5e5e5;
  background-color: #f2f2f2;
  text-align: center;
  color: #333333;
  width: 180px;
}
table.gridtable .noneback {
  background: #fff;
}
.dialog-footers {
  text-align: center;
}
.demo-form-inline {
  height: 56px !important;
}
.dialog__footer {
  margin-top: 32px;
  padding: 10px 20px 20px;
  text-align: center;
}
</style>


