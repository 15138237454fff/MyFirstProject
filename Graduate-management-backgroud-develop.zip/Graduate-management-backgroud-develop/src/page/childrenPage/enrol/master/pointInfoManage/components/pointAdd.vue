<template>
  <div class="specialAdd">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div class="header-right">
        <!-- <el-button type="primary" @click="saveForm">保存</el-button> -->
      </div>
    </div>
    <table>
      <tr>
        <td class="listcss">考点代码</td>
        <td>{{content.bmddm}}</td>
        <td class="listcss">邮政编码</td>
        <td>{{content.yzbm}}</td>
      </tr>
      <tr>
        <td class="listcss">联系电话</td>
        <td>{{content.yddh}}</td>
        <td class="listcss">接收试卷地址</td>
        <td>{{content.jssjdz}}</td>
      </tr>
      <tr>
        <td class="listcss">接收试卷人姓名</td>
        <td>{{content.jssjrxm}}</td>
        <td class="listcss">试卷接收人电话</td>
        <td>{{content.sjjsrdh}}</td>
      </tr>
      <tr>
        <td class="listcss">考试地点名称</td>
        <td>{{content.ksddmc}}</td>
        <td class="listcss">所在省市码</td>
        <td>{{content.szssm}}</td>
      </tr>
      <tr>
        <td class="listcss">城市名称</td>
        <td>{{content.csmc}}</td>
        <td class="listcss">联系部门</td>
        <td>{{content.lxbm}}</td>
      </tr>
      <tr>
        <td class="listcss">传真</td>
        <td>{{content.cz}}</td>
        <td class="listcss">邮箱</td>
        <td>{{content.email}}</td>
      </tr>
      <tr>
        <td class="listcss">接受试卷人QQ</td>
        <td>{{content.jssjrim}}</td>
        <td class="listcss">备注</td>
        <td>{{content.bz}}</td>
      </tr>
      <tr>
        <td class="listcss">联系人姓名</td>
        <td>{{content.lxrim}}</td>
        <td class="listcss">联系人传真</td>
        <td>{{content.lxrcz}}</td>
      </tr>
      <tr>
        <td class="listcss">联系人邮箱</td>
        <td>{{content.lxremail}}</td>
        <td class="listcss">联系人电话</td>
        <td>{{content.lxrdh}}</td>
      </tr>
      <tr>
        <td class="listcss">联系人手机</td>
        <td>{{content.lxrsj}}</td>
        <td class="listcss">联系人职位</td>
        <td>{{content.lxrzw}}</td>
      </tr>
      <tr>
        <td class="listcss"> 联系人QQ</td>
        <td>{{content.lxrim}}</td>
        <td class="listcss"></td>
        <td></td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: "pointAdd",
  data() {
    return {
      content: {}
    };
  },
  created() {
    this.$http
      .get(`/api/enroll/evc/${this.$route.query.specialId}`)
      .then(res => {
        if (res.data.data) {
          this.$storage.addObjectKey(res.data.data, this.content);
          this.content = res.data.data;
        } else {
          this.$message.error("数据异常,请刷新");
          this.$router.go(-1);
        }
      });
  },
  computed: {},
  methods: {}
};
</script>
<style lang="scss" scoped>
.specialAdd {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;
    margin-bottom: 20px;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 48px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 48px;
      padding-left: 10px;
      width: 180px;
    }
    .left_cont {
      text-align: left;
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      background: #f2f2f2;
      width: 180px;
    }
    .ss1 {
      color: red;
    }
    .ss2 {
      color: rgb(255, 153, 0);
    }
    .ss3 {
      color: rgb(102, 204, 51);
    }
  }
}
</style>

