<template>
  <div class="pointInfoManage">
    <point-add v-if="id != 2"></point-add>
    <point-list v-if="id == 2"></point-list>
  </div>
</template>
<script>
import pointList from './components/pointList';
import pointAdd from './components/pointAdd';
export default {
  name: 'pointInfoManage',
  data() {
    return {}
  },
  components: {
    'point-list': pointList,
    'point-add': pointAdd
  },
  computed: {
    id() {
      return this.$route.query.id
    }
  }
}
</script>
<style lang="scss" scoped>
.pointInfoManage {
  width: 100%;
  overflow: hidden;
}
</style>


