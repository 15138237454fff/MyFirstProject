<template>
  <div class="specialList">
    <searchcomponment>
      <div slot="left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考点代码/名称"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
      </div>
      <div slot="right">
        <el-upload
          action="/api/enroll/evc/import"
          :show-file-list="false"
          style="display:inline-block;"
          :on-success="handleUpload"
          :on-error="handleError"
          :headers="headers"
          v-if="$btnAuthorityTest('pointInfoManage:import')"
        >
          <el-button type="primary" plain>导入</el-button>
        </el-upload>
        <el-dropdown
          @command="handleTags"
          v-if="$btnAuthorityTest('pointInfoManage:export')"
        >
          <el-button type="primary" plain>
            导出
            <i class="el-icon-arrow-down el-icon--right"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item :command="1">考点邮件封面</el-dropdown-item>
            <el-dropdown-item :command="2">硕士初试汇总</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$storage.tableHeaderColor"
    >
      <el-table-column type="index" width="55" label="序号"></el-table-column>
      <el-table-column prop="bmddm" label="考点代码"></el-table-column>
      <el-table-column prop="ksddmc" label="考点名称"></el-table-column>
      <el-table-column prop="csmc" label="城市名称"></el-table-column>
      <el-table-column prop="jssjrxm" label="接受试卷人姓名"></el-table-column>
      <el-table-column prop="sjjsrdh" label="联系电话"></el-table-column>
      <el-table-column prop="lxbm" label="联系部门"></el-table-column>
      <el-table-column prop="yzbm" label="邮政编码"></el-table-column>
      <el-table-column prop="ksddmc" label="接收试卷地址"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <!-- <span class="tablexq" @click="goxq(scope.row,scope.$index)" style="text-decoration: underline">查看详情</span> -->
          <span
            class="tablexq"
            @click="goDetail(scope.row, scope.$index)"
            style="text-decoration: underline"
            v-if="$btnAuthorityTest('pointInfoManage:view')"
            >查看详情</span
          >
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>

<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../../componments/timecommon";
export default {
  components: {
    searchcomponment: searchcomponment,
    timecommon
  },
  name: "pointList",
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // 报名点代码
          bmddm: "",
          // 城市名称
          csmc: "",
          // ID
          id: "",
          // 接收试卷地址
          jssjdz: "",
          // 接收试卷人姓名
          jssjrxm: "",
          // 考试地点名称
          ksddmc: "",
          // 联系部门
          lxbm: "",
          // 试卷接收人电话
          sjjsrdh: "",
          // 邮政编码
          yzbm: ""
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: 2019
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 可选的年度列表
      yearOptions: [
        { label: "2019年", value: 2019 },
        { label: "2020年", value: 2020 }
      ],
      tableHeight: null,
      headers: {
        userToken: this.$stores.state.token
      }
    };
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };

    // 获取当前的招生年度数据
    this.requireCurrentYear();
  },
  watch: {
    $route(to) {
      if (to.name === "pointInfoManage") {
        this.loadTable();
      }
    }
  },
  methods: {
    // 查看详情
    goxq(row, index) {
      console.log(row, index);
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      console.log("正在请求列表数据");
      this.loading = true;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 2000);
      this.$http
        .post("/api/enroll/evc/list", this.limitQuery)
        .then(res => {
          let data = res.data;
          this.loading = false;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!data || !Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          // console.log(data.info);
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 导入按钮事件
    handleUpload(res) {
      if (res.code == 200) {
        this.$message.success(res.message);
        this.loading = true;
        setTimeout(() => {
          this.loadTable();
        }, 10000);
      } else {
        this.loading = false;
        this.$message.error(res.message);
      }
    },
    // 导入出错
    handleError(err) {
      console.log(err);
      this.$message.error("导入失败，请重试");
    },
    // 导出下拉菜单项点击事件
    handleTags(command) {
      this.$http.get(`/api/enroll/evc/export/check/${command}`).then(res => {
        if (res.data.code == 200) {
          if (command === 1) {
            window.location.href = `/api/enroll/evc/export/exam`;
          } else {
            window.location.href = `/api/enroll/evc/export/preliminary`;
          }
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 查看详情
    goDetail(row, index) {
      console.log(`正在前往查看第${index}条数据`);
      // return;
      this.$router.push({
        path: "/pointInfoManage",
        query: {
          id: 3,
          specialId: this.tableData[index].id,
          page: this.limitQuery.pageNum
        }
      });
    },

    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.yearOptions = res.data.data;
      });
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.loadTable();
      });
    }
    // //判断是否可以勾选的方法
    // confirmSelectable(row) {
    //   if (row.zt == "1" || row.zt == "3") {
    //     return false;
    //   } else {
    //     return true;
    //   }
    // }
  },
  filters: {
    xxxsFilter(arr) {
      if (Array.isArray(arr)) {
        const tmp = arr
          // .sort((a, b) => a - b)
          .map(el => (el == 1 ? "全日制" : "非全日制"))
          .toString();
        return tmp;
      } else {
        console.error("过滤的参数不是一个数组");
        return "";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.specialList {
  padding-top: 7px;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  /deep/ .el-date-editor {
    margin-left: 10px;
  }

  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-select,
    .el-button {
      margin-left: 0px;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
}
</style>
