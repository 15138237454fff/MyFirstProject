<template>
  <div class="specialAdd">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="saveForm" v-if="writeable">保存</el-button>
        <!-- <el-button type="primary" v-if="!writeable && (status == 2 || status == 4) && this.$route.query.isForm =='1'">保存</el-button> -->
        <span v-if="(!writeable && status == 1) || status == 3" :class="status | zsZTFilter(1)">{{ status | zsZTFilter(0) }}</span>
      </div>
    </div>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="2" class="table-one">
        <tbody>
          <th colspan="6"><span>|</span> 招生专业信息</th>
          <tr>
            <td class="required">学院名称</td>
            <td colspan="5">
              <el-select v-model="specialForm.xydm" :disabled="!writeable" style="width:50%;">
                <el-option v-for="(item, index) in xyOptions" :key="index" :label="item.label" :value="item.value"></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="required">专业名称</td>
            <td colspan="5">
              <el-select v-model="specialForm.zydm" :disabled="!writeable" style="width:50%;" placeholder="请选择" @change="specialFormxydm(specialForm.xydm, specialForm.zydm)">
                <el-option v-for="(item, index) in zyOptions" :key="index" :label="item.label" :value="item.value"></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="required">学习方式</td>
            <td colspan="5">
              <el-checkbox-group v-model="specialForm.xxxs" :disabled="!writeable" @change="specialFormxxxs">
                <el-checkbox :label="1">全日制</el-checkbox>
                <el-checkbox :label="2">非全日制</el-checkbox>
              </el-checkbox-group>
            </td>
          </tr>
          <tr>
            <td>研究方向</td>
            <td colspan="5">
              <div v-for="(item, index) of specialForm.yjfx" :key="index" class="yjfx-row">
                <el-input-number v-model="item.dm" placeholder="请输入方向代码" :disabled="!writeable" @input="fxdmIpt(item.dm, index)" :min="0" controls-position="right"></el-input-number>
                <el-input v-model="item.mc" placeholder="请输入方向名称" :disabled="!writeable"></el-input>
                <el-select v-model="item.xxfs" style="margin-left:5px" :disabled="!writeable" @visible-change="selectXxfs">
                  <el-option label="全日制" value="1" v-if="!writeable">
                  </el-option>
                  <el-option label="非全日制" value="2" v-if="!writeable">
                  </el-option>
                  <el-option label="全日制" value="1" v-if="
                      writeable &&
                        specialForm.xxxs &&
                        specialForm.xxxs.includes(1)
                    ">
                  </el-option>
                  <el-option label="非全日制" value="2" v-if="
                      writeable &&
                        specialForm.xxxs &&
                        specialForm.xxxs.includes(2)
                    ">
                  </el-option>
                </el-select>
                <el-button icon="el-icon-circle-plus" @click="addYjfx" class="add" v-if="writeable && index === 0"></el-button>
                <el-button icon="el-icon-remove" @click="removeYjfx(index)" class="add" v-if="writeable && index !== 0"></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>联系人</td>
            <td colspan="5">
              <el-input placeholder="请输入" v-model="specialForm.lxr" style="width:50%;" :disabled="!writeable"></el-input>
            </td>
          </tr>
          <tr>
            <td>联系方式</td>
            <td colspan="5">
              <el-input placeholder="请输入" v-model="specialForm.lxfs" style="width:50%;" :disabled="!writeable"></el-input>
            </td>
          </tr>
          <tr>
            <td>学位点简介</td>
            <td colspan="5">
              <el-input placeholder="请输入" v-model="specialForm.xwdjj" type="textarea" :rows="3" :disabled="!writeable"></el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-two">
        <tbody>
          <th colspan="6"><span>|</span>拟招生人数</th>
          <tr>
            <td class="required">全日制人数</td>
            <td>
              <el-input type="number" style="width:87px" :min="1" v-model="specialForm.qrzrs" :disabled="!writeable || qrzshow">
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
            <td class="required">非全日制人数</td>
            <td>
              <el-input type="number" style="width:87px" :min="1" v-model="specialForm.fqrzrs" :disabled="!writeable || fzrzshow">
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
          </tr>
          <tr>
            <td class="required">港澳台招生</td>
            <td>
              <el-switch v-model="specialForm.sfgatzs" active-text="是" :active-value="1" inactive-text="否" :inactive-value="0" class="my-switch" :disabled="!writeable"></el-switch>
              <el-input type="number" style="width:87px" :min="0" v-model="specialForm.gatzsrs" v-if="specialForm.sfgatzs" :disabled="!writeable">
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
            <td class="required">推免生招生</td>
            <td>
              <el-switch v-model="specialForm.sftmszs" active-text="是" :active-value="1" inactive-text="否" :inactive-value="0" class="my-switch" :disabled="!writeable"></el-switch>
              <el-input type="number" style="width:87px" :min="0" v-model="specialForm.tmsrs" v-if="specialForm.sftmszs" :disabled="!writeable">
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-three">
        <tbody>
          <th colspan="6"><span>|</span>初试考试科目</th>
          <tr class="td-header">
            <td>科目类别</td>
            <td>科目代码</td>
            <td>科目名称</td>
          </tr>
          <tr>
            <td>思想政治理论</td>
            <td>
              <div v-for="(item, index) of specialForm.sxzzll" :key="index">
                <el-input v-model="item.dm" placeholder="请输入" :disabled="!writeable"></el-input>
              </div>
            </td>
            <td>
              <div class="mc" placeholder="请输入" v-for="(item, index) of specialForm.sxzzll" :key="index">
                <el-input v-model="item.mc" placeholder="请输入" :disabled="!writeable"></el-input>
                <el-button icon="el-icon-circle-plus" @click="addSxzzll" class="add" v-if="writeable && index === 0"></el-button>
                <el-button icon="el-icon-remove" @click="removeSxzzll(index)" class="add" v-if="writeable && index !== 0"></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>外国语</td>
            <td>
              <div v-for="(item, index) of specialForm.wgy" :key="index">
                <el-input v-model="item.dm" placeholder="请输入" :disabled="!writeable"></el-input>
              </div>
            </td>
            <td>
              <div class="mc" placeholder="请输入" v-for="(item, index) of specialForm.wgy" :key="index">
                <el-input v-model="item.mc" placeholder="请输入" :disabled="!writeable"></el-input>
                <el-button icon="el-icon-circle-plus" @click="addWgy" class="add" v-if="writeable && index === 0"></el-button>
                <el-button icon="el-icon-remove" @click="removeWgy(index)" class="add" v-if="writeable && index !== 0"></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>业务课一</td>
            <td>
              <div v-for="(item, index) of specialForm.ywky" :key="index">
                <el-input v-model="item.dm" placeholder="请输入" :disabled="!writeable"></el-input>
              </div>
            </td>
            <td>
              <div class="mc" placeholder="请输入" v-for="(item, index) of specialForm.ywky" :key="index">
                <el-input v-model="item.mc" placeholder="请输入" :disabled="!writeable"></el-input>
                <el-button icon="el-icon-circle-plus" @click="addYwky" class="add" v-if="writeable && index === 0"></el-button>
                <el-button icon="el-icon-remove" @click="removeYwky(index)" class="add" v-if="writeable && index !== 0"></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>业务课二</td>
            <td>
              <div v-for="(item, index) of specialForm.ywke" :key="index">
                <el-input v-model="item.dm" placeholder="请输入" :disabled="!writeable"></el-input>
              </div>
            </td>
            <td>
              <div class="mc" placeholder="请输入" v-for="(item, index) of specialForm.ywke" :key="index">
                <el-input v-model="item.mc" placeholder="请输入" :disabled="!writeable"></el-input>
                <el-button icon="el-icon-circle-plus" @click="addYwke" class="add" v-if="writeable && index === 0"></el-button>
                <el-button icon="el-icon-remove" @click="removeYwke(index)" class="add" v-if="writeable && index !== 0"></el-button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-four">
        <tbody>
          <tr>
            <td>复试科目及参考书</td>
            <td colspan="5">
              <el-input placeholder="请输入" v-model="specialForm.fskmjcks" type="textarea" :rows="3" :disabled="!writeable"></el-input>
            </td>
          </tr>
          <tr>
            <td>同等学力加试科目及参考书</td>
            <td colspan="5">
              <el-input placeholder="请输入" v-model="specialForm.tdlxjskmjcks" type="textarea" :rows="3" :disabled="!writeable"></el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <apply-status-bottom></apply-status-bottom>
    </div>
  </div>
</template>
<script>
import applyStatusBottom from "@/components/applyStatusBottom";
export default {
  name: "specialAdd",
  data() {
    return {
      specialForm: {
        // 学习形式
        xxxs: [],
        // 研究方向
        yjfx: [{ dm: "", mc: "", xxfs: "" }],
        // 非全日制人数
        fqrzrs: 0,
        // 复试科目及参考书
        fskmjcks: "",
        // 港澳台招生人数
        gatzsrs: 1,
        // 联系方式
        lxfs: "",
        // 联系人
        lxr: "",
        // 全日制人数
        qrzrs: 0,
        // 是否港澳台招生
        sfgatzs: 0,
        // 是否推免生招生
        sftmszs: 0,
        // 思想政治理论
        sxzzll: [{ dm: "", mc: "" }],
        // 外国语
        wgy: [{ dm: "", mc: "" }],
        // 业务课一
        ywky: [{ dm: "", mc: "" }],
        // 业务课二
        ywke: [{ dm: "", mc: "" }],
        // 同等学力加试科目及参考书
        tdlxjskmjcks: "",
        // 推免生人数
        tmsrs: 1,
        // 学位点简介
        xwdjj: "",
        // 学院代码
        xydm: "",
        // 专业代码
        zydm: ""
      },
      // //是否可写
      // writeable: true,
      // 审核状态
      status: "",
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      qrzshow: true,
      fzrzshow: true
    };
  },
  components: {
    "apply-status-bottom": applyStatusBottom
  },
  created() {
    console.log(this.$route.query);
    // 请求学院专业信息
    this.requireXY();
    // 请求审核记录
    this.detailStatus();
    // 如果是查看/修改页面
    if (this.id == 3 || this.id == 4) {
      // 回显数据
      this.dataBack();
      console.log(this.specialForm);
    }
  },
  computed: {
    // 根据路由信息返回是否可写
    writeable() {
      console.log("writeable");
      if (this.$route.query.id != 3) {
        return true;
      } else {
        return false;
      }
    },
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  methods: {
    fxdmIpt(val, index) {
      if (val.length > 2) {
        this.specialForm.yjfx[index].dm = val.slice(0, 2);
      }
    },
    selectXxfs(val) {
      console.log(val);
      if (val && this.specialForm.xxxs.length == 0) {
        this.$message.warning("请先选择学习方式");
      }
    },
    specialFormxxxs(val) {
      val.includes(1) ? (this.qrzshow = false) : (this.qrzshow = true);
      val.includes(2) ? (this.fzrzshow = false) : (this.fzrzshow = true);
    },
    // 学院与专业的校验是否已经是上报过的专业
    specialFormxydm(val, zydm) {
      console.log(this.specialForm.zydm);
      this.$http.get(`/api/enroll/mbc/getAddedZydms/${val}`).then(res => {
        console.log(res);
        if (res.data.data == 1) {
          this.$message.error("该学院所对应的专业已经上报过,请重新选择");
          this.specialForm.zydm = "";
        }
      });
    },
    // 提交表单数据，保存
    saveForm() {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmSave,
        title: "确认保存",
        msgOne: "是否确认保存？",
        msgTwo: ""
      });
    },
    // 回显历史的申请记录
    dataBack() {
      this.$http.get(`/api/enroll/mbc/${this.specialId}`).then(res => {
        const data = res.data.data;
        // 非空验证
        if (!data) {
          this.$message.error("获取历史上报记录失败，请重试");
          return;
        }
        // 保存请求获取的表单值
        Object.keys(this.specialForm).forEach(key => {
          this.specialForm[key] = data[key];
        });
        if (this.id == 4) {
          if (!this.specialForm.yjfx) {
            this.specialForm.yjfx = [{ dm: "", mc: "", xxfs: "" }];
          }
          if (!this.specialForm.sxzzll) {
            this.specialForm.sxzzll = [{ dm: "", mc: "" }];
          }
          if (!this.specialForm.wgy) {
            this.specialForm.wgy = [{ dm: "", mc: "" }];
          }
          if (!this.specialForm.ywky) {
            this.specialForm.ywky = [{ dm: "", mc: "" }];
          }
          if (!this.specialForm.ywke) {
            this.specialForm.ywke = [{ dm: "", mc: "" }];
          }
        }
        // 保存审核状态
        this.status = data.zt;
        this.specialFormxxxs(this.specialForm.xxxs);
      });
    },
    // 提交表单数据的方法
    confirmSave() {
      if (!this.qrzshow) {
        if (this.specialForm.qrzrs < 1) {
          return this.$message.error("全日制人数必须大于1人");
        }
      }
      if (!this.fzrzshow) {
        if (this.specialForm.fqrzrs < 1) {
          return this.$message.error("非全日制人数必须大于1人");
        }
      }
      // 关闭对话框
      this.$store.commit("skb/updateDialog", { visible: false });
      // 基本类型的必填字段
      let requiredArr = ["xydm", "zydm"],
        tmpTest = true,
        specialForm = JSON.parse(JSON.stringify(this.specialForm));
      // 如果是港澳台招生，则港澳台人数必填
      if (specialForm.sfgatzs === 1) {
        requiredArr.push("gatzsrs");
      }
      // 如果是港澳台招生，则推免生人数必填
      if (specialForm.sftmszs === 1) {
        requiredArr.push("tmsrs");
      }
      // 对待提交的数据进行验证
      requiredArr.forEach(key => {
        // 如果必填项包含空字符
        if (specialForm[key] === "") {
          console.log(1);
          tmpTest = false;
          return;
        }
        // 如果学习形式没有勾选
        if (specialForm.xxxs.length === 0) {
          tmpTest = false;
          return;
        }
      });
      if (specialForm.yjfx) {
        specialForm.yjfx.forEach(Element => {
          if (Element.dm == "" && Element.mc == "" && Element.xxfs == "") {
            specialForm.yjfx = null;
          }
        });
      }
      // 如果验证通过发送请求保存数据
      if (tmpTest) {
        specialForm.sxzzll = specialForm.sxzzll.filter(el => {
          return el.dm !== "" && el.mc !== "";
        });
        if (specialForm.sxzzll.length === 0) {
          specialForm.sxzzll = null;
        }
        specialForm.wgy = specialForm.wgy.filter(el => {
          return el.dm !== "" && el.mc !== "";
        });
        if (specialForm.wgy.length === 0) {
          specialForm.wgy = null;
        }
        specialForm.ywky = specialForm.ywky.filter(el => {
          return el.dm !== "" && el.mc !== "";
        });
        if (specialForm.ywky.length === 0) {
          specialForm.ywky = null;
        }
        specialForm.ywke = specialForm.ywke.filter(el => {
          return el.dm !== "" && el.mc !== "";
        });
        if (specialForm.ywke.length === 0) {
          specialForm.ywke = null;
        }
        console.log(specialForm);
        if (this.id == 1) {
          this.$http
            .post("/api/enroll/mbc", specialForm)
            .then(res => {
              if (res.data.code === 200) {
                this.$message.success("保存成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            })
            .catch(err => {
              if (err.response.data.code == 400) {
                this.$message.error("请勿添加重复专业");
              } else this.$message.error(err.response.data.message);
            });
        } else if (this.id == 4) {
          this.$http
            .put(`/api/enroll/mbc/${this.specialId}`, specialForm)
            .then(res => {
              if (res.data.code === 200) {
                this.$message.success("保存成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
      // 如果验证不通过
      else {
        this.$message.warning("请将必填项填写完整后再尝试提交");
      }
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http
        .get("/api/system/dict/select/enroll/local/college")
        .then(res => {
          const data = res.data.data;
          // 验证列表数据格式是否正确
          if (!Array.isArray(data)) {
            return this.$message.error("获取学院和专业信息失败，请重试");
          }
          this.xyOptions = data;
          const tmp = this.xyOptions.filter(el => {
            return el.value === this.specialForm.xydm;
          });
          if (!tmp[0]) {
            return;
          }
          this.zyOptions = tmp[0].children;
          this.specialForm.xymc = tmp[0].label;
        });
    },
    // 前往修改页面
    goModify() {
      this.$router.push({
        path: "/specialReport",
        query: { id: 4, specialId: this.specialId }
      });
    },
    // 添加一行研究方向
    addYjfx() {
      this.specialForm.yjfx.push({ dm: "", mc: "", xxfs: "" });
    },
    // 移除一行研究方向
    removeYjfx(index) {
      this.specialForm.yjfx.splice(index, 1);
    },
    // 添加一行思想政治理论
    addSxzzll() {
      this.specialForm.sxzzll.push({ dm: "", mc: "" });
    },
    // 移除一行思想政治理论
    removeSxzzll(index) {
      this.specialForm.sxzzll.splice(index, 1);
    },
    // 添加一行外国语
    addWgy() {
      this.specialForm.wgy.push({ dm: "", mc: "" });
    },
    // 移除一行外国语
    removeWgy(index) {
      this.specialForm.wgy.splice(index, 1);
    },
    // 添加一行业务课一
    addYwky() {
      this.specialForm.ywky.push({ dm: "", mc: "" });
    },
    // 移除一行业务课一
    removeYwky(index) {
      this.specialForm.ywky.splice(index, 1);
    },
    // 添加一行业务课二
    addYwke() {
      this.specialForm.ywke.push({ dm: "", mc: "" });
    },
    // 移除一行业务课二
    removeYwke(index) {
      this.specialForm.ywke.splice(index, 1);
    },
    detailStatus() {
      if (this.id == 3) {
        // 如果进入查看详情页面，请求对应流程id的审核状态
        this.$http.get("/api/enroll/mbac/" + this.specialId).then(res => {
          const data = res.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("获取审核具体流程数据失败，请刷新重试");
            return;
          }
          // 将审核具体流程数据发送给applyStatus
          this.$bus.$emit("stepList", data);
        });
      }
    }
  },
  watch: {
    "specialForm.xydm": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        if (this.zyOptions.length === 0) {
          this.specialForm.zydm = "";
          this.specialForm.zymc = "";
          return;
        }
        this.specialForm.xymc = tmp[0].label;
        this.specialForm.zydm = this.zyOptions[0].value;
        this.specialForm.zymc = this.zyOptions[0].label;
        this.specialFormxydm(val, this.specialForm.zydm);
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.specialAdd {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;

    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .box {
    // border: 1px solid rgba(228, 228, 228, 1);
    font-size: 14px;
    background-color: #fff;
    padding: 20px;
    margin-top: 10px;
    margin-bottom: 0;
    min-height: 73vh;
    table {
      width: 100%;
      border: 1px solid rgba(228, 228, 228, 1);
      border-collapse: collapse;
      color: #333;
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
      }
      td {
        width: 200px;
        height: 40px;
        border: 1px solid #e5e5e5;
      }
    }
    .table-one {
      td {
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
          text-align: center;
        }
        &:nth-child(even) {
          text-align: left;
          background: #fafafa;
        }
        .el-checkbox-group {
          padding-left: 20px;
        }
      }
    }
    .table-two {
      margin-top: 20px;
      td {
        text-align: center;
        position: relative;
      }
      /deep/ .my-switch {
        position: absolute;
        top: 50%;
        left: 50%;
        margin-left: -90px;
        margin-top: -10px;
        .el-switch__label {
          position: absolute;
          display: none;
          color: #fff;
        }
        .el-switch__label--left {
          z-index: 9;
          left: 20px;
        }
        .el-switch__label--right {
          z-index: 9;
          left: -4px;
        }
        .el-switch__label.is-active {
          display: block;
        }
        .el-switch .el-switch__core,
        .el-switch .el-switch__label {
          width: 50px !important;
        }
      }
    }
    .table-three {
      margin-top: 20px;
      td {
        text-align: center;
      }
      .td-header {
        background: #f0f2f5;
      }
    }
    .table-four {
      margin-top: 20px;
      td:nth-child(odd) {
        background: #f2f2f2;
        text-align: center;
      }
      .td-header {
        background: #f0f2f5;
      }
    }
    .add {
      &.el-button {
        padding: 0 10px;
      }
      font-size: 24px;
      color: #1e6fd9;
      border-radius: 50%;
      padding-left: 10px;
      background: #fff;
      outline: none;
      border: none;
    }
    .yjfx-row {
      width: 60%;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      align-items: center;
      .el-input:first-child {
        flex: 1;
      }
      .el-input:nth-child(2) {
        flex: 2;
        margin-left: 5px;
      }
    }
    .danwei {
      line-height: 40px;
      margin-right: 5px;
      color: #ccc;
      font-style: normal;
    }
    .mc {
      width: 100%;
      display: flex;
      flex-wrap: nowrap;
      align-items: center;
    }
  }
}
</style>
