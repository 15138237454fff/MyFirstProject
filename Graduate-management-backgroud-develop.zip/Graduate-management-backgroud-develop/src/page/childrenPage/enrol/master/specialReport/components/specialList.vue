<template>
  <div class="specialList">
    <searchcomponment>
      <div slot="left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入专业代码/名称"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <!-- <el-select v-model="limitQuery.year" type="year" placeholder="选择年度" @change="loadTable" style="width:120px" filterable clearable>
          <el-option v-for="(item,index) in yearOptions" :key="index" :label="item" :value="item"></el-option>
        </el-select> -->
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="addClick"
          v-if="$btnAuthorityTest('specialReport:add')"
          >添加</el-button
        >
        <el-button
          type="danger"
          @click="removeClick"
          v-if="$btnAuthorityTest('specialReport:delete')"
          >删除</el-button
        >
        <el-button
          type="primary"
          plain
          @click="reportClick"
          v-if="$btnAuthorityTest('specialReport:report')"
          >上报</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="$storage.tableHeaderColor"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="zydm" label="专业代码"></el-table-column>
      <el-table-column prop="zymc" label="专业名称"></el-table-column>
      <el-table-column prop="xymc" label="所属学院"></el-table-column>
      <el-table-column prop="xxxs" label="学习方式">
        <template slot-scope="scope">
          <span>{{ scope.row.xxxs | xxfsFilter(0) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="nzsrs" label="拟招生人数"></el-table-column>
      <el-table-column prop="zt" label="审核状态">
        <template slot-scope="scope">
          <span :class="scope.row.zt | zsZTFilter(1)">{{
            scope.row.zt | zsZTFilter(0)
          }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <span
            class="tablexq"
            @click="goDetail(scope.$index, 0)"
            v-if="$btnAuthorityTest('specialReport:view')"
            >查看</span
          >
          <span
            v-if="
              $btnAuthorityTest('specialReport:view') &&
                $btnAuthorityTest('specialReport:update')
            "
          >
            |
          </span>
          <template v-if="$btnAuthorityTest('specialReport:update')">
            <span
              class="tablexg"
              v-if="scope.row.zt == '2' || scope.row.zt == '4'"
              @click="goDetail(scope.$index, 1)"
              >修改</span
            ><span v-else class="tabledisbale">修改</span>
          </template>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>

<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../../componments/timecommon";
export default {
  name: "specialList",
  components: {
    searchcomponment,
    timecommon
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // 非全日制人数
          fqrzrs: "",
          // ID
          id: "",
          // 拟招生人数
          nzsrs: "",
          // 全日制人数
          qrzrs: "",
          // 是否港澳台招生
          sfgatzs: "",
          // 推免生人数
          tmsrs: "",
          // 学习形式
          xxxs: [],
          // 学院代码
          xydm: "",
          // 学院名称
          xymc: "",
          // 状态 0:不通过 1：通过 2：退回 3：审核中 4：未提交
          zt: "",
          // 专业代码
          zydm: "",
          // 专业名称
          zymc: ""
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: 2019
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 可选的年度列表
      yearOptions: [
        { label: "2019年", value: 2019 },
        { label: "2020年", value: 2020 }
      ],
      // 勾选的列
      selectRowList: [],
      tableHeight: null
    };
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    // 获取当前的招生年度数据
    this.requireCurrentYear();

    // this.loadTable()
  },
  watch: {
    $route(to) {
      if (to.name === "specialReport") {
        this.loadTable();
      }
    }
  },
  methods: {
    yeartable() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.yearOptions = res.data.data;
      });
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      console.log("正在请求列表数据");
      this.loading = true;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 2000);
      this.$http
        .post("/api/enroll/mbc/list", this.limitQuery)
        .then(res => {
          let data = res.data;
          this.loading = false;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          // console.log(data.info);
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 勾选一行时触发的事件处理函数
    handleSelectionChange(row) {
      this.selectRowList = row;
    },
    // 查看详情
    goDetail(index, val) {
      if (val == "0") {
        this.$router.push({
          path: "/specialReport",
          query: { id: 3, specialId: this.tableData[index].id, isForm: val }
        });
      }
      if (val == "1") {
        this.$router.push({
          path: "/specialReport",
          query: { id: 4, specialId: this.tableData[index].id, isForm: val }
        });
      }
      console.log(`正在前往查看第${index}条数据`);
    },
    // 点击添加的方法
    addClick() {
      console.log("正在前往添加");
      this.$router.push({ path: "/specialReport", query: { id: 1 } });
    },
    // 点击删除的出现对话框方法
    removeClick() {
      let tmpState = true;
      // 如果未勾选数据，验证不通过
      if (this.selectRowList.length === 0) {
        this.$message.error("请选择一条数据！");
        tmpState = false;
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmRemove,
        title: "删除信息",
        msgOne: "确定删除已选记录？",
        msgTwo: " "
      });
    },
    // 确认删除的方法
    confirmRemove() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
      // 临时的验证状态
      let tmpState = true;
      // 如果勾选了已通过/待审核的数据，验证不通过
      this.selectRowList.forEach(el => {
        if (el.zt == 3) {
          this.$message.error("请勿删除审核中数据！");
          tmpState = false;
          return;
        }
        if (el.zt == 1) {
          this.$message.error("请勿删除已通过数据！");
          tmpState = false;
          return;
        }
      });
      // 如果验证通过
      if (tmpState) {
        console.log("确认删除");
        let ids = [];
        this.selectRowList.forEach(el => {
          ids.push(el.id);
        });
        this.$http.delete("/api/enroll/mbc", { data: ids }).then(res => {
          if (res.data.code === 200) {
            this.$message.success("删除成功");
            this.loadTable();
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
    },
    // 点击上报出现对话框的方法
    reportClick() {
      let tmpState = true;
      if (this.selectRowList.length === 0) {
        this.$message.error("请选择一条数据！");
        tmpState = false;
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmReport,
        title: "上报",
        msgOne: "上报所有已选专业？",
        msgTwo: " "
      });
    },
    // 确认上报的方法
    confirmReport() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
      // 临时的验证状态
      let tmpState = true;
      // console.log(this.selectRowList);
      // 如果未勾选数据，验证不通过

      // 如果勾选了已通过/待审核的数据，验证不通过
      this.selectRowList.forEach(el => {
        // console.log(el.zt);
        if (el.zt == 1 || el.zt == 3) {
          this.$message.error("请勿重复上报！");
          tmpState = false;
          return;
        }
      });
      // console.log(tmpState);
      // 如果验证通过
      if (tmpState) {
        console.log("确认上报");
        let ids = [];
        this.selectRowList.forEach(el => {
          ids.push(el.id);
        });
        this.$http.put("/api/enroll/mbc/reported", ids).then(res => {
          if (res.data.code === 200) {
            this.$message.success("上报成功");
            this.loadTable();
          } else {
            this.$message.error(res.data.message);
          }
        });
      }
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.loadTable();
        this.yeartable();
      });
    }
  },
  filters: {}
};
</script>

<style lang="scss" scoped>
.specialList {
  padding-top: 7px;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  /deep/ .el-date-editor {
    margin-left: 10px;
  }

  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-select,
    .el-button {
      margin-left: 0px;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
}
</style>
