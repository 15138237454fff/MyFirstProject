<template>
  <div class="specialReport">
    <special-add v-if="id != 2"></special-add>
    <special-list v-if="id == 2"></special-list>
  </div>
</template>
<script>
import specialList from './components/specialList';
import specialAdd from './components/specialAdd';
export default {
  name: 'specialReport',
  data() {
    return {}
  },
  components: {
    'special-list': specialList,
    'special-add': specialAdd
  },
  computed: {
    id() {
      return this.$route.query.id
    }
  }
}
</script>
<style lang="scss" scoped>
.specialReport {
  width: 100%;
  overflow: hidden;
}
</style>


