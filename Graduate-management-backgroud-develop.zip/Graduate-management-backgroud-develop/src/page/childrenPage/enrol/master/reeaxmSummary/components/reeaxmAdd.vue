<template>
  <div class="reeaxmAdd">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          @click="passClick"
          v-if="!writeable && status == 3"
          >通过</el-button
        >
        <el-button
          type="danger"
          @click="backClick"
          v-if="!writeable && status == 3"
          >退回</el-button
        >
      </div>
    </div>
    <div class="filter">
      <div class="required">
        所属学院：
        <el-select
          v-model="specialForm.xydm"
          :disabled="!writeable"
          style="width:60%;"
        >
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div class="required">
        招生专业：
        <el-select
          v-model="specialForm.zydm"
          :disabled="!writeable"
          style="width:60%;"
          placeholder="请选择"
        >
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
    </div>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="2" class="table-one">
        <thead>
          <tr>
            <th colspan="8" class="required">专业分数线及复试权重</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>学习方式</th>
            <th>总分</th>
            <th>思想政治理论</th>
            <th>外国语</th>
            <th>业务课一</th>
            <th>业务课二</th>
            <th>备注</th>
            <th>复试权重</th>
          </tr>
          <tr>
            <td>全日制</td>
            <td>
              <el-input
                v-model="specialForm.qrz.zf"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.sxzzll"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.wgy"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.ywky"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.ywke"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-radio
                v-model="specialForm.qrz.bz"
                :disabled="!writeable"
                :label="1"
                >国家线</el-radio
              >
              <el-radio
                v-model="specialForm.qrz.bz"
                :disabled="!writeable"
                :label="2"
                >自划线</el-radio
              >
            </td>
            <td>
              <el-input v-model="specialForm.qrz.fsqz" :disabled="!writeable">
                <i slot="suffix" class="danwei">%</i>
              </el-input>
            </td>
          </tr>
          <tr>
            <td>非全日制</td>
            <td>
              <el-input
                v-model="specialForm.fqrz.zf"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.sxzzll"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.wgy"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.ywky"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.ywke"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-radio
                v-model="specialForm.fqrz.bz"
                :disabled="!writeable"
                :label="1"
                >国家线</el-radio
              >
              <el-radio
                v-model="specialForm.fqrz.bz"
                :disabled="!writeable"
                :label="2"
                >自划线</el-radio
              >
            </td>
            <td>
              <el-input v-model="specialForm.fqrz.fsqz" :disabled="!writeable">
                <i slot="suffix" class="danwei">%</i>
              </el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-two">
        <thead>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <th colspan="9"><span>|</span>研究方向复试分数线</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>方向代码</th>
            <th>研究方向</th>
            <th>学习方式</th>
            <th>总分</th>
            <th>思想政治理论</th>
            <th>外国语</th>
            <th>业务课一</th>
            <th>业务课二</th>
            <th>备注</th>
          </tr>
          <tr v-for="(item, index) of specialForm.yjfxfsfsx" :key="index">
            <td>{{ item.dm }}</td>
            <td>{{ item.mc }}</td>
            <td>{{ item.xxfs | xxfsFilter(0) }}</td>
            <td>
              <el-input v-model="item.zf" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.sxzzll" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.wgy" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.ywky" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.ywke" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-radio v-model="item.bz" :disabled="!writeable" :label="1"
                >国家线</el-radio
              >
              <el-radio v-model="item.bz" :disabled="!writeable" :label="2"
                >自划线</el-radio
              >
            </td>
          </tr>
        </tbody>
      </table>
      <el-dialog
        title="退回"
        :visible.sync="dialogVisible"
        width="380px"
        top="31vh"
      >
        <p>是否不通过该条记录？</p>
        <p class="required">请输入不通过原因：</p>
        <div>
          <textarea
            style="width:100%;height:60px;"
            v-model="comment"
          ></textarea>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="confirmBack">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
export default {
  name: "reeaxmAdd",
  data() {
    return {
      specialForm: {
        // 非全日制
        fqrz: {
          // 备注
          bz: "",
          // 复试权重
          fsqz: "",
          // 思想政治理论
          sxzzll: "",
          // 外国语
          wgy: "",
          // 业务课二
          ywke: "",
          // 业务课一
          ywky: "",
          // 总分
          zf: ""
        },
        // id
        id: "",
        // 全日制
        qrz: {
          // 备注
          bz: "",
          // 复试权重
          fsqz: "",
          // 思想政治理论
          sxzzll: "",
          // 外国语
          wgy: "",
          // 业务课二
          ywke: "",
          // 业务课一
          ywky: "",
          // 总分
          zf: ""
        },
        // 学院代码
        xydm: "",
        // 学院名称
        xymc: "",
        // 专业代码
        zydm: "",
        // 专业名称
        zymc: "",
        // 研究方向复试分数线
        yjfxfsfsx: [
          // {
          //   // 备注
          //   bz: "",
          //   // 方向代码
          //   dm: "",
          //   // 研究方向
          //   mc: "",
          //   // 思想政治理论
          //   sxzzll: "",
          //   // 外国语
          //   wgy: "",
          //   // 业务课二
          //   ywke: "",
          //   // 业务课一
          //   ywky: "",
          //   // 总分
          //   zf: ""
          // }
        ]
      },
      // //是否可写
      // writeable: true,
      // 审核状态
      status: "",
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 退回的原因
      comment: "",
      // 一键退回对话框可见性
      dialogVisible: false
    };
  },
  created() {
    // 请求学院专业信息
    this.requireXY();
    //如果是查看/修改页面
    if (this.id == 3) {
      // 回显数据
      this.dataBack();
    }
  },
  computed: {
    // 根据路由信息返回是否可写
    writeable() {
      console.log("writeable");
      if (this.$route.query.id != 3) {
        return true;
      } else {
        return false;
      }
    },
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  methods: {
    // 回显历史的申请记录
    dataBack() {
      this.$http.get(`/api/enroll/sirc/${this.specialId}`).then(res => {
        const data = res.data.data;
        console.log(data);
        //非空验证
        if (!data) {
          this.$message.error("获取历史上报记录失败，请重试");
          return;
        }
        // 保存请求获取的表单值
        Object.keys(this.specialForm).forEach(key => {
          this.specialForm[key] = data[key];
        });
        //保存审核状态
        this.status = data.zt;
      });
    },
    // 点击一键通过的出现对话框方法
    passClick() {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmPass,
        title: "通过",
        msgOne: "是否通过该条记录？",
        msgTwo: " "
      });
    },
    // 确认通过的方法
    confirmPass() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
      console.log("确认通过");
      this.$http
        .post("/api/enroll/sirac/audit", {
          ids: [this.specialId],
          comment: "",
          status: 1
        })
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("通过成功");
            //返回列表页
            this.$router.go(-1);
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    // 点击一键退回出现对话框的方法
    backClick() {
      // 清空意见
      this.comment = "";
      // 呼出对话框
      this.dialogVisible = true;
    },
    // 确认一键退回的方法
    confirmBack() {
      if (this.comment == "") return this.$message.error("请填写退回意见");
      // 关闭对话框
      this.dialogVisible = false;
      console.log("确认退回");
      this.$http
        .post("/api/enroll/sirac/audit", {
          ids: [this.specialId],
          comment: this.comment,
          status: 2
        })
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("退回成功");
            //返回列表页
            this.$router.go(-1);
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http
        .get("/api/system/dict/select/enroll/local/college")
        .then(res => {
          const data = res.data.data;
          //验证列表数据格式是否正确
          if (!Array.isArray(data)) {
            this.$message.error("获取学院和专业信息失败，请重试");
            return;
          }
          this.xyOptions = data;
          const tmp = this.xyOptions.filter(el => {
            return el.value === this.specialForm.xydm;
          });
          if (!tmp[0]) {
            return;
          }
          this.zyOptions = tmp[0].children;
        });
    }
  },
  watch: {
    "specialForm.xydm": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        this.specialForm.zydm = this.zyOptions[0].value;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.reeaxmAdd {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;

    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .filter {
    display: flex;
    font-size: 14px;
    padding-top: 20px;
    padding-left: 20px;
    div:last-child {
      margin-left: 20px;
    }
  }
  .box {
    // border: 1px solid rgba(228, 228, 228, 1);
    font-size: 14px;
    background-color: #fff;
    padding: 20px;
    margin-bottom: 0;
    min-height: 73vh;
    table {
      width: 100%;
      border: 1px solid rgba(228, 228, 228, 1);
      border-collapse: collapse;
      color: #333;
      table-layout: fixed;
      margin-bottom: 20px;
      thead th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        // border: 1px solid #e5e5e5;
        background: #e4e4e4;
        span {
          color: #1890ff;
          margin-right: 5px;
        }
      }
      tbody {
        th {
          background: #f2f2f2;
          padding: 11px 10px 11px 10px;
          border: 1px solid #e5e5e5;
        }
      }
      td {
        width: 200px;
        height: 40px;
        border: 1px solid #e5e5e5;
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        .el-radio {
          margin-right: 20px;
        }
        .el-radio:last-child {
          margin-right: 0;
        }
      }
      tr.first {
        td {
          width: 12%;
          height: 0px;
        }
        td:nth-child(2) {
          width: 19%;
        }
        td:last-child {
          width: 19%;
        }
      }
    }
    .danwei {
      line-height: 40px;
      margin-right: 5px;
      color: #ccc;
      font-style: normal;
    }
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
