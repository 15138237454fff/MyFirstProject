<template>
  <div class="specialList">
    <searchcomponment>
      <div slot="left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入专业代码/名称"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <!-- <el-select
          v-model="limitQuery.year"
          type="year"
          placeholder="选择年度"
          @change="loadTable"
          style="width:120px;"
          clearable
          filterable
        >
          <el-option
            v-for="(item, index) in yearOptions"
            :key="index"
            :label="item"
            :value="item"
          ></el-option>
        </el-select> -->
        <el-select
          v-model="limitQuery.college"
          style="width:150px;"
          @change="loadTable"
          
          filterable
        >
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="passClick"
          v-if="$btnAuthorityTest('reeaxmSummary:allPass')"
          >一键通过</el-button
        >
        <el-button
          type="danger"
          @click="backClick"
          v-if="$btnAuthorityTest('reeaxmSummary:allBack')"
          >一键退回</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      @selection-change="handleSelectionChange"
      :header-cell-style="$storage.tableHeaderColor"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="zydm" label="专业代码"></el-table-column>
      <el-table-column prop="zymc" label="专业名称"></el-table-column>
      <el-table-column prop="xymc" label="所属学院"></el-table-column>
      <el-table-column prop="xxxs" label="学习方式">
        <template slot-scope="scope">
          <span>{{ scope.row.xxxs | xxfsFilter(0) }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="zt" label="审核状态">
        <template slot-scope="scope">
          <span :class="scope.row.zt | zsZTFilter(1)">{{
            scope.row.zt | zsZTFilter(0)
          }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click="goDetail(scope.$index)"
            type="text"
            size="small"
            class="under-line"
            v-if="$btnAuthorityTest('reeaxmSummary:view')"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="newsCount"
      ref="block"
      :page.sync="limitQuery.pageNum"
      :limit.sync="limitQuery.pageSize"
      class="pagination-content"
      @pagination="loadTable"
    ></pagination>
    <el-dialog
      title="一键退回"
      :visible.sync="dialogVisible"
      width="380px"
      top="31vh"
    >
      <p>是否不通过所有已选记录？</p>
      <p class="required">请输入不通过原因：</p>
      <div>
        <textarea style="width:100%;height:60px;" v-model="comment"></textarea>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirmBack">确 定</el-button>
      </span>
    </el-dialog>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>

<script>
import pagination from "@/components/pagination";
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../../componments/timecommon";
export default {
  name: "specialList",
  components: {
    searchcomponment,
    pagination,
    timecommon
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // ID
          id: "",
          // 学习形式
          xxxs: "",
          // 学院代码
          xydm: "",
          // 学院名称
          xymc: "",
          // 状态 0:不通过 1：通过 2：退回 3：审核中 4：未提交
          zt: "",
          // 专业代码
          zydm: "",
          // 专业名称
          zymc: ""
        }
      ],
      // 分页查询的参数
      limitQuery: {
        // 学院代码
        college: "",
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: null
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 可选的年度列表
      yearOptions: [
        { label: "2019年", value: 2019 },
        { label: "2020年", value: 2020 }
      ],
      // 学院的待选列表
      xyOptions: [],
      // 勾选的列
      selectRowList: [],
      // 退回意见
      comment: "",
      // 一键退回对话框可见性
      dialogVisible: false,
      tableHeight: null
    };
  },
  created() {
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    // 获取可选学院列表
    this.requireXY();
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
  },
  watch: {
    $route(to) {
      if (to.name === "reeaxmSummary") {
        this.loadTable();
      }
    }
  },
  methods: {
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      console.log("正在请求列表数据");
      this.loading = true;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 2000);
      this.$http
        .post("/api/enroll/sirac/list", this.limitQuery)
        .then(res => {
          let data = res.data;
          this.loading = false;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          // console.log(data.info);
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 勾选一行时触发的事件处理函数
    handleSelectionChange(row) {
      this.selectRowList = row;
    },
    // 查看详情
    goDetail(index) {
      console.log(`正在前往查看第${index}条数据`);
      this.$router.push({
        path: "reeaxmSummary",
        query: { id: 3, specialId: this.tableData[index].id }
      });
    },
    // 点击一键通过的出现对话框方法
    passClick() {
      let tmpState = true;
      // 如果未勾选数据，验证不通过
      if (this.selectRowList.length === 0) {
        this.$message.error("请选择一条数据！");
        tmpState = false;
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmPass,
        title: "一键通过",
        msgOne: "是否通过所有已选记录？",
        msgTwo: " "
      });
    },
    // 确认通过的方法
    confirmPass() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
      console.log(this.selectRowList);
      // 临时的验证状态
      let tmpState = true;
      // 如果未勾选数据，验证不通过
      // 如果勾选了已通过/待审核的数据，验证不通过
      this.selectRowList.forEach(el => {
        // if (el.zt == 3) {
        //   this.$message.error("请勿删除审核中数据！");
        //   tmpState = false;
        //   return;
        // }
        if (el.zt == 1) {
          this.$message.error("不可重复审核!");
          tmpState = false;
          return;
        }
      });
      // 如果验证通过
      if (tmpState) {
        console.log("确认一键通过");
        let ids = [];
        this.selectRowList.forEach(el => {
          ids.push(el.id);
        });
        this.$http
          .post("/api/enroll/sirac/audit", { ids, comment: "", status: 1 })
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("通过成功");
              this.loadTable();
            } else {
              this.$message.error(res.data.message);
            }
          });
      }
    },
    // 点击一键退回出现对话框的方法
    backClick() {
      let tmpState = true;
      // console.log(this.selectRowList);
      // 如果未勾选数据，验证不通过
      if (this.selectRowList.length === 0) {
        this.$message.error("请选择一条数据！");
        tmpState = false;
        return;
      }
      // 清空意见
      this.comment = "";
      // 呼出对话框
      this.dialogVisible = true;
    },
    // 确认一键退回的方法
    confirmBack() {
      if (this.comment == "") return this.$message.error("请填写退回意见");
      // 关闭对话框
      this.dialogVisible = false;
      // 临时的验证状态
      let tmpState = true;
      // 如果勾选了已通过/待审核的数据，验证不通过
      this.selectRowList.forEach(el => {
        // console.log(el.zt);
        if (el.zt == 1) {
          this.$message.error("不可重复审核!");
          tmpState = false;
          return;
        }
      });
      // console.log(tmpState);
      // 如果验证通过
      if (tmpState) {
        const ids = [];
        this.selectRowList.forEach(el => {
          ids.push(el.id);
        });
        this.$http
          .post("/api/enroll/sirac/audit", {
            ids,
            comment: this.comment,
            status: 2
          })
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("退回成功");
              this.loadTable();
            } else {
              this.$message.error(res.data.message);
            }
          });
      }
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.yearOptions = res.data.data;
      });
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.loadTable();
      });
    },
    // 获取学院的可选列表
    requireXY() {
      this.$http.get("/api/system/dict/select/enroll/academy").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          return this.$message.error("获取学院和专业信息失败，请重试");
        }
        // 保存学院的待选列表
        this.xyOptions = data;
        this.xyOptions.unshift({
          label: "全部学院",
          value: null
        });
        // 取第一个学院为默认选中
        this.limitQuery.college = data[0].value;
      });
    }
  },
  filters: {}
};
</script>

<style lang="scss" scoped>
.specialList {
  padding-top: 7px;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  /deep/ .el-date-editor {
    margin-left: 10px;
  }

  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-select,
    .el-button {
      margin-left: 0px;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
