<template>
  <div class="examManage">
    <searchcomponment>
      <div slot="left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入科目代码/名称"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select
          v-model="limitQuery.genre"
          @change="loadTable"
          style="width:30%;"
          
          filterable
        >
          <el-option label="全部科目类型" :value="null"></el-option>
          <el-option
            v-for="(item, index) in kmOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="mtlxClick"
          v-if="$btnAuthorityTest('examManage:setclass')"
          >设置命题类别</el-button
        >
        <el-button
          type="primary"
          @click="kssjClick"
          v-if="$btnAuthorityTest('examManage:settime')"
          >设置考试时间</el-button
        >
        <el-dropdown
          @command="handleTags"
          v-if="$btnAuthorityTest('examManage:generate')"
        >
          <el-button type="primary" plain>
            打印科目小标签
            <i class="el-icon-arrow-down el-icon--right"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item
              v-for="(item, index) of kmOptions"
              :key="index"
              :value="item.value"
              :command="item.value"
              >{{ item.label }}</el-dropdown-item
            >
          </el-dropdown-menu>
        </el-dropdown>
        <el-button
          type="primary"
          plain
          @click="outputClick"
          v-if="$btnAuthorityTest('examManage:export')"
          >导出</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$storage.tableHeaderColor"
      :default-sort="{ prop: 'kmdm', order: 'ascending' }"
    >
      <el-table-column type="index" width="55" label="序号"></el-table-column>
      <el-table-column prop="kmdm" label="科目代码"></el-table-column>
      <el-table-column prop="kmmc" label="科目名称"></el-table-column>
      <el-table-column label="科目类别">
        <template slot-scope="scope">
          <span>{{ scope.row.kmlb | kmlbFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column label="命题类别">
        <template slot-scope="scope">
          <span v-if="scope.row.mtlx !== null">{{
            scope.row.mtlx === 1 ? "统考题" : "自主命题"
          }}</span>
        </template>
      </el-table-column>
      <el-table-column label="考试时间">
        <template slot-scope="scope">
          <span
            >{{ scope.row.ksrq }} {{ scope.row.jtkssj }}-{{
              scope.row.jtjssj
            }}</span
          >
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click="goModify(scope.row)"
            type="text"
            size="small"
            class="under-line"
            v-if="$btnAuthorityTest('examManage:update')"
            >修改</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <slot-dialog
      title="修改"
      ref="modifyDialog"
      :callback="confirmModify"
      btnName="保存"
      :widthpx="'550px'"
    >
      <div class="slot-box">
        <div>
          科目代码：
          <span>{{ modifyForm.kmdm }}</span>
        </div>
        <div>
          科目名称：
          <span>{{ modifyForm.kmmc }}</span>
        </div>
        <div>
          科目类别：
          <span>{{ modifyForm.kmlb | kmlbFilter }}</span>
        </div>
        <div>
          命题类别：
          <el-radio v-model="modifyForm.mtlx" :label="2">自主命题</el-radio>
          <el-radio v-model="modifyForm.mtlx" :label="1">统考题</el-radio>
        </div>
        <div>
          考试时间：
          <el-date-picker
            v-model="modifyForm.ksrq"
            type="date"
            placeholder="选择日期"
            style="width:150px;"
            format="yyyy.MM.dd"
          ></el-date-picker>
          <el-time-picker
            v-model="modifyForm.jtkssj"
            placeholder="开始"
            style="width:100px"
            format="HH:mm"
          >
          </el-time-picker>
          <span>至</span>
          <el-time-picker
            v-model="modifyForm.jtjssj"
            placeholder="结束"
            style="width:100px"
            format="HH:mm"
          >
          </el-time-picker>
        </div>
      </div>
    </slot-dialog>
    <slot-dialog
      title="设置命题类别"
      ref="mtlxDialog"
      :callback="confirmMTLX"
      btnName="确定"
      :widthpx="'450px'"
    >
      <table class="slot-mtlx">
        <tr>
          <th>科目类别</th>
          <th>命题类别</th>
        </tr>
        <tr v-for="(item, index) of kmOptions" :key="index">
          <td>{{ item.label }}</td>
          <td>
            <el-select v-model="mtlxForm[item.name]">
              <el-option label="自主命题" :value="2"></el-option>
              <el-option label="统考题" :value="1"></el-option>
            </el-select>
          </td>
        </tr>
      </table>
    </slot-dialog>
    <slot-dialog
      title="设置考试时间"
      ref="kssjDialog"
      :callback="confirmKSSJ"
      btnName="确定"
      :widthpx="'700px'"
    >
      <table class="slot-kssj">
        <tr>
          <th>科目类别</th>
          <th>考试时间</th>
        </tr>
        <tr v-for="(item, index) of kmOptions" :key="index">
          <td>{{ item.label }}</td>
          <td>
            <div>
              <el-date-picker
                v-model="kssjForm[item.name].ksrq"
                type="date"
                placeholder="选择日期"
                style="width:180px;"
                format="yyyy.MM.dd"
              ></el-date-picker>
              <el-time-picker
                v-model="kssjForm[item.name].jtkssj"
                placeholder="开始"
                style="width:120px"
                format="HH:mm"
              >
              </el-time-picker>
              <span>至</span>
              <el-time-picker
                v-model="kssjForm[item.name].jtjssj"
                placeholder="结束"
                style="width:120px"
                format="HH:mm"
              >
              </el-time-picker>
            </div>
          </td>
        </tr>
      </table>
    </slot-dialog>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>
<script>
import slotDialog from "@/components/skb/slotDialog";
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../componments/timecommon";
export default {
  name: "examManage",
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // ID integer($int32)
          id: "",
          // 具体时间 1:上午 2：下午 integer($int32)
          jtsj: "",
          // string
          // 科目代码
          kmdm: "",
          // 科目类别 1:政治思想理论 2：外国语 3：业务课一 4，业务课二 integer($int32)
          kmlb: "",
          // 科目名称 string
          kmmc: "",
          // 考试时间 string($date-time)
          ksrq: "",
          // 考试时间 string
          kssj: "",
          // 命题类型 1：统考题 2：自主命题 integer($int32)
          mtlx: ""
        }
      ],
      // 分页查询的参数
      limitQuery: {
        // 学院代码
        genre: null,
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: ""
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 科目的待选列表
      kmOptions: [
        { label: "思想政治理论", value: 1, name: "sxzzll" },
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywky" },
        { label: "业务课二", value: 4, name: "ywke" }
      ],
      // 待提交的修改表单
      modifyForm: {
        // ID
        id: "",
        // 具体时间 1:上午 2：下午
        jtsj: 1,
        // 科目代码
        kmdm: "",
        // 科目类别 1:政治思想理论 2：外国语 3：业务课一 4，业务课二
        kmlb: "",
        // 科目名称
        kmmc: "",
        // 考试时间
        ksrq: "",
        // 命题类型 1：统考题 2：自主命题
        mtlx: "",
        jtkssj: "",
        jtjssj: ""
      },
      // 待提交的设置命题类型表单
      mtlxForm: {
        // 思想政治理论
        sxzzll: 2,
        // 外国语
        wgy: 2,
        // 业务课二
        ywke: 1,
        // 业务课一
        ywky: 1
      },
      kssjForm: {
        // 思想政治理论
        sxzzll: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 外国语
        wgy: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课二
        ywke: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课一
        ywky: { jtkssj: "", jtjssj: "", ksrq: "" }
      },
      tableHeight: null,
      formpass: false,
      year: 2019
    };
  },
  components: {
    "slot-dialog": slotDialog,
    searchcomponment: searchcomponment,
    timecommon
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    // 获取当前的招生年度数据
    this.requireCurrentYear();
  },
  mounted() {
    this.loadTable();
  },
  watch: {
    $route(to) {
      if (to.name === "examManage") {
        this.requireCurrentYear();
        this.loadTable();
      }
    },
    formpass(val) {
      return val;
    }
  },
  methods: {
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      this.limitQuery.year = this.year;
      this.loading = true;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 2000);
      this.$http
        .post("/api/enroll/tsc/list", this.limitQuery)
        .then(res => {
          this.loading = false;
          let data = res.data;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          // console.log(data.info);
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 点击修改的出现对话框方法
    goModify(row) {
      // 呼出对话框
      this.$refs.modifyDialog.openDialog();
      // 根据当前科目数据显示修改详情
      Object.keys(this.modifyForm).forEach(key => {
        this.modifyForm[key] = row[key];
      });
      this.modifyForm.jtjssj = `${this.modifyForm.ksrq} ${this.modifyForm.jtjssj}:00`;
      this.modifyForm.jtkssj = `${this.modifyForm.ksrq} ${this.modifyForm.jtkssj}:00`;
    },
    // 确认修改
    confirmModify() {
      let tmpObj = { ...this.modifyForm };
      tmpObj.jtjssj = this.$tagTime(tmpObj.jtjssj, "HH:mm");
      tmpObj.jtkssj = this.$tagTime(tmpObj.jtkssj, "HH:mm");
      this.$http
        .put("/api/enroll/tsc", tmpObj)
        .then(res => {
          if (res.data.code == 200) {
            this.$message.success("修改成功");
            // 重新请求列表
            this.$refs.modifyDialog.dialogVisible = false;
            this.loadTable();
          } else {
            this.$message.error(res.data.message);
            this.$refs.modifyDialog.dialogVisible = true;
          }
        })
        .catch(err => {
          this.$message.error(err.response.data.message);
        });
      console.log(this.$refs.modifyDialog.dialogVisible);
    },
    // 点击设置命题类型的出现对话框方法
    mtlxClick() {
      console.log("点击设置命题类型");
      // 将下拉框设为默认值
      this.mtlxForm = {
        // 思想政治理论
        sxzzll: 1,
        // 外国语
        wgy: 1,
        // 业务课二
        ywke: 2,
        // 业务课一
        ywky: 2
      };
      // 呼出对话框
      this.$refs.mtlxDialog.openDialog();
    },
    // 确定设置命题类型
    confirmMTLX() {
      this.$http
        .put("/api/enroll/tsc/setup/thesis", this.mtlxForm)
        .then(res => {
          if (res.data.code == 200) {
            this.$refs.mtlxDialog.dialogVisible = false;
            this.$message.success("修改成功");
            // 重新请求列表
            this.loadTable();
          } else {
            this.$message.error(res.data.message);
            this.$refs.mtlxDialog.dialogVisible = true;
          }
        })
        .catch(err => {
          this.$message.error(err.response.data.message);
        });
    },
    // 点击设置考试时间的出现对话框方法
    kssjClick() {
      console.log("点击设置考试时间");
      // 将下拉框设为默认值
      this.kssjForm = {
        // 思想政治理论
        sxzzll: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 外国语
        wgy: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课二
        ywke: { jtkssj: "", jtjssj: "", ksrq: "" },
        // 业务课一
        ywky: { jtkssj: "", jtjssj: "", ksrq: "" }
      };
      // 呼出对话框
      this.$refs.kssjDialog.openDialog();
    },
    confirmKSSJ() {
      var flag = true;
      var keyValue = ["sxzzll", "wgy", "ywke", "ywky"];
      let tmpObj = this.kssjForm;
      keyValue.forEach(element => {
        if (flag) {
          if (
            !tmpObj[element].ksrq ||
            !tmpObj[element].jtjssj ||
            !tmpObj[element].jtkssj
          ) {
            this.$message.error("具体时间不能为空");
            flag = false;
          } else {
            tmpObj[element].ksrq = this.$tagTime(
              tmpObj[element].ksrq,
              "yyyy-MM-dd"
            );

            tmpObj[element].jtjssj = this.$tagTime(
              tmpObj[element].jtjssj,
              "HH:mm"
            );

            tmpObj[element].jtkssj = this.$tagTime(
              tmpObj[element].jtkssj,
              "HH:mm"
            );
          }
        }
      });
      if (flag) {
        this.$http
          .put("/api/enroll/tsc/setup/time", tmpObj)
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("修改成功");
              this.$refs.kssjDialog.dialogVisible = false;
              // 重新请求列表
              this.loadTable();
            } else {
              this.$message.error(res.data.message);
              this.$refs.kssjDialog.dialogVisible = true;
            }
          })
          .catch(err => {
            this.$message.error(err.response.data.message);
          });
      }
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.year = res.data.data;
      });
    },
    // 点击导出的方法
    outputClick() {
      window.location.href = "/api/enroll/tsc/export";
    },
    // 点击小标签导出的方法
    handleTags(val) {
      this.$http
        .get(`/api/enroll/tsc/export/check/${val}`)
        .then(res => {
          if (res.data.code === 200) {
            window.location.href = `/api/enroll/tsc/export/tag/${val}`;
          } else {
            this.$message.error(res.data.message);
          }
        })
        .catch(err => {
          this.$message.error(err.response.data.message);
        });
    }
  },
  filters: {
    // 过滤科目类别
    kmlbFilter(val) {
      switch (val) {
        case 1:
          return "思想政治理论";
        case 2:
          return "外国语";
        case 3:
          return "业务课一";
        case 4:
          return "业务课二";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.examManage {
  padding-top: 7px;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button,
    .el-select {
      margin-left: 0px;
    }
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
