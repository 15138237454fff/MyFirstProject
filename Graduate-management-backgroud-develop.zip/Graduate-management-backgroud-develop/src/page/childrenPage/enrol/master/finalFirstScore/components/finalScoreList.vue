<template>
  <div class="finalScoreList">
    <div class="header">
      <div class="header-left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考生编号/姓名"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select v-model="limitQuery.bkxy" @change="loadTable">
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.bkzy" @change="loadTable">
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div class="header-right">
        <el-button
          @click="outputClick"
          type="primary"
          plain
          v-if="$btnAuthorityTest('finalFirstScore:export')"
          >导出</el-button
        >
        <el-upload
          action="/api/enroll/masterResult/uploadFile"
          :show-file-list="false"
          style="display:inline-block;"
          :on-success="handleUpload"
          :on-error="handleError"
          :headers="headers"
          v-if="$btnAuthorityTest('finalFirstScore:import')"
        >
          <el-button type="primary" plain>导入</el-button>
        </el-upload>
        <el-button
          @click="fsmenu"
          type="primary"
          plain
          v-if="$btnAuthorityTest('finalFirstScore:preview')"
          >复试名单预测</el-button
        >
        <el-button
          @click="clickGenerateList"
          type="primary"
          plain
          v-if="$btnAuthorityTest('finalFirstScore:generate')"
          >生成成绩清单</el-button
        >
      </div>
    </div>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      v-if="kemuRequireFinish"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      style="width: 100%;"
      :height="tableHeight"
      ref="tableList"
      @filter-change="filterHandler"
      :header-cell-style="$storage.tableHeaderColor"
      :default-sort="{ prop: 'ksbh', order: 'ascending' }"
    >
      <el-table-column prop="ksbh" label="考生编号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="bkxy" label="报考学院"></el-table-column>
      <el-table-column prop="bkzy" label="报考专业"></el-table-column>
      <el-table-column prop="xxfs" label="学习方式">
        <template slot-scope="scope">
          {{ scope.row.xxfs | xxfs }}
        </template>
      </el-table-column>
      <el-table-column
        prop="zzll"
        label="思想政治理论"
        column-key="zzllm"
        :filters="
          zzllOptions.map(el => {
            return { text: el.label, value: el.value };
          })
        "
        :filter-multiple="false"
      >
      </el-table-column>
      <el-table-column
        prop="wgy"
        label="外国语"
        column-key="wgym"
        :filters="
          wgyOptions.map(el => {
            return { text: el.label, value: el.value };
          })
        "
        :filter-multiple="false"
      >
      </el-table-column>
      <el-table-column
        prop="ywk1"
        label="业务课一"
        column-key="ywk1m"
        :filters="
          ywk1Options.map(el => {
            return { text: el.label, value: el.value };
          })
        "
        :filter-multiple="false"
      >
      </el-table-column>
      <el-table-column
        prop="ywk2"
        label="业务课二"
        column-key="ywk2m"
        :filters="
          ywk2Options.map(el => {
            return { text: el.label, value: el.value };
          })
        "
        :filter-multiple="false"
      >
      </el-table-column>
      <el-table-column prop="zf" label="初试总分"></el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 20, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="limitQuery.year"></timecommon>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <el-form ref="form" :model="modalOption" label-width="120px">
          <el-form-item label="科目类别：">
            <el-select v-model="modalOption.kmlb" @change="handleKmlbChange">
              <el-option :value="null" label="全部科目类别"></el-option>
              <el-option
                v-for="(item, index) in kmOptions"
                :key="index"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="考试科目：">
            <el-select v-model="modalOption.kskm">
              <el-option :value="null" label="全部考试科目"></el-option>
              <el-option
                v-for="(item, index) in ksOptions"
                :key="index"
                :label="item.kmmc"
                :value="item.kmdm"
              ></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <p slot="footer">
        <el-button size="small" type="primary" @click="clickOk">导出</el-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import timecommon from "../../../componments/timecommon";
import myModal from "@/components/skb/myModal";
export default {
  name: "finalScoreList",
  data() {
    return {
      headers: {
        userToken: this.$stores.state.token
      },
      // 表格展示的数据
      tableData: [
        {
          // 报考学院
          bkxy: "",
          // 报考专业
          bkzy: "",
          // 初试总分
          cszf: "",
          // 考生编号
          ksbh: "",
          // 外国语分
          wgy: "",
          // 考生姓名
          xm: "",
          // 学习方式
          xxfs: "",
          // 业务课一分
          ywk1: "",
          // 业务课二分
          ywk2: "",
          // 政治理论分
          zzll: ""
        }
      ],
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      kmOptions: [
        { label: "思想政治理论", value: 1, name: "sxzzll" },
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywke" },
        { label: "业务课二", value: 4, name: "ywky" }
      ],
      ksOptions: [],
      zzllOptions: [],
      wgyOptions: [],
      ywk1Options: [],
      ywk2Options: [],
      // 分页查询的参数
      limitQuery: {
        // 报考学院
        bkxy: "",
        // 报考专业
        bkzy: "",
        query: "",
        pageSize: 15,
        pageNum: 1,
        xslb: "0",
        fszt: "0",
        year: null,
        wgym: null,
        zzllm: null,
        ywk1m: null,
        ywk2m: null
      },
      kemuRequireFinish: false,
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      tableHeight: null,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-finalScoreList",
        kmlb: null,
        kskm: null
      }
    };
  },
  components: {
    timecommon,
    "my-modal": myModal
  },
  filters: {
    xxfs(val) {
      var key = val.toString();
      switch (key) {
        case "1":
          return "全日制";
          break;
        case "2":
          return "非全日制";
          break;
        case "1,2":
          return "全日制,非全日制";
          break;
        default:
          break;
      }
    }
  },
  created() {
    this.requireKemu();
    this.requireKSKM(null);
    // 获取当前的招生年度数据
    this.requireCurrentYear();
    // 请求学院专业信息
    this.requireXY();
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 290;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 290;
      })();
    };
  },
  methods: {
    filterHandler(row) {
      let keys = Object.keys(row);
      console.log(keys);
      keys.map(key => {
        if (row[key].length !== 0) {
          this.limitQuery[key] = row[key][0];
        } else {
          this.limitQuery[key] = null;
        }
      });
      this.loadTable();
    },
    handleKmlbChange() {
      this.modalOption.kskm = null;
      this.requireKSKM(this.modalOption.kmlb);
    },
    clickGenerateList() {
      this.modalOption.kmlb = null;
      this.modalOption.kskm = null;
      this.modalOption.title = `生成成绩清单`;
      this.modalOption.modalVisiabal = true;
    },
    requireKemu() {
      this.$http
        .get("/api/enroll/masterResult/kemuTree")
        .then(res => {
          let data = res.data;
          this.kemuRequireFinish = true;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          data = data.data;
          console.log(data.zzlls);
          if (Array.isArray(data.zzlls)) {
            this.zzllOptions = data.zzlls;
          } else {
            this.zzllOptions = [];
          }
          if (Array.isArray(data.wgys)) {
            this.wgyOptions = data.wgys;
          } else {
            this.wgyOptions = [];
          }
          if (Array.isArray(data.ywk1s)) {
            this.ywk1Options = data.ywk1s;
          } else {
            this.ywk1Options = [];
          }
          if (Array.isArray(data.ywk2s)) {
            this.ywk2Options = data.ywk2s;
          } else {
            this.ywk2Options = [];
          }
          console.log(this.zzllOptions);
        })
        .catch(err => {
          console.log(err.message);
        });
    },
    requireKSKM(kmlb) {
      this.$http
        .post("/api/enroll/masterResult/getTree", { kmlb })
        .then(res => {
          const data = res.data.data;
          // 验证消息格式
          // 保存新的考试科目可选列表
          this.ksOptions = data;
          // 重置考试科目的所选值
          this.limitQuery.kskm = null;
        });
    },
    // 导入按钮事件
    handleUpload(res) {
      console.log(res);
      if (res.code !== 200) {
        this.$message.error(res.message);
      } else {
        if (res.data === -1) {
          let str = res.message;
          this.$message({
            type: "error",
            dangerouslyUseHTMLString: true,
            message: str.replace(/,/g, "<br />").replace(/#/g, "<br />")
          });
          return;
        }
        this.$message.success("导入成功");
        this.loadTable();
      }
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 点击对话框的确定
    clickOk() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      this.handleOutPutScoreList();
    },
    handleOutPutScoreList() {
      console.log("生成成绩清单");
      let { kmlb, kskm } = this.modalOption;
      window.location.href = `/api/enroll/masterResult/export/resultList/${kmlb}/${kskm}`;
    },
    // 导入出错
    handleError(err) {
      console.log(err);
      this.$message.error("导入失败，请重试");
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 导出
    outputClick() {
      console.log("导出");
      window.location = `/api/enroll/masterResult/export`;
    },
    // 导出
    inputClick() {
      console.log("导入");
    },
    // 复试名单预测
    fsmenu() {
      this.$emit("finalfa", true);
    },
    // 请求列表数据的方法
    loadTable() {
      console.log("正在请求列表数据");
      this.loading = true;
      // setTimeout(() => {
      //   this.loading = false;
      // }, 2000);
      this.$http
        .post("/api/enroll/masterResult/checkEnd", this.limitQuery)
        .then(res => {
          this.loading = false;
          let data = res.data;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          // console.log(data.info);
          this.tableData = data.list;
          this.newsCount = data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },

    // 获取学院和专业的可选列表
    requireXY() {
      this.$http.get("/api/system/dict/select/enroll/college").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        }
        // 保存学院的待选列表
        this.xyOptions = data;
        // 取第一个学院为默认选中
        this.limitQuery.bkxy = data[0].value;
        // 取出可选的专业待选列表
        this.zyOptions = this.xyOptions[0].children;
      });
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.loadTable();
      });
    }
  },
  watch: {
    $route(to) {
      if (to.name === "finalFirstScore") {
        this.loadTable();
      }
    },
    "limitQuery.bkxy": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        this.limitQuery.bkzy = this.zyOptions[0].value;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.finalScoreList {
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .header {
    height: 50px;
    display: flex;
    .header-left {
      flex: 3;
      .el-select {
        width: 140px;
      }
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 2;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button,
    .el-select {
      margin-left: 0px;
    }
  }
  .el-table /deep/ {
    .cell::before {
      content: "";
      display: table;
    }
    .el-select {
      display: inline-block;
      margin-top: 8px;
      padding: 0;
    }
    .el-input__icon {
      line-height: 38px;
    }
    .el-input--suffix .el-input__inner {
      padding: 0 20px 0 10px;
    }
    .el-input.el-input--suffix {
      right: 0px;
      padding: 0 5px;
    }
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    padding: 0;
  }
  /deep/ .el-table td {
    padding: 0 !important;
    height: 50px;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
<style lang="scss">
.modal-finalScoreList {
  width: 380px !important;
  .el-dialog__body {
    padding-top: 28px !important;
  }
}
</style>
