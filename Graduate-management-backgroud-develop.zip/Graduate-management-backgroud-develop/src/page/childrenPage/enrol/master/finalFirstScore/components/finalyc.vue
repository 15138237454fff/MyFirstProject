<template>
  <div class="finalyc">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="go">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="savebut">生成复试名单</el-button>
      </div>
    </div>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column prop="zydm" label="学院"> </el-table-column>
      <el-table-column prop="zymc" label="专业"> </el-table-column>
      <el-table-column label="学习方式" prop="xxfs">
        <template slot-scope="scope">
          <span> {{ scope.row.xxfs | xxfs }} </span>
        </template>
      </el-table-column>
      <el-table-column label="思想政治理论">
        <template slot-scope="scope">
          <el-input
            v-model.number="scope.row.zzll"
            type="number"
            @keyup.enter.native="loadTable(scope.row)"
          ></el-input>
        </template>
      </el-table-column>
      <el-table-column label="外国语">
        <template slot-scope="scope">
          <el-input
            v-model.number="scope.row.wgy"
            type="number"
            @keyup.enter.native="loadTable(scope.row)"
          ></el-input>
        </template>
      </el-table-column>
      <el-table-column label="业务课一">
        <template slot-scope="scope">
          <el-input
            v-model.number="scope.row.ywk1"
            type="number"
            @keyup.enter.native="loadTable(scope.row)"
          ></el-input>
        </template>
      </el-table-column>
      <el-table-column label="业务课二">
        <template slot-scope="scope">
          <el-input
            v-model.number="scope.row.ywk2"
            type="number"
            @keyup.enter.native="loadTable(scope.row)"
          ></el-input>
        </template>
      </el-table-column>
      <el-table-column label="初试总分">
        <template slot-scope="scope">
          <el-input
            v-model.number="scope.row.zf"
            type="number"
            @keyup.enter.native="loadTable(scope.row)"
          ></el-input>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total="total"
      ref="block"
      v-if="pageshow"
      :page.sync="listQuery.queryPage.pageNum"
      :limit.sync="listQuery.queryPage.pageSize"
      class="pagination-content"
      @pagination="takeList"
    ></pagination>
    <el-dialog title="复试名单预测总人数" :visible.sync="list" width="700px">
      <span style="margin-right:65px;">复试名单预测总人数：{{ yczs }}人</span
      ><span>过线总人数：{{ sxzs }}人</span>
      <el-table
        :data="dialogtableData"
        border
        ref="multipleTable"
        style="width: 100%;margin-top:15px"
        :header-cell-style="$storage.tableHeaderColor"
        height="500px"
      >
        <el-table-column prop="xymc" label="学院"> </el-table-column>
        <el-table-column prop="zymc" label="专业"> </el-table-column>
        <el-table-column label="学习方式">
          <template slot-scope="scope">
            <span> {{ scope.row.xxfs | xxfs }} </span>
          </template>
        </el-table-column>
        <el-table-column prop="sxrs" label="上线人数"> </el-table-column>
      </el-table>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage4"
        :page-sizes="[15, 20, 50, 100]"
        :page-size="pagesize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total1"
      >
      </el-pagination>
      <span slot="footer" class="dialog-footer">
        <div class="dialog-footers" style="text-align: center;">
          <el-button type="primary" @click="passsubmit">导出</el-button>
        </div>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
export default {
  components: {
    pagination
  },
  name: "finalyc",
  filters: {
    xxfs(val) {
      var key = val.toString();
      switch (key) {
        case "1":
        case "全日制":
          return "全日制";
          break;
        case "2":
        case "非全日制":
          return "非全日制";
          break;
        case "1,2":
        case "全日制,非全日制":
          return "全日制,非全日制";
          break;
        default:
          break;
      }
    }
  },
  data() {
    return {
      sxzs: 0,
      yczs: 0,
      tableData: [],
      tableHeight: null,
      loading2: false,
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      total: 0,
      pageshow: true,
      currentPage4: 1,
      total1: 0,
      pagesize: 10,
      list: false,
      dialogtableData: []
    };
  },
  methods: {
    loadTable(row) {
      this.$http.post("api/enroll/masterPredict/update", row).then(res => {
        if (res.data.data == 0) {
          this.$message.error("添加失败");
        } else {
          this.freshtakeList();
        }
        console.log(res);
      });
    },
    savebut() {
      this.list = true;
      this.dialist();
    },
    go() {
      this.$emit("finalfa", false);
    },
    passsubmit() {
      window.location.href = "/api/enroll/masterPredict/export";
    },
    handleSizeChange(val) {
      this.pagesize = val;
      this.dialist();
    },
    handleCurrentChange(val) {
      this.currentPage4 = val;
      this.dialist();
    },
    dialist() {
      this.$http
        .post("api/enroll/masterPredict/fsList", {
          pageNum: this.currentPage4,
          pageSize: this.pagesize
        })
        .then(res => {
          this.dialogtableData = res.data.data.voList.list;
          this.total1 = res.data.data.voList.total;
          this.sxzs = res.data.data.sxzs;
          this.yczs = res.data.data.yczs;
        });
    },
    takeList() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterPredict/list", {
          pageNum: params.pageNum,
          pageSize: params.pageSize
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    },
    freshtakeList() {
      this.loading2 = true;
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterPredict/queryList", {
          pageNum: params.pageNum,
          pageSize: params.pageSize
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.takeList();
  }
};
</script>
<style lang="scss" scoped>
.finalyc {
  width: 100%;
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;

    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .dialog-footers {
    text-align: center;
  }
}
</style>
