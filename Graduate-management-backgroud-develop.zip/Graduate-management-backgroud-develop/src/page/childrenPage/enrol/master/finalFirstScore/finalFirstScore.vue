<template>
  <div class="finalFirstScore">
    <template v-if="!finalycshow">
      <div class="tabs">
        <el-tabs v-model="activeName">
          <el-tab-pane label="成绩校验" name="first"></el-tab-pane>
          <el-tab-pane label="最终成绩" name="second"></el-tab-pane>
        </el-tabs>
      </div>
      <score-check-list v-if="activeName==='first'"></score-check-list>
      <final-score-list v-if="activeName==='second'" :final="finalycshow" @finalfa="finalfamed"></final-score-list>
    </template>
    <finalyc v-else-if="finalycshow" @finalfa="finalfamed"></finalyc>
  </div>
</template>
<script>
import finalScoreList from './components/finalScoreList';
import scoreCheckList from './components/scoreCheckList';
import finalyc from './components/finalyc';
export default {
  name: 'finalFirstScore',
  components: {
    'final-score-list': finalScoreList,
    'score-check-list': scoreCheckList,
    finalyc: finalyc
  },
  data() {
    return {
      activeName: 'first',
      finalycshow: false
    }
  },
  methods: {
    finalfamed(val) {
      this.finalycshow = val
    }
  }
}
</script>
<style lang="scss" scoped>
.finalFirstScore {
  width: 100%;
}
.tabs {
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
}
</style>

