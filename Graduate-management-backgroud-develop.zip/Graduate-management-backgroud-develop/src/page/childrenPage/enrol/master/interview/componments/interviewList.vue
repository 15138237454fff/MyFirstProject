<template>
  <div class="perFormance">
    <template>
      <div class="container">
        <div class="left">
          <el-form :inline="true" :model="formInline" class="demo-form-inline">
            <el-form-item>
              <el-input
                v-model="formInline.user"
                placeholder="请输入考生编号/姓名"
                suffix-icon="el-icon-search"
                clearable
                @clear="clearinput"
              ></el-input>
            </el-form-item>
            <el-form-item>
              <el-button @click="searchBtn">查询</el-button>
            </el-form-item>
            <el-form-item>
              <el-select
                v-model="formInline.school"
                filterable
                placeholder="全部学院"
                @change="collegeChange"
                
              >
                <el-option
                  v-for="item in collegeList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-select
                v-model="formInline.zy"
                filterable
                placeholder="全部专业"
                
                @change="selectchange"
              >
                <el-option
                  v-for="item in zyList"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
        </div>
        <div class="right">
          <el-button
            @click="classyz"
            style="border-color:rgba(24, 144, 255, 1);color:rgba(24, 144, 255, 1);"
            v-if="$btnAuthorityTest('interviewTable:test')"
            >成绩过线校验</el-button
          >
          <el-button
            @click="onSubmitBtn"
            type="primary"
            v-if="$btnAuthorityTest('interviewTable:submit')"
            >提交</el-button
          >
        </div>
      </div>
      <div class="table">
        <el-table
          :data="tableData"
          border
          ref="multipleTable"
          style="width: 100%"
          :row-class-name="tableRowClassName"
          :header-cell-style="$storage.tableHeaderColor"
          :height="tableHeight"
          v-loading="loading2"
          element-loading-text="加载中"
          @selection-change="handleSelectionChange"
          @row-click="clickRow"
          @select-all="allClick"
        >
          <el-table-column type="selection" width="55"> </el-table-column>
          <el-table-column label="考生编号" width="150">
            <template slot-scope="scope">
              <!-- <img src="https://axure-file.lanhuapp.com/e936b784-0261-48f8-818f-545d09424aaa__7ab73f678a5fc8a11bebec7159a8cc4e" style="width:21px;height:21px" v-if="scope.row.isactive"> -->
              <span>{{ scope.row.ksbh }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="xm" label="姓名"> </el-table-column>
          <el-table-column prop="bkxy" label="报考学院"> </el-table-column>
          <el-table-column prop="bkzy" label="报考专业"> </el-table-column>
          <el-table-column prop="xxfs" label="学习方式">
            <template slot-scope="scope">
              {{ scope.row.xxfs | xxfs }}
            </template>
          </el-table-column>
          <el-table-column prop="zzll" label="思想政治理论"> </el-table-column>
          <el-table-column prop="wgy" label="外国语"> </el-table-column>
          <el-table-column prop="ywk1" label="业务课一"> </el-table-column>
          <el-table-column prop="ywk2" label="业务课二"> </el-table-column>
          <el-table-column label="初试总分">
            <template slot-scope="scope">
              <!-- <input v-focus v-model="scope.row.zf" placeholder="请输入内容" @keyup.enter="onSubmit(scope.$index)" :id="'fouce'+scope.$index" :ref="'fouce'+scope.$index" class="input" v-if="scope.row.isactive"> -->
              {{ scope.row.zf }}
            </template>
          </el-table-column>
        </el-table>
        <!-- https://www.jianshu.com/p/cd03674e92b1 -->
        <pagination
          :total="total"
          :page.sync="listQuery.queryPage.pageNum"
          :limit.sync="listQuery.queryPage.pageSize"
          class="pagination-content"
          @pagination="tableList"
        ></pagination>
        <timecommon :year="formInline.class"></timecommon>
      </div>
    </template>
  </div>
</template>
<script>
import pagination from "@/components/pagination";
import timecommon from "../../../componments/timecommon";
export default {
  name: "perFormance",
  data() {
    return {
      formInline: {
        user: "", // 请输入考生编号/姓名
        school: "", // 全部学院
        zy: "", // 全部专业
        class: 2019 // 年级
      },
      schoolList: [],
      zyList: [],
      classList: [],
      tableData: [],
      loading2: false,
      total: 0,
      isactive: false,
      gradeList: [], // 年份筛选
      collegeList: [], // 学院
      listQuery: {
        // 获取审计列表传参集合
        queryPage: {
          pageNum: 1, // 当前页
          pageSize: 15 // 每页显示条数
        }
      },
      tableHeight: null,
      multipleSelection: []
    };
  },
  filters: {
    xxfs(val) {
      var key = val.toString();
      switch (key) {
        case "1":
          return "全日制";
          break;
        case "2":
          return "非全日制";
          break;
        case "1,2":
          return "全日制,非全日制";
          break;
        default:
          break;
      }
    }
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    this.requireCurrentYear();

    this.selectList();
  },
  directives: {
    focus: {
      // 指令的定义
      inserted: function(el) {
        document.getElementById("fouce0").focus();
      }
    }
  },
  methods: {
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.formInline.class = res.data.data;
        this.tableList();
      });
    },
    fresh() {
      this.tableList();
      this.listQuery.queryPage.pageNum = 1;
    },
    clearinput() {
      this.formInline.user = "";
      this.fresh();
    },
    searchBtn() {
      this.fresh();
    },
    selectchange() {
      this.fresh();
    },
    collegeChange(val) {
      const temp = this.collegeList.find(item => {
        return item.value === val;
      });
      this.major = "";
      this.zyList = temp.children;
      this.fresh();
    },
    tableRowClassName({ row, rowIndex }) {
      if (row.isactive) {
        return "warning-row";
      }
      return "";
    },
    classyz() {
      this.$http.post("api/enroll/masterResultFs/checkResult", {}).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: res.data.message,
            type: "success"
          });
          this.fresh();
        } else {
          this.$message({
            message: "成绩校验异常",
            type: "error"
          });
        }
      });
      // this.tableData.forEach(el => {
      //   console.log(el);
      //   if (el.state == 0) {
      //     el.isactive = true;
      //   }
      //   // this.$set(el, isactive, false);
      // });
    },
    uploadForm() {},
    onSubmit(index) {
      const fouce = `fouce${index + 1}`;
      console.log(this.tableData.length);
      if (index === this.tableData.length - 1) {
        this.$message({
          message: "下面没有填写了,请从第一个开始",
          type: "error"
        });
        document.getElementById("fouce0").focus();
      } else {
        document.getElementById(fouce).focus();
      }

      //   this.$router.push("/perFormance/alias2");
    },
    // 提交
    onSubmitBtn() {
      this.multipleSelection.length == 0
        ? this.$message({
            message: "请勾选数据再提交",
            type: "error"
          })
        : this.$http
            .post(`api/enroll/masterResultFs/updateFsStatus`, {
              ids: this.multipleSelection,
              xslb: "0",
              zt: "0"
            })
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: res.data.message,
                  type: "success"
                });
                this.fresh();
              } else {
                this.$message({
                  message: "提交出现异常",
                  type: "error"
                });
              }
            });
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    },
    handleSizeChange() {},
    handleCurrentChange() {},
    handleSelectionChange(rows) {
      this.multipleSelection = [];
      if (rows) {
        rows.forEach(row => {
          this.multipleSelection.push(row.id);
        });
      }
    },
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    allClick() {},
    selectList() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.gradeList = res.data.data;
      });
      this.$http.get("api/system/dict/select/enroll/college").then(res => {
        this.collegeList = res.data.data; // 学院
        this.zyList = this.collegeList[0].children; // 专业
      });
    },
    tableList() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false; // 动画
      // }, 1000);
      const params = {};
      params.pageNum = this.listQuery.queryPage.pageNum; // 当前页
      params.pageSize = this.listQuery.queryPage.pageSize; // 每页显示条数
      // 对分页进行相关操作的判断
      arguments[0]
        ? ((params.pageSize = arguments[0].limit),
          (params.pageNum = arguments[0].page))
        : params;
      this.$http
        .post("api/enroll/masterResultFs/list", {
          bkxy: this.formInline.school,
          bkzy: this.formInline.zy,
          fszt: "0",
          nf: this.formInline.class,
          pageNum: params.pageNum,
          pageSize: params.pageSize,
          query: this.formInline.user,
          xslb: "0"
        })
        .then(res => {
          this.loading2 = false;
          if (res.data.code == 400) {
            this.$message({
              message: "数据异常,请刷新",
              type: "error"
            });
          } else {
            this.tableData = res.data.data.list; // 表格数据
            this.total = res.data.data.total; // 总条数
            this.tableData.forEach(el => {
              this.$set(el, "isactive", false);
            });
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    }
  },
  components: {
    pagination,
    timecommon
  },
  watch: {
    //    this.$stores.getters.Height
    // $route(to) {
    //   if (to.path === "/perFormance/alias2") {
    //     this.loadTable();
    //     this.paramsForm.isOpen = 1;
    //   }
    // }
  }
};
</script>
<style lang="scss" scoped>
.perFormance {
  width: 100%;
  position: relative;
  .container {
    display: flex;
    height: 48px; /* 48/16 */
    .left {
      flex: 2;
    }
    .right {
      flex: 1;
      text-align: right;
    }
    .demo-form-inline {
      height: 48px;
    }
  }
  .table {
    width: 100%;
  }
}
</style>
<style>
.el-table .warning-row {
  background: #f9d8d8;
  color: #ff0000;
}

.el-table .success-row {
  background: #f9d8d8;
  color: #ff0000;
}
.input {
  -webkit-appearance: none;
  background-color: #fff;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: inherit;
  height: 40px;
  line-height: 40px;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  width: 100%;
}
</style>
