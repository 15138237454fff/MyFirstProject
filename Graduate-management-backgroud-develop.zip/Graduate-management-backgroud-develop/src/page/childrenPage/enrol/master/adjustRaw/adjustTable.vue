<template>
  <div class="adjustTable">
    <adjustxq v-if="this.$route.path =='/adjustTable/adjustxq'"></adjustxq>
    <template v-else>
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="待确认名单" name="first"></el-tab-pane>
          <el-tab-pane label="已确认名单" name="second"></el-tab-pane>
        </el-tabs>
      </div>
      <adjustList v-if="activeName=='first'"></adjustList>
      <adjustRow v-if="activeName=='second'"></adjustRow>
    </template>
  </div>
</template>
<script>
import adjustList from './componments/adjustList';
import adjustRow from './componments/adjustRow';
import adjustxq from './componments/adjustxq';
export default {
  name: 'adjustTable',
  components: {
    adjustList: adjustList,
    adjustRow: adjustRow,
    adjustxq: adjustxq
  },
  data() {
    return {
      activeName: 'first'
    }
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    }
  }
}
</script>
<style scoped lang="scss">
.addmissProposed {
  width: 100%;
}
.tabs {
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
}
</style>