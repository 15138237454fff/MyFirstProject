<template>
  <div class="specialAdd">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          @click="passClick"
          v-if="!writeable && status == 3"
          >通过</el-button
        >
        <el-button
          type="danger"
          @click="backClick"
          v-if="!writeable && status == 3"
          >退回</el-button
        >
      </div>
    </div>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="2" class="table-one">
        <tbody>
          <th colspan="6"><span>|</span> 招生专业信息</th>
          <tr>
            <td class="required">学院名称</td>
            <td colspan="5">
              <el-select
                v-model="specialForm.xydm"
                :disabled="!writeable"
                style="width:50%;"
              >
                <el-option
                  v-for="(item, index) in xyOptions"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="required">专业名称</td>
            <td colspan="5">
              <el-select
                v-model="specialForm.zydm"
                :disabled="!writeable"
                style="width:50%;"
                placeholder="请选择"
              >
                <el-option
                  v-for="(item, index) in zyOptions"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="required">学习形式</td>
            <td colspan="5">
              <el-checkbox-group
                v-model="specialForm.xxxs"
                :disabled="!writeable"
              >
                <el-checkbox :label="1">全日制</el-checkbox>
                <el-checkbox :label="2">非全日制</el-checkbox>
              </el-checkbox-group>
            </td>
          </tr>
          <tr>
            <td>研究方向</td>
            <td colspan="5">
              <div
                v-for="(item, index) of specialForm.yjfx"
                :key="index"
                class="yjfx-row"
              >
                <el-input
                  v-model="item.dm"
                  placeholder="请输入方向代码"
                  :disabled="!writeable"
                ></el-input>
                <el-input
                  v-model="item.mc"
                  placeholder="请输入方向名称"
                  :disabled="!writeable"
                ></el-input>
                <el-select
                  v-model="item.xxfs"
                  style="margin-left:5px"
                  :disabled="!writeable"
                >
                  <el-option label="全日制" value="1"> </el-option>
                  <el-option label="非全日制" value="2"> </el-option>
                </el-select>
                <el-button
                  icon="el-icon-circle-plus"
                  @click="addYjfx"
                  class="add"
                  v-if="writeable && index === 0"
                ></el-button>
                <el-button
                  icon="el-icon-remove"
                  @click="removeYjfx(index)"
                  class="add"
                  v-if="writeable && index !== 0"
                ></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>联系人</td>
            <td colspan="5">
              <el-input
                placeholder="请输入"
                v-model="specialForm.lxr"
                style="width:50%;"
                :disabled="!writeable"
              ></el-input>
            </td>
          </tr>
          <tr>
            <td>联系方式</td>
            <td colspan="5">
              <el-input
                placeholder="请输入"
                v-model="specialForm.lxfs"
                style="width:50%;"
                :disabled="!writeable"
              ></el-input>
            </td>
          </tr>
          <tr>
            <td>学位点简介</td>
            <td colspan="5">
              <el-input
                placeholder="请输入"
                v-model="specialForm.xwdjj"
                type="textarea"
                :rows="3"
                :disabled="!writeable"
              ></el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-two">
        <tbody>
          <th colspan="6"><span>|</span>拟招生人数</th>
          <tr>
            <td class="required">全日制人数</td>
            <td>
              <el-input
                type="number"
                style="width:87px"
                :min="0"
                v-model="specialForm.qrzrs"
                :disabled="!writeable"
              >
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
            <td class="required">非全日制人数</td>
            <td>
              <el-input
                type="number"
                style="width:87px"
                :min="0"
                v-model="specialForm.fqrzrs"
                :disabled="!writeable"
              >
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
          </tr>
          <tr>
            <td class="required">港澳台招生</td>
            <td>
              <el-switch
                v-model="specialForm.sfgatzs"
                active-text="是"
                :active-value="1"
                inactive-text="否"
                :inactive-value="0"
                class="my-switch"
                :disabled="!writeable"
              ></el-switch>
              <el-input
                type="number"
                style="width:87px"
                :min="0"
                v-model="specialForm.gatzsrs"
                v-if="specialForm.sfgatzs"
                :disabled="!writeable"
              >
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
            <td class="required">推免生招生</td>
            <td>
              <el-switch
                v-model="specialForm.sftmszs"
                active-text="是"
                :active-value="1"
                inactive-text="否"
                :inactive-value="0"
                class="my-switch"
                :disabled="!writeable"
              ></el-switch>
              <el-input
                type="number"
                style="width:87px"
                :min="0"
                v-model="specialForm.tmsrs"
                v-if="specialForm.sftmszs"
                :disabled="!writeable"
              >
                <i slot="suffix" class="danwei">人</i>
              </el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-three">
        <tbody>
          <th colspan="6"><span>|</span>初试考试科目</th>
          <tr class="td-header">
            <td>科目类别</td>
            <td>科目代码</td>
            <td>科目名称</td>
          </tr>
          <tr>
            <td>思想政治理论</td>
            <td>
              <div v-for="(item, index) of specialForm.sxzzll" :key="index">
                <el-input
                  v-model="item.dm"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
              </div>
            </td>
            <td>
              <div
                class="mc"
                placeholder="请输入"
                v-for="(item, index) of specialForm.sxzzll"
                :key="index"
              >
                <el-input
                  v-model="item.mc"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
                <el-button
                  icon="el-icon-circle-plus"
                  @click="addSxzzll"
                  class="add"
                  v-if="writeable && index === 0"
                ></el-button>
                <el-button
                  icon="el-icon-remove"
                  @click="removeSxzzll(index)"
                  class="add"
                  v-if="writeable && index !== 0"
                ></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>外国语</td>
            <td>
              <div v-for="(item, index) of specialForm.wgy" :key="index">
                <el-input
                  v-model="item.dm"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
              </div>
            </td>
            <td>
              <div
                class="mc"
                placeholder="请输入"
                v-for="(item, index) of specialForm.wgy"
                :key="index"
              >
                <el-input
                  v-model="item.mc"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
                <el-button
                  icon="el-icon-circle-plus"
                  @click="addWgy"
                  class="add"
                  v-if="writeable && index === 0"
                ></el-button>
                <el-button
                  icon="el-icon-remove"
                  @click="removeWgy(index)"
                  class="add"
                  v-if="writeable && index !== 0"
                ></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>业务课一</td>
            <td>
              <div v-for="(item, index) of specialForm.ywky" :key="index">
                <el-input
                  v-model="item.dm"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
              </div>
            </td>
            <td>
              <div
                class="mc"
                placeholder="请输入"
                v-for="(item, index) of specialForm.ywky"
                :key="index"
              >
                <el-input
                  v-model="item.mc"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
                <el-button
                  icon="el-icon-circle-plus"
                  @click="addYwky"
                  class="add"
                  v-if="writeable && index === 0"
                ></el-button>
                <el-button
                  icon="el-icon-remove"
                  @click="removeYwky(index)"
                  class="add"
                  v-if="writeable && index !== 0"
                ></el-button>
              </div>
            </td>
          </tr>
          <tr>
            <td>业务课二</td>
            <td>
              <div v-for="(item, index) of specialForm.ywke" :key="index">
                <el-input
                  v-model="item.dm"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
              </div>
            </td>
            <td>
              <div
                class="mc"
                placeholder="请输入"
                v-for="(item, index) of specialForm.ywke"
                :key="index"
              >
                <el-input
                  v-model="item.mc"
                  placeholder="请输入"
                  :disabled="!writeable"
                ></el-input>
                <el-button
                  icon="el-icon-circle-plus"
                  @click="addYwke"
                  class="add"
                  v-if="writeable && index === 0"
                ></el-button>
                <el-button
                  icon="el-icon-remove"
                  @click="removeYwke(index)"
                  class="add"
                  v-if="writeable && index !== 0"
                ></el-button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-four">
        <tbody>
          <tr>
            <td>复试科目及参考书</td>
            <td colspan="5">
              <el-input
                placeholder="请输入"
                v-model="specialForm.fskmjcks"
                type="textarea"
                :rows="3"
                :disabled="!writeable"
              ></el-input>
            </td>
          </tr>
          <tr>
            <td>同等学力加试科目及参考书</td>
            <td colspan="5">
              <el-input
                placeholder="请输入"
                v-model="specialForm.tdlxjskmjcks"
                type="textarea"
                :rows="3"
                :disabled="!writeable"
              ></el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <el-dialog
        title="退回"
        :visible.sync="dialogVisible"
        width="380px"
        top="31vh"
      >
        <p>是否不通过该条记录？</p>
        <p class="required">请输入不通过原因：</p>
        <div>
          <textarea
            style="width:100%;height:60px;"
            v-model="comment"
          ></textarea>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="confirmBack">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
export default {
  name: "specialAdd",
  data() {
    return {
      specialForm: {
        // 学习形式
        xxxs: [],
        // 研究方向
        yjfx: [{ dm: "", mc: "", xxfs: "" }],
        // 非全日制人数
        fqrzrs: 0,
        // 复试科目及参考书
        fskmjcks: "",
        // 港澳台招生人数
        gatzsrs: 0,
        // 联系方式
        lxfs: "",
        // 联系人
        lxr: "",
        // 全日制人数
        qrzrs: 0,
        // 是否港澳台招生
        sfgatzs: 0,
        // 是否推免生招生
        sftmszs: 0,
        // 思想政治理论
        sxzzll: [{ dm: "", mc: "" }],
        // 外国语
        wgy: [{ dm: "", mc: "" }],
        // 业务课一
        ywky: [{ dm: "", mc: "" }],
        // 业务课二
        ywke: [{ dm: "", mc: "" }],
        // 同等学力加试科目及参考书
        tdlxjskmjcks: "",
        // 推免生人数
        tmsrs: 0,
        // 学位点简介
        xwdjj: "",
        // 学院代码
        xydm: "",
        // 专业代码
        zydm: ""
      },
      // //是否可写
      // writeable: true,
      // 审核状态
      status: "",
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 退回的原因
      comment: "",
      // 一键退回对话框可见性
      dialogVisible: false
    };
  },

  created() {
    // 请求学院专业信息
    this.requireXY();
    //如果是查看页面
    if (this.id == 3) {
      console.log(123123);
      //回显数据
      this.dataBack();
    }
  },
  computed: {
    // 根据路由信息返回是否可写
    writeable() {
      if (this.$route.query.id != 3) {
        return true;
      } else {
        return false;
      }
    },
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  methods: {
    // 回显历史的申请记录
    dataBack() {
      this.$http.get(`/api/enroll/mbc/${this.specialId}`).then(res => {
        const data = res.data.data;
        console.log(data);
        //非空验证
        if (!data) {
          this.$message.error("获取历史上报记录失败，请重试");
          return;
        }
        // 保存请求获取的表单值
        Object.keys(this.specialForm).forEach(key => {
          this.specialForm[key] = data[key];
        });
        //保存审核状态
        this.status = data.zt;
      });
    },
    // 点击一键通过的出现对话框方法
    passClick() {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmPass,
        title: "通过",
        msgOne: "是否通过该条记录？",
        msgTwo: " "
      });
    },
    // 确认通过的方法
    confirmPass() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });

      console.log("确认通过");
      this.$http
        .post("/api/enroll/mbac/audit", {
          ids: [this.specialId],
          comment: "",
          status: 1
        })
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("通过成功");
            //返回列表页
            this.$router.go(-1);
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    // 点击一键退回出现对话框的方法
    backClick() {
      // 清空意见
      this.comment = "";
      // 呼出对话框
      this.dialogVisible = true;
    },
    // 确认一键退回的方法
    confirmBack() {
      if (this.comment === "") {
        this.$message.error("请填写审核意见");
        return;
      }
      // 关闭对话框
      this.dialogVisible = false;
      console.log("确认退回");
      this.$http
        .post("/api/enroll/mbac/audit", {
          ids: [this.specialId],
          comment: this.comment,
          status: 2
        })
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("退回成功");
            // 返回列表页
            this.$router.go(-1);
          } else {
            this.$message.error(res.data.message);
          }
        });
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http
        .get("/api/system/dict/select/enroll/local/college")
        .then(res => {
          const data = res.data.data;
          //验证列表数据格式是否正确
          if (!Array.isArray(data)) {
            this.$message.error("获取学院和专业信息失败，请重试");
            return;
          }
          // 保存学院的待选列表
          this.xyOptions = data;
          const tmp = this.xyOptions.filter(el => {
            return el.value === this.specialForm.xydm;
          });
          if (!tmp[0]) {
            return;
          }
          this.zyOptions = tmp[0].children;
        });
    }
  },
  watch: {
    "specialForm.xydm": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        console.log(this.zyOptions);
        this.specialForm.zydm = this.zyOptions[0].value;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.specialAdd {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;

    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .box {
    // border: 1px solid rgba(228, 228, 228, 1);
    font-size: 14px;
    background-color: #fff;
    padding: 20px;
    margin-top: 10px;
    margin-bottom: 0;
    min-height: 73vh;
    table {
      width: 100%;
      border: 1px solid rgba(228, 228, 228, 1);
      border-collapse: collapse;
      color: #333;
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
      }
      td {
        width: 200px;
        height: 40px;
        border: 1px solid #e5e5e5;
      }
    }
    .table-one {
      td {
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
          text-align: center;
        }
        &:nth-child(even) {
          text-align: left;
          background: #fafafa;
        }
        .el-checkbox-group {
          padding-left: 20px;
        }
      }
    }
    .table-two {
      margin-top: 20px;
      td {
        text-align: center;
        position: relative;
      }
      /deep/ .my-switch {
        position: absolute;
        top: 50%;
        left: 50%;
        margin-left: -90px;
        margin-top: -10px;
        .el-switch__label {
          position: absolute;
          display: none;
          color: #fff;
        }
        .el-switch__label--left {
          z-index: 9;
          left: 20px;
        }
        .el-switch__label--right {
          z-index: 9;
          left: -4px;
        }
        .el-switch__label.is-active {
          display: block;
        }
        .el-switch .el-switch__core,
        .el-switch .el-switch__label {
          width: 50px !important;
        }
      }
    }
    .table-three {
      margin-top: 20px;
      td {
        text-align: center;
      }
      .td-header {
        background: #f0f2f5;
      }
    }
    .table-four {
      margin-top: 20px;
      td:nth-child(odd) {
        background: #f2f2f2;
        text-align: center;
      }
      .td-header {
        background: #f0f2f5;
      }
    }
    .add {
      &.el-button {
        padding: 0 10px;
      }
      font-size: 24px;
      color: #1e6fd9;
      border-radius: 50%;
      padding-left: 10px;
      background: #fff;
      outline: none;
      border: none;
    }
    .yjfx-row {
      width: 60%;
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      align-items: center;
      .el-input:first-child {
        flex: 1;
      }
      .el-input:nth-child(2) {
        flex: 2;
        margin-left: 5px;
      }
    }
    .danwei {
      line-height: 40px;
      margin-right: 5px;
      color: #ccc;
      font-style: normal;
    }
    .mc {
      width: 100%;
      display: flex;
      flex-wrap: nowrap;
      align-items: center;
    }
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
