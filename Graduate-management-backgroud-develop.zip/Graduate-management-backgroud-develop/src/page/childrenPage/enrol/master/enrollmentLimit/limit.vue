<template>
  <div class="limit">
    <searchcomponment>
      <div slot="left">
        <el-input
          v-model="formInline.user"
          placeholder="请输入学院代码/名称"
          suffix-icon="el-icon-search"
          clearable
          style="width:200px"
          @clear="clearinput"
        ></el-input>
        <el-button @click="onSubmit">查询</el-button>
        <!-- <el-select
          v-model="formInline.year"
          type="year"
          placeholder="选择年度"
          @change="fresh"
          style="width:120px"
        >
          <el-option
            v-for="(item, index) in yearOptions"
            :key="index"
            :label="item"
            :value="item"
          ></el-option>
        </el-select> -->
      </div>
      <div slot="right">
        <el-button
          plain
          @click="onSave('0')"
          :disabled="isshow"
          v-if="$btnAuthorityTest('limit:save')"
          >保存</el-button
        >
        <el-button
          type="primary"
          @click="onSave('1')"
          :disabled="isshow"
          v-if="$btnAuthorityTest('limit:submit')"
          >提交</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="tableData"
      border
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
      v-loading="loading2"
      element-loading-text="加载中"
    >
      <el-table-column prop="xydm" label="学院代码"> </el-table-column>
      <el-table-column prop="xymc" label="学院名称"> </el-table-column>
      <el-table-column label="全日制招生名额">
        <template slot-scope="scope">
          <!-- <el-input
            placeholder="请输入内容"
            v-model.number="scope.row.qrzme"
            clearable
            type="number"
            v-if="scope.row.status == '0'"
          >
          </el-input> -->
          <el-input-number
            v-model="scope.row.qrzme"
            controls-position="right"
            placeholder="请输入内容"
            :min="1"
            :precision="0"
            v-if="scope.row.status == '0'"
          ></el-input-number>
          <span v-else>{{ scope.row.qrzme }}</span>
        </template>
      </el-table-column>
      <el-table-column label="非全日制招生名额">
        <template slot-scope="scope">
          <!-- <el-input
            placeholder="请输入内容"
            v-model.number="scope.row.fqrzme"
            clearable
            type="number"
            v-if="scope.row.status == '0'">
          </el-input>
           -->
          <el-input-number
            v-model="scope.row.fqrzme"
            controls-position="right"
            placeholder="请输入内容"
            :min="1"
            :precision="0"
            v-if="scope.row.status == '0'"
          ></el-input-number>
          <span v-else>{{ scope.row.fqrzme }}</span>
        </template>
      </el-table-column>
    </el-table>
    <timecommon :year="formInline.year"></timecommon>
  </div>
</template>
<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../componments/timecommon";
export default {
  name: "limit",
  data() {
    return {
      formInline: {
        user: "",
        year: 2019
      },
      loading2: false,
      tableHeight: null,
      tableData: [],
      // 可选的年度列表
      yearOptions: [
        { label: "2019年", value: 2019 },
        { label: "2020年", value: 2020 }
      ],
      isshow: false
    };
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 230;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 230;
      })();
    };
    this.requireCurrentYear();
  },
  methods: {
    clearinput() {
      this.formInline.user = "";
      this.fresh();
    },
    onSubmit() {
      this.fresh();
    },
    fresh() {
      this.loadTable();
    },
    onSave(val) {
      var tableData = [...this.tableData];
      var formsubmit = [];
      var flag = true;

      tableData.forEach(Element => {
        if (val == "1") {
          if (flag) {
            if (!Element.fqrzme && !Element.qrzme) {
              this.$message.error("请填写完整在提交");
              flag = false;
            }
          }
        }
        formsubmit.push({
          id: Element.id,
          fqrzme: Element.fqrzme,
          qrzme: Element.qrzme,
          status: val
        });
      });
      if (flag) {
        this.$http
          .post("api/enroll/masterPlaces/updates", { placesDtos: formsubmit })
          .then(res => {
            if (res.data.code == 200) {
              this.$message.success(res.data.message);
              this.fresh();
            }
          });
      }
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.yearOptions = res.data.data;
      });
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.formInline.year = res.data.data;
        this.loadTable();
      });
    },
    loadTable() {
      this.loading2 = true;
      // setTimeout(() => {
      //   this.loading2 = false;
      // }, 1000);
      this.$http
        .post("api/enroll/masterPlaces/list", {
          query: this.formInline.user,
          nf: this.formInline.year
        })
        .then(res => {
          this.loading2 = false;
          this.tableData = res.data.data;
          if (this.tableData.length == 0) {
            this.isshow = true;
          }
          if (this.tableData.length > 0) {
            if (this.tableData[0].status == "1") {
              this.isshow = true;
            } else {
              this.isshow = false;
            }
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loading2 = false;
        });
    } // 查看校区列表
  },
  computed: {},
  components: {
    searchcomponment: searchcomponment,
    timecommon
  }
};
</script>
<style lang="scss" scoped>
.limit {
  width: 100%;
  padding-top: 7px;
  .bg-purple-light {
    text-align: right;
  }
  .demo-form-inline {
    height: 56px !important;
  }
}
</style>
