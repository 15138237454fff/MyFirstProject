<template>
  <div class="stuInfoDetail">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
    </div>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="2">
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 考生基本信息
          </th>

          <tr>
            <td>
              <div>
                考生姓名：
                <span>{{stuInfoForm.xm}}</span>
              </div>
            </td>
            <td>
              <div>
                报名点代码：
                <span>{{stuInfoForm.bmddm}}</span>
              </div>
            </td>
            <td>
              <div>
                考生报名号：
                <span>{{stuInfoForm.bmh}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                考生姓名拼音：
                <span>{{stuInfoForm.xmpy}}</span>
              </div>
            </td>
            <td>
              <div>
                考生编号：
                <span>{{stuInfoForm.ksbh}}</span>
              </div>
            </td>
            <td>
              <div>
                证件类型：
                <span>{{stuInfoForm.zjlx|zjlxFilter}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                证件号码：
                <span>{{stuInfoForm.zjhm}}</span>
              </div>
            </td>
            <td>
              <div>
                出生日期：
                <span>{{stuInfoForm.csrq}}</span>
              </div>
            </td>
            <td>
              <div>
                性别码：
                <span>{{stuInfoForm.xbm | sexFilter}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                婚姻状况：
                <span>{{stuInfoForm.hfm|hfmFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                现役军人码：
                <span>{{stuInfoForm.xyjrm|xyjrmFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                政治面貌码：
                <span>{{stuInfoForm.zzmmm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                籍贯所在地码：
                <span>{{stuInfoForm.jgszdm}}</span>
              </div>
            </td>
            <td>
              <div>
                出生地码：
                <span>{{stuInfoForm.csdm}}</span>
              </div>
            </td>
            <td>
              <div>
                户口所在地码：
                <span>{{stuInfoForm.hkszdm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                考生档案所在地码：
                <span>{{stuInfoForm.daszdm}}</span>
              </div>
            </td>
            <td colspan="2">
              <div>
                考生档案所在单位：
                <span>{{stuInfoForm.daszdw}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                考生档案所在单位地址：
                <span>{{stuInfoForm.daszdwdz}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                现在学习或工作单位：
                <span>{{stuInfoForm.xxgzdw}}</span>
              </div>
            </td>
            <td>
              <div>
                考生作弊情况：
                <span>{{stuInfoForm.kszbqk}}</span>
              </div>
            </td>
            <td>
              <div>
                考生档案所在单位邮政编码：
                <span>{{stuInfoForm.daszdwyzbm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                户口所在地详细地址：
                <span>{{stuInfoForm.hkszdxxdz}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                家庭主要成员：
                <div v-html="textChange(stuInfoForm.jtcy)"></div>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                学习与工作经历：
                <div v-html="textChange(stuInfoForm.xxgzjl)"></div>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                何时何地何原因受过何种奖励或处分：
                <span>{{stuInfoForm.jlcf}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table>
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 考生联系方式
          </th>
          <tr>
            <td>
              <div>
                考生通讯地址：
                <span>{{stuInfoForm.txdz}}</span>
              </div>
            </td>
            <td>
              <div>
                考生通讯地址邮政编码：
                <span>{{stuInfoForm.yzbm}}</span>
              </div>
            </td>
            <td>
              <div>
                固定电话：
                <span>{{stuInfoForm.lxdh}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                移动电话：
                <span>{{stuInfoForm.yddh}}</span>
              </div>
            </td>
            <td colspan="2">
              <div>
                电子邮箱：
                <span>{{stuInfoForm.dzxx}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table>
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 考生来源以及毕业信息
          </th>
          <tr>
            <td>
              <div>
                考生来源码：
                <span>{{stuInfoForm.masterStudentBkInfo.kslym|kslymFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                毕业学校代码：
                <span>{{stuInfoForm.masterStudentBkInfo.bydwm}}</span>
              </div>
            </td>
            <td>
              <div>
                毕业学校名称：
                <span>{{stuInfoForm.masterStudentBkInfo.bydw}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                毕业专业代码：
                <span>{{stuInfoForm.masterStudentBkInfo.byzydm}}</span>
              </div>
            </td>
            <td>
              <div>
                毕业专业名称：
                <span>{{stuInfoForm.masterStudentBkInfo.byzymc}}</span>
              </div>
            </td>
            <td>
              <div>
                取得最后学历的学习形式：
                <span>{{stuInfoForm.masterStudentBkInfo.xxxs|xxxsFilter}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                最后学历码：
                <span>{{stuInfoForm.masterStudentBkInfo.xlm|xlmFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                毕业证书编号：
                <span>{{stuInfoForm.masterStudentBkInfo.xlzsbh}}</span>
              </div>
            </td>
            <td>
              <div>
                获得最后学历毕业年月：
                <span>{{stuInfoForm.masterStudentBkInfo.byny}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                注册学号：
                <span>{{stuInfoForm.masterStudentBkInfo.zcxh}}</span>
              </div>
            </td>
            <td>
              <div>
                最后学位码：
                <span>{{stuInfoForm.masterStudentBkInfo.xwm|xwmFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                学位证书编号：
                <span>{{stuInfoForm.masterStudentBkInfo.xwzsbh}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table>
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 退役大学生士兵计划信息
          </th>
          <tr>
            <td>
              <div>
                入伍前所在高校入学年月：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqrxny}}</span>
              </div>
            </td>
            <td>
              <div>
                入伍前所在高校所在省市码：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqgxssm}}</span>
              </div>
            </td>
            <td>
              <div>
                入伍前所在高校码：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqgxdm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                入伍前所在高校名称：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqgxmc}}</span>
              </div>
            </td>
            <td>
              <div>
                入伍前所在高校学习形式：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqxxxs}}</span>
              </div>
            </td>
            <td>
              <div>
                入伍前所在高校学习专业代码
                <span>{{stuInfoForm.masterStudentSbInfo.rwqzydm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                批准入伍年月：
                <span>{{stuInfoForm.masterStudentSbInfo.rwny}}</span>
              </div>
            </td>
            <td colspan="2">
              <div>
                批准退役年月：
                <span>{{stuInfoForm.masterStudentSbInfo.tyny}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                入伍前所在高校学习专业名称：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqzymc}}</span>
              </div>
            </td>
            <td colspan="2">
              <div>
                入伍前所在高校毕业证书编号：
                <span>{{stuInfoForm.masterStudentSbInfo.rwqxlzsbh}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                批准入伍机关名称：
                <span>{{stuInfoForm.masterStudentSbInfo.rwpzdw}}</span>
              </div>
            </td>
            <td colspan="2">
              <div>
                入伍批准书编号：
                <span>{{stuInfoForm.masterStudentSbInfo.rwpzsbh}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                批准退役机关名称：
                <span>{{stuInfoForm.masterStudentSbInfo.typzdw}}</span>
              </div>
            </td>
            <td colspan="2">
              <div>
                退出现役编号：
                <span>{{stuInfoForm.masterStudentSbInfo.tcxyzbh}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table>
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 考生报考信息
          </th>
          <tr>
            <td>
              <div>
                报考单位代码：
                <span>{{stuInfoForm.masterStudentBkInfo.bkdwdm}}</span>
              </div>
            </td>
            <td>
              <div>
                报考专业代码：
                <span>{{stuInfoForm.masterStudentBkInfo.bkzydm}}</span>
              </div>
            </td>
            <td>
              <div>
                考试方式码：
                <span>{{stuInfoForm.masterStudentBkInfo.ksfsm|ksfsmFilter}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                专项计划：
                <span>{{stuInfoForm.masterStudentBkInfo.zxjh|zxjhFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                报考类别码：
                <span>{{stuInfoForm.masterStudentBkInfo.bklbm|bklbmFilter}}</span>
              </div>
            </td>
            <td>
              <div>
                定向就业单位所在地码：
                <span>{{stuInfoForm.masterStudentBkInfo.dxwpdwszdm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                定向就业单位：
                <span>{{stuInfoForm.masterStudentBkInfo.dxwpdw}}</span>
              </div>
            </td>
            <td>
              <div>
                报考院系所码：
                <span>{{stuInfoForm.masterStudentBkInfo.bkyxsm}}</span>
              </div>
            </td>
            <td>
              <div>
                学习方式：
                <span>{{stuInfoForm.masterStudentBkInfo.bkxxfs | bkxxfs}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                研究方向码：
                <span>{{stuInfoForm.masterStudentBkInfo.yjfxm}}</span>
              </div>
            </td>
            <td>
              <div>
                政治理论码：
                <span>{{stuInfoForm.masterStudentBkInfo.zzllm}}</span>
              </div>
            </td>
            <td>
              <div>
                政治理论名称：
                <span>{{stuInfoForm.masterStudentBkInfo.zzllmc}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                外国语码：
                <span>{{stuInfoForm.masterStudentBkInfo.wgym}}</span>
              </div>
            </td>
            <td>
              <div>
                外国语名称：
                <span>{{stuInfoForm.masterStudentBkInfo.wgymc}}</span>
              </div>
            </td>
            <td>
              <div>
                业务课一码：
                <span>{{stuInfoForm.masterStudentBkInfo.ywk1m}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                业务课一名称：
                <span>{{stuInfoForm.masterStudentBkInfo.ywk1mc}}</span>
              </div>
            </td>
            <td>
              <div>
                业务课二码：
                <span>{{stuInfoForm.masterStudentBkInfo.ywk2m}}</span>
              </div>
            </td>
            <td>
              <div>
                业务课二名称：
                <span>{{stuInfoForm.masterStudentBkInfo.ywk2mc}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table>
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 备用信息
          </th>
          <tr>
            <td>
              <div>
                备用信息：
                <span>{{stuInfoForm.byxx}}</span>
              </div>
            </td>
            <td>
              <div>
                备用信息1：
                <span>{{stuInfoForm.byxx1}}</span>
              </div>
            </td>
            <td>
              <div>
                报考点说明：
                <span>{{stuInfoForm.bkdsm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                招生单位说明：
                <span>{{stuInfoForm.zsdwsm}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                备用信息2：
                <span>{{stuInfoForm.byxx2}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <table>
        <tbody>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <th colspan="6">
            <span>|</span> 网报系统附加字段
          </th>
          <tr>
            <td>
              <div>
                毕业学校所在省市代码：
                <span>{{stuInfoForm.masterStudentBkInfo.bydwssm}}</span>
              </div>
            </td>
            <td>
              <div>
                跨专业信息：
                <span>{{stuInfoForm.masterStudentBkInfo.kzyxx}}</span>
              </div>
            </td>
            <td>
              <div>
                交费标志：
                <span>{{stuInfoForm.masterStudentBkInfo.jfbz}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                照相标志：
                <span>{{stuInfoForm.masterStudentBkInfo.zxbz}}</span>
              </div>
            </td>
            <td>
              <div>
                报名时间：
                <span>{{stuInfoForm.masterStudentBkInfo.bmsj}}</span>
              </div>
            </td>
            <td>
              <div>
                修改时间：
                <span>{{stuInfoForm.masterStudentBkInfo.xgsj}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td>
              <div>
                确认时间：
                <span>{{stuInfoForm.masterStudentBkInfo.qrsj}}</span>
              </div>
            </td>
            <td>
              <div>
                取消时间：
                <span>{{stuInfoForm.masterStudentBkInfo.qxsj}}</span>
              </div>
            </td>
            <td>
              <div>
                是否有效：
                <span>{{stuInfoForm.sfyx | sfyx}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colspan="3">
              <div>
                备用信息：
                <span>{{stuInfoForm.byxx3}}</span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
export default {
  name: "stuInfoDetail",
  data() {
    return {
      stuInfoForm: {
        bkdsm: "",
        bmddm: "",
        bmh: "",
        byxx: "",
        byxx1: "",
        byxx2: "",
        byxx3: "",
        cjsj: "",
        csdm: "",
        csrq: "",
        daszdm: "",
        daszdw: "",
        daszdwdz: "",
        daszdwyzbm: "",
        dzxx: "",
        hfm: "",
        hkszdm: "",
        hkszdxxdz: "",
        id: "",
        jgszdm: "",
        jlcf: "",
        jtcy: "",
        ksbh: "",
        ksbkxxm: "",
        kstyzbxxm: "",
        kszbqk: "",
        lxdh: "",
        masterStudentBkInfo: {},
        masterStudentSbInfo: {},
        mzm: "",
        nf: "",
        sfyx: "",
        txdz: "",
        xbm: "",
        xm: "",
        xmpy: "",
        xslb: "",
        xxgzdw: "",
        xxgzjl: "",
        xyjrm: "",
        yddh: "",
        yzbm: "",
        zjhm: "",
        zjlx: "",
        zsdwsm: "",
        zzmmm: ""
      }
    };
  },

  created() {
    // 如果是查看页面
    if (this.id == 3) {
      // 回显数据
      this.dataBack();
    }
  },
  computed: {
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  filters: {
    sfyx(val) {
      switch (val) {
        case "1":
          return "是";
        case "0":
          return "否";
        default:
          break;
      }
    },
    // 证件类型
    zjlxFilter(val) {
      switch (val) {
        case "01":
          return "居民身份证";
        case "03":
          return "港澳台身份证";
        case "04":
          return "华侨身份证件";
        default:
          return " ";
      }
    },
    // 婚姻状况
    hfmFilter(val) {
      switch (val) {
        case "1":
          return "未婚";
        case "2":
          return "已婚";
        case "3":
          return "丧偶";
        case "4":
          return "离婚";
        case "9":
          return "其他";
        default:
          return " ";
      }
    },
    // 现役军人
    xyjrmFilter(val) {
      switch (val) {
        case "1":
          return "军队在职干部";
        case "2":
          return "军校应届本科毕业生";
        case "3":
          return "国防生";
        case "0":
          return "非军人";
        default:
          return " ";
      }
    },
    // 考生来源码
    kslymFilter(val) {
      switch (val) {
        case "1":
          return "科学研究人员";
        case "2":
          return "高等教育教师";
        case "3":
          return "中等教育教师";
        case "4":
          return "其他在职人员";
        case "5":
          return "普通全日制应届本科毕业生";
        case "6":
          return "成人应届本科毕业生";
        case "7":
          return "其他人员";
        default:
          return " ";
      }
    },
    // 取得最后学历的学习形式
    xxxsFilter(val) {
      switch (val) {
        case "1":
          return "普通全日制";
        case "2":
          return "成人教育";
        case "3":
          return "自学考试";
        case "4":
          return "网络教育";
        case "5":
          return "获境外学历或学位证书者";
        case "6":
          return "其他";
        default:
          return " ";
      }
    },
    // 最后学历
    xlmFilter(val) {
      switch (val) {
        case "1":
          return "研究生";
        case "2":
          return "本科毕业";
        case "3":
          return "本科结业";
        case "4":
          return "高职高专";
        default:
          return " ";
      }
    },
    // 最后学位
    xwmFilter(val) {
      switch (val) {
        case "1":
          return "博士学位";
        case "2":
          return "硕士学位";
        case "3":
          return "学士学位";
        case "4":
          return "无";
        default:
          return " ";
      }
    },
    // 考试方式
    ksfsmFilter(val) {
      switch (val) {
        case "21":
          return "全国统考";
        case "23":
          return "单独考试";
        case "25":
          return "管理类联考";
        case "26":
          return "法硕联考";
        case "27":
          return "强军计划";
        case "28":
          return "援藏计划";
        default:
          return " ";
      }
    },
    // 专项计划
    zxjhFilter(val) {
      switch (val) {
        case "1":
          return "强军计划";
        case "2":
          return "援藏计划";
        case "4":
          return "少数民族骨干计划";
        case "7":
          return "退役大学生计划";
        case "0":
          return "无专项计划";
        default:
          return " ";
      }
    },
    // 报考类别
    bklbmFilter(val) {
      switch (val) {
        case "11":
          return "非定向就业";
        case "12":
          return "定向就业";
        default:
          return " ";
      }
    },
    bkxxfs(val) {
      switch (val) {
        case "1":
          return "全日制";
        case "2":
          return "非全日制";
        case "1,2":
          return "全日制,非全日制";
        default:
          return " ";
      }
    }
  },
  methods: {
    // 回显历史的申请记录
    dataBack() {
      // 如果id为空不请求数据
      if (!this.specialId) {
        return;
      }
      this.$http
        .get(`/api/enroll/masterStudent/getInfo/${this.specialId}`)
        .then(res => {
          const data = res.data.data;
          console.log(data);
          // 非空验证
          if (!data) {
            this.$message.error("获取历史上报记录失败，请重试");
            return;
          }
          // 保存请求获取的表单值
          this.stuInfoForm = Object.assign({}, this.stuInfoForm, data);
        });
    },
    // 文本转化
    textChange(val) {
      if (!val) {
        return "";
      }
      const tmp = val.replace(/\|/g, " ").replace(/#/g, "</br>");
      console.log(tmp);
      return tmp;
    }
  }
};
</script>
<style lang="scss" scoped>
.stuInfoDetail {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;
    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
  }
  .box {
    // border: 1px solid rgba(228, 228, 228, 1);
    font-size: 14px;
    background-color: #fff;
    padding: 20px;
    margin-bottom: 0;
    min-height: 73vh;

    table {
      width: 100%;
      margin-bottom: 20px;
      border: 1px solid rgba(228, 228, 228, 1);
      border-collapse: collapse;
      table-layout: fixed;
      color: #333;
      tbody {
        th {
          text-align: left;
          font-weight: 700;
          padding: 11px 2px 11px 10px;
          background: #f0f2f5;
          span {
            color: #1890ff;
          }
        }
      }
      td {
        width: 450px;
        height: 24px;
        div {
          width: 100%;
          box-sizing: border-box;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          padding: 0 1em;
        }
      }
      tr.first {
        td {
          width: 33.3%;
          height: 0px;
        }
      }
    }
  }
}
</style>

