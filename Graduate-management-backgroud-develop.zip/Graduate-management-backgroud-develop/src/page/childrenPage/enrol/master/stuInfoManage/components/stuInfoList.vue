<template>
  <div class="stuInfoList">
    <searchcomponment>
      <div slot="left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入考生编号/姓名"
          clearable
          @clear="loadTable"
          @keyup.enter.native="loadTable"
          style="width:200px"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select
          v-model="limitQuery.bkxym"
          style="width:150px;"
          @change="loadTable"
          filterable
          
        >
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="genarateClick"
          v-if="$btnAuthorityTest('stuInfoManage:generate')"
          >生成考生编号</el-button
        >
        <el-upload
          action="/api/enroll/masterStudent/uploadFile/0"
          :show-file-list="false"
          style="display:inline-block;"
          :headers="headers"
          :before-upload="handleBeforeUpload"
          :on-success="handleUpload"
          :on-error="handleError"
          v-if="$btnAuthorityTest('stuInfoManage:import')"
        >
          <el-button type="primary" plain>导入</el-button>
        </el-upload>
        <el-button
          type="primary"
          plain
          @click="outputClick"
          v-if="$btnAuthorityTest('stuInfoManage:export')"
          >导出</el-button
        >
      </div>
    </searchcomponment>
    <el-table
      :data="newsCount === 0 ? [] : tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      element-loading-spinner="el-icon-loading"
      ref="multipleTable"
      style="width: 100%;"
      :header-cell-style="$storage.tableHeaderColor"
      :height="tableHeight"
    >
      <el-table-column type="index" width="55" label="序号"></el-table-column>
      <el-table-column prop="ksbh" label="考生编号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="xbm" label="性别">
        <template slot-scope="scope">
          <span>{{ scope.row.xbm | sexFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="bmdmc"
        label="报名点名称"
        width="300px"
      ></el-table-column>
      <el-table-column prop="bkxy" label="报考学院"></el-table-column>
      <el-table-column prop="bkzy" label="报考专业"></el-table-column>
      <el-table-column label="学习方式">
        <template slot-scope="scope">
          <span>{{ scope.row.ksxxfs | ksxxfs }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click="goDetail(scope.$index)"
            type="text"
            size="small"
            class="under-line"
            v-if="$btnAuthorityTest('stuInfoManage:view')"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination
        background
        :current-page="limitQuery.pageNum"
        :page-sizes="[15, 25, 50, 100]"
        :page-size="limitQuery.pageSize"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="newsCount"
        style="margin-top:15px;text-align:center"
      ></el-pagination>
    </div>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
</template>

<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../../componments/timecommon";

export default {
  name: "stuInfoList",
  components: {
    searchcomponment: searchcomponment,
    timecommon
  },
  data() {
    return {
      // uploadData: {
      //   zslb: "0"
      // },
      // 表格展示的数据
      tableData: [
        {
          // 报考院校
          bkxy: "",
          // 报考专业
          bkzy: "",
          // 考生报名点名称
          bmdmc: "",
          // id
          id: "",
          // 考生编号
          ksbh: "",
          // 考生姓名
          xm: "",
          // 学习方式
          ksxxfs: "",
          // 性别
          xbm: ""
        }
      ],
      // 分页查询的参数
      limitQuery: {
        //	院校
        bkxym: "",
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: 2019
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      // 可选的年度列表
      yearOptions: [
        { label: "2019年", value: 2019 },
        { label: "2020年", value: 2020 }
      ],
      // 学院的待选列表
      xyOptions: [],
      // 勾选的列
      selectRowList: [],
      tableHeight: null,
      headers: {
        userToken: this.$stores.state.token
      }
    };
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };

    // 获取当前的招生年度数据
    this.requireCurrentYear();
    // 获取可选学院列表
    this.requireXY();
  },
  watch: {
    $route(to) {
      if (to.name === "stuInfoManage") {
        this.loadTable();
      }
    }
  },
  methods: {
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求列表数据的方法
    loadTable() {
      console.log("正在请求列表数据");
      this.loading = true;
      this.$http
        .post("/api/enroll/masterStudent/list", this.limitQuery)
        .then(res => {
          this.loading = false;
          let data = res.data;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          console.log(data);
          // console.log(data.info);
          this.tableData = data.list;
          this.newsCount = data.total;
          // setTimeout(() => {
          //   this.loading = false;
          // }, 500);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 查看详情
    goDetail(index) {
      console.log(`正在前往查看第${index}条数据`);
      this.$router.push({
        path: "/stuInfoManage",
        query: { id: 3, specialId: this.tableData[index].id }
      });
    },
    // 点击生成考生编号的方法
    genarateClick() {
      this.loading = true;
      this.$http.get("/api/enroll/masterStudent/generate").then(res => {
        setTimeout(() => {
          if (res.data.code == 200) {
            this.loadTable();
            this.$message.success("生成成功");
          } else {
            this.$message.error(res.data.message);
          }
        }, 1000);
      });
    },
    // 点击导出的方法
    outputClick() {
      window.location.href = "/api/enroll/masterStudent/downloadFile";
    },

    handleBeforeUpload() {
      this.loading = true;
    },

    // 导入按钮事件
    handleUpload(res) {
      setTimeout(() => {
        if (res.code == 200 && res.message) {
          this.loadTable();
          this.loading = false;
          this.$message.success(res.message);
        } else {
          this.$message.error(res.message);
          // 重新申请数据，取消加载状态显示
          this.loading = false;
        }
      }, 1000);
    },
    // 导入出错
    handleError(err) {
      console.log(err);
      this.$message.error("导入失败，请重试");
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/getYear").then(res => {
        this.yearOptions = res.data.data;
      });
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.loadTable();
      });
    },
    // 获取学院的可选列表
    requireXY() {
      this.$http.get("/api/system/dict/select/enroll/academy").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        } // 保存学院的待选列表
        this.xyOptions = data;
        this.xyOptions.unshift({
          label: "全部学院",
          value: ""
        }); // 取第一个学院为默认选中
        this.limitQuery.college = data[0].value;
      });
    } // 文件导入按钮触发的方法
  },
  filters: {
    ksxxfs(val) {
      switch (val) {
        case "1":
          return "全日制";
        case "2":
          return "非全日制";
        case "1,2":
          return "全日制,非全日制";
        default:
          break;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.stuInfoList {
  padding-top: 7px;

  .block {
    text-align: center;
    margin-bottom: 20px;
  }

  /deep/ .el-date-editor {
    margin-left: 10px;
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }

  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }

  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;

    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }

  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }

  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
