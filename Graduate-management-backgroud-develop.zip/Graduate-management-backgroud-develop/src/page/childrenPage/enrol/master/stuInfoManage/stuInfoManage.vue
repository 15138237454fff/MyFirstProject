<template>
  <div class="stuInfoManage">
    <stu-info-detail v-if="id != 2"></stu-info-detail>
    <stu-info-list v-if="id == 2"></stu-info-list>
  </div>
</template>
<script>
import stuInfoList from "./components/stuInfoList";
import stuInfoDetail from "./components/stuInfoDetail";
export default {
  name: "stuInfoManage",
  data() {
    return {};
  },
  components: {
    "stu-info-list": stuInfoList,
    "stu-info-detail": stuInfoDetail
  },
  computed: {
    id() {
      return this.$route.query.id;
    }
  }
};
</script>
<style lang="scss" scoped>
.stuInfoManage {
  width: 100%;
  overflow: hidden;
}
</style>


