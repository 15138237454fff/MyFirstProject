<template>
  <div class="firstScoreInput" v-if="isOpen">
    <searchcomponment>
      <div slot="left">
        <el-input prefix-icon="el-icon-search" v-model="limitQuery.query" placeholder="请输入考生编号/姓名" clearable @clear="freshtable" @keyup.enter.native="freshtable" style="width:200px"></el-input>
        <el-button @click="freshtable">查询</el-button>
        <el-select v-model="limitQuery.bkxy" @change="freshtable">
          <el-option v-for="(item, index) in xyOptions" :key="index" :label="item.label" :value="item.value"></el-option>
        </el-select>
        <el-select v-model="limitQuery.bkzy" @change="freshtable">
          <el-option v-for="(item, index) in zyOptions" :key="index" :label="item.label" :value="item.value"></el-option>
        </el-select>
        <el-select v-model="limitQuery.kmlb" @change="freshtable">
          <el-option label="全部科目类别" :value="null"></el-option>
          <el-option v-for="(item, index) in kmOptions" :key="index" :label="item.label" :value="item.value"></el-option>
        </el-select>
        <el-select v-model="limitQuery.kskm" @change="freshtable">
          <el-option label="全部考试科目" :value="null"></el-option>
          <el-option v-for="(item, index) in ksOptions" :key="index" :label="item.kmmc" :value="item.kmdm"></el-option>
        </el-select>
      </div>
      <div slot="right">
        <el-button type="primary" @click="qklogin" v-if="$btnAuthorityTest('firstScoreInput:signup')">缺考登记</el-button>
      </div>
    </searchcomponment>
    <el-table :data="newsCount === 0 ? [] : tableData" tooltip-effect="dark" border v-loading="loading" element-loading-text="加载中" element-loading-spinner="el-icon-loading" style="width: 100%;" :height="tableHeight" :header-cell-style="$storage.tableHeaderColor" :default-sort="{ prop: 'ksbh', order: 'ascending' }">
      <el-table-column prop="ksbh" label="考生编号"></el-table-column>
      <el-table-column prop="xm" label="姓名"></el-table-column>
      <el-table-column prop="bkxy" label="报考学院"></el-table-column>
      <el-table-column prop="bkzy" label="报考专业"></el-table-column>
      <el-table-column label="学习方式">
        <template slot-scope="scope">
          <span> {{ scope.row.xxfs | xxfszt }} </span>
        </template>
      </el-table-column>
      <el-table-column label="科目类别">
        <template slot-scope="scope">
          <span>{{ scope.row.kmlb | kmlbFilter }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="kmmc" label="考试科目"></el-table-column>
      <el-table-column label="初试成绩">
        <template slot-scope="scope">
          <el-input-number v-model="scope.row.cjlr" controls-position="right" @keyup.enter.native="saveData(scope.$index)" :ref="'scopeInput' + scope.$index" :min="-1" :max="150" :precision="0" v-if="$btnAuthorityTest('firstScoreInput:input')"></el-input-number>
        </template>
      </el-table-column>
    </el-table>
    <div class="block">
      <el-pagination background :current-page="limitQuery.pageNum" :page-sizes="[15, 25, 50, 100]" :page-size="limitQuery.pageSize" @size-change="handleSizeChange" @current-change="handleCurrentChange" layout="total, sizes, prev, pager, next, jumper" :total="newsCount" style="margin-top:15px;text-align:center" v-if="loadingpagination"></el-pagination>
    </div>
    <el-dialog title="缺考登记" :visible.sync="dialogVisibles" width="700px" :close-on-click-modal="false" :before-close="handleClose">
      <p style="display:flex;margin-bottom:15px">
        <span style="color:#409EFF;flex:2">{{ content }}</span>
        <span style="text-align:right;flex:1">
          <el-button @click="returnercode">撤销扫码登记</el-button>
        </span>
      </p>
      <table>
        <tr>
          <td class="left_cont">
            <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span><span>考生信息</span>

          </td>
          <td>
            <el-input prefix-icon="el-icon-search" v-model="queryksbh" placeholder="请输入考生编号" clearable style="width:180px;"></el-input>
            <el-select v-model="querykmlb">
              <el-option v-for="(item, index) in kmOptions" :key="index" :label="item.label" :value="item.value"></el-option>
            </el-select>
            <el-button @click="masterResult" type="primary">人工登记</el-button>
          </td>
        </tr>
        <tr>
          <td class="listcss">考生编号</td>
          <td>{{ formparams.ksbh }}</td>
        </tr>
        <tr>
          <td class="listcss">考生姓名</td>
          <td>{{ formparams.xm }}</td>
        </tr>
        <tr>
          <td class="listcss">考试科目代码</td>
          <td>{{ formparams.kmdm }}</td>
        </tr>
        <tr>
          <td class="listcss">考试科目名称</td>
          <td>{{ formparams.kmmc }}</td>
        </tr>
        <tr>
          <td class="listcss">考试时间</td>
          <td>{{ formparams.ksrq }}</td>
        </tr>
        <tr>
          <td class="listcss">考区考点</td>
          <td>{{ formparams.kdmc }}</td>
        </tr>
        <tr>
          <td class="listcss">报考单位</td>
          <td>{{ formparams.bkdwmc }}</td>
        </tr>
        <tr>
          <td class="listcss">缺考成绩</td>
          <td>{{ formparams.qkcj }}</td>
        </tr>
      </table>
    </el-dialog>
    <timecommon :year="limitQuery.year"></timecommon>
  </div>
  <my-blank v-else msg="成绩录入功能暂未开启！"></my-blank>
</template>
<script>
import searchcomponment from "@/components/searchcomponment";
import timecommon from "../../componments/timecommon";
import blank from "@/components/blank";
export default {
  name: "firstScoreInput",
  components: {
    searchcomponment: searchcomponment,
    timecommon,
    "my-blank": blank
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [
        {
          // 报考学院
          bkxy: "",
          // 报考专业
          bkzy: "",
          // 成绩录入
          cjlr: "",
          // 登分成绩人员1id
          cscjjs1: "",
          // 登分成绩人员2id
          cscjjs2: "",
          // 初始成绩录入1
          cscjlr1: "",
          // 初始成绩录入2
          cscjlr2: "",
          id: "",
          // 科目类别
          kmlb: "",
          // 考试科目
          kmmc: "",
          // 考生编号
          ksbh: "",
          // 考生姓名
          xm: "",
          // 学习方式
          xxfs: ""
        }
      ],
      // 科目的待选列表
      kmOptions: [
        { label: "思想政治理论", value: 1, name: "sxzzll" },
        { label: "外国语", value: 2, name: "wgy" },
        { label: "业务课一", value: 3, name: "ywke" },
        { label: "业务课二", value: 4, name: "ywky" }
      ],
      // 考试科目的待选列表
      ksOptions: [],
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      // 分页查询的参数
      limitQuery: {
        // 考试科目
        kskm: null,
        // 报考学院
        bkxy: "",
        // 当前用户角色id
        jsid: this.$stores.state.roleid_tole,
        // 报考专业
        bkzy: "",
        // 科目类别
        kmlb: null,
        query: "",
        pageSize: 15,
        pageNum: 1,
        year: null
      },
      // 消息总数量
      newsCount: 0,
      // 是否正在加载数据
      loading: false,
      tableHeight: null,
      dialogVisibles: false,
      content: "请扫码缺考考生科目小标签进行登记！",
      keycode: "",
      lastTime: "",
      lastCode: "",
      code: "",
      loadingpagination: true,
      formparams: {
        ksbh: "",
        xm: "",
        kmdm: "",
        kmmc: "",
        ksrq: "",
        kdmc: "",
        bkdwmc: "",
        qkcj: ""
      },
      ercode: false,
      isOpen: window.sessionStorage.getItem("enrollInputIsOpen"),
      queryksbh: "",
      querykmlb: ""
    };
  },
  created() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    // 请求学院专业信息

    this.requireXY();
    this.requireCurrentYear();

    // 请求考试科目可选列表
    this.requireKSKM(null);
    this.requireTime();
  },
  methods: {
    masterResult() {
      this.$http
        .get(
          `/api/enroll/masterResult/input/${this.queryksbh}/${this.querykmlb}`
        )
        .then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            this.formparams = res.data.data;
          } else {
            this.$message.error(res.data.message);
            this.formparams = {};
          }
        });
    },
    freshtable() {
      this.loadingpagination = false;
      setTimeout(() => {
        this.loadingpagination = true;
        this.limitQuery.pageNum = 1;
        this.limitQuery.pageSize = 15;
        this.loadTable();
      }, 100);
    },
    requireTime() {
      this.$http.get("/api/enroll/psc/entry/time").then(res => {
        const data = res.data.data;
        if (!data) {
          return this.$message.error("获取成绩录入时间失败，请重试");
        }
        let now = this.$tagTime(new Date(), "yyyy-MM-dd"),
          start = this.$tagTime(new Date(data.startTime), "yyyy-MM-dd"),
          end = this.$tagTime(new Date(data.endTime), "yyyy-MM-dd");
        this.isOpen = data.isOpen === 1 && now <= end && now >= start;
        window.sessionStorage.setItem("enrollInputIsOpen", this.isOpen);
      });
    },
    handleClose() {
      this.ercode = false;
      this.dialogVisibles = false;
    },
    ercodes() {
      document.onkeydown = e => {
        let nextCode,
          nextTime = "";
        let lastTime = this.lastTime;
        let code = this.code; // 扫描枪拿到的字符长度加上键盘编码的一个字符长度
        if (window.event) {
          // IE
          nextCode = e.keyCode;
        } else if (e.which) {
          // Netscape/Firefox/Opera
          nextCode = e.which;
        }
        nextTime = new Date().getTime();
        // 字母上方 数字键0-9 对应键码值 48-57; 数字键盘 数字键0-9 对应键码值 96-105
        if (
          (nextCode >= 48 && nextCode <= 57) ||
          (nextCode >= 96 && nextCode <= 189)
        ) {
          let codes = {
            "48": 48,
            "49": 49,
            "50": 50,
            "51": 51,
            "52": 52,
            "53": 53,
            "54": 54,
            "55": 55,
            "56": 56,
            "57": 57,
            "96": 48,
            "97": 49,
            "98": 50,
            "99": 51,
            "100": 52,
            "101": 53,
            "102": 54,
            "103": 55,
            "104": 56,
            "105": 57,
            "189": 189
          };
          nextCode = codes[nextCode];
          nextTime = new Date().getTime();
        }
        // 第二次输入延迟两秒，删除之前的数据重新计算
        if (nextTime && lastTime && nextTime - lastTime > 2000) {
          code = String.fromCharCode(nextCode);
        } else {
          code += String.fromCharCode(nextCode);
        }
        // 保存数据
        this.nextCode = nextCode;
        this.lastTime = nextTime;
        this.code = code.replace("½", "-");
        // 键入Enter
        if (e.which == 13 && this.ercode) {
          this.$http
            .get(`api/enroll/masterResult/sweep/${this.code}`)
            .then(res => {
              if (res.data.code == 200) {
                this.formparams = res.data.data;
                this.content = "已完成该缺考考生的登记，请继续扫码！";
              } else {
                this.$message({
                  message: res.data.message,
                  type: "error"
                });
              }
            })
            .catch(() => {
              this.$message({
                type: "error",
                message: "该条形码无效！"
              });
            });
          this.code = "";
          return false;
        }
      };
    },
    returnercode() {
      var [queryksbh, querykmlb] = ["", ""];
      if (this.ercode) {
        queryksbh = this.formparams.ksbh;
        querykmlb = this.formparams.kmlb;
      } else {
        queryksbh = this.queryksbh;
        querykmlb = this.querykmlb;
      }
      this.$http
        .get(
          `/api/enroll/masterResult/resetSweep/${this.formparams.id}/${queryksbh}/${querykmlb}`
        )
        .then(res => {
          const data = res.data;
          if (data.code === 200) {
            this.freshparams();
            this.queryksbh = "";
            this.querykmlb = "";
          } else {
            this.$message.error(data.message);
          }
        });
    },
    freshparams() {
      this.formparams = {
        ksbh: "",
        xm: "",
        kmdm: "",
        kmmc: "",
        ksrq: "",
        kdmc: "",
        bkdwmc: "",
        qkcj: ""
      };
      this.content = "请扫码缺考考生科目小标签进行登记！";
    },
    qklogin() {
      this.dialogVisibles = true;
      this.freshparams();
      this.ercodes();
      this.ercode = true;
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.limitQuery.pageSize = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 改变当前页
    handleCurrentChange(val) {
      this.limitQuery.pageNum = val;
      // 重新请求列表数据
      this.loadTable();
    },
    // 成绩录入
    saveData(index) {
      console.log("发送请求保存成绩" + index);
      let tmpRow = this.tableData[index];
      console.log(tmpRow.cjlr);
      if (tmpRow.cjlr === "") {
        this.$message.warning("填写成绩后再尝试提交");
        return;
      }
      // 取出当前所在行的数据
      // 放入待提交的表单对象中
      const uploadForm = {
        id: tmpRow.id,
        // 成绩录入
        cjlr: tmpRow.cjlr,
        // 成绩录入人员的角色id
        jsid: this.$stores.state.roleid_tole
      };
      // console.log(uploadForm);
      // 发送请求提交成绩
      this.$http
        .post("/api/enroll/masterResult/firstSave", uploadForm)
        .then(res => {
          const data = res.data;
          if (data.code === 200) {
            // 切换到下一个输入框
            this.jumpInput(index);
          } else {
            this.$message.error(data.message);
            this.tableData[index].cjlr = "";
          }
        });
    },
    // 请求列表数据的方法
    loadTable() {
      this.loading = true;

      this.$http
        .post("/api/enroll/masterResult/list", this.limitQuery)
        .then(res => {
          this.loading = false;
          let data = res.data;
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message);
            return;
          }
          data = data.data;
          // 如果返回的数据不是数组类型
          if (data && !Array.isArray(data.list)) {
            this.$message.error("数据请求失败，请刷新");
            return;
          }
          // console.log(data.info);
          data.list.forEach(el => {
            if (el.cjlr === null) {
              el.cjlr = undefined;
            }
          });
          this.tableData = data.list;
          this.newsCount = data.total;
          console.log(this.tableData);
          // dom操作放入nextTick,如果存在输入框
          this.$nextTick(() => {
            if (this.$refs.scopeInput0) {
              // 第一个输入框获取焦点
              this.$refs.scopeInput0.focus();
            }
          });
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 切换输入框的方法
    jumpInput(index) {
      // 获取下一个输入框下标
      let nextIndex = index + 1,
        // 获取下一个输入框
        nextInput = this.$refs["scopeInput" + nextIndex];
      // 如果这个输入框存在
      if (nextInput) {
        // 激活下一个输入框
        nextInput.focus();
      }
      // 如果已经是最后一个输入框
      else {
        // 这个输入框失去焦点
        this.$refs["scopeInput" + index].blur();
      }
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http.get("/api/system/dict/select/enroll/college").then(res => {
        const data = res.data.data;
        // 验证列表数据格式是否正确
        if (!Array.isArray(data)) {
          this.$message.error("获取学院和专业信息失败，请重试");
          return;
        }
        // 保存学院的待选列表
        this.xyOptions = data;
        // 取第一个学院为默认选中
        this.limitQuery.bkxy = data[0].value;
        // 取出可选的专业待选列表
        this.zyOptions = this.xyOptions[0].children;
      });
    },
    // 根据科目类型请求对应的考试科目
    requireKSKM(kmlb) {
      this.$http
        .post("/api/enroll/masterResult/getTree", { kmlb })
        .then(res => {
          const data = res.data.data;
          // 验证消息格式
          // 保存新的考试科目可选列表
          this.ksOptions = data;
          // 重置考试科目的所选值
          this.limitQuery.kskm = null;
        });
    },
    // 请求当前的招生年度
    requireCurrentYear() {
      this.$http.get("/api/enroll/psc/annual").then(res => {
        this.limitQuery.year = res.data.data;
        this.loadTable();
      });
    }
  },
  watch: {
    $route(to) {
      if (to.name === "firstScoreInput") {
        this.loadTable();
      }
    },
    "limitQuery.bkxy": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        this.limitQuery.bkzy = this.zyOptions[0].value;
      }
    },
    "limitQuery.kmlb": {
      handler(val) {
        // 请求考试科目可选列表
        this.requireKSKM(val);
      }
    }
  },
  filters: {
    // 过滤科目类别
    kmlbFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "思想政治理论";
        case 2:
          return "外国语";
        case 3:
          return "业务课一";
        case 4:
          return "业务课二";
      }
    },
    xxfszt(val) {
      var key = val.toString();
      switch (key) {
        case "1":
          return "全日制";
        case "2":
          return "非全日制";
        case "1,2":
          return "全日制,非全日制";
        default:
          break;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.firstScoreInput {
  padding-top: 7px;
  table {
    border-collapse: collapse;
    width: 100%;
    color: #444;
    font-size: 14px;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-weight: 400;
    margin-bottom: 20px;
    thead {
      height: 36px !important;
      border: 1px solid #e0e0e0;
    }
    tr {
      border: 1px solid #e0e0e0;
    }
    th,
    td {
      border: 1px solid #e0e0e0;
      height: 36px;
      padding-left: 10px;
      width: 100px;
    }
    .left_cont {
      padding-left: 10px;
      font-weight: bold;
    }
    .listcss {
      text-align: center;
      background: #f2f2f2;
      width: 100px;
    }
  }
  .block {
    text-align: center;
    margin-bottom: 20px;
  }
  .slot-box {
    font-family: "Microsoft YaHei UI";
    font-weight: 400;
    font-style: normal;
    font-size: 14px;
    color: #000000;
    line-height: 35px;
  }
  .slot-mtlx {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 176px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }
  .slot-kssj {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    th {
      height: 40px;
      background: #f2f2f2;
    }
    td:nth-child(odd) {
      width: 100px;
    }
    td,
    th {
      border: 1px solid #e5e5e5;
    }
  }

  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    padding: 0;
  }
  /deep/ .el-table td {
    padding: 0 !important;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    text-align: left;
    p {
      line-height: 32px;
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    color: #333;
    font-weight: 600;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ddd;
  }
  /deep/ .el-dialog__footer {
    text-align: center;
  }
}
</style>
