<template>
  <div class="enrollment">
    <template>
      <div class="tabs">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="拟录取名单" name="first"></el-tab-pane>
          <el-tab-pane label="录取名单" name="second"></el-tab-pane>
        </el-tabs>
      </div>
    </template>
    <adjustList v-if="activeName=='first'"></adjustList>
    <adjustRow v-if="activeName=='second'"></adjustRow>
  </div>
</template>
<script>
import adjustList from './componments/enrollmentList';
import adjustRow from './componments/enrollmentRow';
export default {
  name: 'enrollment',
  components: {
    adjustList: adjustList,
    adjustRow: adjustRow
  },
  data() {
    return {
      activeName: 'first'
    }
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    }
  }
}
</script>
<style scoped lang="scss">
.addmissProposed {
  width: 100%;
}
.tabs {
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
}
</style>