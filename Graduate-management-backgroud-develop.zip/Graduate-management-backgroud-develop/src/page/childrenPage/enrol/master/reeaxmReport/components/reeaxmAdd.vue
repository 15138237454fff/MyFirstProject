<template>
  <div class="reeaxmAdd">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          @click="saveForm"
          v-if="
            (writeable && status == 2) ||
              (status == 4 && this.$route.query.id == 4) ||
              this.$route.query.id == 1
          "
          >保存</el-button
        >
        <span
          v-if="(!writeable && status == 1) || status == 3"
          :class="status | zsZTFilter(1)"
          >{{ status | zsZTFilter(0) }}</span
        >
      </div>
    </div>
    <div class="filter">
      <div class="required">
        所属学院：
        <el-select
          v-model="specialForm.xydm"
          :disabled="writeables"
          style="width:60%;"
          @change="selectapp"
          placeholder="全部学院"
        >
          <el-option
            v-for="(item, index) in xyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div class="required">
        招生专业：
        <el-select
          v-model="specialForm.zydm"
          :disabled="writeables"
          style="width:60%;"
          placeholder="全部专业"
          @change="requireYjfx"
        >
          <el-option
            v-for="(item, index) in zyOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
    </div>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="2" class="table-one">
        <thead>
          <tr>
            <th colspan="8" class="required">专业分数线及复试权重</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>学习方式</th>
            <th>总分</th>
            <th>思想政治理论</th>
            <th>外国语</th>
            <th>业务课一</th>
            <th>业务课二</th>
            <th>备注</th>
            <th>复试权重</th>
          </tr>
          <tr>
            <td>全日制</td>
            <td>
              <el-input
                v-model="specialForm.qrz.zf"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.sxzzll"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.wgy"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.ywky"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.qrz.ywke"
                :disabled="!writeable"
                :readonly="isshow"
                :placeholder="inputplaceholder"
              ></el-input>
            </td>
            <td>
              <el-radio
                v-model="specialForm.qrz.bz"
                :disabled="!writeable"
                :label="1"
                >国家线</el-radio
              >
              <el-radio
                v-model="specialForm.qrz.bz"
                :disabled="!writeable"
                :label="2"
                >自划线</el-radio
              >
            </td>
            <td>
              <el-input v-model="specialForm.qrz.fsqz" :disabled="!writeable">
                <i slot="suffix" class="danwei">%</i>
              </el-input>
            </td>
          </tr>
          <tr>
            <td>非全日制</td>
            <td>
              <el-input
                v-model="specialForm.fqrz.zf"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.sxzzll"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.wgy"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.ywky"
                :disabled="!writeable"
              ></el-input>
            </td>
            <td>
              <el-input
                v-model="specialForm.fqrz.ywke"
                :disabled="!writeable"
                :readonly="isshow"
                :placeholder="inputplaceholder"
              ></el-input>
            </td>
            <td>
              <el-radio
                v-model="specialForm.fqrz.bz"
                :disabled="!writeable"
                :label="1"
                >国家线</el-radio
              >
              <el-radio
                v-model="specialForm.fqrz.bz"
                :disabled="!writeable"
                :label="2"
                >自划线</el-radio
              >
            </td>
            <td>
              <el-input v-model="specialForm.fqrz.fsqz" :disabled="!writeable">
                <i slot="suffix" class="danwei">%</i>
              </el-input>
            </td>
          </tr>
        </tbody>
      </table>
      <table border="1" cellspacing="0" cellpadding="2" class="table-two">
        <thead>
          <tr class="first">
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <th colspan="9"><span>|</span>研究方向复试分数线</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>方向代码</th>
            <th>研究方向</th>
            <th>学习方式</th>
            <th>总分</th>
            <th>思想政治理论</th>
            <th>外国语</th>
            <th>业务课一</th>
            <th>业务课二</th>
            <th>备注</th>
          </tr>
          <tr v-for="(item, index) of specialForm.yjfxfsfsx" :key="index">
            <td>{{ item.dm }}</td>
            <td>{{ item.mc }}</td>
            <td>{{ item.xxfs | xxfsFilter(0) }}</td>
            <td>
              <el-input v-model="item.zf" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.sxzzll" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.wgy" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input v-model="item.ywky" :disabled="!writeable"></el-input>
            </td>
            <td>
              <el-input
                v-model="item.ywke"
                :disabled="!writeable"
                :readonly="isshow"
                :placeholder="inputplaceholder"
              ></el-input>
            </td>
            <td>
              <el-radio v-model="item.bz" :disabled="!writeable" :label="1"
                >国家线</el-radio
              >
              <el-radio v-model="item.bz" :disabled="!writeable" :label="2"
                >自划线</el-radio
              >
            </td>
          </tr>
        </tbody>
      </table>
      <apply-status-bottom></apply-status-bottom>
    </div>
  </div>
</template>
<script>
import applyStatusBottom from "@/components/applyStatusBottom";
export default {
  name: "reeaxmAdd",
  data() {
    return {
      specialForm: {
        // 非全日制
        fqrz: {
          // 备注
          bz: 1,
          // 复试权重
          fsqz: "",
          // 思想政治理论
          sxzzll: "",
          // 外国语
          wgy: "",
          // 业务课二
          ywke: "",
          // 业务课一
          ywky: "",
          // 总分
          zf: ""
        },
        // id
        id: "",
        // 全日制
        qrz: {
          // 备注
          bz: 1,
          // 复试权重
          fsqz: "",
          // 思想政治理论
          sxzzll: "",
          // 外国语
          wgy: "",
          // 业务课二
          ywke: "",
          // 业务课一
          ywky: "",
          // 总分
          zf: ""
        },
        // 学院代码
        xydm: "",
        // 学院名称
        xymc: "",
        // 专业代码
        zydm: "",
        // 专业名称
        zymc: "",
        // 研究方向复试分数线
        yjfxfsfsx: [
          // {
          //   // 备注
          //   bz: "",
          //   // 方向代码
          //   dm: "",
          //   // 研究方向
          //   mc: "",
          //   // 思想政治理论
          //   sxzzll: "",
          //   // 外国语
          //   wgy: "",
          //   // 业务课二
          //   ywke: "",
          //   // 业务课一
          //   ywky: "",
          //   // 总分
          //   zf: ""
          // }
        ]
      },
      // //是否可写
      // writeable: true,
      // 审核状态
      status: "",
      // 可选的学院列表
      xyOptions: [],
      // 可选的专业列表
      zyOptions: [],
      isshow: false,
      inputplaceholder: "",
      haveYwke: true,
      writeables: true
    };
  },
  components: {
    "apply-status-bottom": applyStatusBottom
  },
  created() {
    // 请求学院专业信息
    this.requireXY();
    // 请求审核记录
    this.detailStatus();
    // 如果是查看/修改页面
    if (this.id == 3 || this.id == 4) {
      // 回显数据
      this.dataBack();
    }
    if (this.$route.query.id == 1) {
      this.writeables = false;
    }
  },
  computed: {
    // 根据路由信息返回是否可写
    writeable() {
      if (this.$route.query.id != 3) {
        return true;
      } else {
        return false;
      }
    },
    // 上报的记录Id
    specialId() {
      return this.$route.query.specialId;
    },
    // 页面控制Id
    id() {
      return this.$route.query.id;
    }
  },
  methods: {
    selectapp() {
      // 非全日制
      this.specialForm.fqrz = {
        // 备注
        bz: 1,
        // 复试权重
        fsqz: "",
        // 思想政治理论
        sxzzll: "",
        // 外国语
        wgy: "",
        // 业务课二
        ywke: "",
        // 业务课一
        ywky: "",
        // 总分
        zf: ""
      };
      // 全日制
      this.specialForm.qrz = {
        // 备注
        bz: 1,
        // 复试权重
        fsqz: "",
        // 思想政治理论
        sxzzll: "",
        // 外国语
        wgy: "",
        // 业务课二
        ywke: "",
        // 业务课一
        ywky: "",
        // 总分
        zf: ""
      };
      // 研究方向复试分数线
      this.specialForm.yjfxfsfsx = [];
    },
    // 提交表单数据，保存
    saveForm() {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.confirmSave,
        title: "确认保存",
        msgOne: "是否确认保存？",
        msgTwo: ""
      });
    },
    // 回显历史的申请记录
    dataBack() {
      this.$http.get(`/api/enroll/sirc/${this.specialId}`).then(res => {
        const data = res.data.data;
        // 非空验证
        if (!data) {
          this.$message.error("获取历史上报记录失败，请重试");
          return;
        }
        // 保存请求获取的表单值
        Object.keys(this.specialForm).forEach(key => {
          this.specialForm[key] = data[key];
        });
        // 保存审核状态
        this.status = data.zt;
      });
    },
    // 提交表单数据的方法
    confirmSave() {
      // 关闭对话框
      this.$store.commit("skb/updateDialog", { visible: false });
      // 基本类型的必填字段
      let tmpTest = true;
      // 验证非全日制是否填写完整
      Object.keys(this.specialForm.fqrz).forEach(key => {
        if (key === "ywke" && !this.haveYwke) {
          return;
        }
        if (tmpTest && this.specialForm.fqrz[key] === "") {
          tmpTest = false;
          return;
        }
      });
      if (tmpTest) {
        // 验证全日制是否填写完整
        Object.keys(this.specialForm.qrz).forEach(key => {
          if (key === "ywke" && !this.haveYwke) {
            return;
          }
          if (tmpTest && this.specialForm.qrz[key] === "") {
            tmpTest = false;
            return;
          }
        });
      }
      // 如果验证通过发送请求保存数据
      if (tmpTest) {
        if (this.id == 1) {
          this.$http
            .post("/api/enroll/sirc", this.specialForm)
            .then(res => {
              if (res.data.code === 200) {
                this.$message.success("保存成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            })
            .catch(err => {
              if (err.response.data.code == 400) {
                this.$message.error("请勿添加重复专业");
              } else this.$message.error(err.response.data.message);
            });
        } else if (this.id == 4) {
          this.$http
            .put(`/api/enroll/sirc/${this.specialId}`, this.specialForm)
            .then(res => {
              if (res.data.code === 200) {
                this.$message.success("保存成功");
                this.$router.push({ path: "/reeaxmReport", query: { id: 2 } });
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
      // 如果验证不通过
      else {
        this.$message.warning("请将必填项填写完整后再尝试提交");
      }
    },
    // 获取学院和专业的可选列表
    requireXY() {
      this.$http
        .post("/api/enroll/sirc/select/enroll/college", {
          pageNum: "",
          pageSize: "",
          query: ""
        })
        .then(res => {
          const data = res.data.data;
          // 验证列表数据格式是否正确
          if (!Array.isArray(data)) {
            this.$message.error("获取学院和专业信息失败，请重试");
            return;
          }
          this.xyOptions = data;
          const tmp = this.xyOptions.filter(el => {
            return el.value === this.specialForm.xydm;
          });
          if (!tmp[0]) {
            return;
          }
          this.zyOptions = tmp[0].children;
        });
    },
    // 请求研究方向
    requireYjfx() {
      this.selectapp();
      this.$http
        .get(
          `/api/enroll/sirc/getCheck/${this.specialForm.xydm}/${this.specialForm.zydm}`
        )
        .then(res => {
          res.data.data == "1" ? (this.isshow = true) : (this.isshow = false);
          if (res.data.data == "1") {
            this.inputplaceholder = "该专业无业务课二";
            this.haveYwke = false;
          } else {
            this.inputplaceholder = "";
            this.haveYwke = true;
          }
          if (res.data.data !== "1") {
            this.$http
              .get(
                `/api/enroll/mbc/${this.specialForm.xydm}/${this.specialForm.zydm}`
              )
              .then(res => {
                const data = res.data.data;
                if (!Array.isArray(data)) {
                  console.error("研究方向数据获取失败");
                  return;
                }
                this.specialForm.yjfxfsfsx = data.map(el => {
                  return {
                    bz: 1,
                    dm: el.dm,
                    mc: el.mc,
                    xxfs: el.xxfs,
                    sxzzll: "",
                    wgy: "",
                    ywke: "",
                    ywky: "",
                    zf: ""
                  };
                });
              });
          }
        });
    },
    // 前往修改页面
    goModify() {
      this.$router.push({
        path: "/reeaxmReport",
        query: { id: 4, specialId: this.specialId }
      });
    },
    detailStatus() {
      if (this.id == 3) {
        // 如果进入查看详情页面，请求对应流程id的审核状态
        this.$http.get("/api/enroll/sirac/" + this.specialId).then(res => {
          const data = res.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("获取审核具体流程数据失败，请刷新重试");
            return;
          }
          // 将审核具体流程数据发送给applyStatus
          this.$bus.$emit("stepList", data);
        });
      }
    }
  },
  watch: {
    "specialForm.xydm": {
      handler(val) {
        const tmp = this.xyOptions.filter(el => {
          return el.value === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.zyOptions = tmp[0].children;
        this.specialForm.zydm = this.zyOptions[0].value;
        this.$http
          .get(`/api/enroll/sirc/getCheck/${val}/${this.specialForm.zydm}`)
          .then(res => {
            res.data.data == "1" ? (this.isshow = true) : (this.isshow = false);
            if (res.data.data == "1") {
              this.inputplaceholder = "该专业无业务课二";
              this.haveYwke = false;
            } else {
              this.inputplaceholder = "";
              this.haveYwke = true;
            }
            if (res.data.data !== "1") {
              this.$http
                .get(
                  `/api/enroll/mbc/${this.specialForm.xydm}/${this.specialForm.zydm}`
                )
                .then(res => {
                  const data = res.data.data;
                  if (!Array.isArray(data)) {
                    console.error("研究方向数据获取失败");
                    return;
                  }
                  this.specialForm.yjfxfsfsx = data.map(el => {
                    return {
                      bz: 1,
                      dm: el.dm,
                      mc: el.mc,
                      xxfs: el.xxfs,
                      sxzzll: "",
                      wgy: "",
                      ywke: "",
                      ywky: "",
                      zf: ""
                    };
                  });
                });
            }
          });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.reeaxmAdd {
  .header {
    height: 50px;
    display: flex;
    font-size: 14px;
    padding: 0 20px;
    align-items: center;
    border-bottom: 1px solid #e5e5e5;

    .header-left {
      flex: 4;
      .el-icon-d-arrow-left {
        color: #2779e3;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .filter {
    display: flex;
    font-size: 14px;
    padding-top: 20px;
    padding-left: 20px;
    div:last-child {
      margin-left: 20px;
    }
  }
  .box {
    // border: 1px solid rgba(228, 228, 228, 1);
    font-size: 14px;
    background-color: #fff;
    padding: 20px;
    margin-bottom: 0;
    min-height: 73vh;
    table {
      width: 100%;
      border: 1px solid rgba(228, 228, 228, 1);
      border-collapse: collapse;
      color: #333;
      table-layout: fixed;
      margin-bottom: 20px;
      thead th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        // border: 1px solid #e5e5e5;
        background: #e4e4e4;
        span {
          color: #1890ff;
          margin-right: 5px;
        }
      }
      tbody {
        th {
          background: #f2f2f2;
          padding: 11px 10px 11px 10px;
          border: 1px solid #e5e5e5;
        }
      }
      td {
        width: 200px;
        height: 40px;
        border: 1px solid #e5e5e5;
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        .el-radio {
          margin-right: 20px;
        }
        .el-radio:last-child {
          margin-right: 0;
        }
      }
      tr.first {
        td {
          width: 12%;
          height: 0px;
        }
        td:nth-child(2) {
          width: 19%;
        }
        td:last-child {
          width: 19%;
        }
      }
    }
    .danwei {
      line-height: 40px;
      margin-right: 5px;
      color: #ccc;
      font-style: normal;
    }
  }
}
</style>
