<template>
  <div class="reeaxmReport">
    <reeaxm-add v-if="id != 2"></reeaxm-add>
    <reeaxm-list v-if="id == 2"></reeaxm-list>
  </div>
</template>
<script>
import reeaxmList from './components/reeaxmList';
import reeaxmAdd from './components/reeaxmAdd';
export default {
  name: 'reeaxmReport',
  data() {
    return {}
  },
  components: {
    'reeaxm-list': reeaxmList,
    'reeaxm-add': reeaxmAdd
  },
  computed: {
    id() {
      return this.$route.query.id
    }
  }
}
</script>
<style lang="scss" scoped>
.reeaxmReport {
  width: 100%;
  overflow: hidden;
}
</style>


