<template>
  <div class="MaterialReport">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入标题"
          suffix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          style="width:200px;"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('MaterialReport:add')"
          >添加</el-button
        >
        <el-button
          @click="clickDelete"
          type="danger"
          v-if="$btnAuthorityTest('MaterialReport:delete')"
          >删除</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="selection"
          align="center"
          :width="50"
        ></el-table-column>
        <el-table-column
          prop="bt"
          label="标题"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="clmc"
          label="材料名称"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="pjdja"
          label="上报时间"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.cjsj, "yyyy.MM.dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="状态" align="center" :width="120">
          <template slot-scope="scope">
            <span :class="scope.row.zt | ztClassFilter">{{
              scope.row.zt | ztValueFilter
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" :width="120">
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              @click="clickDetail(scope.row.id, scope.row.zt)"
              v-if="$btnAuthorityTest('MaterialReport:view')"
              >查看</span
            >
            <template
              v-if="
                scope.row.zt === 2 && $btnAuthorityTest('MaterialReport:update')
              "
            >
              <span>|</span>
              <span
                class="orange under-line cursor-pointer"
                @click="clickModify(scope.row.id)"
                >修改</span
              >
            </template>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <template v-if="modalOption.key !== 'detail'">
        <div class="modal-content">
          <el-form
            ref="form"
            :model="formData"
            label-width="100px"
            :rules="rules"
          >
            <el-form-item label="材料名称：" :required="true" prop="lxId">
              <el-select v-model="formData.lxId" style="width:270px;">
                <el-option
                  v-for="(item, index) in mcList"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="标 题：" :required="true" prop="bt">
              <el-input
                v-model="formData.bt"
                placeholder="请输入"
                :maxlength="20"
                style="width:270px;"
              ></el-input>
            </el-form-item>
            <el-form-item label="正 文：" :required="true" prop="zw">
              <el-input
                v-model="formData.zw"
                placeholder="请输入"
                :maxlength="500"
                type="textarea"
                :autosize="{ minRows: 6, maxRows: 8 }"
              ></el-input>
            </el-form-item>
            <el-form-item label="上传附件：">
              <el-upload
                class="upload-demo"
                :action="upload"
                :before-upload="handleBeforeUpload"
                :on-success="handleUploadSuccess"
                :on-remove="handleRemoveList"
                :on-preview="handlePreview"
                :file-list="fileList"
                multiple
                ref="uploadcsv"
                accept=""
                :headers="headtoken"
              >
                <el-button
                  style="border-color:rgba(24, 144, 255, 1);color:#1890FF;width:100px"
                >
                  点击上传+
                </el-button>
              </el-upload>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer">
          <el-button @click="clickCancel">取消</el-button>
          <el-button type="primary" @click="clickOk">提交</el-button>
        </div>
      </template>
      <template v-else>
        <div class="modal-content">
          <el-form
            ref="form"
            :model="formData"
            label-width="100px"
            :rules="rules"
          >
            <el-form-item label="材料名称：">
              <span>{{ getListValue(formData.lxId, mcList) }}</span>
            </el-form-item>
            <el-form-item label="标 题：">
              <span>{{ formData.bt }}</span>
            </el-form-item>
            <el-form-item label="正 文：">
              <div class="request-content">
                {{ formData.zw }}
              </div>
            </el-form-item>
            <el-form-item label="附件：">
              <span v-for="(item, index) of formData.fj" :key="index"
                ><a
                  :href="item.url"
                  class="under-line blue"
                  target="_blank"
                  :download="formData.fileName"
                  >{{ item.fileName }}</a
                ><span v-if="index !== formData.fj.length - 1">，</span></span
              >
            </el-form-item>
          </el-form>
        </div>
        <apply-status-bottom v-bind="aduit"></apply-status-bottom>
      </template>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
import applyStatusBottom from "@/components/skb/applyStatusBottom";
export default {
  name: "MaterialReport",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: ""
      },
      loading: false,
      selectedHistoryList: [],
      msgCount: 0,
      tableHeight: null,
      fileList: [],
      formData: {
        bt: "",
        fj: [],
        lxId: "",
        zw: ""
      },
      rules: {
        lxId: [{ required: true, message: "请选择材料名称" }],
        bt: [{ required: true, message: "请输入标题" }],
        zw: [{ required: true, message: "请输入正文" }]
      },
      mcList: [],
      aduit: {
        status: null,
        name: "",
        endTime: "",
        comment: "",
        assignee: ""
      },
      maxSize: 10240,
      upload: "/api/system/upload",
      headtoken: {
        userToken: this.$stores.state.token
      },
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-MaterialReport"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-breadcrumb": myBreadcrumb,
    "apply-status-bottom": applyStatusBottom
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.loadTable();
    this.requireMcList();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/enroll/berichten/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击添加
    clickAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-MaterialReport";
    },
    handleAdd() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let tmpObj = { ...this.formData };
      this.$http
        .post("/api/enroll/berichten", tmpObj)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("添加成功");
            // 清空勾选
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击删除
    clickDelete() {
      let sign = true;
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        sign = false;
      }
      this.selectedHistoryList.forEach(el => {
        if (!sign) {
          return;
        }
        if (el.zt === 3 || el.zt === 1) {
          sign = false;
          this.$message.error("审核中/已通过材料不可删");
        }
      });
      if (!sign) {
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleDelete,
        title: "删除信息",
        msgOne: "确定删除已选记录？",
        msgTwo: ""
      });
    },
    handleDelete() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .delete("/api/enroll/berichten", {
          data: this.selectedHistoryList.map(el => el.id)
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("删除成功");
            // 清空勾选
            this.$refs.box.clearSelection();
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    // 点击前往修改页
    clickModify(id) {
      this.modalOption.title = `修改`;
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-MaterialReport";
      this.dataCallBack(id);
    },
    dataCallBack(id) {
      console.log("数据回显");
      this.$http.get(`/api/enroll/berichten/${id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        this.formData = data.data;
        this.formData.lxId += "";
        this.fileList = this.formData.fj.map(el => {
          return { name: el.fileName, url: el.url };
        });
      });
    },
    handleModify() {
      console.log("修改");
      let tmpObj = { ...this.formData };
      this.$http
        .put(`/api/enroll/berichten/${tmpObj.id}`, tmpObj)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("修改成功");
            // 清空勾选
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
        });
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击前往项目详情页
    clickDetail(id, zt) {
      this.modalOption.title = `查看详情`;
      this.modalOption.key = "detail";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-MaterialReport-detail";
      this.dataCallBack(id);
      if (zt === 2) {
        this.requireAduitDetail(id);
      }
    },
    // 表单验证
    testFormData() {
      let sign = true,
        msg = "";
      this.$refs.form.validate(valid => {
        if (!valid) {
          msg = "请填写完整后再尝试保存";
          sign = false;
        }
      });
      return { sign, msg };
    },
    clearFormData() {
      this.$refs.form.resetFields();
      this.fileList = [];
      this.formData = {
        bt: "",
        fj: [],
        lxId: "",
        zw: ""
      };
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearFormData();
      }
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击对话框的确定
    clickOk() {
      let result = this.testFormData();
      if (!result.sign) {
        this.$message.error(result.msg);
        return;
      }
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      if (this.modalOption.key === "add") {
        this.handleAdd();
      } else if (this.modalOption.key === "modify") {
        this.handleModify();
      }
    },
    // 文件上传前校验原附件个数
    handleBeforeUpload(file) {
      if (this.formData.fj.length > 9) {
        this.$message.error("最多上传10个附件");
        return false;
      }
      if (file.size / 1024 > this.maxSize) {
        this.$message.error(`上传文件大小不能超过 ${this.maxSize / 1024}MB!`);
        return false;
      }
    },
    // 文件上传成功的处理函数
    handleUploadSuccess(res) {
      this.formData.fj.push(res.data);
    },
    handleRemoveList(file, fileList) {
      let index = this.formData.fj.findIndex(el => {
        return el.fileName === file.fileName && el.url === file.url;
      });
      this.formData.fj.splice(index, 1);
    },
    handlePreview(file) {
      console.log(file);
      if (file.response) {
        file.url = file.response.data.url;
      }
      let url = file.url;
      console.log(url);
      if (!url) {
        return;
      }
      window.location.href = url;
    },
    // 请求审核历史记录
    requireAduitDetail(id) {
      this.$http.get(`/api/enroll/materialAudit/${id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!Array.isArray(data.data)) {
          console.log("审核历史记录数据获取失败");
          return;
        }
        let tmpObj = data.data[data.data.length - 1];
        this.aduit.status = tmpObj.status;
        this.aduit.endTime = tmpObj.verifytime;
        this.aduit.assignee = tmpObj.auditor;
        this.aduit.name = tmpObj.name;
        this.aduit.comment = tmpObj.comment;
      });
    },
    requireMcList() {
      console.log("获取材料名称列表");
      this.$http.get(`/api/enroll/material/select`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        this.mcList = data.data;
      });
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val;
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  filters: {
    ztValueFilter(val) {
      switch (val) {
        case 1:
          return "通过";
        case 2:
          return "退回";
        case 3:
          return "审核中";
      }
    },
    ztClassFilter(val) {
      switch (val) {
        case 1:
          return "green";
        case 2:
          return "red";
        case 3:
          return "orange";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.MaterialReport {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-MaterialReport-detail,
.modal-MaterialReport {
  width: 500px !important;
  .modal-content {
    padding: 10px;
  }
}
.modal-MaterialReport-detail {
  .el-dialog__footer {
    display: none;
  }
  .el-form-item {
    margin-bottom: 10px;
  }
  /deep/ div.applyStatusBottom {
    margin-top: 0;
  }
  .request-content {
    width: 90%;
    padding: 5px;
    border: 1px solid #ccc;
    height: 180px;
    margin-top: 8px;
    overflow: auto;
  }
}
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
