<template>
  <div class="MaterialTypeSetting">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入材料名称"
          suffix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          style="width:200px;"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('MaterialTypeSetting:add')"
          >添加</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="index"
          align="center"
          label="序号"
          :width="50"
        ></el-table-column>
        <el-table-column
          prop="clmc"
          label="材料名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="pjdja"
          label="上报起止时间"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              >{{ $tagTime(scope.row.kssj, "yyyy.MM.dd 至 ")
              }}{{ $tagTime(scope.row.jssj, "yyyy.MM.dd") }}</span
            >
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" :width="120">
          <template slot-scope="scope">
            <span
              class="orange under-line cursor-pointer"
              @click="clickModify(scope.$index, scope.row.isRelated)"
              v-if="$btnAuthorityTest('MaterialTypeSetting:update')"
              >修改</span
            >
            <span
              v-if="
                $btnAuthorityTest('MaterialTypeSetting:update') &&
                  $btnAuthorityTest('MaterialTypeSetting:delete')
              "
              >|</span
            >
            <template v-if="$btnAuthorityTest('MaterialTypeSetting:delete')">
              <span
                v-if="scope.row.isRelated === 0"
                class="red under-line cursor-pointer"
                @click="clickDelete(scope.row.id)"
                >删除</span
              >
              <span v-else class="grey">删除</span>
            </template>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <el-form
          ref="form"
          :model="formData"
          label-width="130px"
          :rules="rules"
        >
          <el-form-item label="材料名称：" :required="true" prop="clmc">
            <el-input
              v-if="modalOption.isRelated === 0"
              v-model="formData.clmc"
              placeholder="请输入"
              :maxlength="20"
              style="width:270px;"
            ></el-input>
            <span v-else>{{ formData.clmc }}</span>
          </el-form-item>
          <el-form-item label="上报起止时间：" prop="sznj">
            <el-date-picker
              v-model="computedTime"
              type="daterange"
              range-separator="至"
              prefix-icon="el-icon-date"
              style="width:270px;"
              :editable="false"
            ></el-date-picker>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer">
        <el-button @click="clickCancel">取消</el-button>
        <el-button type="primary" @click="clickOk">保存</el-button>
      </div>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "MaterialTypeSetting",
  data() {
    var validateTime = (rule, value, callback) => {
      value = this.computedTime;
      console.log(value);
      if (
        !Array.isArray(value) ||
        value.length !== 2 ||
        value[0] === "" ||
        value[1] === ""
      ) {
        callback(new Error("请选择起止时间"));
      } else {
        callback();
      }
    };
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: ""
      },
      loading: false,
      msgCount: 0,
      tableHeight: null,
      formData: {
        clmc: "",
        jssj: "",
        kssj: "",
        id: ""
      },
      rules: {
        clmc: [{ required: true, message: "请输入材料名称" }],
        sznj: [{ validator: validateTime }]
      },
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-MaterialTypeSetting",
        isRelated: 0
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/enroll/material/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击添加
    clickAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
      this.modalOption.isRelated = 0;
    },
    handleAdd() {
      console.log("保存添加");
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let tmpObj = { ...this.formData };
      this.$http
        .post("/api/enroll/material", tmpObj)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("添加成功");
            // 清空勾选
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击删除
    clickDelete(id) {
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: () => this.handleDelete(id),
        title: "删除信息",
        msgOne: "确定删除已选记录？",
        msgTwo: ""
      });
    },
    handleDelete(id) {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .delete(`/api/enroll/material/${id}`)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("删除成功");
            // 清空勾选
            this.$refs.box.clearSelection();
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    // 表单验证
    testFormData() {
      let sign = true,
        msg = "";
      this.$refs.form.validate(valid => {
        if (!valid) {
          msg = "请填写完整后再尝试保存";
          sign = false;
        }
      });
      return { sign, msg };
    },
    clearFormData() {
      this.$refs.form.resetFields();
      this.formData = {
        clmc: "",
        jssj: "",
        kssj: "",
        id: ""
      };
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearFormData();
      }
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击对话框的确定
    clickOk() {
      let result = this.testFormData();
      if (!result.sign) {
        this.$message.error(result.msg);
        return;
      }
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      if (this.modalOption.key === "add") {
        this.handleAdd();
      } else if (this.modalOption.key === "modify") {
        this.handleModify();
      }
    },
    // 点击前往修改页
    clickModify(index, isRelated) {
      this.modalOption.title = `修改`;
      this.modalOption.key = "modify";
      this.modalOption.isRelated = isRelated;
      this.modalOption.modalVisiabal = true;
      // 数据回显
      let tmpObj = this.tableData[index];
      if (!tmpObj) {
        return;
      }
      this.formData.clmc = tmpObj.clmc;
      this.formData.jssj = tmpObj.jssj;
      this.formData.kssj = tmpObj.kssj;
      this.formData.id = tmpObj.id;
    },
    handleModify() {
      console.log("保存数据");
      let tmpObj = { ...this.formData };
      this.$http
        .put(`/api/enroll/material/${tmpObj.id}`, tmpObj)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("修改成功");
            // 清空勾选
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
        });
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  filters: {
    ztValueFilter(val) {
      switch (val) {
        case 0:
          return "失效";
        case 1:
          return "未发布";
        case 2:
          return "已发布";
      }
    },
    ztClassFilter(val) {
      switch (val) {
        case 0:
          return "red";
        case 1:
          return "orange";
        case 2:
          return "green";
      }
    }
  },
  computed: {
    computedTime: {
      get() {
        if (!this.formData.kssj || !this.formData.jssj) {
          return [];
        }
        return [this.formData.kssj, this.formData.jssj];
      },
      set(arr) {
        if (arr === null) {
          arr = ["", ""];
        }
        this.formData.kssj = arr[0];
        this.formData.jssj = arr[1];
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.MaterialTypeSetting {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-MaterialTypeSetting {
  width: 500px !important;
  .modal-content {
    padding: 10px;
  }
  /deep/ .el-date-editor {
    .el-input__icon {
      line-height: 29px;
    }
    .el-range-separator {
      line-height: 26px;
    }
  }
  [for="sznj"]:before {
    content: "*";
    color: red;
    margin-right: 5px;
  }
}
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
