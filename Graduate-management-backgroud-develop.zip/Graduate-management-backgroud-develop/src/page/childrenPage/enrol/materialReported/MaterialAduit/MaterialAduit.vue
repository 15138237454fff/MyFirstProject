<template>
  <div class="MaterialAduit">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入标题"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.type" @change="initLoadTable">
          <el-option label="全部材料" :value="null"></el-option>
          <el-option
            v-for="item in mcList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAllPass"
          type="primary"
          v-if="$btnAuthorityTest('MaterialAduit:allPass')"
          >一键通过</el-button
        >
        <el-button
          @click="clickAllBack"
          type="danger"
          v-if="$btnAuthorityTest('MaterialAduit:allBack')"
          >一键退回</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        @selection-change="handleSelectionChange"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column type="selection" align="center"></el-table-column>
        <el-table-column
          prop="bt"
          label="标题"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="clmc"
          label="材料名称"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="name"
          label="上报人"
          align="center"
          :width="120"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ `${scope.row.name}(${scope.row.userName})` }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="ssdwmc"
          label="所属单位"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="cjsj"
          label="上报时间"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.cjsj, "yyyy.MM.dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="状态" align="center" :width="120">
          <template slot-scope="scope">
            <span :class="scope.row.zt | ztClassFilter">{{
              scope.row.zt | ztValueFilter
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="nodeName"
          label="操作"
          align="center"
          :width="150"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              v-if="$btnAuthorityTest('MaterialAduit:view')"
              @click="clickDetail(scope.row.id, scope.row.zt)"
              >查看详情</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <template v-if="modalOption.key === 'allBack'">
        <div class="modal-content">
          <span>是否不通过所有已选记录？</span>
          <span class="required">请输入不通过原因：</span>
          <el-input
            v-model="formData.reason"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 4 }"
          ></el-input>
        </div>
        <p slot="footer">
          <el-button size="small" @click="clickCancel">取消</el-button>
          <el-button size="small" type="primary" @click="clickOk"
            >提交</el-button
          >
        </p>
      </template>
      <template v-else>
        <div class="modal-content">
          <el-form ref="form" :model="formData" label-width="100px">
            <el-form-item label="材料名称：">
              <span>{{ getListValue(formData.lxId, mcList) }}</span>
            </el-form-item>
            <el-form-item label="标 题：">
              <span>{{ formData.bt }}</span>
            </el-form-item>
            <el-form-item label="上报人：">
              <span>{{ `${formData.name}(${formData.userName})` }}</span>
            </el-form-item>
            <el-form-item label="正 文：">
              <div class="request-content">
                {{ formData.zw }}
              </div>
            </el-form-item>
            <el-form-item label="附件：">
              <span v-for="(item, index) of formData.fj" :key="index"
                ><a
                  :href="item.url"
                  class="under-line blue"
                  target="_blank"
                  :download="formData.fileName"
                  >{{ item.fileName }}</a
                ><span v-if="index !== formData.fj.length - 1">，</span></span
              >
            </el-form-item>
          </el-form>
          <el-input
            v-if="modalOption.key === 'waitAduit'"
            v-model="formData.reason"
            placeholder="请输入审核意见"
            :maxlength="500"
            type="textarea"
            :autosize="{ minRows: 3, maxRows: 4 }"
          ></el-input>
        </div>
        <p slot="footer">
          <el-button size="small" type="danger" @click="clickBack"
            >退回</el-button
          >
          <el-button size="small" type="primary" @click="clickPass"
            >通过</el-button
          >
        </p>
      </template>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "MaterialAduit",
  data() {
    return {
      tableData: [],
      formData: {
        id: "",
        bt: "",
        fj: [],
        lxId: "",
        zw: "",
        name: "",
        userName: "",
        reason: ""
      },
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        type: null
      },
      loading: false,
      mcList: [],
      msgCount: 0,
      selectedHistoryList: [],
      tableHeight: null,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-MaterialAduit"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-modal": myModal
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
    this.loadTable();
    this.requireMcList();
  },
  methods: {
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val;
    },
    clickAllPass() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleAllPass,
        title: "一键通过",
        msgOne: "是否通过所有已选记录？",
        msgTwo: ""
      });
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击对话框的确定
    clickOk() {
      if (this.formData.reason === "") {
        this.$message.error("请填写退回意见后再尝试提交");
        return;
      }
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      this.handleAllBack();
    },
    handleAllBack() {
      console.log(this.selectedHistoryList.map(el => el.id));
      this.handleAduit(
        2,
        this.selectedHistoryList.map(el => el.id),
        this.formData.reason
      );
    },
    handleAllPass() {
      this.handleAduit(
        1,
        this.selectedHistoryList.map(el => el.id),
        ""
      );
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    clickAllBack() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      this.modalOption.title = `一键退回`;
      this.modalOption.key = "allBack";
      this.modalOption.className = "modal-MaterialAduit-allBack";
      this.modalOption.modalVisiabal = true;
    },
    clickPass() {
      console.log("通过");
      this.modalOption.modalVisiabal = false;
      this.handleAduit(1, [this.formData.id], this.formData.reason);
    },
    clickBack() {
      console.log(this.formData.reason);
      if (this.formData.reason === "") {
        this.$message.error("请填写退回意见后再尝试提交");
        return;
      }
      this.modalOption.modalVisiabal = false;
      this.handleAduit(2, [this.formData.id], this.formData.reason);
    },
    handleAduit(status, ids, reason) {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/enroll/materialAudit/audit", {
          ids: ids,
          comment: reason,
          status: status
        })
        .then(res => {
          loading.close();
          this.formData.reason = "";
          if (res.data.code !== 200) {
            this.$message.error(res.data.message);
            return;
          }
          this.$message.success(res.data.message);
          // 清空勾选
          this.$refs.box.clearSelection();
          this.initLoadTable();
        })
        .catch(error => {
          loading.close();
          console.error(error.message);
        });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/enroll/materialAudit/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    clearFormData() {
      this.formData = {
        id: "",
        bt: "",
        fj: [],
        lxId: "",
        zw: "",
        name: "",
        userName: "",
        reason: ""
      };
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    requireMcList() {
      console.log("获取材料名称列表");
      this.$http.get(`/api/enroll/material/select`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        this.mcList = data.data;
      });
    },
    // 点击查看详情
    clickDetail(id, zt) {
      this.modalOption.title = `查看详情`;
      if (zt === 3) {
        this.modalOption.key = "waitAduit";
        this.modalOption.className = "modal-MaterialAduit-waitAduit";
      } else {
        this.modalOption.key = "aduited";
        this.modalOption.className = "modal-MaterialAduit-aduited";
      }
      this.dataCallBack(id);
      this.modalOption.modalVisiabal = true;
    },
    dataCallBack(id) {
      console.log("数据回显");
      this.$http.get(`/api/enroll/berichten/${id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        Object.keys(data.data).forEach(key => {
          this.formData[key] = data.data[key];
        });
      });
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  filters: {
    ztValueFilter(val) {
      switch (val) {
        case 1:
          return "通过";
        case 2:
          return "退回";
        case 3:
          return "审核中";
      }
    },
    ztClassFilter(val) {
      switch (val) {
        case 1:
          return "green";
        case 2:
          return "red";
        case 3:
          return "orange";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.MaterialAduit {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-MaterialAduit-allBack {
  width: 380px !important;
  .modal-content {
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 10px;
    span {
      margin-bottom: 7px;
    }
  }
}
.modal-MaterialAduit-waitAduit,
.modal-MaterialAduit-aduited {
  width: 500px;
  .modal-content {
    padding: 10px;
  }
  .el-form-item {
    margin-bottom: 10px;
  }
  .request-content {
    width: 90%;
    padding: 5px;
    border: 1px solid #ccc;
    height: 180px;
    margin-top: 8px;
    overflow: auto;
  }
}
.modal-MaterialAduit-aduited {
  .el-dialog__footer {
    display: none;
  }
}
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 12px;
  }
}
</style>
