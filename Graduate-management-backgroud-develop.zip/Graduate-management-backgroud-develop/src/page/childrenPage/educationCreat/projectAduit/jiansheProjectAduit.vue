<template>
  <!-- 培养计划审核 trainPlanAudit -->
  <div class="jiansheProjectAduit">
    <el-tabs v-model="activeTab" @tab-click="tabClick">
      <el-tab-pane label="待审核" name="waitAduit">
        <project-aduit-for-wait-aduit
          v-if="activeTab === 'waitAduit'"
        ></project-aduit-for-wait-aduit>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="aduited">
        <project-aduit-for-aduited
          v-if="activeTab === 'aduited'"
        ></project-aduit-for-aduited>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import projectAduitForWaitAduit from "./projectAduitForWaitAduit";
import projectAduitForAduited from "./projectAduitForAduited";
export default {
  name: "jiansheProjectAduit",
  components: {
    "project-aduit-for-wait-aduit": projectAduitForWaitAduit,
    "project-aduit-for-aduited": projectAduitForAduited
  },
  data() {
    return {
      activeTab: "waitAduit"
    };
  },
  created() {
    // 如果路由传参了指定页，则展示指定页
    if (this.$route.query.activeTab) {
      this.activeTab = this.$route.query.activeTab;
    }
  },
  methods: {
    // tab切换
    tabClick(t) {}
  }
};
</script>

<style lang="scss" scoped>
.jiansheProjectAduit {
  /deep/ .el-tabs__nav-wrap {
    background: #fff;
  }
  /deep/ .el-tabs__nav {
    margin-left: 12px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin-bottom: 10px;
  }
}
</style>
