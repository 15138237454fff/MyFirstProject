<template>
  <div class="projectAduitForWaitAduit">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称/申请人"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.status" @change="initLoadTable">
          <el-option
            v-for="item in typeOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAllPass"
          type="primary"
          v-if="$btnAuthorityTest('jiansheProjectAduit:allPass')"
          >一键通过</el-button
        >
        <el-button
          @click="clickAllBack"
          type="danger"
          v-if="$btnAuthorityTest('jiansheProjectAduit:allBack')"
          >一键退回</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        @selection-change="handleSelectionChange"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column type="selection" align="center"></el-table-column>
        <el-table-column
          prop="projectName"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="projectType"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ getListValue(scope.row.projectType, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="name"
          label="申请人"
          align="center"
          :width="120"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="collegeName"
          label="所属学院"
          align="center"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="applyDate"
          label="申请时间"
          align="center"
          :width="120"
        >
        </el-table-column>
        <el-table-column
          prop="nodeName"
          label="当前审核环节"
          align="center"
          :width="150"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              v-if="$btnAuthorityTest('jiansheProjectAduit:audit')"
              @click="
                clickToApplay(
                  scope.row.projectType,
                  scope.row.executionId,
                  scope.row.taskId,
                  scope.row.nodeName,
                  scope.row.collegeNum
                )
              "
              >{{ scope.row.nodeName }}</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <span>是否退回所有已选申请？</span>
        <span class="required">请输入退回原因：</span>
        <el-input
          v-model="formData.reason"
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 4 }"
        ></el-input>
      </div>
      <p slot="footer">
        <el-button size="small" @click="clickCancel">取消</el-button>
        <el-button size="small" type="primary" @click="clickOk">提交</el-button>
      </p>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "projectAduitForWaitAduit",
  data() {
    return {
      tableData: [],
      formData: {
        reason: ""
      },
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        status: null
      },
      loading: false,
      typeOptions: [
        {
          label: "全部项目",
          value: null
        },
        {
          label: "硕士研究生课程建设项目",
          value: 1
        },
        {
          label: "博士研究生课程建设项目",
          value: 2
        },
        {
          label: "专业学位研究生课程案例库建设项目",
          value: 3
        },
        {
          label: "田野调查基金项目",
          value: 4
        },
        {
          label: "校级研究生科研项目",
          value: 5
        },
        {
          label: "知行浙江社会调研项目",
          value: 6
        }
      ],
      msgCount: 0,
      selectedHistoryList: [],
      tableHeight: null,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-projectAduitForWaitAduit"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-modal": myModal
  },
  mounted() {
    this.loadTable();
    this.tableHeight = document.documentElement.clientHeight - 280;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 280;
      })();
    };
  },
  computed: {
    // tableHeight() {
    //   return this.$store.getters.getTableHeight - 60;
    // }
  },
  methods: {
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val.map(item => {
        return item.taskId;
      });
    },
    clickAllPass() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleAllPass,
        title: "一键通过",
        msgOne: "是否通过所有已选项目？",
        msgTwo: ""
      });
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击对话框的确定
    clickOk() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      this.handleAllBack();
    },
    handleAllBack() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put("/api/education/process/batchBack", {
          taskIds: this.selectedHistoryList,
          comment: this.formData.reason
        })
        .then(res => {
          loading.close();
          this.formData.reason = "";
          if (res.data.code !== 200) {
            this.$message.error(res.data.message);
            return;
          }
          this.$message.success(res.data.message);

          // 清空勾选
          this.$refs.box.clearSelection();
          this.initLoadTable();
        })
        .catch(error => {
          loading.close();
          console.error(error.message);
        });
    },
    handleAllPass() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put("/api/education/process/batchPass", this.selectedHistoryList)
        .then(res => {
          loading.close();
          if (res.data.code !== 200) {
            this.$message.error(res.data.message);
            return;
          }
          this.$message.success(res.data.message);
          // 清空勾选
          this.$refs.box.clearSelection();
          this.initLoadTable();
        })
        .catch(error => {
          console.error(error.message);
          loading.close();
        });

      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    clickAllBack() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      this.modalOption.title = `一键退回`;
      this.modalOption.modalVisiabal = true;
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/process/admin/toAudit/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.info)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.info;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击前往审核页
    clickToApplay(type, id, taskId, nodeName, collegeNum) {
      var transmit = 0;
      if (nodeName === "学院秘书审核") {
        transmit = 1;
      }
      this.$router.push(
        `/projectAduitAdd/${type}/${id}/${taskId}/${transmit}/${collegeNum}`
      );
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.projectReport {
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-projectAduitForWaitAduit {
  width: 380px !important;
  .modal-content {
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 10px;
    span {
      margin-bottom: 7px;
    }
  }
}
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 12px;
  }
}
</style>
