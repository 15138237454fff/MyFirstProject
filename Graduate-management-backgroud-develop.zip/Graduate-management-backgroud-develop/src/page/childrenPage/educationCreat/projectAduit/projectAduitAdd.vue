<template>
  <div class="myProjectDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
    >
      <project-detail-ssyjskcjsxm
        v-if="type === '1'"
      ></project-detail-ssyjskcjsxm>
      <project-detail-bsyjskcjsxm
        v-if="type === '2'"
      ></project-detail-bsyjskcjsxm>
      <project-detail-kcalkjsxm v-if="type === '3'"></project-detail-kcalkjsxm>
      <project-detail-tydcjjxm v-if="type === '4'"></project-detail-tydcjjxm>
      <project-detail-xjyjskyxm v-if="type === '5'"></project-detail-xjyjskyxm>
      <project-detail-zxzjshdyxm
        v-if="type === '6'"
      ></project-detail-zxzjshdyxm>
      <apply-status :aduitList="aduitList"></apply-status>
      <audit-submit
        @submit="handleSubmit"
        v-if="transmit === '0'"
      ></audit-submit>
      <div class="xymscd" v-else>
        <div class="dashed"></div>
        <div>
          <div class="xymscd-area">
            <span class="required">选择学院领导：</span>
            <el-select v-model="formData.type">
              <el-option
                v-for="(item, index) in typeOptions"
                :key="index"
                :label="`${item.userName}(${item.name})`"
                :value="item.userName"
              ></el-option>
            </el-select>
          </div>
          <el-button type="primary" @click="clickSubmit">提交</el-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import projectDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/projectDetailForSSYJSKCJSXM";
import projectDetailForBSYJSKCJSXM from "@/components/jiansheProject/detail/projectDetailForBSYJSKCJSXM";
import projectDetailForKCALKJSXM from "@/components/jiansheProject/detail/projectDetailForKCALKJSXM";
import projectDetailForTYDCJJXM from "@/components/jiansheProject/detail/projectDetailForTYDCJJXM";
import projectDetailForXJYJSKYXM from "@/components/jiansheProject/detail/projectDetailForXJYJSKYXM";
import projectDetailForZXZJSHDYXM from "@/components/jiansheProject/detail/projectDetailForZXZJSHDYXM";
import applyStatus from "@/components/skb/applyStatus";
import auditSubmit from "@/components/skb/aduitSubmit";
export default {
  name: "myProjectDetail",
  props: {
    type: {
      type: String
    },
    id: {
      type: String
    },
    taskId: {
      type: String
    },
    collegeNum: {
      type: String
    },
    transmit: {
      type: String
    }
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-detail-ssyjskcjsxm": projectDetailForSSYJSKCJSXM,
    "project-detail-bsyjskcjsxm": projectDetailForBSYJSKCJSXM,
    "project-detail-kcalkjsxm": projectDetailForKCALKJSXM,
    "project-detail-tydcjjxm": projectDetailForTYDCJJXM,
    "project-detail-xjyjskyxm": projectDetailForXJYJSKYXM,
    "project-detail-zxzjshdyxm": projectDetailForZXZJSHDYXM,
    "apply-status": applyStatus,
    "audit-submit": auditSubmit
  },
  data() {
    return {
      loading: false,
      detailPathForSSYJSKCJSXM: "curriculum",
      detailPathForBSYJSKCJSXM: "doctoral",
      detailPathForKCALKJSXM: "casebase",
      detailPathForTYDCJJXM: "fieldwork",
      detailPathForXJYJSKYXM: "university",
      detailPathForZXZJSHDYXM: "social",
      updatePathForSSYJSKCJSXM: "jiansheProject/updateFormDataForSSYJSKCJSXM",
      updatePathForBSYJSKCJSXM: "jiansheProject/updateFormDataForBSYJSKCJSXM",
      updatePathForKCALKJSXM: "jiansheProject/updateFormDataForKCALKJSXM",
      updatePathForTYDCJJXM: "jiansheProject/updateFormDataForTYDCJJXM",
      updatePathForXJYJSKYXM: "jiansheProject/updateFormDataForXJYJSKYXM",
      updatePathForZXZJSHDYXM: "jiansheProject/updateFormDataForZXZJSHDYXM",
      aduitList: [],
      typeOptions: [],
      formData: {}
    };
  },
  mounted() {
    this.dataCallBack();
    this.requireAduitDetail();
    if (this.transmit === "1") {
      this.getCollegeLeadSelect();
    }
  },
  methods: {
    // 获取学院领导下拉框
    getCollegeLeadSelect() {
      this.$http
        .get(`/api/system/role/collegeLead/select?yxsh=${this.collegeNum}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.typeOptions = data.data;
        });
    },
    dataCallBack() {
      switch (this.type) {
        case "1":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "2":
          this.requirePorjectDetail(
            this.detailPathForBSYJSKCJSXM,
            this.updatePathForBSYJSKCJSXM
          );
          return;
        case "3":
          this.requirePorjectDetail(
            this.detailPathForKCALKJSXM,
            this.updatePathForKCALKJSXM
          );
          return;
        case "4":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "5":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
          return;
        case "6":
          this.requirePorjectDetail(
            this.detailPathForZXZJSHDYXM,
            this.updatePathForZXZJSHDYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(data.data);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http.get(`/api/education/process/history/${this.id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!Array.isArray(data.data)) {
          console.log("审核历史记录数据获取失败");
          return;
        }
        this.aduitList = data.data;
      });
    },
    goBack() {
      this.$router.push(`/jiansheProjectAduit`);
    },
    handleSubmit(obj) {
      const loading = this.$loading({
        lock: true,
        text: "提交审核中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(`/api/education/process/audit`, {
          taskId: this.taskId,
          lcid: this.id,
          check: obj.status,
          comment: obj.comment,
          type: "1" // 后端标志
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success(data.message);
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    }, // 点击提交审核
    clickSubmit() {
      const loading = this.$loading({
        lock: true,
        text: "提交审核中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(`/api/education/process/transmit`, {
          taskId: this.taskId,
          userName: this.formData.type
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success(data.message);
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.myProjectDetail {
  padding-top: 10px;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
  .xymscd {
    .dashed {
      margin-top: 25px;
      margin-bottom: 20px;
      height: 1px;
      background: linear-gradient(
        to right,
        rgba(204, 204, 204, 1),
        rgba(204, 204, 204, 1) 5px,
        transparent 5px,
        transparent
      );
      background-size: 10px 100%;
    }
    font-size: 14px;
    .el-select {
      width: 300px;
      line-height: 34px;
    }
    .xymscd-area {
      margin-bottom: 22px;
    }
    .el-button {
      width: 200px;
      margin-left: 115px;
    }
  }
}
</style>
