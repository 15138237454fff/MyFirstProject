<template>
  <div class="projectStatistical">
    <div class="title">教育建设项目申报人数统计分析</div>
    <div class="project-box">
      <div style="width:240px;">
        <span>项目类型</span>
        <div class="border-right">
          <div v-for="(item, index) of typeOptions" :key="index">
            {{ item.label }}
          </div>
        </div>
      </div>
      <div style="width:150px;">
        <span>申报对象</span>
        <div>
          <div v-for="(item, index) of typeOptions" :key="index" class="blue">
            {{ item.value | dxFilter }}
          </div>
        </div>
      </div>
      <div ref="echartProject" style="width:500px"></div>
      <div style="width:150px;">
        <span>申报人数</span>
        <div class="border-right">
          <div v-for="(item, index) of result[0]" :key="index">
            {{ item }}人
          </div>
        </div>
      </div>
      <div style="width:150px;">
        <span>立项人数</span>
        <div class="border-right">
          <div v-for="(item, index) of result[1]" :key="index">
            {{ item }}人
          </div>
        </div>
      </div>
      <div style="width:150px;">
        <span>立项率</span>
        <div>
          <div v-for="(item, index) of result[0]" :key="index" class="blue">
            <span v-if="item !== 0">
              {{ ((result[1][index] / item) * 100).toFixed(0) }}%
            </span>
            <span v-else>0</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
var echarts = require("echarts");
export default {
  name: "projectStatistical",
  data() {
    return {
      result: [],
      typeOptions: [
        {
          label: "硕士研究生课程建设项目",
          value: 1
        },
        {
          label: "博士研究生课程建设项目",
          value: 2
        },
        {
          label: "专业学位研究生课程案例库建设项目",
          value: 3
        },
        {
          label: "田野调查基金项目",
          value: 4
        },
        {
          label: "校级研究生科研项目",
          value: 5
        },
        {
          label: "知行浙江社会调研项目",
          value: 6
        }
      ]
    };
  },
  mounted() {
    this.requireDetail();
  },
  methods: {
    requireDetail() {
      this.$http.get("/api/education/statistic/apply").then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        data = data.data;
        this.result = data;
        this.drawBar();
      });
    },
    drawBar() {
      if (!this.result[0]) {
        return;
      }
      let myChart = echarts.init(this.$refs.echartProject),
        data = this.result[0];
      const option = {
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "line" // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        legend: {
          orient: "vertical",
          x: "right",
          data: []
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true
        },
        color: [
          "#c6e3ff",
          "#71b8ff",
          "#4da6ff",
          "#178bff",
          "#0061c1",
          "#005097"
        ],
        xAxis: [
          {
            type: "value",
            splitLine: {
              show: false
            },
            show: false
          }
        ],
        yAxis: [
          {
            type: "category",
            data: [],
            axisLabel: {
              interval: 0,
              rotate: 30
            },
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "申报人数统计",
            type: "bar",
            stack: "chart",

            itemStyle: {
              // 通常情况下：
              normal: {
                // 每个柱子的颜色即为colorList数组里的每一项，如果柱子数目多于colorList的长度，则柱子颜色循环使用该数组
                color: function(params) {
                  var colorList = [
                    "#c6e3ff",
                    "#71b8ff",
                    "#4da6ff",
                    "#178bff",
                    "#0061c1",
                    "#005097"
                  ];
                  return colorList[params.dataIndex];
                }
              }
            },
            data: data
          }
        ]
      };
      myChart.setOption(option);
      window.addEventListener("resize", function() {
        myChart.resize();
      });
    }
  },
  filters: {
    dxFilter(val) {
      return val <= 3 ? "教职工" : "学生";
    }
  }
};
</script>
<style lang="scss" scoped>
.projectStatistical {
  padding: 40px;
  .title {
    font-size: 24px;
    font-weight: bold;
  }
  .project-box {
    font-size: 14px;
    display: flex;
    margin-top: 70px;
    height: calc(100vh - 450px);
    justify-content: space-between;
    & > div {
      display: flex;
      flex-direction: column;
      &:not(:last-child) {
        margin-right: 10px;
      }
      & > span:first-child {
        font-weight: bold;
        margin-bottom: 66px;
        display: inline-block;
      }
      & > div {
        padding: 0 10px 0px 0;
        margin-bottom: 60px;
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        &.border-right {
          border-right: 2px dashed #e4e4e4;
        }
      }
    }
  }
}
</style>
