<template>
  <!-- 培养计划审核 trainPlanAudit -->
  <div class="projectApproval">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="待立项" name="waitSetUp">
        <project-approval-for-wait-setup
          v-if="activeTab === 'waitSetUp'"
        ></project-approval-for-wait-setup>
      </el-tab-pane>
      <el-tab-pane label="已立项" name="setuped">
        <project-approval-for-setuped
          v-if="activeTab === 'setuped'"
        ></project-approval-for-setuped>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import projectApprovalForWaitSetUp from "./projectApprovalForWaitSetUp";
import projectApprovalForSetUped from "./projectApprovalForSetUped";
export default {
  name: "projectApproval",
  components: {
    "project-approval-for-wait-setup": projectApprovalForWaitSetUp,
    "project-approval-for-setuped": projectApprovalForSetUped
  },
  data() {
    return {
      activeTab: "waitSetUp"
    };
  },
  created() {
    // 如果路由传参了指定页，则展示指定页
    if (this.$route.query.activeTab) {
      this.activeTab = this.$route.query.activeTab;
    }
  }
};
</script>

<style lang="scss" scoped>
.projectApproval {
  /deep/ .el-tabs__nav-wrap {
    background: #fff;
  }
  /deep/ .el-tabs__nav {
    margin-left: 12px;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin-bottom: 10px;
  }
}
</style>
