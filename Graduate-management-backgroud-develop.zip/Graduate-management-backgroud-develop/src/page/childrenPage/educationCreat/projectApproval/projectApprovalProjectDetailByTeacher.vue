<template>
  <div class="projectApprovalProjectDetailByTeacher">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <project-detail-ssyjskcjsxm
        v-if="type === '1'"
      ></project-detail-ssyjskcjsxm>
      <project-detail-bsyjskcjsxm
        v-if="type === '2'"
      ></project-detail-bsyjskcjsxm>
      <project-detail-kcalkjsxm v-if="type === '3'"></project-detail-kcalkjsxm>
      <project-detail-tydcjjxm v-if="type === '4'"></project-detail-tydcjjxm>
      <project-detail-xjyjskyxm v-if="type === '5'"></project-detail-xjyjskyxm>
      <project-detail-zxzjshdyxm
        v-if="type === '6'"
      ></project-detail-zxzjshdyxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import projectDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/projectDetailForSSYJSKCJSXM";
import projectDetailForBSYJSKCJSXM from "@/components/jiansheProject/detail/projectDetailForBSYJSKCJSXM";
import projectDetailForKCALKJSXM from "@/components/jiansheProject/detail/projectDetailForKCALKJSXM";
import projectDetailForTYDCJJXM from "@/components/jiansheProject/detail/projectDetailForTYDCJJXM";
import projectDetailForXJYJSKYXM from "@/components/jiansheProject/detail/projectDetailForXJYJSKYXM";
import projectDetailForZXZJSHDYXM from "@/components/jiansheProject/detail/projectDetailForZXZJSHDYXM";
export default {
  name: "projectApprovalProjectDetailByTeacher",
  props: {
    type: {
      type: String
    },
    id: {
      type: String
    }
  },
  data() {
    return {
      detailPathForSSYJSKCJSXM: "curriculum",
      detailPathForBSYJSKCJSXM: "doctoral",
      detailPathForKCALKJSXM: "casebase",
      detailPathForTYDCJJXM: "fieldwork",
      detailPathForXJYJSKYXM: "university",
      detailPathForZXZJSHDYXM: "social",
      updatePathForSSYJSKCJSXM: "jiansheProject/updateFormDataForSSYJSKCJSXM",
      updatePathForBSYJSKCJSXM: "jiansheProject/updateFormDataForBSYJSKCJSXM",
      updatePathForKCALKJSXM: "jiansheProject/updateFormDataForKCALKJSXM",
      updatePathForTYDCJJXM: "jiansheProject/updateFormDataForTYDCJJXM",
      updatePathForXJYJSKYXM: "jiansheProject/updateFormDataForXJYJSKYXM",
      updatePathForZXZJSHDYXM: "jiansheProject/updateFormDataForZXZJSHDYXM"
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-detail-ssyjskcjsxm": projectDetailForSSYJSKCJSXM,
    "project-detail-bsyjskcjsxm": projectDetailForBSYJSKCJSXM,
    "project-detail-kcalkjsxm": projectDetailForKCALKJSXM,
    "project-detail-tydcjjxm": projectDetailForTYDCJJXM,
    "project-detail-xjyjskyxm": projectDetailForXJYJSKYXM,
    "project-detail-zxzjshdyxm": projectDetailForZXZJSHDYXM
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "1":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "2":
          this.requirePorjectDetail(
            this.detailPathForBSYJSKCJSXM,
            this.updatePathForBSYJSKCJSXM
          );
          return;
        case "3":
          this.requirePorjectDetail(
            this.detailPathForKCALKJSXM,
            this.updatePathForKCALKJSXM
          );
          return;
        case "4":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "5":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
          return;
        case "6":
          this.requirePorjectDetail(
            this.detailPathForZXZJSHDYXM,
            this.updatePathForZXZJSHDYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(data.data);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.projectApprovalProjectDetailByTeacher {
  padding-top: 10px;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
