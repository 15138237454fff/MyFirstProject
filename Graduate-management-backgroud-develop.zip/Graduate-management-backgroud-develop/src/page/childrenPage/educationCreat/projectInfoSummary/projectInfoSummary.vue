<template>
  <div class="projectInfoSummary">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称/申请人"
          suffix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          style="width:200px;"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.xmlx" @change="initLoadTable">
          <el-option
            v-for="(item, index) in typeOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        ref="box"
      >
        <el-table-column
          type="index"
          label="序号"
          align="center"
          :width="50"
        ></el-table-column>
        <el-table-column
          prop="xmMc"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="xmlx"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ getListValue(scope.row.xmlx, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="xm"
          label="申请人"
          align="center"
          :width="150"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="yxsmc"
          label="所属学院"
          align="center"
          :width="150"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="lxsj"
          label="立项时间"
          align="center"
          :width="120"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.lxsj, "yyyy-MM-dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="pjrk"
          label="项目详情"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span
              v-if="$btnAuthorityTest('projectInfoSummary:view')"
              class="blue under-line cursor-pointer"
              @click="clickToProjectDetail(scope.row.xmlx, scope.row.lcid)"
              >项目详情</span
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="pjrk"
          label="结题报告"
          align="center"
          :width="120"
        >
          <template
            slot-scope="scope"
            v-if="$btnAuthorityTest('projectInfoSummary:view')"
          >
            <span v-if="!xmlxFilter(scope.row.xmlx)">无结题</span>
            <span
              class="blue under-line cursor-pointer"
              v-else
              @click="
                clickToDetail(scope.row.xmlx, scope.row.lcid, scope.row.zt)
              "
              >结题报告</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "projectInfoSummary",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        xmlx: null
      },
      typeOptions: [
        { label: "全部项目", value: null },
        { label: "硕士研究生课程建设项目", value: "1" },
        { label: "博士研究生课程建设项目", value: "2" },
        { label: "专业学位研究生课程案例库建设项目", value: "3" },
        {
          label: "田野调查基金项目",
          value: "4"
        },
        {
          label: "校级研究生科研项目",
          value: "5"
        },
        {
          label: "知行浙江社会调研项目",
          value: "6"
        }
      ],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/setUp/setUpList", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击前往项目详情页
    clickToProjectDetail(type, id) {
      this.$router.push(
        `/projectInfoSummaryProjectDetailByTeacher/${type}/${id}`
      );
    },
    // 点击前往审核页
    clickToDetail(type, id, zt) {
      if (zt !== 1) {
        this.$message.warning("暂未结题");
        return;
      }
      this.$router.push(`/projectInfoSummaryDetail/${type}/${id}`);
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    },
    xmlxFilter(val) {
      val = parseInt(val);
      console.log(val);
      switch (val) {
        case 1:
          return true;
        case 4:
          return true;
        case 5:
          return true;
        default:
          return false;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.projectInfoSummary {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
