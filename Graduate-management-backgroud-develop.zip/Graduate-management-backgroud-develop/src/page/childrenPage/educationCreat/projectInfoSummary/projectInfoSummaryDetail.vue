<template>
  <div class="conclusionAduitDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <conclusion-detail-for-tydcjjxm
        v-if="type === '4'"
        :lcid="id"
      ></conclusion-detail-for-tydcjjxm>
      <conclusion-detail-for-xjyjskyxm
        v-if="type === '5'"
        :lcid="id"
      ></conclusion-detail-for-xjyjskyxm>
      <conclusion-detail-for-ssyjskcjsxm
        v-if="type === '1'"
        :lcid="id"
      ></conclusion-detail-for-ssyjskcjsxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import conclusionDetailForTYDCJJXM from "@/components/jiansheProject/detail/conclusionDetailForTYDCJJXM";
import conclusionDetailForXJYJSKYXM from "@/components/jiansheProject/detail/conclusionDetailForXJYJSKYXM";
import conclusionDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/conclusionDetailForSSYJSKCJSXM";
import applyStatus from "@/components/skb/applyStatus";
export default {
  name: "conclusionAduitDetail",
  props: {
    type: {
      type: String
    },
    id: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "conclusion-detail-for-tydcjjxm": conclusionDetailForTYDCJJXM,
    "conclusion-detail-for-xjyjskyxm": conclusionDetailForXJYJSKYXM,
    "conclusion-detail-for-ssyjskcjsxm": conclusionDetailForSSYJSKCJSXM,
    "apply-status": applyStatus
  },
  data() {
    return {
      detailPathForTYDCJJXM: "fieldworkTask",
      detailPathForXJYJSKYXM: "universityTask",
      detailPathForSSYJSKCJSXM: "classEstablish",
      updatePathForTYDCJJXM:
        "jiansheProject/updateFormDataIsConclusionForTYDCJJXM",
      updatePathForXJYJSKYXM:
        "jiansheProject/updateFormDataIsConclusionForXJYJSKYXM",
      updatePathForSSYJSKCJSXM:
        "jiansheProject/updateFormDataIsConclusionForSSYJSKCJSXM"
    };
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    goBack() {
      this.$router.push(`/projectInfoSummary`);
    },
    dataCallBack() {
      switch (this.type) {
        case "1":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "4":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "5":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(data.data);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAduitDetail {
  padding-top: 10px;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
