<template>
  <div class="projectPublish">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称"
          suffix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.xmmc"
          @keyup.enter.native="initLoadTable"
          style="width:200px;"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.xmlx" @change="initLoadTable">
          <el-option
            v-for="(item, index) in typeOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.zt" @change="initLoadTable">
          <el-option
            v-for="(item, index) in ztOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('projectPublish:add')"
          >添加</el-button
        >
        <el-button
          @click="clickDelete"
          type="danger"
          v-if="$btnAuthorityTest('projectPublish:delete')"
          >删除</el-button
        >
        <el-button
          @click="clickPublish"
          :plain="true"
          type="primary"
          v-if="!isPublish && $btnAuthorityTest('projectPublish:publish')"
          >发布</el-button
        >
        <el-button
          @click="clickUnPublish"
          :plain="true"
          type="primary"
          v-else-if="isPublish && $btnAuthorityTest('projectPublish:publish')"
          >取消发布</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="$storage.tableHeaderColor"
        :height="tableHeight"
        @selection-change="handleSelectionChange"
        v-loading="loading"
        element-loading-text="加载中"
        element-loading-spinner="el-icon-loading"
        ref="box"
      >
        <el-table-column
          type="selection"
          align="center"
          :width="50"
        ></el-table-column>
        <el-table-column
          prop="xmMc"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="xmlx"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ getListValue(scope.row.xmlx, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="fbdx"
          label="发布对象"
          align="center"
          :width="100"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.fbdx === 1 ? "学生" : "教职工" }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="pjdja"
          label="有效时间"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              >{{ $tagTime(scope.row.yssjKssj, "yyyy.MM.dd 至 ")
              }}{{ $tagTime(scope.row.yssjJssj, "yyyy.MM.dd") }}</span
            >
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="状态" align="center" :width="120">
          <template slot-scope="scope">
            <span :class="scope.row.zt | ztClassFilter">{{
              scope.row.zt | ztValueFilter
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" :width="120">
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              @click="clickToDetail(scope.row.xmId)"
              v-if="$btnAuthorityTest('projectPublish:view')"
              >查看</span
            >
            <template v-if="scope.row.zt !== 2">
              <span v-if="$btnAuthorityTest('projectPublish:update')">|</span>
              <span
                class="orange under-line cursor-pointer"
                @click="clickToModify(scope.row.xmId)"
                v-if="$btnAuthorityTest('projectPublish:update')"
                >修改</span
              >
            </template>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/skb/myPagination";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import myModal from "@/components/skb/myModal";
export default {
  name: "projectPublish",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        xmmc: "",
        xmlx: null,
        zt: null
      },
      loading: false,
      selectedHistoryList: [],
      typeOptions: [
        { label: "全部项目", value: null },
        { label: "硕士研究生课程建设项目", value: "1" },
        { label: "博士研究生课程建设项目", value: "2" },
        { label: "专业学位研究生课程案例库建设项目", value: "3" },
        {
          label: "田野调查基金项目",
          value: "4"
        },
        {
          label: "校级研究生科研项目",
          value: "5"
        },
        {
          label: "知行浙江社会调研项目",
          value: "6"
        }
      ],
      ztOptions: [
        { label: "全部状态", value: null },
        { label: "失效", value: 0 },
        { label: "未发布", value: 1 },
        { label: "已发布", value: 2 }
      ],
      msgCount: 0,
      tableHeight: null
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.tableHeight = document.documentElement.clientHeight - 240;
    window.onresize = () => {
      return (() => {
        this.tableHeight = document.documentElement.clientHeight - 240;
      })();
    };
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/projectPublish/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击添加
    clickAdd() {
      this.$router.push("/projectPublishAdd");
    },
    // 点击删除
    clickDelete() {
      let sign = true;
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        sign = false;
      }
      this.selectedHistoryList.forEach(el => {
        if (!sign) {
          return;
        }
        if (el.zt === 2) {
          sign = false;
          this.$message.error("项目已发布，不可删除！");
        }
      });
      if (!sign) {
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleDelete,
        title: "删除信息",
        msgOne: "确定删除已选记录？",
        msgTwo: ""
      });
    },
    handleDelete() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .delete("/api/education/projectPublish/delete", {
          data: this.selectedHistoryList.map(el => el.xmId)
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("删除成功");
            // 清空勾选
            this.$refs.box.clearSelection();
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    // 点击发布
    clickPublish() {
      let sign = true;
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        sign = false;
      }
      this.selectedHistoryList.forEach(el => {
        if (!sign) {
          return;
        }
        if (el.zt === 0) {
          sign = false;
          this.$message.error("请修改项目有效时间再发布！");
        }
        if (el.zt === 2) {
          sign = false;
          this.$message.error("已发布项目不可重复发布！");
        }
      });
      if (!sign) {
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handlePublish,
        title: "发布",
        msgOne: "确定发布已选记录？",
        msgTwo: ""
      });
    },
    handlePublish() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put(
          "/api/education/projectPublish/publish",
          this.selectedHistoryList.map(el => el.xmId)
        )
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("发布成功");
            // 清空勾选
            this.$refs.box.clearSelection();
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    clickUnPublish() {
      let sign = true;
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        sign = false;
      }
      this.selectedHistoryList.forEach(el => {
        if (!sign) {
          return;
        }
        if (el.zt === 0) {
          sign = false;
          this.$message.error("请修改项目有效时间再取消发布！");
        }
        if (el.zt === 1) {
          sign = false;
          this.$message.error("未发布项目不可取消发布!");
        }
      });
      if (!sign) {
        return;
      }
      // 呼出对话框，并为确定按钮绑定回调
      this.$store.commit("skb/updateDialog", {
        visible: true,
        successCallback: this.handleUnPublish,
        title: "取消发布",
        msgOne: "确定取消发布已选记录？",
        msgTwo: ""
      });
    },
    handleUnPublish() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put(
          "/api/education/projectPublish/unPublish",
          this.selectedHistoryList.map(el => el.xmId)
        )
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("取消发布成功");
            // 清空勾选
            this.$refs.box.clearSelection();
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("skb/updateDialog", {
        visible: false
      });
    },
    // 点击前往修改页
    clickToModify(id) {
      this.$router.push(`/projectPublishModify/${id}`);
    },
    // 点击前往项目详情页
    clickToDetail(id) {
      this.$router.push(`/projectPublishDetail/${id}`);
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val;
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  computed: {
    isPublish() {
      let oneSelect = this.selectedHistoryList[0];
      if (!oneSelect) {
        return false;
      }
      return oneSelect.zt === 2;
    }
  },
  filters: {
    ztValueFilter(val) {
      switch (val) {
        case 0:
          return "失效";
        case 1:
          return "未发布";
        case 2:
          return "已发布";
      }
    },
    ztClassFilter(val) {
      switch (val) {
        case 0:
          return "red";
        case 1:
          return "orange";
        case 2:
          return "green";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.projectPublish {
  padding-top: 10px;
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  margin-bottom: 10px;
  div.left {
    & > div {
      display: flex;
      & > div:not(:last-child) {
        margin-right: 6px;
      }
    }
    flex: 3;
    display: flex;
  }
  .el-button:not(:last-child) {
    margin-right: 6px;
  }
}
</style>
