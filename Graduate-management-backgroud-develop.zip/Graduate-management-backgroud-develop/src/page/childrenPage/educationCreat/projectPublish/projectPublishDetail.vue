<template>
  <div class="projectPublishModify">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="main-details">
      <el-form ref="form" :model="formData" label-width="100px">
        <el-row>
          <el-col :span="15">
            <el-form-item label="项目名称:">
              <span>{{ formData.xmMc }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="15">
            <el-form-item label="项目类型:">
              <span>{{ getListValue(formData.xmlx, typeOptions) }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="15">
            <el-form-item label="有效时间:">
              <span
                >{{ $tagTime(formData.yssjKssj, "yyyy-MM-dd ~ ")
                }}{{ $tagTime(formData.yssjJssj, "yyyy-MM-dd") }}</span
              >
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="15">
            <el-form-item label="发布对象:">
              <span>{{ computedFbdx === 0 ? "老师" : "学生" }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="项目要求:">
              <div v-html="formData.xmyq" class="request-content"></div>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="相关附件：">
              <span v-for="(item, index) of formData.files" :key="index"
                ><a
                  :href="item.url"
                  class="under-line blue"
                  target="_blank"
                  :download="formData.fileName"
                  >{{ item.fileName }}</a
                ><span v-if="index !== formData.files.length - 1"
                  >，</span
                ></span
              >
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "projectPublishModify",
  props: {
    id: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      formData: {
        files: [],
        xmMc: "",
        xmlx: "",
        xmyq: "",
        yssjJssj: "",
        yssjKssj: ""
      },
      fileList: [],
      typeOptions: [
        {
          label: "硕士研究生课程建设项目",
          value: "1"
        },
        {
          label: "博士研究生课程建设项目",
          value: "2"
        },
        {
          label: "专业学位研究生课程案例库建设项目",
          value: "3"
        },
        {
          label: "田野调查基金项目",
          value: "4"
        },
        {
          label: "校级研究生科研项目",
          value: "5"
        },
        {
          label: "知行浙江社会调研项目",
          value: "6"
        }
      ] // 选项列表
    };
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    dataCallBack() {
      this.$http
        .get(`/api/education/projectPublish/getInfo/${this.id}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          console.log(data);
          data = data.data;
          if (!data) {
            this.$message.error("发布详情数据获取失败");
            return;
          }
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.fileList = this.formData.files.map(el => {
            return { name: el.fileName, url: el.url };
          });
        });
    },
    goBack() {
      this.$router.push("/projectPublish");
    }
  },
  computed: {
    computedFbdx() {
      let xmlx = parseInt(this.formData.xmlx);
      switch (xmlx) {
        case 1:
          return 0;
        case 2:
          return 0;
        case 3:
          return 0;
        case 4:
          return 1;
        case 5:
          return 1;
        case 6:
          return 1;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.projectPublishModify {
  padding-top: 10px;
  .fl {
    float: left;
    font-size: 14px;
    margin-left: 45px;
    color: #606266;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
  }
  .attachment {
    text-decoration: underline;
  }
  .request-content {
    width: 100%;
    padding: 5px;
    border: 1px solid #ccc;
    height: 300px;
    margin-top: 8px;
    overflow: auto;
  }
  .diyButton {
    background: none;
    border: none;
    color: #2779e3;
  }
  /deep/ .el-form {
    margin-top: 15px;
  }
  /deep/ .el-date-editor {
    .el-input__icon {
      line-height: 29px;
    }
    .el-range-separator {
      line-height: 26px;
    }
  }
}
</style>
