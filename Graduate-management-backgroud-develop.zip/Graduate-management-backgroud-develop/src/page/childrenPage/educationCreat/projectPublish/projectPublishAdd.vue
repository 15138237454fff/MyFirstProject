<template>
  <div class="projectPublishAdd">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right">
        <el-button @click="clickSave" type="primary">保存</el-button>
      </div>
    </my-breadcrumb>
    <div class="main-details">
      <el-form ref="form" :model="formData" label-width="100px">
        <el-row>
          <el-col :span="15">
            <el-form-item label="项目名称:" :required="true">
              <el-input v-model="formData.xmMc"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="15">
            <el-form-item label="项目类型:" :required="true">
              <el-select
                v-model="formData.xmlx"
                placeholder="请选择"
                style="width: 300px; float: left;"
              >
                <el-option
                  v-for="(item, index) in typeOptions"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="15">
            <el-form-item label="有效时间:" :required="true">
              <el-date-picker
                v-model="computedTime"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              >
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="15">
            <el-form-item label="发布对象:" :required="true">
              <span>{{ computedFbdx === 0 ? "老师" : "学生" }}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="margin-bottom:100px">
          <el-col :span="20">
            <el-form-item label="项目要求:">
              <quill-editor
                ref="myTextEditor"
                v-model="formData.xmyq"
                :options="editorOption"
              >
              </quill-editor>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="20">
            <el-form-item label="相关附件：">
              <el-upload
                class="upload-demo"
                :action="upload"
                :before-upload="handleBeforeUpload"
                :on-success="handleUploadSuccess"
                :on-remove="handleRemoveList"
                :on-preview="handlePreview"
                multiple
                ref="uploadcsv"
                accept=""
                :headers="headtoken"
              >
                <el-button
                  style="border-color:rgba(24, 144, 255, 1);color:#1890FF;width:350px"
                  >点击上传</el-button
                ><span
                  style="margin-left:20px;color:red"
                  slot="tip"
                  class="el-upload__tip"
                  >请上传10M以内的附件</span
                >
              </el-upload>
              <div>
                <li v-for="(item, index) in fileList" :key="index">
                  <i class="el-icon-document"></i
                  ><span
                    style="margin-right:20px;margin-left:10px"
                    @click="open(item.url)"
                    >{{ item.fileName }}</span
                  ><i
                    class="el-icon-close cursor-pointer"
                    @click="handleRemoveList(index, item.id)"
                  ></i>
                </li>
              </div>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>

<script>
import { quillEditor } from "vue-quill-editor";
import myBreadcrumb from "@/components/skb/myBreadcrumb";
export default {
  name: "projectPublishAdd",
  props: ["status", "data"],
  components: {
    quillEditor,
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      formData: {
        files: [],
        xmMc: "",
        xmlx: "",
        xmyq: "",
        yssjJssj: "",
        yssjKssj: ""
      },
      maxSize: 10240,
      fileList: [],
      typeOptions: [
        {
          label: "硕士研究生课程建设项目",
          value: "1"
        },
        {
          label: "博士研究生课程建设项目",
          value: "2"
        },
        {
          label: "专业学位研究生课程案例库建设项目",
          value: "3"
        },
        {
          label: "田野调查基金项目",
          value: "4"
        },
        {
          label: "校级研究生科研项目",
          value: "5"
        },
        {
          label: "知行浙江社会调研项目",
          value: "6"
        }
      ], // 选项列表
      upload: "/api/system/upload",
      headtoken: {
        userToken: this.$stores.state.token
      },
      editorOption: {
        theme: "snow",
        boundary: document.body,
        modules: {
          toolbar: [
            ["bold", "italic", "underline", "strike"],
            ["blockquote", "code-block"],
            [{ header: 1 }, { header: 2 }],
            [{ list: "ordered" }, { list: "bullet" }],
            [{ script: "sub" }, { script: "super" }],
            [{ indent: "-1" }, { indent: "+1" }],
            [{ direction: "rtl" }],
            [{ size: ["small", false, "large", "huge"] }],
            [{ header: [1, 2, 3, 4, 5, 6, false] }],
            [{ color: ["red", "blue", "green"] }, { background: [] }],
            [{ font: [] }],
            [{ align: [] }],
            ["clean"],
            ["link", "image", "video"]
          ]
        },
        placeholder: "Insert text here ...",
        readOnly: false
      }
    };
  },
  methods: {
    clickSave() {
      let sign = this.testForm();
      if (!sign) {
        return;
      }
      this.handleSave();
    },
    testForm() {
      let testArr = ["xmMc", "xmlx", "yssjJssj", "yssjKssj"],
        sign = true;
      testArr.forEach(key => {
        if (!sign) {
          return;
        }
        if (this.formData[key] === "") {
          sign = false;
        }
      });
      if (
        this.$tagTime(this.formData.yssjJssj, "yyyy-MM-dd") <
        this.$tagTime(new Date(), "yyyy-MM-dd")
      ) {
        this.$message.error("项目截止日期不能小于当前日期");
        return false;
      }
      if (!sign) {
        this.$message.error("请填写完整后再尝试提交");
      }
      return sign;
    },
    handleSave() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/education/projectPublish/save", {
          ...this.formData,
          fbdx: this.computedFbdx
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("添加成功");
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    goBack() {
      this.$router.push("/projectPublish");
    },

    // 文件上传前校验原附件个数
    handleBeforeUpload(file) {
      if (this.formData.files.length > 9) {
        this.$message.error("最多上传10个附件");
        return false;
      }
      if (file.size / 1024 > this.maxSize) {
        this.$message.error(`上传文件大小不能超过 ${this.maxSize / 1024}MB!`);
        return false;
      }
    },
    // 文件上传成功的处理函数
    handleUploadSuccess(res) {
      this.formData.files.push(res.data);
    },
    handleRemoveList(file, fileList) {
      let index = this.formData.files.findIndex(el => {
        return el.fileName === file.fileName && el.url === file.url;
      });
      this.formData.files.splice(index, 1);
    },
    handlePreview(file) {
      let url = file.response.data.url;
      if (!url) {
        return;
      }
      window.location.href = url;
    }
  },
  computed: {
    computedTime: {
      get() {
        return [this.formData.yssjKssj, this.formData.yssjJssj];
      },
      set(arr) {
        console.log(arr);
        if (arr === null) {
          arr = ["", ""];
        }
        this.formData.yssjKssj = arr[0];
        this.formData.yssjJssj = arr[1];
      }
    },
    computedFbdx() {
      let xmlx = parseInt(this.formData.xmlx);
      switch (xmlx) {
        case 1:
          return 0;
        case 2:
          return 0;
        case 3:
          return 0;
        case 4:
          return 1;
        case 5:
          return 1;
        case 6:
          return 1;
      }
    }
  }
};
</script>

<style scoped lang="scss">
.projectPublishAdd {
  padding-top: 10px;
  .fl {
    float: left;
    font-size: 14px;
    margin-left: 45px;
    color: #606266;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
  .top-title {
    width: 100%;
    height: 60px;
    border-bottom: 1px solid #f2f2f2;
    line-height: 60px;
  }
  .diyButton {
    background: none;
    border: none;
    color: #2779e3;
  }
  /deep/ .el-form {
    margin-top: 15px;
  }
  /deep/ .el-date-editor {
    .el-input__icon {
      line-height: 29px;
    }
    .el-range-separator {
      line-height: 26px;
    }
  }
}
.quill-editor {
  height: 200px;
}
</style>
