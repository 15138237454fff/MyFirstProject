<template>
  <div class="myProjectDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <project-detail-tydcjjxm v-if="type === '8'"></project-detail-tydcjjxm>
      <project-detail-xjyjskyxm v-if="type === '9'"></project-detail-xjyjskyxm>
      <project-detail-ssyjskcjsxm v-if="type === '7'"></project-detail-ssyjskcjsxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import projectDetailForTYDCJJXM from "@/components/jiansheProject/detail/projectDetailForTYDCJJXM";
import projectDetailForXJYJSKYXM from "@/components/jiansheProject/detail/projectDetailForXJYJSKYXM";
import projectDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/projectDetailForSSYJSKCJSXM";
export default {
  name: "myProjectDetail",
  props: {
    type: {
      type: String
    },
    id: {
      type: String
    }
  },
  data() {
    return {
      detailPathForTYDCJJXM: "fieldwork",
      detailPathForXJYJSKYXM: "university",
      detailPathForSSYJSKCJSXM: "curriculum",
      updatePathForTYDCJJXM: "jiansheProject/updateFormDataForTYDCJJXM",
      updatePathForXJYJSKYXM: "jiansheProject/updateFormDataForXJYJSKYXM",
      updatePathForSSYJSKCJSXM: "jiansheProject/updateFormDataForSSYJSKCJSXM",
    };
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "7":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "8":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "9":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.$http.get(`/api/education/${detailPath}/${this.id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!data.data) {
          console.log("申请详情数据获取失败");
          return;
        }
        console.log(data.data);
        this.$store.commit(updatePath, data.data);
      });
    }
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-detail-tydcjjxm": projectDetailForTYDCJJXM,
    "project-detail-xjyjskyxm": projectDetailForXJYJSKYXM,
    "project-detail-ssyjskcjsxm": projectDetailForSSYJSKCJSXM
  }
};
</script>
<style lang="scss" scoped>
.myProjectDetail {
  padding-top: 10px;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
