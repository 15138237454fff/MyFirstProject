<template>
  <div class="conclusionAduit">
    <el-tabs v-model="activeTab" @tab-click="tabClick">
      <el-tab-pane label="待审核" name="waitAduit">
        <conclusion-aduit-for-wait-aduit
          v-if="this.activeTab === 'waitAduit'"
        ></conclusion-aduit-for-wait-aduit>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="aduited">
        <conclusion-aduit-for-aduited
          v-if="this.activeTab === 'aduited'"
        ></conclusion-aduit-for-aduited>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import conclusionAduitForWaitAduit from "./conclusionAduitForWaitAduit";
import conclusionAduitForAduited from "./conclusionAduitForAduited";
export default {
  name: "conclusionAduit",
  components: {
    "conclusion-aduit-for-wait-aduit": conclusionAduitForWaitAduit,
    "conclusion-aduit-for-aduited": conclusionAduitForAduited
  },
  data() {
    return {
      activeTab: "waitAduit"
    };
  },
  created() {
    // 如果路由传参了指定页，则展示指定页
    if (this.$route.query.activeTab) {
      this.activeTab = this.$route.query.activeTab;
    }
  },
  methods: {
    // tab切换
    tabClick(t) {}
  }
};
</script>

<style lang="scss" scoped>
.conclusionAduit {
  width: 100%;
  /deep/ .el-tabs__nav-wrap {
    height: 42px;
  }
  /deep/ .el-tabs__nav {
    margin-left: 15px;
  }
  /deep/ .el-tabs__item {
    width: 130px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin: 0 0 10px;
  }
  /deep/ .el-tabs__active-bar {
    width: 120px !important;
    margin-bottom: 0px;
  }
}
</style>
