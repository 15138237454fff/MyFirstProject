<template>
  <div class="conclusionAduitAdd">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <conclusion-detail-ssyjskcjsxm
        :lcid="id"
        v-if="type === '7'"
      ></conclusion-detail-ssyjskcjsxm>
      <conclusion-detail-tydcjjxm
        :lcid="id"
        v-if="type === '8'"
      ></conclusion-detail-tydcjjxm>
      <conclusion-detail-xjyjskyxm
        :lcid="id"
        v-if="type === '9'"
      ></conclusion-detail-xjyjskyxm>
      <apply-status :aduitList="aduitList"></apply-status>
      <audit-submit
        @submit="handleSubmit"
        v-if="transmit === '0'"
      ></audit-submit>
      <div class="xymscd" v-else>
        <div class="dashed"></div>
        <div>
          <div class="xymscd-area">
            <span class="required">选择学院领导：</span>
            <el-select v-model="formData.type">
              <el-option
                v-for="(item, index) in typeOptions"
                :key="index"
                :label="`${item.userName}(${item.name})`"
                :value="item.userName"
              ></el-option>
            </el-select>
          </div>
          <el-button type="primary" @click="clickSubmit">提交</el-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import conclusionDetailForTYDCJJXM from "@/components/jiansheProject/detail/conclusionDetailForTYDCJJXM";
import conclusionDetailForXJYJSKYXM from "@/components/jiansheProject/detail/conclusionDetailForXJYJSKYXM";
import conclusionDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/conclusionDetailForSSYJSKCJSXM";
import applyStatus from "@/components/skb/applyStatus";
import auditSubmit from "@/components/skb/aduitSubmit";
export default {
  name: "conclusionAduitAdd",
  props: {
    type: {
      type: String
    },
    executionId: {},
    id: {},
    taskId: {},
    transmit: {},
    collegeNum: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "conclusion-detail-tydcjjxm": conclusionDetailForTYDCJJXM,
    "conclusion-detail-xjyjskyxm": conclusionDetailForXJYJSKYXM,
    "conclusion-detail-ssyjskcjsxm": conclusionDetailForSSYJSKCJSXM,
    "apply-status": applyStatus,
    "audit-submit": auditSubmit
  },
  data() {
    return {
      detailPathForTYDCJJXM: "fieldworkTask",
      detailPathForXJYJSKYXM: "universityTask",
      detailPathForSSYJSKCJSXM: "classEstablish",
      updatePathForTYDCJJXM:
        "jiansheProject/updateFormDataIsConclusionForTYDCJJXM",
      updatePathForXJYJSKYXM:
        "jiansheProject/updateFormDataIsConclusionForXJYJSKYXM",
      updatePathForSSYJSKCJSXM:
        "jiansheProject/updateFormDataIsConclusionForSSYJSKCJSXM",
      aduitList: [],
      typeOptions: [],
      formData: {}
    };
  },
  mounted() {
    this.dataCallBack();
    this.requireAduitDetail();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "7":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "8":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "9":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.$http.get(`/api/education/${detailPath}/${this.id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!data.data) {
          console.log("申请详情数据获取失败");
          return;
        }
        if (this.transmit === "1") {
          this.getCollegeLeadSelect(this.collegeNum);
        }
        this.$store.commit(updatePath, data.data);
      });
    },
    // 获取学院领导下拉框
    getCollegeLeadSelect(collegeNum) {
      this.$http
        .get(`/api/system/role/collegeLead/select?yxsh=${collegeNum}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.typeOptions = data.data;
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http
        .get(`/api/education/process/history/${this.executionId}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!Array.isArray(data.data)) {
            console.log("审核历史记录数据获取失败");
            return;
          }
          this.aduitList = data.data;
        });
    },
    handleSubmit(obj) {
      console.log("点击提交审核");
      const loading = this.$loading({
        lock: true,
        text: "提交审核中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(`/api/education/process/audit`, {
          taskId: this.taskId,
          lcid: this.id,
          check: obj.status,
          comment: obj.comment,
          type: "1" // 后端标志
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success(data.message);
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    goBack() {
      this.$router.push(`/conclusionAduit`);
    },
    // 点击提交审核
    clickSubmit() {
      const loading = this.$loading({
        lock: true,
        text: "提交审核中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(`/api/education/process/transmit`, {
          taskId: this.taskId,
          userName: this.formData.type
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success(data.message);
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAduitAdd {
  padding-top: 10px;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .xymscd {
    .dashed {
      margin-top: 25px;
      margin-bottom: 20px;
      height: 1px;
      background: linear-gradient(
        to right,
        rgba(204, 204, 204, 1),
        rgba(204, 204, 204, 1) 5px,
        transparent 5px,
        transparent
      );
      background-size: 10px 100%;
    }
    font-size: 14px;
    .el-select {
      width: 300px;
      line-height: 34px;
    }
    .xymscd-area {
      margin-bottom: 22px;
    }
    .el-button {
      width: 200px;
      margin-left: 115px;
    }
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
