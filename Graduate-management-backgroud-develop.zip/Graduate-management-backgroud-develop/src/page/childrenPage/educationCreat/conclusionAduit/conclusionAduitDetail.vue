<template>
  <div class="conclusionAduitDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <conclusion-detail-ssyjskcjsxm
        :lcid="executionId"
        v-if="type === '7'"
      ></conclusion-detail-ssyjskcjsxm>
      <conclusion-detail-tydcjjxm
        :lcid="executionId"
        v-if="type === '8'"
      ></conclusion-detail-tydcjjxm>
      <conclusion-detail-xjyjskyxm
        :lcid="executionId"
        v-if="type === '9'"
      ></conclusion-detail-xjyjskyxm>
      <apply-status :aduitList="aduitList"></apply-status>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/skb/myBreadcrumb";
import conclusionDetailForTYDCJJXM from "@/components/jiansheProject/detail/conclusionDetailForTYDCJJXM";
import conclusionDetailForXJYJSKYXM from "@/components/jiansheProject/detail/conclusionDetailForXJYJSKYXM";
import conclusionDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/conclusionDetailForSSYJSKCJSXM";
import applyStatus from "@/components/skb/applyStatus";
export default {
  name: "conclusionAduitDetail",
  props: {
    type: {
      type: String
    },
    id: {},
    executionId: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "conclusion-detail-tydcjjxm": conclusionDetailForTYDCJJXM,
    "conclusion-detail-xjyjskyxm": conclusionDetailForXJYJSKYXM,
    "conclusion-detail-ssyjskcjsxm": conclusionDetailForSSYJSKCJSXM,
    "apply-status": applyStatus
  },
  data() {
    return {
      detailPathForTYDCJJXM: "fieldwork",
      detailPathForXJYJSKYXM: "university",
      detailPathForSSYJSKCJSXM: "classEstablish",
      updatePathForTYDCJJXM: "jiansheProject/updateFormDataForTYDCJJXM",
      updatePathForXJYJSKYXM: "jiansheProject/updateFormDataForXJYJSKYXM",
      updatePathForSSYJSKCJSXM:
        "jiansheProject/updateFormDataIsConclusionForSSYJSKCJSXM",
      aduitList: []
    };
  },
  mounted() {
    this.dataCallBack();
    this.requireAduitDetail();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "7":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "8":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "9":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.$http
        .get(`/api/education/${detailPath}/${this.executionId}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          this.$store.commit(updatePath, data.data);
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http.get(`/api/education/process/history/${this.id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!Array.isArray(data.data)) {
          console.log("审核历史记录数据获取失败");
          return;
        }
        this.aduitList = data.data;
      });
    },
    goBack() {
      this.$router.push(`/conclusionAduit?activeTab=aduited`);
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAduitDetail {
  padding-top: 10px;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
