<template>
  <div class="index">
    <div class="head" ref="head">
      <headNav></headNav>
    </div>
    <div class="sidebar">
      <navTag @showcool="show"></navTag>
    </div>
    <transition
      :duration="300"
      mode="out-in"
      appear
      enter-active-class="animated fadeIn"
      leave-active-class="animated fadeOut"
      appear-active-class="animated zoomInDown"
    >
      <div :class="[collapse ? maincollapse : main]">
        <tags ref="tag"></tags>
        <div class="router_view" ref="router_view">
          <!-- <keep-alive> -->
          <router-view></router-view>
          <!-- </keep-alive> -->
        </div>
      </div>
    </transition>
  </div>
</template>
<script>
import headNav from "@/components/headNav";
import navTag from "@/components/navTag";
import tags from "@/components/tags";
export default {
  name: "index",
  data() {
    return {
      collapse: false, // 菜单的收起展开
      main: "main",
      maincollapse: "maincollapse",
      waitTime: 30 * 60 * 1000,
      timer: null
    };
  },
  components: {
    headNav,
    navTag,
    tags
  },
  methods: {
    show(data) {
      this.collapse = data;
    },
    throttle() {
      console.log(
        "重置定时器" + this.timer,
        this.$tagTime(new Date(), "yyyy-MM-dd HH:mm:ss")
      );
      clearTimeout(this.timer);
      this.timer = setTimeout(this.handleOutlog, this.waitTime);
      console.log(
        "生成定时器" + this.timer,
        this.$tagTime(new Date(), "yyyy-MM-dd HH:mm:ss")
      );
    },
    handleOutlog() {
      console.log("退出登录", this.$tagTime(new Date(), "yyyy-MM-dd HH:mm:ss"));
      clearTimeout(this.timer);
      this.endTimeOut();
      // 清空用户登录信息
      this.$stores.commit("tokenrole", "");
      if (this.$route.path === "/") {
        return;
      }
      this.$message.error("长时间无操作，强制退出");
      this.$router.push("/");
    },
    startTimeOut() {
      document.body.onmousemove = this.throttle;
    },
    endTimeOut() {
      this.timer = null;
      document.body.onmousemove = null;
    }
  },
  created() {},
  destroyed() {
    this.endTimeOut();
  },
  mounted() {
    this.startTimeOut();
  }
};
</script>

<style scoped lang="scss">
.index {
  width: 100%;
  height: 100%;
  .head,
  .foot,
  .sidebar,
  .maincollapse,
  .main {
    position: absolute;
  }
  .head {
    top: 0;
    left: 0;
    right: 0;
    height: 80px;
  }
  .sidebar {
    width: 230px;
    top: 80px;
    bottom: 0px;
    left: 0;
    overflow: hidden;
    overflow-y: auto;
    z-index: 99;
    background-color: rgb(40, 66, 97);
  }
  .sidebar::-webkit-scrollbar {
    //设置整个滚动条宽高
    width: 0px;
    height: 100%;
  }
  .sidebar::-webkit-scrollbar-thumb {
    //设置滑块
    width: 0px;
    height: 60px;
    background-color: #ccc;
    border-radius: 3px;
  }
  .sidebar::-webkit-scrollbar-track {
    border-radius: 10px;
    background-color: rgba(255, 255, 255, 0.5); //设置背景透明
  }
  .main {
    top: 80px;
    bottom: 0px;
    left: 230px;
    right: 0;
    transition: left 0.3s ease-in-out;
    overflow: hidden;
  }
  .maincollapse {
    top: 80px;
    bottom: 0px;
    left: 65px;
    right: 0;
    transition: left 0.3s ease-in-out;
  }
  .router_view {
    overflow-y: auto;
    overflow-x: hidden;
    padding: 0 10px 0px 10px;
    height: calc(100% - 48px);
  }
  .router_view::-webkit-scrollbar,
  .router_view::-ms-scrollbar,
  .router_view::-o-scrollbar,
  .router_view::-moz-scrollbar {
    //设置整个滚动条宽高
    width: 0px;
    height: 100%;
  }
  .router_view::-webkit-scrollbar-thumb,
  .router_view::-ms-scrollbar-thumb,
  .router_view::-o-scrollbar-thumb,
  .router_view::-moz-scrollbar-thumb {
    //设置滑块
    width: 0px;
    height: 60px;
    background-color: #ccc;
    border-radius: 3px;
  }
  .router_view::-webkit-scrollbar-track,
  .router_view::-ms-scrollbar-track,
  .router_view::-o-scrollbar-track,
  .router_view::-moz-scrollbar-track {
    border-radius: 10px;
    background-color: rgba(255, 255, 255, 0.5); //设置背景透明
  }
}
</style>
<style>
.el-header {
  padding: 0;
  height: 80px !important;
}
.el-main {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}
.el-upload-dragger {
  background: rgba(250, 250, 250, 1) !important;
}
</style>
