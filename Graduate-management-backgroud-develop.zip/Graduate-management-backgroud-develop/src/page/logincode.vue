<template>
  <div class="main" :style="{
      'background-image': 'url(' + paramsForm.gldlbjt + ')'
    }">
    <!-- 登录页 login -->
    <div class="view">
      <div class="login-form">
        <div class="">
          <div class="head">
            <div class="headTop">欢迎登录</div>
          </div>
          <el-form :model="form" ref="form">
            <el-form-item lable="用户名">
              <el-input v-model="form.userName" placeholder="请输入账号" type="text" prefix-icon="el-icon-service" @keyup.enter.native="loginCLick" autocomplete="off" style="width:350px">
              </el-input>
            </el-form-item>
            <el-form-item lable="密码" style="margin-top:20px">
              <el-input type="password" placeholder="请输入密码" v-model="form.password" prefix-icon="el-icon-goods" @keyup.enter.native="loginCLick" autocomplete="off" style="width:350px;">
              </el-input>
            </el-form-item>
          </el-form>
          <el-button class="login-Button" @click="loginCLick" @keyup.enter.native="loginCLick">登录</el-button>
          <div class="loginpassword">
            <li style="float:left;">
              <el-checkbox v-model="checked" style="color: #000;">一周内记住密码</el-checkbox>
            </li>
            <li style="float: right;" @click="forgetPass">忘记密码？</li>
          </div>
          <div class="bottom">
            <span>技术支持: 杭州毕为科技有限公司</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import coverImgUrl from "../assets/mriMg.png";
export default {
  name: "login",
  data() {
    return {
      form: {
        userName: "", // 用户名
        password: "" // 密码
      },
      imgurl: "",
      checked: false,
      formset: null,
      paramsForm: {
        gldlbjt: window.localStorage.getItem("loginBackgroundImage")
      },
      coverImgUrl: coverImgUrl
    };
  },
  mounted() {
    this.$http
      .get("api/system/xxinfo/getInfo")
      .then(res => {
        this.formset = res.data.data;
        if (this.formset == 0) {
          this.paramsForm = { gldlbjt: coverImgUrl };
          window.localStorage.setItem("loginBackgroundImage", coverImgUrl);
        } else {
          this.paramsForm = res.data.data;
          if (!res.data.data.gldlbjt) {
            this.paramsForm.gldlbjt = coverImgUrl;
            window.localStorage.setItem("loginBackgroundImage", coverImgUrl);
          } else {
            window.localStorage.setItem(
              "loginBackgroundImage",
              res.data.data.gldlbjt
            );
          }
          this.$stores.commit("loGogh", this.paramsForm.logo);
        }
      })
      .catch(err => {
        console.log(err.message);
        this.paramsForm = { gldlbjt: coverImgUrl };
        window.localStorage.setItem("loginBackgroundImage", coverImgUrl);
      });
  },
  methods: {
    forgetPass() {
      this.$router.push("/forgetPassword");
    },
    loginCLick() {
      if (this.form.userName == "") {
        this.$message({
          message: "用户名不能为空",
          type: "error"
        });
        return false;
      } else if (this.form.password == "") {
        this.$message({
          message: "密码不能为空",
          type: "error"
        });
        return false;
      } else {
        this.$http
          .post(`api/usermanage/user/loginBack`, {
            username: this.form.userName,
            password: this.form.password,
            week: 0
          })
          .then(res => {
            if (res.data.code == 200 && res.data !== "") {
              this.$stores.commit("tokenParam", res.data.data);
              this.$router.push("/first");
              this.initData();
              this.updateUserStatus();
              // 登入成功后需调用此接口初始化数据
              this.$stores.commit("tokenrole", res.data.data.userToken); // token验证
              this.$storage.set("UserName", res.data.data.userName); // 缓存用户名
              this.$storage.set("UserID", res.data.data.id); // 缓存用户id来获取菜单权限
              this.$storage.set("userSsy", res.data.data.userSsy); // 获取所属域
              this.$storage.set("usersnames", res.data.data.name); // 密码修改
              this.$stores.commit("roleid_toles", res.data.data.currentRoleId); // 用户切换身份标识的唯一
              if (res.data.data.currentRoleId == "1") {
                console.log(res.data.data.currentRoleId, "我是超级管理员");
                this.$stores.commit("menuArrend", {
                  xzmneu: this.$stores.state.navList[0].id,
                  submenuArr: this.$stores.state.navList[0].children,
                  endmenuArr: this.$stores.state.navList
                });
              } else {
                console.log(res.data.data.currentRoleId, "我是其他角色登录");
                this.$http
                  .get(
                    "api/system/home/selectByRoleId/" +
                      res.data.data.currentRoleId
                  )
                  .then(res => {
                    let tmpArr = res.data.data[0].childen;
                    tmpArr.forEach(el => {
                      if (!el.childen) {
                        return;
                      }
                      el.childen = el.childen.filter(v => {
                        return v.menuType !== "4";
                      });
                      if (
                        Array.isArray(el.childen) &&
                        el.childen.length === 0
                      ) {
                        el.childen = null;
                      }
                    });

                    this.$stores.commit("menuArrend", {
                      xzmneu: res.data.data[0].id,
                      submenuArr: tmpArr,
                      endmenuArr: res.data.data
                    });
                    this.$stores.commit("menulistansy", res.data.data);
                  });
              }
            } else {
              this.$message({
                message: res.data.message,
                type: "error"
              });
            }
          });
      }
    },
    initData() {
      // 登入成功后需调用此接口初始化数据
      this.$http.get(`api/system/home/initData`).then(res => {});
    },
    updateUserStatus() {
      this.$http.get(`api/system/home/updateUserStatus`).then(res => {});
    }
  }
};
</script>

<style scoped lang="scss">
.main {
  width: 100%;
  background-size: cover;
  background-repeat: no-repeat;
  position: relative;
  height: 100%;
  .title {
    color: #fff;
    font-size: 36px;
    padding: 60px 0 70px 70px;
    img {
      height: 80px;
    }
    .text {
      vertical-align: middle;
      margin-left: 30px;
      color: #45a8fe;
    }
  }
  .view {
    text-align: center;
    img {
      width: 70%;
    }
    .login-form {
      border-radius: 15px;
      width: 390px;
      position: absolute;
      height: 350px;
      padding: 10px;
      top: 30%;
      right: 8%;
      background: hsla(0, 0%, 100%, 0.4);
      .headTop {
        font-weight: 500;
        font-size: 23px;
        text-align: center;
        margin-bottom: 30px;
        color: #000;
      }
      .el-button {
        width: 100%;
        color: #fff;
        background: #45a8fe;
        border-radius: 3px;
        margin-top: 20px;
        margin-bottom: 20px;
        width: 350px;
        border: none;
      }
    }
  }
  .bottom {
    width: 100%;
    font-size: 13px;
    text-align: center;
    color: #fff;
    position: absolute;
    bottom: 20px;
  }
  .loginpassword {
    text-decoration: underline;
    color: #000;
    font-size: 16px;
    text-align: center;
    cursor: pointer;
    text-align: center;
    padding: 0 25px;
  }
}
</style>
