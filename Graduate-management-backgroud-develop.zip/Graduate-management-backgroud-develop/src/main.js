// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import router from './router'
import storage from '@/router/router'
import permission from '@/router/permission'
// import permission from '@/router/eslint.js';
import Log from '@/components/log'
import store from '@/store/store'
import stores from '@/store/stores'
import axios from 'axios'
import VueQuillEditor from 'vue-quill-editor'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import App from './App'
import dict from './global/dict.js'
import CryptoJS from 'crypto-js'
Vue.use(CryptoJS)
Vue.use(Log)
import baseMethod from './global/baseMethod.js'
import 'font-awesome/scss/font-awesome.scss'
import md5 from 'js-md5'
import '@/components/common/element-variables.scss'
// 添加自定义的全局方法 -- skb
import globalFunc from './global/globalFunc'
Vue.use(globalFunc)
// 添加全局的css文件 -- skb
import '@/components/codecss/global.scss'
// 引入全局过滤器 -- skb
import * as filters from './filters' //global filters
// register global utility filters.加载全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
// 引入公共bus -- skb
import bus from '@/components/bus.js'
Vue.prototype.$bus = bus
Vue.prototype.$md5 = md5
Vue.use(ElementUI)
Vue.use(VueQuillEditor)
Vue.use(baseMethod)
Vue.use(permission)
Vue.config.productionTip = false
Vue.prototype.$http = axios
Vue.prototype.$dict = dict
Vue.prototype.$storage = storage
Vue.prototype.$stores = stores
import HappyScroll from 'vue-happy-scroll'
import 'vue-happy-scroll/docs/happy-scroll.css'
Vue.use(HappyScroll)
axios.defaults.timeout = 30000
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
axios.defaults.retry = 4
axios.defaults.retryDelay = 1000
axios.interceptors.request.use((config) => {
  config.headers['userToken'] = stores.state.token
  return config
}, (error) => {
  ElementUI.Message({
    message: `请求超时`,
    type: 'error'
  })
  return Promise.reject(error)
})
var flag = true
axios.interceptors.response.use((response) => {
  return response
}, (error) => {
  if (error.response.status == 401 || error.response.status.code == 401) {
    if (flag) {
      ElementUI.Message({
        message: `身份已过期，请重新登录`,
        type: 'error'
      })
      router.replace({
        path: '/'
      })
      // window.sessionStorage.clear()
      window.localStorage.clear()
      flag = false
      return false
    }
  } else {
    if (flag) {
      ElementUI.Message({
        message: `系统错误,请联系管理员`,
        type: 'error'
      })
      flag = false
    }
  }
  return Promise.reject(error)
})
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: {
    App
  },
  template: '<App/>'
})
