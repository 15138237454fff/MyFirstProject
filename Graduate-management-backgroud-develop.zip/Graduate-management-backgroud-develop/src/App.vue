<template>
  <div id="app">
    <router-view />
    <my-dialog></my-dialog>
  </div>
</template>

<script>
import "@/components/common/reset.css";
import myDialog from "./components/skb/myDialog";
export default {
  name: "App",
  components: {
    "my-dialog": myDialog
  },
  data() {
    return {};
  }
};
</script>

<style>
#app {
  width: 100%;
  height: 100%;
}
.el-table td,
.el-table th {
  text-align: center !important;
}
.el-pagination {
  position: relative;
  top: 7px;
  text-align: center;
}
.el-dialog__title {
  font-size: 16px;
  color: #333333;
}
.el-dialog__header {
  padding: 20px 20px 15px;
  border-bottom: 1px solid #dcdfe6 !important;
}
.el-tooltip__popper {
  max-width: 20%;
}
textarea {
  resize: none !important;
}
.el-input-group__prepend {
  background: none !important;
  border: none !important;
}
.el-header {
  padding: 0 !important;
}
.el-input__inner {
  height: 34px;
}
.el-button {
  padding: 9px 20px;
}
.tablexq {
  color: #409dff;
  cursor: pointer;
}
.tablesc {
  cursor: pointer;
  color: #f04a4a;
}
.tablexg {
  color: #ff9a32;
  cursor: pointer;
}
.tablezd {
  color: #52c41a;
  cursor: pointer;
}
.tableqxzd {
  color: #52c41a;
  cursor: pointer;
}
.filtermore {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.tabledisbale {
  cursor: pointer;
  color: #ccc;
}
.collegebtn {
  color: #409dff;
  background: #fff;
}
.el-button + .el-button {
  margin-left: 5px !important;
}
.yes {
  color: #409eff;
}
.back {
  color: #f56c6c;
}
.audit {
  color: #febc5a;
}
.yes1 {
  background: #409eff;
}
.back1 {
  background: #f56c6c;
}
.time {
  margin-left: 15px;
  color: #909399;
  font-size: 13px;
}
.comment {
  margin-top: 8px;
  color: #909399;
  font-size: 13px;
}
.mytext {
  color: #333 !important;
}
.red {
  color: #f56c6c;
}
.grey {
  color: #999;
}
.blue {
  color: #409eff;
}
.green {
  color: #52c41a;
}
.orange {
  color: #ff9a32;
}
.under-line {
  text-decoration: underline;
}
.cursor-pointer {
  cursor: pointer;
}
.thead-bg {
  background: #f2f2f2;
}
pre {
  padding: 5px;
}
</style>
