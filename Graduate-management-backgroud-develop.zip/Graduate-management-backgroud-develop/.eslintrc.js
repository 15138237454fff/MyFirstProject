// https://eslint.org/docs/user-guide/configuring

module.exports = {

  //此项是用来告诉eslint找当前配置文件不能往父级查找
  root: true,

  //此项是用来指定eslint解析器的，解析器必须符合规则，babel-eslint解析器是对babel解析器的包装使其与ESLint解析
  parser: 'babel-eslint',

  //此项是用来指定javaScript语言类型和风格，sourceType用来指定js导入的方式，默认是script，此处设置为module，指某块导入方式
  parserOptions: {
    // 设置 script(默认) 或 module，如果代码是在ECMASCRIPT中的模块
    sourceType: 'module',
    "ecmaVersion": 6,
    "ecmaFeatures": {
      "jsx": true
    }
  },

  // 此项指定环境的全局变量，下面的配置指定为浏览器环境
  env: {
    "browser": true,
    "node": true,
    "commonjs": true,
    "es6": true,
    "amd": true
  },
  // https://github.com/standard/standard/blob/master/docs/RULES-en.md
  // 此项是用来配置标准的js风格，就是说写代码的时候要规范的写，如果你使用vs-code我觉得应该可以避免出错
  extends: 'vue',
  // 此项是用来提供插件的，插件名称省略了eslint-plugin-，下面这个配置是用来规范html的
  plugins: [
    'html',
    "flow-vars",
    "react"
  ],
  /* 
   下面这些rules是用来设置从插件来的规范代码的规则，使用必须去掉前缀eslint-plugin-
    主要有如下的设置规则，可以设置字符串也可以设置数字，两者效果一致
    "off" -> 0 关闭规则
    "warn" -> 1 开启警告规则
    "error" -> 2 开启错误规则
  */
  rules: {
    // 关闭数组，对象最后一个元素后的逗号检查
    'comma-dangle': 0,
    'no-extra-semi': 0,
    'new-cap': 0,
    'no-new': 0,
    'no-undef': 0,
    'max-len': 0,
    'no-useless-escape': 0,
    'space-before-function-paren': [0, 'always'], //函数定义时括号前面要不要有空格
    'no-console': 0, // 禁止使用console
    // allow async-await
    'generator-star-spacing': 'off',
    'no-unused-expressions': 'off',
    // allow debugger during development
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'semi': [2, 'never'], //不使用语句强制分号结尾
    'eqeqeq': [0], // 必须使用全等
    'indent': [0], // 缩进风格，switch缩进风格
    'semi': 0,
    'quotes': 0,
    'prefer-const': 0,
    'one-var': 0
  }
}
