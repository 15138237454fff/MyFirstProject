module.exports = {
    publicPath: "/mangshen/",
    runtimeCompiler: true,
    devServer: {
        proxy: {
            "/mangshen/api": {
                // target: "http://192.168.31.57:10010", // 测试
                target: "http://192.168.31.135:6677", // jss
                // target: "http://192.168.31.57:6677", // jss
                // target: "http://192.168.31.181:6677", // yx 本地
                // target: 'http://192.168.31.202:10010', // yx 虚拟机
                // target: 'http://192.168.31.181:6677',// 胡润元
                changeOrigin: true,
                pathRewrite: {
                    // 重写路径
                    "^/mangshen/api": ""
                }
            }
        },
        port: 8081
    },
    pluginOptions: {
        "style-resources-loader": {
            patterns: [],
            preProcessor: "scss"
        }
    },
    css: {
        // 向所有 Sass 样式传入共享的全局变量：
        loaderOptions: {
            // 给 sass-loader 传递选项
            sass: {
                // @/ 是 src/ 的别名
                data: `@import "~@/styles/index.scss";`
            }
        }
    }
};