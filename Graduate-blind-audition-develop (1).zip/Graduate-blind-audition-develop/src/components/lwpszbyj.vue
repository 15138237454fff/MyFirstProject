<template>
  <div class="lwpszbyj">
    <table>
      <tr>
        <td class="left_cont" colspan="6">
          <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>论文评审指标
          <span style="color:#409EFF;float:right;margin-right:10px">总评分：{{ lwpfs }}</span>
        </td>
      </tr>
      <tr>
        <td class="listcss">一级指标</td>
        <td class="listcss">二级指标和评价要点</td>
        <td class="listcss">项目满分</td>
        <td class="listcss">评分</td>
      </tr>
      <tr v-for="(item, index) in pszbVOList" :key="index">
        <td>
          {{ item.zb }}
        </td>
        <td>
          {{ item.nr }}
        </td>
        <td>
          {{ item.fs }}
        </td>
        <td>
          <el-input v-model.number="item.pf" :disabled="item.isshow" type="number" @input="lwpfchange(item.fs, item.pf)" :min="1"></el-input>
        </td>
      </tr>
      <tr>
        <td class="left_cont" colspan="6">
          <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>评审意见
        </td>
      </tr>
      <tr style="height:80px">
        <td colspan="4">
          <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6 }" placeholder="请输入评审意见" v-model="psyj">
          </el-input>
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  props: ["pszbVOList", "psyj", "lwpf"],
  name: "lwpszbyj",
  data() {
    return {
      lwpfs: this.lwpf,
      List: this.pszbVOList
    };
  },
  methods: {
    lwpfchange(newval, oldval) {
      if (oldval > newval)
        return this.$message.error("当前评分不能大于项目分数");
      var totalnum = this.pszbVOList
        .map(row => row.pf * 1)
        .reduce((acc, cur) => cur + acc, 0);
      console.log(totalnum);
      this.lwpfs = Number(totalnum);
    }
  },
  created() {},
  mounted() {
    console.log(this.lwpfs, this.lwpf);
    console.log(this.pszbVOList, 55);
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.lwpszbyj {
  width: 100%;
}
table {
  width: 100%;
  color: #444;
  font-size: 14px;
  white-space: nowrap;
  font-weight: 400;
  margin-bottom: 20px;
  border-collapse: collapse;
  text-overflow: ellipsis;
}
table thead {
  height: 60px !important;
  border: 1px solid #e0e0e0;
}
tr {
  border: 1px solid #e0e0e0;
  height: 48px;
}
th,
td {
  border: 1px solid #e0e0e0;
  height: 48px;
  line-height: 48px;
  text-align: center;
  width: 180px;
}
.left_cont {
  text-align: left;
  padding-left: 10px;
  font-weight: bold;
}
.listcss {
  background: rgba(240, 242, 245, 1);
  width: 180px;
}
</style>
