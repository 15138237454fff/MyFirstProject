<template>
  <div class="headernav">
    <li><img src="../assets/university.png" alt="" /></li>
    <li>浙江财经大学研究生论文盲审系统</li>
    <li>
      <i class="el-icon-switch-button icontyope" @click="loginout">退出</i>
    </li>
  </div>
</template>

<script>
export default {
  name: "headernav",
  data() {
    return {};
  },
  methods: {
    loginout() {
      this.$router.push("/logincode");
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.headernav {
  width: 100%;
  height: 80px;
  background: rgba(39, 121, 227, 1);
  box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.08);
  display: flex;
}
.headernav li {
  flex: 1;
  line-height: 80px;
  color: #fff;
  text-align: center;
}
.headernav li:nth-child(1) {
  text-align: left;
  padding-top: 10px;
  padding-left: 10px;
}
.headernav li:nth-child(2) {
  font-size: 30px;
}
.headernav li:nth-child(1) img {
  width: 50%;
}
.headernav li:nth-child(3) {
  text-align: right;
  padding-right: 20px;
  font-size: 16px;
}
.icontyope {
  color: #fff;
}
</style>
