<template>
  <div class="top">
    <div class="box">
      <h2>{{ xslwbt }}</h2>
    </div>
    <el-card class="box-card boxs">
      <el-card class="box-card elcard_table">
        <table>
          <tr>
            <td class="listcss">论文英文题目</td>
            <td class="right">{{ selectPaper.xwlwywtm }}</td>
          </tr>
          <tr>
            <td class="listcss">论文字数</td>
            <td class="right">{{ selectPaper.lwzs }}万</td>
          </tr>
          <tr>
            <td class="listcss">论文类型</td>
            <td class="right">{{ selectPaper.lwlx }}</td>
          </tr>
          <tr>
            <td class="listcss">选题来源</td>
            <td class="right">{{ selectPaper.xtly }}</td>
          </tr>
          <tr>
            <td class="listcss">论文关键词</td>
            <td class="right">{{ selectPaper.lwgjz }}</td>
          </tr>
          <tr>
            <td class="listcss">论文研究方向</td>
            <td class="right">{{ selectPaper.lwyjfx }}</td>
          </tr>
        </table>
      </el-card>
      <el-card class="box-card elcard_div">
        <p>请点击下载论文：</p>
        <div class="text_item" style="cursor: pointer;" @click="open(lwdowm.url)">
          <li class="text_item_li">{{ lwdowm.name }}</li>
          <img src="../assets/down.png" alt="" class="imgs" />
        </div>
      </el-card>
    </el-card>
    <el-card class="box-card grmessage">
      <usermessage ref="usermessage"></usermessage>
      <lwpszbyj :pszbVOList="pszbVOList" :psyj="psyj" :lwpf="lwpf" ref="lwpszbyj"></lwpszbyj>
      <div style="text-align: center;">
        <el-button type="primary" style="width:200px" @click="saveFormparams" :disabled="saveshow">提 交</el-button>
      </div>
    </el-card>
  </div>
</template>

<script>
import usermessage from "./usermessage";
import lwpszbyj from "./lwpszbyj";
export default {
  name: "top",
  data() {
    return {
      xslwbt: "",
      lwdowm: {
        name: "论文附件.doc",
        zs: "1012M",
        scrq: "2019.01.01 12:40上传",
        url: ""
      },
      form: {
        xm: "",
        sfzh: "",
        sj: "",
        khh: "",
        yhk: ""
      },
      selectPaper: {},
      pszbVOList: [],
      psyj: "",
      lwpf: 0,
      content: {},
      saveshow: false
    };
  },
  methods: {
    loading() {
      if (this.content.lx !== null) {
        this.$axios
          .get(
            `api/degree/blind/selectPaper?userName=${this.content.zh}&lx=${this.content.lx}`
          )
          .then(res => {
            Object.assign(this.selectPaper, res.data.data);
            if (res.data.data.grxx) {
              this.form = res.data.data.grxx;
            }
            this.$bus.$emit("formlist", this.form);
            this.lwdowm.name = this.selectPaper.fj.fileName;
            this.lwdowm.url = this.selectPaper.fj.url;
            this.pszbVOList = this.selectPaper.pszbVOList;
            this.pszbVOList.forEach(el => {
              this.$set(el, "isshow", false);
            });
            this.$nextTick(() => {
              this.$refs.lwpszbyj.lwpfs = res.data.data.zf;
            });
            this.psyj = this.selectPaper.psyj;
            this.xslwbt = this.selectPaper.xwlwtm;
          });
      }
    },
    open(val) {
      return (window.location.href = val);
    },
    saveFormparams() {
      var pszbVOList = this.$refs.lwpszbyj.pszbVOList;
      var arr = [];
      this.$refs.usermessage.form;
      if (
        !this.$refs.usermessage.form.xm ||
        !this.$refs.usermessage.form.sfzh ||
        !this.$refs.usermessage.form.sj ||
        !this.$refs.usermessage.form.khh ||
        !this.$refs.usermessage.form.yhk
      ) {
        return this.$message.error("个人信息请填写完整在提交");
      }
      pszbVOList.forEach(el => {
        arr.push({ pf: el.pf, zbid: el.id });
      });
      var obj = {
        zh: this.content.zh,
        zf: this.$refs.lwpszbyj.lwpfs,
        xh: this.content.xh,
        psyj: this.$refs.lwpszbyj.psyj,
        grxx: this.$refs.usermessage.form,
        lwpf: arr,
        lx: this.content.lx
      };
      if (this.content.lx == "1" || this.content.lx == "2") {
        this.$axios.post(`api/degree/blind/save`, obj).then(res => {
          if (res.data.code == 200) {
            this.$message.success(res.data.message);
            this.$router.push({ path: "/topxq" });
          } else {
            this.$message.error(res.data.message);
          }
        });
      } else {
        this.$message.error("参数错误!");
      }
    }
  },
  components: {
    usermessage,
    lwpszbyj
  },
  created() {
    this.content = JSON.parse(sessionStorage.getItem("user"));
    this.loading();
  },
  mounted() {}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.top {
  width: 100%;
}
.top > .box {
  width: 80%;
  margin: 0 auto;
}
.box h2 {
  height: 60px;
  background: rgba(66, 157, 255, 0.5);
  border-radius: 2px 2px 0px 0px;
  text-align: center;
  line-height: 60px;
  font-size: 22px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
}
.boxs {
  width: 80%;
  margin: 0 auto;
  padding-bottom: 20px;
}
table {
  width: 100%;
  color: #444;
  font-size: 14px;
  white-space: nowrap;
  font-weight: 400;
  margin-bottom: 20px;
  border-collapse: collapse;
  text-overflow: ellipsis;
}
table thead {
  height: 60px !important;
  border: 1px solid #e0e0e0;
}
tr {
  border: 1px solid #e0e0e0;
  /* height: 48px; */
}
th,
td {
  border: 1px solid #e0e0e0;
  /* height: 48px; */
  line-height: 32px;
  padding-left: 5px;
  text-align: center;
  width: 180px;
}
.left_cont {
  text-align: left;
  padding-left: 10px;
  font-weight: bold;
}
.right {
  text-align: left;
}
.listcss {
  background: rgba(240, 242, 245, 1);
  width: 180px;
  text-align: left;
}

.elcard_table {
  float: left;
  width: 48%;
  height: 240px;
}
.elcard_div {
  float: right;
  width: 48%;
  height: 200px;
  background: rgba(240, 242, 245, 1);
  padding-top: 40px;
  text-align: left;
}
.elcard_div p {
  width: 50%;
  margin: 15px auto;
  font-size: 14px;
  font-family: Microsoft YaHei;
  font-weight: 300;
  color: rgba(102, 102, 102, 1);
}
.elcard_div .text_item {
  width: 50%;
  height: 60px;
  margin: 0 auto;
  border-radius: 5px;
  background: url("../assets/文件 (2).png") no-repeat #fff;
  background-size: 15%;
  background-position: 5% center;
  position: relative;
  padding-top: 20px;
}
.text_item_li {
  width: 100%;
  text-align: center;
  font-weight: bold;
  margin-top: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.text_item .imgs {
  position: absolute;
  width: 36px;
  height: 36px;
  top: 20px;
  right: 10px;
}
.lidown {
  font-size: 12px;
  font-weight: normal;
}
.grmessage {
  width: 80%;
  margin: 15px auto;
}
</style>
