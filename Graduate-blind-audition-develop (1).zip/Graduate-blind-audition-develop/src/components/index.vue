<template>
  <div class="index">
    <headernav></headernav>
    <topnav
      v-if="xszt == 0 && this.$route.path !== '/topxq'"
      :content="content"
    ></topnav>
    <xwssjl
      v-if="xszt == 1 && this.$route.path !== '/topxq'"
      :content="content"
    ></xwssjl>
  </div>
</template>

<script>
import headernav from "./headernav";
import xwssjl from "./xwssjl";
import topnav from "./top";
export default {
  name: "index",
  components: {
    headernav,
    topnav,
    xwssjl
  },
  data() {
    return {
      xszt: 0,
      content: {}
    };
  },
  methods: {
    loadtable() {}
  },
  mounted() {
    this.content = JSON.parse(sessionStorage.getItem("user"));
    this.xszt = this.content.status;
    console.log(this.content);
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
