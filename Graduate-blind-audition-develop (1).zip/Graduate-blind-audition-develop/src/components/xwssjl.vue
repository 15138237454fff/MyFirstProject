<template>
  <div class="xwssjl">
    <el-card class="box-card itembox">
      <h3>{{ content.dwmc }}单位管理员您好！</h3>
    </el-card>
    <div style="margin-bottom:30px"></div>
    <el-card class="box-card itembox">
      <searchcomponment>
        <div slot="left">
          <el-input v-model="input" placeholder="请输入账号/论文名称" style="width:200px;margin-right:10px" suffix-icon="el-icon-search" @clear="fresh" clearable></el-input>
          <el-button style="margin-right:10px" @click="fresh">查询</el-button>
          <el-select v-model="zy" placeholder="全部专业" style="width:200px;margin-right:10px" clearable @change="fresh">
            <el-option label="全部专业" value=""> </el-option>
            <el-option v-for="(item, index) in zyarr" :key="index" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <el-select v-model="pszt" placeholder="全部评审状态" style="width:200px;margin-right:10px" clearable @change="fresh">
            <el-option label="全部评审状态" value=""> </el-option>
            <el-option v-for="item in psztarr" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </div>
        <div slot="right">
          <el-button type="primary" plain @click="excel">导出</el-button>
        </div>
      </searchcomponment>
      <el-table :data="tableData" height="550" border style="width: 100%">
        <el-table-column prop="zh" label="账号" width="180"> </el-table-column>
        <el-table-column prop="mm" label="密码" width="180"> </el-table-column>
        <el-table-column prop="lwtm" label="论文题目"> </el-table-column>
        <el-table-column prop="zymc" label="所属专业"> </el-table-column>
        <el-table-column prop="xslb" label="学生类别"> </el-table-column>
        <el-table-column prop="pscj" label="评审成绩"> </el-table-column>
        <el-table-column prop="pszt" label="评审状态">
          <template slot-scope="scope">
            <span :class="scope.row.pszt | ztcolor">{{
              scope.row.pszt | pszt
            }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage4" :page-sizes="[10, 20, 30, 40]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total" background>
        </el-pagination>
      </div>
    </el-card>
    <!-- <el-button style="margin-right:10px" @click="loist">查询</el-button> -->
  </div>
</template>

<script>
import searchcomponment from "./searchcomponment";

export default {
  props: ["content"],
  name: "index",
  data() {
    return {
      location: "admin",
      options: [],
      value: "",
      tableData: [],
      currentPage4: 1,
      zyarr: [],
      psztarr: [
        {
          value: "0",
          label: "未评审"
        },
        {
          value: "1",
          label: "已评审"
        }
      ],
      zy: "",
      pszt: "",
      input: "",
      pagesize: 10,
      total: 0
    };
  },
  components: {
    searchcomponment
  },
  mounted() {
    this.loading();
    this.tablelist();
  },
  filters: {
    pszt(val) {
      switch (val) {
        case "0":
          return "未评审";
        case "1":
          return "已评审";
        default:
          break;
      }
    },
    ztcolor(val) {
      switch (val) {
        case "0":
          return "red";
        case "1":
          return "green";
        default:
          break;
      }
    }
  },
  methods: {
    timeouts(val) {
      return new Promise((resolve, reject) => {
        resolve(val);
      });
    },
    loist() {
      var count = 0;
      count++;
      this.timeouts(count).then(res => {
        console.log(res);
      });
    },
    fresh() {
      this.currentPage4 = 1;
      this.pagesize = 10;
      this.tablelist();
    },
    excel() {
      window.location.href = `api/degree/degreeAudit/export?dwzh=${this.content.zh}&pszt=${this.pszt}&query=${this.input}&zydm=${this.zy}`;
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.pagesize = val;
      this.tablelist();
    },
    handleCurrentChange(val) {
      this.currentPage4 = val;
      this.tablelist();
      console.log(`当前页: ${val}`);
    },
    loading() {
      this.$axios.get(`api/degree/degreeAudit/selectZY`).then(res => {
        this.zyarr = res.data.data;
      });
    },
    tablelist() {
      this.$axios
        .post(`api/degree/degreeAudit/list`, {
          dwzh: this.content.zh,
          pageSize: this.pagesize,
          pageNum: this.currentPage4,
          pszt: this.pszt,
          query: this.input,
          zydm: this.zy
        })
        .then(res => {
          this.tableData = res.data.data.list;
          this.total = res.data.data.total;
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.xwssjl {
  width: 100%;
  padding-top: 20px;
}
table {
  width: 100%;
  color: #444;
  font-size: 14px;
  white-space: nowrap;
  font-weight: 400;
  margin-bottom: 20px;
  border-collapse: collapse;
  text-overflow: ellipsis;
}
table thead {
  height: 60px !important;
  border: 1px solid #e0e0e0;
}
tr {
  border: 1px solid #e0e0e0;
  height: 48px;
}
th,
td {
  border: 1px solid #e0e0e0;
  height: 48px;
  line-height: 48px;
  text-align: center;
  width: 180px;
}
.left_cont {
  text-align: left;
  padding-left: 10px;
  font-weight: bold;
}
.listcss {
  background: rgba(240, 242, 245, 1);
  width: 180px;
}
.itembox {
  width: 80%;
  margin: 0px auto;
}
.pagination {
  margin-top: 10px;
  text-align: center;
}
.red {
  color: #ff9900;
  text-decoration: underline;
}
.green {
  color: #66cc00;
  text-decoration: underline;
}
</style>
