<template>
  <div class="logincode">
    <div class="backbox">
      <h1>研究生学位论文盲审系统</h1>
      <div class="container">
        <el-input v-model="form.username" placeholder="用户名" class="boxinput" prefix-icon="el-icon-s-custom" autocomplete="off" style="margin-top:60px"></el-input>
        <el-input v-model="form.password" class="boxinput" prefix-icon="el-icon-lock" placeholder="默认为身份证后六位" show-password type="password" autocomplete="off"></el-input>
        <p>
          <el-button type="primary" style="width:60%;margin-top:60px" @click="logincode">登录</el-button>
        </p>
        <p class="bottom">技术支持：杭州毕为科技有限公司</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "logincode",
  data() {
    return {
      form: {
        username: "",
        password: ""
      }
    };
  },
  methods: {
    logincode() {
      if (!this.form.username || !this.form.password) {
        return this.$message.error("用户名和密码其中任意一项都不能为空");
      }
      this.$axios
        .get(
          `api/degree/degreeAudit/blindAuditLogin/${this.form.username}/${this.form.password}`
        )
        .then(res => {
          if (res.data.code == 200) {
            sessionStorage.setItem("user", JSON.stringify(res.data.data));
            if (res.data.data.pszt == "1") {
              this.$router.push("/topxq");
            } else {
              this.$router.push("/index");
            }
          } else {
            this.$message.error(res.data.message);
          }
        });
      // $axios
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.logincode {
  width: 100%;
  height: 100%;
  background: url("../assets/盲审.png") no-repeat;
  background-size: 100% 100%;
  background-position: center center;
  position: relative;
}
.backbox {
  width: 100%;
  position: absolute;
  left: 50%;
  top: 40%;
  transform: translate(-50%, -40%);
}
.backbox h1 {
  font-size: 62px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
  margin-bottom: 25px;
  text-align: center;
}
.boxinput {
  width: 60%;
  margin-top: 20px;
}
.container {
  width: 600px;
  height: 380px;
  text-align: center;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  margin: 0 auto;
}
.bottom {
  margin-top: 20px;
  font-size: 16px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
}
</style>
