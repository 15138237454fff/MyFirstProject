<template>
  <div class="usermessage">
    <table>
      <tr>
        <td class="left_cont" colspan="6">
          <span style="color:#409EFF;margin-right:3px;font-size:12px;font-weight:bold">|</span>个人信息
        </td>
      </tr>
      <tr>
        <td class="listcss">姓名</td>
        <td class="listcss">身份证号码</td>
        <td class="listcss">手机号</td>
        <td class="listcss">开户行</td>
        <td class="listcss">银行卡号</td>
      </tr>
      <tr>
        <td>
          {{ form.xm }}
        </td>
        <td>
          {{ form.sfzh }}
        </td>
        <td>
          {{ form.sj }}
        </td>
        <td>
          {{ form.khh }}
        </td>
        <td>
          {{ form.yhk }}
        </td>
      </tr>
    </table>
  </div>
</template>
<script>
export default {
  name: "usermessage",
  data() {
    return {
      form: {
        xm: "",
        sfzh: "",
        sj: "",
        khh: "",
        yhk: ""
      }
    };
  },
  methods: {},
  created() {
    this.$bus.$on("formlist", msg => {
      console.log(5363);
      console.log(msg);
      this.form = msg;
    });
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.usermessage {
  width: 100%;
}
table {
  width: 100%;
  color: #444;
  font-size: 14px;
  white-space: nowrap;
  font-weight: 400;
  margin-bottom: 20px;
  border-collapse: collapse;
  text-overflow: ellipsis;
}
table thead {
  height: 60px !important;
  border: 1px solid #e0e0e0;
}
tr {
  border: 1px solid #e0e0e0;
  height: 48px;
}
th,
td {
  border: 1px solid #e0e0e0;
  height: 48px;
  line-height: 48px;
  text-align: center;
  width: 180px;
}
.left_cont {
  text-align: left;
  padding-left: 10px;
  font-weight: bold;
}
.listcss {
  background: rgba(240, 242, 245, 1);
  width: 180px;
}
</style>
