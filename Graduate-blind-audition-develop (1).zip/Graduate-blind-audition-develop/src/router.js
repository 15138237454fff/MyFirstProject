import Vue from "vue";
import Router from "vue-router";
Vue.use(Router);
export default new Router({
    mode: "hash", //要使用hash模式还是 history模式 我们一般情况下还是用 hash模式 history在后台支持的情况下可以开启
    base: "mangshen", // 应用的基路径。例如，如果整个单页应用服务在 /app/ 下，然后 base 就应该设为 "/app/"
    routes: [{
            path: "/logincode",
            name: "logincode",
            component: () =>
                import ("./components/logincode.vue")
        },
        {
            path: "/",
            name: "index",
            component: () =>
                import ("./components/index.vue"),
            redirect: "/logincode",
            children: [{
                path: "/index",
                name: "index",
                component: () =>
                    import ("./components/index.vue")
            }]
        },
        {
            path: "/topxq",
            name: "topxq",
            component: () =>
                import ("./components/topxq.vue")
        }
    ]
});