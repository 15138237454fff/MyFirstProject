// 过滤审核状态
export function zsZTFilter(val, type) {
    val = parseInt(val)
    if (type === 0) {
        switch (val) {
            case 1:
                return '通过';
            case 2:
                return '退回';
            case 3:
                return '审核中';
            case 4:
                return '未上报';
        }
    } else {
        switch (val) {
            case 1:
                return 'status-success';
            case 2:
                return 'status-back';
            case 3:
                return 'status-ing';
            case 4:
                return 'status-wait';
        }
    }
}
// 导师调课：星期过滤
export function xqFilter(xq) {
    const statusMap = {
        '1': '星期一',
        '2': '星期二',
        '3': '星期三',
        '4': '星期四',
        '5': '星期五',
        '6': '星期六',
        '7': '星期日',
    }
    return statusMap[xq]
}

// 时间转为日期格式
export function toDate(time) {
    const tmpTime = new Date(time)
    return `${tmpTime.getFullYear()}.${tmpTime.getMonth() + 1}.${tmpTime.getDate()}`
}
// 时间转为年月日格式
export function toYMD(time) {
    const tmpTime = new Date(time)
    return `${tmpTime.getFullYear()}年${tmpTime.getMonth() + 1}月${tmpTime.getDate()}日`
}
export function sexFilter(val) {
    val = parseInt(val)
    switch (val) {
        case 1:
            return '男'
        case 0:
            return '女'
        default:
            return ""
    }
}
export function zjlxFilter(val) {
    switch (val) {
        case '01':
            return '居民身份证'
        case '03':
            return '港澳台身份证'
        case '04':
            return '华侨身份证件'
    }
}