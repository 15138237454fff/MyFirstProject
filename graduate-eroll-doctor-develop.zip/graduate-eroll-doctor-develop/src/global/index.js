//skb`s func
export default {
    install(Vue) {
        /**
         * 挂载一个动态添加实例data中对象的属性的方法到Vue原型上
         * data:待添加的新对象
         * object:实例的data中已经声明的对象
         */
        Vue.prototype.$addObjectKey = (data, object) => {
                //要求传入的参数必须都为对象
                if (Object.prototype.toString.call(data) === '[object Object]' && Object.prototype.toString.call(object) === '[object Object]') {
                    Object.keys(data).forEach(key => {
                        Vue.set(object, key, data[key])
                    })
                } else {
                    console.error("请正确传入参数，要求都为对象")
                }
            }
            //设置表头颜色的方法
        Vue.prototype.$tableHeaderColor = ({
            rowIndex
        }) => {
            if (rowIndex == 0) {
                return "background-color:#f2f2f2;font-weight:500";
            }
        }
    },
    //防抖
    debounce: function(callback, wait) {
        let timer = null
        return () => {
            if (timer !== null) clearInterval(timer)
            setInterval(callback, wait)
        }
    }
}