// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import '../static/common/element-variables.scss'
Vue.use(ElementUI);
import BaiduMap from 'vue-baidu-map'
Vue.use(BaiduMap, {
    // ak 是在百度地图开发者平台申请的密钥 详见 http://lbsyun.baidu.com/apiconsole/key */
    ak: 'yttqQKBMogYxcZhFnmCstYV3KkEleORE'
})
import qs from 'qs'
import store from './store/index.js'
import factUrl from '@/store/facturl.js'
import axios from 'axios'
Vue.prototype.$qs = qs
Vue.prototype.$http = axios
Vue.prototype.FACTURL = factUrl
    // 添加自定义的全局方法
import globalFunc from './global/index.js'
Vue.use(globalFunc)
import * as filters from './filters' //global filters
// register global utility filters.加载全局过滤器
Object.keys(filters).forEach(key => {
    Vue.filter(key, filters[key])
})



Vue.config.productionTip = false
let timer = null,
    prevUrl = ""
    // 添加一个请求拦截器
axios.interceptors.request.use(
    config => {
        if (store.state.userLoginMsg.xh === '' && router.history.current.fullPath !== "/forgotPassword") {
            router.push('/')
        }
        config.headers.token = store.state.userLoginMsg.token
        if (timer === null && config.method === "post") {
            prevUrl = config.url
            timer = setTimeout(() => {
                timer = null
                prevUrl = ""
            }, 500)
        } else if (config.method === "post" && config.url === prevUrl) {
            ElementUI.Message({
                message: `操作过频`,
                type: 'error'
            })
            return Promise.reject(error)
        } else {
            clearInterval(timer)
            timer = null
            prevUrl = ""
        }
        return config;
    },
    error => {
        ElementUI.Message({
            message: `请求超时`,
            type: 'error'
        })
        return Promise.reject(error);
    }
);
// 添加一个响应拦截器
axios.interceptors.response.use(
    response => {
        let err = {};
        if (!response) {
            ElementUI.Message({
                message: `请求超时`,
                type: 'error'
            })
            err.message = "请求超时";
            return Promise.reject(err)
        }
        return response;
    },
    error => {
        if (error.response && error.response.status === 401 || error.response.status.code === 401) {
            globalFunc.debounce(() => { ElementUI.Message.error('登录信息失效，请重新登录') }, 100)
            store.commit('updateLogin', {})
            router.push('/')
        } else {
            ElementUI.Message.error(error.response.data.message)
        }
        return Promise.reject(error);
    }
);
// router.beforeEach((to, from, next) => {
//         if (to.meta.title) {
//             document.title = '浙江财经大学博士报名系统'
//         }
//         next()
//     })
/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store,
    axios,
    components: { App },
    template: '<App/>'
})