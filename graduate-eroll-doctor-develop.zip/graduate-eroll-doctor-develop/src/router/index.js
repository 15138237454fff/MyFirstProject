import Vue from 'vue'
import VueRouter from 'vue-router'
import index from '@/pages/login'
Vue.use(VueRouter)
const routes = [{
        path: '/',
        name: 'index',
        component: index,
        meta: {
            title: '浙江财经大学博士报名系统'
        }
    },
    {
        path: '/register',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/register/index'),
        },
        meta: {
            title: '注册页'
        }
    },
    {
        path: '/modifyRegister',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/register/modifyRegister'),
        },
        meta: {
            title: '修改注册信息页'
        }
    },
    {
        path: '/forgotPassword',
        name: 'forgotPassword',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/forgotPassword'),
        },
        meta: {
            title: '忘记密码页'
        }
    },
    {
        path: '/pageMain',
        name: 'pageMain',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/pageMain'),
        },
        meta: {
            title: '报名入口页'
        }
    },
    {
        path: '/agreement',
        name: 'agreement',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/agreement/agreement'),
        },
        meta: {
            title: '条款页'
        }
    },
    {
        path: '/enrollPage',
        name: 'enrollPage',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/enrollPage'),
        },
        meta: {
            title: '报名前主页'
        }
    },
    {
        path: '/cgbm',
        name: 'cgbm',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/cgbm'),
        },
        meta: {
            title: '报名前主页'
        }
    },
    {
        path: '/enrolledPage',
        name: 'enrolledPage',
        components: {
            header: () =>
                import ('@/components/header'),
            default: () =>
                import ('@/pages/enrolled/index'),
        },
        meta: {
            title: '报名后主页'
        }
    },
    {
        path: '*',
        redirect: "/",
    }
]
export default new VueRouter({
    mode: 'hash',
    base: 'boshi',
    routes,
})