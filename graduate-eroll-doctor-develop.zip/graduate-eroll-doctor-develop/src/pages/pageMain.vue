<template>
    <div class="pageMainBox">
        <header class="pageMainBox-header">
            <div class="left">
                <i class="el-icon-tickets"></i>
                <div class="left-info">
                    <h2>报名列表</h2>
                    <p>请根据个人意愿，选择招生专业及研究方向</p>
                </div>
            </div>
            <div class="right">
                <i class="el-icon-document"></i>
                <p>报名起止日期: {{startTime}} 至 {{endTime}}</p>
            </div>
        </header>
        <div class="pageMainBox-cont">
            <div class="table">
                <el-table v-loading="loading2" element-loading-text="加载中" :data="tableData" border ref="multipleTable" style="width: 100%; margin-top: 15px;" :header-cell-style="tableHeaderColor"  border fit highlight-current-row>
                    <el-table-column label="序号"  type="index" width="55" align="center">
                        <template slot-scope="scope">
                        <span>{{scope.$index + 1}}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="xymc" label="招生院系" width="150" align="center">
                    </el-table-column>
                    <el-table-column prop="zymc" label="招生专业" align="center">
                    </el-table-column>
                    <el-table-column prop="yjfxMc" label="研究方向" align="center">
                    </el-table-column>
                    <el-table-column prop="xxfs" label="学习方式" align="center">
                    </el-table-column>
                    <el-table-column prop="xwdjj" label="专业简介" align="center">
                        <template slot-scope="scope">
                            <a style="color:#409EFF;cursor:pointer" @click="openDetails(scope.row)">专业简介</a>
                        </template>
                    </el-table-column>
                    <el-table-column label="在线报名" align="center">
                        <template slot-scope="scope">
                            <el-button type="primary" @click="goDetails(scope.row)">在线报名</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- <div class="block" v-if="total/pageSize>1">
                    <el-pagination :current-page.sync="currentPage" :page-sizes="[5, 10, 50, 100]" :page-size="pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
                    </el-pagination>
                </div> -->
            </div>
        </div>
        <el-dialog title="专业简介" class="zyDialog" :visible.sync="dialogShow" width="500px">
            <div class="cont">
                <el-form ref="form" :model="form" label-width="100px">
                    <el-form-item label="招生院系：">
                        {{form.xymc}}
                    </el-form-item>
                </el-form>
                <el-form ref="form" :model="form" label-width="100px">
                    <el-form-item label="招生专业：">
                        {{form.zymc}}
                    </el-form-item>
                </el-form>
                <el-form ref="form" :model="form" label-width="100px">
                    <el-form-item label="研究方向：">
                        {{form.yjfxMc}}
                    </el-form-item>
                </el-form>
                <el-form ref="form" :model="form" label-width="100px">
                    <el-form-item label="学习方式：">
                        {{form.xxfs}}
                    </el-form-item>
                </el-form>
                <el-form ref="form" :model="form" label-width="100px">
                    <el-form-item label="专业简介：" prop="xwdjj">
                        <el-input type="textarea" class="textarea"  v-model="form.xwdjj"></el-input>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return{
            time:{start:'2019-10-1',end:'2020-02-10'},
            loading2: false,
            tableData: [],
            tableHeight: null, // 表格高度
            currentPage: 1,
            total: 1, // 总数据条数
            pageSize: 10,
            dialogShow:false,
            form:{}
        }
    },
    methods:{
        takeList() {
            this.loading2 = true
            this.$http
                .post('/api/doctorate/before/list')
                .then(res => {
                    this.loading2 = false
                    if(res.data.code == 200){
                        this.tableData = res.data.data
                    }else{
                        this.$message.error(res.data.message)
                    }
                })
                .catch(function(err) {
                    console.log(err)
                })
        }, // 获取列表

        // changePage(val) {
        //     this.takeList(val)
        // }, 
        // sizeChange(val) {
        //     this.pageSize = val
        //     this.takeList(1)
        // }, 
        tableHeaderColor({ row, column, rowIndex, columnIndex }) {
            if (rowIndex === 0) {
                return 'background-color: #eee;font-weight: 500;color:#333';
            }
        }, 
        openDetails(val){
            console.log(val,'-----------')
            let xxfs
            if(val.xxfs == '全日制'){
                xxfs = 1
            }else{
                xxfs = 2
            }
            let params={xxfs:xxfs,
                        xydm:val.xydm,
                        yjfxDm:val.yjfxDm,
                        zydm:val.zydm}
            this.$http
                .post(`/api/doctorate/before/info`,params).then(res=>{
                    if(res.data.code == 200){
                        this.form = res.data.data
                    }else{
                        this.$message.error(res.data.message)
                    }
                })
            this.dialogShow = true
        },
        goDetails(val){
            console.log(val,'val')
             this.$router.push({ 
              path:`/enrollPage`,query:{xydm:val.xydm,zydm:val.zydm,yjfxDm:val.yjfxDm,id:val.id,xymc:val.xymc,yjfxMc:val.yjfxMc,zymc:val.zymc,xxfs:val.xxfs}
            })
        }
    },
    watch:{
    },
    created(){
        this.takeList(1)
        
    },
    mounted(){
        console.log(this.startTime,this.endTime)
    },
    computed: {
        //是否报名
        sfbm(){
            return this.$store.getters.getSfbm
        },
        endTime(){
            return this.$store.getters.getEndTime
        },
        startTime(){
            return this.$store.getters.getStartTime
        },
    }
}
</script>
<style lang="scss" scoped>
    .pageMainBox{
        width: 80%;
        min-height:calc(100vh - 120px);
        margin: 20px auto;
        background:#fff;
        .pageMainBox-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                .el-icon-tickets{
                    font-size:52px;
                    color:#409EFF;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
            .right{
                display: flex;
                align-items: center;
                justify-content: center;
                .el-icon-document{
                    font-size: 19px;
                    margin-right: 10px;
                    color:#409EFF;
                }
                p{
                    font-size:14px;
                    color:#409EFF;
                }
            }
        }
        .pageMainBox-cont{
            width:calc(100% - 40px);
            padding:20px;
            height: calc(100vh - 280px);
            overflow-y: auto;
            .table{
                box-sizing: border-box;
            }
        }
        /deep/ .zyDialog{
            .el-dialog__header{
                border-bottom:1px solid #ccc;
            }
            .cont .el-form-item{
                margin-bottom:0;
                .el-textarea{
                    .el-textarea__inner{
                        min-height:100px!important;
                    }
                }
            }
        }
    }
</style>