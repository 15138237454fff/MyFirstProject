<template>
    <div class="enrollPageBox">
        <header class="enrollPageBox-header">
            <div class="left">
                <img src="../assets/img/bmlbTitle.png" alt="" srcset="">
                <div class="left-info">
                    <h2>在线报名</h2>
                    <p>请完整填写报名信息，保证信息真实准确！</p>
                </div>
            </div>
            <div class="right">
                <i class="el-icon-date"></i>
                <p>报名起止日期: {{$store.state.userLoginMsg.startTime}} 至 {{$store.state.userLoginMsg.endTime}}</p>
                <el-button type="primary" plain icon="el-icon-d-arrow-left" @click="goBack">返回</el-button>
            </div>
        </header>
        <div class="enrollPageBox-cont">
            <table>
                <tr>
                    <td class="listcss" colspan="7" style="text-align:left;font-weight:bold">| 基本信息</td>
                </tr>
                <tr>
                    <td class="listcss">姓名</td>
                    <td colspan="2">{{resetForm.xm}}</td>
                    <td class="listcss"><span class="mustInput">*</span>姓名拼音</td>
                    <td colspan="2"><el-input v-model="resetForm.xmpy" @input="xmpyIpt" maxlength="80"></el-input></td>
                    <td rowspan="5">
                        <div class="avtarBox" v-if="!resetForm.zp" >
                            <img  src="../assets/img/avator.png" class="avatar" style="width:100px;height:100px;display: inline;">
                            <ul> 
                                <li>1、请上传1寸免冠照片</li>
                                <li> 2、背景建议白底或浅色</li>
                                <li>3、文件大小小于40kb</li>
                                <li>4、支持格式.jpg</li>
                            </ul>
                        </div>
                        <el-upload
                            class="avatar-uploader"
                            action="/api/doctorate/before"
                            :headers="headers"
                            :show-file-list="false"
                            :on-success="handleAvatarSuccess"
                            :on-error="handleAvatarError"
                            :before-upload="beforeAvatarUpload">
                            <el-button type="primary" size="small" v-if="!resetForm.zp">点击上传</el-button>
                            <div class="avtarBox" v-else>
                                <img  :src="resetForm.zp" class="avatar" style="width:100px;height:100px;display: inline;">
                            </div>
                        </el-upload>
                        
                    </td>
                </tr>
                <tr>
                    <td class="listcss">证件类型</td>
                    <td colspan="2">{{resetForm.zjlx | zjlxFilter}}</td>
                    <td class="listcss">证件号码</td>
                    <td colspan="2">{{resetForm.zjhm}}</td>
                </tr>
                <tr>
                    <td class="listcss" ><span class="mustInput">*</span>出生日期</td>
                    <td colspan="2"><el-date-picker v-model="resetForm.csrq" type="date" resetFormat="yyyy-MM-dd" value-format="yyyyMMdd" placeholder="选择日期时间"></el-date-picker></td>
                    <td class="listcss"><span class="mustInput">*</span>出生所在地</td>
                    <td colspan="2"><el-cascader :options="nativeList" v-model="resetForm.csdm" style="min-min-width:400px" filterable :props="{ checkStrictly: true ,emitPath : false}"  clearable></el-cascader></td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>民族</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.mzm" placeholder="请选择">
                            <el-option
                                v-for="item in dict.mz"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>性别</td>
                    <td colspan="2">
                        <el-radio-group v-model="resetForm.xbm">
                            <el-radio label="1">男</el-radio>
                            <el-radio label="2">女</el-radio>
                        </el-radio-group>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>婚姻状况</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.hfm" placeholder="请选择">
                            <el-option v-for="(item,index) in this.hfOption" :value="item.value" :label="item.label" :key="index" />
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>政治面貌</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.zzmmm" placeholder="请选择">
                            <el-option v-for="(item,index) in this.dict.zzmm" :value="item.value" :label="item.label" :key="index" />
                        </el-select>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>现役军人</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.xyjrm" placeholder="请选择">
                            <el-option v-for="(item,index) in this.xyjrOption" :value="item.value" :label="item.label" :key="index" />
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>籍贯</td>
                    <td colspan="3">
                        <el-cascader :options="nativeList" v-model="resetForm.jgdm" style="min-width:400px" filterable :props="{ checkStrictly: true ,emitPath : false}" clearable></el-cascader>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>户口所在地</td>
                    <td colspan="2">
                        <el-cascader :options="nativeList" v-model="resetForm.hkszdm" style="min-width:400px" filterable :props="{ checkStrictly: true ,emitPath : false}" clearable></el-cascader>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>通讯地址</td>
                    <td colspan="3">
                        <el-input v-model="resetForm.txdz" :maxlength="59"></el-input>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>邮政编码</td>
                    <td colspan="2">
                        <el-input v-model="resetForm.yzbm"  type="number" @change="lengInputRule(6,resetForm.yzbm)"></el-input>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>固定电话</td>
                    <td colspan="3">
                        <el-input v-model="resetForm.lxdh" :maxlength="39"  type="number"></el-input>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>移动电话</td>
                    <td colspan="2">
                        <el-input v-model="resetForm.yddh"  type="number" @change="lengInputRule(11,resetForm.yddh)"></el-input>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>电子信箱</td>
                    <td colspan="3">
                        <el-input v-model="resetForm.dzxx" :maxlength="49"></el-input>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>现在学习或工作单位</td>
                    <td colspan="2">
                        <el-input v-model="resetForm.xxgzdw" :maxlength="59"></el-input>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>现在学习或工作单位性质</td>
                    <td colspan="3">
                        <el-select v-model="resetForm.xxgzdwxz" placeholder="请选择">
                            <el-option v-for="(item,index) in this.xxgzdwxzOption" :value="item.value" :label="item.label" :key="index" />
                        </el-select>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>考生来源</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.kslym" placeholder="请选择">
                            <el-option v-for="(item,index) in this.colyOption" :value="item.value" :label="item.label" :key="index" />
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>档案所在地</td>
                    <td colspan="3">
                        <el-cascader :options="nativeList" v-model="resetForm.daszdm" style="min-width:400px" filterable :props="{ checkStrictly: true ,emitPath : false}" clearable></el-cascader>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>档案所在单位名称</td>
                    <td colspan="2">
                        <el-input v-model="resetForm.daszdw" :maxlength="59"></el-input>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>档案所在单位邮编</td>
                    <td colspan="3">
                        <el-input v-model="resetForm.daszdwyzbm" type="number" @change="lengInputRule(6,resetForm.daszdwyzbm)" ></el-input>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>档案所在单位地址</td>
                    <td colspan="8">
                        <el-input v-model="resetForm.daszdwdz" :maxlength="79"></el-input>
                    </td>
                </tr>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="15" style="text-align:left;font-weight:bold">| 个人经历</td>
                </tr>
                <tr>
                    <td :rowspan="tableTwo.jlcfVOList.length+1" colspan="2" class="listcss">
                        <p class="wrapName">何时何地何原因受过何种奖励或处分</p>
                        <!-- <el-input v-model="resetForm.hkxxdz" class="textareaInput"  type="textarea" maxlength="220" :show-word-limit="true"></el-input> -->
                    </td>
                    <td colspan="2" class="listcss">时间</td>
                    <td colspan="2" class="listcss">地点</td>
                    <td colspan="6" class="listcss">奖惩项目</td>
                    <td colspan="2" class="listcss">奖惩名称</td>
                    <td class="listcss">操作</td>
                </tr>
                <template v-for="(item,index) in tableTwo.jlcfVOList">
                    <tr>
                        <td colspan="2"><el-date-picker @change="changeTime(item.jcsj,index)" v-model="item.jcsj" type="date" format="yyyy-MM-dd"  value-format="yyyy-MM-dd" placeholder="选择日期时间"></el-date-picker></td>
                        <td colspan="2"><el-input v-model="item.jcdd" type="text" ></el-input></td>
                        <td colspan="6"><el-input v-model="item.jcxm"></el-input></td>
                        <td colspan="2"><el-input v-model="item.jcmc" ></el-input></td>
                        <td>
                            <i class="el-icon-circle-plus" style="color:#409eff;font-size:20px" @click="qtListadd(item,index,1)" v-if="index===tableTwo.jlcfVOList.length-1"></i>
                            <i class="el-icon-remove" style="color:#f56c6c;font-size:20px" v-if="index!==tableTwo.jlcfVOList.length-1" @click="qtListdelet(item,index,1)"></i>
                        </td>
                    </tr>
                </template>
                 <tr>
                    <td :rowspan="tableTwo.jtcyList.length+1" colspan="2" class="listcss">
                        <p class="wrapName"><span class="mustInput">*</span>家庭主要成员</p>
                        <!-- <el-input v-model="resetForm.hkxxdz" class="textareaInput"  type="textarea" maxlength="220" :show-word-limit="true"></el-input> -->
                    </td>
                    <td colspan="2" class="listcss">姓名</td>
                    <td colspan="2" class="listcss">与本人关系</td>
                    <td colspan="6" class="listcss">在何单位工作 | 任何职务</td>
                    <td colspan="2" class="listcss">联系电话</td>
                    <td class="listcss">操作</td>
                </tr>
                <template v-for="(rel,index) in tableTwo.jtcyList">
                    <tr>
                        <td colspan="2"><el-input v-model="rel.xm" type="text" ></el-input></td>
                        <td colspan="2">
                            <el-select v-model="rel.gx" placeholder="请选择">
                                <el-option
                                    v-for="item in dict.jtgx"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </td>
                        <td colspan="6"><el-input v-model="rel.hdwhz" @change="changeZw(rel.hdwhz,index)" placeholder="示例：xx公司(xx职务)"></el-input></td>
                        <td colspan="2"><el-input v-model="rel.lxdh" type="number"></el-input></td>
                        <td>
                            <i class="el-icon-circle-plus" style="color:#409eff;font-size:20px" @click="qtListadd(rel,index,2)" v-if="index===tableTwo.jtcyList.length-1"></i>
                            <i class="el-icon-remove" style="color:#f56c6c;font-size:20px" v-if="index!==tableTwo.jtcyList.length-1" @click="qtListdelet(rel,index,2)"></i>
                        </td>
                    </tr>
                </template>
                 <tr>
                    <td :rowspan="tableTwo.xxgzjlVoList.length+1" colspan="2" class="listcss">
                        <p class="wrapName"><span class="mustInput">*</span> 学习与工作经历(请从高中学习经历填起)</p>
                        <!-- <el-input v-model="resetForm.hkxxdz" class="textareaInput"  type="textarea" maxlength="220" :show-word-limit="true"></el-input> -->
                    </td>
                    <td colspan="4" class="listcss">起止年月</td>
                    <td colspan="2" class="listcss">学习或工作单位</td>
                    <td colspan="6" class="listcss">任何职务</td>
                    <td>操作</td>
                </tr>
                <template v-for="(item,index) in tableTwo.xxgzjlVoList">
                    <tr>
                        <td colspan="4"><el-date-picker v-model="item.time" range-separator="至" type="daterange" start-placeholder="开始日期" end-placeholder="结束日期" value-format="yyyy-MM-dd" format="yyyy-MM-dd" placeholder="选择日期时间"></el-date-picker></td>
                        <td colspan="2"><el-input v-model="item.gzdw" type="text" ></el-input></td>
                        <td colspan="6"><el-input v-model="item.zw" ></el-input></td>
                        <td>
                            <i class="el-icon-circle-plus" style="color:#409eff;font-size:20px" @click="qtListadd(item,index,3)" v-if="index===tableTwo.xxgzjlVoList.length-1"></i>
                            <i class="el-icon-remove" style="color:#f56c6c;font-size:20px" v-if="index!==tableTwo.xxgzjlVoList.length-1" @click="qtListdelet(item,index,3)"></i>
                        </td>
                    </tr>
                </template>
                 <tr>
                    <td :rowspan="tableTwo.fblwzzVOList.length+1" colspan="2" class="listcss">
                        <p class="wrapName"> 发表的主要学术论文和著作</p>
                        <!-- <el-input v-model="resetForm.hkxxdz" class="textareaInput"  type="textarea" maxlength="220" :show-word-limit="true"></el-input> -->
                    </td>
                    <td colspan="4" class="listcss">发表时间</td>
                    <td colspan="8" class="listcss">论文题目</td>
                    <td class="listcss">操作</td>
                </tr>
                <template v-for="(item,index) in tableTwo.fblwzzVOList">
                    <tr>
                        <td colspan="4"><el-date-picker v-model="item.fbsj" @change="changeTime1(item.fbsj,index)" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择日期时间"></el-date-picker></td>
                        <td colspan="8"><el-input v-model="item.lwtm" type="text" ></el-input></td>
                        <td>
                            <i class="el-icon-circle-plus" style="color:#409eff;font-size:20px" @click="qtListadd(item,index,4)" v-if="index===tableTwo.fblwzzVOList.length-1"></i>
                            <i class="el-icon-remove" style="color:#f56c6c;font-size:20px" v-if="index!==tableTwo.fblwzzVOList.length-1" @click="qtListdelet(item,index,4)"></i>
                        </td>
                    </tr>
                </template>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 学位学历信息</td>
                </tr>
                <tr>
                    <td  colspan="6" style="text-align:center;font-weight:bold;color:#409EFF">授学位单位,本科毕业单位和有关专业可直接输入或点击选择，如无授予单位请输入“无”</td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>获学士学位单位</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.xsxwdw"
                            :fetch-suggestions="universitySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>获学士学位专业</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.xsxwzy"
                            :fetch-suggestions="xszySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>获学士学位年月</td>
                    <td><el-date-picker v-model="resetForm.xsxwny" type="month" format="yyyy-MM"  value-format="yyyyMM" placeholder="选择日期时间"></el-date-picker></td>
                </tr>
                <tr>
                    <td class="listcss">本科毕业单位</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.bkbydw"
                            :fetch-suggestions="universitySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss">本科毕业专业</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.bkbyzy"
                            :fetch-suggestions="xszySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss">本科毕业年月</td>
                    <td><el-date-picker v-model="resetForm.bkbyny" type="month" format="yyyy-MM"  value-format="yyyyMM" placeholder="选择日期时间"></el-date-picker></td>
                </tr>
                <tr>
                    <td class="listcss">获硕士学位单位</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.ssxwdw"
                            :fetch-suggestions="universitySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss">获硕士学位专业</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.ssxwzy"
                            :fetch-suggestions="sszySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss">获硕士学位年月</td>
                    <td><el-date-picker v-model="resetForm.ssxwny" type="month" format="yyyy-MM" value-format="yyyyMM" placeholder="选择日期时间"></el-date-picker></td>
                </tr>
                <tr>
                    <td class="listcss">硕士毕业单位</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.ssbydw"
                            :fetch-suggestions="universitySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss">硕士毕业专业</td>
                    <td>
                        <el-autocomplete
                            v-model="tableThree.ssbyzy"
                            :fetch-suggestions="sszySearchAsync"
                            placeholder="请输入内容"
                            :maxlength="100"
                            >
                        </el-autocomplete>
                    </td>
                    <td class="listcss">硕士毕业年月</td>
                    <td><el-date-picker v-model="resetForm.ssbyny" type="month" format="yyyy-MM" value-format="yyyyMM" placeholder="选择日期时间"></el-date-picker></td>
                </tr>
                <tr>
                    <td  colspan="6" style="text-align:center;font-weight:bold;color:#409EFF">无相关学历毕业证号和学位证号，请在学位证号和毕业证号输入框中填“无”，境外人员的学位证号请填写教育部学位认证号</td>
                </tr>
                <tr>
                    <td class="listcss">学士学位证书编号</td>
                    <td>
                        <el-input v-model="resetForm.xsxwzsbh" :maxlength="20"></el-input>
                    </td>
                    <td class="listcss">本科毕业证书编号</td>
                    <td>
                        <el-input v-model="resetForm.bkbyzsbh" :maxlength="18"></el-input>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>最后学历</td>
                    <td>
                        <el-select v-model="resetForm.xlm" placeholder="请选择">
                                <el-option
                                    v-for="item in xlmOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                </tr>
                <tr>
                    <td class="listcss">硕士学位证书编号</td>
                    <td>
                        <el-input v-model="resetForm.ssxwzsbh" :maxlength="20"></el-input>
                    </td>
                    <td class="listcss">硕士毕业证书编号</td>
                    <td>
                        <el-input v-model="resetForm.ssbyzsbh" :maxlength="18"></el-input>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>最后学位</td>
                    <td>
                        <el-select v-model="resetForm.xwm" placeholder="请选择">
                                <el-option
                                    v-for="item in xwmOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>取得本科学历学习形式</td>
                    <td>
                        <el-select v-model="resetForm.bkxxxs" placeholder="请选择">
                                <el-option
                                    v-for="item in bkxxxsOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>获硕士学位方式</td>
                    <td>
                        <el-select v-model="resetForm.ssxwfs" placeholder="请选择">
                                <el-option
                                    v-for="item in ssxwfsOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                    <td class="listcss">在校生注册学号</td>
                    <td>
                        <el-input v-model="resetForm.zcxh" :maxlength="18"></el-input>
                    </td>
                </tr>
            </table>
             <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 报考信息</td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>报考院系</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.bkyxsm" placeholder="请选择" @change="getBkyxsmc">
                                <el-option
                                    v-for="item in bkyxsmOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>报考专业</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.bkzydm" placeholder="请选择" @visible-change="changeBkzy" @change="getSbId">
                                <el-option
                                    v-for="item in bkzydmOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value"
                                    >
                                </el-option>
                        </el-select>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>研究方向</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.bkyjfxm" placeholder="请选择" @visible-change="changebkyjfx" @change="getBkyjfxmc">
                                <el-option
                                    v-for="item in bkyjfxmOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>报考学习方式</td>
                    <td colspan="2">
                        <el-radio-group v-model="resetForm.bkxxfs">
                            <el-radio label="1">全日制</el-radio>
                            <el-radio label="2">非全日制</el-radio>
                        </el-radio-group>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>报考博导</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.bkbdbh" filterable placeholder="请选择" @visible-change="changeBkbd" @change="getBkbdsx">
                                <el-option
                                    v-for="item in bkbdxmOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>博导属性</td>
                    <td colspan="2">
                        <span v-if="resetForm.bkbdsx == 1">本单位导师</span>
                        <span v-if="resetForm.bkbdsx == 2">兼职导师</span>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>考试方式</td>
                    <td colspan="2">
                         <el-radio-group v-model="resetForm.ksfsm">
                            <el-radio label="11">普通招考</el-radio>
                            <el-radio label="23">硕博连读</el-radio>
                        </el-radio-group>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>报考类别</td>
                    <td colspan="2">
                        <el-radio-group v-model="resetForm.bklbm">
                            <el-radio label="11">非定向就业</el-radio>
                            <el-radio label="12">定向就业</el-radio>
                        </el-radio-group>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>专项计划</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.zxjh" filterable placeholder="请选择">
                                <el-option
                                    v-for="item in zxjhOption"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>是否申请考核</td>
                    <td colspan="2">
                        <el-radio-group v-model="resetForm.sqkh">
                            <el-radio label="0">否</el-radio>
                            <el-radio label="1">是</el-radio>
                        </el-radio-group>
                    </td>
                </tr>
                <tr>
                    <td class="listcss">定向就业单位</td>
                    <td colspan="2">
                        <el-input placeholder="请输入" v-model="resetForm.dxwpdw" :maxlength="60"/>
                    </td>
                    <td class="listcss">定向就业单位所在地</td>
                    <td colspan="2">
                        <el-cascader :options="nativeList" v-model="resetForm.dxwpdwszdm" style="min-min-width:400px" filterable :props="{ checkStrictly: true ,emitPath : false}" clearable></el-cascader>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>外国语</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.wgym" filterable placeholder="请选择" @visible-change="changeWgym" @change="getWgymc">
                            <el-option
                                v-for="item in wgymOption"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"><span class="mustInput">*</span>业务课一</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.ywk1m" filterable placeholder="请选择" @visible-change="changeWgym" @change="getYwk1mc">
                            <el-option
                                v-for="item in ywk1mOption"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </td>
                </tr>
                <tr>
                    <td class="listcss"><span class="mustInput">*</span>业务课二</td>
                    <td colspan="2">
                        <el-select v-model="resetForm.ywk2m" filterable placeholder="请选择" @visible-change="changeWgym" @change="getYwk2mc">
                            <el-option
                                v-for="item in ywk2mOption"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </td>
                    <td class="listcss"></td>
                    <td colspan="2">
                    </td>
                </tr>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="15" style="text-align:left;font-weight:bold">| 推荐人信息</td>
                </tr>
                <tr>
                    <td class="listcss" colspan="2">推荐人姓名</td>
                    <td class="listcss" colspan="5">推荐人职称</td>
                    <td class="listcss" colspan="2">推荐人性别</td>
                    <td class="listcss" colspan="6">推荐人工作单位</td>
                </tr>
                <tr>
                    <td colspan="2"><el-input v-model="resetForm.tjr1xm" type="text" :maxlength="20"></el-input></td>
                    <td colspan="5"><el-input v-model="resetForm.tjr1zc" type="text" :maxlength="50"></el-input></td>
                    <td colspan="2">
                        <el-radio-group v-model="resetForm.tjr1xbm">
                            <el-radio label="1">男</el-radio>
                            <el-radio label="0">女</el-radio>
                        </el-radio-group>
                    </td>
                    <td colspan="6"><el-input v-model="resetForm.tjr1gzdw" :maxlength="50"></el-input></td>
                </tr>
                <tr>
                    <td colspan="2"><el-input v-model="resetForm.tjr2xm" type="text" :maxlength="20"></el-input></td>
                    <td colspan="5"><el-input v-model="resetForm.tjr2zc" type="text" :maxlength="50"></el-input></td>
                    <td colspan="2">
                        <el-radio-group v-model="resetForm.tjr2xbm">
                            <el-radio label="1">男</el-radio>
                            <el-radio label="0">女</el-radio>
                        </el-radio-group>
                    </td>
                    <td colspan="6"><el-input v-model="resetForm.tjr2gzdw" :maxlength="50"></el-input></td>
                </tr>
            </table>
            <div class="xiBox">
                <!-- <div class="left">
                    <el-checkbox v-model="resetForm.sfyd" :checked="true" @change="change" true-label="1" false-label="0"></el-checkbox>
                    <p>我已阅读并同意<router-link tag="a" :to="{path:'/agreement',query:{from:'enrollPage'}}"  style="color:#409EFF">“浙江财经大学博士生网上报名须知”</router-link></p>
                </div> -->
                <el-button type="primary" @click="submit">提交报名</el-button>
            </div>
        </div>
        <el-dialog title="提交报名" class="registerDialog" :visible.sync="dialogShow" width="400px">
            <div class="cont">
            <i class="el-icon-success"/>
            <div class="registerInfo">
                <h2 v-if="this.$route.query.from && this.$route.query.from == 'enrolledPage'">修改成功!</h2>
                <h2 v-else>报名成功!</h2>
                <p><i>{{time}}</i>s后自动跳转至主页面</p>
            </div>
            </div>
            <div class="footer" slot="footer">
                <el-button type="primary" plain @click="goLogin">前往主页</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
export default {
    data(){
        return{
            resetForm:{
                //第一个table
                xm:this.$store.state.userLoginMsg.xm,
                xmpy:'',
                zjlx:this.$store.state.userLoginMsg.zjlx,
                zjhm:this.$store.state.userLoginMsg.zjhm,
                csrq:'',
                csdm:'',
                xbm:'',
                mzm:'',
                hfm:'',
                zzmmm:'',
                xyjrm:'',
                jgdm:'',
                hkszdm:'',
                txdz:'',
                yzbm:'',
                lxdh:'',
                yddh:'',
                dzxx:'',
                xxgzdw:'',
                xxgzdwxz:'',
                kslym:'',
                daszdm:'',
                daszdwdz:'',
                daszdw:'',
                daszdwyzbm:'',
                //第二个table
                jlcf:'',
                jtcy:'',
                xxgzjl:'',
                fblwzz:'',
                //第三个table
                xsxwdwm:'',
                xsxwzydm:'',
                xsxwny:'',
                bkbydwm:'',
                bkbydw:'',
                bkbyzymc:'',
                bkbyzydm:'',
                bkbyny:'',
                ssxwdwm:'',
                ssxwzydm:'',
                ssxwny:'',
                ssbydwm:'',
                ssbyzydm:'',
                ssbyny:'',
                xsxwzsbh:'',
                bkbyzsbh:'',
                xlm:'',
                xwm:'',
                ssxwzsbh:'',
                ssbyzsbh:'',
                bkxxxs:'',
                ssxwfs:'',
                zcxh:'',
                //第四个table
                bkyxsm:'',
                bkzydm:'',
                bkyjfxm:'',
                bkxxfs:'',//报考学习方式 1-全日制，2-非全日制
                bkbdxm:'',
                bkbdbh:'',//博导编号
                bkbdsx:'',//报考博导属性1-本单位导师，2-兼职导师
                ksfsm:'',//考试方式 11-普通招考，23-硕博连读
                bklbm:'',//报考类别 11-非定向就业，12－定向就业
                zxjh:'',
                sqkh:'',
                dxwpdw:'',
                dxwpdwszdm:'',
                wgym:'',
                ywk1m:'',
                ywk2m:'',
                //第五个table
                tjr1gzdw:'',
                tjr1xbm:'',
                tjr1xm:'',
                tjr1zc:'',
                tjr2gzdw:'',
                tjr2xbm:'',
                tjr2xm:'',
                tjr2zc:'',

                sfyd:'1',//是否阅读并同意’浙江财经大学博士生网上报名须知’(0未读1已读)
                nf:this.$store.state.zsnd.val,
                zp:'',
                
            },
            tableTwo:{
                jlcfVOList:[
                    {jcsj:'',jcdd:'',jcxm:'',jcmc:''}
                    ],
                jtcyList:[{xm:'',gx:'',hdwhz:'',lxdh:''}],
                xxgzjlVoList:[{time:'',gzdw:'',zw:''}],
                fblwzzVOList:[{fbsj:'',lwtm:''}]
            },
            tableThree:{//第三个表格第一部分展示字段
                xsxwdw:'',
                xsxwzy:'',
                bkbydw:'',
                bkbyzy:'',
                ssxwdw:'',
                ssxwzy:'',
                ssbydw:'',
                ssbyzy:'',
            },
            xxgzdwxzOption:[],
            nativeList:[],
            jgList:[],//籍贯（未用）
            hfOption:[
                {value:'1',label:'未婚'},
                {value:'2',label:'已婚'},
                {value:'3',label:'丧偶'},
                {value:'4',label:'离婚'},
                {value:'9',label:'其他'},
            ],
            xyjrOption:[ //现役军人下拉框
                {value:'0',label:'非军人'},
                {value:'1',label:'军队在职干部'},
                {value:'2',label:'军校学员'}
            ],
            schoolOption:[],//所有学校
            xszyOption:[],//所有本科专业
            sszyOption:[],//所有硕士专业
            ssxwfsOption:[ //获取硕士学位方式
                {value: "1", label: "学历教育"},
                {value:'2',label:'非学历教育(申请学位)'}
            ],
            xlmOption:[ //最后学历
                {value: "1", label: "博士研究生"},
                {value: "2", label: "硕士研究生(含应届硕士)"},
                {value: "3", label: "大学本科生(包括硕博连读)"},
                {value: "4", label: "本科以下"},
            ],
            xwmOption:[],//最后学位
            bkxxxsOption:[],//取得本科学历的学习形式
            colyOption:[],//考生来源
            bkyxsmOption:[],//报考院系
            bkzydmOption:[],//报考专业
            sbId:'',
            bkyjfxmOption:[],//研究方向
            bkbdxmOption:[],//博导
            zxjhOption:[],//博士专项计划
            wgymOption:[],//外语
            ywk1mOption:[],
            ywk2mOption:[],
            gxOption: [],
            dict: {},
            checked:false,
            headers:{
                token: this.$store.state.userLoginMsg.token
            },
            uploadLoading:'',
            //倒计时弹框参数
            dialogShow:false,
            time:10,
            timer:null
        }
            
    },
    methods:{
        xmpyIpt(){
            let reg = /^[a-zA-Z]{1,80}$/;
            if(!reg.test(this.resetForm.xmpy)){
                this.$message.error('请输入姓名拼音，长度小于80');
                this.resetForm.xmpy = ''
                return ;
            }
        },
        lengInputRule(length,val){
            if(this.resetForm.daszdwyzbm.length != length && this.resetForm.daszdwyzbm!='' && val == this.resetForm.daszdwyzbm){
               this.$message.error('档案所在单位邮编长度必须为6位');
               this.resetForm.daszdwyzbm = val.substring(0,6)
            }
            if(this.resetForm.yzbm.length != length && this.resetForm.yzbm!='' && val == this.resetForm.yzbm){
               this.$message.error('邮政编码长度必须为6位');
               this.resetForm.yzbm = val.substring(0,6)
            }
            if(this.resetForm.yddh.length != length && this.resetForm.yddh!='' && val == this.resetForm.yddh){
               this.$message.error('移动电话长度必须为11位');
               this.resetForm.yddh = val.substring(0,length)
            }
        },
        change(val){
            console.log(val,this.resetForm.sfyd,'pppppppppp')
            },
        changeTime(val,index){
            if(val == null){
                this.tableTwo.jlcfVOList[index].jcsj = ''
            }
            console.log(val,'22222222',this.tableTwo.jlcfVOList[index].jcsj)
        },
        changeTime1(val,index){
            if(val == null){
                this.tableTwo.fblwzzVOList[index].fbsj = ''
            }
            console.log(val,'22222222',index,this.tableTwo.fblwzzVOList)
        },
        changeZw(val,index){
            if(val.indexOf("(") != -1){
                var arr = val.split('(')
                if(arr.length>1){
                    this.tableTwo.jtcyList[index].hdwhz = `${arr[0]}(${arr[1]})`
                    this.tableTwo.jtcyList[index].hdwhz = this.tableTwo.jtcyList[index].hdwhz.substr(0, this.tableTwo.jtcyList[index].hdwhz.length - 1)
                }
            }
            console.log(this.tableTwo.jtcyList[index].hdwhz,'0000000000')
        },
        getBkyjfxmc(val){
            console.log('111',val)
            this.bkyjfxmOption.find(itm=>{
                if(val == itm.value){
                    this.resetForm.bkyjfxmc = itm.label
                }
            })
        },
        getBkyxsmc(val){
            this.bkyxsmOption.find(itm=>{
                if(val == itm.value){
                    this.resetForm.bkyxsmc = itm.label
                    this.resetForm.bkzydm = ''
                    this.resetForm.bkyjfxm = ''
                    this.getSbId()
                }
            })
        },
        getWgymc(val){
            this.wgymOption.find(itm=>{
                console.log(itm,'000')
                if(val == itm.value){
                    this.resetForm.wgymc = itm.label
                }
            })
        },
        getYwk1mc(val){
            this.ywk1mOption.find(itm=>{
                console.log(itm,'000')
                if(val == itm.value){
                    this.resetForm.ywk1mc = itm.label
                }
            })
        },
        getYwk2mc(val){
            this.ywk2mOption.find(itm=>{
                console.log(itm,'000')
                if(val == itm.value){
                    this.resetForm.ywk2mc = itm.label
                }
            })
        },
        goBack(){
            this.$router.go(-1)
        },
        getXxgzdwxzOption(){//学习或工作单位性质
            this.$http.get('/api/doctorate/before/dwxzOption').then(res => {
                this.xxgzdwxzOption = res.data.data
            })
        },
        getNtiveList(){ //省市区
             this.$http.get('/api/doctorate/bsOption/select/origoLevelThree').then(res => {
                this.nativeList = res.data.data
            })
        },
        getJgList(){ //籍贯二级
             this.$http.get('/api/doctorate/bsOption/select/origo').then(res => {
                this.jgList = res.data.data
            })
        },
        getCsly(){//考生来源
            this.$http.get('/api/doctorate/user/kslyOption').then(res => {
                this.colyOption = res.data.data
            })
        },
        getXwm(){//最后学位
            this.$http.get('/api/doctorate/bsOption/xwOption').then(res => {
                this.xwmOption = res.data.data
            })
        },
        getBkxxxs(){//取得本科学历的学习形式
            this.$http.get('/api/doctorate/bsOption/xxxsOption').then(res => {
                this.bkxxxsOption = res.data.data
            })
        },
        getZxjh(){//取得博士专项计划
            this.$http.get('/api/doctorate/bsOption/zxjhOption').then(res => {
                this.zxjhOption = res.data.data
            })
        },
        getBkyxsm(){//报考院系
            this.$http.post('/api/doctorate/bsOption/bkyxApplyOption').then(res => {
                this.bkyxsmOption = res.data.data
            })
        },
        getBkzydm(){//报考专业
            this.$http.post(`/api/doctorate/bsOption/bkzyApplyOption`,{yxdm:this.resetForm.bkyxsm}).then(res => {
                this.bkzydmOption = res.data.data
                console.log('enter')
            })
        },
        changeBkzy(val){
            if(this.resetForm.bkyxsm == '' && val){
                this.$message.warning('请先选择报考学院')
            }else if(val && this.resetForm.bkyxsm!=''){
                this.getBkzydm()
            }
        },
        getSbId(){
            this.bkzydmOption.forEach(val=>{
                if(val.value == this.resetForm.bkzydm){
                    console.log('000000000',val)
                    this.resetForm.bkzymc = val.label
                    this.sbId = val.sbId
                    this.getYjfx()
                    this.getBkbd()
                    this.getWgym()
                    this.getYwk2m()
                    this.getYwk1m()
                }
            })
        },
        changebkyjfx(val){
            if(this.sbId == '' && val){
                this.$message.warning('请先选择报考专业')
            }
        },
        getYjfx(){//研究方向
        console.log(this.sbId,'this.sbId')
            this.$http.get(`/api/doctorate/bsOption/yjfxOption/${this.sbId}`).then(res => {
                this.bkyjfxmOption = res.data.data
                if(this.bkyjfxmOption.length == 0){
                    this.bkyjfxmOption = [{value: "", label: "无"}]
                }
            })
            
        },
        getBkbd(){//报考博导
            this.bkbdxmOption = []
            this.$http.get(`/api/doctorate/bsOption/bdOption/${this.sbId}`).then(res => {
                res.data.data.forEach(val=>{
                    this.bkbdxmOption.push({label:val.xm,value:val.gh,dslb:val.dslb})
                })
            })
        },
        changeBkbd(val){
            if(this.sbId == '' && val){
                this.$message.warning('请先选择报考专业')
            }
        },
        getBkbdsx(){//获取博导属性
            this.bkbdxmOption.find(val=>{
                console.log(val,'1111')
                if(val.value == this.resetForm.bkbdbh){
                    this.resetForm.bkbdsx = val.dslb + ''
                    this.resetForm.bkbdxm = val.label
                }
            })
        },
        changeWgym(val){
            if(this.resetForm.bkzydm == '' && val){
                this.$message.warning('请先选择报考专业')
            }
        },
        getWgym(){//外语
            this.$http.get(`/api/doctorate/bsOption/wgyOption/${this.resetForm.bkyxsm}/${this.resetForm.bkzydm}`).then(res => {
                this.wgymOption = res.data.data
            })
        },
        getYwk2m(){//业务课2
            this.$http.get(`/api/doctorate/bsOption/ywkrOption/${this.resetForm.bkyxsm}/${this.resetForm.bkzydm}`).then(res => {
                this.ywk2mOption = res.data.data
                if(this.ywk2mOption.length == 0){
                    this.ywk2mOption.push({value:'',label:'无'})
                }
            })
        },
        getYwk1m(){//业务课1
            this.$http.get(`/api/doctorate/bsOption/ywkyOption/${this.resetForm.bkyxsm}/${this.resetForm.bkzydm}`).then(res => {
                this.ywk1mOption = res.data.data
            })
        },
        getSchoolOption(){//所有高校
            this.$http.get(`/api/doctorate/bsOption/bszsOption/qgyx`).then(res => {
                this.schoolOption = res.data.data
                this.schoolOption.push({value: "", label: "无"})
            })
        },
        getXszyOption(){//所有本科专业
            this.$http.get(`/api/doctorate/bsOption/bszsOption/bkzy`).then(res => {
                this.xszyOption = res.data.data
                this.xszyOption.push({value: "", label: "无"})
            })
        },
        getSszyOption(){//所有硕士专业
            this.$http.get(`/api/doctorate/bsOption/bszsOption/sszy`).then(res => {
                this.sszyOption = res.data.data
                this.sszyOption.push({value: "", label: "无"})
            })
        },
        loadDict() {//数据字典
            this.$http.get('/api/doctorate/bsOption/select/all').then(res => {
                this.dict = res.data.data
            })
        },
        //个人经历
        // 学习和工作经历增加
        qtListadd(val, index,nav) {
            let obj = {}
            let flag = false
            Object.values(val).some(itm=>{
                if(itm == ''){
                    flag = true
                    return true;
                }
            })
            if(flag){
                this.$message.warning('请把当期项填写完整')
                return;
            }
            if(nav == 1){
                obj = {jcsj:'',jcdd:'',jcxm:'',jcmc:''}
                this.tableTwo.jlcfVOList.push(obj)
            }else if(nav == 2){
                obj = {xm:'',gx:'',hdwhz:'',lxdh:''}
                this.tableTwo.jtcyList.push(obj)
            }else if(nav == 3){
                obj = {time:'',gzdw:'',zw:''}
                this.tableTwo.xxgzjlVoList.push(obj)
            }else if(nav == 4){
                obj = {fbsj:'',lwtm:''}
                this.tableTwo.fblwzzVOList.push(obj)
            }
        },
        // 学习和工作经历删除
        qtListdelet(val, index,nav) {
            if(nav == 1){
                this.tableTwo.jlcfVOList.splice(index,1)
            }else if(nav == 2){
                this.tableTwo.jtcyList.splice(index,1)
            }else if(nav == 3){
                this.tableTwo.xxgzjlVoList.splice(index,1)
            }else if(nav == 4){
                this.tableTwo.fblwzzVOList.splice(index,1)
            }
        },
        universitySearchAsync(queryString, cb){
            var restaurants = this.schoolOption;
            var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
            cb(results);
        },
        createStateFilter(queryString) {
            return (state) => {
                return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
            };
        },
        xszySearchAsync(queryString, cb){
            var restaurants = this.xszyOption;
            var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
            cb(results);
        },
        sszySearchAsync(queryString, cb){
            var restaurants = this.sszyOption;
            var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;
            cb(results);
        },
        submit(){
            if(this.resetForm.sfbm == 0){
                this.$message.error('请先阅读协议')
                return;
            }
            //校验家庭主要成员信息是否有未填项tableTwo.xxgzjlVoList
            let jtcyListFlag = false
            this.tableTwo.jtcyList.some(obj=>{
                let flag = false
                Object.values(obj).some(val=>{
                    if(val == ''){
                        flag = true
                        return true
                    }
                })
                if(flag){
                    this.$message.error('请把家庭主要成员信息填写完整')
                    jtcyListFlag = true
                    return true
                }else{
                   jtcyListFlag = false 
                }
            })
            if(jtcyListFlag){
                return;
            }
            //校验学习与工作经历信息是否有未填项tableTwo.xxgzjlVoList
            let xxgzjlVoListFlag = false
            this.tableTwo.xxgzjlVoList.some(obj=>{
                let flag = false
                Object.values(obj).some(val=>{
                    if(val == ''){
                        flag = true
                        return true
                    }
                })
                if(flag){
                    this.$message.error('请把学习与工作经历填写完整')
                    xxgzjlVoListFlag = true
                    return true
                }else{
                   xxgzjlVoListFlag = false 
                }
            })
            if(xxgzjlVoListFlag){
                return;
            }
            console.log( [...new Set(Object.values(this.tableTwo.jlcfVOList[0]))].join() == '','ppppppppppp')
            if([...new Set(Object.values(this.tableTwo.jlcfVOList[0]))].join() != ''){
                let jlcf = ''
                this.tableTwo.jlcfVOList.forEach((val,index)=>{
                    jlcf += `${val.jcsj}|${val.jcdd}|${val.jcxm}|${val.jcmc}#`
                })
                this.resetForm.jlcf = jlcf.substr(0, jlcf.length - 1);
            }else{
                this.resetForm.jlcf = ''
            }
            let jtcy = ''
            this.tableTwo.jtcyList.forEach((val,index)=>{
                    jtcy+=`${val.xm}|${val.gx}|${val.hdwhz}|${val.lxdh}#`
            }) 
            this.resetForm.jtcy = jtcy.substr(0, jtcy.length - 1);
            
            let xxgzjl = ''
            let jlArr = this.tableTwo.xxgzjlVoList
            jlArr.forEach((val,index)=>{
                console.log(val.time,'0000000000')
                val.time = typeof(val.time) == Array ? val.time.join(',') : val.time
                val.kssj && val.kssj!='' ? delete val.kssj : ''
                val.jssj && val.jssj!='' ? delete val.jssj : ''
                xxgzjl+=`${val.time}|${val.gzdw}|${val.zw}#`
            })
            this.resetForm.xxgzjl = xxgzjl.substr(0, xxgzjl.length - 1);
            
            if([...new Set(Object.values(this.tableTwo.fblwzzVOList[0]))].join() != ''){
                let fblwzz = ''
                this.tableTwo.fblwzzVOList.forEach((val,index)=>{
                        fblwzz+=`${val.fbsj}|${val.lwtm}#`
                }) 
                this.resetForm.fblwzz = fblwzz.substr(0, fblwzz.length - 1);
            }else{
                this.resetForm.fblwzz = ''
            }
            console.log(this.resetForm.jlcf,this.resetForm.jtcy,this.resetForm.xxgzjl,this.resetForm.fblwzz,'sssssssss')
            let ywk2mFlag = false
            this.ywk2mOption.some(val=>{ //业务课二非空校验
                if(val.value!='' && this.resetForm.ywk2m == ''){
                    ywk2mFlag = true
                    return true;
                }
            })
            if(ywk2mFlag){
                this.$message.error('请选择业务课二')
                return;
            }
            let path = '/api/doctorate/before/save'
            if(this.$route.query.from && this.$route.query.from == 'enrolledPage'){
                path = '/api/doctorate/before/update'
            }else{
                path = '/api/doctorate/before/save'
            }
            let loadingInstance = this.$loading({target:document.querySelector('.enrollPageBox')});
            this.$http.post(path,this.resetForm).then(res => {
                loadingInstance.close();
                if(res.data.code == 200){
                    this.$store.commit('updateSfbm',1)
                    console.log(res.data.data,'1111',typeof(res.data.data) == 'number')
                    if(typeof(res.data.data) == 'number'){
                        this.$store.commit('updateBmId',{id:res.data.data})
                    }
                    this.dialogShow = true
                    this.timer = setInterval(()=>{
                        this.time--
                        if(this.time == 0){
                            this.dialogShow = false
                            this.$router.push({
                                path: 'enrolledPage'
                            })
                        }
                    },1000)
                }else{
                    this.$message.error(res.data.message)
                }
            }).catch((err)=>{
                this.$message.error(err.data.message)
                loadingInstance.close();
            })
            
        },
        handleAvatarSuccess(res, file){
            console.log(res,'111111',file)
            this.uploadLoading.close()
            if(res.code == '200'){
                this.resetForm.zp = res.data.url;
                this.$message.success('上传成功')
            }else{
                this.$message.error(res.message)
            }
        },
        handleAvatarError(err,file, fileList){
            console.log(err)
            console.log(file)
            console.log('=========================')
        },
        beforeAvatarUpload(file){
            this.uploadLoading = this.$loading({
                lock: true,
                text: 'Loading',
                target: document.querySelector('.avtarBox')
            });
             const isJPG = file.type === 'image/jpeg';
             const isLt40K = file.size / 1024 <= 40;
             console.log(isLt40K,file.size)
             if (!isJPG) {
                this.uploadLoading.close()
                this.$message.error('上传头像图片只能是 JPG 格式!');
             }
             if (!isLt40K) {
                this.uploadLoading.close()
                this.$message.error('上传头像图片大小不能超过 40KB!');
             }
             return isJPG && isLt40K;
        },
        goLogin(){
            this.dialogShow = false
            this.$store.commit('updateSfbm',1)
            this.$router.push('/enrolledPage')
        },
        getFormData(){
            let loadingInstance = this.$loading({target:document.querySelector('.enrollPageBox')});
            this.$http.get(`/api/doctorate/before/selectById/${this.$store.state.bmId.id}`).then(res => {
                loadingInstance.close();
                if(res.data.code == 200){
                    this.resetForm = res.data.data
                    this.tableTwo.fblwzzVOList = this.resetForm.fblwzzVOList
                    this.tableTwo.jlcfVOList = this.resetForm.jlcfVOList
                    this.tableTwo.jtcyList = this.resetForm.jtcyList
                    this.tableTwo.xxgzjlVoList = this.resetForm.xxgzjlVoList
                    if(!this.resetForm.jlcfVOList || this.resetForm.jlcfVOList.length == 0){ //空添加一行展示数据
                        this.tableTwo.jlcfVOList = [{jcdd:'',jcmc:'',jcsj:'',jcxm:''}]
                    }
                    if(this.resetForm.jlcfVOList && this.resetForm.jlcfVOList.length>0){ // null过滤
                        this.tableTwo.jlcfVOList.forEach(val=>{
                            for(let i in val){
                                if(val[i] == null || val[i] == 'null'){
                                    val[i] = ''
                                }
                            }
                        })
                    }
                    console.log(this.tableTwo.jlcfVOList,'0000000000000000')
                    if(!this.resetForm.fblwzzVOList || this.resetForm.fblwzzVOList.length == 0){
                        this.tableTwo.fblwzzVOList = [{fbsj:'',lwtm:''}]
                    }
                    if(this.resetForm.fblwzzVOList && this.resetForm.fblwzzVOList.length>0){ // null过滤
                        this.tableTwo.fblwzzVOList.forEach(val=>{
                            for(let i in val){
                                if(val[i] == null || val[i] == 'null'){
                                    val[i] = ''
                                }
                            }
                        })
                    }
                    console.log(this.resetForm.fblwzzVOList.length,this.tableTwo.fblwzzVOList)
                    if(this.tableTwo.xxgzjlVoList.length == 0){
                        this.tableTwo.xxgzjlVoList = [{time:'',gzdw:'',zw:''}]
                    }
                    if(this.tableTwo.xxgzjlVoList[0].kssj){
                        this.tableTwo.xxgzjlVoList.forEach(val=>{
                            val.time = [val.kssj,val.jssj]
                        })
                    }
                    
                    this.tableThree.xsxwdw = this.resetForm.xsxwdw
                    this.tableThree.xsxwzy = this.resetForm.xsxwzymc
                    this.tableThree.bkbydw = this.resetForm.bkbydw
                    this.tableThree.bkbyzy = this.resetForm.bkbyzymc
                    this.tableThree.ssxwdw = this.resetForm.ssxwdw
                    this.tableThree.ssxwzy = this.resetForm.ssxwzymc
                    this.tableThree.ssbydw = this.resetForm.ssbydw
                    this.tableThree.ssbyzy = this.resetForm.ssbyzymc
                    this.sbId = this.resetForm.sbid
                    this.$http.post(`api/doctorate/bsOption/bkzyApplyOption`,{yxdm:this.resetForm.bkyxsm}).then(res => {
                        this.bkzydmOption = res.data.data
                    }).then(()=>{
                        this.getSbId()
                    })
                }else{
                    this.$message.error(res.data.message)
                }
            }).catch(()=>{
                loadingInstance.close();
            })
        }
    },
    created(){
        this.getNtiveList()
        this.getXxgzdwxzOption()
        this.getJgList()
        this.getCsly()
        this.getXwm()
        this.getBkxxxs()
        this.getZxjh()
        this.getBkyxsm()
        this.getSchoolOption()
        this.getXszyOption()
        this.getSszyOption()
        this.loadDict()
        // console.log(this.$route.query,'11111111')
        if(this.$route.query.xydm && this.$route.query.xydm != undefined){
            console.log(this.$route.query,'11111111')
            this.resetForm.bkyxsm = this.$route.query.xydm
            this.resetForm.bkzydm = this.$route.query.zydm
            this.resetForm.bkyjfxm = this.$route.query.yjfxDm ? this.$route.query.yjfxDm : ''
            this.resetForm.bkyxsmc = this.$route.query.xymc
            this.resetForm.bkzymc = this.$route.query.zymc
            this.resetForm.bkyjfxmc = this.$route.query.yjfxMc
            this.sbId = this.$route.query.id
            if(this.$route.query.xxfs == '全日制'){
                this.resetForm.bkxxfs = "1"
            }else{
                this.resetForm.bkxxfs = "2"
            }
            this.$http.post(`/api/doctorate/bsOption/bkzyApplyOption`,{yxdm:this.resetForm.bkyxsm}).then(res => {
                this.bkzydmOption = res.data.data
            }).then(()=>{
                this.getSbId()
            })
        }
        
    },
    mounted(){
        if(this.$route.query.from && this.$route.query.from == 'enrolledPage'){
            this.getFormData()
        }
    },
    watch: {
        '$route.path':{
            handler: function(newVal,oldVal) {
                console.log('000')
                 console.log(newVal,oldVal,'1111')
            }
        },
        'resetForm.xsxwdwm': {
            handler: function() {
                console.log(this.resetForm.xsxwdwm,'1111111111')
            },
            deep: true
        },
        'tableThree.xsxwdw': {
            handler: function(val) {
                this.schoolOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.xsxwdwm = school.label 
                        this.resetForm.xsxwdw = school.value 
                    }
                })
            },
            deep: true
        },
        'tableThree.xsxwzy': {
            handler: function(val) {
                this.xszyOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.xsxwzydm = school.label 
                        this.resetForm.xsxwzymc = school.value 
                    }
                })
            },
            deep: true
        },
        'tableThree.bkbydw': {
            handler: function(val) {
                this.schoolOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.bkbydwm = school.label 
                        this.resetForm.bkbydw = school.value 
                    }
                })
            },
            deep: true
        },
        'tableThree.bkbyzy': {
            handler: function(val) {
                this.xszyOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.bkbyzydm = school.label 
                        this.resetForm.bkbyzymc = school.value
                    }
                })
            },
            deep: true
        },
        'tableThree.ssxwdw': {
            handler: function(val) {
                this.schoolOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.ssxwdwm = school.label 
                        this.resetForm.ssxwdw = school.value 
                    }
                })
            },
            deep: true
        },
        'tableThree.ssxwzy': {
            handler: function(val) {
                this.sszyOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.ssxwzydm = school.label 
                        this.resetForm.ssxwzymc = school.value 
                    }
                })
            },
            deep: true
        },
        'tableThree.ssbydw': {
            handler: function(val) {
                this.schoolOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.ssbydwm = school.label 
                        this.resetForm.ssbydw = school.value 
                    }
                })
            },
            deep: true
        },
        'tableThree.ssbyzy': {
            handler: function(val) {
                this.sszyOption.find(school=>{
                    if(school.value == val){
                        this.resetForm.ssbyzydm = school.label 
                        this.resetForm.ssbyzymc = school.value 
                    }
                })
            },
            deep: true
        },
    },
    beforeDestroy(){
        clearInterval(this.timer)
    }
}
</script>
<style lang="scss" scoped>
     .enrollPageBox{
        width: 80%;
        min-height:calc(100vh - 120px);
        min-width:1300px;
        margin: 20px auto;
        background:#fff;
        .enrollPageBox-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
            .right{
                display: flex;
                align-items: center;
                justify-content: center;
                .el-icon-date{
                    font-size: 19px;
                    margin-right: 10px;
                    color:#409EFF;
                }
                p{
                    font-size:14px;
                    color:#409EFF;
                    margin-right: 10px;
                }
            }
        }
        .enrollPageBox-cont{
            width:calc(100% - 40px);
            padding:20px;
            height: calc(100vh - 220px);
            overflow-y:auto;
            /deep/ table {
                width: 100%;
                // table-layout:fixed;
                color: #444;
                font-size: 14px;
                white-space: nowrap;
                font-weight: 400;
                margin-bottom: 20px;
                thead {
                    height: 60px !important;
                    border: 1px solid #e0e0e0;
                }
                tr {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                }
                th,
                td {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                    line-height: 48px;
                    padding-left: 5px;
                    padding-right: 5px;
                    text-align: center;
                    // width: 150px;
                    font-size: 14px;
                }
                .listcss {
                    background: #f2f2f2;
                    // width: 150px;
                    .mustInput{
                        color:#f56c6c;
                        margin-right:2px;
                    }
                }
                .el-select,.el-input,.el-cascader,.el-date-editor{
                    width:calc(100% - 0px);
                }
                .wrapName{
                    display: inline-block;
                    width: 100%;
                    line-height: 20px;
                    white-space:normal;
                    word-break: break-all;
                    text-align: left;
                }
                .textareaInput{
                    height: 100%;
                    textarea{
                        height: 100%!important;
                    }
                }
            }
            .avtarBox{
                // width: 120px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: space-around;
                ul li{
                    // width:82px;
                    font-size:8px;
                    font-weight:400;
                    line-height:20px;
                    color:#ccc;
                    word-break: break-all;
                    white-space: normal;
                    text-align: left;
                }
            }
            .experienceTable{
                table-layout:fixed;
            }
            .xiBox{
                display: flex;
                // justify-content: space-between;
                justify-content: center;
                align-items: center;
                .left{
                    display: flex;
                    align-items: center;
                    p{
                        font-size:14px;
                        margin-left:20px;
                        cursor: pointer;
                    }
                }
            }
        }
        /deep/ .registerDialog{
            .el-dialog__header{
                border-bottom:1px solid #ccc;
            }
            .cont{
              height:60px;
              display: flex;
              justify-content: center;
              // padding-top:20px;
              .el-icon-success{
                font-size:25px;
                color:#67c13d;
                margin-right:10px;
              }
              .registerInfo{
                h2{
                  font-size:20px;
                }
                p{
                  font-size:16px;
                  color:#666;
                  height: 30px;
                  line-height: 30px;
                  i{
                    color:#409eff;
                    font-style: normal;
                  }
                }
              }
            }
            .el-dialog__footer{
                border-top:1px solid #ccc;
                .footer{
                    text-align: center;
                    button{
                        margin-left:30px;
                    }
                }
            }
        }
    }
</style>