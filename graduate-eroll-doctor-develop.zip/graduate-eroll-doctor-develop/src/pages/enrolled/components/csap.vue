<template>
    <div class="csap-box">
        <header class="csap-box-header">
            <div class="left">
                <img src="../../../assets/img/csap.png" alt="" srcset="">
                <div class="left-info">
                    <h2>初试考试安排</h2>
                    <p>请在开考前仔细阅读！</p>
                </div>
            </div>
        </header>
        <div class="csap-box-cont" v-loading="loading">
            <table>
                <tr>
                    <td class="listcss">考生编号</td>
                    <td colspan="6">{{ksxx[0].ksbh}}</td>
                </tr>
                <tr>
                    <td class="listcss" :rowspan="ksxx.length + 1">初试信息</td>
                    <td colspan="2" class="listcss">考试科目</td>
                    <td colspan="2" class="listcss">考场</td>
                    <td colspan="2" class="listcss">考试时间</td>
                    <!-- {{ksxx.cssj[0].kssj}} {{ksxx.cssj[0].jtkssj}}-{{ksxx.cssj[0].jtjssj}} -->
                </tr>
                <tr v-if="ksxx.length>0">
                    <td colspan="2" >{{ksxx[0].kmmc}}</td>
                    <td colspan="2">{{ksxx[0].cdmc}}</td>
                    <td colspan="4">{{ksxx[0].kssj}}</td>
                    <!-- {{ksxx.cssj[0].kssj}} {{ksxx.cssj[0].jtkssj}}-{{ksxx.cssj[0].jtjssj}} -->
                </tr>
                <tr v-if="ksxx.length>1">
                    <td colspan="2" >{{ksxx[1].kmmc}}</td>
                    <td colspan="2">{{ksxx[1].cdmc}}</td>
                    <td colspan="2">{{ksxx[1].kssj}}</td>
                </tr>
                <tr v-if="ksxx.length>2">
                    <td colspan="2" >{{ksxx[2].kmmc}}</td>
                    <td colspan="2">{{ksxx[2].cdmc}}</td>
                    <td colspan="2">{{ksxx[2].kssj}}</td>
                </tr>
                <tr>
                    <td rowspan="10" class="listcss">初试地点</td>
                    <td colspan="6" rowspan="10">
                        <baiduMap />
                    </td>
                </tr>
            </table>
        </div>
    </div>
</template>
<script>
import baiduMap from './bauduMap.vue'
export default {
     components:{
        baiduMap
    },
    data(){
        return {
            ksxx:[
                {cdmc: "",
                jtjssj: "",
                jtkssj: "",
                kmmc: "",
                ksbh: "",
                ksrq: "",
                kssj: ""}
            ],
            loading:true
        }
    },
    methods:{
        getData(){
            this.$http.get(`/api/doctorate/after/selectByZjhm/${this.$store.state.userLoginMsg.zjhm}`).then(res=>{
                this.loading = false
                if(res.data.code == 200){
                    console.log(res.data.data.length)
                    if(res.data.data == null || res.data.data.length == 0){
                        console.log(res.data.data.length,this.ksxx)
                        return ;
                    }
                    this.ksxx = res.data.data
                    console.log(this.ksxx)
                }else{
                    this.$message.error(res.data.message)
                }
            }).catch(err=>{
                this.loading = false
                this.$message.error(err.data.message)
            })
        }
    },
    created(){
        console.log(this.$store.state,'000000000000')
        this.getData()
    }
}
</script>
<style lang="scss">
    .csap-box{
        width:100%;
        height:100%;
        .csap-box-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
        }
        .csap-box-cont{
            height: calc(100vh - 310px);
            overflow-y: auto;
            /deep/ table {
                width: 100%;
                // table-layout:fixed;
                color: #444;
                font-size: 14px;
                white-space: nowrap;
                font-weight: 400;
                margin-bottom: 20px;
                thead {
                    height: 60px !important;
                    border: 1px solid #e0e0e0;
                }
                tr {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                }
                th,
                td {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                    line-height: 48px;
                    padding-left: 5px;
                    text-align: center;
                    width: 150px;
                    font-size: 14px;
                }
                .left_cont {
                    text-align: left;
                    padding-left: 10px;
                    font-weight: bold;
                }
                .listcss {
                    background: #f2f2f2;
                    width: 150px;
                    .mustInput{
                        color:#f56c6c;
                        margin-right:2px;
                    }
                }
                .el-select,.el-input,.el-cascader,.el-date-editor{
                    width:calc(100% - 2px);
                }
                .wrapName{
                    display: inline-block;
                    width: 100%;
                    line-height: 20px;
                    white-space:normal;
                    word-break: break-all;
                    text-align: left;
                }
                .textareaInput{
                    height: 100%;
                    textarea{
                        height: 100%!important;
                    }
                }
            }
            table{
                margin-top:20px;
            }
        }
    }
</style>