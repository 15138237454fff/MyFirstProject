<template>
    <baidu-map class="map"  :center="mapCenter" :zoom="mapZoom" @ready="handlerBMap">
        <!-- 添加一个小红点的，并将当前的经纬度写入数据中 -->
        <bm-marker :position="{lng:mapCenter.lng, lat: mapCenter.lat}" animation="BMAP_ANIMATION_BOUNCE">
            <bm-label content="浙江财经大学(下沙校区)"  :offset="{width: -35, height: -40}"/>
        </bm-marker>
    </baidu-map>
</template>
<script>
export default {
  data () {
    return {
      mapZoom: 15,
      mapCenter: { lng: 0, lat: 0 },
      locationCity:'杭州市',
      mapLocation: {
        address: '浙江省杭州市下沙高教园区学源街18号'
      }
    }
  },
  methods: {
    handlerBMap ({BMap, map}) {
      this.BMap = BMap
      this.map = map
      var that = this
      var myGeo = new this.BMap.Geocoder() //创建地址解析器实例
      myGeo.getPoint(this.mapLocation.address, function(point) { //将地址解析结果显示在地图上，并调整地图视野
        if (point) {
          that.makerCenter(point)
        }
      }, this.locationCity)
    },
    makerCenter(point) {
      if (this.map) {
        // this.map.clearOverlays()
        // this.map.addOverlay(new this.BMap.Marker(point)) //添加遮挡物
        this.mapCenter.lng = point.lng
        this.mapCenter.lat = point.lat
        this.mapZoom = 15
      }
    }
  }
}
</script>
<style lang="scss">
    .map{
        width:calc(100% - 20px);
        height:100%;
        min-height: 500px;
        padding:10px;
    }
    .BMap_cpyCtrl {
        display:none;
    }
    .anchorBL{
        display:none;
    }
</style>