<template>
    <div class="tableComponent" v-loading.lock="loading">
        <header class="tableComponent-header">
            <div class="left" v-if="isModify">
                <img src="../../../assets/img/personCenter.png" alt="" srcset="">
                <div class="left-info">
                    <h2>报名信息</h2>
                    <p>报名起止日期: {{$store.state.userLoginMsg.startTime}} 至 {{$store.state.userLoginMsg.endTime}}</p>
                </div>
            </div>
            <div class="left" v-if="!isModify">
                <img src="../../../assets/img/personCenter.png" alt="" srcset="">
                <div class="left-info">
                    <h2>报名信息</h2>
                    <p>已超过报名截止时间，不可修改报名信息！</p>
                </div>
            </div>
            <div class="right" v-if="isModify">
                <el-button type="primary"  @click="modify">修改</el-button>
            </div>
        </header>
        <div class="tableComponent-cont" >
            <table>
                <tr>
                    <td class="listcss" colspan="9" style="text-align:left;font-weight:bold">| 基本信息</td>
                </tr>
                <tr>
                    <td class="listcss">姓名</td>
                    <td colspan="3">{{resetForm.xm}}</td>
                    <td class="listcss">姓名拼音</td>
                    <td colspan="3">{{resetForm.xmpy}}</td>
                    <td rowspan="5">
                        <img  :src="resetForm.zp" class="avatar" style="width:100px;height:100px;display: inline;">
                    </td>
                </tr>
                <tr>
                    <td class="listcss">证件类型</td>
                    <td colspan="3">{{resetForm.zjlx | zjlxFilter}}</td>
                    <td class="listcss">证件号码</td>
                    <td colspan="2">{{resetForm.zjhm}}</td>
                </tr>
                <tr>
                    <td class="listcss" >出生日期</td>
                    <td colspan="3">{{resetForm.csrqzm}}</td>
                    <td class="listcss">出生所在地</td>
                    <td colspan="2">{{resetForm.csdmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">民族</td>
                    <td colspan="3">{{resetForm.mzmc}}</td>
                    <td class="listcss">性别</td>
                    <td colspan="2">{{resetForm.xbm | sexFilter}}</td>
                </tr>
                <tr>
                    <td class="listcss">婚姻状况</td>
                    <td colspan="3">{{resetForm.hfm | toHf}}</td>
                    <td class="listcss">政治面貌</td>
                    <td colspan="2">{{resetForm.zzmmmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">现役军人</td>
                    <td colspan="3">{{resetForm.xyjrm | toXyjr}}</td>
                    <td class="listcss">籍贯</td>
                    <td colspan="4">{{resetForm.jgmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">户口所在地</td>
                    <td colspan="3">{{resetForm.hkszdmc}}</td>
                    <td class="listcss">通讯地址</td>
                    <td colspan="4">{{resetForm.txdz}}</td>
                </tr>
                <tr>
                    <td class="listcss">邮政编码</td>
                    <td colspan="3">{{resetForm.yzbm}}</td>
                    <td class="listcss">固定电话</td>
                    <td colspan="4">{{resetForm.lxdh}}</td>
                </tr>
                <tr>
                    <td class="listcss">移动电话</td>
                    <td colspan="3">{{resetForm.yddh}}</td>
                    <td class="listcss">电子信箱</td>
                    <td colspan="4">{{resetForm.dzxx}}</td>
                </tr>
                <tr>
                    <td class="listcss">现在学习或工作单位</td>
                    <td colspan="3">{{resetForm.xxgzdw}}</td>
                    <td class="listcss">现在学习或工作单位性质</td>
                    <td colspan="4">{{resetForm.xxgzdwxzmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">考生来源</td>
                    <td colspan="3">{{resetForm.kslymc}}</td>
                    <td class="listcss">档案所在地</td>
                    <td colspan="4">{{resetForm.daszdmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">档案所在单位名称</td>
                    <td colspan="3">{{resetForm.daszdw}}</td>
                    <td class="listcss">档案所在单位邮编</td>
                    <td colspan="4">{{resetForm.daszdwyzbm}}</td>
                </tr>
                <tr>
                    <td class="listcss">档案所在单位地址</td>
                    <td colspan="8">{{resetForm.daszdwdz}}</td>
                </tr>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="14" style="text-align:left;font-weight:bold">| 个人经历</td>
                </tr>
                <tr>
                    <td :rowspan="resetForm.jlcfVOList.length+1" colspan="2" class="listcss">
                        <p class="wrapName">何时何地何原因受过何种奖励或处分</p>
                    </td>
                    <td colspan="2">时间</td>
                    <td colspan="2">地点</td>
                    <td colspan="6">奖惩项目</td>
                    <td colspan="2">奖惩名称</td>
                </tr>
                <template v-for="item in resetForm.jlcfVOList">
                    <tr>
                        <td colspan="2">{{item.jcsj}}</td>
                        <td colspan="2">{{item.jcdd}}</td>
                        <td colspan="6">{{item.jcxm}}</td>
                        <td colspan="2">{{item.jcmc}}</td>
                    </tr>
                </template>
                 <tr v-if="resetForm.jtcyList">
                    <td :rowspan="resetForm.jtcyList.length+1" colspan="2" class="listcss">
                        <p class="wrapName">家庭主要成员</p>
                    </td>
                    <td colspan="2">姓名</td>
                    <td colspan="2">与本人关系</td>
                    <td colspan="6">在何单位工作 | 任何职务</td>
                    <td colspan="2">联系电话</td>
                </tr>
                <template v-for="item in resetForm.jtcyList">
                    <tr>
                        <td colspan="2">{{item.xm}}</td>
                        <td colspan="2">{{item.gxmc}}</td>
                        <td colspan="6">{{item.hdwhz}}</td>
                        <td colspan="2">{{item.lxdh}}</td>
                    </tr>
                </template>
                 <tr v-if="resetForm.xxgzjlVoList">
                    <td :rowspan="resetForm.xxgzjlVoList.length+1" colspan="2" class="listcss">
                        <p class="wrapName"> 学习与工作经历(请从高中学习经历填起)</p>
                    </td>
                    <td colspan="4">起止年月</td>
                    <td colspan="6">任何职务</td>
                    <td colspan="2">学习或工作单位</td>
                </tr>
                <template v-for="item in resetForm.xxgzjlVoList">
                    <tr>
                        <td colspan="4">{{item.kssj}} 至 {{item.jssj}}</td>
                        <td colspan="6">{{item.zw}}</td>
                        <td colspan="2">{{item.gzdw}}</td>
                    </tr>
                </template>
                 <tr v-if="resetForm.fblwzzVOList">
                    <td :rowspan="resetForm.fblwzzVOList.length+1" colspan="2" class="listcss">
                        <p class="wrapName"> 发表的主要学术论文和著作</p>
                    </td>
                    <td colspan="4">发表时间</td>
                    <td colspan="8">论文题目</td>
                </tr>
                <template v-for="item in resetForm.fblwzzVOList" >
                    <tr>
                        <td colspan="4">{{item.fbsj}}</td>
                        <td colspan="8">{{item.lwtm}}</td>
                    </tr>
                </template>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 学位学历信息</td>
                </tr>
                <tr>
                    <td class="listcss">获学士学位单位</td>
                    <td>{{resetForm.xsxwdw}}</td>
                    <td class="listcss">获学士学位专业</td>
                    <td>{{resetForm.xsxwzymc}}</td>
                    <td class="listcss">获学士学位年月</td>
                    <td>{{resetForm.xsxwnyzm}}</td>
                </tr>
                <tr>
                    <td class="listcss">本科毕业单位</td>
                    <td>{{resetForm.bkbydw}}</td>
                    <td class="listcss">本科毕业专业</td>
                    <td>{{resetForm.bkbyzymc}}</td>
                    <td class="listcss">本科毕业年月</td>
                    <td>{{resetForm.bkbynyzm}}</td>
                </tr>
                <tr>
                    <td class="listcss">获硕士学位单位</td>
                    <td>{{resetForm.ssxwdw}}</td>
                    <td class="listcss">获硕士学位专业</td>
                    <td>{{resetForm.ssxwzymc}}</td>
                    <td class="listcss">获硕士学位年月</td>
                    <td>{{resetForm.ssxwnyzm}}</td>
                </tr>
                <tr>
                    <td class="listcss">硕士毕业单位</td>
                    <td>{{resetForm.ssbydw}}</td>
                    <td class="listcss">硕士毕业专业</td>
                    <td>{{resetForm.ssbyzymc}}</td>
                    <td class="listcss">硕士毕业年月</td>
                    <td>{{resetForm.ssbynyzm}}</td>
                </tr>
                <tr>
                    <td class="listcss">学士学位证书编号</td>
                    <td>{{resetForm.xsxwzsbh}}</td>
                    <td class="listcss">本科毕业证书编号</td>
                    <td>{{resetForm.bkbyzsbh}}</td>
                    <td class="listcss">最后学历</td>
                    <td>{{resetForm.xlm | toXl}}</td>
                </tr>
                <tr>
                    <td class="listcss">硕士学位证书编号</td>
                    <td>{{resetForm.ssxwzsbh}} </td>
                    <td class="listcss">硕士毕业证书编号</td>
                    <td>{{resetForm.ssbyzsbh}}</td>
                    <td class="listcss">最后学位</td>
                    <td>{{resetForm.xwmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">取得本科学历学习形式</td>
                    <td>{{resetForm.bkxxxsmc}}</td>
                    <td class="listcss">获硕士学位方式</td>
                    <td>{{resetForm.ssxwfsmc}}</td>
                    <td class="listcss">在校生注册学号</td>
                    <td>{{resetForm.zcxh}}</td>
                </tr>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 报考信息</td>
                </tr> 
                <tr>
                    <td class="listcss">报考院系</td>
                    <td colspan="2">{{resetForm.bkyxsmc}} </td>
                    <td class="listcss">报考专业</td>
                    <td colspan="2">{{resetForm.bkzymc}}</td>
                </tr>
                <tr>
                    <td class="listcss">研究方向</td>
                    <td colspan="2">{{resetForm.bkyjfxmc}}</td>
                    <td class="listcss">报考学习方式</td>
                    <td colspan="2">{{resetForm.bkxxfs | toBkxxfs}}</td>
                </tr>
                <tr>
                    <td class="listcss">报考博导</td>
                    <td colspan="2">{{resetForm.bkbdxm}}</td>
                    <td class="listcss">博导属性</td>
                    <td colspan="2">{{resetForm.bkbdsx | toBkbdsx}}</td>
                </tr>
                <tr>
                    <td class="listcss">考试方式</td>
                    <td colspan="2">{{resetForm.ksfsm | toKsfs}}</td>
                    <td class="listcss">报考类别</td>
                    <td colspan="2">{{resetForm.bklbm | toBklb}}</td>
                </tr>
                <tr>
                    <td class="listcss">专项计划</td>
                    <td colspan="2">{{resetForm.zxjhmc}}</td>
                    <td class="listcss">是否申请考核</td>
                    <td colspan="2">{{resetForm.sqkhmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">定向就业单位</td>
                    <td colspan="2">{{resetForm.dxwpdw}}</td>
                    <td class="listcss">定向就业单位所在地</td>
                    <td colspan="2">{{resetForm.dxwpdwszdmc}}</td>
                </tr>
                <tr>
                    <td class="listcss">外国语</td>
                    <td colspan="2">{{resetForm.wgymc}}</td>
                    <td class="listcss">业务课一</td>
                    <td colspan="2">{{resetForm.ywk1mc}}</td>
                </tr>
                <tr>
                    <td class="listcss">业务课二</td>
                    <td colspan="2">{{resetForm.ywk2mc}}</td>
                    <td></td>
                    <td colspan="2"></td>
                </tr>
            </table>
            <table class="experienceTable">
                <tr>
                    <td class="listcss" colspan="15" style="text-align:left;font-weight:bold">| 推荐人信息</td>
                </tr>
                <tr>
                    <td class="listcss" colspan="2">推荐人姓名</td>
                    <td class="listcss" colspan="5">推荐人职称</td>
                    <td class="listcss" colspan="2">推荐人性别</td>
                    <td class="listcss" colspan="6">推荐人工作单位</td>
                </tr>
                <tr>
                    <td colspan="2">{{resetForm.tjr1xm}}</td>
                    <td colspan="5">{{resetForm.tjr1zc}}</td>
                    <td colspan="2">{{resetForm.tjr1xbm | sexFilter}}</td>
                    <td colspan="6">{{resetForm.tjr1gzdw}}</td>
                </tr>
                <tr>
                    <td colspan="2">{{resetForm.tjr2xm}}</td>
                    <td colspan="5">{{resetForm.tjr2zc}}</td>
                    <td colspan="2">{{resetForm.tjr2xbm | sexFilter}}</td>
                    <td colspan="6">{{resetForm.tjr2gzdw}}</td>
                </tr>
            </table>
        </div>
    </div>
</template>
<script>
export default {
    props:['navIndex'],
    data(){
        return{
            resetForm:{
                jlcfVOList:[{jcdd:'',jcmc:'',jcsj:'',jcxm:''}],
                jtcyList:[{hdwhz:'',gx:'',lxdh:'',xm:''}],
                xxgzjlVoList:[{jssj:'',gzdw:'',zw:'',kssj:''}],
                fblwzzVOList:[{fbsj:'',lwtm:''}],
                zp:''
            },
            loading:true
        }
            
    },
    filters:{
        toHf(val){
            switch (val) {
                case '1':
                    return '未婚'
                case '2':
                    return '已婚'
                case '3':
                    return '丧偶'
                case '4':
                    return '离婚'
                case '9':
                    return '其他'
            }
        },
        toXyjr(val){
            switch (val) {
                case '1':
                    return '军队在职干部'
                case '2':
                    return '军校学员'
                case '0':
                    return '非军人'
            }
        },
        toBkxxfs(val){
             switch (val) {
                case '1':
                    return '全日制'
                case '2':
                    return '非全日制'
            }
        },
        toBkbdsx(val){
            switch (val) {
                case '1':
                    return '本单位导师'
                case '2':
                    return '兼职导师'
            }
        },
        toKsfs(val){
            switch (val) {
                case '11':
                    return '普通招考'
                case '23':
                    return '硕博连读'
            }
        },
        toBklb(val){
            switch (val) {
                case '11':
                    return '非定向就业'
                case '12':
                    return '定向就业'
            }
        },
        toXl(val){
             switch (val) {
                case '1':
                    return '博士研究生'
                case '2':
                    return '硕士研究生(含应届硕士)'
                case '3':
                    return '大学本科生(包括硕博连读)'
                case '4':
                    return '本科以下'
            }
        }
    },
    methods:{
        modify(){
            this.$router.push({path:'/enrollPage',query:{from:'enrolledPage'},lock:true})
        },
        getData(){
            // this.$store.commit('updateBmId',{id:367})  ${this.$store.state.bmId.id}
            this.$http.get(`/api/doctorate/before/selectById/${this.$store.state.bmId.id}`).then(res => {
                this.loading = false
                if(res.data.code == 200){
                    this.resetForm = res.data.data
                    if(this.resetForm.jlcfVOList && this.resetForm.jlcfVOList.length == 0){
                        this.resetForm.jlcfVOList = [{jcdd:'',jcmc:'',jcsj:'',jcxm:''}]
                    }
                    if(this.resetForm.fblwzzVOList && this.resetForm.fblwzzVOList.length == 0){
                        this.resetForm.fblwzzVOList = [{fbsj:'',lwtm:''}]
                    }
                }else{
                    this.$message.error(res.data.message)
                }
            }).catch(err=>{
                this.loading = false
                this.$message.error(err.data.message)
            })
        }
    },
    mounted(){
        this.getData()
    },
    computed:{
        isModify(){
            if(this.$store.state.userLoginMsg.sfxg == 1){
                return true;
            }else{
                return false;
            }
        }
    }
}
</script>
<style lang="scss">
    .tableComponent{
        width:100%;
        height:100%;
        .tableComponent-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
            .right{
                display: flex;
                align-items: center;
                justify-content: center;
                p{
                    font-size:14px;
                    color:#409EFF;
                    margin-right: 10px;
                }
            }
        }
        .tableComponent-cont{
            height: calc(100vh - 310px);
            overflow-y: auto;
            /deep/ table {
                width: 100%;
                // table-layout:fixed;
                color: #444;
                font-size: 14px;
                white-space: nowrap;
                font-weight: 400;
                margin-bottom: 20px;
                thead {
                    height: 60px !important;
                    border: 1px solid #e0e0e0;
                }
                tr {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                }
                th,
                td {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                    white-space:nowrap;
                    text-overflow: ellipsis;
                    overflow: hidden;
                    line-height: 48px;
                    padding-left: 5px;
                    text-align: center;
                    width: 150px;
                    font-size: 14px;
                }
                .left_cont {
                    text-align: left;
                    padding-left: 10px;
                    font-weight: bold;
                }
                .listcss {
                    background: #f2f2f2;
                    width: 150px;
                    .mustInput{
                        color:#f56c6c;
                        margin-right:2px;
                    }
                }
                .el-select,.el-input,.el-cascader,.el-date-editor{
                    width:calc(100% - 2px);
                }
                .wrapName{
                    display: inline-block;
                    width: 100%;
                    line-height: 20px;
                    white-space:normal;
                    word-break: break-all;
                    text-align: left;
                }
                .textareaInput{
                    height: 100%;
                    textarea{
                        height: 100%!important;
                    }
                }
            }
            table{
                margin-top:20px;
            }
        }
        .experienceTable{
                table-layout:fixed;
            }
    }
</style>