<template>
    <div class="cjcx-box">
        <header class="cjcx-box-header">
            <div class="left">
                <img src="../../../assets/img/cjcx1.png" alt="" srcset="">
                <div class="left-info">
                    <h2>成绩查询</h2>
                    <p>请初试过线考生及时阅读复试须知！</p>
                </div>
            </div>
        </header>
        <div class="cjcx-box-cont" v-loading="loading">
            <table>
                 <tr>
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 考生信息</td>
                </tr>
                <tr>
                    <td class="listcss" >考生姓名</td>
                    <td class="listcss" colspan="3">报考院系</td>
                    <td class="listcss" colspan="2">报考专业</td>
                </tr>
                <tr>
                    <td >{{kscj.xm}}</td>
                    <td colspan="3">{{kscj.bkyxsmc}}</td>
                    <td colspan="2">{{kscj.bkzymc}}</td>
                </tr>
                <tr style="position:relative">
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">
                        <span>| 初试成绩总分</span>
                        <span class="title">{{kscj.zf}}</span>
                    </td>
                </tr>
                <tr>
                    <td class="listcss" >科目类别</td>
                    <td class="listcss" colspan="3">科目名称</td>
                    <td class="listcss" colspan="2">分数</td>
                </tr>
                <tr>
                    <td class="listcss">外国语</td>
                    <td colspan="3">{{kscj.wgymc}}</td>
                    <td colspan="2">{{kscj.wgy}}</td>
                </tr>
                <tr>
                    <td class="listcss">业务课一</td>
                    <td colspan="3">{{kscj.ywk1mc}}</td>
                    <td colspan="2">{{kscj.ywk1}}</td>
                </tr>
                <tr>
                    <td class="listcss">业务课二</td>
                    <td colspan="3">{{kscj.ywk2mc}}</td>
                    <td colspan="2">{{kscj.ywk2}}</td>
                </tr>
                <tr style="position:relative">
                    <td class="listcss" colspan="6" style="text-align:left;font-weight:bold">| 复试成绩<span class="title">{{kscj.fscj}}</span></td>
                </tr>
            </table>
            <div class="zhcj-box">
                <div class="left">
                    <img src="../../../assets/img/cj.png" alt="" srcset="">
                    <span>综合成绩</span>
                </div>
                <span>{{kscj.zhcj}}</span>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return{
            kscj:{},
            loading:true
        }
    },
    methods:{
        getData(){
            this.$http.get(`/api/doctorate/after/selectCjByZjhm/${this.$store.state.userLoginMsg.zjhm}`).then(res=>{
                this.loading = false
                if(res.data.code == 200){
                    if(res.data.data == null){
                        return ;
                    }
                    this.kscj = res.data.data
                }else{
                    this.$message.error(res.data.message)
                }
            }).catch(err=>{
                this.loading = false
                this.$message.error(err.data.message)
            })
        }
    },
    created(){
        this.getData()
    }
}
</script>
<style lang="scss">
    .cjcx-box{
        width:100%;
        height:100%;
        .cjcx-box-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
        }
        .cjcx-box-cont{
            width:100%;
            min-height: 700px;
            /deep/ table {
                width: 100%;
                // table-layout:fixed;
                color: #444;
                font-size: 14px;
                white-space: nowrap;
                font-weight: 400;
                margin-bottom: 20px;
                thead {
                    height: 60px !important;
                    border: 1px solid #e0e0e0;
                }
                tr {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                }
                th,
                td {
                    border: 1px solid #e0e0e0;
                    height: 48px;
                    line-height: 48px;
                    padding-left: 5px;
                    text-align: center;
                    width: 150px;
                    font-size: 14px;
                }
                .left_cont {
                    text-align: left;
                    padding-left: 10px;
                    font-weight: bold;
                }
                .listcss {
                    background: #f2f2f2;
                    // width: 150px;
                    .mustInput{
                        color:#f56c6c;
                        margin-right:2px;
                    }
                }
                .title{
                    position: absolute;
                    right: 11%;
                    color: #409EFF;
                    font-size: 14px;
                    font-weight: bold;
                }
                .el-select,.el-input,.el-cascader,.el-date-editor{
                    width:calc(100% - 2px);
                }
                .wrapName{
                    display: inline-block;
                    width: 100%;
                    line-height: 20px;
                    white-space:normal;
                    word-break: break-all;
                    text-align: left;
                }
                .textareaInput{
                    height: 100%;
                    textarea{
                        height: 100%!important;
                    }
                }
            }
            table{
                margin-top:20px;
            }
            .zhcj-box{
                // width:100%;
                display: flex;
                align-items: center;
                justify-content: space-between;
                height:80px;
                border:1px solid rgba(238,238,238,1);
                box-shadow:0px 3px 6px rgba(0,0,0,0.16);
                margin-top:20px;
                padding:0 20px;
                span{
                    color: #409EFF;
                    font-size: 28px;
                    font-weight: bold;
                }
                .left{
                    display: flex;
                    align-items: center;
                    img{
                        max-width: 25px;
                        max-height: 25px;
                    }
                    span{
                        font-size: 14px;
                        color:#666;
                        margin-left: 15px;
                    }
                }
            }
        }
    }
</style>