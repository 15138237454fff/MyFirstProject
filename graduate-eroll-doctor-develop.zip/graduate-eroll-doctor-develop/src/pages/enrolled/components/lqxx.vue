<template>
    <div class="lqxx-box" v-loading="loading">
        <header class="lqxx-box-header">
            <div class="left">
                <img src="../../../assets/img/lqxxTitle.png" alt="" srcset="">
                <div class="left-info">
                    <h2>录取信息</h2>
                    <p v-if="enrollData.lqmass2!=''">预祝您下次取得优异成绩！</p>
                    <p v-else>请考生关注我校官网，了解报道须知！</p>
                </div>
            </div>
        </header>
        <div class="lqxx-box-cont" >
            <div class="enrollInfoBox">
                <p>{{enrollData.lqmass1}}</p>
                <p v-if="enrollData.lqmass2!=''">{{enrollData.lqmass2}}</p>
            </div>
            <div class="time">
                {{enrollData.time}}
            </div>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            enrollData:{
                time:'',
                lqmass1:'',
                lqmass2:''
            },
            loading:true
        }
    },
    methods:{
        getData(){
            this.$http.get(`/api/doctorate/after/selectLQByZjhm/${this.$store.state.userLoginMsg.zjhm}`).then(res => {
                this.loading = false
                if(res.data.code == 200){
                    this.enrollData = res.data.data
                }else{
                    this.$message.error(res.data.message)
                }
            }).catch(err=>{
                this.loading = false
                this.$message.error(err.data.message)
            })
        }
    },
    created(){
        this.getData()
    }
}
</script>
<style lang="scss">
    .lqxx-box{
        width:100%;
        height:100%;
        .lqxx-box-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
        }
        .lqxx-box-cont{
            width:100%;
            min-height: 700px;
            display: flex;
            justify-content: center;
            position: relative;
            .enrollInfoBox{
                width:1008px;
                height: 700px;
                display: flex;
                flex-direction: column;
                // align-items: center;
                justify-content: center;
                background: url('../../../assets/img/lqxxbg.png') no-repeat;
                background-position: 264px 110px;/*这个是按从左往右，从上往下的百分比位置进行调整*/
                // background-size: 100% 100%;/*按比例缩放*/
                p{
                   font-size: 36px;
                   font-weight:400;
                   color:#666;
                   text-align: center;
                }
            }
            .time{
                text-align: right;
                margin-top:600px;
                font-size: 24px;
                color:#666;
                position:absolute;
                left:calc(100% - 250px)
            }
        }
    }
</style>