<template>
    <div class="enrolled-box">
        <ul class="breadcrumb" >
            <li @click="goNavPage(nav,index)" v-for="(nav,index) in navArr" :key="index" :class="{'actived':nav.actived,'active':nav.active,'disable':index>navIndex}">{{nav.name}}</li>
        </ul>
        <div class="enrolled-box-cont">
            <tableComponent :navIndex="navIndex" v-if="chooseNavIndex == 0"/>
            <csap v-if="chooseNavIndex == 1"/>
            <cjcx v-if="chooseNavIndex == 2"/>
            <lqxx v-if="chooseNavIndex == 3"/>
        </div>
        
    </div>
</template>
<script>
import tableComponent from './components/table.vue'
import csap from './components/csap.vue'
import cjcx from './components/cjcx.vue'
import lqxx from './components/lqxx.vue'
export default {
    data(){
        return {
            navArr:[ //active:当前，actived：经过
                {actived:false,active:true,name:'在线报名'},
                {actived:true,active:false,name:'初试安排'},
                {actived:false,active:false,name:'成绩查询'},
                {actived:false,active:false,name:'录取信息'},
            ],
            navIndex:0, //流程进行的位置（从0开始）
            chooseNavIndexInfo:'',//鼠标选中的nav
        }
    },
    components:{
        tableComponent,
        csap,
        cjcx,
        lqxx
    },
    methods:{
        getNavIndex(){ //当前显示的标签页
             if (this.$store.state.userLoginMsg.jszs == '1') {
                 this.navIndex = 3
            } else if (this.$store.state.userLoginMsg.kfcx == '1') {
                this.navIndex = 2
            } else if (this.$store.state.userLoginMsg.csap == '1') {
                this.navIndex = 1
            } else if (this.$store.state.userLoginMsg.sfbm == '1') {
                this.navIndex = 0
            }
            this.$store.commit('updateBreadcrumb', this.navIndex)
            this.chooseNavIndex = this.navIndex
            console.log(this.navIndex,'navIndex',this.chooseNavIndex,this.$store.state.breadcrumb)
            this.navArr.map((val,index)=>{
                if(index == this.navIndex){
                    val.active = true
                }else{
                    val.active = false
                }
                if(this.navIndex + 1 > index){
                    val.actived = true
                }else{
                    val.actived = false
                }
            })
        },
        goNavPage(nav,position){
            if(position <= this.navIndex){
                this.$store.commit('updateBreadcrumb',position)
                this.navArr.map((val,index)=>{
                    if(index == position){
                        val.active = true
                    }else{
                        val.active = false
                    }
                })
            }
            
        }
    },
    created(){
        this.getNavIndex()
    },
    watch:{
        chooseNavIndexInfo(nav){
            this.navArr.map((val,index)=>{
                if(index == nav){
                    val.active = true
                }else{
                    val.active = false
                }
            })
        }
    },
    computed:{
        chooseNavIndex:{ ////鼠标选中的nav
            get: function() {
                this.chooseNavIndexInfo = this.$store.state.breadcrumb.index
                return this.$store.state.breadcrumb.index
            },
            set: function(newVal) {
                this.chooseNavIndexInfo = this.$store.state.breadcrumb.index
                return this.$store.state.breadcrumb.index
            }
        }
    }
}
</script>
<style lang="scss" scoped>
    .enrolled-box{
        width: 80%;
        min-height:calc(100vh - 120px);
        margin: 20px auto;
        background:#fff;
        padding:0 40px;
        ul{
            width:100%;
            box-sizing: border-box;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin:20px 0;
            padding-top:20px;
            overflow: hidden;
            li{
                width:25%;
                height:42px;
                line-height: 42px;
                text-align: center;
                background:url('../../assets/img/nav1.png') no-repeat ;
                background-size:100% 100%;
                font-size: 16px;
                font-weight: 500;
                color: #666;
                cursor: pointer;
            }
            .actived{
                background:url('../../assets/img/nav2.png') no-repeat ;
                background-size:100% 100%;
                color:#fff;
            }
            .active{
                color:#fff;
                background:url('../../assets/img/nav3.png') no-repeat ;
                background-size:100% 100%;
            }
            .disable{
                cursor: not-allowed;
            }
        }
        .enrolled-box-cont{
            width:100%;
            min-height:calc(100% - 62px);
            // height: calc(100vh - 182px);
            border:1px solid rgba(238,238,238,1);
            box-shadow:0px 2px 6px rgba(0,0,0,0.15);
            // overflow-y: auto;
        }
    }
</style>