<template>
  <div class="main" :style="app">
    <!-- 登录页 login -->
    <div class="box">
      <h2 class="box_p">{{zsnd}}年度博士网上报名系统</h2>
      <el-form :model="loginForm" :rules="rules" ref="loginForm">
        <el-form-item lable="用户名" prop="username">
          <el-input
            v-model="loginForm.zjhm"
            placeholder="证件号码"
            type="text"
            prefix-icon="el-icon-user"
          ></el-input>
        </el-form-item>
        <el-form-item lable="密码" prop="password" style="margin-top:20px">
          <el-input
            type="password"
            placeholder="密码"
            v-model="loginForm.password"
            @keyup.enter.native="loginCLick"
            prefix-icon="el-icon-unlock"
            show-password
          ></el-input>
        </el-form-item>
        <el-form-item lable="yan" prop="changeCode" style="margin-top:20px">
          <el-row>
            <el-col :span="14">
              <el-input
                v-model="loginForm.changeCode"
                placeholder="验证码"
                type="text"
                @keyup.enter.native="loginCLick"
              ></el-input>
            </el-col>
            <el-col :span="9" :offset="1" style="border:1px solid #f4f4f4;height:40px">
              <img :src="imgurl" @click="changeImg" style="width:100%;height:100%" />
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <el-button class="login-Button" @click="loginCLick" type="primary">登录</el-button>
      <div class="mind">
         <span @click="goRegister" tag="span" class="forgotpassword">立即注册</span>
         <!-- <label><input type="checkbox" value="0" @change="remind" id="remid"></label> -->
         <router-link :to="{path:'/forgotpassword'}" tag="span" class="forgotpassword">忘记密码</router-link>
      </div>
      <!-- <div class="bottom">
        <span>© 技术支持：杭州毕为科技有限公司</span>
      </div> -->
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      loginForm: {
        zjhm: '',
        password: '',
        changeCode: '',
        // week:0
      },
      app: {
        backgroundImage: 'url(' + require('../assets/img/mainbg.png') + ')',
        backgroundRepeat: 'no-repeat',
        backgroundSize: '100% 100%'
      },
      imgurl: '',
      rules: {},
      checked:false,
      isRegister:false,
      zsnd:''
    }
  },
  mounted () {
    this.changeImg()
    this.isGoRegister()
    this.getZsnd()
  },
  methods: {
    loginCLick () {
      if (Object.values(this.loginForm).includes('')) {
        this.$message.warning('请将登录信息填写完整')
        return;
      }
      this.$store
        .dispatch('login', this.loginForm)//dispatch：含有异步操作，例如向后台提交数据，写法： this.$store.dispatch('action方法名',值)
        .then(result => {
          this.$message.success(result)
          console.log(this.time,'0000000000')
          if(!this.time){
            if(this.sfbm == 1){
              this.$router.push({ //已报名
                path:'/enrolledPage'
              })
            }else{
              this.$router.push({ //未报名
                path:'/pageMain'
              })
            }
          }else{
            this.$router.push({ //错过报名时间
                path:'/cgbm'
              })
          }
        })
        .catch(err => {
          console.log("登录失败",err);
          this.changeImg()
          this.$message.error(err)
        })
    },
    // 修改验证码图片
    changeImg () {
      // console.log("更新验证码");
      this.$http
        .get('/api/doctorate/user/changeCode?t=' + Math.random(),{ responseType: 'arraybuffer' }).then(res=>{
           this.imgurl = `data: image/jpeg;base64,${btoa(new Uint8Array(res.data).reduce((data, byte) => data + String.fromCharCode(byte), ''))}`;
        })
    },
    remind(){//记住密码，有7天的有效期限
      if (checked == true) {
        $.cookie("userid", this.loginForm.password, { expires: 7 }); // 存储一个带7天期限的 cookie
     }
     if ($.cookie("this.loginForm.password") != null) {
        ($.cookie("userid"));
      }
    },
    forgot(){
      this.$router.push('/forgotPassword')
    },
    isGoRegister(){
      this.$http.get('/api/doctorate/user/check').then(res=>{
        if(res.data.code == 200){
          this.isRegister = true
        }else{
          this.isRegister = false
        }
      })
    },
    goRegister(){
      if(this.isRegister){
        this.$router.push('/register')
      }else{ 
        this.$message.warning('博士招生未开启！')
      }
    },
    getZsnd(){
      this.$http.get('/api/doctorate/user/annual').then(res=>{
        if(res.data.code == 200){
          this.zsnd = res.data.data
          this.$store.state.zsnd.val = this.zsnd
        }else{
          this.$message.error(res.data.message)
        }
      })
    }
  },
  computed: {
    //是否报名
    sfbm(){
      return this.$store.state.userLoginMsg.sfbm
    },
    time(){ //是否错过报名时间
      return this.$store.state.userLoginMsg.time
    },
    endTime(){
      return this.$store.state.userLoginMsg.endTime
    },
    startTime(){
      return this.$store.state.userLoginMsg.startTime
    },
    userStatus () {
      return this.$store.state.userLoginMsg.getStatus
    }
  }
}
</script>

<style lang="scss" scoped>
.main {
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  .box {
    width: 28%;
    // max-width: 330px;
    max-width: 360px;
    // height: 300px;
    border-radius: 8px;
    background-color: rgba(255, 255, 255, 1);
    padding: 50px 60px;
    .box_p{
      color: #000;
      font-weight: bold;
      font-size: 28px;
      width: 100%;
      text-align: center;
      margin-bottom: 30px;
    }
    // .el-form{
    //   .el-form-item{
    //     margin-top: 5px !important;
    //   }
    // }
    .el-button {
      width: 100%;
    }
    .mind{
      display: flex;
      justify-content:space-between;
      margin-top: 20px;
      font-size:14px;
      color:#409EFF;
      cursor: pointer;
      .forgotpassword:hover{
        color: #45a8fe;
      }
    }
    .bottom {
      text-align: center;
      margin-top: 40px;
      font-size: 12px;
    }
  }
  // .box /deep/ .el-input__inner {
  //     background-color: rgba(255, 255, 255, .3);
  //     color: #fff;
  // }
}
</style>
<style lang="scss">
.box .el-input__icon {
  font-size: 20px !important;
}
</style>
