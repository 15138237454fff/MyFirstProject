<template>
  <div class="forgotPassword">
    <div class="bix">
      <header>
        <div style="text-align:right;padding-right:15px">
          <img src="../assets/icons/fgtpas.png" alt style="width:60px;height:60px;margin-top:30px;" />
        </div>
        <div>找回密码</div>
      </header>
      <div>
        <safety v-if="safetycompent" @safetycompentent="safetycompentent"></safety>
        <resetpsd
          v-if="resetpsdcompent"
          @resetpsdcompentent="resetpsdcompentent"
          @finshdcompentent="finshdcompentent"
        ></resetpsd>
        <finshd v-if="finshdcompent"></finshd>
      </div>
    </div>
  </div>
</template>
<script>
import safety from "@/components/safety";
import resetpsd from "@/components/resetpsd";
import finshd from "@/components/finshd";
export default {
  name: "forgotPassword",
  data() {
    return {
      percentage: 20,
      customColor: "#409eff",
      safetycompent: true,
      resetpsdcompent: false,
      finshdcompent: false
    };
  },
  components: {
    safety: safety,
    resetpsd: resetpsd,
    finshd: finshd
  },
  methods: {
    safetycompentent(val) {
      this.resetpsdcompent = val;
      this.safetycompent = !val;
    },
    resetpsdcompentent(val) {
      this.resetpsdcompent = !val;
      this.safetycompent = val;
    },
    finshdcompentent(val) {
      this.resetpsdcompent = !val;
      this.finshdcompent = val;
    }
  }
};
</script>
<style lang="scss" scoped>
.forgotPassword {
  margin: 20px 0;
  height:calc(100vh - 120px);
  .bix {
    width: 80%;
    height:100%;
    background: rgba(255, 255, 255, 1);
    margin: 0 auto;
    header {
      width: 100%;
      height: 120px;
      display: flex;
      line-height: 120px;
      border-bottom: 1px solid rgba(217, 217, 217, 1);
      div {
        flex: 1;
        font-weight: bold;
      }
    }
  }
}
</style>