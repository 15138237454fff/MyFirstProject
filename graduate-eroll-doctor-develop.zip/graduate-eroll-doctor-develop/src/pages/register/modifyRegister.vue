<template>
    <div class="modifyRegister-box">
        <header class="modifyRegister-box-header">
            <div class="left">
                <img src="../../assets/img/bmlb.png" alt="" srcset="">
                <div class="left-info">
                    <h2>修改注册信息</h2>
                    <p>请保证信息真实准确！！</p>
                </div>
            </div>
            <div class="right">
                <el-button type="primary" plain icon="el-icon-d-arrow-left" @click="goBack">返回</el-button>
            </div>
        </header>
        <div class="modifyRegister-box-cont">
            <ul class="userInfoBox">
                <li>
                    <span><i class="el-icon-user-solid"></i>姓名</span>
                    <span>{{userInfo.xm}}</span>
                    <el-button type="text" @click="modifyName">修改</el-button>
                </li>
                <li>
                    <span><i class="el-icon-set-up"></i>证件类型/证件号码</span>
                    <span><b>{{userInfo.zjlx | zjlxFilter}}</b>/<b>{{userInfo.zjhm}}</b></span>
                    <el-button type="text" @click="modifyZj">修改</el-button>
                </li>
                <li>
                    <span><i class="el-icon-mobile-phone"></i>手机号码</span>
                    <span>{{userInfo.phone}}</span>
                    <el-button type="text" @click="modifyTel">修改</el-button>
                </li>
                <li>
                    <span><i class="el-icon-message"></i>电子信箱</span>
                    <span>{{userInfo.email}}</span>
                    <el-button type="text" @click="modifyEmail">修改</el-button>
                </li>
                <li>
                    <span><i class="el-icon-goods"></i>密码</span>
                    <span><el-input type="password"  v-model="userInfo.password" class="psdInput"></el-input></span>
                    <el-button type="text" @click="modifyPw">修改</el-button>
                </li>
            </ul>
            <el-dialog title="修改手机号码" class="telDialog registerDialog" :visible.sync="teldialogShow" width="500px" :close-on-click-modal="false">
                <div class="cont">
                    <el-form ref="form" label-width="100px" >
                        <el-form-item label="手机号码" required>
                            <el-input type="tel"  v-model="userInfo.phone"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="footer" slot="footer">
                    <el-button @click="teldialogShow = false">取消</el-button>
                    <el-button type="primary" @click="teldialogConfirm">保存</el-button>
                </div>
            </el-dialog>
            <el-dialog title="修改密码" class="registerDialog" :visible.sync="pwDialogShow" width="500px" :close-on-click-modal="false">
                <div class="cont">
                    <el-form ref="pdform" :model="pdform" :rules="rules" label-width="100px" >
                        <el-form-item label="原密码" prop="password">
                            <el-input type="password"  v-model="pdform.password" :show-password="true"></el-input>
                        </el-form-item>
                        <el-form-item label="新密码" prop="newPassword" >
                            <el-input type="password"  v-model="pdform.newPassword" :show-password="true"></el-input>
                        </el-form-item>
                        <el-form-item label="确认密码" prop="qrpassword">
                            <el-input type="password"  v-model="pdform.qrpassword" :show-password="true"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="footer" slot="footer">
                    <el-button @click="pwDialogShow = false">取消</el-button>
                    <el-button type="primary" @click="pwDialogConfirm">保存</el-button>
                </div>
            </el-dialog>
            <el-dialog title="修改姓名" class="registerDialog" :visible.sync="nameDialogShow" width="500px" :close-on-click-modal="false">
                <div class="cont">
                    <el-form ref="form" label-width="100px" >
                        <el-form-item label="修改姓名" required>
                            <el-input type="text"  v-model="userInfo.xm"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="footer" slot="footer">
                    <el-button @click="nameDialogShow = false">取消</el-button>
                    <el-button type="primary" @click="nameDialogConfirm">保存</el-button>
                </div>
            </el-dialog>
            <el-dialog title="修改证件" class="registerDialog" :visible.sync="zjDialogShow" width="500px" :close-on-click-modal="false">
                <div class="cont">
                    <el-form ref="form" label-width="100px" label="证件号码" required>
                         <el-form-item label="证件号码" required>
                            <el-select v-model="userInfo.zjlx" placeholder="请选择" class="spc">
                                <el-option label="居民身份证" value="01"></el-option>
                                <el-option label="港澳台身份证" value="03"></el-option>
                                <el-option label="华侨身份证件" value="04"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="证件号码" required>
                            <el-input type="number"  v-model="userInfo.zjhm"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="footer" slot="footer">
                    <el-button @click="zjDialogShow = false">取消</el-button>
                    <el-button type="primary" @click="zjDialogConfirm">保存</el-button>
                </div>
            </el-dialog>
            <el-dialog title="修改电子信箱" class="registerDialog" :visible.sync="emailDialogShow" width="500px" :close-on-click-modal="false" >
                <div class="cont">
                    <el-form ref="form" label-width="100px" >
                        <el-form-item label="电子信箱" required>
                            <el-input type="email"  v-model="userInfo.email"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="footer" slot="footer">
                    <el-button @click="emailDialogShow = false">取消</el-button>
                    <el-button type="primary" @click="emailDialogConfirm">保存</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            userInfo:{
                id:this.$store.state.userLoginMsg.id,
                xm:'',
                zjlx:'',
                zjhm:'',
                phone:'',
                email:'',
                password:'',
                oldpassword:'',
                qrpassword:''
            },
            teldialogShow:false,
            pwDialogShow:false,
            nameDialogShow:false,
            zjDialogShow:false,
            emailDialogShow:false,
            pdform:{
                newPassword:'',
                qrpassword:'',
                password:'',
            },
            rules:{
                password:[{ required: true, message: '请输入原密码', trigger: 'blur' }],
                newPassword:[{ required: true, message: '请输入新密码', trigger: 'blur' }],
                qrpassword:[{ required: true, message: '请输入确认密码', trigger: 'blur' }]
            }
                
            
        }
    },
    methods:{
        goBack(){
            this.$router.go(-1)
        },
        modifyTel(){
            this.teldialogShow = true
        },
        modifyPw(){
            this.pwDialogShow = true
        },
        modifyName(){
            this.nameDialogShow = true
        },
        modifyZj(){
            this.zjDialogShow = true
        },
        modifyEmail(){
            this.emailDialogShow = true
        },
        teldialogConfirm(){
            if(this.userInfo.phone){ //手机号校验
                let reg = /^1[3|4|5|7|8][0-9]\d{8}$/;
                if(!reg.test(this.userInfo.phone)){
                    this.$message.error('请输入正确的手机号');
                    return ;
                }
            }
            this.modifyInfo({id:this.userInfo.id,phone:this.userInfo.phone})
            this.teldialogShow = false
        },
        pwDialogConfirm(){
            if(this.pdform.newPassword){
                const rule = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$)^.{8,16}$/;
                if(!rule.test(this.pdform.newPassword)){
                    this.$message.error('新密码长度在8~18之间，至少包含数字、字母、特殊符号中的两种');
                    return ;
                }
            }
            if(this.pdform.password){
                const rule = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$)^.{8,16}$/;
                if(!rule.test(this.pdform.password)){
                    this.$message.error('原密码长度在8~18之间，至少包含数字、字母、特殊符号中的两种');
                    return ;
                }
            }
            if(this.pdform.qrpassword){
                const rule = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$)^.{8,16}$/;
                if(!rule.test(this.pdform.qrpassword)){
                    this.$message.error('确认密码长度在8~18之间，至少包含数字、字母、特殊符号中的两种');
                    return ;
                }
            }
            if(this.pdform.newPassword && this.pdform.qrpassword){
                if(this.pdform.newPassword!=this.pdform.qrpassword){
                    this.$message.error('两次密码输入不一致');
                    return ;
                }
            }
            this.$refs.pdform.validate((rule)=>{
                if(rule){
                    let params = {
                        id:this.userInfo.id,
                        oldpassword:this.pdform.password,
                        password:this.pdform.newPassword,
                        qrpassword:this.pdform.qrpassword
                    }
                    this.$http.put(`/api/doctorate/before/update`,params).then(res=>{
                        if(res.data.code == 200){
                            this.pwDialogShow = false
                            this.$message.success('修改成功')
                        }else{
                            this.$message.error(res.data.message)
                        }
                    })
                }else{
                    this.$message.error('请把信息填写完整')
                }
            })
            
        },
        nameDialogConfirm(){
            this.modifyInfo({id:this.userInfo.id,xm:this.userInfo.xm})
            this.nameDialogShow = false
        },
        zjDialogConfirm(){
            this.modifyInfo({id:this.userInfo.id,zjlx:this.userInfo.zjlx,zjlxmc:this.userInfo.zjlxmc,zjhm:this.userInfo.zjhm})
            this.zjDialogShow = false
        },
        emailDialogConfirm(){
            this.modifyInfo({id:this.userInfo.id,email:this.userInfo.email})
            this.emailDialogShow = false
        },
        getInfo(){
             this.$http.get(`/api//doctorate/before/selectByID/${this.$store.state.userLoginMsg.id}`).then(res => {
                if(res.data.code == 200){
                    this.userInfo = res.data.data
                }else{
                    this.$message.error(res.data.message)
                }
            })
        },
        modifyInfo(params){
            this.$http.put(`/api/doctorate/before/update`,params).then(res=>{
                if(res.data.code == 200){
                    this.$message.success('修改成功')
                }else{
                    this.$message.error(res.data.message)
                }
            })
        }
    },
    created(){
        this.getInfo()
    }
}
</script>
<style lang="scss" scoped>
    .modifyRegister-box{
        width: 80%;
        min-height:calc(100vh - 120px);
        margin: 20px auto;
        background:#fff;
        padding:0 40px;
        .modifyRegister-box-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
            .right{
                display: flex;
                align-items: center;
                justify-content: center;
            }
        }
        .modifyRegister-box-cont{
            width:100%;
            min-height: 700px;
            .userInfoBox{
                margin:10% 20%;
                border-top:1px solid #ccc;
                li{
                    padding:0 20px;
                    display: flex;
                    // justify-content: space-between;
                    align-items: center;
                    height: 60px;
                    border-bottom:1px solid #ccc;
                    span:first-of-type{
                        display: inline-block;
                        width:40%;
                        font-size:18px;
                        color:#666;
                        i{
                            color:#409EFF;
                            margin-right:5px;
                            font-size:20px;
                        }
                    }
                    span:nth-of-type(2){
                        display: inline-block;
                        width:57%;
                        font-size:18px;
                        color:#666;
                        b{
                            font-size:18px;
                            margin-right: 5px;
                            font-weight: 400;
                            color:#666;
                        }
                    }
                }
                /deep/ .psdInput{
                    .el-input__inner{
                        border:0;
                    }
                }
            }
            /deep/ .registerDialog{
                .el-dialog__header{
                    border-bottom:1px solid #ccc;
                }
                .el-dialog__footer{
                    border-top:1px solid #ccc;
                    .footer{
                        text-align: center;
                        button{
                            margin-left:30px;
                        }
                    }
                }
                .cont{
                    min-height: 150px;
                    display: flex;
                    align-items: center;
                    /deep/ .el-form-item{
                        width:450px;
                        .spc{
                            width:100%;
                        }
                    }
                }
            }
        }
    }
</style>