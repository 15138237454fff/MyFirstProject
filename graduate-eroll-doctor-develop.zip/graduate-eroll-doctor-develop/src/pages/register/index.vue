<template>
  <!-- 注册页面 -->
  <div class="registerBox">
    <header class="registerBox-header">
      <div class="left">
        <i class="el-icon-tickets"></i>
      </div>
      <div class="right">
        <h2>在线注册</h2>
        <p>请完整填写注册信息，保证信息真实准确！</p>
      </div>
    </header>

    <div class="registerBox-cont">
      <el-form :model="registerForm" :rules="rules" ref="registerForm" label-width="100px">
        <el-form-item label="姓名:" prop="xm" required>
          <el-input maxlength="20" v-model="registerForm.xm" placeholder="请填写真实姓名" type="text"></el-input>
        </el-form-item>
        <el-form-item label="证件类型：" prop="zjlx" required>
          <el-select v-model="registerForm.zjlx" placeholder="请选择" class="spc">
            <el-option label="居民身份证" value="01"></el-option>
            <el-option label="港澳台身份证" value="03"></el-option>
            <el-option label="华侨身份证件" value="04"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="证件号码:" prop="zjhm" required>
          <el-input v-model="registerForm.zjhm" placeholder="请输入" type="text"></el-input>
        </el-form-item>
        <el-form-item label="手机号:" prop="phone" required>
          <el-input v-model="registerForm.phone" placeholder="请输入" type="tel"></el-input>
        </el-form-item>
        <el-form-item label="电子邮箱:" prop="email" required>
          <el-input v-model="registerForm.email" placeholder="请输入" type="text"></el-input>
        </el-form-item>
        <el-form-item label="密码:" prop="password" required>
          <el-input
            class="passwordInput"
            v-model="registerForm.password"
            placeholder="请输入"
            type="password"
            show-password
            @keyup.enter.native="loginCLick"
          ></el-input>
          <!-- <p class="passwordRules">密码长度在8~18之间，至少包含数字、字母、特殊符号中的两种</p> -->
        </el-form-item>
        <el-form-item label="确认密码:" prop="qrpassword" required>
          <el-input
            v-model="registerForm.qrpassword"
            placeholder="请输入"
            type="password"
            show-password
            @keyup.enter.native="loginCLick"
          ></el-input>
        </el-form-item>
        <el-form-item label prop required>
          <el-checkbox v-model="registerForm.zt" :true-label="1" :false-label="0" class="xyBtn"></el-checkbox>
          <p class="xyComment">
            我已阅读并同意
            <router-link :to="{path:'/agreement',query:{from:'register'}}" tag="a">"注册服务条款"</router-link>
          </p>
        </el-form-item>
        <el-form-item label prop required>
          <el-button type="primary" class="registerBtn" @click="registerClick">在线注册</el-button>
          <router-link :to="{path:'/'}" tag="div" class="loginBtn">已有账号，前往登录>></router-link>
        </el-form-item>
      </el-form>
      <div class="psdInfo">
        提示：密码长度位8-16位<br/>
        至少包括数字，字母，特殊符号中的两种
      </div>
    </div>
    <el-dialog title="完成注册" class="registerDialog" :visible.sync="dialogShow" width="400px">
        <div class="cont">
           <i class="el-icon-success"/>
           <div class="registerInfo">
             <h2>注册成功!</h2>
             <p><i>{{time}}</i>s后自动跳转至登录页面</p>
           </div>
        </div>
        <div class="footer" slot="footer">
            <el-button type="primary" plain @click="goLogin">前往登录</el-button>
        </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "Register",
  data() {
    return {
      dqxq: "2019年上半学期",
      registerForm: {
        zt: 0
      },
      rules: {
        xm: [{ required: true, message: "请输入真实姓名", trigger: "blur" },
        { required: true, message: "请输入真实姓名", trigger: "change" }],
        zjlx: [
          { required: true, message: "请选择证件类型", trigger: "change" }
        ],
        zjhm: [{ required: true, message: "请输入证件号码", trigger: "blur" },
        { required: true, message: "请输入证件号码", trigger: "change" }],
        phone: [{ required: true, message: "请输入手机号", trigger: "blur" },
        { required: true, message: "请输入手机号", trigger: "change" }],
        email: [
          { required: true, message: "请输入电子邮箱", trigger: "blur" },
          { type: "email", message: "请输入正确的邮箱！", trigger: "blur" }
        ],
        password: [{ required: true, message: "请输入密码", trigger: "blur" },
        { required: true, message: "请输入密码", trigger: "change" }],
        qrpassword: [
          { required: true, message: "请输入确认密码", trigger: "blur" },
          { required: true, message: "请输入确认密码", trigger: "change" }
        ]
      },
      dialogShow:false,
      time:10,
      timer:null
    };
  },
  mounted() {
  },
  methods: {
    registerClick() {
      if(this.registerForm.phone){ //手机号校验
        let reg = /^1[3|4|5|7|8][0-9]\d{8}$/;
        if(!reg.test(this.registerForm.phone)){
          this.$message.error('请输入正确的手机号');
          return ;
        }
      }
      if(this.registerForm.password){
        const rule = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$)^.{8,16}$/;
        if(!rule.test(this.registerForm.password)){
          this.$message.error('密码长度在8~16之间，至少包含数字、字母、特殊符号中的两种');
          return ;
        }
      }
      if(this.registerForm.qrpassword){
        const rule = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$)^.{8,16}$/;
        if(!rule.test(this.registerForm.qrpassword)){
          this.$message.error('密码长度在8~16之间，至少包含数字、字母、特殊符号中的两种');
          return ;
        }
      }
      if(this.registerForm.password && this.registerForm.qrpassword){
        if(this.registerForm.qrpassword!=this.registerForm.password){
          this.$message.error('两次密码输入不一致');
          return ;
        }
      }
      if(!this.registerForm.zt){
          this.$message.error('请同意服务条款');
          return ;
      }

      this.$refs.registerForm.validate((rule)=>{
        if(rule){
           this.$http.post('/api/doctorate/user/save',this.registerForm).then(res => {
              if (res.data.code === 200) {
                this.dialogShow = true
                this.timer = setInterval(()=>{
                  this.time--
                  if(this.time == 0){
                    this.dialogShow = false
                    this.$router.push({
                      path: '/'
                    })
                  }
                },1000)
                this.$refs.registerForm.resetFields();
              }else{
                this.$message.error(res.data.message);
              }
            }).catch(err=>{
              this.$message.error(err.data.message);
            })
        }else{
          this.$message.error('请把信息填写完整');
          return false;
        }
      })
    },
    goLogin(){
      this.dialogShow = false
      this.$router.push('./')
    }
    // 获取基本信息
    // getData() {
    //   this.$http.get("/api/doctorate/user/save" + this.xh).then(res => {
    //     console.log(res.data.data);
    //     this.userInfo = res.data.data;
    //   });
    // }
  },
  beforeDestroy(){
    clearInterval(this.timer)
  }
  // computed: {
  //   xh() {
  //     return this.$store.getters.getXH;
  //   }
  // }
};
</script>

<style lang="scss" scoped>
.registerBox {
  width: 80%;
  height: calc(100vh - 120px);
  margin: 20px auto;
  background: #fff;
  .registerBox-header {
    width: 100%;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-bottom: 1px solid rgba(217, 217, 217, 1);
    .left {
      font-size: 52px;
      color: #409eff;
      margin-right: 20px;
    }
    .right {
      height: 60px;
      display: flex;
      flex-direction: column;
      justify-content: space-around;
      h2 {
        font-size: 20px;
        color: #409eff;
      }
      p {
        font-size: 14px;
        color: #409eff;
      }
    }
  }
  .registerBox-cont {
    width: 100%;
    padding-top: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    .passwordInput {
      // display: inline-block;
      width: 250px;
    }
    .passwordRules {
      // display: inline-block;
      width: 250px;
    }
    .xyBtn {
      display: inline-block;
    }
    .xyComment {
      display: inline-block;
      margin-left: 10px;
      a {
        color: #409eff;
      }
    }
    .registerBtn {
      width: 250px;
    }
    .loginBtn {
      color: #409eff;
      cursor: pointer;
    }
    .spc {
      width: 250px;
    }
  }
  .psdInfo{
    font-size:12px;
    color:#999;
    position:absolute;
    top:334px;
    right:calc(50% - 420px);
  }
  /deep/ .registerDialog{
            .el-dialog__header{
                border-bottom:1px solid #ccc;
            }
            .cont{
              height:60px;
              display: flex;
              justify-content: center;
              // padding-top:20px;
              .el-icon-success{
                font-size:25px;
                color:#67c13d;
                margin-right:10px;
              }
              .registerInfo{
                h2{
                  font-size:20px;
                }
                p{
                  font-size:16px;
                  color:#666;
                  height: 30px;
                  line-height: 30px;
                  i{
                    color:#409eff;
                    font-style: normal;
                  }
                }
              }
            }
            .el-dialog__footer{
                border-top:1px solid #ccc;
                .footer{
                    text-align: center;
                    button{
                        margin-left:30px;
                    }
                }
            }
  }
}
</style>
