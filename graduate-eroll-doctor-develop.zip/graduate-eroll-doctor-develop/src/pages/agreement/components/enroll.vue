<template>
    <div>
        <h2>报名协议</h2>
    </div>
</template>
<script>
export default {
    
}
</script>