<template>
    <div class="agreementBox">
        <header class="agreementBox-header">
            <div class="left">
                <img src="../../assets/img/agreementTitle.png" alt="" srcset="">
                <div class="left-info">
                    <h2>{{title}}</h2>
                </div>
            </div>
            <div class="right">
                <el-button type="primary" plain icon="el-icon-d-arrow-left" @click="goBack">返回</el-button>
            </div>
        </header>
        <div class="agreementBox-cont">
            <registerComponent v-if="$route.query.from == 'register'"/>
            <enrollComponent v-if="$route.query.from == 'enrollPage'"/>
        </div>
    </div>
</template>
<script>
import registerComponent from './components/register'
import enrollComponent from './components/enroll'
export default {
    components:{
        registerComponent,
        enrollComponent
    },
     data(){
        return{
            title:'注册条款'
        }
            
    },
    methods:{
        goBack(){
            this.$router.go(-1)
        },
        getData(){}
    },
    created(){
        if(this.$route.query.from == 'register'){
            this.title = '注册条款'
        }
        if(this.$route.query.from == 'enrollPage'){
            this.title = '报名条款'
        }
        this.getData()
    },
}
</script>
<style lang="scss" scoped>
     .agreementBox{
        width: 80%;
        min-height:calc(100vh - 120px);
        min-width:1300px;
        margin: 20px auto;
        background:#fff;
        .agreementBox-header{
            width: 100%;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(217, 217, 217, 1);
            padding:0 20px;
            box-sizing: border-box;
            .left{
                display: flex;
                align-items: center;
                img{
                    width: 48px;
                    height: 48px;
                    margin-right: 20px;
                }
                .left-info{
                    display: flex;
                    flex-direction: column;
                    padding:16px 0;
                    justify-content: space-between;
                    h2{
                        font-size:20px;
                        color:#409EFF;
                    }
                    p{
                        font-size:14px;
                        color:#409EFF;
                    }
                }
            }
            .right{
                display: flex;
                align-items: center;
                justify-content: center;
                .el-icon-date{
                    font-size: 19px;
                    margin-right: 10px;
                    color:#409EFF;
                }
                p{
                    font-size:14px;
                    color:#409EFF;
                    margin-right: 10px;
                }
            }
        }
        .agreementBox-cont{
            width:calc(100% - 40px);
            padding:20px;
        }
    }
</style>