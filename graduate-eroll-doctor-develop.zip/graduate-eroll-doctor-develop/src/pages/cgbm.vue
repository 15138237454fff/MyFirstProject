 <template>
    <div class="cgbmBox">
        <div class="cgbmBox-cont">
            <img src="@/assets/img/cgbm.png" alt="" srcset="">
            <p>很遗憾，您已错过{{zsnd}}年浙江财经大学博士报名，请关注下一年度报名时间！</p>
            <el-button type="primary" plain @click="back">退出系统</el-button>
        </div>
    </div>
</template>
<script>
export default {
     data(){
        return{
        }
            
    },
    methods:{
        back(){
            this.$http.put('/api/doctorate/before/getOut').then(res=>{
                    this.$store.commit('updateLogin',{})
                    this.$router.push('/')
            })
        }
    },
    computed:{
        zsnd(){
            return this.$store.state.zsnd.val
        }
    }
}
</script>
<style lang="scss" scoped>
     .cgbmBox{
        width: 80%;
        // height:calc(100vh - 120px);
        min-height: 700px;
        min-width:1300px;
        margin: 20px auto;
        background:#fff;
        .cgbmBox-cont{
            width:calc(100% - 40px);
            // padding:20px 25%;
            display: flex;
            flex-direction: column;
            align-items: center;
            overflow: hidden;
            p{
                font-size:20px;
                color: #666;
                margin-bottom: 20px;
            }
        }
    }
</style>