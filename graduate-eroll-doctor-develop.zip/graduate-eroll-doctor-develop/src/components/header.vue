<template>
    <div>
       <el-header class="header">
        <el-row style="height:80px">
            <el-col :span="16" style="font-size:25px">
                <div class="logoBox">
                    <img src="../assets/img/header_logo.png" class="logo-img" />
                    <span>|</span>
                    <p>{{$store.state.zsnd.val}}年度博士网上报名系统</p>
                </div>
            </el-col>
            <!-- <el-col :span="8" style="text-align:center;font-size:25px">
                <span style="white-space:nowrap">浙江财经大学研究生院综合服务平台</span>
            </el-col> -->
            <el-col :span="8" style="font-size:20px" v-if="rightShow">
                <div class="header-right">
                    <!-- <div class="enrollPage">
                        <i class="el-icon-s-home"></i>
                        <span @click="goEnrolledPage"  >报名主页</span>
                    </div> -->
                    <el-popover placement="bottom-end" width="150" trigger="click" popper-class="popver-person-center">
                        <div class="personCenter" slot="reference">
                            <i class="el-icon-user-solid"></i>
                            <span>个人中心</span>
                        </div>
                        <div class="personCenterBtn">
                            <router-link :to="{path:'/modifyRegister'}" tag="div" class="top" >
                                <i class="el-icon-document"></i>
                                <span>修改注册信息</span>
                            </router-link>
                            <div @click="goLogin" class="bottom">
                                <i class="el-icon-switch-button"></i>
                                <span>退出登录</span>
                            </div>
                        </div>
                    </el-popover>    
                </div>
            </el-col>
        </el-row>
    </el-header>
    </div>
</template>
<script>
export default {
    data(){
        return{
            rightShow:true
        }
    },
    methods:{
        goEnrolledPage(){
            this.$store.commit('updateBreadcrumb',0)
            this.$router.push('/enrolledPage')
        },
        goLogin(){
            this.$http.put('/api/doctorate/before/getOut').then(res=>{
                    this.$store.commit('updateLogin',{})
                    this.$router.push('/')
            })
        }
    },
    watch:{
        $route(to,from){
            if(to.path == '/register'){
                this.rightShow = false
            }else{
                this.rightShow = true
            }
        }
    },
    created(){
        if(this.$route.path == '/register'){
            this.rightShow = false
        }else{
            this.rightShow = true
        }
    },
}
</script>
<style lang="scss">
  .el-header {
    padding: 0 40px;
  }
  .el-header,
  .header {
    background: linear-gradient(
      90deg,
      rgba(24, 144, 255, 1) 0%,
      rgba(24, 144, 255, 1) 0%,
      rgba(136, 199, 255, 1) 100%,
      rgba(136, 199, 255, 1) 100%
    );
    height: 80px !important;
    color: #fff;
    line-height: 80px;
    & > div > div:last-child > div:first-child span {
      cursor: pointer;
    }
    .logoBox{
        height: 100%;
        display: flex;
        align-items: center;
        span{
            margin:0 20px;
        }
        p{
            font-size: 20px;
        }
    }
    .logo-img {
      max-width: 300px;
      max-height:40px;
    }
    .header-right{
        display: flex;
        align-items: center;
        justify-content: flex-end;
        .enrollPage{
            margin-right: 20px;
            span{
                font-size: 14px;
            }
        }
    }
  }
  .popver-person-center{
      margin-top:-10px!important;
  }
  .personCenter{
      span{
          font-size: 14px;
      }
  }
  .personCenterBtn{
      span{
          font-size: 14px;
      }
      .top{
          margin-bottom:10px;
          .el-icon-document{
              color:#409EFF;
          }
      }
      .el-icon-switch-button{
          color:#f56c6c;
      }
      .top,.bottom{
          cursor: pointer;
      }
  }
</style>