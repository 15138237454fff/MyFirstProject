<template>
  <div class="finshd">
    <section>
      <div class="safety_div">
        <el-button type="primary" circle icon="el-icon-check"></el-button><span>安全认证</span>
        <div class="step"></div>
      </div>
      <div class="safety_div">
        <el-button type="primary" circle style="width:40px" icon="el-icon-check"></el-button><span>重置密码</span>
        <div class="step"></div>
      </div>
      <div class="safety_div1">
        <el-button type="primary" circle style="width:40px" icon="el-icon-check"></el-button><span>完成</span>
      </div>
    </section>
    <div class="centers">
      <el-button type="success" circle icon="el-icon-check"></el-button><span>修改密码成功</span>
    </div>
    <div class="btn_center">
      <el-button @click="nextForm" class="btn">返回登录</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'finshd',
  data() {
    return {}
  },
  methods: {
    nextForm() {
      this.$router.push('/')
    }
  }
}
</script>

<style scoped lang="scss">
.finshd {
  width: 100%;
  section {
    display: flex;
    padding: 20px 0px 20px 120px;
    margin-top: 50px;
    margin-bottom: 150px;
    .safety_div {
      position: relative;
      flex: 2;
    }
    .safety_div1 {
      position: relative;
      flex: 1;
    }
    div {
      .step {
        position: absolute;
        border-color: inherit;
        background-color: #e8e8e8;
        height: 1.5px;
        top: 18px;
        left: 116px;
        right: 15px;
      }
      span {
        margin-left: 10px;
        font-family: "MicrosoftTaiLe-Bold", "Microsoft Tai Le Bold",
          "Microsoft Tai Le";
        font-weight: 700;
        font-style: normal;
        font-size: 16px;
        color: rgba(0, 0, 0, 0.847058823529412);
      }
    }
  }
  .centers {
    text-align: center;
    margin-bottom: 15px;
    span {
      margin-left: 10px;
    }
  }
  .btn_center {
    text-align: center;
    .btn {
      border-color: #66b1ff;
      color: #66b1ff;
    }
  }
}
</style>
