<template>
  <div class="resetpsd">
    <section>
      <div class="safety_div">
        <el-button type="primary" circle icon="el-icon-check"></el-button><span>安全认证</span>
        <div class="step"></div>
      </div>
      <div class="safety_div">
        <el-button type="primary" circle style="width:40px">2</el-button><span>重置密码</span>
        <div class="step"></div>
      </div>
      <div class="safety_div1">
        <el-button circle style="width:40px">3</el-button><span style="color:rgba(0, 0, 0, 0.447058823529412);">完成</span>
      </div>
    </section>
    <el-form :model=" ruleForm" ref="ruleForm" label-width="150px" class="demo-ruleForm" :rules="rules">
      <el-form-item label="请输入新密码：" :required="true" prop="password">
        <el-input v-model="ruleForm.password" placeholder="请输入" style="width:450px"></el-input>
      </el-form-item>
      <el-form-item label="请确认密码：" :required="true" prop="newpassword">
        <el-input v-model="ruleForm.newpassword" placeholder="请输入" style="width:450px"></el-input>
      </el-form-item>
      <p>8-16位,至少包含数字、字母、特殊字符中的2种</p>
      <el-form-item class="btn">
        <el-button @click="submitForm">上一步</el-button>
        <el-button type="primary" @click="nextForm('ruleForm')">下一步</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: 'resetpsd',
  data() {
    return {
      ruleForm: {
        password: '',
        newpassword: ''
      },
      rules: {
        password: [
          { required: true, message: '请输入新密码', trigger: 'blur' },
          { min: 8, max: 16, message: '长度在 8 到 16 个字符', trigger: 'blur' }
        ],
        newpassword: [
          { required: true, message: '请确认密码', trigger: 'blur' },
          { min: 8, max: 16, message: '长度在 8 到 16 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    submitForm() {//点击上一步跳转到安全验证的页面
      this.$emit('resetpsdcompentent', true)
    },
    nextForm(formName) {//点击下一步进行接口调取的参数
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$http
            .put(`/api/doctorate/user/updatePassword`, {
              zjhm: sessionStorage.getItem('deskuserName'),
              password: this.ruleForm.password,
              confirm: this.ruleForm.newpassword
            })
            .then(result => {
              if (result.data.code == 200) {
                this.$message.success({
                  message: '密码重置成功,请重新登录'
                })
                this.$emit('finshdcompentent', true)
              } else {
                this.$message.error({
                  message: result.data.message
                })
              }
            })
        } else {
          return false
        }
      })
    }
  }
}
</script>
<style scoped lang="scss">
.resetpsd {
  width: 100%;
  section {
    display: flex;
    padding: 20px 0px 20px 120px;
    margin-top: 50px;
    margin-bottom: 50px;
    .safety_div {
      position: relative;
      flex: 2;
    }
    .safety_div1 {
      position: relative;
      flex: 1;
    }
    div {
      .step {
        position: absolute;
        border-color: inherit;
        background-color: #e8e8e8;
        height: 1.5px;
        top: 18px;
        left: 116px;
        right: 15px;
      }
      span {
        margin-left: 10px;
        font-family: "MicrosoftTaiLe-Bold", "Microsoft Tai Le Bold",
          "Microsoft Tai Le";
        font-weight: 700;
        font-style: normal;
        font-size: 16px;
        color: rgba(0, 0, 0, 0.847058823529412);
      }
    }
  }
  .demo-ruleForm {
    width: 800px;
    margin: 0 auto;
    p {
      font-family: "MicrosoftTaiLe", "Microsoft Tai Le";
      font-weight: 400;
      font-style: normal;
      font-size: 12px;
      color: rgba(153, 153, 153, 0.647058823529412);
      text-align: center;
      margin-bottom: 80px;
      padding-right: 40px;
      color: red;
    }
    .btn {
      margin-left: 100px;
    }
  }
}
</style>
