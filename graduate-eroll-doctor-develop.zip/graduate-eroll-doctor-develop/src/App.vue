<template>
  <div id="app">
    <router-view name = "header"></router-view>
    <router-view></router-view>
    <router-view name = "footer"></router-view>
  </div>
</template>

<script>
import "../static/common/reset.css";
export default {
  name: 'App'
}
</script>

<style lang="scss">
#app {
  width: 100%;
  height: 100%;
  min-width: 1440px;
  overflow-y: hidden;
  background:#F5F5F5;
}
</style>
