import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import axios from 'axios'
// import factUrl from '@/store/facturl.js'
Vue.use(Vuex)

const state = {
    // 存储用户登录信息
    userLoginMsg: {
        endTime: '', //博士招生结束时间
        startTime: '', //博士招生起止时间
        jszs: '', //是否开放录取模块(0不开放1开放)
        kfcx: '', //是否开放成绩查询模块(0不开放1开放)
        csap: '', //是否开放初试安排模块(0不开放1开放)
        sfbm: '', //是否报名(0未报名1已报名)
        status: '', //是否注册(0未注册1已注册)
        time: '', //博士招生是否错过报名时间(0否1是)
        sfxg: '', //是否在起止时间内(0否1是)
        token: '',
        xm: '',
        zjhm: '',
        zjlx: '',
        zjlxmc: '',
        id: '',
    },
    breadcrumb: {
        index: 0
    },
    zsnd: { //招生年度
        val: ''
    },
    bmId: {
        id: '',
    },
    // 表格高度
    tableHeight: null
}

const getters = {
    getStartTime(state) {
        return state.userLoginMsg.startTime
    },
    getEndTime(state) {
        return state.userLoginMsg.endTime
    },
    //是否在报名时间区间内
    getTime(state) {
        return state.userLoginMsg.time
    },
    // 外部获取token的方法
    getToken(state) {
        return state.userLoginMsg.token
    },
    // 外部获取是否结束招生
    getJszs(state) {
        return state.userLoginMsg.jszs
    },
    // 是否开放成绩查询模块(0不开放1开放)
    getKfcx(state) {
        return state.userLoginMsg.kfcx
    },
    // 是否报名(0未报名1已报名)
    getSfbm(state) {
        return state.userLoginMsg.sfbm
    },
    // 是否注册(0未注册1已注册)
    getStatus(state) {
        return state.userLoginMsg.status
    },
    // 外部获取name
    getName(state) {
        return state.userLoginMsg.xm
    },
    // 外部获取表格高度
    getTableHeight(state) {
        return state.tableHeight
    },
    getBreadcrumbIndex(state) {
        return state.breadcrumb.index
    }
}
const mutations = {
    // 更新登录用户的信息的方法
    updatedUser(state, val) {
        state.userLoginMsg = val
    },
    // 更新登录用户的信息的方法
    updateLogin(state, val) {
        state.userLoginMsg = val
    },
    //更新报名状态
    updateSfbm(state, val) {
        state.userLoginMsg.val = val
    },
    //更新报名id
    updateBmId(state, val) {
        state.bmId = val
    },
    // 更新表格高度
    updateTableHeight(state) {
        console.log('更新表格高度')
        state.tableHeight = document.documentElement.clientHeight - 258
    },
    updateBreadcrumb(state, val) {
        state.breadcrumb.index = val
    }
}

const actions = {
    // 登录的方法
    login(context, loginForm) {
        // 返回一个promise对象
        return new Promise((resolve, reject) => {
            // 发送登录请求
            axios
                .post(
                    '/api/doctorate/user/doctorLogin', loginForm
                )
                .then(result => {
                    // 如果登录成功
                    if (result.data.code === 200) {
                        let data = result.data.data
                            // console.log(result.data.data)
                        if (!data) {
                            reject('成功登陆后，用户信息返回失败')
                        }
                        // if (data.status == 0) {
                        //     reject('未注册,请选注册')
                        // }
                        let startTime = data.startTime.slice(0, 10)
                        let endTime = data.endTime.slice(0, 10)
                        let tmpObject = {
                                endTime: endTime,
                                startTime: startTime,
                                jszs: data.jszs,
                                kfcx: data.kfcx,
                                sfbm: data.sfbm,
                                csap: data.csap,
                                status: data.status,
                                token: data.token,
                                time: data.time,
                                xm: data.xm,
                                zjhm: data.zjhm,
                                zjlx: data.zjlx,
                                zjlxmc: data.zjlxmc,
                                id: data.id,
                                sfxg: data.sfxg
                            }
                            // //当前角色id不为空
                        context.commit('updatedUser', tmpObject)
                        data.bsid ? context.commit('updateBmId', { id: data.bsid }) : ''

                        // axios.put(`api/system/home/saveLogin/${data.userName}/${data.userStatus}`)//登录有问题时会出错
                        resolve('登录成功')
                    } else {
                        reject(result.data.message)
                    }
                })
        })
    }
}

export default new Vuex.Store({
    state,
    getters,
    mutations,
    actions,
    // 添加插件在F5刷新前将数据存储入sessionStorage中，刷新后将数据恢复
    plugins: [createPersistedState({
        storage: window.sessionStorage
    })],
    modules: {
        // jiansheProject,
        // common
    }
})