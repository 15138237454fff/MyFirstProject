const baseUrl = 'http://192.168.31.181:6013'
export default {
    baseUrl
}