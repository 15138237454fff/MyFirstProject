<template>
  <div class="course-box">
    <div class="item-box">
      <div class="left">
        <div class="flag">学堂学分课</div>
        <img src="../../assets/image/10489.jpg" alt="" class="course-img">
        <div class="time">
          <div>学期：2019年春</div>
          <div>开课中</div>
        </div>
      </div>
      <div class="right">
        <div class="head">
          <span>如何写好科研论文</span>
        </div>
        <div class="middle">
          <span>课程id:</span>
          <span>10489</span>
          <span style="margin-left: 30px;">课程代码：</span>
          <span>KC0001</span>
        </div>
        <hr>
        <div class="bottom">
          <a :href="getHref(10489)" target="_blank">
            <el-button type="primary">点击跳转</el-button>
          </a>
        </div>

      </div>
    </div>
    <div class="item-box">
      <div class="left">
        <div class="flag">学堂学分课</div>
        <img src="../../assets/image/10490.jpg" alt="" class="course-img">
        <div class="time">
          <div>学期：2019年春</div>
          <div>开课中</div>
        </div>
      </div>
      <div class="right">
        <div class="head">
          <span>科研伦理与学术规范</span>
        </div>
        <div class="middle">
          <span>课程ID:</span>
          <span>10490</span>
          <!-- <span style="margin-left: 30px;">课程代码：</span>
          <span>KC0001</span> -->
        </div>
        <hr>
        <div class="bottom">
          <a :href="getHref(10490)" target="_blank">
            <el-button type="primary">点击跳转</el-button>
          </a>
        </div>

      </div>
    </div>
    <div class="item-box">
      <div class="left">
        <div class="flag">学堂学分课</div>
        <img src="../../assets/image/10491.jpg" alt="" class="course-img">
        <div class="time">
          <div>学期：2019年春</div>
          <div>开课中</div>
        </div>
      </div>
      <div class="right">
        <div class="head">
          <span>工程伦理</span>
        </div>
        <div class="middle">
          <span>课程id:</span>
          <span>10491</span>
          <!-- <span style="margin-left: 30px;">课程代码：</span>
          <span>KC0001</span> -->
        </div>
        <hr>
        <div class="bottom">
          <a :href="getHref(10491)" target="_blank">
            <el-button type="primary">点击跳转</el-button>
          </a>
        </div>

      </div>
    </div>
    <div class="item-box">
      <div class="left">
        <div class="flag">学堂学分课</div>
        <img src="../../assets/image/10492.jpg" alt="" class="course-img">
        <div class="time">
          <div>学期：2019年春</div>
          <div>开课中</div>
        </div>
      </div>
      <div class="right">
        <div class="head">
          <span>英文科技论文写作与学术报告</span>
        </div>
        <div class="middle">
          <span>课程ID:</span>
          <span>10492</span>
          <!-- <span style="margin-left: 30px;">课程代码：</span>
          <span>KC0001</span> -->
        </div>
        <hr>
        <div class="bottom">
          <a :href="getHref(10492)" target="_blank">
            <el-button type="primary">点击跳转</el-button>
          </a>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      url: "https://zjut.xuetangx.com/api/v1/oauth/zjut/login/",
      reaIdCard: ""
    };
  },
  mounted() {
    this.getIdRsaInfo();
  },
  methods: {
    getHref(soureId) {
      return this.url + soureId + "?id=" + this.reaIdCard;
    },
    getIdRsaInfo() {
      this.$http.post(this.$server.glourl + 'stuinfo/rsa').then(response => {
        if (response.data.code == 0) {
          this.reaIdCard = response.data.result;
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.course-img{
  width: 100%;
  height: 100%;
}
.course-box {
  color: #606266;
  margin: 20px;
  .item-box {
    width: 100%;
    display: flex;
    height: 230px;
    padding: 20px;
    box-sizing: border-box;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    margin-bottom: 15px;
    .left {
      flex: 1;
      // background: #eee;
      position: relative;
      .flag {
        width: 30%;
        height: 30px;
        left: 0;
        position: absolute;
        background: #e6a23c;
        font-size: 14px;
        color: #fff;
        line-height: 30px;
        text-align: center;
      }
      .time {
        width: 100%;
        height: 46px;
        bottom: 0;
        position: absolute;
        background: rgba(0, 0, 0, 0.3);
        text-align: center;
        font-size: 15px;
        padding-top: 4px;
        color: #fff;
      }
    }
    .right {
      flex: 2;
      padding: 10px;
      // background: #f2f2f2;
      .head {
        height: 50px;
        color: #303133;
        span {
          font-weight: 500;
          font-size: 20px;
        }
      }
      hr {
        background-color: #dcdfe6;
        height: 1px;
        border: none;
        margin: 24px 0;
      }
    }
    .bottom {
      // display: flex;
      margin-top: 37px;
      .item1,
      .item2,
      .item3,
      .item4 {
        flex: 1;
        .num {
          color: #409eff;
          font-size: 20px;
        }
      }
    }
  }
}
</style>
