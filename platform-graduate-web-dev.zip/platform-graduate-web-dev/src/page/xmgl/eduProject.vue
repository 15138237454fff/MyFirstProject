<template>
    <div>
        <!-- 列表展示 -->
        <div class="container" v-show="showTable">
            <div class="header">
                <!-- 查询部分 -->
                <!-- <div class="left">
                    <el-input placeholder="请输入内容" class="header-input" clearable></el-input>
                    <el-button>查询</el-button>
                </div> -->

                <!-- 增删改查 -->
                <div class="right">
                    <el-button type="danger" @click="handleSee">修改</el-button>
                    <el-button type="primary" @click="handleProgress">查看审核记录</el-button>
                </div>
                <el-dialog title="审核信息" :visible.sync="seeVisible" width="30%" :before-close="handleClose">
                    <div style="border:1px solid #ddd;padding:20px;margin-bottom:20px" v-for="(item, index) in his" :key="index">
                        <div class="see-title" style="border-bottom: 1px solid #ddd;padding-bottom:20px;font-size:17px">{{item.name}}</div>
                        <el-row style="padding: 20px 0 20px 0;border-bottom:1px solid #ddd">
                            <el-col :span="24">
                                <span>经办人：{{item.assignee}}</span>
                            </el-col>
                        </el-row>

                        <el-row style="padding: 20px 0 20px 0;border-bottom:1px solid #ddd">
                            <el-col :span="24">
                                <span>开始时间：{{item.startTime}}</span>
                            </el-col>
                        </el-row>

                        <el-row style="padding: 20px 0 0 0">
                            <el-col :span="24">
                                <span>结束时间：{{item.endTime}}</span>
                            </el-col>
                        </el-row>

                        <el-row style="padding: 20px 0 0 0" v-if="item.comment!=null">
                            <el-col :span="24">
                                <span>审核意见：{{item.comment}}</span>
                            </el-col>
                        </el-row>

                        <el-row style="padding: 20px 0 0 0" v-if="item.state!=null">
                            <el-col :span="24">
                                <span v-if="item.state == '1' && item.name != '提交申请'">审核：
                                    <el-button type="success">{{item.state == '1' ?'通过': item.state == '2' ? '退回': item.state == '0' ? '不通过': item.state == '3' ? '指定学科账号成功':item.state == '4'?'指定学院账号成功':'指定学位点账号成功'}}</el-button>
                                </span>
                                <span v-if="item.state == '0' && item.name != '提交申请'">审核：
                                    <el-button type="danger">{{item.state == '1' ?'通过': item.state == '2' ? '退回': item.state == '0' ? '不通过': item.state == '3' ? '指定学科账号成功':item.state == '4'?'指定学院账号成功':'指定学位点账号成功'}}</el-button>
                                </span>
                                <span v-if="item.state == '2' && item.name != '提交申请'">审核：
                                    <el-button type="success">{{item.state == '1' ?'通过': item.state == '2' ? '退回': item.state == '0' ? '不通过': item.state == '3' ? '指定学科账号成功':item.state == '4'?'指定学院账号成功':'指定学位点账号成功'}}</el-button>
                                </span>
                                <span v-if="item.state == '3' && item.name != '提交申请'">审核：
                                    <el-button type="success">{{item.state == '1' ?'通过': item.state == '2' ? '退回': item.state == '0' ? '不通过': item.state == '3' ? '指定学科账号成功':item.state == '4'?'指定学院账号成功':'指定学位点账号成功'}}</el-button>
                                </span>
                                <span v-if="item.state == '4' && item.name != '提交申请'">审核：
                                    <el-button type="success">{{item.state == '1' ?'通过': item.state == '2' ? '退回': item.state == '0' ? '不通过': item.state == '3' ? '指定学科账号成功':item.state == '4'?'指定学院账号成功':'指定学位点账号成功'}}</el-button>
                                </span>
                                <span v-if="item.state == '5' && item.name != '提交申请'">审核：
                                    <el-button type="success">{{item.state == '1' ?'通过': item.state == '2' ? '退回': item.state == '0' ? '不通过': item.state == '3' ? '指定学科账号成功':item.state == '4'?'指定学院账号成功':'指定学位点账号成功'}}</el-button>
                                </span>
                            </el-col>
                        </el-row>
                    </div>

                    <span slot="footer" class="see-footer">
                        <el-button @click="seeVisible = false">取 消</el-button>
                        <el-button type="primary" @click="seeVisible = false">确 定</el-button>
                    </span>
                </el-dialog>

            </div>

            <!-- 表格 -->
            <div class="table">
                <el-table v-loading="loading" :data="dataList" @row-click="clickRow" tooltip-effect="dark" border style="width: 100%;text-align: center" ref="moviesTable" @selection-change="handleSelectionChange">

                    <el-table-column type="selection" label="全选" align="center"></el-table-column>

                    <el-table-column label="序号" sortable width="80" type="index" :index="indexMethod" align="center">
                    </el-table-column>

                    <el-table-column prop="xmmc" label="项目名称" align="center">
                    </el-table-column>

                    <!-- <el-table-column prop="xmlx" label="项目类型"  align="center">
                    </el-table-column> -->

                    <!-- <el-table-column prop="ssxy" label="所属学院"  align="center">
                    </el-table-column> -->

                    <!-- <el-table-column prop="yqjxy" label="要求及内容"  align="center">
                    </el-table-column> -->

                    <el-table-column prop="zt" label="审核状态" align="center">
                        <template slot-scope="scope">
                            {{ scope.row.zt == 0 ? '审核不通过' :scope.row.zt == 1 ? '审核通过':scope.row.zt == 2 ? '审核中' :scope.row.zt == 3 ? '待审核':scope.row.zt == 4 ? '退回':scope.row.zt == 5 ? '未提交':''}}
                        </template>
                    </el-table-column>

                    <el-table-column label="创建时间" prop="cjsj" align="center">
                        <template slot-scope="scope">{{scope.row.cjsjString}}</template>
                    </el-table-column>
                    <el-table-column label="编辑" align="center" prop="bj">
                        <template slot-scope="scope">
                            <el-button type="primary" plain :size="small" @click="download(scope.row.lcid,scope.row.zt)">下载</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>

            <!-- 分页 -->
            <div class="pagination">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageList.currPage" :page-sizes="[5,10,15]" :page-size="pageList.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageList.totalCount">
                </el-pagination>
            </div>
        </div>

        <!-- 表单详情 -->
        <div class="container" v-show="!showTable">
            <el-row>
                <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                    <div class="small"></div>
                    <span>申请项目及申请人基本情况</span>
                    <div class="close" @click="close"> X </div>
                </el-col>
            </el-row>

            <el-form :model="jgxm" :rules="rules" ref="jgxm" label-width="177px" class="demo-ruleForm" label-position="left">

                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="项目名称：" prop="">
                            <el-input v-model="jgxm.xmmc"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11">
                        <el-form-item label="申请经费（万元）：" prop="">
                            <el-input v-model="jgxm.sqjf"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="22">
                        <el-form-item label="起止时间：（必填项）" prop="sj">
                            <div class="date">
                                <el-form-item>
                                    <el-date-picker v-model="jgxm.sj" value-format="yyyy-MM-dd" type="daterange" unlink-panels range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerOptions2">
                                    </el-date-picker>
                                </el-form-item>
                            </div>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="22">
                        <el-form-item label="项目性质：" prop="">
                            <el-radio-group v-model="jgxm.xmxz">
                                <el-radio label="0">理论研究</el-radio>
                                <el-radio label="1">实践探索</el-radio>
                                <el-radio label="2">专项项目</el-radio>
                            </el-radio-group>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="22">
                        <el-form-item label="预期的主要成果：" prop="">
                            <el-checkbox-group style="width:90%" v-model="yqdzycg">
                                <el-checkbox label="0">研究报告</el-checkbox>
                                <el-checkbox label="1">论文</el-checkbox>
                                <el-checkbox label="2">课件</el-checkbox>
                                <el-checkbox label="3">实验装置</el-checkbox>
                                <el-checkbox label="4">多媒体软件</el-checkbox>
                                <el-checkbox label="5">其他</el-checkbox>
                            </el-checkbox-group>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="姓名：" prop="">
                            <el-input v-model="jgxm.xm"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11">
                        <el-form-item label="性别：" prop="">
                            <el-input v-model="jgxm.xbm == '1'? '男':jgxm.xbm == '2'? '女': ''"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="民族：" prop="">
                            <el-input placeholder="民族暂无"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11">
                        <el-form-item label="出生年月：" prop="">
                            <el-input v-model="jgxm.csrq"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="职务：" prop="">
                            <el-input v-model="jgxm.zw"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11">
                        <el-form-item label="职称：" prop="">
                            <el-input v-model="jgxm.zc"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="学历：" prop="">
                            <el-input></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11">
                        <el-form-item label="硕、博导：" prop="">
                            <el-input :v-model="jgxm.dslb == '1' ? '硕士生导师' : jgxm.dslb == '2' ? '博士生导师' : ''"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="所在院、学科：" prop="">
                            <el-input v-model="jgxm.yxqc"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="11">
                        <el-form-item label="联系电话：" prop="">
                            <el-input v-model="jgxm.bgsdh"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="30">
                    <el-col :span="11">
                        <el-form-item label="E-mail：" prop="">
                            <el-input v-model="jgxm.dzyx"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :span="20">
                        <div class="table-data">
                            <el-table :data="jgxm.zycjzjk" ref="multipleTable" @cell-mouse-enter="handleMouseEnter" @cell-mouse-leave="handleMouseOut">
                                <el-table-column label="主要参加者概况" align="center" style="width: 100%;text-align: center">
                                    <el-table-column label="序号" width="70" align="center" prop="num">
                                    </el-table-column>

                                    <el-table-column prop="xm" label="姓名" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.xm" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.xm}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="xb" label="性别" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.xb" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.xb}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="csrq" label="出生年月" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.csrq" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.csrq}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="xl" label="学历" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.xl" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.xl}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="zc" label="职称" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.zc" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.zc}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="zw" label="职务" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.zw" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.zw}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="xmfg" label="项目分工" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.xmfg" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.xmfg}}</span>
                                        </template>
                                    </el-table-column>

                                    <el-table-column prop="gzdw" label="工作单位" align="center">
                                        <template slot-scope="scope">
                                            <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.gzdw" placeholder="请输入" />
                                            <span v-show="!scope.row.editFlag">{{scope.row.gzdw}}</span>
                                        </template>
                                    </el-table-column>
                                </el-table-column>
                            </el-table>
                        </div>
                    </el-col>
                    <el-col :span='1' :offset='1' style="padding-top:80px;">
                        <el-button icon="el-icon-plus" size='mini' circle @click="addRow(1)" class="plus"></el-button>
                    </el-col>
                    <el-col :span='1' style="padding-top:80px;">
                        <el-button icon="el-icon-minus" size='mini' circle @click="delRow(1)" class="plus"></el-button>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>已完成的研究生教改项目及时间：</span>
                    </el-col>
                </el-row>
                <el-row :gutter="30" class="textarea">
                    <el-col :span="22">
                        <el-input type="textarea" :autosize="{ minRows: 6, maxRows: 8}" placeholder="请输入内容" v-model="jgxm.ywcjgxmhsj">
                        </el-input>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>项目研究内容、意义摘要：</span>
                    </el-col>
                </el-row>
                <el-row :gutter="30" class="textarea">
                    <el-col :span="22">
                        <el-input type="textarea" :autosize="{ minRows: 6, maxRows: 8}" placeholder="请输入内容" v-model="jgxm.yjnr">
                        </el-input>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>本项目研究意义及国内外同类研究工作现状</span>
                    </el-col>
                </el-row>
                <el-row :gutter="30" class="textarea">
                    <el-col :span="22">
                        <el-input type="textarea" :autosize="{ minRows: 6, maxRows: 8}" placeholder="请输入内容" v-model="jgxm.gzxz">
                        </el-input>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>主要研究内容、目标、方案和进度及拟解决的关键问题</span>
                    </el-col>
                </el-row>
                <el-row :gutter="30" class="textarea">
                    <el-col :span="22">
                        <el-input type="textarea" :autosize="{ minRows: 6, maxRows: 8}" placeholder="请输入内容" v-model="jgxm.zyyjfx">
                        </el-input>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>与本项目有关的工作条件（包括研究工作基础、实验条件等）</span>
                    </el-col>
                </el-row>
                <el-row :gutter="30" class="textarea">
                    <el-col :span="22">
                        <el-input type="textarea" :autosize="{ minRows: 6, maxRows: 8}" placeholder="请输入内容" v-model="jgxm.gztj">
                        </el-input>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>项目预期成果形式、效果</span>
                    </el-col>
                </el-row>
                <el-row :gutter="30" class="textarea">
                    <el-col :span="22">
                        <el-input type="textarea" :autosize="{ minRows: 6, maxRows: 8}" placeholder="请输入内容" v-model="jgxm.xmyqcgxsxg">
                        </el-input>
                    </el-col>
                </el-row>

                <el-row>
                    <el-col :sapn='24' style="margin-top:5px;line-height:50px">
                        <div class="small"></div>
                        <span>经费预算（单位：万元）：</span>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="20">
                        <div class="table-data">
                            <el-table border :data="jgxm.jfys" ref="multipleTable" @cell-mouse-enter="handleMouseEnter" @cell-mouse-leave="handleMouseOut">
                                <el-table-column prop="sj" label="时间" align="center">
                                    <template slot-scope="scope">
                                        <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.sj" placeholder="请输入内容" />
                                        <span v-show="!scope.row.editFlag">{{scope.row.sj}}</span>
                                    </template>
                                </el-table-column>

                                <el-table-column prop="jfys" label="经费预算" align="center">
                                    <template slot-scope="scope">
                                        <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.jfys" placeholder="请输入内容" />
                                        <span v-show="!scope.row.editFlag">{{scope.row.jfys}}</span>
                                    </template>
                                </el-table-column>

                                <el-table-column prop="yt" label="用途" align="center">
                                    <template slot-scope="scope">
                                        <el-input size="mini" v-show="scope.row.editFlag" v-model="scope.row.yt" placeholder="请输入内容" />
                                        <span v-show="!scope.row.editFlag">{{scope.row.yt}}</span>
                                    </template>
                                </el-table-column>

                            </el-table>
                        </div>
                    </el-col>
                    <el-col :span='1' :offset='1' style="padding-top:60px;">
                        <el-button icon="el-icon-plus" size='mini' circle @click="addRow(2)" class="plus"></el-button>
                    </el-col>
                    <el-col :span='1' style="padding-top:60px;">
                        <el-button icon="el-icon-minus" size='mini' circle @click="delRow(2)" class="plus"></el-button>
                    </el-col>
                </el-row>

                <!-- <el-row :gutter="30">
                  <el-col :span="22">
                    <el-form-item label="附件：" prop="">
                      <a :href="item.url" v-for="item in jgxm.fj" class="fj">
                        <i class="el-icon-document"></i>
                        {{item.name}}<br/>
                      </a>
                    </el-form-item>
                  </el-col>
                </el-row> -->

                <!-- 添加附件 -->
                <div class="append-btn">
                    <el-upload class="upload-demo" :action="baseUrls" :on-progress="progress" :on-preview="handlePreview" :on-remove="handleRemove" :before-remove="beforeRemove" :on-success="handleSuccess" multiple  :on-exceed="handleExceed" :file-list="fileList">
                        <el-col :span="24">
                            <el-button size="small" @click="print">
                                <div class="append-img">
                                    <img src="../../assets/image/attachment.png" alt="" style="width:100%;height:100%;">
                                </div>
                                <p class="append-text">添加附件</p>
                            </el-button>
                        </el-col>
                        <!-- <el-col :span="12">
                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                        </el-col> -->
                    </el-upload>
                </div>

                <!-- 提交重置 -->
                <div class="submit-box">
                    <el-button type="primary" @click="saveMsg" class="submit-btn">保存</el-button>
                    <!-- <el-button type="primary" @click="applySave" class="submit-btn">保存</el-button>
                    <el-button type="primary" @click="reset" class="submit-btn">重置</el-button> -->
                    <el-button type="primary" @click="handleCancel" class="submit-btn">返回</el-button>
                    <el-button :loading="this.loading" type="primary" @click="changeSubmit" class="submit-btn" :disabled="onsuccess">{{ submit }}</el-button>
                </div>
            </el-form>
        </div>
    </div>
</template>

<script>
export default {
  data() {
    return {
      tableTime: "", //列表结束时间
      changeTime: "", //修改当前时间
      subTime: "", //提交当前时间
      onsuccess: false,
      submit: "提交",
      loading: false, //显示正在加载中动画开关
      fileList: [], //上传文件列表展示
      showTable: true, //展示列表开关
      dataList: [], //列表数据相关
      seeVisible: false, //审核流程图显示开关
      his: [], //审核记录相关
      lcid: "", //流程id
      id: "",
      zt: "",
      //列表前端分页
      pageList: {
        totalCount: "",
        pageSize: "",
        totalPage: "",
        currPage: ""
      },
      pageHelp: {
        page: 1,
        limit: 5,
        sidx: "cjsj",
        order: "desc"
      },
      // 教改项目
      yqdzycg: [],
      jgxm: {
        fj: [],
        zycjzjk: [
          {
            num: 1,
            xb: "",
            xl: "",
            xm: "",
            zc: "",
            zw: "",
            csrq: "",
            gzdw: "",
            xmfg: "",
            editFlag: false,
            tableNum: 1
          }
        ],
        jfys: [
          {
            num: 1,
            sj: "",
            yt: "",
            jfys: "",
            editFlag: false,
            tableNum: 2
          }
        ]
      }
    };
  },
  methods: {
    // 列表页面：
    // 时间戳转换成时间：使用element table组件中的formatter属性，传入一个函数
    timestampToTime(row, column) {
      var date = new Date(row.cjsj); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
      var Y = date.getFullYear() + "-";
      var M =
        (date.getMonth() + 1 < 10
          ? "0" + (date.getMonth() + 1)
          : date.getMonth() + 1) + "-";
      var D = date.getDate() + " ";
      var h = date.getHours() + ":";
      var m = date.getMinutes() + ":";
      var s = date.getSeconds();
      return Y + M + D + h + m + s;
      // console.log(timestampToTime (1533293827000))
    },
    loadTable() {
      if (this.has("teajgxm:selectListForService")) {
        this.$http
          .get(this.$server.glourl + "teajgxm/selectListForService", {
            params: this.pageHelp
          })
          .then(response => {
            const data = response.data;
            this.dataList = data.page.list;
            this.pageList = data.page;
            // console.log(response)
          });
      } else {
        console.log();
      }
    },
    // 分页功能
    indexMethod(index) {
      return (this.pageList.currPage - 1) * this.pageList.pageSize + index + 1;
    },
    handleSizeChange(val) {
      this.pageList.pageSize = val;
      this.pageHelp.limit = this.pageList.pageSize;
      this.pageHelp.page = this.pageList.currPage;
      this.loadTable();
    },
    handleCurrentChange(currentPage) {
      this.pageList.currPage = currentPage;
      this.pageHelp.page = this.pageList.currPage;
      this.loadTable();
    },
    //列表下载按钮
    download(lcid, zt) {
      if (zt == "1") {
        location.href = this.$server.glourl + "teajgxm/downWord?lcid=" + lcid;
      } else {
        this.$message({
          message: "审核未通过！",
          type: "error"
        });
      }
    },
    //点击列表选中
    clickRow(row) {
      this.$refs.moviesTable.toggleRowSelection(row);
      //console.log(row);
    },
    // 选择表格行id
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.id = "";
        this.lcid = "";
        this.zt = "";
        this.tableTime = "";
      } else {
        this.id = selection[0].id;
        this.lcid = selection[0].lcid;
        this.zt = selection[0].zt;
        this.tableTime = selection[0].jssj;
        // console.log(selection)
      }
    },
    //关闭申请页面
    close() {
      this.showTable = true;
      this.loadTable();
    },
    //取消
    handleCancel() {
      this.showTable = true;
      this.loadTable();
    },
    // 文件上传成功时的钩子
    handleSuccess(response, file, fileList) {
      this.jgxm.fj.push({ name: response.name, url: response.url });
      this.onsuccess = false;
    },
    progress: function() {
      this.onsuccess = true;
    },
    handleRemove(file, fileList) {
      this.onsuccess = false;
      this.fileList = fileList;
      this.jgxm.fj = this.fileList;
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    },
    //保存
    saveMsg() {
      //   this.jgxm.jfly = this.jfly.join()
      this.jgxm.yqdzycg = this.yqdzycg.join();
      this.$http
        .post(this.$server.glourl + "teajgxm/saveforupdate", this.jgxm)
        .then(response => {
          if (response.data.code == 0) {
            this.$message({
              message: "保存成功！",
              type: "success"
            });
            // this.jfly = []
            this.showTable = true;
            this.loadTable();
          }
        })
        .catch(function(err) {
          console.log(err);
        });
    },
    // 修改申请表单提交
    changeSubmit() {
      this.subTime = new Date().getTime();
      if (this.tableTime < this.subTime) {
        this.$message({
          message: "已过期，无效操作!",
          type: "error"
        });
        return;
      } else {
        this.loading = true;
        this.submit = "加载中";
        //   this.jgxm.jfly = this.jfly.join()
        this.jgxm.yqdzycg = this.yqdzycg.join();
        this.$http
          .post(this.$server.glourl + "teajgxm/update", this.jgxm)
          .then(response => {
            if (response.data.code == 0) {
              this.$message({
                message: "修改成功！",
                type: "success"
              });
              // this.jfly = []
              this.loading = false;
              this.submit = "提交";
              this.showTable = true;
              this.loadTable();
            }else if (response.data.code == 123456) {
                this.loading = false;
                this.submit = "提交";
                this.$message({
                  message: "同一项目只能申请一次!",
                  type: "error"
                });
                return;
              }
          })
          .catch(function(err) {
            console.log(err);
          });
      }
    },
    // 查看详情（点击修改按钮）
    handleSee() {
      this.changeTime = new Date().getTime();
      if (this.id == null || this.id == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      } else if (this.zt != 4 && this.zt != 5) {
        this.$message({
          message: "只能修改退回或未提交的信息！",
          type: "error"
        });
      } else {
        if (this.tableTime < this.changeTime) {
          this.$message({
            message: "已过期，无效操作!",
            type: "error"
          });
          return;
        } else {
          this.$http
            .get(this.$server.glourl + "teajgxm/selectInfoById?id=" + this.id)
            .then(response => {
               //console.log(response.data)
              this.jgxm = response.data.jgxm;

              this.yqdzycg = (response.data.jgxm.yqdzycg).split(",")
              // console.log(this.jgxm.sj)
              // 附件展示，需要解析成对象
              this.jgxm.fj = JSON.parse(response.data.jgxm.fj);
              this.fileList = this.jgxm.fj;
              this.jgxm.zycjzjk = JSON.parse(response.data.jgxm.zycjzjk);
              this.jgxm.jfys = JSON.parse(response.data.jgxm.jfys);
              // console.log(response.data.map.stu)
            });
          this.showTable = false;
        }
      }
    },
    //申请信息table鼠标经过事件
    handleMouseEnter(row, column, cell, event) {
      const tableIndex = row.tableNum;
      let num = row.num - 1;
      switch (tableIndex) {
        // 教改
        case 1:
          this.jgxm.zycjzjk[num].editFlag = true;
          break;
        case 2:
          this.jgxm.jfys[num].editFlag = true;
          break;
        default:
          break;
      }
    },
    //申请信息table鼠标经过移出事件
    handleMouseOut(row, column, cell, event) {
      const tableIndex = row.tableNum;
      let num = row.num - 1;
      switch (tableIndex) {
        // 教改
        case 1:
          this.jgxm.zycjzjk[num].editFlag = false;
          break;
        case 2:
          this.jgxm.jfys[num].editFlag = false;
          break;
        default:
          break;
      }
    },
    //申请表信息动态添加行
    addRow(tableIndex) {
      switch (tableIndex) {
        // 教改
        case 1:
          this.jgxm.zycjzjk.push({
            num: this.jgxm.zycjzjk.length + 1,
            editFlag: false,
            tableNum: 1
          });
          break;
        case 2:
          this.jgxm.jfys.push({
            num: this.jgxm.jfys.length + 1,
            editFlag: false,
            tableNum: 2
          });
          break;
        default:
          break;
      }
    },
    //申请信息动态减少行
    delRow(tableIndex) {
      switch (tableIndex) {
        // 教改
        case 1:
          if (this.jgxm.zycjzjk.length == 1) {
            return;
          }
          this.jgxm.zycjzjk.pop();
          break;
        case 2:
          if (this.jgxm.jfys.length == 1) {
            return;
          }
          this.jgxm.jfys.pop();
          break;
        default:
          break;
      }
    },
    // 查看审核记录
    handleProgress() {
      if (this.id == null || this.id == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      if (this.lcid == null || this.lcid == "") {
        this.$message({
          message: "请选择一条已提交审核的数据！",
          type: "error"
        });
        return;
      } else {
        this.$http
          .get(
            this.$server.glourl + "stucgbb/selectHisBuLcid?lcid=" + this.lcid
          )
          .then(response => {
            for (let i = 0; i < response.data.his.length; i++) {
              if (response.data.his[i].endTime != null) {
                response.data.his[i].endTime = this.changeDataType(
                  response.data.his[i].endTime
                );
              }
              response.data.his[i].startTime = this.changeDataType(
                response.data.his[i].startTime
              );
            }
            this.his = response.data.his;
            //   console.log(this.his)
            // console.log(this.his[0].startTime)
          });
        this.seeVisible = true;
      }
    },
    //改变时间格式
    changeDataType(time) {
      const date = new Date();
      date.setTime(time); // value通过截取字符串只取数字。
      return date.toLocaleDateString() + " " + date.toLocaleTimeString();
    }
    //   getData () {
    //       this.$http
    //         .get("platform-framework/teajgxm/selectJGInit?xmid="+this.id)
    //         .then(
    //             response => {
    //                 this.jgxm = response.data.teaJgxm
    //                 this.jgxm.fj = JSON.parse(response.data.teaJgxm.fj)
    //         }
    //     )
    //   },
  },
  activated() {
    this.loadTable();
    //   this.getData()
  }
};
</script>

<style lang="scss" scoped>
.el-button + .el-button {
  margin-left: 0px;
}
@import "../../style/common"; //必须加分号，不然会报错
@import "../../style/ele";
</style>
