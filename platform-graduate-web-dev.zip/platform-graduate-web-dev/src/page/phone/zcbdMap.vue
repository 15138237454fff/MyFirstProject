<template>
    <div class="outdiv">
        123
    </div>

</template>
<style scoped>
@import "../../style/common.css";
</style>
