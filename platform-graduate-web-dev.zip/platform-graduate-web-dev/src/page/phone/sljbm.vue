<template>
  <div class="outdiv">
    <div class="score-wrappers" v-show="showForm">
      <table class="sljbm">
        <tbody>
          <tr class="name_bw">
            <td>姓名</td>
            <td class="table-left">{{grxx.xm}}</td>
          </tr>
          <tr class="name_bw">
            <td>学号</td>
            <td class="table-left">{{grxx.xh}}</td>
          </tr>
          <tr class="name_bw">
            <td>身份证号</td>
            <td class="table-left">{{grxx.sfzjh}}</td>
          </tr>
          <tr class="xh_bw">
            <td>所属学院</td>
            <td class="table-left">{{grxx.yxsmc}}</td>
          </tr>
          <tr class="xh_bw">
            <td>校区选择</td>
            <td class="table-left">
              <select style="width:100%;border:none !important" v-model="cetInfo.xq">
                <option :value="1">朝晖校区</option>
                <option :value="2">屏峰校区</option>
              </select>
            </td>
          </tr>
          <tr class="xh_bw">
            <td>报名名称</td>
            <td class="table-left">{{cetParams.name}}</td>
          </tr>
        </tbody>
      </table>
      <div style="width:94%;height:2rem;background:#ffffff;margin:0 auto;padding-left:0.3rem;padding-top:0.1rem;box-sizing:border-box" class="xh_bw">
        <p>英语四六级报名选择</p>
        <el-radio-group v-model="cetInfo.type" style="width:100%;text-align:center;" class="selectfx" @change="radioChange">
          <el-radio-button label="1">四级</el-radio-button>
          <el-radio-button label="2" style="margin-left:1rem;">六级</el-radio-button>
        </el-radio-group>
      </div>
      <div style="width:94%;height:3rem;margin:0 auto;text-align:center;margin-top:1rem;" class="bottombtn">
        <el-button type="success" v-if="cetInfo.status==1">已报名</el-button>
        <el-button @click="sumitCET" type="warning" v-else-if="cetInfo.status==2">待支付</el-button>
        <el-button @click="sumitCET" type="primary" v-else>提交</el-button>
      </div>
    </div>
    <div v-show="!showForm">
      <el-card class="box-card" id="order_info" :body-style="{padding: '10px'}">
        <div slot="header" class="clearfix">
          <span class="title">订单信息</span>
        </div>
        <div>
          <el-form>
            <el-row>
              <el-col span="12">
                <el-form-item label="姓名：">
                  <span>{{grxx.xm}}</span>
                </el-form-item>
              </el-col>
              <el-col span="12">
                <el-form-item label="学院：">
                  <span>{{grxx.yxsmc}}</span>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col span="12">
                <el-form-item label="学号：">
                  <span>{{grxx.xh}}</span>
                </el-form-item>
              </el-col>
              <el-col span="12">
                <el-form-item label="提交时间：">
                  <span>{{date}}</span>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col span="24">
                <el-form-item label="身份证号：">
                  <span>{{grxx.sfzjh}}</span>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
      </el-card>
      <el-card class="box-card" id="order_explain">
        <div slot="header" class="clearfix">
          <span class="title">订单说明</span>
        </div>
        <div style="border-bottom: 1px solid #ccc;padding-bottom: 0.4rem;">
          <el-row>
            <el-col :span="5">
              <span class="explain_title">物品名称</span>
            </el-col>
            <el-col :span="18" style="text-align:right">
              <span class="explain_title">物品价格</span>
            </el-col>
          </el-row>
          <el-row style="padding-top:0.2rem">
            <el-col :span="19">
              <span>{{payParams.orderName}}</span>
            </el-col>
            <el-col :span="4" style="text-align:center">
              <span>{{payParams.payAmount}}元</span>
            </el-col>
          </el-row>
        </div>
        <div>
          <el-row style="padding-top:0.2rem">
            <el-col :span="24" style="text-align:right">
              <span>合计&nbsp;<strong style="color:red;font-size:0.5rem">{{payParams.payAmount}}</strong>&nbsp;元</span>
            </el-col>
          </el-row>
        </div>
      </el-card>
      <el-card class="box-card" id="order_explain">
        <div slot="header" class="clearfix">
          <span class="title">支付方式</span>
        </div>
        <div>
          <el-row>
            <el-col :span="22">
              <i class="el-icon-alipay"></i>&nbsp;&nbsp;<span style="font-size: 0.35rem;">支付宝支付</span>
            </el-col>
            <el-col :span="2">
              <i class="el-icon-circle-check" style="font-size: 0.4rem;color:#0078fd;  "></i>
            </el-col>
          </el-row>
        </div>
      </el-card>
      <el-row style="margin-left:10%;width:80%">
        <el-col span="24">
          <el-button type="primary" style="width:100%" @click="payOrder">立即支付</el-button>
        </el-col>
      </el-row>

    </div>
  </div>

</template>
<style scoped>
@import "../../style/common.css";
.el-icon-alipay {
  background: url("../../assets/image/alipay.png") center no-repeat;
  background-size: 0.38rem;
}
.el-icon-alipay:before {
  content: "替";
  font-size: 18px;
  visibility: hidden;
}
.sljbm {
  padding-left: 0.5rem;
  border-collapse: collapse;
}
.sljbm tr {
  height: 1rem;
  font-size: 0.26rem;
}
#order_info {
  margin-left: 2%;
  font-size: 0.26rem;
  width: 96%;
}
#order_explain {
  margin-top: 0.3rem;
  margin-left: 2%;
  font-size: 0.26rem;
  width: 96%;
}
.title {
  font-size: 0.32rem;
  font-weight: bold;
}
.explain_title {
  font-size: 0.27rem;
  font-weight: bold;
}
.bottombtn button {
  width: 70%;
  height: 0.8rem;
  border-radius: 0.1rem;
  border: none;
  color: #fff;
}
</style>
<style>
.selectfx .el-radio-button__inner {
  border-radius: 0.1rem !important;
  border: 0.01rem solid #dcdfe6;
  padding: 0.12rem 0.5rem !important;
}
</style>

<script>
import QRCode from "qrcodejs2";
export default {
  data() {
    return {
      grxx: {},
      cetInfo: {
        xq: 1,
        type: 1
      },
      cet4Info: {
        xq: 1,
        type: 1
      },
      cet6Info: {
        xq: 1,
        type: 2
      },
      cetParams: {

      },
      payParams: {

      },
      radio: "1",
      showForm: true,
      date: null
    };
  },
  created() {
    //获取四六级报名参数信息
    this.getCETParamsInfo();
    //获取学生基本信息
    this.getStuInfo();
  },
  methods: {
    //立即支付
    payOrder() {
      this.createOrder();
    },
    //获取四六级报名参数信息
    getCETParamsInfo() {
      this.$http
        .get(this.$server.glourl + "cetparams/info")
        .then((response) => {
          if (response.data.code == 0) {
            this.cetParams = response.data.info;
            this.payParams.orderName = this.cetParams.cet4OrderName;
            this.payParams.payAmount = this.cetParams.cet4PayAmount;
            this.payParams.cetParamsId = this.cetParams.id;
            //获取四级报名信息
            this.getCETinfo(1);
            //获取六级报名信息
            this.getCETinfo(2);
            //获取时间
            this.date = this.getCurrentDate();
          } else {
            if (confirm(response.data.msg)) {
              this.$router.push({ name: "zzfw" });
            }
            else {
              this.$router.push({ name: "zzfw" });
            }
          }
        })
    },
    //类型改变事件
    radioChange(value) {
      if (value == 1) {
        this.cetInfo = this.cet4Info;
        this.payParams.orderName = this.cetParams.cet4OrderName;
        this.payParams.payAmount = this.cetParams.cet4PayAmount;
        this.cetInfo.type = 1;
      } else if (value == 2) {
        this.cetInfo = this.cet6Info;
        this.payParams.orderName = this.cetParams.cet6OrderName;
        this.payParams.payAmount = this.cetParams.cet6PayAmount;
        this.cetInfo.type = 2;
      }
    },
    //获取四六级报名信息
    getCETinfo(type) {
      this.$http
        .get(this.$server.glourl + "cet/cetInfo", {
          params: {            type: type, xq: 1
          }
        })
        .then((response) => {
          if (this.isEmpty(response.data.info)) {
            if (type == 1) {
              this.cet4Info = response.data.info;
              this.cetInfo = this.cet4Info;
            } else if (type == 2) {
              this.cet6Info = response.data.info;
            }
          }
        })
    },
    //获取学生基本信息
    getStuInfo() {
      this.$http
        .get(this.$server.glourl + "cet/info")
        .then((response) => {
          this.grxx = response.data.info;
        })
    },
    // 创建订单
    createOrder() {
      if (this.order_id == null) {
        this.$http.post(this.$server.glourl + 'alipay/cet/orderCreate', {
          orderName: this.payParams.orderName,
          payAmount: this.payParams.payAmount,
          xq: this.cetInfo.xq,
          type: this.cetInfo.type,
          xh: this.grxx.xh,
          ssxy: this.grxx.yxsh,
          cetParamsId: this.payParams.cetParamsId
        }).then(response => {
          var result = response.data
          if (result && result.ret_content) {
            if (result.ret_code == '0') {
              this.order_id = result.param.out_trade_no;
              this.goPay(result.param.url, this.cetInfo.xq);
            } else {
              alert(result.ret_content)
            }
          }
        })
      }
    },
    goPay(url, xq) {
      console.log(url.xq)
      this.$router.push({
        name: "PayCET",
        query: { url: url, xq: xq }
      });
    },
    sumitCET() {
      this.showForm = false;
    }
  }
};
</script>