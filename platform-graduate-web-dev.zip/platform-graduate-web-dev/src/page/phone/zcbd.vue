<template>
    <div class="outdiv">
        <div class="score-wrappers">
            <div class="score-title">
                研究生注册报到情况
            </div>
            <table class="table-center">
                <tbody>
                    <tr>
                        <th>学院</th>
                        <th>报到情况</th>
                    </tr>
                    <tr>
                        <td>经贸学院</td>
                        <td>
                            <span>应注册：1155</span>
                            <span>已注册：910</span>
                            <span>暂缓注册：175</span>
                            <span>注册率：93.9%</span>
                        </td>
                    </tr>
                    <tr>
                        <td>经贸学院</td>
                        <td>
                            <span>应注册：1155</span>
                            <span>已注册：910</span>
                            <span>暂缓注册：175</span>
                            <span>注册率：93.9%</span>
                        </td>
                    </tr>
                    <tr>
                        <td>经贸学院</td>
                        <td>
                            <span>应注册：1155</span>
                            <span>已注册：910</span>
                            <span>暂缓注册：175</span>
                            <span>注册率：93.9%</span>
                        </td>
                    </tr>
                    <tr>
                        <td>经贸学院</td>
                        <td>
                            <span>应注册：1155</span>
                            <span>已注册：910</span>
                            <span>暂缓注册：175</span>
                            <span>注册率：93.9%</span>
                        </td>
                    </tr>
                    <tr>
                        <td>经贸学院</td>
                        <td>
                            <span>应注册：1155</span>
                            <span>已注册：910</span>
                            <span>暂缓注册：175</span>
                            <span>注册率：93.9%</span>
                        </td>
                    </tr>
                    <tr>
                        <td>经贸学院</td>
                        <td>
                            <span>应注册：1155</span>
                            <span>已注册：910</span>
                            <span>暂缓注册：175</span>
                            <span>注册率：93.9%</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</template>
<style scoped>
@import "../../style/common.css";
</style>
<script>
export default {
  data() {
    return {};
  }
};
</script>