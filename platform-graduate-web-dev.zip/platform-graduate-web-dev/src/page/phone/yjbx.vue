<template>
  <el-card class="box-card">
    <div
      slot="header"
      class="clearfix"
      style=" font-size: 0.30rem"
    >
      <span>浙江工业大学研究生院自助终端报修</span>
    </div>
    <el-form
      ref="form"
      :rules="rules"
      :model="repairs"
      label-position:top
    >
      <el-form-item
        label="学号:"
        prop="idCard"
      >
        <el-input v-model="repairs.idCard"></el-input>
      </el-form-item>
      <el-form-item
        label="联系方式:"
        prop="phone"
      >
        <el-input v-model="repairs.phone"></el-input>
      </el-form-item>
      <el-form-item
        label="校区:"
        prop="campus"
      >
        <el-row :gutter="10">
          <el-col
            :xs="24"
            :sm="24"
            :md="24"
            :lg="24"
            :xl="24"
          >
            <el-select
              style="width:100%"
              v-model="repairs.campus"
              placeholder="请选择校区"
            >
              <el-option
                label="屏峰校区"
                :value="1"
              ></el-option>
              <el-option
                label="朝晖校区"
                :value="2"
              ></el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item
        label="故障原因:"
        prop="cause"
      >
        <el-row :gutter="10">
          <el-col
            :xs="24"
            :sm="24"
            :md="24"
            :lg="24"
            :xl="24"
          >
            <el-checkbox-group v-model="repairs.cause">
              <el-checkbox :label="1">机器故障</el-checkbox>

              <el-checkbox label="2">页面异常</el-checkbox>
              <el-checkbox label="3">打印机故障</el-checkbox>
            </el-checkbox-group>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col
            :xs="24"
            :sm="24"
            :md="24"
            :lg="24"
            :xl="24"
          >
            <el-checkbox-group v-model="repairs.cause">

              <el-checkbox label="4">支付异常</el-checkbox>
              <el-checkbox label="5">数据异常</el-checkbox>
              <el-checkbox label="6">其他原因</el-checkbox>
            </el-checkbox-group>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item
        label="故障描述:"
        prop="desc"
      >
        <el-input
          type="textarea"
          v-model="repairs.desc"
        ></el-input>
      </el-form-item>
      <el-form-item
        label="上传照片:"
        prop="file"
      >
        <el-row :gutter="10">
          <el-col
            :xs="24"
            :sm="24"
            :md="24"
            :lg="24"
            :xl="24"
          >
            <el-upload
              class="upload-demo"
              :action="baseUrls"
              :limit=3
              :before-upload="beforeAvatarUpload"
              :on-success="handleSuccess"
              :on-remove="handleRemove"
              :file-list="fileList"
              list-type="picture"
            >
              <el-button
                size="small"
                type="primary"
              >点击上传</el-button>
              <div
                slot="tip"
                class="el-upload__tip"
              >只能上传总数不超过3张的2MB以下的jpg/png文件</div>
            </el-upload>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item style="padding-top:0.2rem">
        <el-button
          style="width:100%"
          type="primary"
          @click="onSubmit"
        >提交</el-button>
      </el-form-item>
    </el-form>
  </el-card>

</template>
<style scoped>
@import "../../style/common.css";
</style>
<script> 
export default {
  data() {
    return {
      checkList: [],
      imageUrl: '',
      fileList: [],
      repairs: { cause: [], file: [], campus: 1 },
      rules: {
        idCard: [
          { required: true, message: '请输入学号', trigger: 'blur' }
        ], campus: [
          { required: true, message: '请选择活动区域', trigger: 'change' }
        ],
        cause: [
          { type: 'array', required: true, message: '请选择报修原因', trigger: 'change' }
        ],      }
    };
  }, methods: {

    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg';
      const isPNG = file.type === 'image/png';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!(isJPG || isPNG)) {
        this.$message.error('上传图片只能是 JPG 或者 PNG 格式!');
      }
      if (!isLt2M) {
        this.$message.error('上传图片大小不能超过 2MB!');
      }
      return (isJPG || isPNG) && isLt2M;
    },
    handleRemove(file, fileList) {
      for (let index = 0; index < this.repairs.file.length; index++) {
        const element = this.repairs.file[index];
        if (element.url = file.url) {
          this.repairs.file.splice(index, 1);
          break;
        }
      }
    },
    handleSuccess(response, file, fileList) {
      this.repairs.file.push({
        name: response.name,
        url: response.url
      })
    },
    onSubmit() {
      this.$refs["form"].validate((valid) => {
        if (valid) {
          this.submitInfo();
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    submitInfo() {
      var params = new URLSearchParams();
      params.append('json', JSON.stringify(this.repairs));
      this.$http
        .post(this.$server.glourl + "sstrepairs/save", params)
        .then(res => {
          if (res.data.code == 0) {
            this.$refs["form"].resetFields();
            this.fileList = [];
            alert("提交成功，我们会尽快处理！");

          }
        })
        .catch(function (err) {
          console.log(err);
        });
    }
  }
};
</script>
