<template>
  <div v-show="showInfo" style="font-size:0.40rem;" class="showInfo">
    <img src="../../assets/image/bg2x.png" style="width: 100%; height: 100%;" />
  </div>
</template>
<script>
export default {
  data() {
    return {
      showInfo: false
    };
  },
  mounted() {
    console.log(this.$route.query.url)
    var xq = this.$route.query.xq;
    if (xq == 1) {
      this.sunPay();
    } else if (xq == 2) {
      this.peakPay();
    }
  },
  methods: {
    //屏峰校区支付
    peakPay() {
      this.createOrder(this.$route.query.url);
    },
    //朝晖校区支付
    sunPay() {
      var ua = navigator.userAgent.toLowerCase();
      var isWeixin = ua.indexOf('micromessenger') != -1;
      if (isWeixin) {
        this.showInfo = true;
      } else {
        this.createOrder(this.$route.query.url);
      }
    },
    createOrder(url) {
      if (this.isEmpty(url)) {
        window.location.href = url;
      }
    },

  }
}
</script>
<style scoped>
.showInfo {
  width: 100%;
  height: 100%;
}
</style>

