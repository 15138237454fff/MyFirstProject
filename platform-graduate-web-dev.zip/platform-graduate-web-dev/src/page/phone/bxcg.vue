<template>
  <div class="outdiv">
    <div class="score-wrapper">
      <div class="cg_true">
        <img src="../../assets/image/true.png" alt="">
        <p>信息提交成功</p>
        <p>感谢您的提交，工作人员将尽快处理</p>
      </div>
    </div>
  </div>

</template>
<style scoped>
@import "../../style/common.css";
</style>
<script>
export default {
  data() {
    return {};
  }
};
</script>
