<template>
  <div style="width:100%">
    <!-- 列表与审核弹窗 -->
    <div class="container" v-show="show">
      <el-row style="margin:0 auto;">
        <el-col :span="24">
          <el-row style="float:right">
            <el-button type="primary" @click="see">查看审核信息</el-button>
            <el-button type="success" @click="addApply" v-if="has('project:create')">添加</el-button>
            <el-button type="danger" @click="applyChange" v-if="has('project:update')">修改</el-button>
            <el-button type="warning" @click="handleEdit" v-if="has('project:shenhe')">审核</el-button>
            <el-dialog title="审核信息" :visible.sync="dialogFormVisible" width="65%" style="margin-top:-5vh">
              <div class="divShadow2" v-show="stuKyxm.dsxm != null">
                <div class="topBlue1">导师审核信息</div>
                <el-form :model="stuKyxm" label-width="100px" class="demo-stuKyxm" label-position="left" style="padding-top:40px;">
                  <el-row :gutter="30">
                    <el-col :span="11">
                      <el-form-item label="审核人:">
                        <el-input v-model="stuKyxm.dsxm" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="11">
                      <el-form-item label="审核时间：">
                        <el-input v-model="stuKyxm.dsshsj" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row :gutter="30">
                    <el-col :span="22">
                      <el-form-item label="审核意见：">
                        <el-input type="textarea" v-model="stuKyxm.dsshyj" :rows="3" placeholder="" readonly="readonly">
                        </el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div class="divShadow2" v-show="stuKyxm.xyshr != null">
                <div class="topBlue1">学院审核信息</div>
                <el-form :model="stuKyxm" label-width="100px" class="demo-stuKyxm" label-position="left" style="padding-top:40px;">
                  <el-row :gutter="30">
                    <el-col :span="11">
                      <el-form-item label="审核人:">
                        <el-input v-model="stuKyxm.xyshr" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="11">
                      <el-form-item label="审核时间：">
                        <el-input v-model="stuKyxm.xyshsj" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row :gutter="30">
                    <el-col :span="22">
                      <el-form-item label="审核意见：">
                        <el-input type="textarea" v-model="stuKyxm.xyshyj" :rows="3" placeholder="" readonly="readonly">
                        </el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div class="divShadow2" v-show="stuKyxm.xxshr != null">
                <div class="topBlue1">学校审核信息</div>
                <el-form :model="stuKyxm" label-width="100px" class="demo-stuKyxm" label-position="left" style="padding-top:40px;">
                  <el-row :gutter="30">
                    <el-col :span="11">
                      <el-form-item label="审核人:">
                        <el-input v-model="stuKyxm.xxshr" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="11">
                      <el-form-item label="审核时间：">
                        <el-input v-model="stuKyxm.xxshsj" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row :gutter="30">
                    <el-col :span="22">
                      <el-form-item label="审核意见：">
                        <el-input type="textarea" v-model="stuKyxm.xxshyj" :rows="3" placeholder="" readonly="readonly">
                        </el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
              </div>
            </el-dialog>
          </el-row>
        </el-col>
      </el-row>
      <el-table ref="moviesTable" :data="page.slice((currentPage-1)*pageSize,currentPage*pageSize)" @row-click="clickRow" tooltip-effect="dark" style="margin:0 auto;margin-top:5px;text-align:center" @selection-change="handleSelectionChange" border>
        <el-table-column type="selection" width="55" align="center">
        </el-table-column>
        <el-table-column label="序号" type="index" :index="indexMethod" align="center" width="80">
        </el-table-column>
        <el-table-column prop="id" label="id" type="index" align="center" v-if="show4">
          <template slot-scope="scope">{{ scope.row.id }}</template>
        </el-table-column>
        <el-table-column prop="xsxm" label="学生姓名" align="center" show-overflow-tooltip>
          <template slot-scope="scope">{{ scope.row.xsxm }}</template>
        </el-table-column>
        <el-table-column prop="deptName" label="项目名称" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.xmmc }}</template>
        </el-table-column>
        <el-table-column prop="deptName" label="项目类型" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.xmlx }}</template>
        </el-table-column>
        <el-table-column prop="shzt" label="审核状态" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.shzt === '0' ? '导师审核中' :scope.row.shzt === '1'?'导师审核不通过':scope.row.shzt === '2'?'学院待审' :scope.row.shzt === '3'?'不通过':scope.row.shzt === '4'?'审核通过':scope.row.shzt === '5'?'学校退回' : scope.row.shzt === '6'? '退回':''}}</template>
        </el-table-column>
      </el-table>
      <div class="block" style="text-align:center;margin-top:30px">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 50]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="page.length">
        </el-pagination>
      </div>
    </div>
    <!-- 添加 -->
    <div v-show="!show">
      
      <div class="divShadow" v-show="!showCheck">
        <div class="topBlue">个人信息</div>
        <el-form label-width="177px" class="demo-stuKyxm" label-position="left" style="padding-top:50px;">
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="姓名：">
                <el-input v-model="stuKyxm.xsxm" readonly="readonly"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="学号：">
                <el-input v-model="stuKyxm.xh"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="学院名称：">
                <el-input v-model="stuKyxm.xymc" readonly="readonly"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div>
        <el-form :model="stuKyxm" :rules="rules" ref="stuKyxm" label-width="177px" class="demo-stuKyxm" label-position="left">
           <div class="divShadow" style="padding-bottom: 10px;">
        <div class="topBlue">填写提示</div>
        <h4  style="color:red;padding-top:50px;"><i>{{dict.message}}</i></h4>
      </div>
          <div class="divShadow">
            <div class="topBlue">关键信息</div>
            <el-row :gutter="30" style="padding-top:20px;">
              <el-col :span="11">
                <el-form-item label="项目名称：" prop="xmmc">
                  <el-input v-model="stuKyxm.xmmc" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="本人排名/总数：" prop="brpm">
                  <el-row>
                    <el-col span="5">
                      <el-input type="number" v-model="stuKyxm.brpm" max="10" min="1" :readonly="!showCheck"></el-input>
                    </el-col>
                    <el-col span="6">
                      <el-input type="number" v-model="stuKyxm.zzzrs" max="10" min="1" :readonly="!showCheck"></el-input>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="项目类型：" prop="xmlx">
                  <el-select v-model="stuKyxm.xmlx" placeholder="请选择" style="width:100%">
                    <el-option v-for="(item,index) in dict.itemList" :label="item.title" :value="item.title" :key="index" :disabled="!showCheck"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="项目具体类型：" prop="jtlx" v-if="isEmpty(stuKyxm.xmlx)">
                  <el-select v-model="stuKyxm.jtlx" placeholder="请选择" style="width:100%">
                    <el-option v-for="(item,index) in dict.specificList" :label="item.title" :value="item.title" :key="index" :disabled="!showCheck"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="项目编号：" prop="xmbh">
                  <el-input v-model="stuKyxm.xmbh" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="项目经费：" prop="xmjf">
                  <el-input v-model="stuKyxm.xmjf" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="是否是第一作者：" prop="sfdyzz">
                  <el-radio-group v-model="stuKyxm.sfdyzz">
                    <el-radio :label="1" :disabled="!showCheck">是</el-radio>
                    <el-radio :label="2" :disabled="!showCheck">否</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="11" v-if="stuKyxm.sfdyzz == '2'">
                <el-form-item label="是否是导师第一作者：" prop="dsdyzz">
                  <el-radio-group v-model="stuKyxm.dsdyzz">
                    <el-radio :label="1" :disabled="!showCheck">是</el-radio>
                    <el-radio :label="2" :disabled="!showCheck">否</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="导师参与类别：" prop="dscylb">
                  <el-select v-model="stuKyxm.dscylb" placeholder="请选择" style="width:100%">
                    <el-option v-for="(item,index) in dict.partType" :label="item.name" :value="item.name" :key="index" :disabled="!showCheck"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="学生参与类别：" prop="xscylb">
                  <el-select v-model="stuKyxm.xscylb" placeholder="请选择" style="width:100%">
                    <el-option v-for="(item,index) in dict.partType" :label="item.name" :value="item.name" :key="index" :disabled="!showCheck"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="项目开始时间：" prop="xmkssj">
                  <div class="date">
                    <el-form-item style="margin-left:0">
                      <el-date-picker v-model="stuKyxm.xmkssj" type="month" placeholder="项目开始时间" :readonly="!showCheck">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="项目结束时间：" prop="xmjssj">
                  <div class="date">
                    <el-form-item style="margin-left:0">
                      <el-date-picker v-model="stuKyxm.xmjssj" type="month" placeholder="项目结束时间" :readonly="!showCheck">
                      </el-date-picker>
                    </el-form-item>
                  </div>
                </el-form-item>
              </el-col>
            </el-row>

          </div>
          <div class="divShadow">
            <div class="topBlue">项目信息</div>
            <el-row :gutter="30" style="padding-top:40px;">
              <el-col :span="11">
                <el-form-item label="中文关键字：" prop="zwgjz">
                  <el-input v-model="stuKyxm.zwgjz" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="英文关键字：" prop="ywgjz">
                  <el-input v-model="stuKyxm.ywgjz" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="中文摘要：" prop="zwzy">
                  <el-input v-model="stuKyxm.zwzy" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>

              <el-col :span="11">
                <el-form-item label="英文摘要：" prop="ywzy">
                  <el-input v-model="stuKyxm.ywzy" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="网络收录地址：" prop="wlsldz">
                  <el-input v-model="stuKyxm.wlsldz" :readonly="!showCheck"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="项目来源：" prop="xmly" v-if="isEmpty(stuKyxm.jtlx)">
                  <el-select v-model="stuKyxm.xmly" placeholder="请选择" style="width:100%">
                    <el-option v-for="(item,index) in dict.sourceList" :label="item.title" :value="item.title" :key="index" :disabled="!showCheck"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30" v-if="showCheck">
              <el-col :span="11">
                <el-form-item label="附件:" prop="fj">
                  <el-upload class="upload-demo" :action="baseUrl2" name="file" :on-preview="handlePreview" :on-remove="handleRemove" :before-remove="beforeRemove" :on-success="handleSuccess" multiple :limit="1" :on-exceed="handleExceed" :file-list="fileList">
                    <el-button slot="trigger" size="small" class="add">
                      <div class="img">
                        <img src="../../assets/image/attachment.png" alt style="width:100%;height:100%;" />
                      </div>
                      <span class="append">添加附件</span>
                    </el-button>
                    <div slot="tip" class="el-upload__tip">多个文件，请打压缩包上传！</div>
                  </el-upload>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row v-if="!showCheck">
              <el-col :span="11">
                <el-form-item label="附件:" prop="fj">
                  <el-button @click="download">下载附件</el-button>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <div class="bottomBox" style="text-align:center;"  v-if="showCheck">
            <el-button type="primary" class="reset" @click="close">取消</el-button>
            <el-button type="primary" class="reset" @click="submit">提交</el-button>
          </div>
          <div class="divShadow" v-if="!showCheck">
          <div class="topBlue">审核意见</div>
          <el-row style="margin-left:56px;padding-top:50px">
            <el-col :span="22">
              <el-input type="textarea" v-model="textarea" :rows="8" placeholder="请输入审核意见："></el-input>
            </el-col>
          </el-row>
          <div class="bottomBox" style="text-align:center;">
            <el-button type="primary" class="reset" @click="close">取消</el-button>
            <el-button type="primary" class="reset" @click="adopt()">通过</el-button>
            <el-button type="primary" class="reset" @click="nothrough()">不通过</el-button>
          </div>
        </div>
        </el-form>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  inject: ['reload'],
  data() {
    return {
      show: true, // 展示列表
      watch:true,
      fileList: [], //上传文件列表展示
      alist: {},
      page: [],
      currentPage: 1,
      pageSize: 5,
      ids: "",
      id: "",
      totalItems: 0,
      textarea: "",
      dialogFormVisible: false,
      stuKyxm: {
      },
      dict: {
        specificList: [],
        sourceList: []
      },
      rules: {
        xmmc: [{ required: true, message: "请填写项目名称", trigger: "blur" }],
        brpm: [{          required: true, trigger: 'blur',
          validator: (rule, value, callback) => {

            if (!this.isEmpty(this.stuKyxm.brpm)) {
              callback(new Error("请填写本人排名"));
            } else if (!this.isEmpty(this.stuKyxm.zzzrs)) {
              callback(new Error('请填写总人数'));
            } else {
              callback();
            }
          }
        }],
        xmlx: [{ required: true, message: "请选择项目类型", trigger: "change" }],
        jtlx: [{ required: true, message: "请选择项目具体类型", trigger: "change" }],
        xmbh: [{ required: true, message: "请填写项目编号", trigger: "blur" }],
        xmjf: [{ required: true, message: "请填写项目经费", trigger: "blur" }],
        sfdyzz: [{ required: true, message: '请选择是否第一作者', trigger: 'blur' }],
        dsdyzz: [{ required: true, message: '请选择是否导师作者', trigger: 'blur' }],
        dscylb: [{ required: true, message: '请选择导师参与类别', trigger: 'change' }],
        xscylb: [{ required: true, message: '请选择学生参与类别', trigger: 'change' }],
        xmkssj: [{ required: true, message: '请选择开始时间', trigger: 'change' }],
        xmjssj: [{ required: true, message: '请选择结束时间', trigger: 'change' }],
        xmly: [{ required: true, message: "请填写项目来源", trigger: "blur" }],
        // zwgjz:  [{ required: true, message: "请填写中文关键字", trigger: "blur" }],
        // ywgjz:  [{ required: true, message: "请填写英文关键字", trigger: "blur" }],
        // zwzy:   [{ required: true, message: "请填写中文摘要", trigger: "blur" }],
        // ywzy:   [{ required: true, message: "请填写英文摘要", trigger: "blur" }],
        // wlsldz: [{ required: true, message: "请填写网络收录地址", trigger: "blur" }],
      }
    }
  },
  mounted() {
    //进入页面，加载申请列表
    this.loadTable();
    //加载参数
    this.loadMessage();
  },
  watch: {
    'stuKyxm.xmlx'(val) {
      for (let index = 0; index < this.dict.itemList.length; index++) {
        const element = this.dict.itemList[index];
        if (element.title == val) {
          this.dict.specificList = element.children;
           if(this.watch){
          this.$set(this.stuKyxm, 'jtlx', null);
           }
          break;
        }
      }
    },
    'stuKyxm.jtlx'(val) {
      for (let index = 0; index < this.dict.specificList.length; index++) {
        const element = this.dict.specificList[index];
        if (element.title == val) {
          this.dict.sourceList = element.children;
          if(this.watch){
             this.$set(this.stuKyxm, 'xmly', null);
          }
          break;
        }
      }
    }
  },
  methods: {
    loadMessage() {
      //科研项目项目类型-具体类型-项目来源
      this.loadDict(this.dict, 'itemList', 'XS-21083');
      //消息提醒
      this.loadDict(this.dict, 'message', 'XS-28493');
      //参与类别
      this.loadDict(this.dict, 'partType', 'XS-29039');
    },
    //加载列表
    loadTable() {
      this.$http
        .post(this.$server.glourl + "stukyxm/KyxmMenu")
        .then(response => {
          this.page = response.data.stukyxm
          this.alist = response.data.xjxxMap
        });
    },
    //表格方法
    //点击列表选中
    clickRow(row) {
      this.$refs.moviesTable.toggleRowSelection(row);
    },
    //列表选择改变事件
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.ids = "";
        this.shzt="";
      } else {
        this.ids = selection[0].id;
        this.shzt=selection[0].shzt;
      }
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val;
      this.loadTable();
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      this.loadTable();
    },
    //列表序号
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1;
    },
    //下载附件
    download() {
      location.href = this.$server.glourl + "stukyxm/download";
    },
    // 文件上传成功时的钩子
    handleSuccess(response, file, fileList) {
      this.stuKyxm.fj = response.url;
    },
    //查看审核信息
    see() {
      if (this.ids == null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      } else {
        this.$http
          .post(this.$server.glourl + "stukyxm/info/" + this.ids)
          .then(response => {
            this.stuKyxm = response.data.stuKyxm;
            this.dialogFormVisible = true;
            if (this.stuKyxm.dsxm == null) {
              this.dialogFormVisible = false;
              this.$message({
                message: "无审核信息！",
                type: "error"
              });
            }
          });
      }
    },
    //添加按钮函数
    addApply() {
      this.show = false;
      this.showCheck = true;
      this.watch=true;
      this.stuKyxm.xsxm = this.alist.xm;
      this.stuKyxm.xh = this.alist.xh;
      this.stuKyxm.xymc = this.alist.yxsh;
      //this.xscgMessage(this.dict.message);
    },
    //关闭添加页面
    close() {
      this.show = true
      this.loadTable()
    },
    //点击重置
    reset() {
      this.stuKyxm.cyzxx = [];
      this.$message({
        message: '已重置',
        type: 'success'
      });
    },
    //点击审核
    handleEdit(index, row) {
      if (this.ids == null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      this.$http
        .post(this.$server.glourl + "stukyxm/info/" + this.ids)
        .then(response => {
          this.stuKyxm = response.data.stuKyxm
          this.show = false;
           this.watch=false;
        });
    },
    //点击通过
    adopt() {
      this.$http
        .get(this.$server.glourl + "stukyxm/TutorCheck", {
          params: {
            id: this.stuKyxm.id,
            suggestion: this.textarea,
            shenhe: "1"
          }
        })
        .then(res => {
          if (res.data.msg == 1) {
            this.$message({
              message: "抱歉，该数据已被审核，不可操作！",
              type: "error"
            });
          } else {
            this.loadTable();
            this.$message({
              message: "审核成功！",
              type: "success"
            });
             this.show=true;
          }
        });
    },
    //点击不通过
    nothrough() {
      if (!this.isEmpty(this.textarea)) {
        this.$message({
          message: "请输入审核意见！",
          type: "error"
        });
        return;
      }
      this.$http
        .get(this.$server.glourl + "stukyxm/TutorCheck", {
          params: {
            id: this.stuKyxm.id,
            suggestion: this.textarea,
            shenhe: "2"
          }
        })
        .then(res => {
          if (res.data.msg == 1) {
            this.$message({
              message: "抱歉，该数据已被审核，不可操作！",
              type: "error"
            });
          } else {
            this.show = true
            this.loadTable();
            this.$message({
              message: "审核成功！",
              type: "success"
            });
          }
        });
    },
    //申请信息提交至远程
    submitInfo() {
      this.$http
        .post(this.$server.glourl + "stukyxm/save", this.stuKyxm)
        .then(res => {
          if (res.data.code == 0) {
            this.$message({
              message: "申请信息提交成功，请等待审核！",
              type: "success"
            });
            this.show = true
            this.loadTable();
          }
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    //申请信息提交事件
    submit: function () {
      this.$refs['stuKyxm'].validate(valid => {
        if (valid) {
          if (!this.isEmpty(this.stuKyxm.id)) {
            this.submitInfo();
          } else {
            this.changeSubmit();
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 修改申请表单
    applyChange() {
      if (this.ids == null || this.ids == '') {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      }
      else if (this.shzt != 6) {
        this.$message({
          message: "只能修改退回的信息！",
          type: "error"
        });
      }
      else {
        this.$http
          .post(this.$server.glourl + "stukyxm/info/" + this.ids)
          .then(response => {
            this.watch=false
            this.stuKyxm = response.data.stuKyxm
            this.show = false
            this.showCheck=true
            
          });

      }
    },
    // 修改申请表单提交
    changeSubmit() {
      this.$http
        .post(this.$server.glourl + "stukyxm/modify", this.stuKyxm)
        .then(response => {
          if (response.data.code == 0) {
            this.$message({
              message: "修改成功！",
              type: "success"
            })
            // this.reload()
            this.show = true
            this.loadTable()
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../../style/xscg"; //必须加分号，不然会报错
@import "../../style/ele1";
// 信息提示弹窗样式
.dialog /deep/ .el-dialog {
  margin-top: 33vh !important;
  padding-bottom: 50px;
}
.point {
  text-align: center;
  color: #f56c6c;
  font-size: 18px;
}

.divShadows {
  width: 97%;
  background: rgba(255, 255, 255, 1);
  border-radius: 10px;
  margin: 0 auto;
  margin-top: 1%;
  padding-bottom: 1%;
  box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.1);
  position: relative;
}

.container {
  padding: 30px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
  margin-top: 10px;
  overflow: hidden;
}
.bottomBox {
  width: 97%;
  background: rgba(255, 255, 255, 1);
  margin-top: 3%;
  padding-bottom: 1%;
}
.close {
  text-align: center;
  width: 20px;
  height: 20px;
  color: #cccccc;
  font-size: 16px;
  position: absolute;
  right: 30px;
  top: 10px;
  cursor: pointer;
  z-index: 1000;
}
.el-btn {
  margin-top: 30px;
  /* margin-left: 56px; */
  margin-bottom: 20px;
}
.el-button--small,
.el-button--small.is-round {
  /* margin-left: 5px; */
  padding: 5px 15px 5px 15px;
}
.el-button {
  margin-left: 0px;
}
.el-button + .el-button {
  margin-left: 0px;
}
</style>
