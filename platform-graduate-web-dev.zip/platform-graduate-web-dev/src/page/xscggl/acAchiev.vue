<template>
  <div style="width:100%">
    <div class="container" v-show="show">
      <div class="header">
        <div class="right">
          <el-button type="primary" @click="see">查看审核信息</el-button>
          <el-button type="primary" @click="clickDetail">查看详情</el-button>
          <el-button type="success" @click="addApply" v-if="has('paper:save')"
            >添加</el-button
          >
          <el-button
            type="danger"
            @click="applyChange"
            v-if="has('paper:update')"
            >修改</el-button
          >
          <el-button
            type="warning"
            @click="handleEdit"
            v-if="has('paper:audit')"
            >审核</el-button
          >
          <el-button type="danger" @click="clickDelete">删除</el-button>
        </div>
        <el-dialog
          title="审核信息"
          :visible.sync="dialogFormVisible"
          width="500px"
          style="margin-top:-5vh"
        >
          <div style="padding:20px;" class="step">
            <el-steps direction="vertical">
              <el-step
                :title="item.node | nodeFilter"
                :description="item.comment"
                v-for="(item, index) of aduitHistoryList"
                :key="index"
              >
                <div slot="title" class="text-ellipsis">
                  <span>{{ item.node | nodeFilter }}</span>
                </div>

                <div slot="description">{{ item.userName }}</div>
                <span slot="description" class="time">{{
                  item.createTime
                }}</span>
                <span
                  slot="description"
                  :class="item.status | dsstatusFilter"
                  class="status"
                  >{{ item.status | dsztFilter }}</span
                >
                <div slot="description" class="comment" v-if="item.comment">
                  {{ item.comment }}
                </div>
                <i
                  v-if="item.status === null"
                  slot="icon"
                  class="el-icon-check"
                ></i>
                <i
                  v-else-if="item.status == 1"
                  slot="icon"
                  class="el-icon-check"
                ></i>
                <i
                  v-else-if="item.status == 2"
                  slot="icon"
                  class="el-icon-d-arrow-left"
                ></i>
                <i
                  v-else-if="item.status == 0"
                  slot="icon"
                  class="el-icon-close"
                ></i>
              </el-step>
            </el-steps>
          </div>
          <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="dialogFormVisible = false"
              >确 定</el-button
            >
          </div>
        </el-dialog>
      </div>
      <el-table
        ref="moviesTable"
        :data="page"
        @row-click="clickRow"
        tooltip-effect="dark"
        style="margin:0 auto;margin-top:5px;text-align:center"
        @row-dblclick="handleDblclick"
        @selection-change="handleSelectionChange"
        border
      >
        <el-table-column type="selection" width="55" align="center">
        </el-table-column>
        <el-table-column
          label="序号"
          type="index"
          :index="indexMethod"
          align="center"
          width="80"
        >
        </el-table-column>
        <el-table-column
          label="id"
          type="index"
          align="center"
          v-if="show4"
          prop="id"
        >
          <template slot-scope="scope">{{ scope.row.id }}</template>
        </el-table-column>
        <el-table-column
          prop="lwmc"
          label="论文名称"
          show-overflow-tooltip
          align="center"
        >
          <template slot-scope="scope">{{ scope.row.lwmc }}</template>
        </el-table-column>
        <el-table-column
          prop="xsxm"
          label="申请人"
          show-overflow-tooltip
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="shzt"
          label="审核状态"
          show-overflow-tooltip
          align="center"
        >
          <template slot-scope="scope">{{
            scope.row.shzt == "0"
              ? "不通过"
              : scope.row.shzt == "1"
              ? "通过"
              : scope.row.shzt == "2"
              ? "退回"
              : scope.row.shzt == "3"
              ? "审核中"
              : ""
          }}</template>
        </el-table-column>
        <el-table-column
          prop="node"
          label="当前环节"
          show-overflow-tooltip
          align="center"
        >
          <template slot-scope="scope">{{
            scope.row.node == "2"
              ? "学院秘书审核"
              : scope.row.node == "3"
              ? "学院秘书审核"
              : scope.row.node == "4"
              ? "学院秘书待提交"
              : scope.row.node == "5"
              ? "研究生院审核"
              : ""
          }}</template>
        </el-table-column>
      </el-table>
      <div class="block" style="text-align:center;margin-top:30px">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[5, 10, 20, 50]"
          :page-size="pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="totalCount"
        >
        </el-pagination>
      </div>
    </div>
    <!-- 添加 -->
    <div v-show="!show">
      <div class="divShadow" style="padding-bottom: 10px;">
        <div class="topBlue">填写提示</div>
        <h4 style="color:red;padding-top:50px;">
          <i>{{ dict.message }}</i>
        </h4>
      </div>
      <div class="divShadow">
        <div class="topBlue">关键信息</div>
        <el-form
          :model="stuxscg"
          :rules="rules"
          ref="stuxscg"
          label-width="190px"
          class="demo-stuxscg"
          label-position="left"
          style="padding-top:50px;"
        >
          <el-row
            :gutter="30"
            v-if="!isStudent && showCheck && stuxscg.shzt != 3"
          >
            <el-col :span="18">
              <el-form-item label="学生姓名" required prop="xh">
                <el-select
                  v-model="stuxscg.xh"
                  placeholder="请选择"
                  style="width:50%"
                  filterable
                  @change="handleXsChange"
                >
                  <el-option
                    v-for="(item, index) in xsList"
                    :key="index"
                    :label="`${item.xsxm}(${item.xh})`"
                    :value="item.xh"
                    :disabled="!showCheck"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="22">
              <el-form-item label="论文题目：" prop="lwmc">
                <el-input
                  v-model="stuxscg.lwmc"
                  :readonly="!showCheck"
                  @change="handleLwmcChange"
                  placeholder="例如：my-paper我的论文"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="12">
              <el-form-item label="是否是第一作者：" prop="sfdyzz">
                <el-radio-group
                  v-model="stuxscg.sfdyzz"
                  @change="handleFirstChange"
                >
                  <el-radio :label="1" :disabled="!showCheck">是</el-radio>
                  <el-radio :label="2" :disabled="!showCheck">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="12" v-if="stuxscg.sfdyzz == '2'">
              <el-form-item label="是否是导师第一作者：" prop="dsdyzz">
                <el-radio-group v-model="stuxscg.dsdyzz">
                  <el-radio :label="1" :disabled="!showCheck">是</el-radio>
                  <el-radio :label="2" :disabled="!showCheck">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="12">
              <el-form-item label="本人排名/总数：" prop="brpm">
                <el-row>
                  <el-col :span="12">
                    <el-input-number
                      v-model="stuxscg.brpm"
                      controls-position="right"
                      @change="handlePmChange"
                      :min="computedOrder"
                      :max="stuxscg.zzzrs"
                      :precision="0"
                      :disabled="!showCheck || stuxscg.sfdyzz == 1"
                    ></el-input-number>
                    <!-- <el-input
                      type="number"
                      v-model="stuxscg.brpm"
                      @input="handlePmChange"
                      :min="stuxscg.zzzrs"
                      :max="computedOrder"
                      :readonly="!showCheck || stuxscg.sfdyzz == 1"
                    ></el-input> -->
                  </el-col>
                  <el-col :span="12">
                    <!-- <el-input
                      type="number"
                      v-model="stuxscg.zzzrs"
                      :max="10"
                      :min="stuxscg.brpm"
                      :readonly="!showCheck"
                    ></el-input> -->
                    <el-input-number
                      v-model="stuxscg.zzzrs"
                      controls-position="right"
                      :min="stuxscg.brpm"
                      :precision="0"
                      :disabled="!showCheck"
                    ></el-input-number>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
            <el-col
              :span="12"
              v-if="stuxscg.dsdyzz == '2' && stuxscg.sfdyzz == '2'"
            >
              <el-form-item label="第一作者：" prop="dyzz">
                <el-input
                  v-model="stuxscg.dyzz"
                  :readonly="!showCheck"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="24">
              <el-form-item label="刊号：" prop="kh">
                <el-select
                  v-model="stuxscg.khVal"
                  placeholder="请选择"
                  style="width:20%"
                  @change="handleChange"
                >
                  <el-option
                    v-for="item in khOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                    :disabled="!showCheck"
                  >
                  </el-option>
                </el-select>
                <div
                  style="width:45%;display:inline-block"
                  v-if="stuxscg.khVal == 'ISSN'"
                >
                  <el-input
                    :value="computedKh[0]"
                    :maxlength="4"
                    placeholder="例如：0000"
                    @change="
                      val => {
                        this.computedKh = [val, this.computedKh[1]];
                      }
                    "
                    :readonly="!showCheck"
                    style="width:50%"
                  ></el-input>
                  -
                  <el-input
                    :value="computedKh[1]"
                    :maxlength="4"
                    placeholder="0000"
                    @change="
                      val => {
                        this.computedKh = [this.computedKh[0], val];
                      }
                    "
                    style="width:45%"
                    :readonly="!showCheck"
                  ></el-input>
                </div>
                <el-input
                  v-else
                  v-model="stuxscg.kh"
                  style="width:50%"
                  placeholder="例如：00000000"
                  :readonly="!showCheck"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="15">
              <el-form-item label="出版期刊名称：" prop="cbqkmc">
                <el-input
                  v-model="stuxscg.cbqkmc"
                  :readonly="!showCheck"
                  @change="handleQkmcChange"
                  placeholder="例如：scientific citation index"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="22">
              <el-form-item label="发表/录用状态：" prop="ly">
                <el-radio-group v-model="stuxscg.ly" @change="handleZtChange">
                  <el-radio :label="1" :disabled="!showCheck">已录用</el-radio>
                  <el-radio :label="2" :disabled="!showCheck">已发表</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <div v-if="stuxscg.ly == '1'">
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="拟刊出时间：" prop="nkcsj">
                  <el-date-picker
                    v-model="stuxscg.nkcsj"
                    type="date"
                    placeholder="选择日期"
                    format="yyyy / MM / dd "
                    :readonly="!showCheck"
                  >
                  </el-date-picker>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item
                  label="上传录用佐证："
                  prop="lyzz"
                  v-if="showCheck || isStudent"
                >
                  <my-upload
                    :url="baseUrls"
                    :info="this.stuxscg"
                    pointer="lyzz"
                    ref="lyzz"
                    v-if="stuxscg.ly == '1'"
                    :imgUrl="stuxscg.lyzz"
                    :onSuccess="handleSuccess"
                    :onRemove="handleRemove"
                    :isRequired="true"
                    @on-preview="handlePreview"
                    :limit="1"
                  />
                </el-form-item>
                <el-form-item label="录用佐证：" prop="lyzz" v-else>
                  <img
                    v-if="stuxscg.lyzz"
                    :src="stuxscg.lyzz"
                    class="avatar"
                    @click="clickPreview(stuxscg.lyzz)"
                  />
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <div v-if="stuxscg.ly == '2'">
            <el-row :gutter="30">
              <el-col :span="11">
                <el-form-item label="发表日期：" prop="fbrq">
                  <el-date-picker
                    v-model="stuxscg.fbrq"
                    type="date"
                    placeholder="选择日期"
                    format="yyyy / MM / dd "
                    :readonly="!showCheck"
                  >
                  </el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="11">
                <el-form-item label="刊出卷号：">
                  <el-input
                    v-model="stuxscg.kcjh"
                    :readonly="!showCheck"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="30">
              <el-col :span="24">
                <el-form-item
                  label="上传收录佐证："
                  prop="slzz"
                  v-if="showCheck"
                >
                  <my-upload
                    :url="baseUrls"
                    :info="this.stuxscg"
                    pointer="slzzFm"
                    ref="slzzFm"
                    v-if="stuxscg.ly == '2'"
                    :onSuccess="handleSuccess"
                    :onRemove="handleRemove"
                    @on-preview="handlePreview"
                    :isRequired="false"
                    :imgUrl="stuxscg.slzzFm"
                    btnName="封面"
                    :fileList="fileList"
                    :limit="1"
                  />
                  <my-upload
                    :url="baseUrls"
                    :info="this.stuxscg"
                    pointer="slzzMl"
                    ref="slzzMl"
                    v-if="stuxscg.ly == '2'"
                    :onSuccess="handleSuccess"
                    :onRemove="handleRemove"
                    @on-preview="handlePreview"
                    :isRequired="false"
                    :imgUrl="stuxscg.slzzMl"
                    btnName="目录"
                    :fileList="fileList"
                    :limit="1"
                  />
                  <my-upload
                    :url="baseUrls"
                    :info="this.stuxscg"
                    pointer="slzzFd"
                    ref="slzzFd"
                    v-if="stuxscg.ly == '2'"
                    :onSuccess="handleSuccess"
                    :onRemove="handleRemove"
                    @on-preview="handlePreview"
                    :isRequired="false"
                    :imgUrl="stuxscg.slzzFd"
                    btnName="封底"
                    :fileList="fileList"
                    :limit="1"
                  />
                  <my-upload
                    :url="baseUrls"
                    :info="this.stuxscg"
                    pointer="slzzBt"
                    ref="slzzBt"
                    v-if="stuxscg.ly == '2'"
                    :onSuccess="handleSuccess"
                    :onRemove="handleRemove"
                    @on-preview="handlePreview"
                    :isRequired="true"
                    :imgUrl="stuxscg.slzzBt"
                    btnName="标题页"
                    :fileList="fileList"
                    :limit="1"
                  />
                </el-form-item>
                <el-form-item label="收录佐证：" prop="slzz" v-else>
                  <div class="slzz-img">
                    <img
                      v-if="stuxscg.slzzFm"
                      :src="stuxscg.slzzFm"
                      @click="clickPreview(stuxscg.slzzFm)"
                      class="avatar"
                    />
                    <img
                      v-if="stuxscg.slzzMl"
                      :src="stuxscg.slzzMl"
                      @click="clickPreview(stuxscg.slzzMl)"
                      class="avatar"
                    />
                    <img
                      v-if="stuxscg.slzzFd"
                      :src="stuxscg.slzzFd"
                      @click="clickPreview(stuxscg.slzzFd)"
                      class="avatar"
                    />
                    <img
                      v-if="stuxscg.slzzBt"
                      :src="stuxscg.slzzBt"
                      @click="clickPreview(stuxscg.slzzBt)"
                      class="avatar"
                    />
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <el-row :gutter="30" v-if="stuxscg.khVal == 'ISSN'">
            <el-col :span="15">
              <el-form-item label="期刊类别：" prop="qklb">
                <el-select
                  v-model="stuxscg.qklb"
                  multiple
                  placeholder="请选择"
                  style="width:100%"
                >
                  <el-option
                    v-for="item in dict.qklbISSN"
                    :key="item.name"
                    :label="item.name"
                    :value="item.name"
                    :disabled="!showCheck"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30" v-if="stuxscg.khVal == 'ISBN'">
            <el-col :span="15">
              <el-form-item label="期刊类别：" prop="qklb">
                <el-select
                  v-model="stuxscg.qklb"
                  multiple
                  filterable
                  default-first-option
                  placeholder="请选择"
                  style="width:100%"
                >
                  <el-option
                    v-for="item in dict.qklbISBN"
                    :key="item.name"
                    :label="item.name"
                    :value="item.name"
                    :disabled="!showCheck"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="19">
              <el-form-item label="收录级别/影响因子/佐证：" prop="slinfo">
                <el-row v-for="(info, index) in stuxscg.slinfo" :key="index">
                  <el-col :span="8">
                    <el-select
                      v-model="stuxscg.slinfo[index].lyjb"
                      placeholder="请选择录用级别"
                      style="width:100%"
                      filterable
                      default-first-option
                    >
                      <el-option
                        v-for="item in dict.sljbLevel"
                        :key="item.name"
                        :label="item.name"
                        :value="item.name"
                        :disabled="!showCheck"
                      ></el-option>
                    </el-select>
                  </el-col>
                  <el-col :span="8" :offset="1">
                    <el-input
                      v-model="stuxscg.slinfo[index].yxyz"
                      placeholder="请输入影响因子"
                      :readonly="!showCheck"
                    ></el-input>
                  </el-col>
                  <el-col :span="4" :offset="1">
                    <my-upload
                      :url="baseUrls"
                      :info="stuxscg.slinfo[index]"
                      pointer="file"
                      :onSuccess="handleSuccess"
                      :imgUrl="info.file"
                      :onRemove="handleRemove"
                      @on-preview="handlePreview"
                      :fileList="stuxscg.slinfo[index].fileList"
                      btnName="收录证明"
                      :limit="1"
                      v-if="showCheck"
                    />
                    <img
                      v-if="info.file && !showCheck"
                      @click="clickPreview(info.file)"
                      :src="info.file"
                      class="avatar"
                    />
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
            <el-col :span="3" v-if="showCheck">
              <el-row>
                <el-col :span="12">
                  <el-button type="success" @click="addRow">新增</el-button>
                </el-col>
                <el-col :span="12">
                  <el-button type="danger" @click="delRow">删除</el-button>
                </el-col>
              </el-row>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="22">
              <el-form-item label="备注：" prop="bz">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 6, maxRows: 8 }"
                  placeholder="请输入内容"
                  v-model="stuxscg.bz"
                  :readonly="!showCheck"
                >
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="bottomBox" style="text-align:center;" v-if="isDetail">
          <el-button type="primary" class="reset" @click="close"
            >取消</el-button
          >
        </div>
        <div
          class="bottomBox"
          style="text-align:center;"
          v-else-if="showCheck || isStudent"
        >
          <el-button type="primary" class="reset" @click="close"
            >取消</el-button
          >
          <el-button
            type="primary"
            class="reset"
            @click="submit"
            v-if="showCheck"
            >提交</el-button
          >
        </div>
        <div class="divShadow" v-else-if="!showCheck && !isStudent">
          <div class="divShadow">
            <div class="topBlue">审核意见</div>
            <el-row style="margin-left:56px;padding-top:50px">
              <el-col :span="22">
                <el-input
                  type="textarea"
                  v-model="textarea"
                  :rows="8"
                  placeholder="请输入审核意见："
                ></el-input>
              </el-col>
            </el-row>
          </div>
          <div class="bottomBox" style="text-align:center;">
            <el-button type="primary" class="reset" @click="close"
              >取消</el-button
            >
            <el-button type="primary" class="reset" @click="adopt(1)"
              >通过</el-button
            >
            <el-button type="primary" class="reset" @click="adopt(0)"
              >不通过</el-button
            >
          </div>
        </div>
        <el-dialog :visible.sync="dialogVisible">
          <img width="100%" :src="dialogImageUrl" />
        </el-dialog>
      </div>
      <xs-message ref="XsMessage"></xs-message>
    </div>
  </div>
</template>
<script>
import myUpload from "@/components/myUpload.vue";
import XsMessage from "@/components/message.vue";
export default {
  inject: ["reload"],
  components: {
    myUpload,
    XsMessage
  },
  data() {
    return {
      show: true, // 展示列表开关
      showCheck: false,
      // isStudent: false,
      dialogVisible: false,
      dialogImageUrl: "",
      isDetail: false,
      khVal: "ISSN", // 刊号
      khVal1: "", // 刊号
      show4: false,
      fileList: [],
      xsList: [],
      khOptions: [
        {
          value: "ISSN",
          label: "ISSN"
        },
        {
          value: "ISBN",
          label: "ISBN"
        }
      ],
      dict: {
        message: "",
        qklbISSN: [], // 期刊类别ISSN
        qklbISBN: [], // 期刊类别ISBN
        sljbLevel: [] // 收录级别
      },
      sljb: [], // 收录级别
      sljbVal: [], // 收录级别
      sljbValue: [], // 收录级别
      input: "",
      isUpdate: false,
      currentPage: 1,
      pageSize: 5,
      totalItems: 0,
      totalCount: 0,
      textarea: "",
      dialogFormVisible: false,
      ids: "",
      shzt: "", // 审核状态
      node: null,
      id: "",
      page: [],
      file: [],
      aduitHistoryList: [],
      alist: {},
      stuxscg: {
        kh: ""
      },
      rules: {
        xh: [{ message: "请选择学生", required: true }],
        lwmc: [{ required: true, message: "请填写论文名称", trigger: "blur" }],
        sfdyzz: [
          { required: true, message: "请选择是否第一作者", trigger: "change" }
        ],
        dsdyzz: [
          {
            required: true,
            message: "请选择导师是否第一作者",
            trigger: "change"
          }
        ],
        dyzz: [{ required: true, message: "请填写第一作者", trigger: "blur" }],
        kh: [
          {
            required: true,
            message: "请填写刊号",
            trigger: "blur",
            validator: (rule, value, callback) => {
              if (!this.stuxscg.khVal) {
                callback(new Error("请填写刊号"));
                return;
              }
              if (this.stuxscg.khVal == "ISSN") {
                let tmpArr = this.stuxscg.kh.split("-");
                if (!Array.isArray(tmpArr)) {
                  callback(new Error("请填写刊号"));
                }
                tmpArr = tmpArr.filter(el => el);
                if (tmpArr.length !== 2) {
                  callback(new Error("请填写刊号"));
                }
                tmpArr.forEach(el => {
                  if (el.length !== 4) {
                    callback(callback(new Error("请填写刊号")));
                  }
                });
                callback();
              } else {
                if (!this.stuxscg.kh) {
                  callback(new Error("请填写刊号"));
                } else {
                  callback();
                }
              }
            }
          }
        ],
        cbqkmc: [
          { required: true, message: "请填写出版期刊全称", trigger: "blur" }
        ],
        ly: [
          { required: true, message: "请选择发表/录用状态", trigger: "change" }
        ],
        // nkcsj: [
        //   { required: true, message: "请选择拟刊出时间", trigger: "blur" }
        // ],
        fbrq: [{ required: true, message: "请选择发表时间", trigger: "blur" }],
        qklb: [{ required: true, message: "请选择期刊类别", trigger: "blur" }],
        slinfo: [
          {
            required: true,
            trigger: "blur",
            validator: (rule, value, callback) => {
              if (this.stuxscg.slinfo.length == 0) {
                callback();
              } else {
                this.stuxscg.slinfo.forEach(element => {
                  Object.keys(element).forEach((key, i, v) => {
                    if (!this.isEmpty(element[key])) {
                      callback(new Error("请填写收录信息"));
                    }
                  });
                });
                callback();
              }
            }
          }
        ],
        lyzz: [
          {
            required: true,
            trigger: "blur",
            validator: (rule, value, callback) => {
              if (this.isEmpty(this.stuxscg.lyzz)) {
                callback();
              } else {
                callback(new Error("请上传录用佐证"));
              }
            }
          }
        ],
        slzz: [
          {
            required: true,
            trigger: "blur",
            validator: (rule, value, callback) => {
              if (this.isEmpty(this.stuxscg.slzzBt)) {
                callback();
              } else {
                callback(new Error("请上传收录佐证"));
              }
            }
          }
        ],
        brpm: [
          {
            required: true,
            trigger: "blue",
            validator: (rule, value, callback) => {
              if (!this.isEmpty(this.stuxscg.brpm)) {
                callback(new Error("请填写本人排名"));
              } else if (!this.isEmpty(this.stuxscg.zzzrs)) {
                callback(new Error("请填写总人数"));
              } else {
                callback();
              }
            }
          }
        ]
      }
    };
  },
  activated() {
    this.loadTable();
    // 查询可维护信息
    this.loadMessage();
  },
  methods: {
    handleDblclick(row) {
      this.ids = row.id;
      this.clickDetail();
    },
    clickDetail() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      this.isDetail = true;
      this.show = false;
      this.showCheck = false;
      this.dataCallBack();
    },
    clickPreview(url) {
      console.log(url);
      this.dialogImageUrl = url;
      this.dialogVisible = true;
    },
    clickDelete() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      if (this.shzt != "0" && this.shzt != "2") {
        this.$message({
          message: "当前数据不可删除！",
          type: "error"
        });
        return;
      }
      this.$confirm("此操作将删除该记录, 是否继续?", "删除", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "error"
      }).then(this.handleDelete);
    },
    handleDelete() {
      this.$http
        .get(this.$server.glourl + "/academicPaper/delete", {
          params: { id: this.ids }
        })
        .then(res => {
          let data = res.data;
          console.log(data);
          if (data.code != 0) {
            this.$message({
              type: "error",
              message: data.msg
            });
            return;
          }
          this.$message({
            type: "success",
            message: "删除成功"
          });
          this.loadTable();
        });
    },
    handleXsChange(val) {
      let tmpObj = this.xsList.find(el => el.xh == val);
      if (!tmpObj) {
        return;
      }
      this.stuxscg.xsxm = tmpObj.xsxm;
      this.stuxscg.xymc = tmpObj.yxsh;
    },
    exportExcel() {
      window.location.href = this.$server.glourl + "stuxscg/stuExp";
    },
    loadMessage() {
      // ISSN期刊类别
      this.loadDict(this.dict, "qklbISSN", "XS-39621");
      // 提示信息
      this.loadDict(this.dict, "message", "XS-00306");
      // ISBN期刊类别
      this.loadDict(this.dict, "qklbISBN", "XS-41814");
      // ISBN期刊类别
      this.loadDict(this.dict, "sljbLevel", "XS-18669");
    },
    addRow() {
      this.stuxscg.slinfo.push({
        lyjb: "",
        yxyz: "",
        file: ""
      });
    },
    delRow() {
      this.stuxscg.slinfo.pop();
    },
    // 点击列表选中
    clickRow(row) {
      this.$refs.moviesTable.toggleRowSelection(row);
    },
    // 刊号变化触发事件
    handleChange() {
      this.stuxscg.qklb = [];
      this.stuxscg.kh = "";
    },
    // 加载列表
    loadTable() {
      this.$http
        .get(this.$server.glourl + "/academicPaper/serve/list", {
          params: {
            limit: this.pageSize,
            page: this.currentPage,
            sidx: "create_time",
            order: "desc"
          }
        })
        .then(response => {
          // this.page = response.data.stuxscg;
          // this.alist = response.data.xjxxMap;
          // this.qklb = response.data.qklb;
          // this.sljb = response.data.sljb;
          this.page = response.data.page.list;
          this.totalCount = response.data.page.totalCount;
        });
    },
    requireXsList() {
      this.$http
        .get(this.$server.glourl + "/academicPaper/student/list")
        .then(res => {
          let data = res.data;
          console.log(data);
          if (data.code != 0) {
            return;
          }
          this.xsList = data.list;
        });
    },
    // 添加按钮函数
    addApply() {
      this.$refs["stuxscg"].resetFields();
      if (this.isStudent) {
        this.stuxscg = {
          xsxm: this.userInfo.xsxm,
          xh: this.userInfo.xh,
          xymc: this.userInfo.yxsh,
          kh: "",
          slinfo: [],
          qklb: []
        };
      } else {
        this.requireXsList();
        this.stuxscg = {
          xsxm: "",
          xh: "",
          xymc: "",
          kh: "",
          slinfo: [],
          qklb: []
        };
      }
      this.show = false;
      this.showCheck = true;
    },
    handleLwmcChange(val) {
      let reg = /[A-Z]/;
      if (reg.test(val)) {
        this.$message.error("论文题目不能包含大写字母");
      }
      this.stuxscg.lwmc = val.toLowerCase();
    },
    handleQkmcChange(val) {
      let reg = /[A-Z]/;
      if (reg.test(val)) {
        this.$message.error("期刊名称不能包含大写字母，需要填写全称");
      }
      this.stuxscg.cbqkmc = val.toLowerCase();
    },
    handleFirstChange(val) {
      if (val == 1) {
        this.$set(this.stuxscg, "brpm", 1);
      } else if (val == 2 && this.stuxscg.brpm == 1) {
        this.stuxscg.brpm = 2;
      }
      if (parseInt(this.stuxscg.zzzrs) < parseInt(this.stuxscg.brpm)) {
        this.stuxscg.zzzrs = this.stuxscg.brpm;
      }
    },
    handlePmChange(val) {
      val = parseInt(val);
      let zzzrs = parseInt(this.stuxscg.zzzrs);
      console.log(val, zzzrs);
      if (val > zzzrs) {
        this.stuxscg.zzzrs = val;
      }
    },
    handleZtChange(val) {
      this.$nextTick(() => {
        if (val == 1) {
          this.$refs.lyzz.clear();
          this.$message({
            type: "info",
            message: "请尽量填写拟刊出时间"
          });
        } else {
          this.$refs.slzzFm.clear();
          this.$refs.slzzMl.clear();
          this.$refs.slzzFd.clear();
          this.$refs.slzzBt.clear();
        }
      });
    },
    // 关闭添加页面
    close() {
      this.show = true;
      this.isDetail = false;
      this.loadTable();
    },
    // 改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      this.loadTable();
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val;
      this.loadTable();
    },
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1;
    },
    // 下载附件
    download(href) {
      if (!href) {
        return;
      }
      window.location.href = href;
    },
    //  文件上传成功时的钩子
    handleSuccess(response, file, fileList, info, key) {
      if (this.isEmpty(response) && this.isEmpty(response.url)) {
        this.$set(info, key, response.url);
        // info[key] = response.url;
        console.log(info[key]);
      }
    },
    // 附件处理
    handleRemove(file, fileList, info, key) {
      info[key] = "";
    },
    // 列表选择改变事件
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.ids = "";
        this.shzt = "";
        this.node = null;
        this.isUpdate = false;
      } else {
        this.ids = selection[0].id;
        this.shzt = selection[0].shzt;
        this.node = selection[0].node;
        this.isUpdate = selection[0].update;
      }
    },
    // 申请信息提交事件
    submit() {
      this.$refs.stuxscg.validate(valid => {
        if (valid) {
          if (!this.isEmpty(this.stuxscg.id)) {
            this.submitInfo();
          } else {
            this.changeSubmit();
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    submitInfo() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(this.$server.glourl + "/academicPaper/save", this.stuxscg)
        .then(res => {
          loading.close();
          if (res.data.code == 0) {
            this.$message({
              message: "申请信息提交成功，请等待审核！",
              type: "success"
            });
            this.show = true;
            this.loadTable();
          } else {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 点击审核
    handleEdit(index, row) {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      if (this.shzt != "3" || this.node != 2) {
        this.$message({
          message: "当前数据不可审核！",
          type: "error"
        });
        return;
      }
      this.show = false;
      this.showCheck = false;
      this.dataCallBack();
    },
    //  修改申请表单
    applyChange() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      console.log(this.isStudent);
      console.log(typeof this.shzt);
      if (this.isUpdate) {
        this.showCheck = true;
      } else {
        this.$message({
          message: "无法修改的信息！",
          type: "error"
        });
        return;
      }
      this.show = false;
      this.dataCallBack();
    },
    //  修改申请表单提交
    changeSubmit() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(this.$server.glourl + "/academicPaper/serve/update", this.stuxscg)
        .then(response => {
          loading.close();
          if (response.data.code == 0) {
            this.$message({
              message: "修改成功！",
              type: "success"
            });
            //  this.reload()
            this.show = true;
            this.loadTable();
          } else {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
          }
        })
        .catch(function(err) {
          console.log(err.message);
          loading.close();
        });
    },
    // 点击通过
    adopt(status) {
      if (status == 0 && !this.isEmpty(this.textarea)) {
        this.$message({
          message: "请输入审核意见！",
          type: "error"
        });
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(this.$server.glourl + "/academicPaper/audit", {
          comment: this.textarea,
          genre: 1,
          businessId: [this.stuxscg.id],
          status
        })
        .then(res => {
          loading.close();
          if (res.data.code !== 0) {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          } else {
            this.show = true;
            this.loadTable();
            this.$message({
              message: "审核成功！",
              type: "success"
            });
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // // 点击不通过
    // nothrough() {
    //   if (!this.isEmpty(this.textarea)) {
    //     this.$message({
    //       message: "请输入审核意见！",
    //       type: "error"
    //     });
    //     return;
    //   }
    //   this.$http
    //     .get(this.$server.glourl + "stuxscg/TutorCheck", {
    //       params: {
    //         id: this.stuxscg.id,
    //         suggestion: this.textarea,
    //         shenhe: "2"
    //       }
    //     })
    //     .then(res => {
    //       //    console.log(this.stuxscg1.id);
    //       if (res.data.msg == 1) {
    //         this.$message({
    //           message: "抱歉，该数据已被审核，不可操作！",
    //           type: "error"
    //         });
    //       } else {
    //         this.show = true;
    //         this.showCheck = true;
    //         this.loadTable();
    //         this.$message({
    //           message: "审核成功！",
    //           type: "success"
    //         });
    //       }
    //     });
    // },
    // 查看审核信息
    see() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      } else {
        this.$http
          .get(this.$server.glourl + "/academicPaper/history", {
            params: {
              genre: 1,
              id: this.ids
            }
          })
          .then(response => {
            console.log(response);
            if (response.data.code != 0) {
              this.$message({
                message: response.data.msg,
                type: "error"
              });
              return;
            }
            this.aduitHistoryList = response.data.list.reverse();
            this.dialogFormVisible = true;
          });
      }
    },
    handlePreview(file) {
      console.log(file);
      let url = file.url;
      if (!url) {
        return;
      }
      window.location.href = url;
    },
    dataCallBack() {
      this.$http
        .get(this.$server.glourl + "/academicPaper/info?id=" + this.ids)
        .then(response => {
          console.log(response);
          this.stuxscg = response.data.info;
          if (!Array.isArray(this.stuxscg.slinfo)) {
            this.stuxscg.slinfo = [];
            return;
          }
          this.stuxscg.slinfo.map(el => {
            return {
              lyjb: el.lyjb,
              yxyz: el.yxyz,
              file: el.file,
              fileList: { name: "佐证", url: el.file }
            };
          });
        });
    }
  },
  computed: {
    computedOrder() {
      if (this.stuxscg.sfdyzz == 1) {
        return 1;
      } else {
        return 2;
      }
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    isStudent() {
      let result = this.$store.state.identity == 1;
      return result;
    },
    computedKh: {
      get() {
        // if (!Array.isArray(this.stuxscg.kh)) {
        //   return ["", ""];
        // }
        let tmpArr = this.stuxscg.kh.split("-");
        if (Array.isArray(tmpArr) && tmpArr.length == 2) {
          return tmpArr;
        } else {
          return [this.stuxscg.kh, ""];
        }
      },
      set(val) {
        this.stuxscg.kh = val.join("-");
        let tmpArr = this.stuxscg.kh.split("-");
        tmpArr = tmpArr.filter(el => el);
        console.log(tmpArr);
      }
    }
  },
  filters: {
    nodeFilter(val) {
      switch (val) {
        case 1:
          return "提交申请";
        case 2:
          return "导师审核";
        case 3:
          return "学院秘书审核";
        case 4:
          return "学院秘书待提交";
        case 5:
          return "研究生院审核";
        default:
          return "";
      }
    },
    dsstatusFilter(sqzt) {
      sqzt = parseInt(sqzt);
      switch (sqzt) {
        case 1:
          return "yes";
        case 2:
          return "back";
        case 0:
          return "back";
      }
    },
    dsztFilter(sqzt) {
      sqzt = parseInt(sqzt);
      switch (sqzt) {
        case 1:
          return "通过";
        case 2:
          return "退回";
        case 0:
          return "不通过";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import "../../style/xscg"; // 必须加分号，不然会报错
@import "../../style/ele1";
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
/deep/ .el-dialog__body {
  text-align: center;
}
// 表格上面部分
.header {
  overflow: hidden;
}
.header-input {
  width: 70%;
}
.left {
  float: left;
}
.right {
  float: right;
}
.container {
  padding: 30px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
  margin-top: 10px;
  overflow: hidden;
}
.slzz-img {
  img {
    display: inline-block;
    margin-right: 20px;
  }
}
.divShadows {
  width: 97%;
  background: rgba(255, 255, 255, 1);
  border-radius: 10px;
  margin: 0 auto;
  margin-top: 1%;
  padding-bottom: 1%;
  box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.1);
  position: relative;
}
.close {
  text-align: center;
  width: 20px;
  height: 20px;
  color: #cccccc;
  font-size: 16px;
  position: absolute;
  right: 22px;
  top: 20px;
  cursor: pointer;
  z-index: 1000;
}
.grid-content {
  font-size: 16px;
  color: #333333;
}
.bg-purple-dark {
  padding-left: 7%;
  margin-top: 30px;
  background: rgba(248, 251, 255, 1);
}
.el-btn {
  padding-left: 60px;
  overflow: hidden;
  margin-bottom: 20px;
}
//  .el-button {
//    overflow: hidden;
//  }
.el-button {
  margin-left: 0px;
}
p {
  display: inline-block;
}
a {
  color: #606266;
  transition: color 0.3s;
  &:hover {
    color: #237ae4;
  }
}
.el-button + .el-button {
  margin-left: 0px;
}
//  日期控件样式
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 100%;
}
.step {
  color: #333;
  .wait {
    margin-right: 15px;
  }
  .yes {
    margin-right: 15px;
  }
  .ing {
    margin-right: 15px;
  }
  .back {
    margin-right: 15px;
  }
  .time {
    // margin-left: 15px;
    color: #909399;
    font-size: 13px;
    margin-left: 0px;
    margin-right: 15px;
  }
  .comment {
    margin-top: 8px;
    color: #333;
    font-size: 13px;
    width: 180px;
    text-overflow: ellipsis;
    overflow: hidden; /** 隐藏超出的内容 **/
  }
}
.yes {
  color: #409eff;
}
.back {
  color: #f56c6c;
}
.step /deep/ .el-step.is-horizontal .el-step__line {
  top: 16px;
}
.step /deep/ .el-step__title.is-success {
  color: #409eff;
}
.step /deep/ .el-step__head.is-success {
  color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-step__head.is-wait {
  color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-step__title.is-wait {
  color: #333;
}
.step /deep/ .el-step__description.is-success {
  color: #409eff;
}
.step /deep/ .el-icon-d-arrow-left:before,
.step /deep/ .el-icon-close:before {
  color: #fff;
  background-color: #f56c6c;
  font-size: 16px;
  border-radius: 50%;
  padding: 4px;
}
.step /deep/ .el-step__head.is-process .el-step__icon.is-text {
  color: #fff;
  background-color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-steps {
  overflow-x: auto;
  padding-bottom: 10px;
}
</style>
<style>
.el-dialog__body {
  padding: 10px;
}
</style>
