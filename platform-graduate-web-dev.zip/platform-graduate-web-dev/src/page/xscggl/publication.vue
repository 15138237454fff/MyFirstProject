<template>
  <div style="width:100%">
    <div class="container" v-show="show">
      <el-row style="margin:0 auto;">
        <el-col :span="24">
          <el-row style="float:right">
            <el-button type="primary" @click="see">查看审核信息</el-button>

            <el-button type="success" @click="addApply" v-if="has('publication:create')">添加</el-button>

            <el-button type="danger" @click="applyChange" v-if="has('publication:update')">修改</el-button>

            <el-button type="warning" @click="handleEdit" v-if="has('publication:shenhe')">审核</el-button>
            <el-dialog title="审核信息" :visible.sync="dialogFormVisible" width="55%" style="margin-top:-5vh">
              <div class="divShadow2" v-show="stuFbzz.dsxm != null">
                <div class="topBlue1">导师审核信息</div>
                <el-form label-width="100px" class="demo-stuFbzz" label-position="left" style="padding-top:40px;">
                  <el-row :gutter="20">
                    <el-col :span="11">
                      <el-form-item label="审核人:">
                        <el-input v-model="stuFbzz.dsxm" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="11">
                      <el-form-item label="审核时间：">
                        <el-input v-model="stuFbzz.dsshsj" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <!-- <el-row :gutter="30">
                    <el-col :span="22">
                      <el-form-item label="审核状态：">
                        <el-input readonly="readonly" :value="stuFbzz.dsshzt==1?'通过':'不通过'"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row> -->
                  <el-row :gutter="20">
                    <el-col :span="22">
                      <el-form-item label="审核意见：">
                        <el-input type="textarea" v-model="stuFbzz.dsshyj" :rows="3" placeholder="" readonly="readonly">
                        </el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div class="divShadow2" v-show="stuFbzz.xyshr != null">
                <div class="topBlue1">学院审核信息</div>
                <el-form label-width="100px" class="demo-stuFbzz" label-position="left" style="padding-top:40px;">
                  <el-row :gutter="20">
                    <el-col :span="11">
                      <el-form-item label="审核人:">
                        <el-input v-model="stuFbzz.xyshr" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="11">
                      <el-form-item label="审核时间：">
                        <el-input v-model="stuFbzz.xyshsj" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <!-- <el-row :gutter="30">
                    <el-col :span="22">
                      <el-form-item label="审核状态：">
                        <el-input readonly="readonly" :value="stuFbzz.xyshzt==1?'通过':'不通过'"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row> -->
                  <el-row :gutter="20">
                    <el-col :span="22">
                      <el-form-item label="审核意见：">
                        <el-input type="textarea" v-model="stuFbzz.xyshyj" :rows="3" placeholder="" readonly="readonly">
                        </el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div class="divShadow2" v-show="stuFbzz.xxshr != null">
                <div class="topBlue1">学校审核信息</div>
                <el-form label-width="100px" class="demo-stuFbzz" label-position="left" style="padding-top:40px;">
                  <el-row :gutter="20">
                    <el-col :span="11">
                      <el-form-item label="审核人:">
                        <el-input v-model="stuFbzz.xxshr" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span="11">
                      <el-form-item label="审核时间：">
                        <el-input v-model="stuFbzz.xxshsj" readonly="readonly"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <!-- <el-row :gutter="30">
                    <el-col :span="22">
                      <el-form-item label="审核状态：">
                        <el-input readonly="readonly" :value="stuFbzz.xxshzt==1?'通过':'不通过'"></el-input>
                      </el-form-item>
                    </el-col>
                  </el-row> -->
                  <el-row :gutter="20">
                    <el-col :span="22">
                      <el-form-item label="审核意见：">
                        <el-input type="textarea" v-model="stuFbzz.xxshyj" :rows="3" placeholder="" readonly="readonly">
                        </el-input>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
              </div>
            </el-dialog>
          </el-row>
        </el-col>
      </el-row>
      <el-table ref="moviesTable" :data="page.slice((currentPage-1)*pageSize,currentPage*pageSize)" @row-click="clickRow" tooltip-effect="dark" style="margin:0 auto;margin-top:5px;text-align:center" @selection-change="handleSelectionChange" border>
        <el-table-column type="selection" width="55" align="center">
        </el-table-column>
        <el-table-column label="序号" type="index" :index="indexMethod" align="center" width="80">
        </el-table-column>
        <el-table-column prop="zzmc" label="著作名称" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.zzmc }}</template>
        </el-table-column>
        <el-table-column prop="zzlx" label="著作类型" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.zzlx }}</template>
        </el-table-column>
        <el-table-column prop="cbzt" label="出版状态" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.cbzt }}</template>
        </el-table-column>
        <el-table-column prop="shzt" label="审核状态" show-overflow-tooltip align="center">
          <template slot-scope="scope">{{ scope.row.shzt === '0' ? '导师审核中' :scope.row.shzt === '1'?'导师审核不通过':scope.row.shzt === '2'?'学院待审' :scope.row.shzt === '3'?'不通过':scope.row.shzt === '4'?'审核通过':scope.row.shzt === '5'?'学校退回' : scope.row.shzt === '6'? '退回':''}}</template>
        </el-table-column>
      </el-table>
      <div class="block" style="text-align:center;margin-top:30px">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 50]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="page.length">
        </el-pagination>
      </div>
    </div>
    <!-- 添加 -->
    <div v-show="!show">
      <el-form :model="stuFbzz" :rules="rules" ref="stuFbzz" label-width="177px" class="demo-stuFbzz" label-position="left">
        <div class="divShadow" style="padding-bottom: 10px;">
          <div class="topBlue">填写提示</div>
          <h4 style="color:red;padding-top:50px;"><i>{{dict.message}}</i></h4>
        </div>
        <div class="divShadow">
          <div class="topBlue">关键信息</div>
          <el-row :gutter="30" style="padding-top:20px;">
            <el-col :span="11">
              <el-form-item label="著作名称：" prop="zzmc">
                <el-input v-model="stuFbzz.zzmc"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="著作类型：" prop="zzlx">
                <el-select v-model="stuFbzz.zzlx" placeholder="请选择" style="width:100%">
                  <el-option v-for="(item,index) in dict.typeList" :label="item.name" :value="item.name" :key="item+index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="出版状态:" prop="cbzt">
                <el-select v-model="stuFbzz.cbzt" placeholder="请选择" style="width:100%">
                  <el-option v-for="(item,index) in dict.statusList" :label="item.name" :value="item.name" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="备注:" prop="bz">
                <el-input v-model="stuFbzz.bz"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="排序/总人数：" prop="px">
                <el-row>
                  <el-col span="5">
                    <el-input type="number" v-model="stuFbzz.px" max="10" min="1"></el-input>
                  </el-col>
                  <el-col span="6">
                    <el-input type="number" v-model="stuFbzz.zs" max="10" min="1"></el-input>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="是否是第一作者：" prop="sfdyzz">
                <el-radio-group v-model="stuFbzz.sfdyzz">
                  <el-radio :label="1">是</el-radio>
                  <el-radio :label="2">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="11" v-if="stuFbzz.sfdyzz == '2'">
              <el-form-item label="导师是否为第一作者:" prop="dsdyzz">
                <el-radio-group v-model="stuFbzz.dsdyzz">
                  <el-radio :label="1">是</el-radio>
                  <el-radio :label="2">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="divShadow" v-if="stuFbzz.cbzt=='已出版'">
          <div class="topBlue">出版信息</div>
          <el-row :gutter="30" style="padding-top:40px;">
            <el-col :span="11">
              <el-form-item label="出版社：" prop="cbs">
                <el-input v-model="stuFbzz.cbs"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="出版时间：" prop="cbsj">
                <el-date-picker v-model="stuFbzz.cbsj" type="date" placeholder="选择日期" value-format="yyyy-MM-dd">
                </el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="出版级别:" prop="cbjb">
                <el-select v-model="stuFbzz.cbjb" placeholder="请选择" style="width:100%">
                  <el-option v-for="(item,index) in dict.devList" :label="item.name" :value="item.name" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="ISBN：" prop="isbn">
                <el-input v-model="stuFbzz.isbn"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="印刷次数：" prop="yscs">
                <el-input v-model="stuFbzz.yscs"></el-input>
              </el-form-item>
            </el-col>
          </el-row>

        </div>
        <div class="divShadow">
          <div class="topBlue">项目资助信息</div>

          <el-row :gutter="30" style="padding-top:40px;">
            <el-col :span="11">
              <el-form-item label="资助来源名称：" prop="xmzzmc">
                <el-input v-model="stuFbzz.xmzzmc"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="资助号码：" prop="zzhm">
                <el-input v-model="stuFbzz.zzhm">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="资助单位:" prop="zzdw">
                <el-input v-model="stuFbzz.zzdw"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30" v-if="showCheck">
            <el-col :span="11">
              <el-form-item label="附件:" prop="fj">
                <el-upload class="upload-demo" :action="baseUrl2" name="file" :on-preview="handlePreview" :on-remove="handleRemove" :before-remove="beforeRemove" :on-success="handleSuccess" multiple :limit="1" :on-exceed="handleExceed" :file-list="fileList">
                  <el-button slot="trigger" size="small" class="add">
                    <div class="img">
                      <img src="../../assets/image/attachment.png" alt style="width:100%;height:100%;" />
                    </div>
                    <span class="append">添加附件</span>
                  </el-button>
                  <div slot="tip" class="el-upload__tip">多个文件，请打压缩包上传！</div>
                </el-upload>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-if="!showCheck">
            <el-col :span="11">
              <el-form-item label="附件:" prop="fj">
                <el-button @click="download">下载附件</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="bottomBox" style="text-align:center;" v-if="showCheck">
          <el-button type="primary" class="reset" @click="close">取消</el-button>
          <el-button type="primary" class="reset" @click="submit">提交</el-button>
        </div>
        <div class="divShadow" v-if="!showCheck">
          <div class="topBlue">审核意见</div>
          <el-row style="margin-left:56px;padding-top:50px">
            <el-col :span="22">
              <el-input type="textarea" v-model="textarea" :rows="8" placeholder="请输入审核意见："></el-input>
            </el-col>
          </el-row>

          <div class="bottomBox" style="text-align:center;">
            <el-button type="primary" class="reset" @click="close">取消</el-button>
            <el-button type="primary" class="reset" @click="adopt()">通过</el-button>
            <el-button type="primary" class="reset" @click="nothrough()">不通过</el-button>
          </div>
        </div>
      </el-form>
    </div>
    <xs-message ref="XsMessage"></xs-message>
  </div>
</template>
<script>
import XsMessage from '@/components/message.vue';
export default {
  inject: ['reload'],
  components: {
    XsMessage
  },
  data() {
    return {
      show: true, //展示列表开关
      fileList: [], //上传文件列表展示
      alist: {},
      showCheck: false,
      page: [],
      currentPage: 1,
      pageSize: 5,
      ids: "",
      id: "",
      totalItems: 0,
      textarea: "",
      dict: {
        typeList: [],
        statusList: null,
        devList: [],
        message: ""
      },
      dialogFormVisible: false,
      stuFbzz: {
        fj: '',
      },
      rules: {
        zzmc: [{          required: true, message: "请填写著作名称", trigger: "blur", validator: (rule, value, callback) => {
            if (!this.isEmpty(this.stuFbzz.zzmc)) {
              callback(new Error("请填写排序"));
            } else {
              callback();
            }
          }        }],
        zzlx: [{ required: true, message: "请选择著作类型", trigger: "change" }],
        cbzt: [{ required: true, message: "请选择出版状态", trigger: "change" }],
        px: [{          required: true, trigger: 'blur',
          validator: (rule, value, callback) => {

            if (!this.isEmpty(this.stuFbzz.px)) {
              callback(new Error("请填写排序"));
            } else if (!this.isEmpty(this.stuFbzz.zs)) {
              callback(new Error('请填写总人数'));
            } else {
              callback();
            }
          }
        }],
        sfdyzz: [{ required: true, message: '请选择是否第一作者', trigger: 'blur' }],
        dsdyzz: [{ required: true, message: '请选择是否导师作者', trigger: 'blur' }],
        cbs: [{ required: true, message: '请填写出版社名称', trigger: 'blur' }],
        cbsj: [{ required: true, message: '请选择出版时间', trigger: 'blur' }],
        cbjb: [{ required: true, message: '请选择出版级别', trigger: 'change' }],
        isbn: [{ required: true, message: '请填写ISBN', trigger: 'blur' }],
        yscs: [{ required: true, message: '请填写印刷次数', trigger: 'blur' }],
        fj: [
          {
            required: true,
            trigger: 'blur',
            validator: (rule, value, callback) => {
              if (this.isEmpty(this.stuFbzz.fj)) {
                callback();
              } else {
                callback(new Error('请上传附件'));
              }
            }
          }
        ]
      }
    }

  },
  mounted() {
    //进入页面，加载申请列表
    this.loadTable();
    //加载参数
    this.loadMessage();
  },
  methods: {
    //参数信息
    loadMessage() {
      //著作提醒
      this.loadDict(this.dict, 'message', 'XS-04435');
      //著作出版状态
      this.loadDict(this.dict, 'statusList', 'XS-34032');
      //著作类型
      this.loadDict(this.dict, 'typeList', 'XS-14344');
      //著作出版社级别
      this.loadDict(this.dict, 'devList', 'XS-03733');
    },
    //加载列表
    loadTable() {
      this.$http
        .post(this.$server.glourl + "stufbzz/FbzzMenu")
        .then(response => {
          this.page = response.data.stufbzz
          this.alist = response.data.xjxxMap
        });
    },
    //表格方法
    //点击列表选中
    clickRow(row) {
      this.$refs.moviesTable.toggleRowSelection(row);
    },
    //列表选择改变事件
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.ids = "";
      } else {
        this.ids = selection[0].id;
        this.shzt = selection[0].shzt;
      }
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val;
      this.loadTable();
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      this.loadTable();
    },
    //列表序号
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1;
    },
    //下载附件
    download() {
      location.href = this.stuFbzz.fj;
    },
    // 文件上传成功时的钩子
    handleSuccess(response, file, fileList) {
      this.stuFbzz.fj = response.url;
    },
    //查看审核信息
    see() {
      if (this.ids == null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      } else {
        this.$http
          .post(this.$server.glourl + "stufbzz/info/" + this.ids)
          .then(response => {
            this.stuFbzz = response.data.stuFbzz
            this.dialogFormVisible = true;
            if (this.stuFbzz.dsxm == null) {
              this.dialogFormVisible = false;
              this.$message({
                message: "无审核信息！",
                type: "error"
              });
            }
          });
      }
    },
    //添加按钮函数
    addApply() {
      this.show = false;
      this.showCheck = true;
      this.stuFbzz = {};
      // this.$refs["stuFbzz"].resetFields();
      this.stuFbzz.xsxm = this.alist.xm;
      this.stuFbzz.xh = this.alist.xh;
      this.stuFbzz.xymc = this.alist.yxsh;
      //this.$refs.XsMessage.showMessage(this.dict.message);
      // this.xscgMessage(this.dict.message);
    },
    //关闭添加页面
    close() {
      this.show = true;
      this.loadTable();
    },
    //点击审核
    handleEdit(index, row) {
      if (this.ids == null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      if (this.shzt != '0') {
        this.$message({
          message: "当前数据不可审核！",
          type: "error"
        });
        return;
      }
      this.show = false;
      this.showCheck = false;
      this.$http
        .post(this.$server.glourl + "stufbzz/info/" + this.ids)
        .then(response => {
          this.stuFbzz = response.data.stuFbzz
        });
    },
    //点击通过
    adopt() {
      this.$http
        .get(this.$server.glourl + "stufbzz/TutorCheck", {
          params: {
            id: this.stuFbzz.id,
            suggestion: this.textarea,
            shenhe: "1"
          }
        })
        .then(res => {
          if (res.data.msg == 1) {
            this.$message({
              message: "抱歉，该数据已被审核，不可操作！",
              type: "error"
            });
          } else {
            this.show = true;
            this.loadTable();
            this.$message({
              message: "审核成功！",
              type: "success"
            });
          }
        });
    },
    //点击不通过
    nothrough() {
      if (!this.isEmpty(this.textarea)) {
        this.$message({
          message: "请输入审核意见！",
          type: "error"
        });
        return;
      }
      this.$http
        .get(this.$server.glourl + "stufbzz/TutorCheck", {
          params: {
            id: this.stuFbzz.id,
            suggestion: this.textarea,
            shenhe: "2"
          }
        })
        .then(res => {
          if (res.data.msg == 1) {
            this.$message({
              message: "抱歉，该数据已被审核，不可操作！",
              type: "error"
            });
          } else {
            this.show = true;
            this.loadTable();
            this.$message({
              message: "审核成功！",
              type: "success"
            });
          }
        });
    },
    //申请信息提交事件
    submit: function () {
      this.$refs['stuFbzz'].validate(valid => {
        if (valid) {
          if (!this.isEmpty(this.stuFbzz.id)) {
            this.submitInfo();
          } else {
            this.changeSubmit();
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    submitInfo: function () {
      this.$http
        .post(this.$server.glourl + "stufbzz/save", this.stuFbzz)
        .then(res => {
          if (res.data.code == 0) {
            this.$message({
              message: "申请信息提交成功，请等待审核！",
              type: "success"
            });
            this.show = true;
            this.loadTable();
          }
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    // 修改申请表单
    applyChange() {
      if (this.ids == null || this.ids == '') {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      }
      else if (this.shzt != 6) {
        this.$message({
          message: "只能修改退回的信息！",
          type: "error"
        });
      }
      else {
        this.$http
          .post(this.$server.glourl + "stufbzz/info/" + this.ids)
          .then(response => {
            this.$refs["stuFbzz"].resetFields();
            this.stuFbzz = response.data.stuFbzz
          });
        this.show = false;
        this.showCheck = true;
      }
    },
    // 修改申请表单提交
    changeSubmit() {
      this.$http
        .post(this.$server.glourl + "stufbzz/modify", this.stuFbzz)
        .then(response => {
          if (response.data.code == 0) {
            this.$message({
              message: "修改成功！",
              type: "success"
            })
            // this.reload()
            this.show = true
            this.loadTable()
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../style/xscg"; //必须加分号，不然会报错
@import "../../style/ele1";
.el-form-item {
  margin-left: 56px;
}
.divShadows {
  width: 97%;
  background: rgba(255, 255, 255, 1);
  border-radius: 10px;
  margin: 0 auto;
  margin-top: 1%;
  padding-bottom: 1%;
  box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.1);
  position: relative;
}
.container {
  padding: 30px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
  margin-top: 10px;
  overflow: hidden;
}
.close {
  text-align: center;
  width: 20px;
  height: 20px;
  color: #cccccc;
  font-size: 16px;
  position: absolute;
  right: 22px;
  top: 20px;
  cursor: pointer;
  z-index: 1000;
}
.el-btn {
  margin-top: 30px;
  /* margin-left: 56px; */
  margin-bottom: 20px;
}
.el-button--small,
.el-button--small.is-round {
  /* margin-left: 5px; */
  padding: 5px 15px 5px 15px;
}
.el-button {
  margin-left: 0px;
}
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 100%;
}
.el-button + .el-button {
  margin-left: 0px;
}
</style>
