<template>
  <div style="width:100%;padding-top:20px;">
    <div class="container" v-show="show">
      <el-row style="margin:0 auto;">
        <el-col :span="24">
          <el-row style="float:right">
            <el-button type="primary" @click="see">查看审核信息</el-button>
            <el-button type="primary" @click="clickDetail">查看详情</el-button>
            <el-button
              type="success"
              @click="addApply"
              v-if="has('patent:save')"
              >添加</el-button
            >
            <el-button
              type="danger"
              @click="applyChange"
              v-if="has('patent:update')"
              >修改</el-button
            >
            <el-button
              type="warning"
              @click="handleEdit"
              v-if="has('patent:audit')"
              >审核</el-button
            >
            <el-button type="danger" @click="clickDelete">删除</el-button>
            <el-dialog
              title="审核信息"
              :visible.sync="dialogFormVisible"
              width="500px"
              style="margin-top:-5vh"
            >
              <div style="padding:20px;" class="step">
                <el-steps direction="vertical">
                  <el-step
                    :title="item.node | nodeFilter"
                    :description="item.comment"
                    v-for="(item, index) of aduitHistoryList"
                    :key="index"
                  >
                    <div slot="title" class="text-ellipsis">
                      <span>{{ item.node | nodeFilter }}</span>
                    </div>

                    <div slot="description">{{ item.userName }}</div>
                    <span slot="description" class="time">{{
                      item.createTime
                    }}</span>
                    <span
                      slot="description"
                      :class="item.status | dsstatusFilter"
                      class="status"
                      >{{ item.status | dsztFilter }}</span
                    >
                    <div slot="description" class="comment" v-if="item.comment">
                      {{ item.comment }}
                    </div>
                    <i
                      v-if="item.status === null"
                      slot="icon"
                      class="el-icon-check"
                    ></i>
                    <i
                      v-else-if="item.status == 1"
                      slot="icon"
                      class="el-icon-check"
                    ></i>
                    <i
                      v-else-if="item.status == 2"
                      slot="icon"
                      class="el-icon-d-arrow-left"
                    ></i>
                    <i
                      v-else-if="item.status == 0"
                      slot="icon"
                      class="el-icon-close"
                    ></i>
                  </el-step>
                </el-steps>
              </div>
              <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="dialogFormVisible = false"
                  >确 定</el-button
                >
              </div>
            </el-dialog>
          </el-row>
        </el-col>
      </el-row>
      <el-table
        ref="moviesTable"
        :data="page"
        @row-click="clickRow"
        tooltip-effect="dark"
        @row-dblclick="handleDblclick"
        style="margin:0 auto;margin-top:5px;text-align:center"
        @selection-change="handleSelectionChange"
        border
      >
        <el-table-column
          type="selection"
          width="55"
          align="center"
        ></el-table-column>
        <el-table-column
          label="序号"
          type="index"
          :index="indexMethod"
          align="center"
          width="80"
        ></el-table-column>
        <el-table-column
          prop="id"
          label="id"
          type="index"
          align="center"
          v-if="show4"
        >
          <template slot-scope="scope">{{ scope.row.id }}</template>
        </el-table-column>
        <el-table-column
          prop="zlh"
          label="专利号"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">{{ scope.row.zlh }}</template>
        </el-table-column>
        <el-table-column
          prop="zlmc"
          label="专利名称"
          show-overflow-tooltip
          align="center"
        >
          <template slot-scope="scope">{{ scope.row.zlmc }}</template>
        </el-table-column>
        <el-table-column
          prop="zllx"
          label="专利类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">{{ scope.row.zllx }}</template>
        </el-table-column>
        <el-table-column
          prop="xsxm"
          label="申请人"
          show-overflow-tooltip
          align="center"
        >
        </el-table-column>
        <el-table-column
          prop="shzt"
          label="审核状态"
          show-overflow-tooltip
          align="center"
        >
          <template slot-scope="scope">{{
            scope.row.shzt == "0"
              ? "不通过"
              : scope.row.shzt == "1"
              ? "通过"
              : scope.row.shzt == "2"
              ? "退回"
              : scope.row.shzt == "3"
              ? "审核中"
              : ""
          }}</template>
        </el-table-column>
        <el-table-column
          prop="node"
          label="当前环节"
          show-overflow-tooltip
          align="center"
        >
          <template slot-scope="scope">{{
            scope.row.node == "2"
              ? "学院秘书审核"
              : scope.row.node == "3"
              ? "学院秘书审核"
              : scope.row.node == "4"
              ? "学院秘书待提交"
              : scope.row.node == "5"
              ? "研究生院审核"
              : ""
          }}</template>
        </el-table-column>
      </el-table>
      <div class="block" style="text-align:center;margin-top:30px">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[5, 10, 20, 50]"
          :page-size="pageSize"
          :total="totalCount"
          layout="total, sizes, prev, pager, next, jumper"
        ></el-pagination>
      </div>
    </div>
    <el-dialog :visible.sync="dialogVisible">
      <img width="100%" :src="dialogImageUrl" />
    </el-dialog>
    <!-- 添加 -->
    <div v-show="!show">
      <div class="divShadow" style="padding-bottom: 10px;">
        <div class="topBlue">填写提示</div>
        <h4 style="color:red;padding-top:50px;">
          <i>{{ dict.message }}</i>
        </h4>
      </div>
      <div class="divShadow">
        <div class="topBlue">关键信息</div>
        <el-form
          :model="stuZljs"
          :rules="rules"
          ref="stuZljs"
          label-width="177px"
          class="demo-stuZljs"
          label-position="left"
          style="padding-top:50px;"
        >
          <el-row
            :gutter="30"
            v-if="!isStudent && showCheck && stuZljs.shzt != 3"
          >
            <el-col :span="18">
              <el-form-item label="学生姓名" required prop="xh">
                <el-select
                  v-model="stuZljs.xh"
                  placeholder="请选择"
                  style="width:50%"
                  filterable
                  @change="handleXsChange"
                >
                  <el-option
                    v-for="(item, index) in xsList"
                    :key="index"
                    :label="`${item.xsxm}(${item.xh})`"
                    :value="item.xh"
                    :disabled="!showCheck"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="专利号：" prop="zlh">
                <el-input
                  v-model="stuZljs.zlh"
                  :readonly="!showCheck"
                  placeholder="例如：LOC(8) Cl. 17-03"
                >
                  <el-button
                    slot="append"
                    icon="el-icon-search"
                    @click="queryPatent"
                  ></el-button>
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="状态：" prop="zt">
                <el-select
                  v-model="stuZljs.zt"
                  placeholder="请选择"
                  style="width:100%"
                >
                  <el-option
                    v-for="(item, index) in dict.statusList"
                    :label="item.name"
                    :value="item.name"
                    :key="index"
                    :disabled="!showCheck"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="专利名称：" prop="zlmc">
                <el-input
                  v-model="stuZljs.zlmc"
                  :readonly="!showCheck"
                  placeholder="例如：基于笔劲识别的验证系统2011101499189"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="专利类型：" prop="zllx">
                <el-select
                  v-model="stuZljs.zllx"
                  placeholder="请选择"
                  style="width:100%"
                >
                  <el-option
                    v-for="(item, index) in dict.typeList"
                    :label="item.name"
                    :value="item.name"
                    :key="index"
                    :disabled="!showCheck"
                  ></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="申请时间：" prop="sqsj">
                <el-date-picker
                  v-model="stuZljs.sqsj"
                  type="date"
                  placeholder="选择日期"
                  :readonly="!showCheck"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item label="排序/总人数：" prop="px">
                <el-row>
                  <el-col :span="12">
                    <!-- <el-input
                      type="number"
                      v-model="stuZljs.px"
                      :max="stuZljs.zs"
                      :min="computedOrder"
                      @input="handlePmChange"
                      :readonly="!showCheck || stuZljs.sfdyzz == 1"
                    ></el-input> -->
                    <el-input-number
                      v-model="stuZljs.px"
                      controls-position="right"
                      @change="handlePmChange"
                      :min="computedOrder"
                      :max="stuZljs.zs"
                      :precision="0"
                      :disabled="!showCheck || stuZljs.sfdyzz == 1"
                    ></el-input-number>
                  </el-col>
                  <el-col :span="12">
                    <!-- <el-input
                      type="number"
                      v-model="stuZljs.zs"
                      :max="10"
                      :min="stuZljs.px"
                      :readonly="!showCheck"
                    ></el-input> -->
                    <el-input-number
                      v-model="stuZljs.zs"
                      controls-position="right"
                      :min="stuZljs.px"
                      :precision="0"
                      :disabled="!showCheck"
                    ></el-input-number>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item
                label="申请号："
                prop="sqh"
                v-if="stuZljs.zt == '公开'"
              >
                <el-input
                  v-model="stuZljs.sqh"
                  :readonly="!showCheck"
                ></el-input>
              </el-form-item>
              <el-form-item
                label="授权号："
                prop="sqh"
                v-if="stuZljs.zt == '授权'"
              >
                <el-input
                  v-model="stuZljs.sqh"
                  :readonly="!showCheck"
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item
                label="公开时间："
                prop="gbsj"
                v-if="stuZljs.zt == '公开'"
              >
                <el-date-picker
                  v-model="stuZljs.gbsj"
                  type="date"
                  placeholder="选择日期"
                  :readonly="!showCheck"
                ></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="11">
              <el-form-item
                label="授权公告日期："
                prop="sqtime"
                v-if="stuZljs.zt == '授权'"
              >
                <el-date-picker
                  v-model="stuZljs.sqtime"
                  type="date"
                  placeholder="选择日期"
                  :readonly="!showCheck"
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="是否是第一作者：" prop="sfdyzz">
                <el-radio-group
                  v-model="stuZljs.sfdyzz"
                  @change="handleFirstChange"
                >
                  <el-radio :label="1" :disabled="!showCheck">是</el-radio>
                  <el-radio :label="2" :disabled="!showCheck">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="11" v-if="stuZljs.sfdyzz == '2'">
              <el-form-item label="是否是导师第一作者：" prop="dsdyzz">
                <el-radio-group v-model="stuZljs.dsdyzz">
                  <el-radio :label="1" :disabled="!showCheck">是</el-radio>
                  <el-radio :label="2" :disabled="!showCheck">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30">
            <el-col :span="11">
              <el-form-item label="专利所有单位：" prop="zlsydw">
                <el-input
                  v-model="stuZljs.zlsydw"
                  :readonly="!showCheck"
                  placeholder="例如：浙江工业大学"
                ></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="30" v-if="showCheck">
            <el-col :span="11">
              <el-form-item label="佐证:" prop="zz">
                <!-- <el-upload
                  class="upload-demo"
                  :action="baseUrls"
                  name="file"
                  ref="fj"
                  :on-remove="handleRemove"
                  :on-success="handleSuccess"
                  @on-preview="handlePreview"
                  multiple
                  :limit="1"
                  :file-list="fileList"
                >
                  <el-button slot="trigger" size="small" class="add">
                    <div class="img">
                      <img
                        src="../../assets/image/attachment.png"
                        alt
                        style="width:100%;height:100%;"
                      />
                    </div>
                    <span class="append">添加附件</span>
                  </el-button>
                  <div slot="tip" class="el-upload__tip">
                    多个文件，请打压缩包上传！
                  </div>
                </el-upload> -->
                <my-upload
                  :url="baseUrls"
                  :info="this.stuZljs"
                  pointer="fj"
                  ref="fj"
                  :onSuccess="handleSuccess"
                  :onRemove="handleRemove"
                  @on-preview="handlePreview"
                  :imgUrl="stuZljs.fj"
                  :limit="1"
                />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-else>
            <el-col :span="11">
              <el-form-item label="附件:" prop="zz">
                <img
                  v-if="stuZljs.fj"
                  :src="stuZljs.fj"
                  class="avatar"
                  @click="clickPreview(stuZljs.fj)"
                />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="bottomBox" style="text-align:center;" v-if="isDetail">
        <el-button type="primary" class="reset" @click="close">取消</el-button>
      </div>
      <div
        class="bottomBox"
        style="text-align:center;"
        v-else-if="showCheck || isStudent"
      >
        <el-button type="primary" class="reset" @click="close">取消</el-button>
        <el-button type="primary" class="reset" @click="submit">提交</el-button>
      </div>

      <div class="divShadow" v-else-if="!showCheck && !isStudent">
        <div class="divShadow">
          <div class="topBlue">审核意见</div>
          <el-row style="margin-left:56px;padding-top:50px">
            <el-col :span="22">
              <el-input
                type="textarea"
                v-model="textarea"
                :rows="8"
                placeholder="请输入审核意见："
              ></el-input>
            </el-col>
          </el-row>
        </div>
        <div class="bottomBox" style="text-align:center;">
          <el-button type="primary" class="reset" @click="close"
            >取消</el-button
          >
          <el-button type="primary" class="reset" @click="adopt(1)"
            >通过</el-button
          >
          <el-button type="primary" class="reset" @click="adopt(0)"
            >不通过</el-button
          >
        </div>
      </div>
      <xs-message ref="XsMessage"></xs-message>
    </div>
  </div>
</template>
<script>
import XsMessage from "@/components/message.vue";
import myUpload from "@/components/myUpload.vue";
export default {
  components: {
    myUpload,
    XsMessage
  },
  inject: ["reload"],
  data() {
    return {
      show: true, // 展示列表开关
      showCheck: false,
      isDetail: false,
      // isStudent: false,
      fileList: [], // 上传文件列表展示
      messageId: "XS-48008",
      page: [],
      currentPage: 1,
      pageSize: 5,
      dialogVisible: false,
      dialogImageUrl: "",
      show4: false,
      isUpdate: false,
      ids: "",
      id: "",
      dict: {
        statusList: [],
        typeList: [],
        message: ""
      },
      totalCount: 0,
      node: null,
      aduitHistoryList: [],
      xsList: [],
      totalItems: 0,
      textarea: "",
      dialogFormVisible: false,
      stuZljs: {
        zzxx: [
          {
            num: 1,
            editFlag: false
          }
        ],
        fj: ""
      },
      rules: {
        xh: [{ message: "请选择学生", required: true }],
        zllx: [
          { required: true, message: "请填写专利类型", trigger: "change" }
        ],
        zlh: [{ required: true, message: "请填写专利号", trigger: "blur" }],
        sqh: [{ required: true, message: "请填写申请号", trigger: "blur" }],
        zlmc: [{ required: true, message: "请填写专利名称", trigger: "blur" }],
        sqsj: [{ required: true, message: "请填写申请时间", trigger: "blur" }],
        zt: [{ required: true, message: "请选择状态", trigger: "change" }],
        px: [
          {
            required: true,
            trigger: "blur",
            validator: (rule, value, callback) => {
              if (!this.isEmpty(this.stuZljs.px)) {
                callback(new Error("请填写排序"));
              } else if (!this.isEmpty(this.stuZljs.zs)) {
                callback(new Error("请填写总人数"));
              } else {
                callback();
              }
            }
          }
        ],
        gbsj: [{ required: true, message: "请填写公开时间", trigger: "blur" }],
        sqtime: [
          { required: true, message: "请填写授权时间", trigger: "blur" }
        ],
        zlsydw: [
          { required: true, message: "请填写专利所有单位", trigger: "blur" }
        ],
        sfdyzz: [
          { required: true, message: "请选择是否第一作者", trigger: "blur" }
        ],
        dsdyzz: [
          { required: true, message: "请选择是否导师作者", trigger: "blur" }
        ],
        fj: [
          {
            required: true,
            trigger: "blur",
            validator: (rule, value, callback) => {
              if (this.isEmpty(this.stuZljs.fj)) {
                callback();
              } else {
                callback(new Error("请上传附件"));
              }
            }
          }
        ]
      }
    };
  },
  mounted() {
    // 进入页面，加载申请列表
    this.loadTable();
    // 查询可维护信息
    this.loadMessage();
  },
  methods: {
    handleDblclick(row) {
      this.ids = row.id;
      this.clickDetail();
    },
    clickDetail() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      this.isDetail = true;
      this.show = false;
      this.showCheck = false;
      this.dataCallBack();
    },
    clickPreview(url) {
      console.log(url);
      this.dialogImageUrl = url;
      this.dialogVisible = true;
    },
    clickDelete() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      if (this.shzt != "0" && this.shzt != "2") {
        this.$message({
          message: "当前数据不可删除！",
          type: "error"
        });
        return;
      }
      this.$confirm("此操作将删除该记录, 是否继续?", "删除", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "error"
      }).then(this.handleDelete);
    },
    handleDelete() {
      this.$http
        .get(this.$server.glourl + "/patent/delete", {
          params: { id: this.ids }
        })
        .then(res => {
          let data = res.data;
          console.log(data);
          if (data.code != 0) {
            this.$message.error(data.msg);
            return;
          }
          this.$message.success("删除成功");
          this.loadTable();
        });
    },
    handleXsChange(val) {
      let tmpObj = this.xsList.find(el => el.xh == val);
      if (!tmpObj) {
        return;
      }
      this.stuZljs.xsxm = tmpObj.xsxm;
      this.stuZljs.xymc = tmpObj.yxsh;
    },
    requireXsList() {
      this.$http
        .get(this.$server.glourl + "/academicPaper/student/list")
        .then(res => {
          let data = res.data;
          console.log(data);
          if (data.code != 0) {
            return;
          }
          this.xsList = data.list;
        });
    },
    loadMessage() {
      // 专利类型
      this.loadDict(this.dict, "typeList", "XS-54779");
      // 提示信息
      this.loadDict(this.dict, "message", "XS-48008");
      // 专利状态
      this.loadDict(this.dict, "statusList", "XS-35102");
    },
    // 查询专利信息
    queryPatent() {
      if (this.stuZljs.zlh === null || this.stuZljs.zlh == "") {
        this.infoNotice("请输入正确的专利号");
        return;
      }
      this.$http
        .get(this.$server.glourl + "stuzljs/search", {
          params: {
            patentCode: this.stuZljs.zlh
          }
        })
        .then(response => {
          if (response.data.code == 0) {
            var info = response.data.info;
            this.$notify({
              title: "消息",
              message: "查询成功！",
              type: "success"
            });
            Object.keys(info).forEach((key, i, v) => {
              this.$set(this.stuZljs, key, info[key]);
            });
          } else {
            this.infoNotice(response.data.msg);
            this.stuZljs = Object.assign({}, this.stuZljs, {
              xsxm: this.userInfo.xsxm,
              xh: this.userInfo.xh,
              xymc: this.userInfo.yxsh,
              zt: "公开",
              sfdyzz: 2
            });
          }
        });
    },
    // 加载列表
    loadTable() {
      this.$http
        .get(this.$server.glourl + "/patent/serve/list", {
          params: {
            limit: this.pageSize,
            page: this.currentPage,
            sidx: "create_time",
            order: "desc"
          }
        })
        .then(response => {
          this.page = response.data.page.list;
          this.totalCount = response.data.page.totalCount;
        });
    },
    // 表格方法
    // 点击列表选中
    clickRow(row) {
      this.$refs.moviesTable.toggleRowSelection(row);
    },
    // 列表选择改变事件
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.ids = "";
        this.shzt = "";
        this.node = null;
        this.isUpdate = false;
      } else {
        this.ids = selection[0].id;
        this.shzt = selection[0].shzt;
        this.node = selection[0].node;
        this.isUpdate = selection[0].update;
      }
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val;
      this.loadTable();
    },
    // 改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      this.loadTable();
    },
    // 列表序号
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1;
    },
    handleFirstChange(val) {
      if (val == 1) {
        this.$set(this.stuZljs, "px", 1);
      } else if (val == 2 && this.stuZljs.px == 1) {
        this.stuZljs.px = 2;
      }
      if (parseInt(this.stuZljs.zs) < parseInt(this.stuZljs.px)) {
        this.stuZljs.zs = this.stuZljs.px;
      }
    },
    handlePmChange(val) {
      val = parseInt(val);
      let zs = parseInt(this.stuZljs.zs);
      if (val > zs) {
        this.stuZljs.zs = val;
      }
    },
    // 查看审核信息
    see() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      } else {
        this.$http
          .get(this.$server.glourl + "/academicPaper/history", {
            params: {
              genre: 2,
              id: this.ids
            }
          })
          .then(response => {
            if (response.data.code != 0) {
              this.$message({
                message: response.data.msg,
                type: "error"
              });
              return;
            }
            this.aduitHistoryList = response.data.list.reverse();
            this.dialogFormVisible = true;
          });
      }
    },
    // 添加按钮函数
    addApply() {
      this.show = false;
      this.showCheck = true;
      this.$refs["stuZljs"].resetFields();
      if (this.isStudent) {
        this.stuZljs = {
          xsxm: this.userInfo.xsxm,
          xh: this.userInfo.xh,
          xymc: this.userInfo.yxsh,
          zt: "公开",
          sfdyzz: 2
        };
      } else {
        this.requireXsList();
        this.stuZljs = {
          xsxm: "",
          xh: "",
          xymc: "",
          zt: "公开",
          sfdyzz: 2
        };
      }
      console.log(this.stuZljs);
    },
    // 点击审核
    handleEdit(index, row) {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }
      if (this.shzt != "3" || this.node != 2) {
        this.$message({
          message: "当前数据不可审核！",
          type: "error"
        });
        return;
      }
      this.show = false;
      this.showCheck = false;
      this.dataCallBack();
    },
    // 点击通过
    adopt(status) {
      if (status == 0 && !this.isEmpty(this.textarea)) {
        this.$message({
          message: "请输入审核意见！",
          type: "error"
        });
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(this.$server.glourl + "/patent/audit", {
          comment: this.textarea,
          genre: 2,
          businessId: [this.stuZljs.id],
          status
        })
        .then(res => {
          loading.close();
          if (res.data.code !== 0) {
            this.$message({
              message: res.data.msg,
              type: "error"
            });
          } else {
            this.show = true;
            this.loadTable();
            this.$message({
              message: "审核成功！",
              type: "success"
            });
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 提交至远程
    submitInfo() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(this.$server.glourl + "patent/save", this.stuZljs)
        .then(res => {
          loading.close();
          if (res.data.code == 0) {
            this.$message({
              message: "申请信息提交成功，请等待审核！",
              type: "success"
            });
            this.show = true;
            this.loadTable();
          } else {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 申请信息按钮提交失效
    submit() {
      this.$refs["stuZljs"].validate(valid => {
        if (valid) {
          if (!this.isEmpty(this.stuZljs.id)) {
            this.submitInfo();
          } else {
            this.changeSubmit();
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 修改申请表单
    applyChange() {
      if (this.ids === null || this.ids == "") {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
      }
      if (this.isUpdate) {
        this.showCheck = true;
      } else {
        this.$message({
          message: "无法修改的信息！",
          type: "error"
        });
        return;
      }
      this.show = false;
      this.$refs["stuZljs"].resetFields();
      this.dataCallBack();
    },
    //  修改申请表单提交
    changeSubmit() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(this.$server.glourl + "/patent/serve/update", this.stuZljs)
        .then(response => {
          loading.close();
          if (response.data.code == 0) {
            this.$message({
              message: "修改成功！",
              type: "success"
            });
            this.show = true;
            this.loadTable();
          } else {
            this.$message({
              message: res.data.msg,
              type: "success"
            });
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 关闭添加页面
    close() {
      this.show = true;
      this.isDetail = false;
      this.fileList = [];
      this.loadTable();
    },
    //  文件上传成功时的钩子
    handleSuccess(response, file, fileList, info, key) {
      if (this.isEmpty(response) && this.isEmpty(response.url)) {
        this.$set(info, key, response.url);
        // info[key] = response.url;
        console.log(info[key]);
      }
    },
    // 附件处理
    handleRemove(file, fileList, info, key) {
      info[key] = "";
    },
    handlePreview(file) {
      console.log(file);
      let url = file.url;
      if (!url) {
        return;
      }
      window.location.href = url;
    },
    dataCallBack() {
      this.$http
        .get(this.$server.glourl + "/patent/info?id=" + this.ids)
        .then(response => {
          this.stuZljs = response.data.info;
          this.fileList = [
            {
              name: "附件",
              url: this.stuZljs.fj
            }
          ];
        });
    }
  },
  computed: {
    computedOrder() {
      if (this.stuZljs.sfdyzz == 1) {
        return 1;
      } else {
        return 2;
      }
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    isStudent() {
      let result = this.$store.state.identity == 1;
      return result;
    }
  },
  filters: {
    nodeFilter(val) {
      switch (val) {
        case 1:
          return "提交申请";
        case 2:
          return "导师审核";
        case 3:
          return "学院秘书审核";
        case 4:
          return "学院秘书待提交";
        case 5:
          return "研究生院审核";
        default:
          return "";
      }
    },
    dsstatusFilter(sqzt) {
      sqzt = parseInt(sqzt);
      switch (sqzt) {
        case 1:
          return "yes";
        case 2:
          return "back";
        case 0:
          return "back";
      }
    },
    dsztFilter(sqzt) {
      sqzt = parseInt(sqzt);
      switch (sqzt) {
        case 1:
          return "通过";
        case 2:
          return "退回";
        case 0:
          return "不通过";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import "../../style/xscg"; //必须加分号，不然会报错
@import "../../style/ele1";
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
/deep/ .el-dialog__body {
  text-align: center;
}
.el-form-item {
  margin-left: 56px;
}
.divShadows {
  width: 97%;
  background: rgba(255, 255, 255, 1);
  border-radius: 10px;
  margin: 0 auto;
  margin-top: 1%;
  padding-bottom: 1%;
  box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.1);
  position: relative;
}
.container {
  padding: 30px;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
  margin-bottom: 10px;
  margin-top: 10px;
  overflow: hidden;
}
.close {
  text-align: center;
  width: 20px;
  height: 20px;
  color: #cccccc;
  font-size: 16px;
  position: absolute;
  right: 22px;
  top: 20px;
  cursor: pointer;
  z-index: 1000;
}
.el-btn {
  margin-top: 30px;
  /* margin-left: 56px; */
  margin-bottom: 20px;
}
.el-button + .el-button {
  margin-left: 0px;
}
// .el-button--small,
// .el-button--small.is-round {
//   padding: 5px 15px 5px 15px;
// }
//加减号
.plus {
  background: #666;
  color: #fff;
}
.el-button {
  margin-left: 0px;
}
// 日期控件样式
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 100%;
}
.step {
  color: #333;
  .wait {
    margin-right: 15px;
  }
  .yes {
    margin-right: 15px;
  }
  .ing {
    margin-right: 15px;
  }
  .back {
    margin-right: 15px;
  }
  .time {
    // margin-left: 15px;
    color: #909399;
    font-size: 13px;
    margin-left: 0px;
    margin-right: 15px;
  }
  .comment {
    margin-top: 8px;
    color: #333;
    font-size: 13px;
    width: 180px;
    text-overflow: ellipsis;
    overflow: hidden; /** 隐藏超出的内容 **/
  }
}
.yes {
  color: #409eff;
}
.back {
  color: #f56c6c;
}
.step /deep/ .el-step.is-horizontal .el-step__line {
  top: 16px;
}
.step /deep/ .el-step__title.is-success {
  color: #409eff;
}
.step /deep/ .el-step__head.is-success {
  color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-step__head.is-wait {
  color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-step__title.is-wait {
  color: #333;
}
.step /deep/ .el-step__description.is-success {
  color: #409eff;
}
.step /deep/ .el-icon-d-arrow-left:before,
.step /deep/ .el-icon-close:before {
  color: #fff;
  background-color: #f56c6c;
  font-size: 16px;
  border-radius: 50%;
  padding: 4px;
}
.step /deep/ .el-step__head.is-process .el-step__icon.is-text {
  color: #fff;
  background-color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-steps {
  overflow-x: auto;
  padding-bottom: 10px;
}
</style>
