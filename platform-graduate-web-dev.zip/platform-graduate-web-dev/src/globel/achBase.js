exports.install = function(Vue, options) {
  Vue.prototype.loadDict = function(info, item, id) {
    this.$http.get(this.$server.glourl + 'achmaintain/detail/' + id).then(response => {
      if (response.data.code == 0) {
        info[item] = response.data.achMain;
      }
    });
  };
  Vue.prototype.infoNotice = function(message) {
    this.$notify({
      title: '消息',
      message: message
    });
  };
  Vue.prototype.xscgMessage = function(message) {
    this.$notify({
      title: '填写提示',
      message: this.$createElement('i', { style: 'color: red' }, message),
      duration: 0,
      offset: 200
    });
  };
  Vue.prototype.isEmpty = function(obj) {
    //判断字符串是否为空
    if (typeof obj == 'boolean') {
      return true;
    }
    if (typeof obj == 'undefined' || obj == null || obj == '' || obj.length == 0) {
      return false;
    } else {
      return true;
    }
  };
  //获取当前时间，格式YYYY-MM-DD
  Vue.prototype.getCurrentDate = function getNowFormatDate() {
    var date = new Date();
    var seperator1 = '-';
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = '0' + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    return currentdate;
  };
};
