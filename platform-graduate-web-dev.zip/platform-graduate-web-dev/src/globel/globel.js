
const glourl = "http://www.bwgs.zjut.edu.cn/api/"
// const glourl = "http://127.0.0.1:8080/platform-framework/"
// const glourl = "http://192.168.1.109:8080/platform-framework/"

export default {
  glourl
}
