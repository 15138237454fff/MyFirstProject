<template>
  <div style="text-align:center;width:190px;display:inline-block">
    <el-upload
      class="img-upload"
      :action="baseUrls"
      :show-file-list="false"
      ref="lyzz"
      :before-upload="handleBeforeUpload"
      :on-success="Success"
      :on-remove="Remove"
      :on-preview="handlePreview"
    >
      <img v-if="imgUrl" :src="imgUrl" class="avatar" />
      <i v-else class="el-icon-plus avatar-uploader-icon"></i>
    </el-upload>
    <span class="btn-name" :class="{ required: isRequired }" v-if="btnName">{{
      btnName
    }}</span>
  </div>
</template>
<script>
export default {
  name: "myUpload",
  props: {
    url: null,
    info: null, // 接收到的自定义的参数
    pointer: null, // 接收到的自定义的参数
    imgUrl: null,
    onSuccess: Function,
    onRemove: Function,
    fileList: null,
    limit: null,
    isRequired: Boolean,
    btnName: {
      default: ""
    }
  },
  data() {
    return {
      fileType: ["image/jpeg", "image/png"]
    };
  },
  methods: {
    // 文件上传前校验原附件个数
    handleBeforeUpload(file) {
      console.log(file);
      if (file.size / 1024 > 30720) {
        this.$message.error(`上传文件大小不能超过 30MB!`);
        return false;
      }
      if (!this.fileType.includes(file.type)) {
        this.$message.error("只能上传图片");
        return false;
      }
    },
    Success() {
      this.onSuccess(...arguments, this.info, this.pointer);
    },
    handlePreview(file) {
      this.$emit("on-preview", file);
    },
    Remove() {
      this.onRemove(...arguments, this.info, this.pointer);
    },
    clear() {
      this.$refs[this.pointer].clearFiles();
    }
  }
};
</script>
<style lang="scss" scoped>
@import "../style/xscg"; //必须加分号，不然会报错
@import "../style/ele1";
.img-upload {
  /deep/ .el-upload {
    border: 1px dashed #666;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    &:hover {
      border-color: #409eff;
    }
  }
}
// 必填项前置的星号
.required:before {
  content: "*";
  color: red;
  margin-right: 5px;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
.btn-name {
  line-height: 24px;
}
</style>
