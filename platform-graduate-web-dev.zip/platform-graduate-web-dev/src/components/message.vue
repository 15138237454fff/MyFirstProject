<template>
  <div class="dialog">
    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      width="40%"
      :before-close="handleClose"
    >
      <div class="point">{{ message }}</div>
    </el-dialog>
  </div>
</template>
<script>
export default {
  data() {
    return {
      dialogVisible: false,
      message: ""
    };
  },
  methods: {
    handleClose() {},
    showMessage(message) {
      this.message = message;
      this.dialogVisible = true;
    }
  }
};
</script>
<style>
.dialog /deep/ .el-dialog {
  margin-top: 33vh !important;
  padding-bottom: 50px;
}
.point {
  text-align: center;
  color: #f56c6c;
  font-size: 18px;
}
</style>
