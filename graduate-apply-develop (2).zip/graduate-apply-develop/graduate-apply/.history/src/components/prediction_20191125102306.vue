<template>
  <div class="prediction">
    <van-nav-bar
      title="分享给好友"
      left-arrow
      fixed
      @click-left="onClickLeft"
    />
  </div>
</template>

<script>
import Vue from "vue";
import { NavBar } from "vant";
import QRCode from "qrcode";

Vue.use(NavBar);
export default {
  name: "prediction",
  data() {
    return {};
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped lang="scss"></style>
