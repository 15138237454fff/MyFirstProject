<template>
  <div class="prediction">
  </div>
</template>

<script>
export default {
  name: 'prediction',
  data () {
    return {

    }
  }
}
</script>

<style scoped >

</style>
