<template>
  <div class="prediction">
    <van-nav-bar title="预报名" left-arrow fixed @click-left="onClickLeft" />
    <section class="section">
      <van-address-edit
        :area-list="areaList"
       
        :search-result="searchResult"
        :area-columns-placeholder="['请选择', '请选择', '请选择']"
        @save="onSave"
        @delete="onDelete"
        @change-detail="onChangeDetail"
      />
      <ul>
        <li></li>
      </ul>
    </section>
  </div>
</template>

<script>
import Vue from "vue";
import { NavBar } from "vant";
import QRCode from "qrcode";
import { AddressEdit } from "vant";

Vue.use(NavBar);
Vue.use(AddressEdit);
export default {
  name: "prediction",
  data() {
    return {
      areaList:[],
      searchResult: []
    };
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    },
    onSave() {
      Toast("save");
    },
    onDelete() {
      Toast("delete");
    },
    onChangeDetail(val) {
      if (val) {
        this.searchResult = [
          {
            name: "黄龙万科中心",
            address: "杭州市西湖区"
          }
        ];
      } else {
        this.searchResult = [];
      }
    }
  }
};
</script>

<style scoped lang="scss">
.van-nav-bar {
  z-index: 999 !important;
  color: #333;
}
.van-nav-bar__title {
  font-weight: 600;
}
.van-nav-bar .van-icon {
  color: #323233;
  font-weight: 600;
}
.prediction {
  width: 100%;
  height: 100%;
  background: #f5f5f5;
  overflow: auto;
}
</style>
