<template>
  <div class="prediction">
    <van-nav-bar
      title="分享给好友"
      left-arrow
      fixed
      @click-left="onClickLeft"
    />
  </div>
</template>

<script>
export default {
  name: 'prediction',
  data () {
    return {

    }
  }
}
</script>

<style scoped lang="scss">

</style>
