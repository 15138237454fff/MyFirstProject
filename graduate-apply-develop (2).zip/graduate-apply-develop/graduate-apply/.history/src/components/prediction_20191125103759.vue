<template>
  <div class="prediction">
    <van-nav-bar title="预报名" left-arrow fixed @click-left="onClickLeft"/>
    <section class="section">
      <ul>
        <li></li>
      </ul>
    </section>
  </div>
</template>

<script>
import Vue from "vue";
import { NavBar } from "vant";
import QRCode from "qrcode";


Vue.use(NavBar);
export default {
  name: "prediction",
  data() {
    return {};
  },
  methods: {
    onClickLeft() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped lang="scss">
.van-nav-bar{
  z-index: 999 !important;
  color: #333;
}
.van-nav-bar__title{
  font-weight: 600;
} 
.van-nav-bar .van-icon {
  color: #323233;
  font-weight: 600;
}
.prediction{
  width: 100%;
  height: 100%;
  background: #f5f5f5;
  overflow: auto;
}
</style>
