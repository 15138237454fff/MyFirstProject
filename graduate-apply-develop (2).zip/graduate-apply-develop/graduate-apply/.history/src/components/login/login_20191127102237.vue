<template>
  <div class="login" :style="{ height: bodyHeight + 'px' }">
    <div class="login_safe">
      <input
        type="text"
        placeholder="请输入姓名"
        v-model="stuMsg.xm"
        class="stuname"
      />
      <input
        type="text"
        placeholder="请输入身份证号"
        v-model="stuMsg.zjhm"
        class="stuid"
      />
      <button class="query" @click="see">查询</button>
      <div class="inner">
        <p>如果你也有意向报考浙江财经大学</p>
        <p>请点击下方按钮留下你的信息</p>
        <p>浙江财经大学研招办会优先联系你</p>
      </div>
      <button class="sign" @click="luqu">我要报名</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "login",
  data() {
    return {
      bodyHeight: "",
      stuMsg: {
        status:'',
        xm: "",
        zjhm: ""
      }
    };
  },
  methods: {
    see() {
       this.$http.get('/api/system/xbsj/selectStudent', {
         status:'',xm:this.
       }).then((res) =>{
        console.log(res.data.data)
      })
      // this.$router.push('/theQuery')
    },
    getDate(){
      this.$http.get('/api/system/xbsj/selectStudent').then((res) =>{
        console.log(res.data.data)
      })
    },
    luqu() {}
  },
  mounted() {
    this.bodyHeight = document.documentElement.clientHeight;
    // this.getDate()
  }
};
</script>

<style scoped lang="scss">
.login {
  width: 100%;
  height: 100%;
  background-image: url("../../assets/images/prosperity_bg.png");
  background-size: 100% 100%;
  background-repeat: no-repeat;
  color: #333;
  font-size: 0.16rem;
  .login_safe {
    width: 70%;
    margin: 0 auto;
    padding-top: 2.75rem;
    text-align: center;
    input {
      width: 100%;
      height: 0.4rem;
      text-align: center;
      background-color: #fff;
      border-radius: 0.06rem;
    }
    .stuid {
      margin-top: 0.1rem;
    }
    .query {
      width: 100%;
      height: 0.4rem;
      background-color: #c04130;
      color: #fff;
      border-radius: 0.06rem;
      margin-top: 0.1rem;
    }
    .inner {
      margin-top: 0.3rem;
      p {
        font-size: 0.14rem;
        color: #bfbfbf;
      }
    }
    .sign {
      width: 30%;
      border-radius: 0.06rem;
      height: 0.4rem;
      color: #ffffff;
      background-color: #c04130;
      margin-top: 0.25rem;
    }
  }
}
</style>
