<template>
  <div class="theQuery" :style="{ height: bodyHeight + 'px' }">
    <div class="login_safe">
      <p>{{ student.username }} 同学：</p>
      <p class="welcome">
        欢迎你进入浙江财经大学，攻读{{ student.username }},录取信息如下：
      </p>
      <input
        type="text"
        placeholder="学院"
        v-model="student.username"
        class="stuname"
      />
      <input
        type="text"
        placeholder="专业"
        v-model="student.ticket"
        class="stuid"
      />
      <p class="good">已收到{{ student.ticket }}个好友的祝福</p>
      <div class="shareto">
        <button class="sign" @click="luqu">分享给好友</button>
      </div>
      <div class="share">
        本校研究生院正式录取的新生参与集祝福赢好礼，快去分享录取信息给好友吧！
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "theQuery",
  data() {
    return {
      bodyHeight: "",
      student: {
        stuname: "",
        stuxy: "",
        stuzy:'',
        stulx:'',
        studz:null
      }
    };
  },
  methods: {
    luqu() {
      this.$router.push('/qrCode')
    }
  },
  mounted() {
    this.bodyHeight = document.documentElement.clientHeight;
    this.
  }
};
</script>

<style scoped lang="scss">
.theQuery {
  background-image: url("../../assets/images/prosperity_bg.png");
  background-size: 100% 100%;
  background-repeat: no-repeat;
  color: #333;
  font-size: 0.16rem;
  .login_safe {
    width: 90%;
    margin: 0 auto;
    padding-top: 2.7rem;
    p {
      font-weight: 600;
    }
    .welcome {
      margin-top: 0.1rem;
    }
    input {
      width: 100%;
      height: 0.4rem;
      margin-top: 0.1rem;
      background-color: #fff;
      border-radius: 0.06rem;
      padding: 0 0.1rem;
    }
    .good {
      font-size: 0.14rem;
      margin-top: 0.2rem;
      text-align: center;
    }
    .shareto {
      text-align: center;
      .sign {
        width: 40%;
        border-radius: 0.06rem;
        height: 0.4rem;
        color: #ffffff;
        background-color: #c04130;
        margin-top: 0.1rem;
      }
    }
    .share{
      width: 80%;
      font-size: 0.12rem;
      margin: 0 auto;
      padding-top: 0.1rem;
    }
  }
}
</style>
