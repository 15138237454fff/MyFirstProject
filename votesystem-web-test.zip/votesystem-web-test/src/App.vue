<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      
    }
  },
  methods: {
    
  }
}
</script>

<style>
html,
body {
  margin: 0 auto;
  height: 100%;
  box-sizing: border-box;
  overflow-y:hidden;
}
#app {
  width: 100%;
  height: 100%;
  overflow-y:hidden;
  /* min-width: 1200px;
  min-height: 700px; */
}
.el-table td, .el-table th {
    text-align: center !important;
}
::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 3px;
}
a {
  text-decoration: none;
}
.el-table--enable-row-transition .el-table__body td {
    text-align: center;
}
.el-table--border th {
    text-align: center;
}
td, th {
  overflow: hidden;/*超出部分隐藏*/
  text-overflow:ellipsis;/* 超出部分显示省略号 */
  white-space: nowrap;
}
.el-table .cell, .el-table th div {
  overflow: hidden;/*超出部分隐藏*/
  text-overflow:ellipsis;/* 超出部分显示省略号 */
  white-space: nowrap;
}
.el-table td, .el-table th {
  padding: 8px 0;
}
.block {
  margin-top: 15px;
}
.organ {
  background: #ff9b2f;
  color: #fff;
  border: 1px solid #ff9b2f;
  outline: none;
}
.organ:hover {
  color: #fff !important;
  border: 1px solid #ff9b2f !important;
  background: #ffac53 !important;
}
.el-pagination {
  text-align: center !important;
}
.el-message-box__header {
  width: 90%;
  position: relative;
  left: 5px;
  border-bottom: 1px solid #f4f4f4;
}
.el-message-box__title {
  font-size: 16px;
  color: #333333;
}
.el-message-box {
  width: 380px;
  height: 220px !important;
}
.el-message-box__btns {
    text-align: center;
    position: relative;
    top: 70px;
}
.el-message-box__btns button:first-child{
  display: none;
}
.el-message-box__message {
  position: relative;
  top: 40px;
}
.el-message-box__message p {
  text-align: center;
  font-size: 16px;
}
.el-message-box .el-button--small {
  padding: 12px 20px;
  font-size: 14px;
  border-radius: 4px;
}
.el-pagination {
  font-weight: 400;
}
.el-tabs {
  height: 50px;
}
.el-dialog__title {
  font-size: 16px;
  color: #333333;
}
.mainContainer .is-active {
  color: #000 !important;
}
.el-dialog .el-table td, .el-table th div.cell {
  font-size: 16px;
  color: #666;
  font-weight: 400
}
.el-dialog .el-table td, .el-table td div.cell {
  font-size: 14px;
  color: #999;
}
th {
  background: #F5F5F5 !important;
}
.el-message {
  min-width: 200px;
}
input::-webkit-inner-spin-button{
  -webkit-appearance: none !important;
}
.el-popper {
  margin-top: 10px !important;
}
.el-tooltip__popper {
  max-width: 400px !important;
  z-index: 99999 !important;
}
</style>
