<template>
  <div class="backlog">
    <div class="top-title">
			<el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
		</div>
		<div class="main-container">
			<p class="my-title">
				<img src="../../assets/img/1.png" alt="" style="position: relative; top: 3px;">
        <span>待办事项</span>
			</p>
			<div class="main-details">
				<div class="details-left">
					<ul>
						<li>
							我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩
							<span>2019-04-08</span>
						</li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
					</ul>
				</div>
				<div class="details-right">
					<ul>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
					</ul>
				</div>
			</div>
		</div>
  </div>
</template>

<script>
  export default {
    name: 'backlog',
    data () {
      return {
        
      }
    },
		methods: {
			exitList () {
				this.$store.state.backlog = false
			}
		}
 }
</script>

<style scoped lang="scss">

* {
	box-sizing: border-box;
}
.backlog {
	height: 100%;
	.top-title {
		width: 100%;
		height: 60px;
		background: #F2F2F2;
		line-height: 60px;
		.diyButton {
			background: none;
			border: none;
			color: #2779E3;
		}
	}
	.main-container {
		height: calc(100% - 120px);
		margin-top: 15px;
		border: 1px solid #EEEEEE;
		padding: 0 20px 20px 20px;
		position: relative;
		.my-title {
			height: 60px;
		}
		.main-details {
			position: absolute;
			top: 70px;
			left: 20px;
			right: 20px;
			bottom: 20px;
			.details-left, .details-right {
				height: 100%;
				width: 50%;
				float: left;
				ul {
					height: 100%;
					width: 100%;
					padding-top: 15px;
					li {
						position: relative;
						width: 100%;
						list-style: none;
						height: 10%;
						font-size: 14px;
						color: #666;
						padding: 0 15px 0 15px;
						border-top: 1px solid #eee;
						display: flex;
						align-items: center;
						span {
							position: absolute;
							right: 15px;
							float: right;
							font-size: 14px;
							color: #666;
						}
					}
				}
			}
			.details-left {
				border-right: 1px solid #eee;
				padding-right: 20px;
			}
		}
	}
}

</style>
