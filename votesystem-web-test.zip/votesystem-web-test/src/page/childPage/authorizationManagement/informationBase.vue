<!-- 专家信息库 -->
<template>
  <div class="userManagement">
    <div class="header-left">
      <el-input v-model="pageHelper.query" placeholder="请输入用户名/姓名" @keyup.enter.native="takeList" width="200px" class="top-input" clearable @clear="takeList"></el-input>
      <el-button @click="takeList" style="margin-left:5px">查询</el-button>
      <el-select v-model="pageHelper.panelId" placeholder="全部专家组" style="margin-left: 10px;" class="top-input">
        <el-option label="全部" value=""></el-option>
        <el-option v-for="item in panelList" :key="item.value" :label="item.label" :value="item.value">
        </el-option>
      </el-select>
      <el-select v-model="pageHelper.status" placeholder="所有状态">
        <el-option v-for="item in GLOBEL.dict.userStatus" :key="item.value" :label="item.label" :value="item.value">
        </el-option>
      </el-select>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="addNew">添加</el-button>
      <el-button type="warning" @click="modification">修改</el-button>
      <el-button type="danger" @click="deleteInfo">删除</el-button>
      <el-button type="primary" @click="unlock">解锁</el-button>
      <el-button type="primary" @click="initializePas">初始化密码</el-button>
      <!-- <el-button type="primary" @click="exportDate">导出</el-button> -->
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table @selection-change="mySelect" @select-all="allClick" @row-click="rowClick" ref="multipleTable" :data="pageInfo.list" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
        <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="userName" label="用户名" width="200px">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="name" label="姓名" width="150px">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="roleName" label="所属角色" width="150px">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="organizationName" label="所属机构">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="phoneNum" label="手机号">
        </el-table-column>
      </el-table>
    </div>
    <el-dialog :title="userTitle" :visible.sync="addDialog" :before-close="handleClose" width="700px">
      <p class="hr"></p>
      <el-form ref="numberValidateForm" :model="form" label-width="100px" :rules="rules">
        <el-row>
          <el-col :span="10">
            <el-form-item label="用户名：" :required="true" prop="userName">
              <el-input v-model="form.userName" style="width:200px" :readonly="modificationShow"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="姓名：">
              <el-input v-model="form.name" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属角色：">
              <el-select v-model="form.roleIds[0]" placeholder="请选择" style="width:200px">
                <el-option value="003" label="专家">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="所属机构：">
              <el-select v-model="form.organizationId" placeholder="请选择" style="width:200px">
                <el-option v-for="item in organizationList" :key="item.label" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="身份证号：">
              <el-input v-model="form.idCard" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="手机号码：">
              <el-input v-model="form.phoneNum" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="有效期：">
              <el-radio-group v-model="form.status">
                <el-radio :label="1">永久</el-radio>
                <el-radio :label="2">锁定</el-radio>
                <el-radio :label="3">临时</el-radio>
                <el-radio :label="4" v-show="modificationShow">失效</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14">
            <el-form-item label="有效时间：" v-show="form.status == 3||form.status == 4">
              <el-date-picker v-model="validTime" value-format="yyyy-MM-dd" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer" v-show="modificationShow">
        <el-button @click="addDialog = false">取 消</el-button>
        <el-button type="primary" @click="modificationNew">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-show="addShow">
        <el-button @click="addDialog = false">取 消</el-button>
        <el-button type="primary" @click="affirmNew">确 定</el-button>
      </span>
    </el-dialog>
    <deleteDia ref="deleteDia"></deleteDia>
    <div class="block">
      <el-pagination :current-page.sync="pageInfo.pageNum" :page-sizes="[10, 50, 100]" :page-size="pageInfo.pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="pageInfo.total" @size-change="sizeChange">
      </el-pagination>
    </div>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import deleteDia from '@/components/deleteDia'
export default {
  name: 'userManagement',
  data() {
    return {
      deleteDialog: false, // 控制删除弹出框
      characterList: [], // 所属角色列表
      organizationId: '', // 所属机构
      organizationList: [], // 所属机构列表
      addDialog: false, // 控制添加弹出框
      tableData: [],
      addShow: true,
      userTitle: '添加专家', // 添加或修改用户
      modificationShow: false,
      deleteList: [], // 需要删除的列表
      modificData: {}, // 选中修改的数据
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      form: { roleIds: [] },//实体模型
      pageHelper: {//查询帮助类
        pageNum: 1,
        pageSize: 10
      },
      pageInfo: {},//列表信息
      panelList: [],//专家组
      rules: {
        userName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
      },
      validTime: []
    }
  },
  watch: {
    'pageHelper.status': function () {
      this.takeList()
    },
    'pageHelper.panelId': function () {
      this.takeList()
    }
  },
  methods: {
    unlock() {
      if (!this.isEmpty(this.modificData.userId)) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      this.$http
        .put("api/user/clear/" + this.modificData.userId)
        .then(res => {
          if (res.data.code != 200) {
            this.$message.error('解锁失败')
          } else if (res.data.code == 200) {
            this.$message({
              message: '解锁成功',
              type: 'success'
            })
            this.takeList()
          }
        })
    }, // 解锁
    initializePas() {
      this.deleteList.length != 1 ?
        this.$message.error({ message: "请选择一条数据！" }) :
        this.$http
          .put("api/user/reset/" + this.modificData.userId)
          .then(res => {
            if (res.data.code != 200) {
              this.$message.error('密码初始化失败')
            } else if (res.data.code == 200) {
              this.$message({
                message: '密码初始化成功',
                type: 'success'
              })
            }
          })
    }, // 初始化密码
    mySelect(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.userId)
      })
    }, // 用户勾选table中的某一项
    allClick(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.userId)
      })
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    addNew() {
      this.form = { roleIds: ["003"] }
      this.addDialog = true
      this.userTitle = '添加专家'
      this.addShow = true
      this.modificationShow = false
    }, // 添加用户
    takeList() {
      this.$http
        .post("api/specialist/list", this.pageHelper)
        .then(res => {
          this.pageInfo = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有列表数据
    closeDia() {
      this.deleteDialog = false
      this.$http
        .delete("api/specialist", { data: this.deleteList })
        .then(res => {
          this.takeList(1)
          if (res.data.code != 200) {
            this.$message.error(res.data.message)
          } else if (res.data.code == 200) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
          }
        })
        .catch(function (err) {

        })
    }, // 关闭删除弹出框
    changePage(index) {
      this.pageHelper.pageNum = index
      this.takeList()
    }, // 翻页时的数据
    affirmNew() {
      this.$refs["numberValidateForm"].validate((valid) => {
        if (valid) {
          this.submitAddData();
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    }, // 新增确定
    submitAddData() {
      this.getValidTime()
      this.$http
        .post("api/specialist/", this.form)
        .then(res => {
          if (res.data.code != 200) {
            this.$message.error(res.data.message)
          } else if (res.data.code == 200) {
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.addDialog = false
            this.takeList(1)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    deleteInfo() {
      this.deleteList.length != 0 ?
        this.deleteDialog = true :
        this.$message.error({ message: "请选择一条数据！" })
    }, // 删除信息
    downloadTemplate() {
      window.location.href = "api/specialist/down"
    }, // 下载模板
    exportDate() {
      window.location.href = "api/specialist/export"
    }, // 导出数据
    modification() {
      if (!this.isEmpty(this.modificData.userName)) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      this.getUserDetail();
      this.addDialog = true;
      this.addShow = false
      this.modificationShow = true
      this.userTitle = "修改用户"
    }, // 修改用户
    getUserDetail() {
      this.$http
        .get("api/user/" + this.modificData.userName)
        .then(res => {
          if (res.data.code == 200) {
            this.form = res.data.data;
            if (this.form.status == 3) {
              this.validTime[0] = this.form.startTime
              this.validTime[1] = this.form.endTime
            }
          }
          else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {

        })
    },
    deptList() {
      this.$http
        .get("api/organization/select")
        .then(res => {
          this.organizationList = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有的组织机构数据
    getValidTime() {
      if (this.form.status == 3) {
        this.form.startTime = this.validTime[0]
        this.form.endTime = this.validTime[1]
      }
    },//转换时间
    modificationNew() {
      this.getValidTime()
      this.$http
        .put("api/specialist/" + this.modificData.userId, this.form)
        .then(res => {
          if (res.data.code != 200) {
            this.$message.error('修改失败')
          } else if (res.data.code == 200) {
            this.$message({
              message: '修改成功',
              type: 'success'
            })
            this.addDialog = false
            this.takeList()
          }
        })
        .catch(function (err) {

        })
    }, // 确认修改
    handleClose(done) {
      done()
    }, // 关闭弹出框
    searchData() {

    }, // 查询数据
    handleRemove(file, fileList) {
    },
    handlePreview(file) {
    },
    sizeChange(value) {
      this.pagesize = value
      this.takeList(1)
    }, // 切换每页条数
    rowClick(row) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    //专家组下拉数据
    loadPanelList() {
      this.$http.get("api/panel/select").then(res => {
        if (res.data.code == 200) {
          this.panelList = res.data.data
        } else {
          this.$message.error(res.data.message)
        }
      })
    }
  },
  components: {
    deleteDia
  },
  mounted() {
    //加载列表
    this.takeList(1)
    //加载部门集合
    this.deptList()
    //加载专家组集合
    this.loadPanelList()
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.header-left {
  margin-top: 15px;
  float: left;
}
/* .header-left button, .header-right button {
  border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
} */
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 10px;
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.inInput {
  margin-bottom: 10px;
  height: 36px;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
  margin-left: 4px;
  width: 215px;
  padding: 0 10px;
}
label {
  margin-left: 10px;
}
label.import {
  margin-left: 20px;
}
label.import::before {
  content: "*";
  color: #f00;
  margin: 2px 3px 0 0;
}
.upload-demo {
  float: right;
  position: relative;
  left: 10px;
}
.el-upload-list {
  display: none !important;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.userManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
.userManagement /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.userManagement /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 25px 20px !important;
  text-align: center;
}
.top-input {
  width: 200px;
}
@media screen and (max-width: 1500px) {
  .top-input {
    width: 130px;
  }
}
</style>
<style>
/* .el-input--suffix .el-input__inner {
  margin-bottom: 10px;
} */
.el-dialog__title {
  font-size: 16px;
  color: #333333;
}
.el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
</style>