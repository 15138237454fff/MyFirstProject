<template>
  <div class="addtree">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="header-left">
      <el-form ref="form" :model="roleInfo" label-width="110px" :inline="true">
        <el-form-item label="角色名称：" prop="roleName">
          <el-input v-model="roleInfo.roleName" style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="前台/后台：" prop="frontBack">
          <el-select v-model="roleInfo.frontBack">
            <el-option label="前台" :value="1">前台</el-option>
            <el-option label="后台" :value="0">后台</el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="updateRole" v-show="!showAdd">修改</el-button>
          <el-button type="primary" @click="addRole" v-show="showAdd">添加</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="main-container">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="功能模块权限" name="first">
          <el-table :data="tableData" style="width: 100%" :span-method="objectSpanMethod">
            <el-table-column label="功能模块权限">
              <el-table-column label="一级模块" width="200px">
                <template slot-scope="scope">
                  <el-checkbox-group v-model="roleInfo.menuList">
                    <el-checkbox @change="checkHandel(scope.row.id)" :label="scope.row.id">{{scope.row.name}}</el-checkbox>
                  </el-checkbox-group>
                </template>
              </el-table-column>
              <el-table-column label="二级模块">
                <template slot-scope="scope">
                  <el-checkbox-group v-model="roleInfo.menuList">
                    <el-checkbox @change="checkHandel(scope.row.child[0].id)" :label="scope.row.child[0].id">{{scope.row.child[0].name}}</el-checkbox>
                  </el-checkbox-group>
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="按钮权限">
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="数据权限" name="second">
          <el-table :data="deptData" style="width: 100%" :span-method="objectSpanMethod">
            <el-table-column label="数据权限设置">
              <el-table-column label="一级单位" width="200px">
                <template slot-scope="scope">
                  <el-checkbox-group v-model="roleInfo.deptList">
                    <el-checkbox @change="checkHandel(scope.row.id)" :label="scope.row.id">{{scope.row.name}}</el-checkbox>
                  </el-checkbox-group>
                </template>
              </el-table-column>
              <el-table-column label="二级单位">
                <template slot-scope="scope">
                  <el-checkbox-group v-model="roleInfo.deptList">
                    <el-checkbox @change="checkHandel(scope.row.child[0].id)" :label="scope.row.child[0].id">{{scope.row.child[0].name}}</el-checkbox>
                  </el-checkbox-group>
                </template>
              </el-table-column>
            </el-table-column>
            <el-table-column label="三级单位">
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>

    </div>
  </div>
</template>

<script>
import treeTable from '@/components/treeTable'
import { fail } from 'assert';
export default {
  props: ['message'],
  name: 'addtree',
  data() {
    return {
      showAdd: false,
      activeName: 'first',
      form: {},
      tableData: [
      ],
      deptData: [],
      spanArr: [],
      position: 0,
      roleInfo: {
        menuList: []
      }
    }
  },
  methods: {
    //添加角色
    addRole() {
      this.$http
        .post('/api/role', this.roleInfo)
        .then(res => {
          if (res.data.code == 200) {
            this.exitList()
            this.$message({
              message: res.data.message,
              type: "success"
            });
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            })
          }
        })
        .catch(function (err) {
          console.log(err)
        });
    },
    exitList() {
      this.$parent.closeVoteTable();
    },
    parentAddRole() {
      this.showAdd = true;
      this.roleInfo = { frontBack: 1, menuList: [], deptList: [] }
      this.loadUserMenuTable();
      this.loadUserDeptTable();
    },
    //查询角色详情
    queryRoleDetail(roleId) {
      this.showAdd = false;
      this.$http
        .get('api/role/' + roleId)
        .then(res => {
          if (res.data.code == 200) {
            this.roleInfo = res.data.data
            this.loadUserMenuTable();
            this.loadUserDeptTable();
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            })
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    updateRole() {
      this.$http
        .put('/api/role/update/' + this.roleInfo.roleId, this.roleInfo)
        .then(res => {
          if (res.data.code == 200) {
            this.exitList()
            this.$message({
              message: res.data.message,
              type: "success"
            });
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            })
          }
        })
        .catch(function (err) {
          console.log(err)
        });
    },
    handleClick() {

    }, // 切换tab方法
    checkHandel(value, id) {

    }, // 全选一级菜单方法
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 0) {
        return {
          rowspan: row.rowSpan,
          colspan: 1
        };
      }
    },
    loadUserMenuTable() {
      this.$http
        .get('/api/menu/role/' + this.roleInfo.frontBack)
        .then(res => {
          this.tableData = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        });
    },
    loadUserDeptTable() {
      this.$http
        .get('/api/organization/role')
        .then(res => {
          this.deptData = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        });
    }
  }, // 相同一级菜单合并行
  mounted() {
  },
  components: {
    treeTable
  }
}
</script>

<style scoped lang="scss">
.top-title {
  width: 100%;
  height: 60px;
  background: #f2f2f2;
  line-height: 60px;
  .diyButton {
    background: none;
    border: none;
    color: #2779e3;
  }
}

* {
  box-sizing: border-box;
}
.table {
  width: 100%;
  margin-top: 15px;
}
.header-left {
  float: left;
  width: 100%;
  margin-top: 10px;
}
.addtree /deep/ .el-radio-group {
  position: relative;
  top: 8px;
}
.main-container {
  position: absolute;
  top: 130px;
  left: 15px;
  right: 15px;
  bottom: 0;
  border-top: none;
  .table-container {
    width: 100%;
    height: calc(100% - 100px);
    border: 1px solid #ddd;
    position: relative;
    padding: 0 10px;
  }
}
.addtree /deep/ .el-tabs__nav-scroll {
  height: 41px !important;
}
.addtree /deep/ .el-tabs--card > .el-tabs__header {
  border: none !important;
}
.addtree /deep/ .el-tabs {
  position: relative;
  top: 40px;
}
</style>
