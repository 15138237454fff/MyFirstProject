<!-- 菜单管理 -->
<template>
  <div class="menuManagement">
    <div class="header-right">
      <el-button type="primary" @click="addNew">添加</el-button>
    </div>
    <!-- <tree-table :data="data" :columns="columns" border></tree-table> -->
    <el-table :data="data" style="width: 100%;margin-bottom: 20px;" row-key="menuId" border default-expand-all :tree-props="{children: 'children', hasChildren: 'hasChildren'}">
      <el-table-column prop="name" label="模块名称">
      </el-table-column>
      <el-table-column prop="url" label="模块URL">
      </el-table-column>
      <el-table-column prop="orderNum" label="排序">
      </el-table-column>
      <el-table-column prop="perms" label="权限标识">
      </el-table-column>
      <el-table-column prop="type" label="模块类型">
        <template slot-scope="scope">
          <span>{{getDictValue(scope.row.type,"menuType")}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="domain" label="所属域">
        <template slot-scope="scope">
          <span>{{getDictValue(scope.row.domain,"domainList")}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="状态">
        <template slot-scope="scope">
          <span>{{getDictValue(scope.row.status,"menuStatus")}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="handle" label="操作">
        <template slot-scope="scope">
          <el-button type="text" @click="updateMenu(scope.row)">修改</el-button>
          <el-button type="text" @click="deleteMenu(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog :title="title" :visible.sync="dialogShow" width="700px">
      <p class="hr"></p>
      <el-form ref="form" :model="form" label-width="80px" :rules="rules">
        <el-row>
          <el-col :span="22">
            <el-form-item label="菜单类型" prop="type">
              <el-radio-group v-model="form.type" @change="formTypeChange">
                <el-radio :label="1" :disabled="showEdit">一级菜单</el-radio>
                <el-radio :label="2" :disabled="showEdit">二级菜单</el-radio>
                <el-radio :label="3" :disabled="showEdit">按钮</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="菜单名称" prop="name">
              <el-input v-model="form.name"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="排序号">
              <el-input-number v-model="form.orderNum" :min="0"></el-input-number>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属域" prop="domain">
              <el-select v-model="form.domain" placeholder="请选择">
                <el-option v-for="item in GLOBEL.dict.domainList" :key="item.label" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="上级菜单" v-if="form.type==2">
              <el-select v-model="form.parentId" placeholder="请选择">
                <el-option v-for="item in oMenu" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="上级菜单" v-if="form.type==3">
              <el-select v-model="form.parentId" placeholder="请选择">
                <el-option v-for="item in tMenu" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="权限标识">
              <el-input v-model="form.perms"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="URL" v-if="form.type==2">
              <el-input v-model="form.url"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="状态">
              <el-radio-group v-model="form.status">
                <el-radio :label="1">有效</el-radio>
                <el-radio :label="2">无效</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogShow = false">取 消</el-button>
        <el-button type="primary" @click="addMenu">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import treeTable from '@/components/treeTable'
import { fail } from 'assert';
export default {
  name: 'menuManagement',
  data() {
    return {
      form: {},
      dialogShow: false, // 控制弹出框
      data: [
      ],
      title: null,
      oMenu: [],
      tMenu: [],
      columns: [
        {
          label: '',
          width: 150,
          checkbox: true
        },
        {
          label: '模块名称',
          width: 250,
          key: 'name',
          expand: true
        },
        {
          label: '上级模块',
          key: 'parentName',
          align: 'left'
        },
        {
          label: '模块类型',
          key: 'type'
        },
        {
          label: '所属域',
          key: 'domain'
        },
        {
          label: '状态',
          key: 'status'
        }
      ],
      rules: {
        name: [{ required: true, message: '请输入菜单名称', trigger: 'blur' }],
      },
      showEdit: false
    }
  },
  methods: {
    deleteMenu(row) {
      this.$http
        .delete("api/menu/", { data: [row.menuId] })
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "删除成功",
              type: "success"
            });
            this.takeList()
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          }
        })
    },
    //修改菜单
    updateMenu(row) {
      this.showEdit = true;
      this.form = row;
      this.dialogShow = true;
      this.title = "修改菜单"
    },
    //添加菜单
    addMenu() {
      this.$refs["form"].validate((valid) => {
        if (valid) {
          if (this.showEdit) {
            this.submitUpdateInfo()
          } else {
            this.submitAddInfo();
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    //提交修改信息
    submitUpdateInfo() {
      this.$http
        .put("api/menu/" + this.form.menuId, this.form)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "修改成功",
              type: "success"
            });
            this.dialogShow = false
            this.takeList()
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          }
        })
    },
    //提交添加信息
    submitAddInfo() {
      this.$http
        .post("api/menu", this.form)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "添加成功",
              type: "success"
            });
            this.dialogShow = false
            this.takeList()
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            });
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    formTypeChange(type) {
      this.$set(this.form, "parentId", null)
    },
    addNew() {
      this.dialogShow = true
      this.showEdit = false
      this.title = "新增"
      this.form = {
        type: 1,
        domain: 1,
        status: 1,
        orderNum: 1
      }
    },
    mapList() {
      this.oMenu = [];
      this.tMenu = [];
      this.data.forEach(element => {
        this.oMenu.push({
          label: element.name,
          value: element.menuId
        })
        if (element.children.length > 0) {
          element.children.forEach(temp => {
            this.tMenu.push({
              label: temp.name,
              value: temp.menuId
            })
          });
        }
      });
    },
    takeList() {
      this.$http
        .get("api/menu/list")
        .then(res => {
          this.data = res.data.data
          this.mapList()
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有列表数据
  },
  mounted() {
    this.takeList()
  },
  components: {
    treeTable
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-right {
  margin-top: 15px;
  margin-bottom: 10px;
  float: right;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.inInput {
  margin-bottom: 10px;
  height: 36px;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
  margin-left: 4px;
  width: 215px;
  padding: 0 10px;
}
label {
  margin-left: 29px;
}
label.import {
  margin-left: 20px;
}
label.import::before {
  content: "*";
  color: #f00;
  margin: 2px 3px 0 0;
}
</style>

<style>
.el-checkbox {
  padding-left: 0px !important;
}
</style>
