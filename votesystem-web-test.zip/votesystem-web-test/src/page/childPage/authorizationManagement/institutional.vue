<!-- 组织机构 -->
<template>
  <div class="institutional">
    <div class="header-left">
      <el-input
        v-model="searchField"
        placeholder="请输入机构代码/名称"
        style="width:70%"
        @keyup.enter.native="searchData"
      ></el-input>
      <el-button @click="searchData" style="margin-left:5px">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="addNew">添加</el-button>
      <el-button @click="modification" type="warning">修改</el-button>
      <el-button type="danger" @click="deleteInfo">删除</el-button>
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table @selection-change="mySelect" ref="multipleTable" :data="tableData"
        @select-all="allClick"
        tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;"
        @row-click="clickRow"
        :height="tableHeight">
        <el-table-column type="selection" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="deptNum" label="机构代码" :show-overflow-tooltip="true" width="100px">
        </el-table-column>
        <el-table-column prop="deptName" label="机构名称" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="parentName" label="所属机构" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="createUser" label="创建人" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" :show-overflow-tooltip="true">
        </el-table-column>
      </el-table>
    </div>
    <!-- 新增弹出框 -->
    <el-dialog :title="diaTitle" :visible.sync="addDialog" :before-close="handleClose"
      width="460px" ref="hanleDialog">
      <p class="hr"></p>
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="机构代码：" width="200px" prop="deptNum" :rules="[
          { required: true, message: '请输入1-6位的数字'}
        ]">
          <el-input v-model="form.deptNum" :disabled="isModific" maxlength="6" style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="机构名称："  :required="true">
          <el-input v-model="deptName" style="width:200px"></el-input>
        </el-form-item>
        <el-form-item label="所属机构：" width="120px">
          <el-select v-model="organization" placeholder="请选择" @change="myChange"
            style="width: 200px;">
            <el-option v-for="item in organizationList" :key="item.value" :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer" v-show="modificationShow">
        <el-button @click="cancal">取 消</el-button>
        <el-button type="primary" @click="modificationNew">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-show="addShow">
        <el-button @click="cancal">取 消</el-button>
        <el-button type="primary" @click="affirmNew">确 定</el-button>
      </span>
    </el-dialog>
    <div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 50, 100]"
        :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper"
        @current-change="changePage" :total="total" @size-change="sizeChange">
      </el-pagination>
    </div>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import deleteDia from '@/components/deleteDia'
  export default {
    name: 'institutional',
    data() {
      return {
        form: {
          deptNum: ''
        },
        isModific: false, // 修改时的机构代码不可修改
        searchField: '', // 用户搜索的字段
        isDis: true,
        diaTitle: '', // 弹窗的标题
        deleteDialog: false, // 控制删除弹出框
        deptNum: '', // 新增机构代码
        deptName: '', // 新增机构名称
        page: 1, // 当前页码
        currentPage: 1, // 起始页
        pagesize: 10, // 每页条数
        organization: '', // 所属机构
        organizationList: [], // 所属机构列表
        addDialog: false, // 控制添加弹出框
        tableData: [], // 列表数据
        parentId: '', // 所属机构id
        total: 0, // 总的数据条数
        deleteList: [], // 需要删除的列表
        modificData: {}, // 选中修改的数据
        addShow: true,
        modificationShow: false,
        tableHeight: '',
        clientHeight: 0,
        offsetTop: 0
      }
    },
    methods: {
      clickRow(row, column, event) {
        this.$refs.multipleTable.toggleRowSelection(row)
      },
      mySelect(selection) {
        this.deleteList = []
        this.modificData = selection[0]
        selection.map((item, index) => {
          this.deleteList.push(item.deptId)
        })
      }, // 用户勾选table中的某一项
      allClick (selection) {
        this.deleteList = []
        this.modificData = selection[0]
        selection.map((item, index) => {
          this.deleteList.push(item.deptId)
        })
      },
      myChange(item) {
        this.parentId = item
      }, // 下拉列表切换时触发
      tableHeaderColor({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (rowIndex === 0) {
          return 'background-color: #F2F2F2;font-weight: 500;'
        }
      }, // 替换table中thead的颜色
      addNew() {
        this.diaTitle = '添加组织机构'
        this.addDialog = true
        this.isDis = false
        this.addShow = true
        this.modificationShow = false
        this.isModific = false
      }, // 添加机构弹出弹出框
      deleteInfo() {
        this.deleteList.length !== 0 ?
          this.deleteDialog = true :
          this.$message.error({message: "请选择一条数据！"})
      }, // 删除信息
      changePage(index) {
        this.page = index
        this.takeList(index)
      }, // 翻页时的数据
      takeList(index) {
        this.$http
          .post("api/organization/list/", {
            pageNum: index,
            pageSize: this.pagesize,
            query: this.searchField
          })
          .then(res => {
            this.tableData = res.data.data.list
            this.total = res.data.data.total
          })
          .catch(function (err) {
            console.log(err)
          })
      }, // 查询所有列表数据
      deptList() {
        this.$http
          .get("api/organization/select")
          .then(res => {
            res.data.data.map((item, index) => {
              let obj = {}
              obj.value = item.value
              obj.label = item.label
              this.organizationList.push(obj)
            })
          })
          .catch(function (err) {
            console.log(err)
          })
      }, // 查询所有的组织机构数据
      affirmNew() {
        if (this.deptName == '' || this.form.deptNum == '') {
          this.$message.error('请完整数据的填写')
        } else {
          this.addDialog = false
          this.$http
            .post("api/organization/", {
              deptName: this.deptName,
              deptNum: this.form.deptNum,
              parentId: this.organization
            })
            .then(res => {
              if (res.data.code == 200) {
                this.$message({
                  message: '添加成功',
                  type: 'success'
                })
                this.takeList(1)
              } else if (res.data.code != 200) {
                this.$message.error('添加失败')
              }
            })
            .catch(function (err) {
              console.log(err)
            })
          this.empty()
        }
      }, // 添加组织机构
      closeDia() {
        this.deleteDialog = false
        this.$http
          .delete("api/organization", {
            data: this.deleteList
          })
          .then(res => {
            this.takeList(1)
            if (res.data.code == 400) {
              this.$message.error(res.data.message)
            } else if (res.data.code == 200) {
              this.$message({
                message: '删除成功',
                type: 'success'
              })
            }
          })
          .catch(function (err) {

          })
      }, // 关闭删除弹出框
      modificationNew() {
        this.addDialog = false
        this.$http
          .put("api/organization/" + this.modificData.deptId, {
            deptName: this.deptName,
            parentId: this.organization
          })
          .then(res => {
            if (res.data.code == 400) {
              this.$message.error(res.data.message)
            } else if (res.data.code == 200) {
              this.$message({
                message: '修改成功',
                type: 'success'
              })
              this.takeList(1)
            }
          })
          .catch(function (err) {

          })
        this.empty()
      }, // 确认修改
      modification() {
        this.isDis = true
        this.deleteList.length !== 1 ? this.$message.error({message: "请选择一条数据！"}) :
        this.addDialog = true
        this.diaTitle = '修改组织机构'
        this.addShow = false
        this.modificationShow = true
        this.form.deptNum = this.modificData.deptNum
        this.deptName = this.modificData.deptName
        this.organization = this.modificData.parentId
        this.isModific = true
      }, // 修改组织机构
      searchData() {
        // this.$http
        //   .get("api/organization/search/1/5?deptName=" + this.searchField)
        //   .then(res => {
        //     this.tableData = res.data.list
        //     this.total = res.data.total
        //   })
        //   .catch(function (err) {

        //   })
        this.takeList(1)
      }, // 查询数据
      empty() {
        this.form.deptNum = ''
        this.deptName = ''
        this.organization = ''
      }, // 清空弹出列表数据
      cancal() {
        this.empty()
        this.addDialog = false
      },
      sizeChange(value) {
        this.pagesize = value
        this.takeList(1)
      }, // 切换每页条数
      handleClose(done) {
        this.empty()
        done()
      } // 关闭弹出框
    },
    components: {
      deleteDia
    },
    mounted() {
      this.deptList()
      this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
      this.clientHeight = `${document.documentElement.clientHeight}`
      this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
      window.onresize = () => {
        return (() => {
          this.clientHeight = `${document.documentElement.clientHeight}`
          this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
        })()
      }
      this.takeList(1)
    }
  }

</script>

<style scoped>
  * {
    box-sizing: border-box;
  }

  .header-left {
    margin-top: 15px;
    float: left
  }

  /* .header-left button,
  .header-right button {
    border: none;
    background: #237AE4;
    color: #fff;
    height: 30px;
    border-radius: 5px;
    padding: 5px 15px;
  } */

  .header-right {
    margin-top: 15px;
    float: right;
    margin-right: 10px;
  }

  .header-left input {
    height: 40px;
    border-radius: 5px;
    outline: none;
    border: 1px solid #e0e0e0;
    margin-right: 10px;
  }

  .table {
    margin-top: 15px;
    width: 100%;
  }

  .downloadBut {
    margin-left: 10px;
  }

  .hr {
    width: 100%;
    border: 1px solid #f4f4f4;
    padding: 0;
    margin: 0;
    position: relative;
    top: -30px;
  }

  .inInput {
    margin-bottom: 10px;
    height: 36px;
    border-radius: 3px;
    outline: none;
    border: 1px solid #ccc;
    margin-left: 4px;
    width: 215px;
    padding: 0 10px;
  }

  label {
    margin-left: 29px;
  }

  label.import {
    margin-left: 20px;
  }

  label.import::before {
    content: '*';
    color: #f00;
    margin: 2px 3px 0 0;
  }
  .institutional /deep/ .el-dialog .el-dialog__body {
    text-align: center;
  }
  .institutional /deep/ .el-dialog .el-form-item__label {
    position: relative;
    left: 40px;
  }
  .institutional /deep/ .el-dialog .el-form-item__error {
    left: 50px;
  }
  .institutional /deep/ .el-dialog .el-form-item__content {
    left: -15px;
  }
  .institutional /deep/ .el-dialog .el-dialog__footer {
    text-align: center;
    position: relative;
    top: -10px;
  }
  .institutional /deep/ .el-dialog .el-dialog__body {
    padding: 20px 20px 25px 20px !important;
  }
  .institutional /deep/ .upload-demo {
    float: right;
    position: relative;
    left: 10px;
  }
  .institutional /deep/ .dialog-footer button {
    margin: 0 20px;
  }
  .el-upload-list {
    display: none !important;
  }

</style>

<style>
  .el-pagination {
    text-align: center;
  }
  .el-dialog__header {
    padding: 30px 20px 20px;
  }
  .el-dialog__title {
    font-size: 16px;
    color: #333333;
  }
  .el-dialog .el-dialog__body {
    padding: 20px 20px 10px 20px !important;
  }
</style>
