<!-- 通知公告 -->
<template>
	<div class="notification">
		<div class="container" v-if="$store.state.addnotific == false">
			<div class="header-left">
				<el-input v-model="searchField" placeholder="请输入用户名称/姓名" style="width:200px" @keyup.enter.native="searchData"></el-input>
				<el-button @click="searchData" style="margin: 0 10px 0 5px">查询</el-button>
			</div>
			<div class="header-right">
				<el-button type="primary" @click="addNew">添加</el-button>
				<el-button type="warning" @click="modification">修改</el-button>
				<el-button type="danger" @click="deleteInfo">删除</el-button>
				<el-button type="primary" @click="handlePublish">发布</el-button>
				<el-button type="primary" @click="handleCancel">取消发布</el-button>
			</div>
			<div class="table">
				<el-table @selection-change="mySelect" @select-all="allClick" @row-click="clickRow" ref="multipleTable" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
					<el-table-column :show-overflow-tooltip="true" type="selection" width="55">
					</el-table-column>
					<el-table-column :show-overflow-tooltip="true" prop="title" label="标题">
					</el-table-column>
					<el-table-column :show-overflow-tooltip="true" prop="name" label="发布对象">
					</el-table-column>
					<el-table-column :show-overflow-tooltip="true" prop="people" label="创建人">
					</el-table-column>
					<el-table-column :show-overflow-tooltip="true" prop="time" label="创建时间">
					</el-table-column>
					<el-table-column :show-overflow-tooltip="true" prop="status" label="状态">
					</el-table-column>
					<el-table-column label="操作">
						<template slot-scope="scope">
							<el-button type="text" @click="checkInfor(scope.row)">查看数据</el-button>
						</template>
					</el-table-column>
				</el-table>
			</div>
			<div class="block">
				<el-pagination :current-page.sync="currentPage" :page-sizes="[5, 10, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
				</el-pagination>
			</div>
		</div>
		<addnotific v-else-if="$store.state.addnotific == true"></addnotific>
	</div>
</template>

<script>
import addnotific from "./notification/addnotific";
export default {
  name: "notification",
  data() {
    return {
      total: 1, // 总条数
      currentPage: 1,
      pagesize: 5,
      searchField: "", // 查看数据搜索参数
      tableData: [
        {
          title: "1",
          name: "1",
          people: "2",
          time: "2",
          status: "2"
        }
      ],
      tableHeight: "",
      clientHeight: 0,
      offsetTop: 0
    }
  },
  methods: {
    sizeChange(value) {}, // 切换每页条数
    changePage(index) {}, // 翻页时的数据
    searchData() {}, // 搜索数据
    addNew() {
      this.$store.state.addnotific = true;
    }, // 新增
    modification() {}, // 修改
    deleteInfo() {}, // 删除
    handlePublish() {}, // 发布
    handleCancel() {}, // 取消发布
    checkInfor(row) {
    }, // 查看详情
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row);
    },
    mySelect(selection) {}, // 用户勾选table中的某一项
		allClick(selection) {},
		handleClose(done) {
			done()
		},
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    } // 替换table中thead的颜色
  },
  mounted() {
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 150);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 150);
      })()
    }
  },
  components: {
    addnotific
  }
};
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
  margin-bottom: 15px;
}
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 10px;
  margin-bottom: 15px;
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
</style>