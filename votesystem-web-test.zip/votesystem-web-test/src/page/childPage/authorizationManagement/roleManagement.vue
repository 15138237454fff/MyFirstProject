<!-- 角色管理 -->
<template>
  <div class="roleManagement">
    <div class="container" v-show="!showDetail">
      <div class="header-left">
        <el-input v-model="search" placeholder="请输入角色名称" style="width:70%" @keyup.enter.native="handleFind" clearable @clear="loadTable"></el-input>
        <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
      </div>
      <div class="header-right">
        <!-- <el-button type="primary" @click="releRole">关联角色</el-button> -->
        <el-button type="primary" @click="handleAdd">添加</el-button>
        <el-button type="danger" @click="handleDelete">删除</el-button>
      </div>
      <div style="clear: both"></div>
      <div class="table">
        <el-table :data="list" tooltip-effect="dark" border ref="list" :header-cell-style="tableHeaderColor" style="width: 100%;" @select-all="allClick" @selection-change="handleSelectionChange" @row-click="clickRow" :height="tableHeight">
          <el-table-column type="selection" width="55" :show-overflow-tooltip="true">
          </el-table-column>
          <el-table-column prop="roleName" label="角色名称" width="130px">
          </el-table-column>
          <el-table-column prop="createTime" label="创建时间">
          </el-table-column>
          <el-table-column prop="createUser" label="创建人">
          </el-table-column>
          <el-table-column prop="frontBack" label="后台/前台">
            <template slot-scope="scope">
              <span>{{ scope.row.frontBack == 0 ? '后台' : '前台' }}</span>
            </template>
          </el-table-column>
          <el-table-column prop="handle" label="操作">
            <template slot-scope="scope">
              <el-button type="text" @click="checkDetails(scope.row)">修改</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!--  -->
      <deleteDia ref="deleteDia"></deleteDia>
      <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
        <p class="hr"></p>
        <span>确定删除已选记录</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="deleteDialog = false">取 消</el-button>
          <el-button type="primary" @click="closeDia">确 定</el-button>
        </span>
      </el-dialog>
      <!-- 分页 -->
      <div class="block">
        <el-pagination :current-page.sync="pageList.pageNum" :page-sizes="[5, 10, 50]" @size-change="handleSizeChange" :page-size="pageList.pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="handleCurrentChange" :total="this.list == undefined ? null : pageList.total">
        </el-pagination>
      </div>
    </div>
    <addtree ref="addtree" v-show="showDetail"></addtree>
  </div>
</template>

<script>
import deleteDia from '@/components/deleteDia'
import addtree from './roleManage/addtree'
export default {
  name: 'roleManagement',
  data() {
    return {
      deleteDialog: false,
      roleRele: false,
      showDetail: false,
      roleData: [], // 关联用户
      roleValue: [], // 关联用户列表
      currentPage: 1, // 当前页
      pageSize: 10, //分页中每页显示条数
      frontBack: '', // 前台/后台
      addRoles: {
        domain: 1
      }, //添加角色表单
      updateRoles: {}, //修改角色表单
      selectionRow: null, //选择的那一行，修改
      search: "", //查询搜索字段
      pageList: {}, //分页s
      id: null,
      frontBackList: [{
        value: '选项1',
        label: '前台'
      }, {
        value: '选项2',
        label: '后台'
      }], // 前台/后台列表
      list: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      treeExpandedKeys: [],   // 记录打开节点的数组
      updateMenu: [],   // 记录默认打开选中节点的数组(点击修改时)
      updateSjqx: [],   // 记录默认打开选中节点的数组(点击修改时)
      checkedList: [], //选中的节点(菜单权限)
      checkedList3: [], //选中的节点(数据权限)
      checkedList4: [], //修改，选中的节点(菜单权限)
      checkedList5: [], //修改，选中的节点(数据权限)
      a: [],
      b: [],
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      roleId: '',
      roleInfo: {}
    }
  },
  mounted() {
    this.loadTable()
    this.offsetTop = this.$refs.list.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  },
  methods: {
    //关闭详情页
    closeVoteTable() {
      this.showDetail = false
      this.loadTable()
    },
    handleAdd() {
      this.showDetail = true
      this.$refs.addtree.parentAddRole()
    },
    //查看详情
    checkDetails(row) {
      this.showDetail = true
      this.$refs.addtree.queryRoleDetail(row.roleId)
    },
    releRole() {
      this.roleRele = true
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageList.pageSize = val;
      this.pageSize = this.pageList.pageSize;
      this.currentPage = this.pageList.pageNum;
      this.loadTable();
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.pageList.pageNum = currentPage;
      this.currentPage = this.pageList.pageNum;
      this.loadTable();
    },
    //列表序号
    indexMethod(index) {
      return (this.pageList.pageNum - 1) * this.pageList.pageSize + index + 1;
    },
    // 选择列表
    handleSelectionChange(selection) {
      if (selection.length == 0) {
        this.selectionRow = {}
      } else {
        this.selectionRow = selection[0]
        this.id = selection[0].roleId
      }
    },
    allClick(selection) {
      if (selection.length == 0) {
        this.selectionRow = {}
      } else {
        this.selectionRow = selection[0]
        this.id = selection[0].roleId
      }
    },
    //点击列表选中
    clickRow(row) {
      this.$refs.list.toggleRowSelection(row);
    },
    myChange(item1, item2, item3) {
      this.rightList = item1
    },
    //加载列表
    loadTable() {
      this.$http
        .post('api/role/list', {
          pageNum: this.currentPage,
          pageSize: this.pageSize,
          query: this.search
        })
        .then(res => {
          let myres = res.data.data
          this.list = myres.list
          this.pageList.total = myres.total
          this.pageList.pageNum = myres.pageNum
          this.pageList.pageSize = myres.pageSize
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    //查询
    handleFind() {
      this.loadTable()
    },
    addSubmit() {
      // console.log(this.addRoles.roleName.length)
      if (this.addRoles.roleName == undefined || this.addRoles.domain == undefined) {
        this.$message.error('请填写完整信息！')
        return
      }
      this.sysRole = this.addRoles
      this.sysRole.roleMenuList = this.checkedList
      this.$http
        .post("/api/SysRole/save", this.sysRole)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: "新增成功",
              type: "success"
            });
            this.addDialog = false;
          } else {
            this.$message({
              message: res.data.message,
              type: "error"
            })
          }
          this.loadTable()
        })
        .catch(function (err) {
          console.log(err);
        });
    },
    //删除
    handleDelete() {
      if (!this.isEmpty(this.id)) {
        this.$message.error('请选择一条数据')
        return;
      }
      this.deleteDialog = true
    },
    closeDia() {
      this.deleteSucc()
    },
    deleteSucc() {
      this.$http.delete('/api/role/' + this.id).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: '删除成功',
            type: "success"
          })
          this.loadTable()
        } else {
          this.$message({
            message: res.data.message,
            type: "error"
          })
        }
        this.loadTable()
        this.deleteDialog = false
      })
        .catch(err => {
          console.log(err)
        })
    },
    tableHeaderColor({
      row,
      column,
      rowIndex,
      columnIndex
    }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => { });
    }, // 关闭添加弹出框
    deleteInfo() {
      this.$refs.deleteDia.deleteDialog = true
      this.$refs.deleteDia.deleteInfo = '角色管理删除'
      this.deleteDialog = false
    } // 删除信息
  },
  components: {
    deleteDia,
    addtree
  }
}

</script>

<style scoped>
* {
  box-sizing: border-box;
}

.header-left {
  margin-top: 15px;
  float: left;
}

/* .header-left button,
  .header-right button {
    border: none;
    background: #237AE4;
    color: #fff;
    height: 30px;
    border-radius: 5px;
    padding: 5px 15px;
  } */

.header-right {
  margin-top: 15px;
  float: right;
}

.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}

.table {
  margin-top: 15px;
  width: 100%;
}

.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}

.inInput {
  margin-bottom: 10px;
  height: 36px;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
  margin-left: 4px;
  width: 215px;
  padding: 0 10px;
}

/* label {
    margin-left: 20px;
  } */
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 100%;
}
.roleManagement /deep/ .el-dialog .el-dialog__body {
  text-align: left;
  position: relative;
  top: -10px;
}
.roleManagement /deep/ .dialog-footer button {
  text-align: center;
  position: relative;
  top: -10px;
}
.roleManagement /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.roleManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
</style>
