<template>
  <div class="addnotific">
		<div class="top-title">
			<el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
		</div>
		<el-form ref="form" :model="form" label-width="100px">
			<el-row>
				<el-col :span="15">
					<el-form-item label="标题：">
						<el-input v-model="form.title"></el-input>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="15">
					<el-form-item label="发送对象：">
						<el-select v-model="form.department " placeholder="请选择"
						style="width: 49%; float: left;">
							<el-option
								v-for="item in departmentList"
								:key="item.value"
								:label="item.label"
								:value="item.value">
							</el-option>
						</el-select>
						<el-select
						style="width: 49%; float: right;"
							v-model="form.choose"
							multiple
							filterable
							allow-create
							default-first-option
							placeholder="请选择">
							<el-option
								v-for="item in chooseList"
								:key="item.value"
								:label="item.label"
								:value="item.value">
							</el-option>
						</el-select>
					</el-form-item>
				</el-col>	
			</el-row>
			<el-row>
				<el-col :span="20">
					<el-form-item label="相关附件：">
						<el-upload
							class="upload-demo"
							action="https://jsonplaceholder.typicode.com/posts/"
							:on-preview="handlePreview"
							:on-remove="handleRemove"
							:before-remove="beforeRemove"
							multiple
							:file-list="fileList">
							<el-button size="small" type="">点击上传</el-button>
						</el-upload>
					</el-form-item>
				</el-col>
			</el-row>
			<el-row>
				<el-col :span="20" style="position: relative;">
					<span class="fl">正文：</span>
					<quill-editor ref="myTextEditor"
						v-model="content"
						class="fl"
						:config="editorOption"
						@blur="onEditorBlur($event)"
						@focus="onEditorFocus($event)"
						@ready="onEditorReady($event)">
					</quill-editor>
				</el-col>
			</el-row>
		</el-form>	
  </div>
</template>

<script>
	import { quillEditor } from 'vue-quill-editor'
  export default {
    name: 'addnotific',
    data() {
      return {
				fileList: [],
				form: {
					sendPeople: 0,
					choose: []
				},
				content: '请输入正文',
				chooseList: [], // 选项列表
				departmentList: [], // 选项列表
				editorOption: {
					theme: 'snow',
					boundary: document.body, 
					modules: {
						toolbar: [
							['bold', 'italic', 'underline', 'strike'],
							['blockquote', 'code-block'],
							[{ 'header': 1 }, { 'header': 2 }],
							[{ 'list': 'ordered' }, { 'list': 'bullet' }],
							[{ 'script': 'sub' }, { 'script': 'super' }],
							[{ 'indent': '-1' }, { 'indent': '+1' }],
							[{ 'direction': 'rtl' }],
							[{ 'size': ['small', false, 'large', 'huge'] }],
							[{ 'header': [1, 2, 3, 4, 5, 6, false] }],
							[{ 'color': ['red', 'blue', 'green'] }, { 'background': [] }],
							[{ 'font': [] }],
							[{ 'align': [] }],
							['clean'],
							['link', 'image', 'video']
						]
					},
					placeholder: 'Insert text here ...',
					readOnly: false
				}
      }
		},
		methods: {
			handleRemove(file, fileList) {
      },
      handlePreview(file) {
      },
      beforeRemove(file, fileList) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      },
			exitList () {
				this.$store.state.addnotific = false
			},
			onEditorBlur(editor) {
				console.log('editor blur!', editor)
			},
			onEditorFocus(editor) {
				console.log('editor focus!', editor)
			},
			onEditorReady(editor) {
				console.log('editor ready!', editor)
			},
			onEditorChange({ editor, html, text }) {
				// console.log('editor change!', editor, html, text)
				this.content = html
			}
		},
		comments: {
			quillEditor
		}
  }

</script>

<style scoped>
.quill-editor {
	position: absolute;
	height: 200px;
	left: 58px;
	right: 0;
}
.fl {
	float: left;
	font-size: 14px;
	margin-left: 45px;
	color: #606266;
}
.top-title {
	width: 100%;
	height: 60px;
	background: #F2F2F2;
	line-height: 60px;		
}
.diyButton {
	background: none;
	border: none;
	color: #2779E3;
}
.addnotific /deep/ .el-form {
	margin-top: 15px;
}


</style>
