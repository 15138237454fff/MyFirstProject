<!-- 用户管理 -->
<template>
  <div class="userManagement">
    <div class="header-left">
      <el-input v-model="pageHelper.query" placeholder="请输入用户名/姓名" style="width:200px" @keyup.enter.native="takeList" clearable @clear="takeList"></el-input>
      <el-button @click="takeList" style="margin: 0 10px 0 5px">查询</el-button>
      <el-select v-model="pageHelper.status" placeholder="所有状态">
        <el-option v-for="item in GLOBEL.dict.userStatus" :key="item.value" :label="item.label" :value="item.value">
        </el-option>
      </el-select>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="addNew">添加</el-button>
      <el-button type="warning" @click="modification">修改</el-button>
      <el-button type="danger" @click="deleteInfo">删除</el-button>
      <el-button type="primary" @click="unlock">解锁</el-button>
      <el-button type="primary" @click="initializePas">密码初始化</el-button>
      <!-- <el-button type="primary" @click="exportDate">导出</el-button> -->
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table @selection-change="mySelect" @select-all="allClick" @row-click="clickRow" ref="multipleTable" :data="pageInfo.list" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
        <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="userName" label="用户名" width="200px">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="name" label="姓名" width="150px">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="roleName" label="所属角色" width="150px">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="organizationName" label="所属机构">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="phoneNum" label="手机号">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="status" label="状态" width="100px">
          <template slot-scope="scope">
            <span>{{getDictValue(scope.row.status,"userStatus")}}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination :current-page.sync="pageInfo.pageNum" :page-sizes="[10, 50, 100]" :page-size="pageInfo.pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="pageInfo.total" @size-change="sizeChange">
      </el-pagination>
    </div>
    <el-dialog :title="userTitle" :visible.sync="addDialog" :before-close="handleClose" width="690px">
      <p class="hr"></p>
      <el-form ref="numberValidateForm" :model="form" label-width="100px" :rules="rules">
        <el-row>
          <el-col :span="10">
            <el-form-item label="用户名：" :required="true" prop="userName">
              <el-input v-model="form.userName" style="width:200px" :readonly="modificationShow"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="姓名：">
              <el-input v-model="form.name" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属角色：">
              <el-select v-model="form.roleIds[0]" placeholder="请选择" style="width:200px">
                <el-option v-for="item in roleList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="所属机构：">
              <el-select v-model="form.organizationId" placeholder="请选择" style="width:200px">
                <el-option v-for="item in organizationList" :key="item.label" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="身份证号：">
              <el-input v-model="form.idCard" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="手机号码：">
              <el-input v-model="form.phoneNum" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="18">
            <el-form-item label="有效期：">
              <el-radio-group v-model="form.status">
                <el-radio :label="1">永久</el-radio>
                <el-radio :label="2">锁定</el-radio>
                <el-radio :label="3">临时</el-radio>
                <el-radio :label="4" v-show="modificationShow">失效</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14">
            <el-form-item label="有效时间：" v-show="form.status == 3||form.status == 4">
              <el-date-picker v-model="validTime" value-format="yyyy-MM-dd" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer" v-show="modificationShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="modificationNew">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-show="addShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="affirmNew">确 定</el-button>
      </span>
    </el-dialog>
    <deleteDia ref="deleteDia"></deleteDia>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import deleteDia from '@/components/deleteDia'
export default {
  name: 'userManagement',
  data() {
    return {
      form: {
        userName: '',
        validity: 0,
        time: '',
        roleIds: []
      },
      validTime: [],
      userTitle: '添加用户', // 添加或修改用户
      deleteDialog: false, // 控制删除弹出框
      organizationList: [], // 所属机构列表
      addDialog: false, // 控制添加弹出框
      deleteList: [], // 需要删除的列表
      modificData: {}, // 选中修改的数据
      addShow: true,
      modificationShow: false,
      roleIds: [],
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      pageHelper: {
        pageNum: 1,
        pageSize: 10
      },
      pageInfo: {},
      roleList: [],
      rules: {
        userName: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
      }
    }
  },
  watch: {
    'pageHelper.status': function () {
      this.takeList()
    }
  },
  methods: {
    unlock() {
      if (!this.isEmpty(this.modificData.userId)) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      this.$http
        .put("api/user/clear/" + this.modificData.userId)
        .then(res => {
          if (res.data.code != 200) {
            this.$message.error('解锁失败')
          } else if (res.data.code == 200) {
            this.$message({
              message: '解锁成功',
              type: 'success'
            })
            this.takeList()
          }
        })
        .catch(function (err) {

        })
    }, // 解锁
    initializePas() {
      this.deleteList.length != 1 ?
        this.$message.error({ message: "请选择一条数据！" }) :
        this.$http
          .put("api/user/reset/" + this.modificData.userId)
          .then(res => {
            if (res.data.code != 200) {
              this.$message.error('密码初始化失败')
            } else if (res.data.code == 200) {
              this.$message({
                message: '密码初始化成功',
                type: 'success'
              })
            }
          })
          .catch(function (err) {

          })
    }, // 密码初始化
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    mySelect(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.userId)
      })
    }, // 用户勾选table中的某一项
    allClick(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.userId)
      })
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    takeList() {
      this.$http
        .post("api/user/list/", this.pageHelper)
        .then(res => {
          this.pageInfo = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有列表数据
    addNew() {
      this.form = { roleIds: [] };
      this.addDialog = true
      this.userTitle = '添加用户'
      this.addShow = true
      this.modificationShow = false
    }, // 添加用户
    modification() {
      if (!this.isEmpty(this.modificData.userName)) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      this.getUserDetail();
      this.addDialog = true;
      this.addShow = false
      this.modificationShow = true
      this.userTitle = "修改用户"
    }, // 修改用户
    //查询用户详细信息
    getUserDetail() {
      this.$http
        .get("api/user/" + this.modificData.userName)
        .then(res => {
          if (res.data.code == 200) {
            this.form = res.data.data;
            if (this.form.status == 3) {
              this.validTime[0] = this.form.startTime
              this.validTime[1] = this.form.endTime
            }
          }
          else {
            this.$message.error(res.data.message)
          }
        })
    },
    deleteInfo() {
      if (this.deleteList.length < 1) {
        this.$message.error({ message: "请至少选择一条数据！" })
      }
      this.deleteDialog = true;
    }, // 删除信息
    closeDia() {
      this.deleteDialog = false
      this.$http
        .delete("api/user", { data: this.deleteList })
        .then(res => {
          if (res.data.code != 200) {
            this.$message.error(res.data.message)
          } else if (res.data.code == 200) {
            this.takeList()
            this.$message({
              message: '删除成功',
              type: 'success'
            })
          }
        })
        .catch(function (err) {

        })
    }, // 关闭删除弹出框
    affirmNew() {
      this.$refs["numberValidateForm"].validate((valid) => {
        if (valid) {
          this.submitAddInfo();
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    }, // 新增确定
    //添加用户提交
    submitAddInfo() {
      this.getValidTime();
      this.$http
        .post("api/user", this.form)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.addDialog = false
            this.takeList()
          } else if (res.data.code != 200) {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    deptList() {
      this.$http
        .get("api/organization/select")
        .then(res => {
          this.organizationList = res.data.data;
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有的组织机构数据
    changePage(index) {
      this.pageHelper.pageNum = index
      this.takeList()
    }, // 翻页时的数据
    sizeChange(value) {
      this.pageHelper.pageSize = value
      this.takeList()
    }, // 切换每页条数
    searchData() {
      this.takeList()
    }, // 查询数据99
    getValidTime() {
      if (this.form.status == 3) {
        this.form.startTime = this.validTime[0]
        this.form.endTime = this.validTime[1]
      }
    },//转换时间
    modificationNew() {
      this.getValidTime()
      this.$http
        .put("api/user/" + this.modificData.userId, this.form)
        .then(res => {
          this.takeList(1)
          if (res.data.code != 200) {
            this.$message.error(res.data.message)
          } else {
            this.addDialog = false
            this.$message({
              message: '修改成功',
              type: 'success'
            })
          }
        })
        .catch(function (err) {

        })

    }, // 确认修改
    exportDate() {
      window.location.href = "api/user/export"
    }, // 导出数据

    cancel() {
      this.addDialog = false
    },
    handleClose(done) {
      done()
    }, // 关闭弹出框
    takeRoleList() {
      this.$http
        .get("api/role/select")
        .then(res => {
          this.roleList = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询角色列表
  },
  components: {
    deleteDia
  },
  mounted() {
    this.takeList(1)
    this.deptList()
    this.takeRoleList()
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
}
/* .header-left button, .header-right button {
  border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
} */
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 10px;
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.inInput {
  margin-bottom: 10px;
  height: 36px;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
  margin-left: 4px;
  width: 215px;
  padding: 0 10px;
}
label {
  margin-left: 10px;
}
label.import {
  margin-left: 20px;
}
label.import::before {
  content: "*";
  color: #f00;
  margin: 2px 3px 0 0;
}
.el-upload-list {
  display: none !important;
}
.userManagements /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.userManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
.userManagement /deep/ .el-dialog__body {
  padding: 30px 20px 0px 20px;
}
.userManagement /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 25px 20px !important;
}
.userManagement /deep/ .el-dialog .el-dialog__body {
  text-align: center;
}
</style>
<style>
/* .el-select .el-input__inner {
  margin-bottom: 10px;
} */
.el-dialog__title {
  font-size: 16px;
  color: #333333;
}
.el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
</style>
