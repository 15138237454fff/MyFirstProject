<!-- 专家组管理 -->
<template>
  <div class="specialistManage">
    <div class="header-left">
      <el-input v-model="searchField" placeholder="请输入专家组名称" style="width:200px" @keyup.enter.native="searchData"></el-input>
      <el-button @click="searchData" style="margin: 0 10px 0 5px">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="addNew">添加</el-button>
      <el-button type="warning" @click="modification">修改</el-button>
      <el-button type="danger" @click="deleteInfo">删除</el-button>
    </div>
    <div class="table">
      <el-table @selection-change="mySelect" @select-all="allClick" @row-click="clickRow" ref="multipleTable" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
        <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="name" label="专家组名称">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="organizationName" label="所属机构">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="createUser" label="创建人">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="createTime" label="创建时间">
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="checkInfor(scope.row)">专家名单</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[5, 10, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
      </el-pagination>
    </div>
    <el-dialog :title="userTitle" :visible.sync="addDialog" :before-close="addhandleClose" width="690px">
      <p class="hr"></p>
      <el-form ref="form" :model="form" label-width="110px">
        <el-row>
          <el-col :span="10">
            <el-form-item label="专家组名称：">
              <el-input v-model="form.name" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="所属机构：">
              <el-select v-model="form.organizationNum" placeholder="请选择" style="width: 200px;">
                <el-option v-for="item in organizationList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; top: 325px;">
          <el-col :span="10">
            <el-form-item label="选择主席：">
              <el-select v-model="form.chairman" placeholder="请选择" style="width: 200px;">
                <el-option v-for="item in chairmanList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-transfer @change="myChange" style="text-align: left; display: inline-block; position: relative; left: -3px; top: -72px;" v-model="specialistData" filterable :titles="['待选专家', '已选专家']" :button-texts="['到左边', '到右边']" :format="{
					noChecked: '${total}',
					hasChecked: '${checked}/${total}'
				}" :data="transData">
      </el-transfer>
      <span slot="footer" class="dialog-footer" v-show="modificationShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="modificationNew">确 定</el-button>
      </span>
      <span slot="footer" class="dialog-footer" v-show="addShow">
        <el-button @click="cancel">取 消</el-button>
        <el-button type="primary" @click="affirmNew">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="专家名单" :visible.sync="detailsDialog" :before-close="handleClose" width="640px">
      <p class="hr"></p>
      <div class="table">
        <el-table ref="rollTable" :data="panelInfo.list" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" height="241">
          <el-table-column :show-overflow-tooltip="true" prop="userName" label="用户名">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="name" label="姓名">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="isChairman" label="是否为主席">
            <template slot-scope="scope">
              {{getDictValue(scope.row.isChairman,"isTrue")}}
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="organizationName" label="所属机构">
          </el-table-column>
        </el-table>
      </div>
      <div class="block">
        <el-pagination :current-page.sync="panelInfo.pageNum" :page-size="[10,20,30]" class="import" layout="total, prev, pager, next, jumper" @current-change="changePage2" :total="panelInfo.total">
        </el-pagination>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="detailsDialog = false">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'specialistManage',
  data() {
    return {
      deleteDialog: false,
      modificationShow: false,
      addShow: true,
      specialistData: [], // 已关联专家列表
      transData: [], // 所有专家列表
      addDialog: false,
      detailsDialog: false,
      total: 1, // 总条数
      total2: 5, // 专家名单总条数
      currentPage: 1,
      pagesize: 5,
      userTitle: '添加专家组',
      form: {},
      organizationList: [], // 所属机构列表
      chairmanList: [], // 主席列表
      searchField: "", // 查看数据搜索参数
      tableData: [],
      tableHeight: "",
      clientHeight: 0,
      offsetTop: 0,
      deleteList: [], // 删除的列表
      row: {},
      panelHelper: {
        pageNum: 1,
        pageSize: 10
      },
      panelInfo: {},
      modificData: {}
    }
  },
  methods: {
    modificationNew() {
      this.form.userId = this.specialistData
      this.$http
        .post("api/panel", this.form)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: '添加成功',
              type: 'success'
            })
            this.takeList(1)
          } else if (res.data.code != 200) {
            this.$message.error('添加失败')
          }
        })
        .catch(function (err) {
          console.log(err)
        })
      this.addDialog = false
      this.emptyList()
    }, // 确认修改
    affirmNew() {
      this.form.userId = this.specialistData
      this.$http.put("api/panel/" + this.modificData.id, this.form).then(res => {
        if (res.data.code == 200) {
          this.$message({
            message: '修改成功',
            type: 'success'
					})
					this.addDialog=false
          this.takeList(1)
        } else {
          this.$message.error(res.data.message)
        }
      })
    }, // 确认修改
    myChange(item1, item2, item3) {
      this.chairmanList = []
      item1.map((item, index) => {
        this.transData.map((_item, _index) => {
          if (item == _item.key) {
            let obj = {
              value: _item.key,
              label: _item.label
            }
            this.chairmanList.push(obj)
          }
        })
      })
    }, // 穿梭框数据改变
    sizeChange(value) {
      this.pagesize = value
      this.takeList(1)
    }, // 切换每页条数
    sizeChange2(value) { }, // 切换每页条数
    changePage2(index) {
      this.panelHelper.pageNum = index;
      this.takeRollList()
    }, // 翻页时的数据
    searchData() {
      this.takeList(1)
    }, // 搜索数据
    addNew() {
      this.userTitle = '添加专家组'
      this.addDialog = true
      this.modificationShow = true
      this.addShow = false
    }, // 新增
    modification() {
      if (!this.isEmpty(this.modificData.id)) {
        this.$message.error({ message: "请选择一条数据！" })
        return
      }
      //查询专家组详细信息
      this.$http
        .get("api/panel/" + this.modificData.id) // , {data: this.deleteList[0]}
        .then(res => {
          if (res.data.code == 200) {
            this.form = res.data.data
            this.specialistData = this.form.userId
            this.userTitle = '修改专家组'
            this.addDialog = true
            this.modificationShow = false
            this.addShow = true
          } else {
            this.$message.error({ message: res.data.message })
          }

        })

    }, // 修改
    deleteInfo() {
      this.deleteList.length == 1 ?
        this.deleteDialog = true :
        this.$message.error({ message: "请选择一条数据！" })
    }, // 删除
    closeDia() {
      this.deleteDialog = false
      this.$http
        .delete("api/panel/" + this.deleteList[0]) // , {data: this.deleteList[0]}
        .then(res => {
          this.takeList(1)
          if (res.data.code != 200) {
            this.$message.error(res.data.message)
          } else if (res.data.code == 200) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
          }
        })
        .catch(function (err) {

        })
    }, // 确认删除
    speciAll() {
      this.$http
        .get("api/specialist/all")
        .then(res => {
          res.data.data.list.map((item, index) => {
            let obj = {
              key: item.userId,
              label: item.name
            }
            this.transData.push(obj)
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 所有专家
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    mySelect(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.id)
      })
    }, // 用户勾选table中的某一项
    allClick(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.id)
      })
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    }, // 替换table中thead的颜色
    checkInfor(row) {
      this.detailsDialog = true
      this.row = row
      this.takeRollList()
    },
    takeRollList(index) {
      this.$http
        .get("/api/panel/" + this.row.id + "/" + this.panelHelper.pageNum + "/" + this.panelHelper.pageSize)
        .then(res => {
          if (res.data.code == 200) {
            this.panelInfo = res.data.data
          }
          else {
            this.$message.error({ message: res.data.message })
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    handleClose(done) {
      done()
    },
    addhandleClose(done) {
      done()
      this.emptyList()
    }, // 关闭弹出框
    cancel() {
      this.addDialog = false
    },
    takeList(index) {
      this.$http
        .post("api/panel/list/", {
          pageNum: index,
          pageSize: this.pagesize,
          query: this.searchField
        })
        .then(res => {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 拿取页面列表
    emptyList() {
      this.form = {}
      this.specialistData = []
      this.transData = []
      this.speciAll()
    }, // 清空弹出框数据
    deptList() {
      this.$http
        .get("api/organization/select")
        .then(res => {
          res.data.data.map((item, index) => {
            let obj = {}
            obj.value = item.value
            obj.label = item.label
            this.organizationList.push(obj)
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有的组织机构数据
  },
  mounted() {
    this.takeList(1)
    this.deptList()
    this.speciAll()
    this.offsetTop =
      this.$refs.multipleTable.$el.offsetTop -
      document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight =
      document.documentElement.clientHeight - (this.offsetTop + 150);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 150);
      })()
    }
  },
}

</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
  margin-bottom: 15px;
}
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 10px;
  margin-bottom: 15px;
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.specialistManage /deep/ .el-dialog .el-dialog__body {
  text-align: center;
}
.specialistManage /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.specialistManage /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 25px 20px !important;
}
.specialistManage /deep/ .dialog-footer button {
  margin: 0 20px;
}
.specialistManage /deep/ .el-transfer-panel {
  width: 245px;
}
</style>
