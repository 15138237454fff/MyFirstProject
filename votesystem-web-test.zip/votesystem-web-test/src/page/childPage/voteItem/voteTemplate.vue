<!-- 模板管理 -->
<template>
  <div class="voteTemplate">
    <div class="header-left">
      <el-input v-model="searchData" placeholder="请输入模板名称" style="width:70%" @keyup.enter.native="templateSearch"></el-input>
      <el-button @click="templateSearch" style="margin-left:5px">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="addNew">添加</el-button>
      <el-button type="warning" @click="modificationNew">修改</el-button>
      <el-button type="danger" @click="deleteInfo">删除</el-button>
      <!-- <el-button type="warning" @click="revocationInfor">恢复</el-button> -->
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table @selection-change="mySelect" ref="multipleTable" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" @row-click="clickRow" style="width: 100%;" :height="tableHeight">
        <el-table-column :show-overflow-tooltip="true" type="selection" width="55">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="templateName" label="模板名称" width="500">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="voteRuleType" label="投票规则">
          <template slot-scope="scope">
            <span>{{getDictValue(scope.row.voteRuleType,'voteRules')}}</span>
          </template>
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="createUser" label="创建人">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="createTime" label="创建时间">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="templateFile" label="操作">
          <template slot-scope="scope">
            <el-button type="text" @click="downLoad(scope.row)">下载查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog :title="userTitle" :close-on-click-modal="false" :visible.sync="templateShow" :before-close="handleClose" width="765px">
      <p class="hr"></p>
      <el-steps :active="activeNumber" align-center>
        <el-step title="基础信息" description=""></el-step>
        <el-step title="数据表" description=""></el-step>
        <el-step title="投票表" description=""></el-step>
        <el-step title="计票表" description=""></el-step>
        <el-step title="完成" description=""></el-step>
      </el-steps>
      <div class="dia-container">
        <div class="step1" v-if="activeNumber == 1">
          <el-form ref="form" :model="form">
            <el-row>
              <el-col :span="20">
                <el-form-item label="模板名称：">
                  <el-input v-model="form.name" style="width: 200px;"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col>
                <el-form-item label="投票规则：">
                  <el-select v-model="form.rule" placeholder="请选择" style="width:200px">
                    <el-option v-for="item in ruleList" :key="item.label" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col>
                <el-form-item label="所属部门：">
                  <el-select v-model="form.department" placeholder="请选择" style="width:200px">
                    <el-option v-for="item in departmentList" :key="item.label" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col>
                <el-form-item label="是否有附件：">
                  <el-radio-group v-model="form.radio">
                    <el-radio :label="0">否</el-radio>
                    <el-radio :label="1">是</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <span slot="footer" class="dialog-footer" style="position: absolute; bottom: -60px;">
            <el-button @click="cancel">取 消</el-button>
            <el-button type="primary" @click="addStep">下一步</el-button>
          </span>
        </div>
        <div class="step2" v-else-if="activeNumber == 2">
          <div class="mytable">
            <el-table :data="inforData1" tooltip-effect="dark" border :current-change="tableChange1" :header-cell-style="tableHeaderColor" style="width: 100%;" height="241">
              <el-table-column prop="columnName" :key="Math.random()" label="字段名">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.columnName"></el-input>
                </template>
              </el-table-column>
              <el-table-column prop="dataType" :key="Math.random()" label="字段类型">
                <template slot-scope="scope">
                  <span v-if="scope.row.dataType == '字符(附件)'">{{scope.row.dataType}}</span>
                  <el-select v-model="scope.row.dataType" placeholder="请选择" v-else-if="scope.row.dataType != '字符(附件)'">
                    <el-option v-for="item in typeList" :key="item.label" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="characterMaximumLength" :key="Math.random()" label="字段长度">
                <template slot-scope="scope">
                  <el-input v-model="scope.row.characterMaximumLength"></el-input>
                </template>
              </el-table-column>
              <el-table-column prop="nullAble" :key="Math.random()" label="是否为空">
                <template slot-scope="scope">
                  <el-radio-group v-model="scope.row.nullAble">
                    <el-radio :label="false">否</el-radio>
                    <el-radio :label="true">是</el-radio>
                  </el-radio-group>
                </template>
              </el-table-column>
              <el-table-column label="操作" :key="Math.random()" width="200">
                <template slot-scope="scope">
                  <el-button type="primary" icon="el-icon-top" circle style="font-size: 12px;" @click="topHandle1(scope.$index)"></el-button>
                  <el-button type="primary" icon="el-icon-bottom" circle style="font-size: 12px;" @click="downHandle1(scope.$index)"></el-button>
                  <el-button type="danger" icon="el-icon-delete" circle style="font-size: 12px;" @click="cancelHandle1(scope.$index)"></el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-button style="margin-top: 15px;" @click="addbasics">添加基础字段+</el-button>
          <el-form style="position: relative; top: 10px;" label-width="200px;">
            <el-row>
              <el-col :span="12">
                <el-form-item label="设置可查询字段：">
                  <el-select v-model="field1" placeholder="请选择" style="width:200px">
                    <el-option v-for="item in fieldList1" :key="item.value" :value="item.label">
                      {{item.label}}
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="设置附件字段：">
                  <el-select v-model="affix" placeholder="请选择" style="width:200px">
                    <el-option v-for="item in fieldList1" :key="item.label" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <span slot="footer" class="dialog-footer" style="position: absolute; bottom: 0; left: 200px;">
            <el-button @click="subtractStep">上一步</el-button>
            <el-button type="primary" @click="addStep">下一步</el-button>
          </span>
        </div>
        <div class="step3" v-else-if="activeNumber == 3">
          <div class="mytable">
            <el-table :data="inforData2" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" height="241">
              <el-table-column prop="columnName" label="字段名">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.columnName" placeholder="请选择" @change="((val)=>{changeHandle(val, scope.row)})">
                    <el-option v-for="item in fieldList1" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="dataType" label="字段类型">
              </el-table-column>
              <el-table-column prop="characterMaximumLength" label="字段长度">
              </el-table-column>
              <el-table-column prop="nullAble" label="是否为空">
              </el-table-column>
              <el-table-column label="操作" width="200">
                <template slot-scope="scope">
                  <el-button type="primary" icon="el-icon-top" circle style="font-size: 12px;" @click="topHandle2(scope.$index)"></el-button>
                  <el-button type="primary" icon="el-icon-bottom" circle style="font-size: 12px;" @click="downHandle2(scope.$index)"></el-button>
                  <el-button type="danger" icon="el-icon-delete" circle style="font-size: 12px;" @click="cancelHandle2(scope.$index)"></el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-button style="margin-top: 15px;" @click="addbasics2">添加字段+</el-button>
          <span slot="footer" class="dialog-footer" style="position: absolute; bottom: 0; left: 200px;">
            <el-button @click="subtractStep">上一步</el-button>
            <el-button type="primary" @click="addStep">下一步</el-button>
          </span>
        </div>
        <div class="step4" v-else-if="activeNumber == 4">
          <div class="mytable">
            <el-table :data="inforData3" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" height="241">
              <el-table-column prop="columnName" label="字段名">
                <template slot-scope="scope">
                  <el-select v-model="scope.row.columnName" placeholder="请选择" @change="((val)=>{changeHandle(val, scope.row)})">
                    <el-option v-for="item in fieldList1" :key="item.label" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column prop="dataType" label="字段类型">
              </el-table-column>
              <el-table-column prop="characterMaximumLength" label="字段长度">
              </el-table-column>
              <el-table-column prop="nullAble" label="是否为空">
              </el-table-column>
              <el-table-column label="操作" width="200">
                <template slot-scope="scope">
                  <el-button type="primary" icon="el-icon-top" circle style="font-size: 12px;" @click="topHandle3(scope.$index)"></el-button>
                  <el-button type="primary" icon="el-icon-bottom" circle style="font-size: 12px;" @click="downHandle3(scope.$index)"></el-button>
                  <el-button type="danger" icon="el-icon-delete" circle style="font-size: 12px;" @click="cancelHandle3(scope.$index)"></el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <el-button style="margin-top: 15px;" @click="addbasics3">添加字段+</el-button>
          <span slot="footer" class="dialog-footer" style="position: absolute; bottom: 0; left: 200px;" v-show="userTitle == '添加模板'">
            <el-button @click="subtractStep">上一步</el-button>
            <el-button type="primary" @click="finishAdd">完成添加</el-button>
          </span>
          <span slot="footer" class="dialog-footer" style="position: absolute; bottom: 0; left: 200px;" v-show="userTitle == '修改模板'">
            <el-button @click="subtractStep">上一步</el-button>
            <el-button type="primary" @click="finishModification">完成修改</el-button>
          </span>
        </div>
        <div class="step5" v-else-if="activeNumber == 5">
          <img src="../../../assets/img/bingo.png" alt="" style="width: 100px; position: relative; left: 300px; top: 35px;">
          <span style="position: absolute; bottom: 170px; left: 315px; font-size: 18px;">完成创建</span>
          <span slot="footer" class="dialog-footer" style="position: absolute; bottom: 0; left: 300px;">
            <el-button @click="templateShow = false">确 定</el-button>
          </span>
        </div>
      </div>
    </el-dialog>
    <el-dialog title="模板查看" :visible.sync="mytemplateShow" width="440px">
      <p class="hr"></p>
      <el-form label-position="right" label-width="100px">
        <el-row style="position: relative; left: -25px;">
          <el-col>
            <el-form-item label="汇总表">
              <el-input v-model="checkHz" :disabled="true" style="width: 250px;"></el-input>
              <el-button icon="el-icon-download" circle class="downloadBut" @click="downloadhanle1"></el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; left: -25px;">
          <el-col>
            <el-form-item label="计票表">
              <el-input v-model="checkJp" :disabled="true" style="width: 250px;"></el-input>
              <el-button icon="el-icon-download" circle class="downloadBut" @click="downloadhanle2"></el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; left: -25px;">
          <el-col>
            <el-form-item label="投票表">
              <el-input v-model="checkTp" :disabled="true" style="width: 250px;"></el-input>
              <el-button icon="el-icon-download" circle class="downloadBut" @click="downloadhanle3"></el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="mytemplateShow = false">确 定</el-button>
      </span>
    </el-dialog>
    <div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
      </el-pagination>
    </div>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="380px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'voteTemplate',
  data() {
    return {
      oldValue: [],
      typeList: [
        {
          label: '字符串',
          value: "VARCHAR"
        },
        {
          label: '整数',
          value: "INTEGER"
        },
        {
          label: '浮点数',
          value: "DECIMAL"
        },
        {
          label: '文本',
          value: "TEXT"
        }
      ], // 所有字段类型列表
      field1: '', // 可查询字段
      fieldList1: [], // 可查询字段列表
      inforData1: [],
      inforData2: [],
      inforData3: [],
      activeNumber: 1, // 当前进行的步数
      form: {
        radio: 0 // 是否有附件
      },
      affix: '', // 附件字段
      ruleList: [
        {
          value: 0,
          label: '同意制'
        },
        {
          value: 1,
          label: '打分制'
        },
        {
          value: 2,
          label: '排名制'
        }
      ], // 投票规则列表
      total1: 0,
      searchField: '',
      detTempList: [], // 删除的模板文件
      templateList: [
        {
          value: 1,
          label: '投票表'
        },
        {
          value: 2,
          label: '计票表'
        },
        {
          value: 3,
          label: '汇总表'
        }
      ], // 模板类型列表
      revocationShow: false, // 撤回显示
      deleteDialog: false, // 控制删除弹出框
      searchData: '', // 搜索的数据 
      fileList: [], // 上传文件列表
      templateShow: false,
      mytemplateShow: false,
      currentPage: 1, // 起始页
      pagesize: 10, // 每页条数
      tableData: [],
      total: 0, // 总条数'
      userTitle: '添加模板', // 添加或修改模板
      deleteList: [], // 需要删除的列表
      templateName: '', // 模板名称
      templateTypeId: '', // 模板id
      fileName: '', // 上传文件名称
      recoveryData: '', // 恢复数据的id
      page: 1,
      page1: 1,
      recoveryData2: [],
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      filesList1: [],
      filesList2: [],
      filesList3: [],
      checkHz: '', // 汇总表
      checkJp: '', // 计票表
      checkTp: '', // 投票表
      myres: [],
      departmentList: [], // 所属机构列表
    }
  },
  methods: {
    finishModification() {
      let [infor1, infor2, infor3] = [[], [], []]
      this.inforData1.map((item, index) => {
        let obj = {
          columnName: item.columnName,
          characterMaximumLength: item.characterMaximumLength,
          orderId: index + 1,
          dataType: item.dataType == 'VARCHAR' ? 'VARCHAR' :
            item.dataType == 'INTEGER' ? 'INTEGER' :
              item.dataType == 'DECIMAL' ? 'DECIMAL' :
                item.dataType == 'TEXT' ? 'TEXT' : 'VARCHAR',
          nullAble: item.nullAble,
          isAttach: item.isAttach
        }
        infor1.push(obj)
      })
      this.inforData2.map((item, index) => {
        let obj = {
          columnName: item.columnName,
          characterMaximumLength: item.characterMaximumLength,
          orderId: index + 1,
          dataType: item.dataType == '字符串' ? 'VARCHAR' :
            item.dataType == '整数' ? 'INTEGER' :
              item.dataType == '浮点数' ? 'DECIMAL' :
                item.dataType == '文本' ? 'TEXT' : 'VARCHAR',
          nullAble: item.nullAble == '否' ? false : true,
          isAttach: item.isAttach
        }
        this.fieldList1.map((item, index) => {
          if (obj.columnName == item.value) {
            obj.columnName = item.label
          }
        })
        infor2.push(obj)
      })
      this.inforData3.map((item, index) => {
        let obj = {
          columnName: item.columnName,
          characterMaximumLength: item.characterMaximumLength,
          orderId: index + 1,
          dataType: item.dataType == '字符串' ? 'VARCHAR' :
            item.dataType == '整数' ? 'INTEGER' :
              item.dataType == '浮点数' ? 'DECIMAL' :
                item.dataType == '文本' ? 'TEXT' : 'VARCHAR',
          nullAble: item.nullAble == '否' ? false : true,
          isAttach: item.isAttach
        }
        this.fieldList1.map((item, index) => {
          if (obj.columnName == item.value) {
            obj.columnName = item.label
          }
        })
        infor3.push(obj)
      })
      let sysTemplateDto = {
        templateName: this.form.name,
        voteRuleType: this.form.rule,
        isHaveattach: this.form.radio == 0 ? false : true,
        organizationId: this.form.department,
        templateTableDTOList: [
          {
            tableType: 0,
            searchField: this.field1,
            sysTemplateTableFieldList: infor1
          },
          {
            tableType: 1,
            searchField: this.field1,
            sysTemplateTableFieldList: infor2
          },
          {
            tableType: 2,
            searchField: this.field1,
            sysTemplateTableFieldList: infor3
          }
        ]
      }
      this.$http
        .put("/api/template" + this.modificData.id, sysTemplateDto)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: '修改模板成功',
              type: 'success'
            })
            this.activeNumber++
            this.empty()
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 完成修改
    modificationNew() {
      if (this.deleteList.length == 1) {
        this.userTitle = '修改模板'
        this.$http
          .get("api/template/updateInfoById/" + this.modificData.id)
          .then(res => {
            let mydata = res.data.data
            this.form.name = mydata.templateName
            this.form.rule = mydata.voteRuleType
            this.form.department = mydata.organizationId
            this.templateShow = true
            this.form.radio = mydata.isHaveattach == false ? 0 : 1
            mydata.templateTableDTOList[0].sysTemplateTableFieldList.map((item, index) => {
              let obj = {
                columnName: item.columnComment,
                characterMaximumLength: item.characterMaximumLength,
                isAttach: item.isAttach,
                dataType: item.dataType == 'VARCHAR' ? '字符串' :
                  item.dataType == 'INTEGER' ? '整数' :
                    item.dataType == 'DECIMAL' ? '浮点数' : '',
                nullAble: item.isNullAble
              }
              this.inforData1.push(obj)
            })
            mydata.templateTableDTOList[1].sysTemplateTableFieldList.map((item, index) => {
              let obj = {
                columnName: item.columnComment,
                characterMaximumLength: item.characterMaximumLength,
                isAttach: item.isAttach,
                dataType: item.dataType == 'VARCHAR' ? '字符串' :
                  item.dataType == 'INTEGER' ? '整数' :
                    item.dataType == 'DECIMAL' ? '浮点数' : '',
                nullAble: item.isNullAble == false ? '否' : '是'
              }
              this.inforData2.push(obj)
            })
            mydata.templateTableDTOList[2].sysTemplateTableFieldList.map((item, index) => {
              let obj = {
                columnName: item.columnComment,
                characterMaximumLength: item.characterMaximumLength,
                isAttach: item.isAttach,
                dataType: item.dataType == 'VARCHAR' ? '字符串' :
                  item.dataType == 'INTEGER' ? '整数' :
                    item.dataType == 'DECIMAL' ? '浮点数' : '',
                nullAble: item.isNullAble == false ? '否' : '是'
              }
              this.inforData3.push(obj)
            })
          })
          .catch(function (err) {
            console.log(err)
          })
      } else {
        this.$message.error({ message: "请选择一条数据！" })
      }
    }, // 修改模板
    deptList() {
      this.$http
        .get("api/organization/select")
        .then(res => {
          res.data.data.map((item, index) => {
            let obj = {}
            obj.value = item.value
            obj.label = item.label
            this.departmentList.push(obj)
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有的组织机构数据
    changeHandle(val, row) {
      let myval = ''
      this.fieldList1.map((item, index) => {
        if (item.value == val) {
          myval = item.label
        }
      })
      this.inforData1.map((item, index) => {
        if (myval == item.columnName) {
          row.characterMaximumLength = item.characterMaximumLength
          row.dataType = item.dataType == 'VARCHAR' ? '字符串' :
            item.dataType == 'INTEGER' ? '整数' :
              item.dataType == 'DECIMAL' ? '浮点数' :
                item.dataType == 'TEXT' ? '文本' : '字符(附件)'
          row.nullAble = item.nullAble == false ? '否' : '是'
        }
      })
    }, // 投票表字段选择
    downloadhanle1() {
      location.href = "api/template/down/" + this.myres[0].id
    },
    downloadhanle2() {
      location.href = "api/template/down/" + this.myres[2].id
    },
    downloadhanle3() {
      location.href = "api/template/down/" + this.myres[1].id
    },
    tableChange1(currentRow, oldCurrentRow) {

    }, // 改变表格
    finishAdd() {
      let [infor1, infor2, infor3] = [[], [], []]
      this.inforData1.map((item, index) => {
        let obj = {
          columnName: item.columnName,
          characterMaximumLength: item.characterMaximumLength,
          orderId: index + 1,
          dataType: item.dataType == 'VARCHAR' ? 'VARCHAR' :
            item.dataType == 'INTEGER' ? 'INTEGER' :
              item.dataType == 'DECIMAL' ? 'DECIMAL' :
                item.dataType == 'TEXT' ? 'TEXT' : 'VARCHAR',
          nullAble: item.nullAble,
          isAttach: item.isAttach,
          columnComment: item.columnName
        }
        infor1.push(obj)
      })
      this.inforData2.map((item, index) => {
        let obj = {
          columnName: item.columnName,
          characterMaximumLength: item.characterMaximumLength,
          orderId: index + 1,
          dataType: item.dataType == '字符串' ? 'VARCHAR' :
            item.dataType == '整数' ? 'INTEGER' :
              item.dataType == '浮点数' ? 'DECIMAL' :
                item.dataType == '文本' ? 'TEXT' : 'VARCHAR',
          nullAble: item.nullAble == '否' ? false : true,
          isAttach: item.isAttach
        }
        this.fieldList1.map((item, index) => {
          if (obj.columnName == item.value) {
            obj.columnName = item.label
            obj.columnComment = item.label
          }
        })
        infor2.push(obj)
      })
      this.inforData3.map((item, index) => {
        let obj = {
          columnName: item.columnName,
          characterMaximumLength: item.characterMaximumLength,
          orderId: index + 1,
          dataType: item.dataType == '字符串' ? 'VARCHAR' :
            item.dataType == '整数' ? 'INTEGER' :
              item.dataType == '浮点数' ? 'DECIMAL' :
                item.dataType == '文本' ? 'TEXT' : 'VARCHAR',
          nullAble: item.nullAble == '否' ? false : true,
          isAttach: item.isAttach
        }
        this.fieldList1.map((item, index) => {
          if (obj.columnName == item.value) {
            obj.columnName = item.label
            obj.columnComment = item.label
          }
        })
        infor3.push(obj)
      })
      let sysTemplateDto = {
        templateName: this.form.name,
        voteRuleType: this.form.rule,
        isHaveattach: this.form.radio == 0 ? false : true,
        organizationId: this.form.department,
        templateTableDTOList: [
          {
            tableType: 0,
            searchField: this.field1,
            sysTemplateTableFieldList: infor1
          },
          {
            tableType: 1,
            searchField: this.field1,
            sysTemplateTableFieldList: infor2
          },
          {
            tableType: 2,
            searchField: this.field1,
            sysTemplateTableFieldList: infor3
          }
        ]
      }
      this.$http
        .post("/api/template", sysTemplateDto)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              message: '添加模板成功',
              type: 'success'
            })
            this.activeNumber++
            this.empty()
            this.takeList(1)
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 完成添加
    topHandle(index, value) {
      if (index != 0) {
        value[index] = value.splice(index - 1, 1, value[index])[0]
      } else {
        value[index]
      }
    }, // 上移
    topHandle1(index) {
      this.topHandle(index, this.inforData1)
    },
    topHandle2() {
      this.topHandle(index, this.inforData2)
    },
    topHandle3() {
      this.topHandle(index, this.inforData3)
    },
    downHandle(index, value) {
      if (index != value.length - 1) {
        value[index] = value.splice(index + 1, 1, value[index])[0]
      } else {
        value.unshift(value.splice(index, 1)[0])
      }
    }, // 下移
    downHandle1(index) {
      this.downHandle(index, this.inforData1)
    },
    downHandle2() {
      this.downHandle(index, this.inforData2)
    },
    downHandle3() {
      this.downHandle(index, this.inforData3)
    },
    cancelHandle(index, value) {
      value.splice(index, 1)
    }, // 删除字段
    cancelHandle1(index) {
      this.cancelHandle(index, this.inforData1)
    },
    cancelHandle2(index) {
      this.cancelHandle(index, this.inforData2)
    },
    cancelHandle3(index) {
      this.cancelHandle(index, this.inforData3)
    },
    add1(index) {
      let obj = {
        columnName: '',
        dataType: '',
        characterMaximumLength: 0,
        nullAble: false
      }
      index.push(obj)
    },
    addbasics() {
      this.add1(this.inforData1)
    }, // 添加基础字段
    addbasics2() {
      this.add1(this.inforData2)
    }, // 添加基础字段
    addbasics3() {
      this.add1(this.inforData3)
    }, // 添加基础字段
    addStep() {
      this.activeNumber++
    }, // 下一步
    subtractStep() {
      this.activeNumber--
    }, // 上一步
    downLoad(row) {
      this.mytemplateShow = true
      this.$http
        .get("/api/template/downloadInfoById/" + row.id)
        .then(res => {
          let myres = res.data.data
          this.checkHz = myres[0].tableNameCn
          this.checkTp = myres[1].tableNameCn
          this.checkJp = myres[2].tableNameCn
          this.myres = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 下载模板
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    changePage(index) {
      this.page = index
      this.takeList(index)
    }, // 翻页时的数据
    changePage1(index) {
      this.page1 = index
      this.handleRevocat(index)
    },
    recoSelect(selection, row) {
      this.recoveryData2 = selection
      this.recoveryData = row.templateId
    },
    mySelect(selection) {
      this.deleteList = []
      this.modificData = selection[0]
      selection.map((item, index) => {
        this.deleteList.push(item.templateId)
      })
    }, // 用户勾选table中的某一项
    addNew() {
      this.templateShow = true
      this.userTitle = '添加模板'
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    // handleClose(done) {
    //   this.$confirm('')
    //     .then(_ => {
    //       done();
    //     })
    //     .catch(_ => {});
    // }, // 关闭添加弹出框
    takeList(index) {
      this.$http
        .post("api/template/list", {
          pageNum: index,
          pageSize: this.pagesize,
          query: this.searchData
        })
        .then(res => {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有列表数据
    affirmNew() {
      if (this.templateName == '' || this.templateTypeId == '' || this.fileName == '') {
        this.$message.error('请完整数据的填写')
      } else {
        this.templateShow = false
        this.$http
          .post("api/template/",
            {
              templateName: this.templateName,
              templateTypeId: this.templateTypeId,
              templateFile: this.fileName
            })
          .then(res => {
            this.takeList(1)
            if (res.data.code != 200) {
              this.$message.error(res.data.message)
            } else if (res.data.code == 200) {
              this.$message({
                message: '添加成功',
                type: 'success'
              })
            }
            this.empty()
          })
          .catch(function (err) {
            console.log(err)
          })
      }
    }, // 确认添加
    cancel() {
      this.templateShow = false
      this.empty()
      this.activeNumber = 1
    }, // 取消
    templateSearch() {
      this.takeList(1)
    },
    deleteInfo() {
      this.deleteList.length !== 0 ?
        this.deleteDialog = true :
        this.$message.error({ message: "请选择一条数据！" })
    },
    closeDia() {
      this.deleteDialog = false
      this.$http
        .delete("api/template", { data: this.deleteList })
        .then(res => {
          this.takeList(1)
          if (res.data.code != 200) {
            this.$message.error(res.data.message)
          } else if (res.data.code == 200) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
          }
        })
        .catch(function (err) {

        })
    }, // 关闭删除弹出框
    // revocationInfor () {
    //   this.revocationShow = true
    //   this.handleRevocat(1)
    // }, // 撤回数据
    handleRevocat(index) {
      this.detTempList = []
      this.$http
        .get("api/template/del/" + index + "/5")
        .then(res => {
          this.total1 = res.data.total
          res.data.list.map((item, index) => {
            let obj = {}
            let type = ''
            obj.templateId = item.templateId
            obj.templateName = item.templateName
            obj.updateTime = item.updateTime
            if (item.templateTypeId == '1') {
              type = '汇总表'
            } else if (item.templateTypeId == '2') {
              type = '投票表'
            } else {
              type = '计票表'
            }
            obj.templateType = type
            this.detTempList.push(obj)
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    recoveryDataFun() {
      if (this.recoveryData2.length != 1) {
        this.$message.error({ message: "请选择一条数据！" })
      } else {
        this.$http
          .put("api/template/recover/" + this.recoveryData)
          .then(res => {
            this.takeList(1)
            this.$message({
              type: 'success',
              message: '恢复成功'
            })
          })
          .catch(function (err) {

          })
        this.revocationShow = false
      }
    },
    sizeChange(value) {
      this.pagesize = value
      this.takeList(1)
    }, // 切换每页条数
    handleClose(done) {
      this.empty()
      done()
      this.activeNumber = 1
    }, // 关闭弹出框
    empty() {
      this.form = {}
      this.inforData1 = []
      this.inforData2 = []
      this.inforData3 = []
      this.fieldList1 = []
      this.field1 = ''
    },
    cmp(x, y) {
      if (x === y) {
        return true
      }
      if (!(x instanceof Object) || !(y instanceof Object)) {
        return false
      }
      if (x.constructor !== y.constructor) {
        return false
      }
      for (var p in x) {
        if (x.hasOwnProperty(p)) {
          if (!y.hasOwnProperty(p)) {
            return false
          }
          if (x[p] === y[p]) {
            continue
          }
          if (typeof (x[p]) !== "object") {
            return false
          }
          if (!Object.equals(x[p], y[p])) {
            return false
          }
        }
      }
      for (p in y) {
        if (y.hasOwnProperty(p) && !x.hasOwnProperty(p)) {
          return false
        }
      }
      return true
    }
  },
  mounted() {
    this.deptList()
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
    this.tableHeight
    this.takeList(1)
  },
  watch: {
    inforData1: {
      handler: function (oldValue, newValue) {
        let _this = this
        for (let i = 0; i < _this.oldValue.length; i++) {
          if (_this.cmp(_this.oldValue[i], newValue[i]) == false) {
            this.inforData2.map((item, index) => {
              if (item.columnName == i) {
                item.characterMaximumLength = newValue[i].characterMaximumLength
                item.dataType = newValue[i].dataType == 'VARCHAR' ? '字符串' :
                  newValue[i].dataType == 'INTEGER' ? '整数' :
                    newValue[i].dataType == 'DECIMAL' ? '浮点数' :
                      newValue[i].dataType == 'TEXT' ? '文本' : '字符(附件)'
                item.nullAble = newValue[i].nullAble == false ? '否' : '是'
              }
            })
          }
        }
        _this.fieldList1 = []
        _this.oldValue = []
        newValue.map((item, index) => {
          if (item.columnName != '') {
            let obj = {
              value: index,
              label: item.columnName
            }
            let obj2 = {
              columnName: item.columnName,
              characterMaximumLength: item.characterMaximumLength,
              dataType: item.dataType,
              isAttach: item.isAttach,
              nullAble: item.nullAble
            }
            _this.fieldList1.push(obj)
            _this.oldValue.push(obj2)
          }
        })
      },
      deep: true
    }
  },
}
</script>

<style scoped>
.el-input__inner {
  width: 217px !important;
}
.diaButton {
  position: relative;
}
/* .el-button--small {
    position: relative;
    top: -23px;
    left: 104px;
} */
.footer {
  width: 100%;
  text-align: center;
  margin-top: 15px;
}
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
}
/* .header-left button, .dia-left button, .header-right button{
  border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
} */
button.myButton {
  border: none;
  background: #237ae4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
}
.header-right {
  margin-top: 15px;
  float: right;
}
.header-left input,
.dia-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.mytable {
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.inInput {
  margin-bottom: 10px;
  height: 36px;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
  margin-left: 4px;
  width: 215px;
  padding: 0 10px;
}
label {
  margin-left: 0;
}
label.import {
  margin-left: 20px;
}
label.import::before {
  content: "*";
  color: #f00;
  margin: 2px 3px 0 0;
}
.dia-container {
  margin-top: 15px;
  width: 100%;
  height: 400px;
  position: relative;
}
.voteTemplate /deep/ .hanleDialog .el-dialog__body {
  text-align: center;
}
/* .voteTemplate /deep/ .el-dialog .el-form-item__label {
  position: relative;
  left: 40px;
} */
.voteTemplate /deep/ .diaButton {
  width: 200px;
  height: 40px;
}
.voteTemplate /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.voteTemplate /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 10px 20px !important;
}
.voteTemplate /deep/ .dialog-footer button {
  margin: 0 20px;
}
.voteTemplate /deep/ .el-dialog .el-dialog__body {
  padding: 20px 20px 25px 20px !important;
}
.step1 {
  width: 400px;
  margin-left: 210px;
  /* margin-top: 60px; */
  height: 240px;
  position: relative;
  top: 40px;
}
.step3,
.step4 {
  width: 100%;
  height: 360px;
  position: relative;
}
.step2 {
  width: 100%;
  height: 400px;
  position: relative;
}
</style>

<style>
.el-dialog__header {
  padding: 30px 20px 20px;
}
.el-dialog__title {
  font-size: 16px;
  color: #333333;
}
.el-dialog .el-dialog__body {
  padding: 20px 20px 10px 20px !important;
}
</style>