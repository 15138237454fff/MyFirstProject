<!-- 投票项目管理 -->
<template>
  <div class="voteManagement">
    <div class="header-left">
      <el-input v-model="searchInfo" placeholder="请输入项目名称" style="width:200px" @keyup.enter.native="loadTable(1)"></el-input>
      <el-button @click="loadTable(1)" style="margin-left:5px">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="handleAdd">添加</el-button>
      <el-button type="warning" @click="handleSee">修改</el-button>
      <el-button type="danger" @click="handleDelete">删除</el-button>
      <el-button type="primary" @click="handlePublish">发布</el-button>
      <el-button type="primary" @click="handleStart">启动</el-button>
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table ref="multipleTable" :data="list" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" @selection-change="handleSelectionChange" @row-click="clickRow" :height="tableHeight">
        <el-table-column type="selection" width="55" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="name" label="项目名称" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="voteRules" label="投票规则">
          <template slot-scope="scope">
            <span>{{getDictValue(scope.row.voteForm,'voteForm')}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="voteForm" label="投票形式">
          <template slot-scope="scope">
            <span>{{getDictValue(scope.row.voteForm,'voteForm')}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="startTime" label="投票时间" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <span>{{scope.row.startTime}}--{{scope.row.endTime}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="sponsor" label="主办单位" width="120px" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column label="专家组">
          <template slot-scope="scope">
            <el-button size="small" @click="voteCheck(scope.row.panelId)">查看专家名单</el-button>
          </template>
        </el-table-column>
        <el-table-column label="模板" width="120px">
          <template slot-scope="scope">
            <el-button size="small" @click="addTemplate(scope.row.templateId)">下载查看</el-button>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100px">
          <template slot-scope="scope">
            <span>{{getDictValue(scope.row.status,'projectStatus')}}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog :title="diaTitle" :visible.sync="dialogAdd" :before-close="handleClose" width="690px">
      <el-form ref="form" :model="form" label-width="100px">
        <el-row>
          <el-col :span="10">
            <el-form-item label="项目名称：" prop="itemName">
              <el-input v-model="form.name" style="width:200px" :disabled="isrelease"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="投票形式：" prop="shape">
              <el-select v-model="form.voteForm" placeholder="请选择" style="width: 200px;" :disabled="isrelease">
                <el-option v-for="item in shapeList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="投票规则：">
              <el-select v-model="form.voteRules" placeholder="请选择" style="width: 200px;" :disabled="isrelease" @change="ruleChange">
                <el-option v-for="item in ruleList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="主办单位：">
              <el-input v-model="form.sponsor" style="width:200px" :disabled="isrelease"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-show="form.voteRules==0">
          <el-col :span="10">
            <el-form-item label="通过规则：">
              <el-select v-model="form.passRules" placeholder="请选择" style="width: 200px;" :disabled="isrelease">
                <el-option v-for="item in GLOBEL.dict.passRules" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="通过率：">
              <el-input-number v-model.number="form.passRate" style="width:200px" :disabled="isrelease" :max="1" :min="0"></el-input-number>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="专家组：" prop="shape">
              <el-select v-model="form.panelId" placeholder="请选择" style="width: 200px;" :disabled="isrelease">
                <el-option v-for="item in specialistList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="投票模板：">
              <el-select v-model="form.templateId" placeholder="请选择" style="width: 200px;" :disabled="isrelease">
                <el-option v-for="item in tempList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="投票地点：" v-if="form.voteForm == 0 || form.voteForm == 1">
              <el-input v-model="form.address" style="width:200px"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2" v-if="form.voteForm == 0 || form.voteForm == 1">
            <el-form-item label="是否签到：" width="120px">
              <el-radio-group v-model="form.sign" style="position: relative; left: -29px;" :disabled="isrelease">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; top: 5px;">
          <el-col :span="10">
            <el-form-item label="投票时间：" prop="shape">
              <el-date-picker v-model="form.time" type="daterange" value-format="yyyy-MM-dd" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
              </el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; top: 5px;" v-if="form.voteRules == 0">
          <el-col :span="14">
            <el-form-item label="是否限制最高通过票数：" label-width="200px">
              <el-radio-group v-model="form.isLimit" style="position: relative; left: -29px;" :disabled="isrelease">
                <el-radio :label="0">是</el-radio>
                <el-radio :label="1">否</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :span="3" v-show="form.isLimit == 0">
            <el-input placeholder="请输入人数" v-model="form.maxPass" style="width: 150px !important; margin-left: 48px;" type="number" :disabled="isrelease">
              <template slot="append">人</template>
            </el-input>
          </el-col>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer" v-show="addBut">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button @click="addSubmit">确 定</el-button>
      </div>
      <div slot="footer" class="dialog-footer" v-show="modificBut">
        <el-button @click="closeDialog">取 消</el-button>
        <el-button @click="modificButSubmit">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="模板查看" :visible.sync="templateShow" width="440px">
      <p class="hr"></p>
      <el-form label-position="right" label-width="100px">
        <el-row style="position: relative; left: -25px; margin-bottom: 15px;">
          <el-col>
            <el-form-item label="汇总表">
              <el-input v-model="checkHz" :disabled="true" style="width: 250px;"></el-input>
              <el-button icon="el-icon-download" circle class="downloadBut" @click="downloadhanle1"></el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; left: -25px; margin-bottom: 15px;">
          <el-col>
            <el-form-item label="计票表">
              <el-input v-model="checkJp" :disabled="true" style="width: 250px;"></el-input>
              <el-button icon="el-icon-download" circle class="downloadBut" @click="downloadhanle2"></el-button>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row style="position: relative; left: -25px;">
          <el-col>
            <el-form-item label="投票表">
              <el-input v-model="checkTp" :disabled="true" style="width: 250px;"></el-input>
              <el-button icon="el-icon-download" circle class="downloadBut" @click="downloadhanle3"></el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="templateShow = false">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 分页 -->
    <div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
      </el-pagination>
    </div>
    <el-dialog title="投票名单" :visible.sync="polloptsShow" :before-close="handleClose3" width="700px">
      <p class="hr"></p>
      <div class="table">
        <el-table ref="voteTable" :data="checkList" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;">

          <el-table-column prop="userName" label="用户名">
          </el-table-column>
          <el-table-column prop="name" label="姓名">
          </el-table-column>
          <el-table-column prop="isChairman" label="是否为主席">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.isChairman,'isTrue')}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="organizationName" label="所属机构">
          </el-table-column>
        </el-table>
        <div class="block">
          <el-pagination :current-page.sync="currentPage1" :page-sizes="[5, 20, 50]" :page-size="pagesize1" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage1" :total="total1" @size-change="sizeChange1">
          </el-pagination>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="polloptsShow=false">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="发布" :before-close="handleClose2" :visible.sync="releaseShow" width="620px">
      <p class="hr"></p>
      <el-transfer :props="{ key: 'value', label: 'label'}"  @change="myChange2" style="text-align: left; display: inline-block; position: relative; left: 20px;" v-model="value1" filterable :titles="['待选发布对象', '已选发布对象']" :button-texts="['到左边', '到右边']" :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }" :data="releaseData">
      </el-transfer>
      <div slot="footer" class="dialog-footer">
        <el-button @click="releaseCancel">取 消</el-button>
        <el-button type="primary" @click="releaseSubmit">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="删除信息" :visible.sync="deleteDialog" width="400px">
      <p class="hr"></p>
      <span>确定删除已选记录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="closeDeleteDia">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'voteManagement',
  data() {
    return {
      ruleList: [
        {
          value: 0,
          label: '同意制'
        },
        {
          value: 1,
          label: '打分制'
        },
        {
          value: 2,
          label: '排名制'
        }
      ], // 投票规则列表
      shapeList: [
        {
          value: 0,
          label: '现场实名'
        },
        {
          value: 1,
          label: '现场匿名'
        },
        {
          value: 2,
          label: '网上实名'
        },
        {
          value: 3,
          label: '网上匿名'
        }
      ], // 投票形式列表
      templateList: [], // 投票模板列表
      tempList: [],
      specialistList: [], // 专家组列表
      currentPage: 1,
      deleteDialog: false, // 删除弹出框
      active: 1, // 步骤条步数
      isLimit: 1, // 是否限制投票通过数
      maxPass: 0, // 限制的人数
      chairman: '', // 主席
      cancelReleaseShow: false, // 取消发布弹出框
      model: {},
      pagesize: 10,
      total: 0,
      diaTitle: '新增项目',
      sign: 0, // 是否投票
      releaseData: [
        // {
        //   key: '(184805851)83987',
        //   label: 'xm0001'
        // },
        // {
        //   key: '(184831511)84434',
        //   label: 'xm0002'
        // },
        // {
        //   key: '0003',
        //   label: '123456'
        // },
        // {
        //   key: '0004',
        //   label: 'zj0001'
        // },
        // {
        //   key: '1',
        //   label: 'admin'
        // },
        // {
        //   key: 'c4ca3c1f8e2847e4a74f95970b1d1905',
        //   label: '875527'
        // }
      ], // 发布数据
      releaseShow: false, // 发布弹出款
      checkHz: '', // 查看汇总表
      checkJp: '', // 查看计票表
      checkTp: '', // 查看投票表
      checkList: [], // 查看投票名单
      voteDataList: [{
        college: '1111', // 学院
        name: '2222', // 姓名
        number: '3333', // 学号
        grade: '', // 年级
        professionName: '' // 授予学位专业名称
      },
      {
        college: '1111',
        name: '2222',
        number: '3333',
        grade: '',
        professionName: ''
      }],
      polloptsShow: false, // 投票数据弹出框
      starttime: '',// 时间
      value1: [],
      value2: [],
      value3: [],
      num: 0, // 参与人数
      summary: '', // 汇总表选择
      ticket: '', // 计票表选择
      vote: '', // 投票表选择
      templateShow: false, // 添加模板弹出框
      currentPage: 1, // 当前页
      pageSize: 10, //分页中每页显示条数
      projectEntity: {}, //查询参数，修改提交
      projectentity: {}, //新增提交
      dialogAdd: false, //新增弹窗
      dialogUpdate: false, //修改弹窗
      addList: {
        starttime: []
      }, //新增
      updateList: {}, //修改
      selectionRow: null, //选择的那一行，修改
      ID: null, //多选
      id: null,
      ids: [],
      summarySheet: [], // 投票表
      list: [],
      rightList: [], // 穿梭框右边列表
      releaseList: [], // 发布列表
      selectId: '', // 选择条目的id
      addBut: true,
      modificBut: false,
      myReleaseList: [], // 确认发布列表
      searchInfo: '', // 查询数据
      pagesize1: 5,
      voteId: '',
      total1: 0,
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      form: {},
      templateShow: false,
      isrelease: false, // 项目是否发布
      myres: []
    }
  },
  methods: {
    downloadhanle1() {
      location.href = "api/template/down/" + this.myres[0].id
    },
    downloadhanle2() {
      location.href = "api/template/down/" + this.myres[2].id
    },
    downloadhanle3() {
      location.href = "api/template/down/" + this.myres[1].id
    }, // 下载模板
    ruleChange(value) {
      this.tempList = this.templateList.filter(function (item) {
        return item.voteRuleType == value;
      })
      this.$set(this.form, "templateId", null);
    },
    clickRow(row) {
      this.id = row.id
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    changePage(index) {
      this.page = index
      this.loadTable(index)
    }, // 翻页时的数据
    changePage1(index) {
      this.page = index
      this.voteList(index)
    },
    voteCheck(id) {
      this.polloptsShow = true
      this.voteId = id
      this.voteList(1)
    }, // 投票数据查看
    voteList(index) {
      this.$http
        .get("/api/panel/" + this.voteId + "/" + index + "/" + this.pagesize1)
        .then(res => {
          if (res.data.code == 200) {
            this.checkList = res.data.data.list
            this.total1 = res.data.data.total
          }
          else {
            this.$message.error({ message: res.data.message })
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    myChange(item1, item2, item3) {
      this.rightList = item1
    },
    myChange2(item1, item2, item3) {
      this.myReleaseList = item1
    },
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val;
      //   this.loadTable();
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      //   this.loadTable();
    },
    //列表序号
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1
    },
    //加载列表
    loadTable(index) {
      this.$http
        .post("/api/project/list", {
          pageNum: index,
          pageSize: this.pageSize,
          query: this.searchInfo
        })
        .then(res => {
          this.list = res.data.data.list
          this.total = res.data.data.total
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    // 选择列表
    handleSelectionChange(selection) {
      this.releaseList = []
      this.deleteList = []
      // this.id = selection[0].id
      if (selection.length == 0) {
        this.modificData = {}
      } else {
        this.selectId = selection[0].id
        this.modificData = selection[0]
        selection.map((item, index) => {
          this.releaseList.push(item.id)
        })
      }
    },
    //查询
    handleFind() {
      this.$http
        .post(
          "/api/project/search?pageNum=" +
          this.currentPage +
          "&pageSize=" +
          this.pageSize, {
            projectEntity: this.projectEntity
          }
        )
        .then(res => {
          this.list = res.data.list
        })
        .catch(function (err) {
          console.log(err)
        });
    },
    // 新增
    handleAdd() {
      this.addBut = true
      this.modificBut = false
      this.dialogAdd = true
      this.diaTitle = '新增项目'
    },
    //新增提交
    addSubmit() {
      let obj = this.form
      obj.startTime = this.form.time[0]
      obj.endTime = this.form.time[1]
      this.$http.post("/api/project", obj).then(res => {
        if (res.data.code == 200) {
          this.$message(
            {
              type: 'success',
              message: '添加成功'
            }
          )
          this.dialogAdd = false
          this.empty()
        } else {
          this.$message.error(
            {
              message: '添加失败'
            }
          )
        }
        this.loadTable(1)
      })
        .catch(err => {
          console.log(err)
        })
    },
    modificSubmit() {

    }, // 确认修改
    closeDialog() {
      this.dialogAdd = false
      this.active = 1
      this.empty()
    }, // 关闭弹出框
    //修改查看详情
    handleSee() {
      if (this.releaseList.length != 1) {
        this.$message.error({ message: "请选择一条数据！" })
      } else if (this.modificData.status == '启动') {
        this.$message.error({ message: "已启动的项目不能修改" })
      } else {
        this.addBut = false
        this.modificBut = true
        this.dialogAdd = true
        this.diaTitle = '修改项目'
        this.$http.get("/api/project/" + this.modificData.id).then(res => {
          this.form = res.data.data
          this.form.time = (res.data.data.startTime + ',' + res.data.data.endTime).split(',')
          if (this.modificData.status == '未发布') {
            this.isrelease = false
          } else if (this.modificData.status == '已发布') {
            this.isrelease = true
          }
        })
          .catch(err => {
            console.log(err)
          })
      }
    },
    addCencal() {
      this.empty()
      this.dialogAdd = false
    }, // 点击取消
    modificButSubmit() {
      let obj = this.form
      obj.startTime = this.form.time[0]
      obj.endTime = this.form.time[1]
      if (this.isrelease == true) {
        this.$http
          .put("api/project/update/published/" + this.modificData.id, obj)
          .then(res => {
            if (res == undefined) {
              this.$message.error(
                {
                  message: '修改失败'
                }
              )
            } else if (res.data.code == 200) {
              this.$message(
                {
                  type: 'success',
                  message: '修改成功'
                }
              )
              this.dialogAdd = false
              this.loadTable(1)
            }
          })
          .catch(function (err) {

          })
      } else if (this.isrelease == false) {
        this.$http
          .put("api/project/update/unpublished/" + this.modificData.id, obj)
          .then(res => {
            if (res == undefined) {
              this.$message.error(
                {
                  message: '修改失败'
                }
              )
            } else if (res.data.code == 200) {
              this.$message(
                {
                  type: 'success',
                  message: '修改成功'
                }
              )
              this.dialogAdd = false
              this.loadTable(1)
            }
          })
          .catch(function (err) {

          })
      }
      this.isrelease = false
    }, // 确认修改
    //删除
    handleDelete() {
      if (this.releaseList.length != 1) {
        this.$message.error({ message: "请选择一条数据！" })
      } else if (this.modificData.status == '已发布') {
        this.$confirm(' 项目已发布,请先取消发布再删除!', '提示', {})
      } else if (this.modificData.status == '启动') {
        this.$confirm(' 项目已启动,请先取消启动再删除!', '提示', {})
      }
      else {
        this.deleteDialog = true
      }
      // this.loadTable(1)
    },
    closeDeleteDia() {
      // this.$http.put('/api/project/delete?id=' + this.modificData.id).then(res => {
      //   this.loadTable(1)
      //   res.data.code == 200?
      //   this.$message({
      //     message: res.data.data,
      //     type: "success"
      //   }) :
      //   this.$message('删除失败')
      // })
      // .catch(err => {
      //   console.log(err)
      // })
      this.$http
        .delete("api/project/" + this.modificData.id)
        .then(res => {
          this.loadTable(1)
          if (res.data.data.code != 200) {
            this.$message.error(res.data.message)
          } else if (res.data.data.code == 200) {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
          }
        })
        .catch(function (err) {

        })
      this.deleteDialog = false
    },
    //发布
    handlePublish() {
      // this.releaseData = []
      if (this.releaseList.length !== 1) { this.$message.error({ message: "请选择一条数据！" }) }
      else if (this.modificData.status == '已发布' || this.modificData.status == '启动') {
        this.$confirm('已启动或已发布项目不能发布', '提示', {})
      } else {
        this.releaseShow = true;
      }
    },
    //查询发布人员
    queryPublishUser() {
      this.$http.get("api/user/pm/select").then(res => {
        this.releaseData = res.data.data;
      }).catch(function (err) {
        console.log(err);
      })
    },
    //取消发布
    handleCancel() {
      if (this.releaseList.length !== 1) {
        this.$confirm('请选择一条已发布数据', '提示', {})
      } else if (this.modificData.status == '未发布') {
        this.$message.error('该项目未发布')
      } else if (this.modificData.status == '启动') {
        this.$message.error('该项目已启动')
      }
      else {
        this.cancelReleaseShow = true
      }
    },
    affirmCancelRelease() {
      this.$http.get('/api/project/cancel?id=' + this.modificData.id + "&hzid=" + this.modificData.hzid).then(res => {
        this.loadTable(1)
        if (res.data.code == 200) {
          this.$message({
            type: 'success',
            message: '取消发布成功'
          })
        } else {
          this.$message('取消发布失败')
        }
      })
        .catch(err => {
          console.log(err)
        })
      this.cancelReleaseShow = false
    }, // 确认取消发布
    //启动
    handleStart() {
      if (this.releaseList.length != 1) {
        this.$message.error({ message: "请选择一条数据！" })
      }
      else if (this.modificData.status == '2') {
        this.$message.error('该项目已启动')
      }
      else if (this.modificData.status == '1') {
        this.$http.put('/api/project/start/' + this.modificData.id).then(res => {
          if (res.data.code == 200) {
            this.loadTable(1)
            this.$message({
              message: '启动成功',
              type: "success"
            })
          } else {
            this.$message.error('启动失败')
          }
        })
          .catch(err => {
            console.log(err)
          })
      } else {
        this.$confirm('当前项目不能启动，请检查项目状态', '提示', {})
      }
    },
    releaseSubmit() {
      this.$http.post('/api/project/publish/' + this.modificData.id, this.myReleaseList).then(res => {
        if (res == undefined) {
          this.$message.error(
            {
              message: '发布失败'
            }
          )
        } else if (res.data.code == 200) {
          this.$message(
            {
              type: 'success',
              message: '发布成功'
            }
          )
          this.releaseShow = false
          this.loadTable(1)
        }
      })
        .catch(err => {
          console.log(err)
        })
      this.loadTable(1)
      this.value1 = []
    }, // 发布确认
    tableHeaderColor({
      row,
      column,
      rowIndex,
      columnIndex
    }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    addTemplate(templateId) {
      this.templateShow = true
      this.$http.get('/api/template/downloadInfoById/' + templateId).then(res => {
        this.myres = res.data.data
        this.checkHz = res.data.data[0].tableNameCn
        this.checkJp = res.data.data[2].tableNameCn
        this.checkTp = res.data.data[1].tableNameCn
      })
        .catch(err => {
          console.log(err)
        })
    },
    releaseCancel() {
      this.releaseShow = false
      this.value1 = []
    }, // 发布弹出框取消
    empty() {
      this.form = {}
      this.isrelease = false
    }, // 清空列表
    handleClose(done) {
      this.empty()
      done()
    }, // 关闭弹出
    handleClose2(done) {
      this.value1 = []
      done()
    }, // 关闭弹出
    handleClose3(done) {
      this.currentPage1 = 1
      done()
    },
    sizeChange(value) {
      this.pageSize = value
      this.loadTable(1)
    }, // 切换每页条数
    sizeChange1(value) {
      this.pageSize1 = value
      this.voteList(1)
    }, // 切换每页条数
    myspecialistList() {
      this.$http
        .get("/api/panel/select")
        .then(res => {
          this.specialistList = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    mytemplateList() {
      this.$http
        .get("/api/template/select")
        .then(res => {
          this.templateList = res.data.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }
  },
  mounted() {
    this.mytemplateList()
    this.myspecialistList()
    this.loadTable(1)
    this.queryPublishUser()
    // setTimeout(() => {
    //   this.tableHeight = window.innerHeight - this.$refs.multipleTable.$el.offsetTop
    // },100)
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  }
}

</script>

<style scoped>
* {
  box-sizing: border-box;
}

.header-left {
  margin-top: 15px;
  float: left;
}
.dialog-footer {
  text-align: center;
}
.el-col-3 {
  margin-left: 10px !important;
}
.step1,
.step2,
.step3 {
  margin-top: 10px;
  height: 530px;
}
.step1 .el-input,
.step2 .el-input,
.step3 .el-input {
  width: 400px !important;
}
.step2 .el-select {
  width: 380px !important;
}
.step2 .el-transfer {
  position: relative;
  left: 50px;
  margin-bottom: 85px;
}
.step1 .el-row {
  position: relative;
  left: -20px;
}
.step1 .el-row,
.step2 .el-row,
.step3 .el-row {
  height: 60px !important;
}

.step1 .el-select {
  width: 310px;
}
.step2 .dialog-footer {
  position: relative;
  top: 300px;
}
.step3 img {
  position: relative;
  top: 100px;
  left: 245px;
  height: 124px;
}
.step3 .dialog-footer {
  position: relative;
  top: 300px;
}
.hintTitle {
  position: relative;
  top: 275px;
  left: 275px;
  font-size: 16px;
}
/* .header-left button,
  .header-right button {
    border: none;
    background: #237AE4;
    color: #fff;
    height: 30px;
    border-radius: 5px;
    padding: 5px 15px;
  } */

.header-right {
  margin-top: 15px;
  float: right;
}

.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}

.table {
  margin-top: 15px;
  width: 100%;
}

.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}

label.import::before {
  content: "*";
  color: #f00;
  margin: 2px 3px 0 0;
}

.inInput {
  margin-bottom: 10px;
  height: 36px;
  border-radius: 3px;
  outline: none;
  border: 1px solid #ccc;
  margin-left: 4px;
  width: 215px;
  padding: 0 10px;
  position: relative;
}

label {
  margin-left: 29px;
}

label.import {
  margin-left: 20px;
}
.el-steps {
  width: 90%;
  margin-left: 7%;
}
.step1 .el-form {
  margin-left: 50px;
  margin-left: 16px;
}
.voteManagement /deep/ .dialog-footer button {
  margin: 0 20px;
}
.voteManagement /deep/ .el-dialog__footer {
  text-align: center;
}
.voteManagement /deep/ .el-form-item {
  margin-bottom: 10px !important;
}

.voteManagement /deep/ .el-input--suffix .el-input__inner {
  margin-bottom: 10px;
}
</style>

<style>
.el-pagination {
  text-align: center;
}
.el-step__title {
  position: relative;
  left: -10px;
}
.el-step__head.is-process {
  color: #c0c4cc;
  border-color: #c0c4cc;
}
.el-step__title.is-process {
  color: #c0c4cc;
}
</style>
