<!-- 投票参数设置 -->
<template>
  <div class="voteNumber">
		<div class="in-voteNumber">
			<el-row>
				<el-form :model="number" label-width="140px">
					<el-form-item label="投票委员会人数：" prop="name">
						<input type="number" v-model="number.name">
						<el-button type="primary" class="saveBut" @click="saveClick">保存</el-button>
					</el-form-item>
					<el-form-item label="会议最低开启人数：" prop="name">
						<input type="number" v-model="number.name2">
						<el-button type="primary" class="saveBut" @click="saveClick2">保存</el-button>
					</el-form-item>
				</el-form>
			</el-row>	
		</div>
	</div>
</template>
  
<script>
	export default {
		name: 'voteNumber',
		data () {
			return {
				myInput: '', // 投票委员会人数
				number: {
					name: ''
				}
			}
		},
		methods: {
			saveClick () {
			if(this.number.name >= 0) {
				this.$http
					.put("api/sys/update", {
						id: 1,
						value: this.number.name
					})
						.then(res => {
							if(res.data.code == 200) {
								this.$message({
									type: "success",
									message: "保存成功"
								})
							}
					})
					.catch(function(err) {                                                                                                                                                                                 
					
					})
				} else {
					this.$message({
						message: "请输入正确的参数",
						type: "error"
					})
				}
			},
			saveClick2 () {
			if(this.number.name >= 0) {
				this.$http
					.put("api/sys/update", {
						id: 2,
						value: this.number.name2
					})
						.then(res => {
							if(res.data.code == 200) {
								this.$message({
									type: "success",
									message: "保存成功"
								})
							}
					})
					.catch(function(err) {                                                                                                                                                                                 
					
					})
				} else {
					this.$message({
						message: "请输入正确的参数",
						type: "error"
					})
				}
			}
		},
		created () {
			this.$http
				.get("api/sys/1/5")
				.then(res => {
					console.log(res.data.data.list[0].value)
					this.number.name = res.data.data.list[0].value
					this.number.name2 = res.data.data.list[1].value
				})
				.catch(function(err) {                                                                                                                                                                                 
				
				})
		}
	}
</script>

<style scoped>
.in-voteNumber {
	width: 500px;
	position: absolute;
	left: 50%;
	margin-left: -250px;
	top: 100px;
}
.in-voteNumber .el-input {
	width: 270px;
}
.el-button--primary {
	float: right;
}
input {
	height: 38px;
	width: 250px;
	border-radius: 3px;
	outline: none;
  border: 1px solid #ccc;
	padding-left: 5px;
}
</style>
  