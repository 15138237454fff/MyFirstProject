<!-- 投票签到管理 -->
<template>
  <div class="managementVote">
    <div class="header-left">
			<input type="text">
			<button>查询</button>
			</div>
			<div class="header-right">
			<button>添加</button>
			<button>修改</button>
			<button>删除</button>
		</div>
		<div style="clear: both"></div>
    <div class="table">
      <el-table
        ref="multipleTable"
        :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
        tooltip-effect="dark"
        border
        :header-cell-style="tableHeaderColor"
        style="width: 100%;">
        <el-table-column
					:show-overflow-tooltip="true"
          type="selection"
          width="55">
        </el-table-column>
        <el-table-column
					:show-overflow-tooltip="true"
          prop="itemID"
          label="项目ID">
        </el-table-column>
        <el-table-column
					:show-overflow-tooltip="true"
          prop="itemName"
          label="项目名称">
        </el-table-column>
        <el-table-column
					:show-overflow-tooltip="true"
          prop="time"
          label="时间">
        </el-table-column>
        <el-table-column
					:show-overflow-tooltip="true"
          prop="place"
          label="地点">
        </el-table-column>
        <el-table-column
					:show-overflow-tooltip="true"
          prop="system"
          label="签到系统">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
          prop="IPaddress"
          label="IP地址">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
          prop="status"
          label="状态">
        </el-table-column>
      </el-table>
		</div>
		<div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 20, 50]" :page-size="5" class="import"
        layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total">
      </el-pagination>
    </div>
	</div>
</template>

<script>
export default {
  name: 'managementVote',
  data () {
    return {
      currentPage: 1, // 起始页
      pagesize: 5, // 每页条数
      tableData: [{
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间``
					place: '4444', // 地点
					system: '', // 签到系统
					IPaddress: '', // IP地址
          status: '' // 项目状态
        },
        {
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间
					place: '4444', // 地点
					system: '', // 签到系统
					IPaddress: '', // IP地址
          status: '' // 项目状态
        },
        {
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间
					place: '4444', // 地点
					system: '', // 签到系统
					IPaddress: '', // IP地址
          status: '' // 项目状态
        },
        {
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间
					place: '4444', // 地点
					system: '', // 签到系统
					IPaddress: '', // IP地址
          status: '' // 项目状态
        },
        {
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间
					place: '4444', // 地点
					system: '', // 签到系统
					IPaddress: '', // IP地址
          status: '' // 项目状态
        },
        {
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间
					place: '4444', // 地点
					system: '', // 签到系统
					IPaddress: '', // IP地址
          status: '' // 项目状态
        },
      ]
    }
  },
  methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    } // 替换table中thead的颜色
  }
}
</script>

<style scoped>

* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left
}
.header-left button, .header-right button {
  border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
}
.header-right {
  margin-top: 15px;
  float: right
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}

</style>

<style>

.el-pagination {
		text-align: center;
}    

</style>
