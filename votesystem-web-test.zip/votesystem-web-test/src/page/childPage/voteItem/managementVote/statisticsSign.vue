<!-- 签到数据统计 -->
<template>
  <div class="statisticsSign">
    <div class="header-left">
      <input type="text">
      <button @click="handleFind">查询</button>
    </div>
    <!-- <div class="header-right">
      <button>添加</button>
      <button>修改</button>
      <button>删除</button>
    </div> -->
    <div style="clear: both"></div>
    <div class="table">
      <el-table ref="multipleTable"
        :data="list" tooltip-effect="dark"
        border :header-cell-style="tableHeaderColor" style="width: 100%;"
        @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55">
        </el-table-column>
        <el-table-column prop="itemCode" label="项目编号">
        </el-table-column>
        <el-table-column prop="itemName" label="项目名称">
        </el-table-column>
        <el-table-column prop="time" label="时间">
        </el-table-column>
        <el-table-column prop="place" label="地点">
        </el-table-column>
        <el-table-column prop="status" label="状态">
        </el-table-column>
        <el-table-column prop="shouldPeople" label="应到人数">
        </el-table-column>
        <el-table-column prop="signPeople" label="签到人数">
        </el-table-column>
        <el-table-column prop="noPeople" label="未签到人数">
        </el-table-column>
        <el-table-column prop="noPeople" label="签到统计">
          <el-button size="small" @click="handleStatistic">签到统计表</el-button>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="投票项目签到统计表" :visible.sync="statisticTable">
      <el-table :data="statisticData" border>
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="name" label="姓名"></el-table-column>
        <el-table-column prop="tel" label="手机号码"></el-table-column>
        <el-table-column prop="status" label="签到状态"></el-table-column>
        <el-table-column prop="time" label="签到时间"></el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button @click="statisticTable = false">取 消</el-button>
        <el-button type="primary" @click="handleExport">导出</el-button>
      </div>
    </el-dialog>
    <!-- 分页 -->
    <div class="block" style="margin-top:15px;text-align:center">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
        :current-page="currentPage" :page-sizes="[50, 100, 150, 200]" :page-size="50"
        layout="total, sizes, prev, pager, next, jumper"
        :total="this.list == undefined ? null : list.length"></el-pagination>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'systemSign',
    data() {
      return {
        currentPage: 1, // 起始页
        pagesize: 5, // 每页条数
        statisticTable: false, //签到统计表
        currentPage: 1, // 当前页
        pageSize: 50, //分页中每页显示条数
        selectionRow: null, //选择的那一行，修改
        ID: null, //多选
        id: null,
        ids: [],
        list: [{
            itemCode: '1111', // 项目ID
            itemName: '2222', // 项目名称
            time: '3333', // 时间
            place: '4444', // 地点
            shouldPeople: '1', // 应到人数
            signPeople: '2', // 签到人数
            noPeople: '3', // 未签到人数
            status: '7777'
          },
          {
            itemCode: '1111',
            itemName: '2222',
            time: '3333',
            place: '4444',
            shouldPeople: '1',
            signPeople: '2',
            noPeople: '3',
            status: '7777'
          },
          {
            itemCode: '1111',
            itemName: '2222',
            time: '3333',
            place: '4444',
            shouldPeople: '1',
            signPeople: '2',
            noPeople: '3',
            status: '7777'
          },
          {
            itemCode: '1111',
            itemName: '2222',
            time: '3333',
            place: '4444',
            shouldPeople: '1',
            signPeople: '2',
            noPeople: '3',
            status: '7777'
          },
          {
            itemCode: '1111',
            itemName: '2222',
            time: '3333',
            place: '4444',
            shouldPeople: '1',
            signPeople: '2',
            noPeople: '3',
            status: '7777'
          },
          {
            itemCode: '1111',
            itemName: '2222',
            time: '3333',
            place: '4444',
            shouldPeople: '1',
            signPeople: '2',
            noPeople: '3',
            status: '7777'
          },
          {
            itemCode: '1111',
            itemName: '2222',
            time: '3333',
            place: '4444',
            shouldPeople: '1',
            signPeople: '2',
            noPeople: '3',
            status: '7777'
          }
        ],
        statisticData: []
      }
    },
    mounted() {
      this.loadTable()
    },
    methods: {
      //改变列表页条数大小回调函数
      handleSizeChange(val) {
        this.pageSize = val;
        //   this.loadTable();
      },
      //改变列表页当前页回调函数
      handleCurrentChange(currentPage) {
        this.currentPage = currentPage;
        //   this.loadTable();
      },
      //列表序号
      indexMethod(index) {
        return (this.currentPage - 1) * this.pageSize + index + 1;
      },
      //加载列表
      loadTable() {
        // this.$http
        //   .get("/api/project/showList", {
        //     params: {
        //       pageNum: this.currentPage,
        //       pageSize: this.pageSize
        //     }
        //   })
        //   .then(res => {
        //     console.log(res.data.list)
        //     this.list = res.data.list
        //   })
        //   .catch(function (err) {
        //     console.log(err)
        //   })
      },
      //查询
      handleFind() {
        // this.$http
        //   .post()
        //   .then(res => {
        //     console.log(res.data)
        //     this.list = res.data.list
        //   })
        //   .catch(function (err) {
        //     console.log(err)
        //   })
      },
      // 选择列表
      handleSelectionChange(selection) {
        if (selection.length == 0) {
          this.selectionRow = {}
        } else {
          this.selectionRow = selection[0]
          this.id = selection[0].id
          // this.id = parseInt(this.id)
          this.ids = []
          selection.forEach(item => {
            this.ids.push(item.id)
          });
          // console.log(this.ids)
        }
      },
      //签到统计表
      handleStatistic() {
        this.statisticTable = true
      },
      //导出
      handleExport() {
        this.statisticTable = false
      },
      tableHeaderColor({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (rowIndex === 0) {
          return 'background-color: #F2F2F2;font-weight: 500;'
        }
      }, // 替换table中thead的颜色
    }
  }

</script>

<style scoped>
  * {
    box-sizing: border-box;
  }

  .header-left {
    margin-top: 15px;
    float: left
  }

  .header-left button,
  .header-right button {
    border: none;
    background: #237AE4;
    color: #fff;
    height: 30px;
    border-radius: 5px;
    padding: 5px 15px;
  }

  .header-right {
    margin-top: 15px;
    float: right
  }

  .header-left input {
    height: 40px;
    border-radius: 5px;
    outline: none;
    border: 1px solid #e0e0e0;
    margin-right: 10px;
  }

  .table {
    margin-top: 15px;
    width: 100%;
  }

</style>

<style>
  .el-pagination {
    text-align: center;
  }

</style>
