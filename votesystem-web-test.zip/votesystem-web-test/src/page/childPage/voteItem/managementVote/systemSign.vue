<!-- 签到系统管理 -->
<template>
  <div class="systemSign">
    <div class="header-left">
      <input type="text" v-model="search">
      <button @click="handleFind">查询</button>
    </div>
    <div class="header-right">
      <button @click="handleAdd">添加</button>
      <button @click="handleSee">修改</button>
      <button @click="handleDelete">删除</button>
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table ref="multipleTable" :data="list" tooltip-effect="dark" border
        :header-cell-style="tableHeaderColor" style="width: 100%;"
        @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55">
        </el-table-column>
        <el-table-column label="序号" align="center" width="80" type="index">
        </el-table-column>
        <el-table-column label="项目名称" align="center">
          <template slot-scope="scope">
            <span>{{ scope.row.hymc }}</span>
          </template>
        </el-table-column>
        <el-table-column label="IP地址" align="center">
          <template slot-scope="scope">
            <span>{{ scope.row.ip }}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" align="center">
          <template slot-scope="scope">
            <!-- <span>{{ scope.row.sfqy }}</span> -->
            <el-switch v-model="scope.row.qy" @change="handleSwitch" active-value="1"
              inactive-value="2" disabled></el-switch>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="添加签到系统" :visible.sync="dialogAdd" width="400px">
      <p class="hr"></p>
      <label for="" class="import">项目名称：<input type="text" class="inInput"
          v-model="addList.hymc"></label><br />
      <label for="" class="import">IP地址：<input type="text" class="inInput" v-model="addList.ip"
          style="left: 15px;"></label><br />
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogAdd = false">取 消</el-button>
        <el-button type="primary" @click="addSubmit">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="修改签到系统" :visible.sync="dialogUpdate" width="400px">
      <p class="hr"></p>
      <label for="" class="import">项目名称：<input type="text" class="inInput"
          v-model="updateList.hymc"></label><br />
      <label for="" class="import">IP地址：<input type="text" class="inInput" v-model="updateList.ip"
          style="left: 15px;"></label><br />
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogUpdate = false">取 消</el-button>
        <el-button type="primary" @click="handleUpdate">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 分页 -->
    <div class="block" style="margin-top:15px;text-align:center">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
        :current-page="currentPage" :page-sizes="[50, 100, 150, 200]" :page-size="50"
        layout="total, sizes, prev, pager, next, jumper"
        :total="this.list == undefined ? null : list.length"></el-pagination>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'systemSign',
    data() {
      return {
        systemTitle: '添加签到系统',
        systemSignShow: false, // 控制弹出框
        currentPage: 1, // 当前页
        pageSize: 50, //分页中每页显示条数
        signmeets: {}, //列表，查询传参
        search: "", //查询搜索字段
        dialogAdd: false, //新增弹窗
        dialogUpdate: false, //修改弹窗
        addList: {}, //新增
        updateList: {}, //修改
        selectionRow: null, //选择的那一行，修改
        list1: [], //列表数据
        list: [{
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '1' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '1' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '1' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '2' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '1' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '2' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '1' // 状态
          },
          {
            hymc: '2222', // 项目名称
            ip: '3333', // IP地址
            qy: '2' // 状态
          }
        ]
      }
    },
    mounted() {
      this.loadTable();
    },
    methods: {
      //改变列表页条数大小回调函数
      handleSizeChange(val) {
        this.pageSize = val;
        //   this.loadTable();
      },
      //改变列表页当前页回调函数
      handleCurrentChange(currentPage) {
        this.currentPage = currentPage;
        //   this.loadTable();
      },
      //列表序号
      indexMethod(index) {
        return (this.currentPage - 1) * this.pageSize + index + 1;
      },
      //加载列表
      loadTable() {
        this.$http
          .post(
            "/api/signmeets/loadTable?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize, {
              signmeets: this.signmeets
            }
          )
          .then(res => {
            // console.log(res.data.list);
            this.list = res.data.list;
          })
          .catch(function (err) {
            console.log(err);
          });
      },
      // 选择列表
      handleSelectionChange(selection) {
        if (selection.length == 0) {
          this.selectionRow = {}
        } else {
          this.selectionRow = selection[0]
          this.id = selection[0].id
          // this.id = parseInt(this.id)
          console.log(selection, this.id)
          this.ids = []
          selection.forEach(item => {
            this.ids.push(item.id)
          });
          // console.log(this.ids)
        }
      },
      //查询
      handleFind() {
        this.$http
          .post(
            "/api/signmeets/loadTable?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize, {
              signmeets: this.search
            }
          )
          .then(res => {
            // console.log(res.data.list);
            this.list = res.data.list;
          })
          .catch(function (err) {
            console.log(err);
          });
      },
      // 添加签到系统
      handleAdd() {
        this.dialogAdd = true
      },
      // 新增提交
      addSubmit() {
        // this.addList.ip = this.addList.ip.split(',')
        this.signmeets = this.addList;
        // console.log(this.signmeets);
        this.$http
          .post("/api/signmeets/save", this.signmeets)
          .then(res => {
            console.log(res);
            // if (res.data.code == 0) {
            //   this.$message({
            //     message: "新增成功",
            //     type: "success"
            //   });
            // }
            this.loadTable();
          })
          .catch(function (err) {
            console.log(err);
          });
        this.dialogAdd = false;
      },
      //修改查看详情
      handleSee() {
        if (this.selectionRow == {} || this.selectionRow == null) {
          this.$message({
            message: "请选择一条数据！",
            type: "error"
          });
          return;
        } else {
          this.dialogUpdate = true;
          this.$http
            .post("/api/signmeets/" + this.id)
            .then(res => {
              // console.log(res.data)
              this.updateList = res.data
            })
            .catch(err => {
              console.log(err);
            });
        }
      },
      // 修改提交
      handleUpdate() {
        this.signmeets = this.updateList
        // console.log(this.signmeets)
        this.$http.post("/api/signmeets/update", this.signmeets).then(res => {
            console.log(res)
            this.loadTable()
            this.dialogUpdate = false
          })
          .catch(err => {
            console.log(err)
          })
      },
      // 删除
      handleDelete() {
        if (this.selectionRow == {} || this.selectionRow == null) {
          this.$message({
            message: "请选择一条数据！",
            type: "error"
          });
          return;
        } else {
          this.$http.post('/api/signmeets/delete', this.ids).then(res => {
              console.log(res.data)
              this.$message({
                message: res.data.data,
                type: "success"
              })
              this.loadTable()
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      // 是否启用
      handleSwitch(e) {
        console.log(e);
      },
      tableHeaderColor({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (rowIndex === 0) {
          return 'background-color: #F2F2F2;font-weight: 500;'
        }
      }, // 替换table中thead的颜色
      handleClose(done) {
        // this.$confirm('确认关闭？')
        //   .then(_ => {
        //     done();
        //   })
        //   .catch(_ => {});
      } // 关闭添加弹出框
    }
  }

</script>

<style scoped>
  * {
    box-sizing: border-box;
  }

  .header-left {
    margin-top: 15px;
    float: left
  }

  .header-left button,
  .header-right button {
    border: none;
    background: #237AE4;
    color: #fff;
    height: 30px;
    border-radius: 5px;
    padding: 5px 15px;
  }

  .header-right {
    margin-top: 15px;
    float: right
  }

  .header-left input {
    height: 40px;
    border-radius: 5px;
    outline: none;
    border: 1px solid #e0e0e0;
    margin-right: 10px;
  }

  .table {
    margin-top: 15px;
    width: 100%;
  }

  .hr {
    width: 100%;
    border: 1px solid #f4f4f4;
    padding: 0;
    margin: 0;
    position: relative;
    top: -30px;
  }

  .inInput {
    margin-bottom: 10px;
    height: 36px;
    border-radius: 3px;
    outline: none;
    border: 1px solid #ccc;
    margin-left: 4px;
    width: 215px;
    padding: 0 10px;
    position: relative;
  }

  label {
    margin-left: 29px;
  }

  label.import {
    margin-left: 20px;
  }

  label.import::before {
    content: '*';
    color: #f00;
    margin: 2px 3px 0 0;
  }

</style>

<style>
  .el-pagination {
    text-align: center;
  }

</style>
