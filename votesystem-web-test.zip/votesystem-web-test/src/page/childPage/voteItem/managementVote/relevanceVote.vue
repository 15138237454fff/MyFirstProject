<!-- 关联投票项目 -->
<template>
  <div class="systemSign">
    <div class="header-left">
      <input type="text">
      <button @click="handleFind">查询</button>
    </div>
    <div class="header-right">
      <button @click="handleAdd">添加</button>
      <button @click="handleSee">修改</button>
      <button @click="handleDelete">删除</button>
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table ref="multipleTable" :data="list" tooltip-effect="dark" border
        :header-cell-style="tableHeaderColor" style="width: 100%;"
        @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55">
        </el-table-column>
        <el-table-column prop="id" label="项目ID">
        </el-table-column>
        <el-table-column prop="name" label="项目名称">
        </el-table-column>
        <el-table-column prop="starttime" label="开始时间">
        </el-table-column>
        <el-table-column prop="address" label="地点">
        </el-table-column>
        <el-table-column prop="hymc" label="签到系统">
        </el-table-column>
        <el-table-column prop="ip" label="IP地址">
        </el-table-column>
        <el-table-column prop="status" label="状态">
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="添加签到系统" :visible.sync="dialogAdd" width="500px">
      <el-form :model="addList" label-position="right" label-width="80px">
        <el-form-item label="签到系统">
          <el-input v-model="addList.hymc"></el-input>
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input v-model="addList.ip"></el-input>
        </el-form-item>
        <!-- <el-form-item label="项目状态">
          <el-input v-model="addList.status"></el-input>
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAdd = false">取 消</el-button>
        <el-button type="primary" @click="addSubmit">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="修改" :visible.sync="dialogUpdate" width="500px">
      <el-form :model="updateList" label-position="right" label-width="80px">
        <el-form-item label="签到系统">
          <el-input v-model="updateList.hymc"></el-input>
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input v-model="updateList.ip"></el-input>
        </el-form-item>
        <!-- <el-form-item label="项目状态">
          <el-input v-model="updateList.status"></el-input>
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogUpdate = false">取 消</el-button>
        <el-button type="primary" @click="handleUpdate">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 分页 -->
    <div class="block" style="margin-top:15px;text-align:center">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
        :current-page="currentPage" :page-sizes="[50, 100, 150, 200]" :page-size="50"
        layout="total, sizes, prev, pager, next, jumper"
        :total="this.list == undefined ? null : list.length"></el-pagination>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'systemSign',
    data() {
      return {
        currentPage: 1, // 当前页
        pageSize: 50, //分页中每页显示条数
        projectEntity: {}, //查询参数，修改提交
        projectentity: {}, //新增提交
        dialogAdd: false, //新增弹窗
        dialogUpdate: false, //修改弹窗
        addList: {}, //新增
        updateList: {}, //修改
        selectionRow: null, //选择的那一行，修改
        ID: null, //多选
        id: null,
        ids: [],
        list: [{
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          },
          {
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          },
          {
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          },
          {
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          },
          {
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          },
          {
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          },
          {
            id: '1111', // 项目ID
            name: '2222', // 项目名称
            starttime: '3333', // 时间
            address: '4444', // 地点
            hymc: '5555', // 签到系统
            ip: '6666', // IP地址
            status: '7777'
          }
        ]
      }
    },
    mounted() {
      this.loadTable();
    },
    methods: {
      //改变列表页条数大小回调函数
      handleSizeChange(val) {
        this.pageSize = val;
        //   this.loadTable();
      },
      //改变列表页当前页回调函数
      handleCurrentChange(currentPage) {
        this.currentPage = currentPage;
        //   this.loadTable();
      },
      //列表序号
      indexMethod(index) {
        return (this.currentPage - 1) * this.pageSize + index + 1;
      },
      //加载列表
      loadTable() {
        this.$http
          .get("/api/project/showList", {
            params: {
              pageNum: this.currentPage,
              pageSize: this.pageSize
            }
          })
          .then(res => {
            console.log(res.data.list)
            this.list = res.data.list
          })
          .catch(function (err) {
            console.log(err)
          })
      },
      // 选择列表
      handleSelectionChange(selection) {
        if (selection.length == 0) {
          this.selectionRow = {}
        } else {
          this.selectionRow = selection[0]
          this.id = selection[0].id
          // this.id = parseInt(this.id)
          console.log(selection, this.id)
          this.ids = []
          selection.forEach(item => {
            this.ids.push(item.id)
          });
          // console.log(this.ids)
        }
      },
      //查询
      handleFind() {
        this.$http
          .post(
            "/api/project/search?pageNum=" +
            this.currentPage +
            "&pageSize=" +
            this.pageSize, {
              projectEntity: this.projectEntity
            }
          )
          .then(res => {
            console.log(res.data)
            this.list = res.data.list
          })
          .catch(function (err) {
            console.log(err);
          });
      },
      // 新增
      handleAdd() {
        this.dialogAdd = true;
      },
      //新增提交
      addSubmit() {
        this.projectentity = this.addList;
        this.$http
          .post("/api/project/save", this.projectentity)
          .then(res => {
            console.log(res.data);
            // if (res.data.code == 0) {
            //   this.$message({
            //     message: "新增成功",
            //     type: "success"
            //   });
            // }
            this.loadTable();
          })
          .catch(function (err) {
            console.log(err);
          });
        this.dialogAdd = false;
      },
      //修改查看详情
      handleSee() {
        if (this.selectionRow == {} || this.selectionRow == null) {
          this.$message({
            message: "请选择一条数据！",
            type: "error"
          });
          return;
        } else {
          this.dialogUpdate = true;
          console.log(this.id)
          this.$http
            .get("/api/project/queryDetail", {
              params: {
                id: this.id
              }
            })
            .then(res => {
              // console.log(res)
              this.updateList = res.data
            })
            .catch(err => {
              console.log(err);
            });
        }
      },
      //修改提交
      handleUpdate() {
        this.projectEntity = this.updateList
        // console.log(this.projectEntity)
        this.$http.post("/api/project/update", this.projectEntity).then(res => {
            console.log(res.data)
            this.loadTable()
            this.dialogUpdate = false
          })
          .catch(err => {
            console.log(err)
          })
      },
      //删除
      handleDelete() {
        if (this.selectionRow == {} || this.selectionRow == null) {
          this.$message({
            message: "请选择一条数据！",
            type: "error"
          });
          return;
        } else {
          this.$http.get('/api/project/deleteprojectsign', {
              params: {
                pid: this.pid,
                sid: this.sid
              }
            }).then(res => {
              console.log(res.data)
              this.$message({
                message: res.data.data,
                type: "success"
              })
              this.loadTable()
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      tableHeaderColor({
        row,
        column,
        rowIndex,
        columnIndex
      }) {
        if (rowIndex === 0) {
          return 'background-color: #F2F2F2;font-weight: 500;'
        }
      }, // 替换table中thead的颜色
    }
  }

</script>

<style scoped>
  * {
    box-sizing: border-box;
  }

  .header-left {
    margin-top: 15px;
    float: left
  }

  .header-left button,
  .header-right button {
    border: none;
    background: #237AE4;
    color: #fff;
    height: 30px;
    border-radius: 5px;
    padding: 5px 15px;
  }

  .header-right {
    margin-top: 15px;
    float: right
  }

  .header-left input {
    height: 40px;
    border-radius: 5px;
    outline: none;
    border: 1px solid #e0e0e0;
    margin-right: 10px;
  }

  .table {
    margin-top: 15px;
    width: 100%;
  }

</style>

<style>
  .el-pagination {
    text-align: center;
  }

</style>
