<!-- 投票结果管理 -->
<template>
  <div class="voteAudit">
    <div v-show="!CountingShow">
      <br />
      <div style="clear: both;"></div>
      <div class="header-middle">
        <el-input v-model="searchInfor" placeholder="请输入项目名称" style="width:70%" @keyup.enter.native="search"></el-input>
        <el-button @click="search" style="margin-left:5px">查询</el-button>
      </div>
      <div class="header-right">
        <el-button type="warning" v-show="isShow" @click="recallResult">撤回投票结果</el-button>
        <el-button type="primary" v-show="isShow" @click="voteAgain">再次发起投票</el-button>
        <el-button type="primary" v-show="isShow" @click="finishClick">正常结束</el-button>
        <el-button type="danger" v-show="isShow" @click="closeClick">异常关闭</el-button>
      </div>
      <div style="clear: both"></div>
      <div class="table">
        <el-table ref="multipleTable" @selection-change="mySelect" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
          <el-table-column type="selection" width="55" v-if="selectionShow">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="name" label="项目名称" width="220px">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="voteRules" label="投票规则">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.voteRules,'voteRules')}}</span>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="voteForm" label="投票形式">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.voteForm,'voteForm')}}</span>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="startTime" width="300px" label="投票时间">
            <template slot-scope="scope">
              <span>{{scope.row.startTime}}--{{scope.row.endTime}}</span>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="voted" label="已投票专家数">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="veto" label="未投票专家数">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" pr label="投票结果">
            <template slot-scope="scope">
              <el-button size="small" @click="Counting(scope.row)">计票表</el-button>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="status" label="项目状态">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.status,'projectStatus')}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!-- ..........撤回提交结果................ -->
      <el-dialog title="撤回提交结果" :visible.sync="recallShow" :before-close="handleClose" width="700px">
        <p class="hr"></p>
        <div class="table">
          <el-table ref="exitTable" highlight-current-row @current-change="recallUserChange" :data="recallList" tooltip-effect="dark" :row-key="getRowKeys" border :header-cell-style="tableHeaderColor" style="width: 100%;">
            <el-table-column type="index" width="80" label="序号">
            </el-table-column>
            <el-table-column prop="userName" label="用户名">
            </el-table-column>
            <el-table-column prop="name" label="姓名">
            </el-table-column>
            <el-table-column prop="organizationName" label="所属机构">
            </el-table-column>
            <el-table-column prop="phoneNum" label="手机号码">
            </el-table-column>
          </el-table>
          <div class="block">
            <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 50, 100]" :page-size="10" class="import" layout="total, prev, pager, next, jumper" @current-change="changePage3" :total="total3">
            </el-pagination>
          </div>
        </div>
        <span slot="footer" class="dialog-footer">
          <el-button @click="recallCancel">取 消</el-button>
          <el-button @click="recallAffirm" type="primary">还 原</el-button>
        </span>
      </el-dialog>
      <el-dialog title="关闭" :visible.sync="closeShow" width="500px">
        <p class="hr"></p>
        <p style="margin-left: 10px; color: #e43936;">确定关闭已选项目？项目关闭后不能再进行任何操作，请谨慎操作</p>
        <el-form ref="form" label-width="80px">
          <el-form-item label="关闭理由">
            <el-input v-model="reason"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="closeAffirm" type="primary">确 认</el-button>
        </span>
      </el-dialog>
      <el-dialog title="结束" :visible.sync="finishShow" width="500px">
        <p class="hr"></p>
        <p v-if="noCast==0">确定结束该投票项目吗？</p>
        <p v-else>还有{{noCast}}位专家未提交，确定结束该投票项目吗？</p>
        <span slot="footer" class="dialog-footer">
          <el-button @click="finishShow = false">取 消</el-button>
          <el-button @click="finishAffirm" type="primary">确 认</el-button>
        </span>
      </el-dialog>
      <el-dialog title="保存" :visible.sync="saveShow" width="320px">
        <p class="hr"></p>
        <p style="text-align: center;">是否保存更改内容</p>
        <span slot="footer" class="dialog-footer">
          <el-button @click="saveShow = false">取 消</el-button>
          <el-button @click="finishSave" type="primary">确 认</el-button>
        </span>
      </el-dialog>
      <div class="block">
        <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 50, 100]" :page-size="10" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
        </el-pagination>
      </div>
    </div>
    <count ref="tableCount" v-show="CountingShow"></count>
  </div>
</template>

<script>
import count from "../../../components/CountTable"
export default {
  inject: ['reload'],
  name: 'voteAudit',
  data() {
    return {
      myrow: {},
      saveShow: false,
      mytotal: 0,
      CountingShow1: false,
      activeName: 'first', // tab默认选中
      // isLimit: '', // 是否限制投票人数
      limit: 1, // 限制投票人数
      form: {
        votePeopleNum: 0,
      },
      countResult: '',
      reason: '', // 关闭理由
      getRowKeys(row) {
        return row.id;
      },
      passRadio: 1,
      tgPeople: 0, // 通过人数
      wtgPeople: 0, // 未通过人数
      wtPeople: 0, // 未投人数
      ytPeople: 0, // 已投人数
      voteInfor: '', // 计票表查询的数据
      butStatus: 2,
      searchInfor: '', // 查询的数据
      CountingList: [], // 计票表页面
      CountingShow: false, // 计票表
      voteAgainList: [], // 再次发起投票数据
      voteAgainShow: false,
      isShow: true,
      startItem: 'primary', // 已启动项目按钮状态
      endItem: '', // 已结束项目按钮状态
      closeItem: '', // 已关闭项目按钮状态
      currentPage: 1, // 起始页
      pagesize: 10, // 每页条数
      tableData: [],
      total: 0, // 总的数据条数'
      total1: 0,
      total2: 0, // 再次发起投票数据
      hzid: '', // 汇总id
      id: '', // 项目id
      deleteList: [],
      row: {},
      voteList: [], // 再次投票列表
      recallList: [], // 撤回列表
      recallShow: false, // 撤回弹出框显示
      recallClickList: [], // 撤回列表选中的数据
      recallRow: {},
      closeShow: false, // 关闭弹出框
      finishShow: false, // 结束弹出框
      noCast: 0, // 未投票人数
      castAll: false, // 所有人投票完成
      castnone: false, // 还有人未投票
      saveList: [], // 需要保存的数据
      waitPass: '', // 不通过
      alreadyPass: '', // 通过
      number: 0,
      selectionShow: true,
      total3: 0,
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      CountingShow: false,
      countTableInfo: {},
      recallUserId: null
    }
  },
  methods: {
    //撤回用户提交结果列表单选事件改变
    recallUserChange(currentRow, oldCurrentRow) {
      if (currentRow == null) {
        this.recallUserId = null;
      } else {
        this.recallUserId = currentRow.userId;
      }
    },
    //关闭计票表
    closeCountTable() {
      this.CountingShow = false;
    },
    mySelect(selection) {
      this.deleteList = []
      if (selection.length == 0) {
        this.row = {}
      } else {
        this.id = selection[0].id
        selection.map((item, index) => {
          this.deleteList.push(item.id)
        })
        this.row = selection[0]
      }
      this.selectionList = selection[0]
    }, // 列表选择
    voteSelect(selection, row) {
      this.voteList = []
      selection.map((item, index) => {
        this.voteList.push(item.dataId)
      })
      this.number = this.voteList.length
    },
    allClick(selection) {
      this.voteList = []
      selection.map((item, index) => {
        this.voteList.push(item.dataId)
      })
      this.number = this.voteList.length
    },
    recallAffirm() {
      if (!this.isEmpty(this.recallUserId)) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      this.$http.put("api/spot/recall/" + this.row.id + "?userId=" + this.recallUserId)
        .then(res => {
          if (res.data.data.code == 200) {
            this.$message({
              type: "success",
              message: "撤回成功!"
            })
            this.takeList(1)
            this.recallShow = false
          } else {
            this.$message.error(res.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 撤回提交结果确认
    recallResult() {
      if (this.deleteList.length !== 1) {
        this.$message.error({ message: "请选择一条数据！" })
      } else {
        this.recallShow = true
        this.takeRecallList(1)
      }
    }, // 撤回投票结果
    takeRecallList(index) {
      this.$http
        .post("api/spot/voted", {
          projectId: this.row.id,
          pageNum: index,
          pageSize: 10
        })
        .then(res => {
          if (res.data.code == 200) {
            this.recallList = res.data.data.list
            this.total3 = res.data.data.total
          }
          else {
            this.$message.error({ message: res.data.message })
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    voteAgain() {
      console.log(this.row.id);
      if (!this.isEmpty(this.row.id)) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      // this.takeVoteList(1)
      // this.$http
      //   .get("api/vtc/castInfo/" + this.selectionList.id + "/" + this.selectionList.hzid)
      //   .then(res => {
      //     this.ytPeople = res.data.data.cast
      //     this.wtPeople = res.data.data.noCast
      //     this.tgPeople = res.data.data.pass
      //     this.wtgPeople = res.data.data.noPass
      //   })
      //   .catch(function (err) {
      //     console.log(err)
      //   })
      this.$refs.tableCount.loadAgainInfo(this.row)
      this.CountingShow = true
    }, // 再次发起投票
    addTemplate() {
      this.templateShow = true
    }, // 添加机构
    deleteInfo() {
      this.$refs.deleteDia.deleteDialog = true
      this.$refs.deleteDia.deleteInfo = '组织机构删除'
    }, // 删除信息
    Counting(row) {
      this.$refs.tableCount.loadInfo(row)
      this.CountingShow = true
      // this.searchTable(1)
    }, // 弹出计票表页面
    searchTable(index) {

    },
    changePage(index) {
      this.page = index
      this.takeList(index)
    }, // 翻页时的数据
    // mychangePage(index) {
    //   this.page = index
    //   console.log(this.id)
    //   this.$http
    //     .post("api/vtc/tally",
    //       {            countResult: '',
    //         hzId: this.hzid,
    //         pageNum: index,
    //         pageSize: this.pagesize,
    //         projectId: this.id,
    //         query: this.voteInfor
    //       })
    //     .then(res => {
    //       let list = res.data.data.list
    //       this.mytotal = res.data.data.total
    //       this.CountingList = list
    //       for (let i = 0; i < this.CountingList.length; i++) {
    //         this.CountingList[i].index = i + this.pagesize * (index - 1) + 1
    //       }
    //       list.map((item, index) => {
    //         let status = ''
    //         if (item.countResult == '0') {
    //           status = '未通过'
    //         } else if (item.countResult == '1') {
    //           status = '通过'
    //         }
    //         this.CountingList[index].countResult = status
    //       })
    //       list.map((item, index) => {
    //         console.log(item.studentId)
    //         if (item.studentId != undefined) {
    //           this.CountingList[index].stuId = item.studentId
    //         }
    //       })
    //       console.log(list)
    //     })
    //     .catch(function (err) {
    //       console.log(err)
    //     })
    // },
    changePage3(index) {
      this.page = index
      this.takeRecallList(index)
    }, // 翻页时的数据
    // changePage1(index) {
    //   console.log(this.id)
    //   this.page = index
    //   this.$http
    //     .post("api/vtc/tally",
    //       {            countResult: "",
    //         hzId: this.hzid,
    //         pageNum: index,
    //         pageSize: this.pagesize,
    //         projectId: this.id,
    //         query: this.voteInfor
    //       })
    //     .then(res => {
    //       let list = res.data.data.list
    //       this.total1 = res.data.data.total
    //       this.CountingList = list
    //       for (let i = 0; i < this.CountingList.length; i++) {
    //         this.CountingList[i].index = i + this.pagesize * (index - 1) + 1
    //       }
    //       list.map((item, index) => {
    //         console.log(item.studentId)
    //         if (item.studentId != undefined) {
    //           this.CountingList[index].stuId = item.studentId
    //         }
    //       })
    //     })
    //     .catch(function (err) {
    //       console.log(err)
    //     })
    // },
    // changePage2(index) {
    //   this.page = index
    //   // this.takeVoteList(index)
    //   this.$http
    //     // +this.row.id+"/"+this.row.hzid+"/"+index+"/"+this.pagesize+"?query="
    //     .post("api/vtc/tally",
    //       {            countResult: "",
    //         hzId: this.row.hzid,
    //         pageNum: index,
    //         pageSize: this.pagesize,
    //         projectId: this.row.id,
    //         query: ""
    //       })
    //     .then(res => {
    //       let list = res.data.data.list
    //       this.total2 = res.data.data.total
    //       this.voteAgainList = list
    //       for (let i = 0; i < this.voteAgainList.length; i++) {
    //         this.voteAgainList[i].index = i + this.pagesize * (index - 1) + 1
    //       }
    //       list.map((item, index) => {
    //         let status = ''
    //         if (item.countResult == '0') {
    //           status = '未通过'
    //         } else if (item.countResult == '1') {
    //           status = '通过'
    //         }
    //         this.voteAgainList[index].countResult = status
    //       })
    //       list.map((item, index) => {
    //         if (item.studentId != undefined) {
    //           this.CountingList[index].stuId = item.studentId
    //         }
    //       })
    //     })
    //     .catch(function (err) {
    //       console.log(err)
    //     })
    // }, // 再次发起投票数据
    sizeChange(value) {
      this.pagesize = value
      this.takeList(1)
    }, // 切换每页条数
    takeList(index) {
      this.$http
        .post("api/spot/list", {
          pageNum: index,
          pageSize: this.pagesize,
          query: this.searchInfor
        })
        .then(res => {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    takeVoteList(index) {
      this.$http
        .post("api/vtc/tally",
          {            countResult: "",
            hzId: this.row.hzid,
            pageNum: index,
            pageSize: this.pagesize,
            projectId: this.row.id,
            query: ""
          })
        .then(res => {
          let list = res.data.data.list
          this.total2 = res.data.data.total
          this.voteAgainList = list
          for (let i = 0; i < this.voteAgainList.length; i++) {
            this.voteAgainList[i].index = i + 1
          }
          list.map((item, index) => {
            let status = ''
            if (item.countResult == '0') {
              status = '未通过'
            } else if (item.countResult == '1') {
              status = '通过'
            }
            this.voteAgainList[index].countResult = status
          })
          list.map((item, index) => {
            console.log(item.studentId)
            if (item.studentId != undefined) {
              this.CountingList[index].stuId = item.studentId
            }
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    voteConfirm() {
      if (this.form.votePeopleNum > this.number) {
        this.$message.error('选择人数不能大于限制人数')
      } else {
        let obj = {}
        obj.dataId = this.voteList
        obj.projectId = this.row.id
        this.limit == 0 ? obj.limit = true : obj.limit = false
        obj.limit == true ? obj.maxPass = this.form.votePeopleNum : obj.maxPass = null
        this.$http
          .post("api/vtc/again", obj)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                type: "success",
                message: "再次发起投票成功!"
              })
              this.takeList(1)
            } else {
              this.$message.error(res.data.message)
            }
          })
          .catch(function (err) {
            console.log(err)
          })
        this.voteAgainShow = false
        this.form.votePeopleNum = 0
        this.reload()
      }
    }, // 确认再次发起投票
    closeClick() {
      if (this.deleteList.length != 1) {
        this.$message.error({ message: "请选择一条数据！" })
        return;
      }
      this.closeShow = true
    }, // 关闭弹出框
    closeAffirm() {
      this.$http
        .put("api/project/close/" + this.row.id + "?reason=" + this.reason)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "关闭项目成功!"
            })
            this.takeList(1)
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
      this.closeShow = false
      this.reason == ''
    }, // 关闭确认
    finishClick() {
      if (this.deleteList.length != 1) {
        this.$message.error({ message: "请选择一条数据！" });
        return;
      }
      this.noCast = this.row.veto;
      this.finishShow = true;
    }, // 结束弹出框
    finishAffirm() {
      this.$http
        .put("api/project/over/" + this.row.id)
        .then(res => {
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "结束项目成功!"
            })
            this.takeList(1)
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
      this.finishShow = false
    }, // 确认结束项目
    exportData() {
      window.location.href = "api/vtc/export/" + this.id + "/" + this.hzid
    }, // 导出数据
    myChange(index, row) {
      let obj = {}
      obj.dataId = row.dataId
      obj.countResult = row.countResult
      this.saveList.map((item, index) => {
        if (row.dataId == item.dataId) {
          this.saveList.splice(index, 1)
        }
      })
      this.saveList.push(obj)
    },
    saveData() {
      if (this.saveList.length != 0) {
        this.saveShow = true
      } else {
        this.reload()
      }
    }, // 保存数据
    finishSave() {
      this.$http
        .post("api/vtc/update/" + this.id + "/" + this.hzid, this.saveList)
        .then(res => {
          console.log(res)
          if (res.data.code == 200) {
            this.$message({
              type: "success",
              message: "项目保存成功!"
            })
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
      this.reload()
    }, // 确认保存
    voteSearch() {
      this.searchTable(1)
    }, // 计票表查询
    search() {
      this.takeList(1)
    }, // 查询列表数据
    handleClose(done) {
      this.empty()
      this.currentPage = 1
      done()
    },
    handleClose1(done) {
      this.reload()
      done()
    },
    voteCancel() {
      this.voteAgainShow = false
      this.reload()
    },
    recallCancel() {
      this.recallShow = false
      this.recallUserId = null;
      this.reload()
    },
    empty() {
      this.voteInfor = ''
    }
  },
  mounted() {
    this.takeList(0)
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  },
  components: {
    count
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.dia-right input {
  background: #fff;
  border: none;
  outline: none;
  letter-spacing: 2px;
  font-size: 14px;
  width: 50px;
}
.header-left {
  margin-top: 5px;
  float: left;
}
.header-middle {
  float: left;
}
/* .header-right button, .header-middle button, .dia-left button, .dia-right button {
  border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
  margin-left: 10px;
} */
.header-left button {
  border-radius: 0;
}
.header-right input,
.header-middle input,
.dia-left input {
  height: 40px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
  border-radius: 4px;
}
.header-right {
  float: right;
}
.dia-left {
  float: left;
  margin-bottom: 10px;
}
.dia-right {
  float: right;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.header-left .el-button {
  margin-left: -5px !important;
}
.header-left button:first-child {
  margin-left: 0 !important;
}
.header-right button {
  margin-left: 10px !important;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.header-middle {
}
.dia-right > div {
  float: left;
  margin-left: 10px;
}
.el-popper[x-placement^="bottom"] {
  margin-top: 0px !important;
  margin-left: 26px;
}
.voteAudit /deep/ .dialog-footer button {
  margin: 0 20px;
}
.voteAudit /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.voteAudit /deep/ .el-tabs__header {
  background: #f2f2f2;
  padding: 0 20px;
  height: 50px;
}
.voteAudit /deep/ .el-tabs__nav-scroll {
  height: 50px;
}
</style>

<style>
.current-row > td {
  background: rgba(0, 158, 250, 0.219) !important;
}
.el-pagination {
  text-align: center;
}
.diaButton button {
  border-radius: none !important;
}
::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 3px;
}
.el-tabs__item {
  height: 50px;
  line-height: 50px;
  letter-spacing: 3px;
}
.el-tabs__nav-wrap::after {
  background: transparent;
}
.el-dialog .table {
  margin-top: 0;
}
</style>

