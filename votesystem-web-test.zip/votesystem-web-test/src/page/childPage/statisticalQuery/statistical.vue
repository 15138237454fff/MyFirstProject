<!-- 统计查询 -->
<template>
  <div class="statistical">
    <div v-show="!CountShow">
      <div class="header-left">
        <el-input v-model="pageHelper.query" placeholder="请输入项目名称" style="width:200px" @keyup.enter.native="loadTable"></el-input>
        <el-button @click="loadTable" style="margin: 0 10px 0 5px">查询</el-button>
        <el-select v-model="pageHelper.voteRules" placeholder="全部投票规则">
          <el-option value="" label="全部"></el-option>
          <el-option v-for="item in GLOBEL.dict.voteRules" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <el-select v-model="pageHelper.voteForm" placeholder="全部投票形式">
          <el-option value="" label="全部"></el-option>
          <el-option v-for="item in GLOBEL.dict.voteForm" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div class="table">
        <el-table ref="multipleTable" :data="pageInfo.list" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
          <el-table-column :show-overflow-tooltip="true" prop="number" label="序号" type="index" width="80">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="name" label="项目名称">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="voteRules" label="投票规则">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.voteRules,'voteRules')}}</span>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="voteForm" label="投票形式">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.voteForm,'voteForm')}}</span>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="startTime" width="300px" label="投票时间">
            <template slot-scope="scope">
              <span>{{scope.row.startTime}}--{{scope.row.endTime}}</span>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="voted" label="已投票专家数">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="result" label="投票结果">
            <template slot-scope="scope">
              <el-button size="small" @click="tempDownload(scope.row)">计票表</el-button>
            </template>
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="status" label="项目状态">
            <template slot-scope="scope">
              <span>{{getDictValue(scope.row.status,'projectStatus')}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="block">
        <el-pagination :current-page.sync="pageInfo.pageNum" :page-sizes="[10, 20, 50, 100]" :page-size="pageInfo.pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="pageInfo.total" @size-change="sizeChange">
        </el-pagination>
      </div>
    </div>
    <count ref="tableCount" v-show="CountShow"></count>
  </div>
</template>

<script>
import count from "../../../components/CountTable"
export default {
  name: 'statistical',
  components: {
    count
  },
  data() {
    return {
      CountShow: false,
      tableHeight: "",
      clientHeight: 0,
      offsetTop: 0,
      pageHelper: {
        pageNum: 1,
        pageSize: 10
      },
      pageInfo: {}
    }
  },
  watch: {
    'pageHelper.voteRules'(newVal) {
      this.loadTable();
    },
    'pageHelper.voteForm'(newVal) {
      this.loadTable();
    }
  },
  methods: {
    //关闭计票表
    closeCountTable() {
      this.CountShow = false;
    },
    //查看计票表
    tempDownload(row) {
      this.$refs.tableCount.loadInfo(row)
      this.CountShow = true
    },
    changePage(val) {
      this.pageHelper.pageNum = val
      this.loadTable()
    },
    sizeChange(val) {
      this.pageHelper.pageSize = val
      this.loadTable()
    },
    loadTable() {
      this.$http.post("api/stat/list", this.pageHelper)
        .then(res => {
          if (res.data.code == 200) {
            this.pageInfo = res.data.data
          } else {
            this.$message.error(res.data.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F2F2F2;font-weight: 500;";
      }
    } // 替换table中thead的颜色
  },
  mounted() {
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop;
    this.clientHeight = `${document.documentElement.clientHeight}`;
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150);
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`;
        this.tableHeight =
          document.documentElement.clientHeight - (this.offsetTop + 150);
      })()
    }
    this.loadTable();
  },
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
  margin-bottom: 15px;
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
</style>