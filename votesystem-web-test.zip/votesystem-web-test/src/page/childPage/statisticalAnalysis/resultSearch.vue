<!-- 投票结果查询 -->
<template>
  <div class="resultSearch">
    <div class="header-left">
			<label>项目名称：<input type="text"></label>
			<label for="">
				时间：
				<el-date-picker
					v-model="expiryDate"
					type="daterange"
					range-separator="至">
				</el-date-picker>
			</label> 
			<label>地点：<input type="text"></label>
			<label>项目状态：<input type="text"></label>
		</div> 
		<div class="header-right">
			<el-button>查询</el-button>
		</div>
		<div class="table">
			<el-table
				ref="multipleTable"
				:data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
				tooltip-effect="dark"
				border
				:header-cell-style="tableHeaderColor"
				style="width: 100%;">
				<el-table-column
					type="selection"
					width="55">
				</el-table-column>
				<el-table-column
					prop="itemID"
					label="项目ID">
				</el-table-column>
				<el-table-column
					prop="itemName"
					label="项目名称">
				</el-table-column>
				<el-table-column
					prop="time"
					label="时间">
				</el-table-column>
				<el-table-column
					prop="place"
					label="地点">
				</el-table-column>
				<el-table-column
					prop="signRate"
					label="签到率">
				</el-table-column>
				<el-table-column
					prop="people"
					label="已投票人数">
				</el-table-column>
				<el-table-column
					prop="result"
					label="投票结果">
				</el-table-column>
				<el-table-column
					prop="status"
					label="项目状态">
				</el-table-column>
			</el-table>
		</div>
		<div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[5, 10, 50, 100]" :page-size="5" class="import"
        layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: 'resultSearch',
  data () {
    return {
			expiryDate: '', // 有效期
      currentPage: 1, // 起始页
      pagesize: 5, // 每页条数
      tableData: [{
          itemID: '1111', // 项目ID
          itemName: '2222', // 项目名称
          time: '3333', // 时间
					place: '4444', // 地点
					signRate: '11%', // 签到率
					people: '5555', // 已投票人数
					result: '222', // 投票结果
          status: '' // 项目状态
        },
        {
          itemID: '1111',
          itemName: '2222',
          time: '3333',
					place: '4444',
					signRate: '11%',
					people: '5555',
					result: '222',
          status: ''
        },
        {
          itemID: '1111',
          itemName: '2222',
          time: '3333',
					place: '4444',
					signRate: '11%',
					people: '5555',
					result: '222',
          status: ''
        },
        {
          itemID: '1111',
          itemName: '2222',
          time: '3333',
					place: '4444',
					signRate: '11%',
					people: '5555',
					result: '222',
          status: ''
        },
        {
          itemID: '1111',
          itemName: '2222',
          time: '3333',
					place: '4444',
					signRate: '11%',
					people: '5555',
					result: '222',
          status: ''
        },
        {
          itemID: '1111',
          itemName: '2222',
          time: '3333',
					place: '4444',
					signRate: '11%',
					people: '5555',
					result: '222',
          status: ''
        }
      ]
    }
	},
	methods: {
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    } // 替换table中thead的颜色
  }
}
</script>

<style scoped>

* {
box-sizing: border-box;
color: #606266;
}
.header-left {
  margin-top: 15px;
	margin-bottom: 15px;
  float: left
}
.header-left button, .header-right button {
  /* border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px; */
}
.header-right {
  margin-top: 15px;
  float: right
}
.header-left input {
	width: 100px;
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
	margin-right: 10px;
}
.table {
  width: 100%;
}
label {
	font-size: 14px;
}

</style>

<style>

.el-pagination {
	text-align: center;
}
.el-range-editor.el-input__inner{
	position: relative;
  top: 1px;
}

</style>
