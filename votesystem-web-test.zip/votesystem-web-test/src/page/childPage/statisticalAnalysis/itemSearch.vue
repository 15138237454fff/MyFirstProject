<!-- 投票项目查询 -->
<template>
  <div class="itemSearch">
      888
  </div>
</template>

<script>
export default {
  name: 'itemSearch',
  data () {
    return {
      
    }
  }
}
</script>

<style scoped>

</style>
