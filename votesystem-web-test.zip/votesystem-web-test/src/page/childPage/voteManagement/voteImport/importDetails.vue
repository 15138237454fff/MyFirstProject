<template>
  <div class="importDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="header-left">
      <el-input v-model="pageHelper.query" placeholder="" style="width:200px;" @keyup.enter.native="getList" clearable @clear="getList"></el-input>
      <el-button @click="getList" style="margin-left:5px">查询</el-button>
    </div>
    <div class="table">
      <el-table ref="multipleTable" :data="pageInfo.list" border style="width: 100%">
        <el-table-column v-for="(item, index) in detailsData" :key="index" :show-overflow-tooltip="true" :prop="item.attributeName" :label="item.attributeNameCn">
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination :current-page.sync="pageInfo.pageNum" :page-sizes="[50, 100, 200]" :page-size="pageInfo.pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="pageInfo.total" @size-change="sizeChange">
      </el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: 'importDetails',
  data() {
    return {
      pageInfo: [], // 表单数据
      detailsData: [], // 表头数据
      importInfo: {},
      pageHelper: {
        pageNum: 1,
        pageSize: 50,
        importId: null,
        projectId: null,
        templateId: null
      }
    }
  },
  methods: {
    changePage(val) {
      this.pageHelper.pageNum = val;
      this.getList();
    },
    sizeChange(val) {
      this.pageHelper.pageSize = val;
      this.getList();
    },
    exitList() {
      this.$parent.closeVoteTable();
    },
    loadInfo(row) {
      this.importInfo = row;
      this.pageHelper = {
        pageNum: 1,
        pageSize: 50,
        importId: this.importInfo.id,
        projectId: this.importInfo.projectId,
        templateId: this.importInfo.templateId
      }
      this.getTableInfo();
    },
    getTableInfo() {
      this.$http.get("api/vtc/voteTable/" + this.pageHelper.projectId).then(res => {

        if (res.data.code == 200) {
          this.detailsData = res.data.data.tableColInfo
          this.getList()
        } else {
          this.infoNotice(res.data.message);
        }

      })
    },
    getList() {
      this.$http
        .post("api/vdc/view", this.pageHelper)
        .then(res => {
          if (res.data.code == 200) {
            this.pageInfo = res.data.data
          } else {
            this.infoNotice(res.data.message);
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
  },
  mounted() {

  }
}
</script>

<style scoped lang="scss">
.header-left {
  padding-top: 10px;
}
.importDetails {
  .top-title {
    width: 100%;
    height: 60px;
    background: #f2f2f2;
    line-height: 60px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .table {
    margin-top: 15px;
    width: 100%;
  }
  .el-table td,
  .el-table th {
    padding: 15px 0 !important;
  }
}
</style>
