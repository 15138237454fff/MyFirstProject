<!-- 投票数据导入 -->
<template>
  <div class="voteImport">
    <div class="main-container" v-show="!showVote">
      <div class="header-left">
        <el-input v-model="searchInformation" placeholder="请输入项目名称" style="width:70%" @keyup.enter.native="searchInfo"></el-input>
        <el-button @click="searchInfo" style="margin-left:5px">查询</el-button>
      </div>
      <div style="clear: both"></div>
      <div class="table">
        <el-table @selection-change="mySelect" @row-click="clickRow" ref="multipleTable" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
          <el-table-column :show-overflow-tooltip="true" prop="name" label="投票项目名称" width="240px">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="startTime" label="投票时间">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="rule" label="投票规则">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="shape" label="投票形式">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="noPeople" label="模板下载" width="120px">
            <template slot-scope="scope">
              <el-button size="small" @click="tempDownload(scope.$index, scope.row)">模板下载</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="noPeople" label="数据导入" width="120px">
            <template slot-scope="scope">
              <el-button size="small" @click="dataImport(scope.$index, scope.row)" :disabled="scope.row.checkStatus == 0 || scope.row.checkStatus == 2">点击导入</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="noPeople" label="查看数据" width="120px">
            <template slot-scope="scope">
              <el-button size="small" @click="checkInfor(scope.$index, scope.row)">查看数据</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="status" label="审核状态" width="100px">
          </el-table-column>
          <el-table-column :show-overflow-tooltip="true" prop="status" width="100px" label="提交审核">
            <template slot-scope="scope">
              <el-button size="small" type="primary" @click="submitInfor(scope.row)" :disabled="scope.row.checkStatus == 0 || scope.row.checkStatus == 2">提交</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="block">
        <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 20, 50]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
        </el-pagination>
      </div>
      <!-- 导入框 -->
      <el-dialog title="投票数据导入" :visible.sync="importShow" width="380px">
        <p class="hr"></p>
        <el-form label-position="right" label-width="100px">
          <el-row>
            <el-col>
              <el-form-item label="导入投票数据">
                <el-upload class="upload-demo" :action="url" :on-change="handleChange" :on-progress="handleProgress" :on-success="successUpload" accept=".xls, .xlsx" :file-list="fileList">
                  <el-button size="small" type="primary" @click="openFullScreen" v-loading.fullscreen.lock="fullscreenLoading">点击上传</el-button>
                </el-upload>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="importShow = false">取 消</el-button>
          <el-button type="primary" @click="inforImport">确 定</el-button>
        </span>
      </el-dialog>
    </div>
    <importDetails ref="importDetails" v-show="showVote"></importDetails>
  </div>
</template>

<script>
import importDetails from './voteImport/importDetails'
export default {
  name: 'systemSign',
  data() {
    return {
      showVote: false,
      fullscreenLoading: '', // 上传模板时的等待
      searchData: '',
      searchInformation: '', // 查询的信息
      importId: '',
      pagesize1: 5,
      fileList: [], // 导入的列表
      currentPage: 1, // 起始页
      importShow: false, // 数据导入弹出框
      pagesize: 10, // 每页条数
      tableData: [],
      total: 0, // 总条数
      submitList: [], // 提交的数据
      row: {},
      url: '',
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      myrow: {}
    }
  },
  methods: {
    exportList() {
      location.href = "api/project/downloadAllExcel?xmid=" + this.xmid + "&hzid=" + this.hzid + "&importId=" + this.importId
    },
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    handleSelect(selection, row) {
      this.handleList = []
      // selection.map((item, index) => {
      // 	this.voteList.push(item.dataId)
      // })
    },
    mySelect(selection) {
      this.submitList = []
      this.row = selection[0]
      selection.map((item, index) => {
        this.submitList.push(item.id)
      })
    }, // 用户勾选table中的某一项
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    takeList(index) {
      this.$http
        .post("api/vdc/inc/list", {
          pageNum: index,
          pageSize: this.pagesize,
          query: this.searchInformation
        })
        .then(res => {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
          res.data.data.list.map((item, index) => {
            let status = ''
            if (item.checkStatus == '0') {
              status = '待审核'
            } else if (item.checkStatus == '1') {
              status = '退回'
            } else if (item.checkStatus == '2') {
              status = '审核成功'
            } else if (item.checkStatus == '3') {
              status = '未提交'
            }
            if (item.voteRules == '0') {
              this.tableData[index].rule = '同意制'
            } else if (item.voteRules == '1') {
              this.tableData[index].rule = '打分制'
            } else if (item.voteRules == '2') {
              this.tableData[index].rule = '排名制'
            }
            if (item.voteForm == '0') {
              this.tableData[index].shape = '现场实名'
            } else if (item.voteForm == '1') {
              this.tableData[index].shape = '现场匿名'
            } else if (item.voteForm == '2') {
              this.tableData[index].shape = '网上实名'
            } else if (item.voteForm == '2') {
              this.tableData[index].shape = '网上匿名'
            }
            this.tableData[index].status = status
            this.tableData[index].submitNum = false
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    tempDownload(index, row) {
      window.location.href = 'api/template/project/down/' + row.templateId
    },
    changePage(index) {
      this.page = index
      this.takeList(index)
    }, // 翻页时的数据
    dataImport(index, row) {
      if (row.status == '待审核') {
        this.$message.error('当前项目为待审核状态')
      } else if (row.status == '审核成功') {
        this.$message.error('当前项目为审核成功状态')
      } else {
        this.importShow = true
        this.fileList = []
        this.url = "api/vdc/import/" + row.id
      }
    }, // 数据导入
    openFullScreen() {
      // this.fullscreenLoading = true
    },
    inforImport() {
      this.importShow = false
      this.takeList(1)
    }, // 确认导入
    handleChange(file, fileList) {
      // this.fullscreenLoading = true
    }, // 导入的方法
    handleProgress(event, file, fileList) {
      this.fullscreenLoading = true
    },
    successUpload(response, file, fileList) {
      if (response.code == 200) {
        this.$message({
          type: 'success',
          message: "导入成功"
        })
        this.fullscreenLoading = false
      } else {
        this.$message({
          message: "导入失败"
        })
      }
    },
    closeVoteTable() {
      this.showVote = false
    },
    checkInfor(index, row) {
      this.myrow = row
      this.showVote = true
      this.$refs.importDetails.loadInfo(row)
    }, // 查看导入数据
    submitInfor(row) {
      if (row.checkStatus != 3) {
        this.$confirm('只有未提交的项目可以提交', '提示', {})
      } else if (row.lead != 1) {
        this.$confirm('请导入投票数据', '提示', {})
      } else {
        this.$http
          .put("api/vdc/submit/" + row.id)
          .then(res => {
            this.takeList(1)
            if (res.data.code == 200) {
              this.$message({
                type: "success",
                message: "提交成功"
              })
            } else {
              this.$message('提交失败')
            }
          })
          .catch(function (err) {
            console.log(err)
          })
      }
    },
    sizeChange(value) {
      this.pagesize = value
      this.takeList(1)
    }, // 切换每页条数
    searchInfo() {
      this.takeList(1)
    },
    handleClose(done) {
      this.searchData = ''
      this.pagesize1 = 5
      done()
    }, // 关闭投票数据
    sizeChange1(value) {
      this.pagesize1 = value
      this.takeList(1)
    }
  },
  mounted() {
    this.takeList(0)
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  },
  components: {
    importDetails
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
}
.header-right {
  margin-top: 15px;
  float: right;
}
.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.voteImport /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.voteImport /deep/ .dialog-footer button {
  margin: 0 20px;
}
</style>

<style>
.el-pagination {
  text-align: center;
}
.el-table {
  position: relative;
  overflow: auto;
}
::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 3px;
}
</style>

