<template>
  <div class="vote1">
    <div class="header-left">
      <el-input
        v-model="searchData"
        placeholder="请输入项目名称"
        style="width:70%"
        @keyup.enter.native="searchList(1)">
      </el-input>
      <el-button style="margin-left:5px" @click="searchList(1)">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="exportList" class="exportButton">导出</el-button>
      <el-button type="info" icon="el-icon-close" class="diyButton" @click="exitHandle"></el-button>
    </div>
		<div style="clear: both"></div>
		<div class="table">
			<el-table
				ref="multipleTable"
				:data="tableData"
				border
				style="width: 100%"
				:height="tableHeight">
				<el-table-column
					:show-overflow-tooltip="true"
					fixed="left"
					prop="no"
					label="序号"
					width="55px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					fixed="left"
					prop="collegeName"
					label="学院"
					width="130px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuName"
					fixed="left"
					label="姓名"
					width="80px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuId"
					fixed="left"
					label="学号"
					width="130px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuGrade"
					width="80px"
					label="年级">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="majorName"
					width="180px"
					label="授予学位专业名称">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					width="120px"
					prop="isPunishment"
					label="是否受过处分">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="studyStatus"
					width="120px"
					label="课程学习情况">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="resultNum"
					label="成果总数"
					width="90px">
				</el-table-column>
				<el-table-column
					prop="resultName"
					label="成果名称"
					width="400px">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.resultName.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.resultName" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					prop="writerSort"
					label="作者排序"
					width="200px">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.writerSort.replace(/\n/g,'<br><br>')" v-if="scope.row.isCheck== 1" style="color: red"></div>
							<div slot="content" v-html="scope.row.writerSort.replace(/\n/g,'<br><br>')" v-else></div>
							<div v-html="scope.row.writerSort" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
          </template>
				</el-table-column>
				<el-table-column
					prop="resultLevel"
					label="成果等级"
					width="200px">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.resultLevel.replace(/\n/g,'<br><br>')" v-if="scope.row.isCheck== 1" style="color: red"></div>
							<div slot="content" v-html="scope.row.resultLevel.replace(/\n/g,'<br><br>')" v-else></div>
							<div v-html="scope.row.resultLevel" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
          </template>
				</el-table-column>
				<el-table-column
					prop="resultSource"
					label="成果出处"
					width="300px">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.resultSource.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.resultSource" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					prop="assDissertation"
					width="200px"
					label="学位论文的关联性">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.assDissertation.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.assDissertation" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="degreeAppication"
					width="120px"
					label="申请学位情况">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="committeeNum"
					width="160px"
					label="答辩委员会人数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="agreeNum"
					width="90px"
					label="同意票数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="disagreeNum"
					width="120px"
					label="不同意票数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="abstention"
					width="90px"
					label="弃权票数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subcommitteeNum"
					width="120px"
					label="分委员会人数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subagreeNum"
					width="100px"	
					label="同意票数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subdisagreeNum"
					width="120px"	
					label="不同意票数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subabstention"
					width="100px"	
					label="弃权票数">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="isPassed"
					width="120px"	
					label="是否通过审核">
				</el-table-column>
				
			</el-table>
			<div class="block">
				<el-pagination :current-page.sync="currentPage" 
				:page-sizes="[20, 50, 100]"
				:pager-count="3" :page-size="pagesize" class="import"
				layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total"
				@size-change="sizeChange">
				</el-pagination>
			</div>
		</div>
  </div>
</template>

<script>
  export default {
    data () {
      return {
				currentPage: 1,
				searchData: '',
				tableData: [],
				total: 0,
				pagesize: 50,
				tableHeight: '',
        clientHeight: 0,
        offsetTop: 0
      }
		},
		methods: {
			searchList (index) {
				this.$http
				.get("api/project/selectAllSuccessData?pageNum="+index
				+"&pageSize="+this.pagesize
				+"&hzid="+this.$route.query.hzid
				+"&xmid="+this.$route.query.xmid
				+"&query="+this.searchData)
				.then(res => {
					this.tableData = res.data.list
					this.total = res.data.total
				})
				.catch(function(err) {                                                                                                                                                                                   
					console.log(err)
				})
			}, // 查询项目导入的相关数据
			changePage (index) {
				this.page = index
				this.searchList(index)
			},
			sizeChange (value) {
				this.pagesize = value
    		this.searchList(1)
			},
			exportList () {
				location.href = "api/project/downloadAllExcel?xmid="+this.$route.query.xmid
				+"&hzid="+this.$route.query.hzid
			},
			exitHandle () {
				this.$router.push('/voteCheck')
			}
		},
		mounted () {
			this.searchList(1)
			this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
      this.clientHeight = `${document.documentElement.clientHeight}`
      this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
      window.onresize = () => {
        return (() => {
          this.clientHeight = `${document.documentElement.clientHeight}`
          this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
        })()
      }
		}
 }
</script>

<style scoped>

.header-left {
  margin-top: 15px;
  float: left;
}
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.el-table td, .el-table th {
  padding: 15px 0 !important;
}
.diyButton {
  width: 54px;
  height: 55px;
  transform: rotate(36deg);
  padding: 30px 0px 0 0;
  position: fixed;
  right: -21px;
  top: 90px;
}
.exportButton {
  position: relative;
  left: -30px;
}

</style>