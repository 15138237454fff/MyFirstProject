<template>
  <div class="vote4">
    <div class="header-left">
      <el-input
        v-model="searchData"
        placeholder="请输入项目名称"
        style="width:70%"
        @keyup.enter.native="searchList(1)">
      </el-input>
      <el-button style="margin-left:5px" @click="searchList(1)">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" @click="exportList" class="exportButton">导出</el-button>
      <el-button type="info" icon="el-icon-close" class="diyButton" @click="exitHandle"></el-button>
    </div>
		<div style="clear: both"></div>
		<div class="table">
			<el-table
				ref="multipleTable"
				:data="tableData"
				border
				style="width: 100%"
				:height="tableHeight">
				<el-table-column
					:show-overflow-tooltip="true"
					fixed="left"
					prop="no"
					label="序号"
					width="55px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					fixed="left"
					prop="collegeName"
					label="学院排序"
					width="130px">
				</el-table-column>
				<el-table-column
					prop="stuName"
					fixed="left"
					:show-overflow-tooltip="true"
					label="姓名"
					width="80px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuId"
					fixed="left"
					label="学号"
					width="130px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuGender"
					width="80px"
					label="性别">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="majorName"
					width="150px"
					label="学科专业名称">
				</el-table-column>
				<el-table-column
					prop="paperTitle"
					width="400px"
					label="论文题目">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.paperTitle.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.paperTitle" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="tutorName"
					width="120px"
					label="导师姓名">
				</el-table-column>
				<el-table-column
					prop="publishName"
					width="400px"
					label="发表文章/刊物名称">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.publishName.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.publishName" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					prop="assDissertation"
					width="150px"
					label="学位论文的关联性">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.assDissertation.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.assDissertation" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					prop="patentStatus"
					width="400px"
					label="获奖(专利)情况">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.patentStatus.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.patentStatus" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="assDissertationCopy"
					width="150px"
					label="学位论文的关联性">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					width="100px"
					prop="reviewResult"
					label="评阅成绩">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="recShoolBest"
					width="120px"
					label="推荐校优情况">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="recProvincBest"
					width="120px"
					label="推荐省优情况">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="isRecommend"
					width="170px"
					label="答辩委员会是否推优">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="remark"
					width="120px"
					label="备注">
				</el-table-column>
			</el-table>
			<div class="block">
				<el-pagination :current-page.sync="currentPage" 
				:page-sizes="[20, 50, 100]"
				:pager-count="3" :page-size="pagesize" class="import"
				layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total"
				@size-change="sizeChange">
				</el-pagination>
			</div>
		</div>
  </div>
</template>

<script>
  export default {
    data () {
      return {
				currentPage: 1,
				searchData: '',
				tableData: [],
				total: 0,
				pagesize: 50,
				tableHeight: '',
        clientHeight: 0,
        offsetTop: 0
      }
		},
		methods: {
			searchList (index) {
				this.$http
				.get("api/project/selectAllSuccessData?pageNum="+index
				+"&pageSize="+this.pagesize
				+"&hzid="+this.$route.query.hzid
				+"&xmid="+this.$route.query.xmid
				+"&query="+this.searchData)
				.then(res => {
					this.tableData = res.data.list
					this.total = res.data.total
					res.data.list.map((item, index) => {
						console.log(item.studentId)
						if (item.studentId != undefined) {
							this.tableData[index].stuId = item.studentId
						}
					})
				})
				.catch(function(err) {                                                                                                                                                                                   
					console.log(err)
				})
			}, // 查询项目导入的相关数据
			changePage (index) {
				this.page = index
				this.searchList(index)
			},
			sizeChange (value) {
				this.pagesize = value
    		this.searchList(1)
			},
			exportList () {
				location.href = "api/project/downloadAllExcel?xmid="+this.$route.query.xmid
				+"&hzid="+this.$route.query.hzid
			},
			exitHandle () {
				this.$router.push('/voteCheck')
			}
		},
		mounted () {
			this.searchList(1)
			this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
      this.clientHeight = `${document.documentElement.clientHeight}`
      this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
      window.onresize = () => {
        return (() => {
          this.clientHeight = `${document.documentElement.clientHeight}`
          this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
        })()
      }
		}
 }
</script>

<style scoped>

.header-left {
  margin-top: 15px;
  float: left;
}
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 10px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.el-table td, .el-table th {
  padding: 15px 0 !important;
}
.diyButton {
  width: 54px;
  height: 55px;
  transform: rotate(36deg);
  padding: 30px 0px 0 0;
  position: fixed;
  right: -21px;
  top: 90px;
}
.exportButton {
  position: relative;
  left: -30px;
}

</style>