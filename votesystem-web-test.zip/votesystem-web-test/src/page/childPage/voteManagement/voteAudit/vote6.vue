<template>
  <div class="vote6">
      <div class="header-left">
      <el-input
        v-model="searchData"
        placeholder="请输入项目名称"
        style="width:70%"
        @keyup.enter.native="searchList(1)">
      </el-input>
      <el-button style="margin-left:5px" @click="searchList(1)">查询</el-button>
    </div>
    <div class="header-right">
			<el-button type='danger' @click="backClick" v-show="$route.query.backShow">退 回</el-button>
      <el-button type="info" icon="el-icon-close" class="diyButton" @click="exitHandle"></el-button>
			<el-button type="primary" @click="auditComplete">审核完成</el-button>
    </div>
    <div style="clear: both"></div>
		<div class="table">
			<el-table
				ref="multipleTable"
				:data="tableData"
				@selection-change="handleSelect"
				@row-click="clickRow"
				border
				style="width: 100%"
				@select-all="allClick"
				:height="tableHeight">
				<el-table-column
					fixed="left"
          type="selection"
          width="55">
        </el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					fixed="left"
					prop="no"
					label="序号"
					width="55px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="collegeName"
					fixed="left"
					label="学院"
					width="130px">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.collegeName}}</span>
						<el-input v-model="scope.row.collegeName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					prop="stuName"
					fixed="left"
					:show-overflow-tooltip="true"
					label="姓名"
					width="80px">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.stuName}}</span>
						<el-input v-model="scope.row.stuName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuId"
					fixed="left"
					label="学号"
					width="130px">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.stuId}}</span>
						<el-input v-model="scope.row.stuId" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="applicatCategory"
					width="150px"
					label="申请人类别">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.applicatCategory}}</span>
						<el-input v-model="scope.row.applicatCategory" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="majorName"
					width="150px"
					label="授予学位专业名称">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.majorName}}</span>
						<el-input v-model="scope.row.majorName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="isPunishment"
					width="120px"
					label="是否受过处分">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.isPunishment}}</span>
						<el-input v-model="scope.row.isPunishment" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="graduationDate"
					width="90px"
					label="毕业时间">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.graduationDate}}</span>
						<el-input v-model="scope.row.graduationDate" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="resultNum"
					width="90px"
					label="成果总数">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.resultNum}}</span>
						<el-input v-model="scope.row.resultNum" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="publishTime"
					width="130px"
					label="发表/获奖时间">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.publishTime}}</span>
						<el-input v-model="scope.row.publishTime" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="resultName"
					width="400px"
					label="成果名称">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.resultName}}</span>
						<el-input v-model="scope.row.resultName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="writerSort"
					width="180px"
					label="作者排序">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.writerSort}}</span>
						<el-input v-model="scope.row.writerSort" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="resultLevel"
					width="140px"
					label="成果等级">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.resultLevel}}</span>
						<el-input v-model="scope.row.resultLevel" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="resultSource"
					width="200px"
					label="成果出处">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.resultSource}}</span>
						<el-input v-model="scope.row.resultSource" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="issn"
					width="140px"
					label="刊号">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.issn}}</span>
						<el-input v-model="scope.row.issn" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="assDissertation"
					width="180px"
					label="学位论文的关联性">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.assDissertation}}</span>
						<el-input v-model="scope.row.assDissertation" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="contributionIllustrate"
					width="300px"
					label="所做贡献的具体说明">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.contributionIllustrate}}</span>
						<el-input v-model="scope.row.contributionIllustrate" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="degreeAppication"
					width="300px"
					label="申请学位情况(符合情况)">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.degreeAppication}}</span>
						<el-input v-model="scope.row.degreeAppication" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subcommitteeNum"
					width="120px"
					label="分委员会人数">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.subcommitteeNum}}</span>
						<el-input v-model="scope.row.subcommitteeNum" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subagreeNum"
					width="100px"
					label="同意票数">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.subagreeNum}}</span>
						<el-input v-model="scope.row.subagreeNum" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subdisagreeNum"
					width="110px"
					label="不同意票数">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.subdisagreeNum}}</span>
						<el-input v-model="scope.row.subdisagreeNum" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="subabstention"
					width="100px"
					label="弃权票数">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.subabstention}}</span>
						<el-input v-model="scope.row.subabstention" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="isPassed"
					width="120px"
					label="是否通过审核">
				</el-table-column>
				<el-table-column
					fixed="right"
					label="操作"
					width="120px">
					<template slot-scope="scope">
						<el-button type="text" @click="modificationRow(scope.$index, scope.row)" v-show="scope.row.isModification">修改</el-button>
						<el-button type="text" @click="cancelRow(scope.$index, scope.row)" v-show="!scope.row.isModification">取消</el-button><span v-show="!scope.row.isModification">|</span>
						<el-button type="text" @click="saveRow(scope.$index, scope.row)" v-show="!scope.row.isModification" style="margin-left: -5px">保存</el-button>
					</template>	
				</el-table-column>
				<el-table-column
          prop="isModification"
          label="修改参数"
          width="1px">
        </el-table-column>
			</el-table>
			<div class="block">
				<el-pagination :current-page.sync="currentPage" 
				:page-sizes="[20, 50, 100]"
				:pager-count="3" :page-size="pagesize" class="import"
				layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total"
				@size-change="sizeChange">
				</el-pagination>
			</div>
		</div>
  </div>
</template>

<script>
  export default {
    data () {
      return {
				searchData: '',
				tableData: [],
				total: 0,
				pagesize: 50,
				handleList: [],
				arr: [],
				tableHeight: '',
        clientHeight: 0,
        offsetTop: 0
      }
		},
		methods: {
			clickRow(row, column, event) {
        this.$refs.multipleTable.toggleRowSelection(row)
      },
			handleSelect (selection) {	
				this.handleList = []
				selection.map((item, index) => {
					this.handleList.push(item.id)
				})
				console.log(this.handleList)
			},
			searchList (index) {
				this.$http
				.get("api/project/selectDataByType?pageNum="+index
				+"&pageSize="+this.pagesize
				+"&hzid="+this.$route.query.hzid
				+"&xmid="+this.$route.query.xmid
				+"&importId="+this.$route.query.importId
				+"&query="+this.searchData)
				.then(res => {
						this.tableData = res.data.list
						this.total = res.data.total
						let t = true
						this.tableData.map((item, index) => {
							item.isModification = t
						})
				})
				.catch(function(err) {                                                                                                                                                                                   
					console.log(err)
				})
			},
			changePage (index) {
				this.page = index
				this.searchList(index)
			},
			sizeChange (value) {
				this.pagesize = value
				this.searchList(1)
			},
			modificationRow (index, row) {
				row.isModification = false
			},
			cancelRow (index, row) {
				row.isModification = true
			},
			saveRow (index, row) {
				row.isModification = true
				this.$http
					.post("api/templateDoctorSummary/updateById", row)
					.then(res => {

					})
					.catch(function(err) {                                                                                                                                                                                       
						console.log(err)
					})
			},
			allClick (selection) {
				this.handleList = []
				selection.map((item, index) => {
					this.handleList.push(item.id)
				})
				console.log(this.handleList)
			}	,
			backClick () {
				this.handleList.map((item, index) => {
					this.arr.push(item)
				})
				this.backList = [...new Set(this.arr)]
			},
			auditComplete () {
				if (this.backList == []) {
					this.$message({
						type: 'success',
						message: '审核成功' 
					})
				} else {
					this.$http
					.put("api/check/cancelData?hzid="+this.$route.query.hzid
					+"&projectId="+this.$route.query.xmid
					+"&importId="+this.$route.query.importId
					+"&checkId="+this.$route.query.id,this.backList)
					.then(res => {
						if(res.data.code == 200) {
							this.$message({
								type: 'success',
								message: '审核成功' 
							})
						} else {
							this.$message('审核失败')
						}
					})
					.catch(function(err) {                                                                                                                                                                               
						
					})
				}
				this.searchData = ''
			},
			exitHandle () {
				this.$router.push('/voteAudit')
			}
		},
		mounted () {
			this.searchList(1)
			this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
      this.clientHeight = `${document.documentElement.clientHeight}`
      this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
      window.onresize = () => {
        return (() => {
          this.clientHeight = `${document.documentElement.clientHeight}`
          this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
        })()
      }
		}
 }
</script>

<style scoped>

.header-left {
  margin-top: 15px;
  float: left;
}
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 40px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.el-table td, .el-table th {
  padding: 15px 0 !important;
}
.diyButton {
  width: 54px;
  height: 55px;
  transform: rotate(36deg);
  padding: 30px 0px 0 0;
  position: fixed;
  right: -21px;
  top: 90px;
}

</style>
