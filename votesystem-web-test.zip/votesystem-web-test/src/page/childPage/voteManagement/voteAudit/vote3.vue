<template>
  <div class="vote3">
      <div class="header-left">
      <el-input
        v-model="searchData"
        placeholder="请输入项目名称"
        style="width:70%"
        @keyup.enter.native="searchList(1)">
      </el-input>
      <el-button style="margin-left:5px" @click="searchList(1)">查询</el-button>
    </div>
    <div class="header-right">
			<el-button type='danger' @click="backClick" v-show="$route.query.backShow">退 回</el-button>
      <el-button type="info" icon="el-icon-close" class="diyButton" @click="exitHandle"></el-button>
			<el-button type="primary" @click="auditComplete">审核完成</el-button>
    </div>
    <div style="clear: both"></div>
		<div class="table">
			<el-table
				ref="multipleTable"
				:data="tableData"
				@selection-change="handleSelect"
				@row-click="clickRow"
				border
				style="width: 100%"
				@select-all="allClick"
				:height="tableHeight">
				<el-table-column
					fixed="left"
          type="selection"
          width="55">
        </el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					fixed="left"
					prop="no"
					label="序号"
					width="55px">
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="collegeName"
					fixed="left"
					label="学院排序"
					width="130px">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.collegeName}}</span>
						<el-input v-model="scope.row.collegeName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuName"
					fixed="left"
					width="80px"
					label="姓名">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.stuName}}</span>
						<el-input v-model="scope.row.stuName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuId"
					fixed="left"
					label="学号"
					width="130px">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.stuId}}</span>
						<el-input v-model="scope.row.stuId" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="stuGender"
					width="80px"
					label="性别">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.stuGender}}</span>
						<el-input v-model="scope.row.stuGender" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="majorName"
					width="150px"
					label="学科专业名称">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.majorName}}</span>
						<el-input v-model="scope.row.majorName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					prop="paperTitle"
					width="400px"
					label="论文题目">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.paperTitle.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.paperTitle" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="tutorName"
					width="120px"
					label="导师姓名">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.tutorName}}</span>
						<el-input v-model="scope.row.tutorName" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					prop="publishName"
					width="400px"
					label="发表文章/刊物名称">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.publishName.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.publishName" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="assDissertation"
					width="150px"
					label="学位论文的关联性">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.assDissertation}}</span>
						<el-input v-model="scope.row.assDissertation" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					prop="patentStatus"
					width="400px"
					label="获奖(专利)情况">
					<template slot-scope="scope">
						<el-tooltip placement="right-end" :enterable="false" transition="0s" style="z-index:99999" :offset='100'>
							<div slot="content" v-html="scope.row.patentStatus.replace(/\n/g,'<br><br>')"></div>
							<div v-html="scope.row.patentStatus" class="ellip" style="text-overflow:ellipsis;overflow:hidden;white-space:nowrap"></div>
						</el-tooltip>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="assDissertationCopy"
					width="150px"
					label="学位论文的关联性">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.assDissertationCopy}}</span>
						<el-input v-model="scope.row.assDissertationCopy" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="reviewResult"
					width="100px"
					label="评阅成绩">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.reviewResult}}</span>
						<el-input v-model="scope.row.reviewResult" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="recShoolBest"
					width="120px"
					label="推荐校优情况">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.recShoolBest}}</span>
						<el-input v-model="scope.row.recShoolBest" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="recProvincBest"
					width="120px"
					label="推荐省优情况">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.recProvincBest}}</span>
						<el-input v-model="scope.row.recProvincBest" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="isRecommend"
					width="170px"
					label="答辩委员会是否推优">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.isRecommend}}</span>
						<el-input v-model="scope.row.isRecommend" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					:show-overflow-tooltip="true"
					prop="remark"
					width="120px"
					label="备注">
					<template slot-scope="scope">
						<span v-show="scope.row.isModification">{{scope.row.remark}}</span>
						<el-input v-model="scope.row.remark" v-show="!scope.row.isModification"></el-input>
					</template>
				</el-table-column>
				<el-table-column
					fixed="right"
					label="操作"
					width="120px">
					<template slot-scope="scope">
						<el-button type="text" @click="modificationRow(scope.$index, scope.row)" v-show="scope.row.isModification">修改</el-button>
						<el-button type="text" @click="cancelRow(scope.$index, scope.row)" v-show="!scope.row.isModification">取消</el-button><span v-show="!scope.row.isModification">|</span>
						<el-button type="text" @click="saveRow(scope.$index, scope.row)" v-show="!scope.row.isModification" style="margin-left: -5px">保存</el-button>
					</template>	
				</el-table-column>
				<el-table-column
          prop="isModification"
          label="修改参数"
          width="1px">
        </el-table-column>
			</el-table>
			<div class="block">
				<el-pagination :current-page.sync="currentPage" 
				:page-sizes="[20, 50, 100]"
				:pager-count="3" :page-size="pagesize" class="import"
				layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total"
				@size-change="sizeChange">
				</el-pagination>
			</div>
		</div>
  </div>
</template>

<script>
  export default {
    data () {
      return {
				searchData: '',
				tableData: [],
				total: 0,
				pagesize: 50,
				handleList: [],
				arr: [],
				tableHeight: '',
        clientHeight: 0,
        offsetTop: 0
      }
		},
		methods: {
			clickRow(row, column, event) {
        this.$refs.multipleTable.toggleRowSelection(row)
      },
			handleSelect (selection) {	
				this.handleList = []
				selection.map((item, index) => {
					this.handleList.push(item.id)
				})
			},
			searchList (index) {
				this.$http
				.get("api/project/selectDataByType?pageNum="+index
				+"&pageSize="+this.pagesize
				+"&hzid="+this.$route.query.hzid
				+"&xmid="+this.$route.query.xmid
				+"&importId="+this.$route.query.importId
				+"&query="+this.searchData)
				.then(res => {
						this.tableData = res.data.list
						this.total = res.data.total
						let t = true
						this.tableData.map((item, index) => {
							item.isModification = t
						})
						res.data.list.map((item, index) => {
							if (item.studentId != undefined) {
								this.tableData[index].stuId = item.studentId
							}
						})
				})
				.catch(function(err) {                                                                                                                                                                                   
					console.log(err)
				})
			},
			changePage (index) {
				this.page = index
				this.searchList(index)
			},
			sizeChange (value) {
				this.pagesize = value
				this.searchList(1)
			},
			modificationRow (index, row) {
				row.isModification = false
			},
			cancelRow (index, row) {
				row.isModification = true
			},
			saveRow (index, row) {
				row.isModification = true
				this.$http
					.post("api/templateDoctorSummary/updateById", row)
					.then(res => {

					})
					.catch(function(err) {                                                                                                                                                                                       
						console.log(err)
					})
			},
			allClick (selection) {
				this.handleList = []
				selection.map((item, index) => {
					this.handleList.push(item.id)
				})
			}	,
			backClick () {
				this.handleList.map((item, index) => {
					this.arr.push(item)
				})
				this.backList = [...new Set(this.arr)]
			},
			auditComplete () {
				if (this.backList == []) {
					this.$message({
						type: 'success',
						message: '审核成功' 
					})
				} else {
					this.$http
					.put("api/check/cancelData?hzid="+this.$route.query.hzid
					+"&projectId="+this.$route.query.xmid
					+"&importId="+this.$route.query.importId
					+"&checkId="+this.$route.query.id,this.backList)
					.then(res => {
						if(res.data.code == 200) {
							this.$message({
								type: 'success',
								message: '审核成功' 
							})
						} else {
							this.$message('审核失败')
						}
					})
					.catch(function(err) {                                                                                                                                                                               
						
					})
				}
				this.searchData = ''
			},
			exitHandle () {
				this.$router.push('/voteAudit')
			}
		},
		mounted () {
			this.searchList(1)
			this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
      this.clientHeight = `${document.documentElement.clientHeight}`
      this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
      window.onresize = () => {
        return (() => {
          this.clientHeight = `${document.documentElement.clientHeight}`
          this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
        })()
      }
		}
 }
</script>

<style scoped>

.header-left {
  margin-top: 15px;
  float: left;
}
.header-right {
  margin-top: 15px;
  float: right;
  margin-right: 40px;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.el-table td, .el-table th {
  padding: 15px 0 !important;
}
.diyButton {
  width: 54px;
  height: 55px;
  transform: rotate(36deg);
  padding: 30px 0px 0 0;
  position: fixed;
  right: -21px;
  top: 90px;
}

</style>
