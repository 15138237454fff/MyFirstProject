<!-- 投票数据查看 -->
<template>
  <div class="voteCheck">
    <div class="main-container" v-show="!polloptsShow">
      <div class="header-left">
        <el-input v-model="searchInfo" placeholder="请输入项目名称" style="width:70%" @keyup.enter.native="takeList(1)"></el-input>
        <el-button @click="takeList(1)" style="margin-left:5px">查询</el-button>
      </div>
      <div style="clear: both"></div>
      <div class="table">
        <el-table @row-click="clickRow" ref="multipleTable" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
          <el-table-column prop="number" label="序号" type="index" width="100px">
          </el-table-column>
          <el-table-column prop="name" label="项目名称">
          </el-table-column>
          <el-table-column prop="rule" label="投票规则">
          </el-table-column>
          <el-table-column prop="shape" label="投票形式">
          </el-table-column>
          <el-table-column prop="startTime" label="投票时间">
          </el-table-column>
          <el-table-column label="查看数据">
            <template slot-scope="scope">
              <el-button @click="pollopts(scope.$index, scope.row)" type="small">投票数据汇总</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="block">
        <el-pagination :current-page.sync="currentPage" :page-sizes="[5, 10, 50, 100]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
        </el-pagination>
      </div>
    </div>
    <checkDetails ref="checkDetails" v-show="polloptsShow"></checkDetails>
  </div>
</template>

<script>
import checkDetails from './voteCheck/checkDetails'
export default {
  name: 'voteCheck',
  data() {
    return {
      myrow: {},
      pagesize1: 5,
      searchData: '',
      searchInfo: '', // 搜索的数据
      voteDataList: [{
        college: '1111', // 学院
        name: '2222', // 姓名
        number: '3333', // 学号
        grade: '', // 年级
        professionName: '' // 授予学位专业名称
      },
      {
        college: '1111',
        name: '2222',
        number: '3333',
        grade: '',
        professionName: ''
      }],
      polloptsShow: false, // 投票数据弹出框
      currentPage: 1, // 起始页
      pagesize: 10, // 每页条数
      tableData: [],
      total: 0, // 总的数据条数
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0
    }
  },
  methods: {
    exportList() {

    },
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    closeVoteTable() {
      this.polloptsShow = false
    },
    pollopts(index, row) {
      this.polloptsShow = true
      this.myrow = row
      if (row.id != undefined) {
        this.$refs.checkDetails.loadInfo(row)
      }
    },
    takeList(index) {
      this.$http
        .post("api/vdc/collect/list", {
          pageNum: index,
          pageSize: this.pagesize,
          query: this.searchInfo
        })
        .then(res => {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
          res.data.data.list.map((item, index) => {
            this.tableData = res.data.data.list
            this.total = res.data.data.total
            res.data.data.list.map((item, index) => {
              let status = ''
              if (item.checkStatus == '0') {
                status = '待审核'
              } else if (item.checkStatus == '1') {
                status = '退回'
              } else if (item.checkStatus == '2') {
                status = '审核成功'
              } else if (item.checkStatus == '3') {
                status = '未提交'
              }
              if (item.voteRules == '0') {
                this.tableData[index].rule = '同意制'
              } else if (item.voteRules == '1') {
                this.tableData[index].rule = '打分制'
              } else if (item.voteRules == '2') {
                this.tableData[index].rule = '排名制'
              }
              if (item.voteForm == '0') {
                this.tableData[index].shape = '现场实名'
              } else if (item.voteForm == '1') {
                this.tableData[index].shape = '现场匿名'
              } else if (item.voteForm == '2') {
                this.tableData[index].shape = '网上实名'
              } else if (item.voteForm == '2') {
                this.tableData[index].shape = '网上匿名'
              }
              this.tableData[index].status = status
              this.tableData[index].submitNum = false
            })
          })
        })
        .catch(function (err) {
          console.log(err)
        })
    }, // 查询所有列表数据
    changePage(index) {
      this.page = index
      this.takeList(index)
    }, // 翻页时的数据

    sizeChange(value) {
      this.pagesize = value
      this.takeList(1)
    }, // 切换每页条数
    handleClose(done) {
      this.searchData = ''
      this.pagesize1 = 5
      done()
    }, // 关闭投票数据

  },
  mounted() {
    this.takeList(0)
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  },
  components: {
    checkDetails
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.header-left {
  margin-top: 15px;
  float: left;
}
.header-left button,
.dia-left button,
.dia-right button {
  /* border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px; */
}
.header-left input,
.dia-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.header-right {
  margin-top: 15px;
  float: right;
}
.dia-left {
  float: left;
  margin-bottom: 10px;
}
.dia-right {
  float: right;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.voteCheck /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
</style>

<style>
.el-pagination {
  text-align: center;
}
</style>

