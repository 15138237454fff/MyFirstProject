<!-- 投票数据审核 -->
<template>
  <div class="voteAudit">
    <div  v-show="!showVote">
    <el-tabs v-model="activeName" @tab-click="tabChangeClick">
      <el-tab-pane label="待审核" name="first"></el-tab-pane>
      <el-tab-pane label="已审核" name="second"></el-tab-pane>
    </el-tabs>
    <br>
    <div style="clear: both;"></div>
    <div class="header-middle">
      <el-input v-model="searchField" placeholder="请输入项目名称" style="width:70%" @keyup.enter.native="takeList(1)"></el-input>
      <el-button @click="takeList(1)" style="margin-left:5px">查询</el-button>
    </div>
    <div class="header-right">
      <el-button type="primary" v-show="isShow" @click="oneKeyPass">一键通过</el-button>
      <el-button type="warning" v-show="isShow" @click="oneKeyBack">一键退回</el-button>
    </div>
    <div style="clear: both"></div>
    <div class="table">
      <el-table @selection-change="mySelect" @row-click="clickRow" ref="multipleTable" :data="tableData" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
        <el-table-column v-if="myStatus == 0" :show-overflow-tooltip="true" type="selection" :key="Math.random()" width="55">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="rule" :key="Math.random()" label="投票规则">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="shape" :key="Math.random()" label="投票形式">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="name" :key="Math.random()" label="项目名称">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="userName" :key="Math.random()" label="申请人">
        </el-table-column>
        <el-table-column :show-overflow-tooltip="true" prop="applyTime" :key="Math.random()" label="申请时间">
        </el-table-column>
        <el-table-column prop="voteData" :key="Math.random()" label="投票数据">
          <template slot-scope="scope">
            <el-button size="small" @click="checkInfor(scope.$index, scope.row)">查看数据</el-button>
          </template>
        </el-table-column>
        <el-table-column v-if="myStatus == 1" prop="checkstatus" :key="Math.random()" label="审核状态" width="100">
        </el-table-column>
      </el-table>
    </div>
    <el-dialog title="投票数据" :visible.sync="polloptsShow" width="700px">
      <p class="hr"></p>
      <div class="table">
        <el-table ref="voteTable" :data="voteDataList" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;">
          <el-table-column prop="order" label="序号">
          </el-table-column>
          <el-table-column prop="college" label="学院">
          </el-table-column>
          <el-table-column prop="name" label="姓名">
          </el-table-column>
          <el-table-column prop="number" label="学号">
          </el-table-column>
          <el-table-column prop="grade" label="年级">
          </el-table-column>
          <el-table-column prop="professionName" label="授予学位专业名称">
          </el-table-column>
        </el-table>
      </div>
    </el-dialog>
    <!--六个列表  -->
    <div class="block">
      <el-pagination :current-page.sync="currentPage" :page-sizes="[10, 20, 50]" :page-size="pagesize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="total" @size-change="sizeChange">
      </el-pagination>
    </div>
    </div>
    <importDetails ref="importDetails" v-show="showVote"></importDetails>
  </div>
</template>

<script>
import importDetails from './voteImport/importDetails'
export default {
  components: {
    importDetails
  },
  name: 'voteAudit',
  data() {
    return {
      showVote: false,
      backShow: true, // 是否显示退回
      searchField: '', // 搜索参数
      arr: [],
      backList: [], // 退回列表
      activeName: 'first', // tab默认选中
      getRowKeys(row) {
        return row.id;
      },
      hzid: '',
      xmid: '',
      id: '',
      importId: '',
      total: 0,
      myStatus: 0,
      isShow: true, // 按钮是否显示
      polloptsShow: false, // 投票数据弹出框
      waitStatus: 'primary', // 待审核按钮状态
      alreadyStatus: '', // 已审核按钮状态
      currentPage: 1, // 起始页
      pagesize: 10, // 每页条数
      voteDataList: [{
        order: '1',
        college: '1111', // 学院
        name: '2222', // 姓名
        number: '1', // 学号
        grade: '', // 年级
        professionName: '' // 授予学位专业名称
      },
      {
        order: '1',
        college: '1111',
        name: '2222',
        number: '2',
        grade: '',
        professionName: ''
      }],
      tableData: [],
      total: 0, // 列表总条数
      passList: [], // 一键通过列表
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0
    }
  },
  methods: {
    changePage(index) {
      this.page = index
      this.takeList(index)
    },
    tabChangeClick(tab, event) {
      if (tab.label == '待审核') {
        this.isShow = true
        this.backShow = true
      } else if (tab.label == '已审核') {
        this.isShow = false
        this.backShow = false
      }
      this.takeList(1)
    }, // 切换头部导航
    clickRow(row, column, event) {
      this.$refs.multipleTable.toggleRowSelection(row)
    },
    mySelect(selection) {
      this.passList = []
      selection.map((item, index) => {
        this.passList.push(item.id)
      })
    }, // 用户勾选table中的某一项
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
    closeVoteTable() {
      this.showVote = false
    },
    checkInfor(index, row) {
      this.myrow = row
      this.showVote = true
      this.$refs.importDetails.loadInfo(row)
    }, // 查看导入数据
    takeList(index) {
      if (this.activeName == 'first') {
        this.$http
          .post("api/vdc/check/list", {
            pageNum: index,
            pageSize: this.pagesize,
            query: this.searchField
          })
          .then(res => {
            this.tableData = res.data.data.list
            this.total = res.data.data.total
            res.data.data.list.map((item, index) => {
              this.tableData = res.data.data.list
              this.total = res.data.data.total
              res.data.data.list.map((item, index) => {
                let status = ''
                if (item.checkStatus == '0') {
                  status = '待审核'
                } else if (item.checkStatus == '1') {
                  status = '退回'
                } else if (item.checkStatus == '2') {
                  status = '审核成功'
                } else if (item.checkStatus == '3') {
                  status = '未提交'
                }
                if (item.voteRules == '0') {
                  this.tableData[index].rule = '同意制'
                } else if (item.voteRules == '1') {
                  this.tableData[index].rule = '打分制'
                } else if (item.voteRules == '2') {
                  this.tableData[index].rule = '排名制'
                }
                if (item.voteForm == '0') {
                  this.tableData[index].shape = '现场实名'
                } else if (item.voteForm == '1') {
                  this.tableData[index].shape = '现场匿名'
                } else if (item.voteForm == '2') {
                  this.tableData[index].shape = '网上实名'
                } else if (item.voteForm == '2') {
                  this.tableData[index].shape = '网上匿名'
                }
                this.tableData[index].status = status
                this.tableData[index].submitNum = false
              })
            })
          })
          .catch(function (err) {
            console.log(err)
          })
      } else if (this.activeName == 'second') {
        this.$http
          .post("api/vdc/checked/list", {
            pageNum: index,
            pageSize: this.pagesize,
            query: this.searchField
          })
          .then(res => {
            this.tableData = res.data.data.list
            this.total = res.data.data.total
            res.data.data.list.map((item, index) => {
              this.tableData = res.data.data.list
              this.total = res.data.data.total
              res.data.data.list.map((item, index) => {
                let status = ''
                if (item.checkStatus == '0') {
                  status = '待审核'
                } else if (item.checkStatus == '1') {
                  status = '退回'
                } else if (item.checkStatus == '2') {
                  status = '审核成功'
                } else if (item.checkStatus == '3') {
                  status = '未提交'
                }
                if (item.voteRules == '0') {
                  this.tableData[index].rule = '同意制'
                } else if (item.voteRules == '1') {
                  this.tableData[index].rule = '打分制'
                } else if (item.voteRules == '2') {
                  this.tableData[index].rule = '排名制'
                }
                if (item.voteForm == '0') {
                  this.tableData[index].shape = '现场实名'
                } else if (item.voteForm == '1') {
                  this.tableData[index].shape = '现场匿名'
                } else if (item.voteForm == '2') {
                  this.tableData[index].shape = '网上实名'
                } else if (item.voteForm == '2') {
                  this.tableData[index].shape = '网上匿名'
                }
                this.tableData[index].status = status
                this.tableData[index].submitNum = false
              })
            })
          })
          .catch(function (err) {
            console.log(err)
          })
      }
    }, // 查询待审核数据
    oneKeyPass() {
      if (this.passList.length == 0) {
        this.$message.error({ message: "请选择数据！" })
      } else {
        this.$http
          .put("api/vdc/check/2", this.passList)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: '一键通过成功',
                type: "success"
              })
            } else {
              this.$message('一键通过失败')
            }
            this.takeList(1)
          })
          .catch(function (err) {

          })
      }
    }, // 一键通过
    oneKeyBack() {
      if (this.passList.length == 0) {
        this.$message.error({ message: "请选择数据！" })
      } else {
        this.$http
          .put("api/vdc/check/1", this.passList)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: '一键退回成功',
                type: "success"
              })
            } else {
              this.$message('一键退回失败')
            }
            this.takeList(1)
          })
          .catch(function (err) {

          })
      }
    }, // 一键退回
    sizeChange(value) {
      this.pagesize = value
      this.takeList(0)
    }, // 切换每页条数
    handleClose(done) {
      this.handleList = []
      this.backList = []
      done()
    },
    handleClose(done) {
      this.searchData = ''
      this.pagesize1 = 5
      done()
    }, // 关闭投票数据
    sizeChange1(value) {
      this.pagesize1 = value
      this.searchList(1)
    }
  },
  mounted() {
    this.takeList(0)
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  }
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}
.el-dialog__footer {
  text-align: center !important;
}
.listHandle {
  float: right;
  margin-bottom: 10px;
}
.header-left {
  margin-top: 5px;
  float: left;
}
.header-middle {
  float: left;
}
.header-right button,
.header-middle button,
.dia-left button,
.dia-right button {
  /* border: none;
  background: #237AE4;
  color: #fff;
  height: 30px;
  border-radius: 5px;
  padding: 5px 15px;
  margin-left: 10px; */
}
.header-left button {
  border-radius: 0;
}
.header-right input,
.header-middle input,
.dia-left input {
  height: 40px;
  border-radius: 4px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}
.header-right {
  float: right;
}
.dia-left {
  float: left;
  margin-bottom: 10px;
}
.dia-right {
  float: right;
}
.table {
  margin-top: 15px;
  width: 100%;
}
.header-left .el-button {
  margin-left: -5px !important;
}
.header-left .el-button:first-child {
  margin-left: 0 !important;
}
.header-right button {
  margin-left: 10px !important;
}
.hr {
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}
.header-middle {
}
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
::-webkit-scrollbar-thumb {
  background-color: transparent;
  /* border-radius: 3px; */
}
.voteAudit /deep/ .el-dialog .el-table td,
.el-table th {
  padding: 5px 0 !important;
}
.voteAudit /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
</style>

<style>
.el-pagination {
  text-align: center;
}
::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}
::-webkit-scrollbar-thumb {
  background-color: #ccc;
  border-radius: 3px;
}
.el-tabs__header {
  background: #f2f2f2;
  padding: 0 20px;
  height: 50px;
}
.el-tabs__nav-scroll {
  height: 50px;
}
.el-tabs__item {
  height: 50px;
  line-height: 50px;
}
.el-tabs__nav-wrap::after {
  background: transparent;
}
</style>
