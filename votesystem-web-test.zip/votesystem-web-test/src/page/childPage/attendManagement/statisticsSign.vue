<!-- 签到数据统计 -->
<template>
  <div class="statisticsSign">
    <!-- <div class="header-left">
      <input type="text" v-model="search" @keyup.enter.native="handleFind">
      <button @click="handleFind">查询</button>
    </div> -->
    <el-row style="width:100%;margin:0 auto;margin-bottom:7px;margin-top:20px">
      <el-col :span="10">
        <el-row style="float:left">
          <el-input clearable v-model="pageHelper.query" placeholder="请输入项目名称" style="width:70%" @keyup.enter.native="handleFind"></el-input>
          <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        </el-row>
      </el-col>
    </el-row>
    <!-- <div class="header-right">
      <button>添加</button>
      <button>修改</button>
      <button>删除</button>
    </div> -->
    <div style="clear: both"></div>
    <div class="table">
      <el-table ref="multipleTable" :data="this.pageInfo.list" tooltip-effect="dark" border :header-cell-style="tableHeaderColor" style="width: 100%;" :height="tableHeight">
        <el-table-column type="index" width="80" label="序号">
        </el-table-column>
        <el-table-column prop="name" label="项目名称" :show-overflow-tooltip="true" width="200">
        </el-table-column>
        <el-table-column prop="starttime" label="投票时间" width="300" :show-overflow-tooltip="true">
          <template slot-scope="scope">
            <span>{{scope.row.startTime}}--{{scope.row.endTime}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="address" label="投票地点" :show-overflow-tooltip="true">
        </el-table-column>
        <el-table-column prop="rate" label="签到率">
        </el-table-column>
        <el-table-column label="签到统计表" align="center">
          <template slot-scope="scope">
            <el-button size='small' @click="handleStatistic(scope.row)">签到统计表</el-button>
          </template>
        </el-table-column>
        <el-table-column label="签到入口" align="center">
          <template slot-scope="scope">
            <el-button size='small' @click="handleSign(scope.row.id,scope.row.name)">签到入口</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog :title="diaTitle" :visible.sync="statisticTable">
      <div class="header-left">
        <el-input v-model="searchData" placeholder="请输入用户名/姓名" style="width:200px">
        </el-input>
        <el-button style="margin-left:5px">查询</el-button>
      </div>
      <el-table :data="signInfo.list" border>
        <el-table-column prop="userName" label="用户名"></el-table-column>
        <el-table-column prop="name" label="姓名"></el-table-column>
        <el-table-column prop="phoneNum" label="手机号码" show-overflow-tooltip></el-table-column>
        <el-table-column label="签到状态" align="center">
          <template slot-scope="scope">
            <span>{{ scope.row.signState == 0 ? '未签到' : scope.row.signState == 1 ? '已签到' : ''}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="signDate" label="签到时间" show-overflow-tooltip></el-table-column>
      </el-table>
      <div class="block" style="margin-top:15px;text-align:center">
        <el-pagination @size-change="signHandleSizeChange" @current-change="signHandleCurrentChange" :current-page="signInfo.pageNum" :page-sizes="[10, 20, 50]" :page-size="signInfo.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="signInfo.total"></el-pagination>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="statisticTable = false">取 消</el-button>
        <el-button type="primary" @click="handleExport">导出</el-button>
      </div>
    </el-dialog>
    <!-- 分页 -->
    <div class="block" style="margin-top:15px;text-align:center">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageInfo.pageNum" :page-sizes="[10, 20, 50]" :page-size="pageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="pageInfo.total"></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  name: 'systemSign',
  data() {
    return {
      diaTitle: '',
      searchData: '',
      currentPage: 1, // 起始页
      pageSize: 10, // 每页条数
      // 分页
      statisticTable: false, //签到统计表
      currentPage: 1, // 当前页
      pageSize: 10, //分页中每页显示条数
      selectionRow: null, //选择的那一行，修改
      ID: null, //多选
      id: null,
      ids: [],
      search: '',
      list: [],
      statisticData: [],
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0,
      exportid: '',
      pageHelper: {
        query: null,
        pageNum: 1,
        pageSize: 10
      },
      pageInfo: {},
      signHelper: {
        pageNum: 1,
        pageSize: 10,
        projectId: null
      },
      signInfo: {}
    }
  },
  mounted() {
    this.loadTable()
    this.offsetTop = this.$refs.multipleTable.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
    this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    window.onresize = () => {
      return (() => {
        this.clientHeight = `${document.documentElement.clientHeight}`
        this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
      })()
    }
  },
  methods: {
    //项目列表Size改变
    handleSizeChange(val) {
      this.pageHelper.pageSize = val
      this.loadTable()
    },
    //签到信息列表Size改变
    signHandleSizeChange(val) {
      this.signHelper.pageSize = val
      this.loadSignTable()
    },
    //项目列表当前页改变
    handleCurrentChange(currentPage) {
      this.pageHelper.pageNum = currentPage
      this.loadTable()
    },
    //签到信息当前页改变
    signHandleCurrentChange(currentPage) {
      this.signHelper.pageNum = currentPage
      this.loadSignTable()
    },
    //加载列表
    loadTable() {
      this.$http
        .post('/api/sign/list', this.pageHelper)
        .then(res => {
          if (res.data.code == 200) {
            this.pageInfo = res.data.data
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    //查询
    handleFind() {
      this.loadTable()
    },
    handleSign(id, name) {
      this.$router.push({
        path: '/sign',
        query: {
          id: id,
          name: name
        }
      })
    },
    //签到统计表
    handleStatistic(row) {
      this.signHelper.projectId = row.id
      this.loadSignTable();
      this.statisticTable = true
      this.diaTitle = row.name + '签到统计表' + "(" + row.rate + ")"
      this.exportid = row.id
    },
    loadSignTable() {
      this.$http.post('/api/sign/roster', this.signHelper).then(res => {
        if (res.data.code == 200) {
          this.signInfo = res.data.data
        } else {
          this.$message.error(res.data.message)
        }
      })
    },
    //导出
    handleExport() {
      location.href = '/api/sign/export?projectId=' + this.exportid
      this.statisticTable = false
    },
    tableHeaderColor({
      row,
      column,
      rowIndex,
      columnIndex
    }) {
      if (rowIndex === 0) {
        return 'background-color: #F2F2F2;font-weight: 500;'
      }
    }, // 替换table中thead的颜色
  }
}

</script>

<style scoped>
* {
  box-sizing: border-box;
}

.header-left {
  float: left;
  margin-bottom: 10px;
}
.header-right {
  margin-top: 15px;
  float: right;
}

.header-left input {
  height: 40px;
  border-radius: 5px;
  outline: none;
  border: 1px solid #e0e0e0;
  margin-right: 10px;
}

.table {
  margin-top: 15px;
  width: 100%;
}
.statisticsSign /deep/ .el-dialog .el-dialog__footer {
  text-align: center;
  position: relative;
  top: -10px;
}
.statisticsSign /deep/ .dialog-footer button {
  margin: 0 20px;
}
</style>

<style>
.el-pagination {
  text-align: center;
}
</style>
