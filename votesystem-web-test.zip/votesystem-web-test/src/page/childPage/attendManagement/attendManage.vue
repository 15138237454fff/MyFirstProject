<!-- 签到项目管理 -->
<template>
  <div>
    <el-row style="width:100%;margin:0 auto;margin-bottom:7px;margin-top:20px">
      <el-col :span="10">
        <el-row style="float:left">
          <el-input
            clearable
            v-model="search"
            placeholder="搜索项目名称"
            style="width:70%"
            @keyup.enter.native="handleFind"
          ></el-input>
          <el-button @click="handleFind" style="margin-left:5px">查询</el-button>
        </el-row>
      </el-col>
      <el-col :span="14" class="ele-btn">
        <el-row style="float:right;font-weight:300">
          <!-- <el-button type="primary" @click="handleExport">导出会议签到</el-button> -->
        </el-row>
      </el-col>
    </el-row>
    <el-table
      ref="list"
      :data="list"
      border
      style="width: 100%"
      @select="handleSelect"
      @row-click="clickRow"
      @selection-change="handleSelectionChange"
      :header-cell-style="tableHeaderColor"
      :height="tableHeight"
      >
      <!-- <el-table-column type="selection" align="center" width="55"></el-table-column>
      <el-table-column label="序号" align="center" width="80" type="index" :index="indexMethod"> -->
        <!-- <template slot-scope="scope">
          <span>{{ scope.row.id }}</span>
        </template>-->
      <!-- </el-table-column> -->
      <el-table-column label="项目名称" align="center"
					:show-overflow-tooltip="true">
        <template slot-scope="scope">
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="时间" align="center"
					:show-overflow-tooltip="true">
        <template slot-scope="scope">
          <span>{{ scope.row.starttime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="地点" align="center"
					:show-overflow-tooltip="true">
        <template slot-scope="scope">
          <span>{{ scope.row.address }}</span>
        </template>
      </el-table-column>
      <!-- <el-table-column label="是否启用" align="center">
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.qy"
            @change="handleSwitch"
            active-value="1"
            inactive-value="2"
            disabled
          ></el-switch>
        </template>
      </el-table-column> -->
      <el-table-column label="签到入口" align="center">
        <template slot-scope="scope">
          <el-button size='small' @click="handleSign(scope.row.id,scope.row.name)">签到入口</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="block" style="margin-top:15px;text-align:center">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageList.currPage"
        :page-sizes="[10,50, 100]"
        :page-size="pageList.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pageList.total"
      ></el-pagination>
    </div>

    <el-dialog title="新增" :visible.sync="dialogAdd" width="500px">
      <el-form :model="addList" label-position="top">
        <el-form-item label="会议名称">
          <el-input v-model="addList.hymc"></el-input>
        </el-form-item>
        <el-form-item label="开始时间">
          <!-- <el-input v-model="list.kssj"></el-input> -->
          <el-date-picker
            v-model="addList.kssj"
            type="date"
            placeholder="选择日期"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间">
          <!-- <el-input v-model="list.jssj"></el-input> -->
          <el-date-picker
            v-model="addList.jssj"
            type="date"
            placeholder="选择日期"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input v-model="addList.ip"></el-input>
        </el-form-item>
        <el-form-item label="是否启用">
          <el-radio-group v-model="addList.qy">
            <el-radio-button label="1">是</el-radio-button>
            <el-radio-button label="2">否</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="是否允许外来人员进场">
          <el-radio-group v-model="addList.wlryqd">
            <el-radio-button label="1">是</el-radio-button>
            <el-radio-button label="2">否</el-radio-button>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAdd = false">取 消</el-button>
        <el-button type="primary" @click="addSubmit">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog title="修改" :visible.sync="dialogUpdate" width="500px">
      <el-form :model="updateList" label-position="top">
        <el-form-item label="会议名称">
          <el-input v-model="updateList.hymc"></el-input>
        </el-form-item>
        <el-form-item label="开始时间">
          <!-- <el-input v-model="list.kssj"></el-input> -->
          <el-date-picker
            v-model="updateList.kssj"
            type="date"
            placeholder="选择日期"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间">
          <!-- <el-input v-model="list.jssj"></el-input> -->
          <el-date-picker
            v-model="updateList.jssj"
            type="date"
            placeholder="选择日期"
            value-format="yyyy-MM-dd"
          ></el-date-picker>
        </el-form-item>
        <el-form-item label="IP地址">
          <el-input v-model="updateList.ip"></el-input>
        </el-form-item>
        <el-form-item label="是否启用">
          <el-radio-group v-model="updateList.qy">
            <el-radio-button label="1">是</el-radio-button>
            <el-radio-button label="2">否</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="是否允许外来人员进场">
          <el-radio-group v-model="updateList.wlryqd">
            <el-radio-button label="1">是</el-radio-button>
            <el-radio-button label="2">否</el-radio-button>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogUpdate = false">取 消</el-button>
        <el-button type="primary" @click="handleUpdate">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// import axios from "axios";
export default {
  data() {
    return {
      currentPage: 1, // 当前页
      pageSize: 10, //分页中每页显示条数
      // 分页
        pageList: {
          currPage: null,
          pageSize: 10,
          total: null,
          pages: null
        },
      search: "", //查询搜索字段
      dialogAdd: false, //新增弹窗
      dialogUpdate: false, //修改弹窗
      ID: null, //多选
      id: null,
      ids: [], //多个id
      addList: {}, //新增
      updateList: {}, //修改
      signmeets: {},
      selectionRow: null, //选择的那一行，修改
      list: [
        {
          hymc: "会议111",
          kssj: "11:00",
          jssj: "15:00",
          ipdz: "127.0.0.1",
          qy: "1"
        },
        {
          hymc: "会议222",
          kssj: "16:00",
          jssj: "18:00",
          ipdz: "192.68.0.1",
          qy: "2"
        }
      ],
      tableHeight: '',
      clientHeight: 0,
      offsetTop: 0
    }
  },
  computed: {
    dataFilter() {
      return this.list.filter(item => {
        if (
          item.hymc.indexOf(this.search) > -1 ||
          item.kssj.indexOf(this.search) > -1 ||
          item.jssj.indexOf(this.search) > -1 ||
          item.ipdz.indexOf(this.search) > -1
        ) {
          return item
        }
      });
    }
  },
  mounted() {
    this.loadTable()
    this.offsetTop = this.$refs.list.$el.offsetTop - document.documentElement.scrollTop
    this.clientHeight = `${document.documentElement.clientHeight}`
		this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
		window.onresize = () => {
			return (() => {
				this.clientHeight = `${document.documentElement.clientHeight}`
				this.tableHeight = document.documentElement.clientHeight-(this.offsetTop + 150)
			})()
		}
  },
  methods: {
    //改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageList.pageSize = val
        this.currentPage = this.pageList.currPage
        this.pageSize = this.pageList.pageSize
        this.loadTable()
    },
    //改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.pageList.currPage = currentPage
        this.currentPage = this.pageList.currPage
        this.loadTable()
      //   this.loadTable();
    },
    //列表序号
    indexMethod(index) {
      return (this.pageList.currPage - 1) * this.pageList.pageSize + index + 1
    },
    // 替换table中thead的颜色
    tableHeaderColor({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;";
      }
    },
    // 选择时触发
    handleSelect(selection,row){
      // console.log(selection)
      this.ID = row.id
      this.ids.push(this.ID)
      // console.log(this.ids)
    },
    //点击列表选中
    clickRow(row) {
      console.log(row)
      this.$refs.list.toggleRowSelection(row)
    },
    // 选择列表
    handleSelectionChange(selection) {
      if(selection.length == 0){
        this.selectionRow = {}
      }else{
        this.selectionRow = selection[0]
        this.id = selection[0].id
        console.log(selection)
        this.ids = []
        selection.forEach(item => {
          this.ids.push(item.id)
        });
        console.log(this.ids)
      }
    },
    //加载列表
    loadTable() {
      this.$http
        .get('/api/sign/'+this.currentPage+'/'+this.pageSize)
        .then(res => {
          console.log(res.data.data)
          this.list = res.data.data.list
          this.pageList.currPage = res.data.data.pageNum
            this.pageList.pageSize = res.data.data.pageSize
            this.pageList.total = res.data.data.total
        })
        .catch(function(err) {
          console.log(err);
        });
    },
    //签到
    handleSign(id,name){
      console.log(id,name)
      this.$router.push({
        path: '/sign',
        query: {
          id: id,
          name: name
        }
      })
    },
    //查询
    handleFind(){
      this.$http
        .get(
          '/api/sign/search/'+this.currentPage+'/'+this.pageSize,{
            params: {
              name: this.search
            }
          }
        )
        .then(res => {
          // console.log(res.data.data.list)
          this.list = res.data.data.list
        })
        .catch(function(err) {
          console.log(err)
        });
    },
    // 新增
    handleAdd() {
      this.dialogAdd = true;
    },
    // 新增提交
    addSubmit() {
      // this.addList.ip = this.addList.ip.split(',')
      this.signmeets = this.addList;
      // console.log(this.signmeets);
      this.$http
        .post("/api/signmeets/save", this.signmeets)
        .then(res => {
          // console.log(res);
          // if (res.data.code == 0) {
          //   this.$message({
          //     message: "新增成功",
          //     type: "success"
          //   });
          // }
          this.loadTable();
        })
        .catch(function(err) {
          console.log(err);
        });
      this.dialogAdd = false;
    },
    // 点击修改查看详情
    handleSee() {
      if (this.selectionRow == {} || this.selectionRow == null) {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      } else {
        this.dialogUpdate = true;
        this.$http
          .post("/api/signmeets/"+this.id)
          .then(res => {
            // console.log(res.data)
            this.updateList = res.data
          })
          .catch(err => {
            console.log(err);
          });
      }
    },
    // 修改提交
    handleUpdate() {
      this.signmeets = this.updateList
      // console.log(this.signmeets)
      this.$http.post("/api/signmeets/update", this.signmeets).then(res => {
        // console.log(res)
        this.loadTable()
        this.dialogUpdate = false
      })
      .catch(err=>{
        console.log(err)
      })
    },
    // 删除
    handleDelete() {
      if (this.selectionRow == {} || this.selectionRow == null) {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }else{
        this.$http.post('/api/signmeets/delete',this.ids).then(res=>{
          // console.log(res.data)
          this.$message({
            message: res.data.data,
            type: "success"
          })
        this.loadTable()
        })
        .catch(err=>{
          console.log(err)
        })
      }
    },
    // 导出
    handleExport() {
      if (this.selectionRow == {} || this.selectionRow == null) {
        this.$message({
          message: "请选择一条数据！",
          type: "error"
        });
        return;
      }else{
        location.href = '/api/sign/export?projectId='+this.id
      }
    },
    // 下载
    handleDownload() {},
    // 是否启用
    handleSwitch(e) {
      console.log(e);
    }
  }
};
</script>

<style scoped>
.ele-btn >>> .el-button {
  font-weight: 300;
}
</style>
