<template>
  <!-- 签到项目 -->
  <main class="main" :style="app">
    <!-- 准备签到 -->
    <section class="meeting">
      <section style="display:block">
        <h2><!-- 浙江工业大学-->
          <span style="color: #409EFF">{{ hymc }}</span> <!--正在召开--></h2>
      </section>
      <section class="tip" style="display:block;text-align:center;font-size:20px">
        <p>假如您未携带身份证，请在下方输入身份证号码完成签到</p>
        <el-row style="margin-top: 100px;" type="flex" justify="center">
          <el-col :span="6">
            <el-input v-model="input" placeholder="请输入身份证号" @keyup.enter.native="handleSign"
              class="cardInput"></el-input>
          </el-col>
          <el-col :span="1">
            <el-button type="primary" icon="el-icon-arrow-right" circle @click.native="handleSign">
            </el-button>
          </el-col>
        </el-row>
      </section>
    </section>
    <!-- 签到成功 -->
    <section class="welcome" style="display:none">
      <h2>{{ hygl }}</h2>
    </section>
  </main>
</template>

<script>
  import axios from 'axios'
  import findIP from '../../../common/findip'
  export default {
    data() {
      return {
        app: {
          backgroundImage: "url(" + require("../../../assets/img/2.jpeg") + ")",
          backgroundRepeat: "no-repeat",
          backgroundSize: "100% 100%"
        },
        input: '',
        websock: null,
        projectId: '',
        hymc: '2019年浙江工业大学学位评定委员会第二次会议签到',
        name: '',
        sfzx: false,
        hyid: '',
        hygl: '',
        xm: '',
        xb: '',
        ip: null,
        card: null,
        timer: null,
        address: null
      }
    },
    // beforeCreate() {
    //   findIP((ip) => {
    //     this.ip = ip
    //     this.Meet();
    //   })
    // },
    mounted() {

    },
    created() {
      console.log(this.$route.query.id, this.$route.query.name)
      this.projectId = this.$route.query.id
      //this.hymc = this.$route.query.name
      if (this.websock == null) {
        this.initWebsock()
      }
    },
    methods: {
      handleSign() {
        console.log(this.card)
        if (this.input == null || this.input == '') {
          this.$notify({
            title: '签到失败',
            message: '请输入身份证号码！',
            duration: 3000
          })
        }
        if (this.card != null || this.card != "") {
          this.$http.post('/api/sign', {
              idCard: this.input,
              projectId: this.projectId
            })
            .then(res => {
              console.log(res.data)
              this.name = res.data.data
              this.sfzx = false
              var meeting = document.getElementsByClassName('meeting')[0]
              var welcome = document.getElementsByClassName('welcome')[0]
              var tip = document.getElementsByClassName('tip')[0]
              meeting.style.display = "none"
              welcome.style.display = "block"
              setTimeout(() => {
                meeting.style.display = "block"
                this.input = ''
                welcome.style.display = "none"
              }, 3000);
              if (res.data.code == 400) {
                this.hygl = res.data.message
                this.$notify({
                  title: '签到失败',
                  message: res.data.message,
                  duration: 3000
                })
              } else {
                // var iden = card.substring(17, 18)
                // this.hygl = "欢迎" + this.name + "老师入场！"
                this.hygl =  "您已签到成功！"
              }
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      initWebsock() {
        // 线上地址:127.0.0.1
        const wsuri = 'ws://127.0.0.1:8080/IdCardClient/ws/TERMINAL'
        this.websock = new WebSocket(wsuri)
        this.websock.onopen = this.websocketopen
        this.websock.onmessage = this.websocketonmessage
        this.websock.onclose = this.websocketclose
        this.websock.onerror = this.websocketerror
      },
      websocketopen() {
        // 打开
        console.log('WebSocket连接成功')
      },
      websocketonmessage(e) {
        // 数据接收
        console.log(e.data)
        var obj = JSON.parse(e.data)
        console.log(obj)
        this.card = obj[1];
        // var name = JSON.stringify(obj[3])
        // var index = name.indexOf("\\")
        // this.xm = name.substring(1, index)
        if (this.card != null || this.card != "") {
          //this.name = res.data.data
          this.sfzx = true;
          console.log(this.card)
          console.log(this.hyid)
          this.$http.post('/api/sign', {
              idCard: this.card,
              projectId: this.projectId
            })
            .then(res => {
              this.sfzx = false
              var meeting = document.getElementsByClassName('meeting')[0]
              var welcome = document.getElementsByClassName('welcome')[0]
              var tip = document.getElementsByClassName('tip')[0]
              meeting.style.display = "none"
              // tip.style.display = "none"
              welcome.style.display = "block"
              setTimeout(() => {
                meeting.style.display = "block"
                // tip.style.display = "block"
                welcome.style.display = "none"
              }, 3000);
              if (res.data.code == 400) {
                this.hygl = res.data.message
                this.$notify({
                  title: '签到失败',
                  message: res.data.message,
                  duration: 3000
                })
              } else {
                // var iden = card.substring(17, 18)
                // this.hygl = "欢迎" + this.name + "老师入场！"
                this.hygl = "您已签到成功！";
              }
            })
            .catch(err => {
              console.log(err)
            })
        }
      },
      websocketclose() {
        // 关闭
        console.log('WebSocket关闭');
      },
      websocketerror() {
        // 失败
        console.log('WebSocket连接失败');
        alert("签到系统连接失败，请联系管理员!")
      }
    }
  }

</script>

<style scoped>
  html,
  body,
  h2 {
    margin: 0;
    padding: 0;
  }

  .main {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
  }

  .meeting,
  .welcome {
    font: 40px '微软雅黑';
    color: #fff;
    /* border-top: 5px solid #fff; */
    /* border-bottom: 5px solid #fff; */
    display: block;
    width: 100%;
    text-align: center;
    /* letter-spacing: 20px; */
    padding: 30px;
  }

  .meeting {}

  .welcome {}

  .tip {
    /* position: absolute; */
    /* top: 65%; */
    color: #fff;
  }

  .tip>>>.el-input__inner {
    width: 100%;
    border-radius: 20px;
    border: none;
    background-color: rgba(255, 255, 255, .3);
    color: #fff;
  }

  .tip>>>.el-input {
    /* margin-top: 100px; */
    /* margin-bottom: 15px; */
  }

  .cardInput {
    /* width: 110%; */
  }
  .tip >>> input::-webkit-input-placeholder {
    /* WebKit browsers */
    /* color: #fff; */
  }

  .tip >>> input:-moz-placeholder {
    /* Mozilla Firefox 4 to 18 */
    /* color: #fff; */
  }

  .tip >>> input::-moz-placeholder {
    /* Mozilla Firefox 19+ */
    /* color: #fff; */
  }

  .tip >>> input:-ms-input-placeholder {
    /* Internet Explorer 10+ */
    /* color: #fff; */
  }

</style>
<style>
  /* .tip input::-webkit-input-placeholder {
    color: #fff !important;
  } */
</style>
