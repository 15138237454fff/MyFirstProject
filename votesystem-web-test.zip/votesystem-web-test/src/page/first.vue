<!-- 首页 -->
<template>
  <div class="first">
    <div class="mycontainer" v-if="$store.state.backlog == false">
      <div class="container-top">
        <div class="information">
          <p class=title>
            <img src="../assets/img/1.png" alt="" style="position: relative; top: 3px;">
            <span>待办事项</span>
            <el-button type="text" class="fr" @click="viewMore">查看更多</el-button>
          </p>
          <div class="container">
            <ul>
              <li>
                我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩
                <span>2019-04-08</span>
              </li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
            </ul>
          </div>
        </div>
        <div class="people">
          <p class=title>
            <img src="../assets/img/22.png" alt="" style="position: relative; top: 4px;">
            <span>通知公告</span>
            <el-button type="text" class="fr">查看更多</el-button>
          </p>
          <div class="container">
            <ul>
              <li>
                我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩
                <span>2019-04-08</span>
              </li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
              <li>我校学生在首届全国高校绿色建筑设计技能大赛上获佳绩</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="container-bottom">
        <div class="draw">
          <p class=title>
            <img src="../assets/img/3.png" alt="" style="position: relative; top: 4px;">
            <span>进行中的项目</span>
          </p>
          <div class="container">
            <ul>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
          </div>
        </div>
        <div style="clear:both;"></div>
      </div>
    </div>
    <backlog v-if="$store.state.backlog == true"></backlog>  
  </div>
</template>

<script>
import backlog from './firstPage/backlog'
export default {
  name: "first",
  data() {
    return {}
  },
  methods: {
    viewMore () {
      this.$store.state.backlog = true
    }
  },
  mounted() {

  },
  components: {
    backlog
  }
}
</script>

<style scoped lang="scss">
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  list-style: none;
}
.fr {
  float: right;
  position: relative;
  top: 18px;
}
.first {
  padding: 15px 0;
  height: calc(100% - 40px);
  .mycontainer {
    height: 100%;
    .container-top,
    .container-bottom {
      width: 100%;
      height: 49.5%;
    }
    .container-top {
      margin-bottom: 1%;
      .information {
        position: relative;
        // padding: 12px;
        width: 64%;
        float: left;
        margin-right: 15px;
        height: 100%;
        box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.1);
        .container {
          position: absolute;
          top: 52px;
          bottom: 12px;
          left: 12px;
          right: 12px;
          ul {
            height: 100%;
            width: 100%;
            padding-top: 15px;
            li {
              width: 100%;
              list-style: none;
              height: 14.3%;
              font-size: 14px;
              color: #666;
              padding: 0 15px 0 15px;
              span {
                float: right;
                font-size: 14px;
                color: #666;
              }
            }
          }
        }
        .title {
          height: 50px;
          border-bottom: 1px solid #eeeeee;
          background: #D3E4FA;
          padding: 0 20px;
          span {
            display: inline-block;
            height: 50px;
            line-height: 50px;
            font-size: 18px;
            color: #237ae4;
          }
        }
      }
      .people {
        position: relative;
        width: calc(36% - 15px);
        float: left;
        height: 100%;
        box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.1);
        .container {
          position: absolute;
          top: 52px;
          bottom: 12px;
          left: 12px;
          right: 12px;
          ul {
            height: 100%;
            width: 100%;
            padding-top: 15px;
            li {
              width: 100%;
              list-style: none;
              height: 14.3%;
              font-size: 14px;
              color: #666;
              padding: 0 15px 0 15px;
              span {
                float: right;
                font-size: 14px;
                color: #666;
              }
            }
          }
        }
        .title {
          height: 50px;
          border-bottom: 1px solid #eeeeee;
          background: #D3E4FA;
          padding: 0 20px;
          span {
            display: inline-block;
            height: 50px;
            line-height: 50px;
            font-size: 18px;
            color: #237ae4;
          }
        }
      }
    }
    .container-bottom {
      .draw {
        position: relative;
        height: 100%;
        box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.1);
        width: 100%;
        .container {
          position: absolute;
          top: 50px;
          bottom: 0px;
          left: 0;
          right: 0;
          overflow-x: auto;
          ul {
            height: 100%;
            overflow-x: auto;
            white-space: nowrap;
            li {
              height: 98%;
              width: 250px;
              // float: left;
              border-right: 1px solid #eee;
              display: inline-block;
            }
          }
        }
        .title {
          height: 50px;
          border-bottom: 1px solid #eeeeee;
          background: #D3E4FA;
          padding: 0 20px;
          span {
            display: inline-block;
            height: 50px;
            line-height: 50px;
            font-size: 18px;
            color: #237ae4;
          }
        }
      }
    }
  }
}
</style>
