// 主体页面
<template>
	<!-- 主体 -->
	<div class="main">
		<!-- 头部 -->
		<headNav></headNav>
		<!-- 侧边栏导航 -->
  	<div class="nav">
   		<navTag></navTag>
		</div>
		<!-- 主体切换显示内容 -->
		<div class="mainContainer">
			<tags></tags>
			<router-view v-if="isRouterAlive"></router-view>
		</div>
	</div>
</template>

<script>
import Vue from "vue"
import navTag from '@/components/navTag'
import headNav from '@/components/headNav'
import tags from '@/components/tags'
export default {
  name: 'index',
  provide () {
    return {
      reload: this.reload
    }
  },
  data () {
    return {
		isRouterAlive: true
    }
  },
  methods: {
    reload () {
      this.isRouterAlive = false
      this.$nextTick(function(){
        this.isRouterAlive = true
      })
    }
  },
  components: {
		navTag,
		headNav,
		tags
  }
}
</script>

<style scoped>
	* {
		box-sizing: border-box;
	}
	.main {
		height: 100%;
		position: relative;
	}
	.nav {
		width: 230px;
		height: 100%;
		box-sizing: border-box;
		overflow-y:hidden;
		float: left;
	}
	.mainContainer {
		position: absolute;
		top: 80px;
		left: 230px;
		bottom: 0;
		right: 0;
		padding: 0 15px 15px 15px;
		overflow: auto;
	}
</style>
