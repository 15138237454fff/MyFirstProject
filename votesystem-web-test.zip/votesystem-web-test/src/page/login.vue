<template>
  <div class="container">
    <!-- 页面头部标题 -->
    <div class="title-left">
      <img src="../assets/img/title.png" alt="">
    </div>
    <div class="title-middle">
      <p>浙江工业大学投票管理系统</p>
    </div>
    <div class="login-Box">
      <el-form :model="loginForm" :rules="rules" ref="loginForm">
        <el-form-item lable="用户名" prop="username">
          <el-input v-model="loginForm.username" placeholder="教职工号" type="text" prefix-icon="el-icon-login-user">
            <!-- <i slot="prefix" class="el-input__icon el-icon-date"></i> -->
          </el-input>
        </el-form-item>
        <el-form-item lable="密码" prop="password" style="margin-top:10%">
          <el-input type="password" placeholder="密码（身份证后六位）" v-model="loginForm.password"
            @keyup.enter.native="main" prefix-icon="el-icon-login-password"></el-input>
        </el-form-item>
        <el-form-item lable="yan" prop="changeCode" style="margin-top:10%">
          <el-row>
            <el-col :span="14">
              <el-input v-model="loginForm.changeCode" placeholder="验证码" type="text"
                @keyup.enter.native="login"></el-input>
            </el-col>
            <el-col :span="9" :offset="1" style="border:1px solid #f4f4f4;height:40px">
              <img :src="imgurl" @click="changeImg" style="width:100%;height:100%" />
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <el-button class="login-Button" @click="login">登录</el-button>
    </div>
    <!-- 页面底部 -->
    <p class="footer">杭州毕为科技有限公司&nbsp;&nbsp;技术支持</p>
  </div>
</template>

<script>
  export default {
    name: 'login',
    data() {
      return {
        loginForm: {},
        imgurl: '/api/changeCode',
        rules: {
          username: [{
            required: true,
            message: "请输入用户名",
            trigger: "blur"
          }],
          password: [{
            required: true,
            message: "请输入密码",
            trigger: "blur"
          }],
          changeCode: [{
            required: true,
            message: "请输入验证码",
            trigger: "blur"
          }]
        },
      }
    },
    mounted(){
      this.changeImg()
      // if(this.$route.query.redirect){
      //   this.$router.push({path: decodeURIComponent(this.$route.query.redirect)})
      // }else{
      //   this.$router.push({name: 'login', query: {}})
      // }
      if(this.$route.query.id == '11') {
        this.$message.error('登陆超时了，请重新登陆')
      }
    },
    methods: {
      login() {
        // this.$router.push({
        //   path: '/first'
        // })
        this.$refs.loginForm.validate(valid => {
          // let params = "changeCode=" +
          //   this.loginForm.changeCode +
          //   "&password=" +
          //   this.loginForm.password +
          //   "&username=" +
          //   this.loginForm.username
          if (valid) {
            this.username = this.loginForm.username
            this.password = this.loginForm.password
            this.changeCode = this.loginForm.changeCode
            this.$http.post('/api/user/checkLogin/'+this.username+'/'+this.password+'/'+this.changeCode).then(res => {
                if (res.data.code == 200) {
                  this.$store.commit('SET_TOKEN', this.loginForm.username)
                  this.$store.commit('GET_USER', this.loginForm)
                  // console.log(this.$store)
                  this.$router.push({
                    path: '/first'
                  })
                  this.$message({
                    message: '登录成功',
                    type: 'success'
                  })
                } else {
                  this.$message({
                    message: res.data.message,
                    type: 'error'
                  })
                }
              })
              .catch(err => {
                console.log(err)
              })
          } else {
            console.log("error submit!!")
            return false
          }
        })
      },
      changeImg() {
        // this.imgurl = this.$server.glourl + "captcha.jpg?" + Math.random()
        this.imgurl = '/api/changeCode?' + Math.random()
      },
    }
  }

</script>

<style scoped>
  * {
    box-sizing: border-box;
  }
/* 添加用户名密码小图标 */
.login-Box>>>.el-icon-login-user{
    background: url(../assets/img/user.png) center no-repeat;
    background-size: contain;
}
.login-Box>>>.el-icon-login-user:before{
    content: "\66ff";
    font-size: 16px;
    visibility: hidden;
}
.login-Box>>>.el-icon-login-password{
    background: url(../assets/img/password.png) center no-repeat;
    background-size: contain;
}
.login-Box>>>.el-icon-login-password:before{
    content: "替";
    font-size: 16px;
    visibility: hidden;
}
.login-Box>>>.el-input__prefix{
  left:10px;
}
.login-Box>>>.el-input--prefix .el-input__inner{
  padding-left: 40px;
}
  .container {
    width: 100%;
    height: 100%;
    background: url('../assets/img/back.jpg') 100% 100%;
    padding-top: 20px;
    position: relative;
    min-height: 700px;
    min-width: 1300px;
    overflow: auto;
  }

  .container>p {
    margin: 0;
    padding: 0;
    height: 16%;
    text-align: center;
  }

  div.login-Box {
    width: 405px;
    height: 340px;
    background: rgba(255, 255, 255, 0.4);
    position: absolute;
    top: 50%;
    left: 50%;
    margin-left: -202.5px;
    margin-top: -170px;
    box-sizing: border-box;
    padding: 30px;
  }

  .login-Box >>> .el-input__inner {
    height: 45px;
    border-radius: 30px;
  }
  div.login-Box>div {
    width: 100%;
    height: 50px;
    margin-bottom: 50px;
    background-color: #fff !important;
    padding: 5px 60px;
    border-radius: 50px;
  }

  div.login-Box>div input {
    height: 100%;
    width: 100%;
    border: 1px solid #fff;
    outline: none;
    font-size: 15px;
  }

  input::-webkit-input-placeholder {
    color: #aab2bd;
    font-size: 12px;
  }

  div.login-Box>div:first-child {
    background: url('../assets/img/user.png') no-repeat 20px 8px;
  }

  div.login-Box>div:nth-child(2) {
    background: url('../assets/img/password.png') no-repeat 20px 8px;
  }

  button.login-Button {
    width: 100%;
    height: 50px;
    border: none;
    background: #237AE4;
    border-radius: 30px;
    color: #fff;
    font-size: 16px;
    letter-spacing: 10px;
    margin-top: 18px;
  }

  p.footer {
    width: 100%;
    font-size: 14px;
    color: #fff;
    position: absolute;
    bottom: 15px;
    text-align: center;
  }
  .title-left {
    float: left;
    margin-left: 5%;
    margin-top: 2%;
  }
  .title-middle {
    float: left;
    font-size: 40px;
    color: #fff;
    position: absolute;
    left: 50%;
    margin-left: -240px;
    margin-top: 2%;
  }
  .title-middle p {
    margin-top: 15px;
  }
::-webkit-scrollbar {
  width: 0px;
  height: 0px;
}
::-webkit-scrollbar-thumb {
  background-color: transparent;
  /* border-radius: 3px; */
}
  @media screen and (max-width: 1400px) {
    .title-left img {
      width: 70%;
      height: 70%;
    }
  }
</style>
