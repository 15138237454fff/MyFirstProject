import Vue from 'vue'
import Router from 'vue-router'
import store from '../store/store'

import Login from '@/page/login'
import Main from '@/page/index'
import institutional from '@/page/childPage/authorizationManagement/institutional'
import specialistManage from '@/page/childPage/authorizationManagement/specialistManage'
import notification from '@/page/childPage/authorizationManagement/notification'
import roleManagement from '@/page/childPage/authorizationManagement/roleManagement'
import userManagement from '@/page/childPage/authorizationManagement/userManagement'
import informationBase from '@/page/childPage/authorizationManagement/informationBase'
import menuManagement from '@/page/childPage/authorizationManagement/menuManagement'
import statistical from '@/page/childPage/statisticalQuery/statistical'
import voteImport from '@/page/childPage/voteManagement/voteImport'
import ImportVote1 from '@/page/childPage/voteManagement/voteImport/vote1'
import ImportVote2 from '@/page/childPage/voteManagement/voteImport/vote2'
import ImportVote3 from '@/page/childPage/voteManagement/voteImport/vote3'
import ImportVote4 from '@/page/childPage/voteManagement/voteImport/vote4'
import ImportVote5 from '@/page/childPage/voteManagement/voteImport/vote5'
import ImportVote6 from '@/page/childPage/voteManagement/voteImport/vote6'
import AuditVote1 from '@/page/childPage/voteManagement/voteAudit/vote1'
import AuditVote2 from '@/page/childPage/voteManagement/voteAudit/vote2'
import AuditVote3 from '@/page/childPage/voteManagement/voteAudit/vote3'
import AuditVote4 from '@/page/childPage/voteManagement/voteAudit/vote4'
import AuditVote5 from '@/page/childPage/voteManagement/voteAudit/vote5'
import AuditVote6 from '@/page/childPage/voteManagement/voteAudit/vote6'
import CheckVote1 from '@/page/childPage/voteManagement/voteCheck/vote1'
import CheckVote2 from '@/page/childPage/voteManagement/voteCheck/vote2'
import CheckVote3 from '@/page/childPage/voteManagement/voteCheck/vote3'
import CheckVote4 from '@/page/childPage/voteManagement/voteCheck/vote4'
import CheckVote5 from '@/page/childPage/voteManagement/voteCheck/vote5'
import CheckVote6 from '@/page/childPage/voteManagement/voteCheck/vote6'
import voteAudit from '@/page/childPage/voteManagement/voteAudit'
import voteCheck from '@/page/childPage/voteManagement/voteCheck'
import voteTemplate from '@/page/childPage/voteItem/voteTemplate'
import voteManagement from '@/page/childPage/voteItem/voteManagement'
import itemSearch from '@/page/childPage/statisticalAnalysis/itemSearch'
import resultSearch from '@/page/childPage/statisticalAnalysis/resultSearch'
import resultVote from '@/page/childPage/voteItem/resultVote'
import voteNumber from '@/page/childPage/voteItem/voteNumber'
import managementVote from '@/page/childPage/voteItem/managementVote'
import systemSign from '@/page/childPage/voteItem/managementVote/systemSign'
import relevanceVote from '@/page/childPage/voteItem/managementVote/relevanceVote'
import hello from '@/components/HelloWorld' 

// import statisticsSign from '@/page/childPage/voteItem/managementVote/statisticsSign'
import first from '@/page/first'
// 签到项目
import attendManage from '../page/childPage/attendManagement/attendManage'
import statisticsSign from '../page/childPage/attendManagement/statisticsSign'
// 签到页面
import sign from '../page/childPage/attendManagement/sign'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/hello',
      name: 'hello',
      component: hello
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/sign',
      name: 'sign',
      component: sign,
      meta: {
        title: '签到',
        requireAuth: true
      }
    },
    {
      path: '/',
      name: 'main',
      component: Main,
      meta: {
        title: '首页',
        requireAuth: true
      },
      children: [
        {
          path: '/first',
          component: first,
          meta: {
            title: '首页',
            requireAuth: true
          }
        },
        {
          path: '/institutional',
          component: institutional,
          meta: {
            title: '组织机构',
            requireAuth: true
          }
        },
        {
          path: '/specialistManage',
          component: specialistManage,
          meta: {
            title: '专家组管理',
            requireAuth: true
          }
        },
        {
          path: '/notification',
          component: notification,
          meta: {
            title: '通知公告',
            requireAuth: true
          }
        },
        {
          path: '/roleManagement',
          component: roleManagement,
          meta: {
            title: '角色管理',
            requireAuth: true
          }
        },
        {
          path: '/userManagement',
          component: userManagement,
          meta: {
            title: '用户管理',
            requireAuth: true
          },
        },
        {
          path: '/informationBase',
          component: informationBase,
          meta: {
            title: '专家信息库',
            requireAuth: true
          },
        },
        {
          path: '/menuManagement',
          component: menuManagement,
          meta: {
            title: '模块管理',
            requireAuth: true
          },
        },
        {
          path: '/statistical',
          component: statistical,
          meta: {
            title: '统计查询',
            requireAuth: true
          },
        },
        {
          path: '/voteImport',
          component: voteImport,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteImport/vote1',
          component: ImportVote1,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteImport/vote2',
          component: ImportVote2,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteImport/vote3',
          component: ImportVote3,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteImport/vote4',
          component: ImportVote4,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteImport/vote5',
          component: ImportVote5,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteImport/vote6',
          component: ImportVote6,
          meta: {
            title: '投票数据导入',
            requireAuth: true
          }
        },
        {
          path: '/voteAudit',
          component: voteAudit,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          },
        },
        {
          path: '/voteAudit/vote1',
          component: AuditVote1,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          }
        },
        {
          path: '/voteAudit/vote2',
          component: AuditVote2,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          }
        },
        {
          path: '/voteAudit/vote3',
          component: AuditVote3,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          }
        },
        {
          path: '/voteAudit/vote4',
          component: AuditVote4,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          }
        },
        {
          path: '/voteAudit/vote5',
          component: AuditVote5,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          }
        },
        {
          path: '/voteAudit/vote6',
          component: AuditVote6,
          meta: {
            title: '投票数据审核',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck',
          component: voteCheck,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck/vote1',
          component: CheckVote1,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck/vote2',
          component: CheckVote2,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck/vote3',
          component: CheckVote3,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck/vote4',
          component: CheckVote4,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck/vote5',
          component: CheckVote5,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteCheck/vote6',
          component: CheckVote6,
          meta: {
            title: '投票数据汇总',
            requireAuth: true
          }
        },
        {
          path: '/voteTemplate',
          component: voteTemplate,
          meta: {
            title: '模板管理',
            requireAuth: true
          },
        },
        {
          path: '/voteManagement',
          component: voteManagement,
          meta: {
            title: '投票项目管理',
            requireAuth: true
          }
        },
        {
          path: '/itemSearch',
          component: itemSearch,
          meta: {
            title: '投票项目查询',
            requireAuth: true
          },
        },
        {
          path: '/resultSearch',
          component: resultSearch,
          meta: {
            title: '投票结果查询',
            requireAuth: true
          }
        },
        {
          path: '/managementVote',
          component: managementVote,
          meta: {
            title: '投票签到管理',
            requireAuth: true
          },
        },
        {
          path: '/resultVote',
          component: resultVote,
          meta: {
            title: '投票进度管理',
            requireAuth: true
          }
        },
        {
          path: '/voteNumber',
          component: voteNumber,
          meta: {
            title: '参数设置',
            requireAuth: true
          }
        },
        {
          path: '/systemSign',
          component: systemSign,
          meta: {
            title: '签到系统管理',
            requireAuth: true
          }
        },
        {
          path: '/relevanceVote',
          component: relevanceVote,
          meta: {
            title: '关联投票项目',
            requireAuth: true
          },
        },
        {
          path: '/statisticsSign',
          component: statisticsSign,
          meta: {
            title: '签到数据统计',
            requireAuth: true
          }
        },
        {
          path: '/attendManage',
          component: attendManage,
          meta: {
            title: '签到项目管理',
            requireAuth: true
          }
        }
      ]
    },
  ]
})

// 注册全局钩子用来拦截导航
router.beforeEach((to, from, next) => {
  const token = store.state.token
  if (to.meta.requireAuth) { // 判断该路由是否需要登录权限
    if (token) { // 通过vuex state获取当前的token是否存在
      next()
    } else {
      // this.$message({
      //   message: '该页面需要登陆',
      //   type: 'error'
      // })
      console.log('该页面需要登陆')
      next({
        path: '/login'
        // query: {redirect: to.fullPath} // 将跳转的路由path作为参数，登录成功后跳转到该路由
      })
    }
  } else {
    next()
  }
})

export default router

