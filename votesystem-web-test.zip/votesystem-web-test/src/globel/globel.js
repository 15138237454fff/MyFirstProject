var dict = {
  voteRules: [{ label: '同意制', value: 0 }, { label: '打分制', value: 1 }, { label: '排名制', value: 2 }],
  voteForm: [
    { label: '现场实名', value: 0 },
    { label: '现场匿名', value: 1 },
    { label: '网上实名', value: 2 },
    { label: '网上匿名', value: 3 }
  ],
  projectStatus: [
    { label: '待发布', value: 0 },
    { label: '已发布', value: 1 },
    { label: '启动', value: 2 },
    { label: '关闭', value: 3 },
    { label: '结束', value: 4 }
  ],
  result: [{ label: '不通过', value: 0 }, { label: '通过', value: 1 }],
  isTrue: [{ label: '否', value: 0 }, { label: '是', value: 1 }],
  passRules: [{ label: '专家组', value: 1 }, { label: '签到人数', value: 2 }],
  userStatus: [
    { label: '正常', value: 1 },
    { label: '锁定', value: 2 },
    { label: '临时', value: 3 },
    { label: '失效', value: 4 }
  ],
  menuType: [{ label: '一级菜单', value: 1 }, { label: '二级菜单', value: 2 }, { label: '按钮', value: 3 }],
  domainList: [{ label: '前台', value: '2' }, { label: '后台', value: '1' }],
  menuStatus: [{ label: '无效', value: 0 }, { label: '有效', value: 1 }]
};
export default {
  dict
};
