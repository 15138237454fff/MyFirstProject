exports.install = function(Vue, options) {
  //获取数据字典值
  Vue.prototype.getDictValue = function(value, key) {
    var list=this.GLOBEL.dict[key];
    for (let index = 0; index < list.length; index++) {
      const element = list[index];
      if(element.value==value){
       
        return element.label;
      }
    }
    return '未知';
  };
  //消息提示
  Vue.prototype.infoNotice = function(message) {
    this.$notify({
      title: '消息',
      message: message
    });
  };
  Vue.prototype.xscgMessage = function(message) {
    this.$notify({
      title: '填写提示',
      message: this.$createElement('i', { style: 'color: red' }, message),
      duration: 0,
      offset: 200
    });
  };
  Vue.prototype.isEmpty = function(obj) {
    //判断字符串是否为空
    if (typeof obj == 'boolean') {
      return true;
    }
    if (typeof obj == 'undefined' || obj == null || obj == '' || obj.length == 0) {
      return false;
    } else {
      return true;
    }
  };
  //获取当前时间，格式YYYY-MM-DD
  Vue.prototype.getCurrentDate = function getNowFormatDate() {
    var date = new Date();
    var seperator1 = '-';
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
      month = '0' + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = '0' + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    return currentdate;
  };
};
