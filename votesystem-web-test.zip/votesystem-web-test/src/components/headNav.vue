// 头部
<template>
  <div class="head-Nav">
    浙江工业大学投票管理系统
    <div class="infor-Box">
      <el-dropdown>
        <span class="user"></span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>
            <el-button @click="centerClick">个人中心</el-button>
          </el-dropdown-item>
          <el-dropdown-item>
            <el-button @click="wordClick">修改密码</el-button>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <span class="exit" @click="exitLogin"></span>
    </div>
    <el-dialog title="个人中心" :visible.sync="dialogVisible" width="600px">
      <el-form ref="form" :model="form" label-width="80px">
        <el-row>
          <el-col :span="10">
            <el-form-item label="用户名">
              <el-input :disabled="true" v-model="form.userName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="姓名">
              <el-input :disabled="true" v-model="form.name"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="所属角色">
              <el-input :disabled="true" v-model="form.roleName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="10" :offset="2">
            <el-form-item label="所属机构">
              <el-input :disabled="true" v-model="form.daptName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="10">
            <el-form-item label="手机号码">
              <el-input :disabled="true" v-model="form.phoneNum"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="修改密码" :visible.sync="wordVisible" width="500px">
      <el-form :model="wordform" :rules="rules" ref="wordform" label-width="150px">
        <el-row>
          <el-col :span="22">
            <el-form-item label="原密码" prop="password" v-show="oldShow">
              <el-input type="password" v-model="wordform.password">
                <i slot="suffix" title="显示密码" @click="changePass1('show')" style="cursor:pointer;"
                  class="el-input__icon el-icon-hide"></i>
              </el-input>
            </el-form-item>
            <el-form-item label="原密码" prop="password" v-show="!oldShow">
              <el-input type="text" v-model="wordform.password">
                <i slot="suffix" title="隐藏密码" @click="changePass1('hide')" style="cursor:pointer;"
                  class="el-input__icon el-icon-view"></i>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="新密码" prop="newPassword" v-show="newShow">
              <el-input type="password" v-model="wordform.newPassword" @focus="condition = true"
                @blur="condition = false">
                <i slot="suffix" title="显示密码" @click="changePass2('show')" style="cursor:pointer;"
                  class="el-input__icon el-icon-hide"></i>
              </el-input>
            </el-form-item>
            <el-form-item label="新密码" prop="newPassword" v-show="!newShow">
              <el-input type="text" v-model="wordform.newPassword">
                <i slot="suffix" title="隐藏密码" @click="changePass2('hide')" style="cursor:pointer;"
                  class="el-input__icon el-icon-view"></i>
              </el-input>
            </el-form-item>
            <!-- <div style="margin-left:150px;margin-bottom:10px;color:#F56C6C;font-size:12px"
              v-show="condition">
              <span>8-16位,数字/字母/特殊字符中任意两种</span>
            </div> -->
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="22">
            <el-form-item label="再次输入新密码" prop="confirmPassword" v-show="confirmShow">
              <el-input type="password" v-model="wordform.confirmPassword">
                <i slot="suffix" title="显示密码" @click="changePass3('show')" style="cursor:pointer;"
                  class="el-input__icon el-icon-hide"></i>
              </el-input>
            </el-form-item>
            <el-form-item label="再次输入新密码" prop="confirmPassword" v-show="!confirmShow">
              <el-input type="text" v-model="wordform.confirmPassword">
                <i slot="suffix" title="显示密码" @click="changePass3('hide')" style="cursor:pointer;"
                  class="el-input__icon el-icon-view"></i>
              </el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="changePassword">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: 'headNav',
    data() {
      var reg1 = /^(?!\D+$)/ //数字
      var reg2 = /^(?![^a-zA-Z]+$)/ //字母
      // var reg3 = /[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/ //特殊字符
      var reg3 = /[^a-zA-Z0-9]+/ //特殊字符
      var reg4 = /(?!^(\d+|[a-zA-Z]+|[~!@#$%^&*_?]+)$)^[\w~!@#$%^&*_?]{8,32}$/
      var validatePass = (rule, value, callback) => {
        // console.log(value)
        if (value == '' || value == undefined) {
          callback(new Error('请输入新密码'))
        } else {
          if (!reg4.test(value)) {
            callback(new Error('8-16位,数字/字母/特殊字符中任意两种'))
          }
          callback()
        }
      }
      var validatePass2 = (rule, value, callback) => {
        if (value == '' || value == undefined) {
          callback(new Error('请再次输入新密码'))
        } else if (value !== this.wordform.newPassword) {
          callback(new Error('两次输入密码不一致!'))
        } else {
          callback()
        }
      }
      var validatePass3 = (rule, value, callback) => {
        if (value == '' || value == undefined) {
          callback(new Error('请输入原密码'))
        } else {
          callback()
        }
      }
      return {
        form: {}, // 个人中心数据
        wordform: {}, // 修改密码数据
        oldPassword: null, //原密码
        dialogVisible: false, // 个人中心弹出框
        wordVisible: false, // 修改密码弹出框
        oldShow: true, //原密码
        newShow: true, //新密码显示
        confirmShow: true, //确认新密码显示
        condition: false, //密码提示条件
        msg: '',
        rules: {
          password: [{
            required: true,
            // message: "请输入原密码",
            validator: validatePass3,
            trigger: "blur"
          }],
          newPassword: [{
            required: true,
            validator: validatePass,
            trigger: 'blur'
          }],
          confirmPassword: [{
            required: true,
            validator: validatePass2,
            trigger: 'blur'
          }],
        }
      }
    },
    methods: {
      // 个人中心
      centerClick() {
        this.dialogVisible = true
      },
      // 修改密码
      wordClick() {
        this.wordVisible = true
      },
      //判断渲染，true:暗文显示，false:明文显示
      changePass(value, visible) {
        // visible = !(value === 'show')
        visible = !visible
      },
      changePass1(value) {
        this.oldShow = !(value === 'show')
      },
      changePass2(value) {
        this.newShow = !(value === 'show')
      },
      changePass3(value) {
        this.confirmShow = !(value === 'show')
      },
      //修改密码提交
      changePassword() {
        this.$refs.wordform.validate(valid => {
          if (valid) {
            this.$http.put('/api/SysRole/password?newPassword=' + this.wordform.newPassword +
                '&password=' + this.wordform.password)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    message: '密码修改成功！',
                    type: 'success'
                  })
                  this.wordVisible = false
                  this.$router.replace({
                    path: '/login'
                  })
                } else if (res.data.code == 400) {
                  this.$message({
                    message: res.data.message,
                    type: 'error'
                  })
                }
              })
              .catch(err => {
                console.log(err)
              })
          } else {
            console.log('error submit')
            return false
          }
        })
      },
      // 退出
      exitLogin() {
        this.$confirm("是否退出本次登陆?",'退出', {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
        }).then(res => {
          this.$store.commit("LOGOUT")
          this.$router.push("/login")
          this.$message({
            type: "success",
            message: "退出成功!"
          })
        })
      }

    },
    mounted() {
      this.$http
        .get("api/user/search")
        .then(res => {
          this.form = res.data
        })
        .catch(function (err) {
          console.log(err)
        })
    }
  }

</script>

<style scoped>
.head-Nav {
  text-align: center;
  color: #FFF;
  font-size: 36px;
  line-height: 70px;
  width: 100%;
  height: 70px;
  background-color: #237AE4 !important;
  background: url(/static/img/title.a527bfb.png) no-repeat 20px 10px;
  background-size: 265px 50px;
  position: relative;
}

  /* 密码显示与隐藏 */
  .head-Nav>>>.el-icon-hide {
    background: url(../assets/img/hidePassword.png) center no-repeat;
    background-size: auto;
  }

  .head-Nav>>>.el-icon-hide::before {
    /* font-size: 16px; */
  }

  .infor-Box {
    height: 100%;
    position: absolute;
    right: 20px;
    top: 0;
  }

  .infor-Box span {
    display: inline-block;
    height: 50px;
    width: 50px;
    margin: 13px 0 0 0;
  }

  span.infor {
    background: url('../assets/img/myinfor.png') no-repeat 10px 10px;
    background-size: 29px 29px;
    margin: 0 0 0 0;
    position: relative;
    top: -6px;
  }

  span.user {
    background: url('../assets/img/myuser.png') no-repeat 4px 8px;
    background-size: 30px 30px;
  }

  span.exit {
    background: url('../assets/img/exit.png') no-repeat 0 8px;
    background-size: 33px 32px;
  }

  .el-dropdown-menu li {
    padding: 0;
  }

  .el-dropdown-menu button {
    width: 100%;
    border: none;
    outline: none;
  }

  .el-dialog__footer {
    text-align: center !important;
  }
  .el-dropdown-menu {
    top: 45px !important;
  }


</style>

<style>
 
  .el-badge__content.is-fixed {
    top: 5px;
    right: 18px;
  }

  .el-icon-view:before {
    font-size: 20px;
  }

</style>
