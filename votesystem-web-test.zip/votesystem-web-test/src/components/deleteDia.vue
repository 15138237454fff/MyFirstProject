<!-- 删除弹出框 -->
<template>
	<el-dialog
		:title="deleteInfo"
		:visible.sync="deleteDialog"
		width="30%">
		<p class="hr"></p>
		<span>确定删除已选记录</span>
		<span slot="footer" class="dialog-footer">
		<el-button @click="deleteDialog = false">取 消</el-button>
		<el-button type="primary" @click="closeDia">确 定</el-button>
		</span>
	</el-dialog>
</template>

<script>
export default {
  name: 'deleteDia',
  data () {
    return {
      deleteDialog: false, // 控制删除弹出框
      deleteInfo: '' // 删除标题
    }
  },
  methods: {
    closeDia () {
      
    }
    
  }
}
</script>

<style scoped>

.hr{
  width: 100%;
  border: 1px solid #f4f4f4;
  padding: 0;
  margin: 0;
  position: relative;
  top: -30px;
}

</style>
