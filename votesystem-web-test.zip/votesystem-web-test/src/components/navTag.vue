// 侧边栏导航
import { setTimeout } from 'timers';
import { setInterval } from 'timers';
<template>
  <div class="navTag">
		<el-menu
			@open="myOpen"
			@select="mySelect"
      :default-active="myMenu"
      class="el-menu-vertical-demo"
      background-color="#001b2d"
      text-color="#fff"
      active-text-color="#fff"
	  	:unique-opened="isOne">
			<template v-for="item in navList">
				<el-submenu v-if="item.children && item.children.length" :index="item.path" :key="item.path">
					<template slot="title"><i :class="item.icon"></i><span>{{item.name}}</span></template>

					<!-- 二级菜单 -->
					<template v-for="itemChild in item.children">
						<el-submenu v-if="itemChild.children && itemChild.children.length" :index="itemChild.path" :key="itemChild.path">
							<template slot="title"><i :class="itemChild.icon"></i><span>{{itemChild.name}}</span></template>

							<!-- 三级菜单 -->
							<el-menu-item v-for="itemChild_Child in itemChild.children" :index="itemChild_Child.path" :key="itemChild_Child.path">
							<i :class="itemChild_Child.icon"></i><span slot="title">{{itemChild_Child.name}}</span></el-menu-item>
						</el-submenu>

						<el-menu-item v-else :index="itemChild.path" :key="itemChild.path"><i :class="itemChild.icon"></i><span slot="title">{{itemChild.name}}</span></el-menu-item>
					</template>
				</el-submenu>
    		<el-menu-item v-else :index="item.path" :key="item.path"><i :class="item.icon"></i><span slot="title">{{item.name}}</span></el-menu-item>
  		</template>
    </el-menu>
  </div>
</template>

<script>
import Vue from "vue"
export default {
  name: 'navTag',
  data () {
    return {
      // myMenu: '',
			nowIndex: '0-0',
			isOne: true, // 是否保持一个菜单展开
			navList: [
        // {
        //   path: '0',
        //   name: '首页',
        //   path: '/first'
        // },
        // {
        //   // path: '/institutional',
        //   name: '用户权限管理',
        //   children: [
        //     {
        //       name: '组织机构',
        //       path: '/institutional'
				// 		},
				// 		{
        //       name: '角色管理',
        //       path: '/roleManagement'
				// 		},
				// 		{
        //       name: '用户管理',
        //       path: '/userManagement'
				// 		},
				// 		{
        //       name: '专家信息库',
        //       path: '/informationBase'
        //     },
        //     {
        //       name: '菜单管理',
        //       path: '/menuManagement'
        //     }
        //   ]
        // },
        // {
        //   path: '/voteTemplate',
        //   name: '投票项目管理',
        //   children: [
				// 		{
        //       name: '模板管理',
        //       path: '/voteTemplate'
				// 		},
				// 		{
        //       name: '投票项目管理',
        //       path: '/voteManagement'
				// 		},
				// 		// {
				// 		// 	name: '投票签到管理',
				// 		// 	path: '2-3',
        //     //   children: [
        //     //     {
        //     //       name: '签到系统管理',
        //     //       path: '/systemSign'
				// 		// 		},
				// 		// 		{
        //     //       name: '关联投票项目',
        //     //       path: '/relevanceVote'
				// 		// 		},
				// 		// 		{
        //     //       name: '签到数据统计',
        //     //       path: '/statisticsSign'
				// 		// 		}
        //     //   ]
        //     // },
        //     {
        //       name: '投票结果管理',
        //       path: '/resultVote'
				// 		}
        //   ]
        // },
        // {
        //   path: '/voteImport',
        //   name: '投票数据管理',
        //   children: [
        //     {
        //       name: '投票数据导入',
        //       path: '/voteImport'
				// 		},
				// 		{
        //       name: '投票数据审核',
        //       path: '/voteAudit'
				// 		},
				// 		{
        //       name: '投票数据查看',
        //       path: '/voteCheck'
				// 		}
        //   ]
        // },
        // {
        //   path: '/itemSearch',
        //   name: '统计分析',
        //   children: [
        //     {
        //       name: '投票项目查询',
        //       path: '/itemSearch'
				// 		},
				// 		{
        //       name: '投票结果查询',
        //       path: '/resultSearch'
				// 		}
        //   ]
        // },
        // {
        //   path: '/attendManage',
        //   name: '签到管理',
        //   children: [
        //     {
        //       name: '签到项目管理',
        //       path: '/attendManage'
        //     },
        //     {
        //       name: '签到数据统计',
        //       path: '/statisticsSign'
				// 		}
        //   ]
        // }
      ],
      currentMenu: '', // 当前选中的菜单
    }
	},
	methods: {
		mySelect (index) {
      this.nowIndex = index
      let num = this.$route.path.split('/').length
      // if(num == 3) {
      //   this.$router.path = ('/' + this.$route.path.split('/')[1])
      // } else {
      //   this.$router.path = index
      // }
      this.$router.push(index)
      if(num == 3) {
        this.$router.back(-1)
      }
      this.myMenu = this.currentMenu
		},
		myOpen (index) {
			// console.log(index)
    },
    takeList () {
      this.$http
      .get("api/sys/menu/1")
      .then(res => {
        if(res.data.code == 200) {
          this.navList = res.data.data
          // this.myMenu = this.currentMenu
        }
        // console.log(this.myMenu)
      })
      .catch(function(err) {                                                                                                                                                                          
        console.log(err)
      })
    }
  },
  computed: {
    myMenu: {
      get () {
        return this.$route.path.replace("/", "")
      },
      set (val) {

      }
    }
  },
	created() {
    this.myMenu = this.$store.state.myMenu
    this.takeList()
    // Vue.set(myMenu,'myMenu', this.$store.state.myMenu)
    // this.takeList()
    // console.log(this.navList)
    // if(this.navList.length != 0) {
    //   console.log(this.navList)
    //   this.currentMenu = this.$route.fullPath
    //   this.myMenu = this.currentMenu
    // }
  },
  mounted () {
    setInterval(() => {
      if(this.navList == []) {
        this.$router.push({
          path: '/login'
        })
      }
    }, 1500)
  }
}
</script>

<style scoped>
	.navTag {
		width: 230px;
		height: 100%;
		background: #001b2d;
	}
</style>
<style>
.el-menu-item.is-active {
	background-color: #237AE4 !important;
}
.el-menu-vertical-demo>li:first-child {
  /* display: none; */
}
.el-submenu__title span {
  color: #ABB1BB;
}
.is-opened .el-submenu__title span {
  color: #FFF;
}
.el-menu-item {
  color: #ABB1BB !important;
}
.is-active {
  color: #fff !important;
}
</style>
