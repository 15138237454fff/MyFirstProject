<template>
  <div class="checkDetails">
    <div class="top-title">
      <el-button icon="el-icon-refresh-left" class="diyButton" @click="exitList">返回列表</el-button>
    </div>
    <div class="header-left">
      <el-input v-model="pageHelper.query" placeholder="请输入项目名称" style="width:200px" @keyup.enter.native="loadTable(1)" class="fl" clearable @clear="loadTable"></el-input>
      <el-button @click="loadTable(1)" style="margin-left:5px" class="fl">查询</el-button>
      <el-button @click="exportTable" style="margin-left:5px" type="success" class="fl">导出</el-button>
      <div class="dia-left">
        <div>
          已投人数：<span>{{castInfo.cast}}&nbsp;&nbsp;</span>
        </div>
        <div>
          未投人数：<span>{{castInfo.noCast}}</span>
        </div>
        <!-- <div>
          通过人数：<span>1</span>
        </div>
        <div>
          未通过数：<span>1</span>
        </div> -->
      </div>
    </div>
    <div class="header-right">
      <el-form ref="form" :model="againInfo" :inline="true" v-if="showAgain">
        <el-form-item label="是否限制最高通过票数:">
          <el-radio-group v-model="againInfo.limit">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="" prop="votePeopleNum" v-show="againInfo.limit==1">
          <el-input v-model.number="againInfo.votePeopleNum" size="small" style="width:120px;">
            <template slot="append">/{{number}}</template>
          </el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitAgain" size="small">提交</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="table">
      <el-table :data="pageInfo.list" ref="countTable" v-if="showTable" border @select="voteSelect" @select-all="allClick" :height="tableHeight">
        <el-table-column v-if="showAgain" :reserve-selection="true" fixed="left" type="selection" width="55">
        </el-table-column>
        <el-table-column v-for="(item, index) in countTableInfo.tableColInfo" :show-overflow-tooltip="true" :prop="item.attributeName" :label="item.attributeNameCn" :key="index" :min-width="getColWidth(item.ratio)" :fixed="index==0">
        </el-table-column>
        <el-table-column fixed="right" prop="TONGYPS" label="同意数" width="80px" v-if="getIsShowByRules(0)">
        </el-table-column>
        <el-table-column fixed="right" prop="BUTYPS" label="不同意数" width="100px" v-if="getIsShowByRules(0)">
        </el-table-column>
        <el-table-column fixed="right" prop="QIQPS" label="弃权数" width="80px" v-if="getIsShowByRules(0)">
        </el-table-column>
        <el-table-column fixed="right" prop="JIEG" label="结果" width="80px" v-if="getIsShowByRules(0)">
          <template slot-scope="scope">
            <span>{{getDictValue(scope.row.JIEG,'result')}}</span>
          </template>
        </el-table-column>
        <el-table-column fixed="right" prop="ZONGF" label="总分" width="100px" v-if="getIsShowByRules(1)">
        </el-table-column>
        <el-table-column fixed="right" prop="PAIMZH" label="总排名" width="100px" v-if="getIsShowByRules(2)">
        </el-table-column>
        <el-table-column fixed="right" prop="PAIMJG" label="排名结果" width="100px" v-if="getIsShowByRules(2)">
        </el-table-column>
      </el-table>
    </div>
    <div class="block">
      <el-pagination :current-page.sync="pageHelper.pageNum" :page-sizes="[5, 10, 50, 100]" :page-size="pageHelper.pageSize" class="import" layout="total, sizes, prev, pager, next, jumper" @current-change="changePage" :total="pageInfo.total" @size-change="sizeChange">
      </el-pagination>
    </div>
  </div>
</template>
<script>
export default {
  props: [],
  name: 'table',
  data() {
    return {
      showTable: false,
      showAgain: false,
      countTableInfo: {
        tableColInfo: []
      },
      pageInfo: {
        list: []
      },
      number: 0,
      pageHelper: {
        pageNum: 1,
        pageSize: 10,
        query: "",
        projectId: null
      },
      againInfo: {
        limit: 0,
        dataId: []
      },
      castInfo: {
        cast: 0,
        noCast: 0
      },
      offsetTop: null,
      clientHeight: null,
      tableHeight: null,
      projectInfo: null
    }
  },
  methods: {
    exportTable(){
      window.location.href="api/vtc/down/"+this.projectInfo.id
    },
    getIsShowByRules(rules) {
      if (this.projectInfo.voteRules == rules) {
        return true;
      } else {
        return false;
      }
    },
    //提交再次发起投票
    submitAgain() {
      if (this.againInfo.limit == 1 && this.againInfo.votePeopleNum > this.number) {
        this.$message.error('选择人数不能大于限制人数')
        return;
      }
      this.againInfo.projectId = this.pageHelper.projectId;
      this.$http
        .post("api/spot/again", this.againInfo)
        .then(res => {
          if (res.data.code == 200) {
            this.exitList();
            this.$message({
              type: "success",
              message: "再次发起投票成功!"
            })
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    allClick(selection) {
      this.againInfo.dataId = []
      selection.map((item, index) => {
        this.againInfo.dataId.push(item.dataId)
      })
      this.number = this.againInfo.dataId
    },
    voteSelect(selection, row) {
      this.againInfo.dataId = []
      selection.map((item, index) => {
        this.againInfo.dataId.push(item.dataId)
      })
      this.number = this.againInfo.dataId.length
    }, // 再次发起投票数据选择
    changePage(index) {
      this.pageHelper.pageNum = index;
      this.loadTable();
    },
    sizeChange(index) {
      this.pageHelper.pageSize = index;
      this.loadTable();
    },
    exitList() {
      this.showTable = false;
      this.$parent.closeCountTable();
    },
    getColWidth(ratio) {
      return ratio + "px";
    },
    //已投/未投信息
    loadCastInfo() {
      this.$http
        .get("api/spot/castInfo/" + this.pageHelper.projectId)
        .then(res => {
          if (res.data.code == 200) {
            this.castInfo = res.data.data;
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    //计票表列表
    loadTable() {
      this.$http
        .post("api/vtc/count", this.pageHelper)
        .then(res => {
          if (res.data.code == 200) {
            this.pageInfo = res.data.data;
          } else {
            this.$message.error(res.data.message)
          }
        })
        .catch(function (err) {
          console.log(err)
        })
    },
    //加载表信息
    loadTableInfo() {
      this.$http.get('/api/vtc/countInfo/' + this.pageHelper.projectId).then(res => {
        if (res.data.code == 200) {
          this.countTableInfo = res.data.data;
          this.loadTable();
        } else {
          this.$message.error(res.data.message)
        }
      })
        .catch(err => {
          console.log(err)
        })
    },
    loadAgainInfo(myrow) {
      this.showAgain = true;
      this.initInfo(myrow);
    },
    loadInfo(myrow) {
      this.showAgain = false;
      this.initInfo(myrow);
    },
    initInfo(myrow) {
      this.showTable = true;
      this.pageHelper.projectId = myrow.id;
      this.projectInfo = myrow;
      //计票表列表
      this.loadTableInfo();
      //已投/未投信息
      this.loadCastInfo();
    }
  },
  mounted() {
    // this.offsetTop = this.$refs.countTable.$el.offsetTop - document.documentElement.scrollTop
    // this.clientHeight = `${document.documentElement.clientHeight}`
    // this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    // console.log(this.tableHeight)
    // window.onresize = () => {
    //   return (() => {
    //     this.clientHeight = `${document.documentElement.clientHeight}`
    //     this.tableHeight = document.documentElement.clientHeight - (this.offsetTop + 150)
    //   })()
    // }
  }
}

</script>

<style scoped lang="scss">
.fl {
  float: left;
}
.header-left {
  float: left;
  padding-top: 20px;
  margin-bottom: 15px;
}
.header-right {
  padding-top: 20px;
  float: right;
  width: 500px;
}
.dia-left {
  float: left;
}
.dia-left div {
  float: left;
  position: relative;
  left: 50px;
  top: 8px;
  font-size: 16px;
  color: #606266;
  span {
    font-size: 14px;
    color: #606266;
  }
}
.table {
  margin-bottom: 15px;
}
.checkDetails {
  .top-title {
    width: 100%;
    height: 60px;
    background: #f2f2f2;
    line-height: 60px;
    margin-bottom: 15px;
    .diyButton {
      background: none;
      border: none;
      color: #2779e3;
    }
  }
  .el-table td,
  .el-table th {
    padding: 15px 0 !important;
  }
}
</style>