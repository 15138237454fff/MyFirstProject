import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const router = new Router({
    mode: 'history',
    routes: [{
            path: '/',
            name: 'login',
            component: () =>
                import ('@/views/login/login.vue'),
            meta: {
                title: '登录页',
                requireAuth: true
            }
        },
        {
            path: '/homePage',
            name: 'homePage',
            component: () =>
                import ('@/views/students/homePage/homePage.vue'),
            meta: {
                title: '学生主页',
                requireAuth: true
            }
        },
        {
            path: '/lecturerHomePage',
            name: 'lecturerHomePage',
            component: () =>
                import ('@/views/students/homePage/homePage.vue'),
            meta: {
                title: '讲师主页',
                requireAuth: true
            }
        },
        {
            path: '/personalDetails',
            name: 'personalDetails',
            component: () =>
                import ('@/views/personalCenter/personalDetails.vue'),
            meta: {
                title: '个人中心',
                requireAuth: true
            }
        },
        {
            path: '/changePassword',
            name: 'changePassword',
            component: () =>
                import ('@/views/personalCenter/changePassword.vue'),
            meta: {
                title: '修改密码',
                requireAuth: true
            }
        },
        {
            path: '/personalDetails',
            name: 'personalDetails',
            component: () =>
                import ('@/views/personalCenter/exit.vue'),
            meta: {
                title: '退出登录',
                requireAuth: true
            }
        }
    ]
})

export default router