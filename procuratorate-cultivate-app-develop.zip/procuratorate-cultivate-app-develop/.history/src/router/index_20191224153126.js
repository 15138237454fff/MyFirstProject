import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const router = new Router({
    mode: 'history',
    routes: [{
            path: '/',
            name: 'login',
            component: () =>
                import ('@/views/login/login.vue'),
            meta: {
                title: '登录页',
                requireAuth: true
            }
        },
        {
            path: '/personalDetails',
            name: 'personalDetails',
            component: () =>
                import ('@/views/personalCenter/personalDetails.vue'),
            meta: {
                title: '个人中心',
                requireAuth: true
            }
        },
        {
            path: '/exit',
            name: 'exit',
            component: () =>
                import ('@/views/personalCenter/exit.vue'),
            meta: {
                title: '退出登录',
                requireAuth: true
            }
        },
        {
            path: '/changePhone',
            name: 'changePhone',
            component: () =>
                import ('@/views/personalCenter/changePhone.vue'),
            meta: {
                title: '修改手机号码',
                requireAuth: true
            }
        },
        {
            path: '/changeEmail',
            name: 'changeEmail',
            component: () =>
                import ('@/views/personalCenter/changeEmail.vue'),
            meta: {
                title: '修改电子邮箱',
                requireAuth: true
            }
        },
        {
            path: '/announcements',
            name: 'announcements',
            component: () =>
                import ('@/views/tzgg/announcements.vue'),
            meta: {
                title: '通知公告',
                requireAuth: true
            }
        },
        {
            path: '/announcementsDetile',
            name: 'announcementsDetile',
            component: () =>
                import ('@/views/tzgg/announcementsDetile.vue'),
            meta: {
                title: '通知公告详情',
                requireAuth: true
            }
        },
        {
            path: '/personChangePsd',
            name: 'personChangePsd',
            component: () =>
                import ('@/views/personalCenter/personChangePsd.vue'),
            meta: {
                title: '忘记密码修改密码',
                requireAuth: true
            }
        },
        {
            path: '/changePassword',
            name: 'changePassword',
            component: () =>
                import ('@/views/login/forgotPassword/changePassword.vue'),
            meta: {
                title: '忘记密码修改密码',
                requireAuth: true
            }
        },
        {
            path: '/resetPassword',
            name: 'resetPassword',
            component: () =>
                import ('@/views/login/forgotPassword/resetPassword.vue'),
            meta: {
                title: '重置密码'
            }
        },
        {
            path: '/personalDetails',
            name: 'personalDetails',
            component: () =>
                import ('@/views/personalCenter/exit.vue'),
            meta: {
                title: '退出登录',
                requireAuth: true
            }
        },
        {
            path: '/homePage',
            name: 'homePage',
            component: () =>
                import ('@/views/students/homePage/homePage.vue'),
            meta: {
                title: '学生主页',
                requireAuth: true
            }
        },
        {
            path: '/lecturerHomePage',
            name: 'lecturerHomePage',
            component: () =>
                import ('@/views/lecturer/homePage/homePage.vue'),
            meta: {
                title: '讲师主页',
                requireAuth: true
            }
        },
        //讲师
        {
            path: '/lecturerTrain',
            name: 'lecturerTrain',
            component: () =>
                import ('@/views/lecturer/train/index.vue'),
            meta: {
                title: '我的培训',
                requireAuth: true
            }
        },
        {
            path: '/lecturerTrainDetail',
            name: 'lecturerTrainDetail',
            component: () =>
                import ('@/views/lecturer/train/detail.vue'),
            meta: {
                title: '培训详情',
                requireAuth: true
            }
        },
        {
            path: '/lecturerSummary',
            name: 'lecturerSummary',
            component: () =>
                import ('@/views/lecturer/summary/index.vue'),
            meta: {
                title: '我的小结',
                requireAuth: true
            }
        },
        {
            path: '/lecturerSummaryDetail',
            name: 'lecturerSummaryDetail',
            component: () =>
                import ('@/views/lecturer/summary/detail.vue'),
            meta: {
                title: '小结详情',
                requireAuth: true
            }
        },
        {
            path: '/lecturerLesson',
            name: 'lecturerLesson',
            component: () =>
                import ('@/views/lecturer/lesson/index.vue'),
            meta: {
                title: '我的课程',
                requireAuth: true
            }
        },
        {
            path: '/lecturerLessonDetail',
            name: 'lecturerLessonDetail',
            component: () =>
                import ('@/views/lecturer/lesson/detail.vue'),
            meta: {
                title: '课程详情',
                requireAuth: true
            }
        },
        //学生
        {
            path: '/studentsTra',
            name: 'lecturerTrain',
            component: () =>
                import ('@/views/lecturer/train/index.vue'),
            meta: {
                title: '我的培训',
                requireAuth: true
            }
        },
        {
            path: '/lecturerTrainDetail',
            name: 'lecturerTrainDetail',
            component: () =>
                import ('@/views/lecturer/train/detail.vue'),
            meta: {
                title: '培训详情',
                requireAuth: true
            }
        },
    ]
})

export default router