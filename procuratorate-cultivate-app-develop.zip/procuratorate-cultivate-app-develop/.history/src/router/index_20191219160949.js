import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

const router = new Router({
    mode: 'history',
    routes: [{
            path: '/',
            name: 'login',
            component: () =>
                import ('@/views/login/login.vue'),
            meta: {
                title: '登录页',
                requireAuth: true
            }
        },
        {
            path: '/homePage',
            name: 'homePage',
            component: () =>
                import ('@/views/students/homePage/homePage.vue'),
            meta: {
                title: '学生主页',
                requireAuth: true
            }
        },
        //讲师
        {
            path: '/lecturerHomePage',
            name: 'lecturerHomePage',
            component: () =>
                import ('@/views/lecturer/homePage/homePage.vue'),
            meta: {
                title: '讲师主页',
                requireAuth: true
            }
        },
        {
            path: '/lecturerTrain',
            name: 'lecturerTrain',
            component: () =>
                import ('@/views/lecturer/train/index.vue'),
            meta: {
                title: '我的培训',
                requireAuth: true
            }
        },
        {
            path: '/personalDetails',
            name: 'personalDetails',
            component: () =>
                import ('@/views/personalCenter/personalDetails.vue'),
            meta: {
                title: '个人中心',
                requireAuth: true
            }
        },
        {
            path: '/changePhone',
            name: 'changePhone',
            component: () =>
                import ('@/views/personalCenter/changePhone.vue'),
            meta: {
                title: '修改手机号码',
                requireAuth: true
            }
        },
        {
            path: '/changeEmail',
            name: 'changeEmail',
            component: () =>
                import ('@/views/personalCenter/changeEmail.vue'),
            meta: {
                title: '修改电子邮箱',
                requireAuth: true
            }
        },
        {
            path: '/changePassword',
            name: 'changePassword',
            component: () =>
                import ('@/views/personalCenter/changePassword.vue'),
            meta: {
                title: '修改密码',
                requireAuth: true
            }
        },
        {
            path: '/resetPassword',
            name: 'resetPassword',
            component: () =>
                import ('@/views/personalCenter/resetPassword.vue'),
            meta: {
                title: '重置密码'
            }
        },
        {
            path: '/personalDetails',
            name: 'personalDetails',
            component: () =>
                import ('@/views/personalCenter/exit.vue'),
            meta: {
                title: '退出登录',
                requireAuth: true
            }
        }
    ]
})

export default router