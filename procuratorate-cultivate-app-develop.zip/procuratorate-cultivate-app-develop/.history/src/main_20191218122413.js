// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store/store'
import axios from 'axios'
import rem from '@/utils/rem.js'
import 'mint-ui/lib/style.css'
// 引入全局过滤器
import * as filters from './filters'
// 如果请求超过5s认为超时
// axios.defaults.timeout = 5000;
// 加载全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
// const SUCCESS_CODE = 10000,
//   NOLOGIN = 20001,
//   FORCED_OFF = 20009,
//   msgRelay = 2000
// let timer = null,
//   prevUrl = "", // 添加功能的路由地址，包含一些发布/取消发布
//   addUrlList = ["/api/summary/submit", "/api/myEvaluate/saveScore", "/api/myLeave/applyLeave", "/api/library/lecturer", "/api/myExam/onlineExam"]
// 添加一个请求拦截器
// axios.interceptors.request.use(
//   config => {
//     let needTest = config.method === "post" && addUrlList.includes(config.url)
//     if (needTest && timer === null) {
//       prevUrl = config.url
//       timer = setTimeout(() => {
//         timer = null
//         prevUrl = ""
//       }, 1000)
//     } else if (needTest && config.url === prevUrl) {
//       Message.error("操作过频")
//       return Promise.reject(new Error('操作过频'))
//     } else {
//       clearInterval(timer)
//       timer = null
//       prevUrl = ""
//     }
//     return config;
//   },
//   error => {
//     return Promise.reject(error);
//   }
// );
// 添加一个响应拦截器
// axios.interceptors.response.use(
//   response => {
//     let err = {};
//     let data = response.data;
//     // 如果是直接返回的数据，没有状态码
//     if (data.code === undefined) {
//       return response;
//     }
//     switch (data.code) {
//       // 成功
//       case SUCCESS_CODE:
//         return response;
//         // 未登录
//       case NOLOGIN:
//         // Message.error(data.msg);
//         baseMethod.debounce(() => {
//           Message.error(data.msg)
//         }, msgRelay);
//         err.message = data.msg;
//         store.commit('skb/updateLogin', false);
//         return Promise.reject(err);
//         // 强制下线
//       case FORCED_OFF:
//         // Message.error(data.msg);
//         baseMethod.debounce(() => {
//           Message.error(data.msg)
//         }, msgRelay);
//         err.message = data.msg;
//         store.commit('skb/updateLogin', false);
//         return Promise.reject(err);
//         // 其他错误
//       default:
//         // Message.error(data.msg);
//         baseMethod.debounce(() => {
//           Message.error(data.msg)
//         }, msgRelay);
//         err.message = data.msg;
//         return Promise.reject(err);
//     }
//   },
//   err => {
//     if (err && err.response) {
//       err.message = err.response.data.msg;
//     } else {
//       err.message = "请求超时";
//     }
//     baseMethod.debounce(() => {
//       Message.error(err.message)
//     }, msgRelay);
//     return Promise.reject(err);
//   }
// );

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  router,
  store,
  rem,
  axios,
  render: h => h(App)
}).$mount('#app')
