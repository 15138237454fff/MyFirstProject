<template>
  <div class="navigation">
    <mt-header fixed :title="title">
      <mt-button icon="back" slot="left" @click="previous"></mt-button>
    </mt-header>
  </div>
</template>
<script>
import Vue from "vue";
export default {
  name: "navigation",
  props: { title: "" },
  data() {
    return {};
  },
  methods: {
    previous() {
      this.$route.go(-1);
    }
  }
};
</script>
<style lang="scss" scoped>
.mint-header {
  background-color: #fff;
  /deep/ h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    color: #000;
    font-size: 0.16rem;
    font-weight: 600;
  }
  .mint-button {
    color: #000;
    font-weight: 600;
  }
}
</style>
