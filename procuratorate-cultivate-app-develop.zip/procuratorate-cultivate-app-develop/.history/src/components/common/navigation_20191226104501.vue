<template>
  <van-nav-bar :title="title" left-arrow @click-left.prevent="goBack" right-text="按钮" fixed>

  </van-nav-bar>
</template>
<script>
export default {
  name:'navigation',
  props:{title:''},
  data() {
    return {};
  },
  methods:{
      goBack(){
          this.$router.go(-1)
      }
  }
};
</script>
<style scoped>
.van-nav-bar{
  color: #333;
}
.van-nav-bar__title{
  font-weight: 600;
} 
.van-nav-bar .van-icon {
  color: #323233;
  font-weight: 600;
}
</style>