<template>
    <div class="noData-box">
        暂无数据
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss">
    .noData-box{
        width:100%;
        // height: 2rem;
        // line-height: 2rem;
        font-size:0.2rem;
        text-align: center;
        font-weight: bold;
        // background: #f5f5f5;
        color: #333;
    }
</style>