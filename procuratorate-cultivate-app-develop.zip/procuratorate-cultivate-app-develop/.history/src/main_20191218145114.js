// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store/store'
import axios from 'axios'
import rem from '@/utils/rem.js'
import 'mint-ui/lib/style.css'
// MessageBox('提示', '操作成功');
// 引入全局过滤器
import * as filters from './filters'
// 加载全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  router,
  store,
  rem,
  axios,
  render: h => h(App)
}).$mount('#app')
