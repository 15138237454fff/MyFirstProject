// 星期过滤
export function xqFilter(xq) {
  const statusMap = {
    '1': '星期一',
    '2': '星期二',
    '3': '星期三',
    '4': '星期四',
    '5': '星期五',
    '6': '星期六',
    '7': '星期日'
  }
  return statusMap[xq]
}
// 周星期过滤
export function zXqFilter(xq) {
  const statusMap = {
    '1': '周一',
    '2': '周二',
    '3': '周三',
    '4': '周四',
    '5': '周五',
    '6': '周六',
    '7': '周日'
  }
  return statusMap[xq]
}
// 时间转为日期格式
export function toDate(time, tag) {
  if (!tag) {
    tag = "-"
  }
  let tmpTime = new Date(time),
    year = tmpTime.getFullYear(),
    month = tmpTime.getMonth() + 1,
    date = tmpTime.getDate()
  // 不足10前面补0
  if (month < 10) {
    month = "0" + month
  }
  // 不足10前面补0
  if (date < 10) {
    date = "0" + date
  }
  return `${year}${tag}${month}${tag}${date}`
}
// 时间转为日期时间格式 YYYY.MM.DD HH:MM
export function toDateTime(time, tag) {
  if (!tag) {
    tag = "."
  }
  if (!time) {
    return "-"
  }
  let tmpTime = new Date(time)
  if (!tmpTime) {
    return '-'
  }
  let year = tmpTime.getFullYear(),
    month = tmpTime.getMonth() + 1,
    date = tmpTime.getDate(),
    hour = tmpTime.getHours(),
    minute = tmpTime.getMinutes()
  // 不足10前面补0
  if (month < 10) {
    month = "0" + month
  }
  // 不足10前面补0
  if (date < 10) {
    date = "0" + date
  }
  // 不足10前面补0
  if (hour < 10) {
    hour = "0" + hour
  }
  // 不足10前面补0
  if (minute < 10) {
    minute = "0" + minute
  }
  return `${year}${tag}${month}${tag}${date} ${hour}:${minute}`
}
// 时间转为时间格式 HH:MM
export function toTime(time) {
  let tmpTime = new Date(time)
  if (!tmpTime) {
    return '-'
  }
  let hour = tmpTime.getHours(),
    minute = tmpTime.getMinutes()
  // 不足10前面补0
  if (hour < 10) {
    hour = "0" + hour
  }
  // 不足10前面补0
  if (minute < 10) {
    minute = "0" + minute
  }
  return `${hour}:${minute}`
}
// 时间转为年月日格式
export function toYMD(time) {
  let tmpTime = new Date(time)
  if (isNaN(tmpTime)) {
    return ''
  }
  return `${tmpTime.getFullYear()}年${tmpTime.getMonth() + 1}月${tmpTime.getDate()}日`
}

export function sexFilter(sex) {
  if (typeof sex !== 'number') {
    console.info("请给过滤器传入一个number类型数据")
    return ""
  }
  switch (sex) {
    case 1:
      return '男'
    case 2:
      return '女'
    default:
      return "未知"
  }
}
