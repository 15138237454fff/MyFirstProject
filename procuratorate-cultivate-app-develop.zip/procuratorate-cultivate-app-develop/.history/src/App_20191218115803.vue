<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  list-style: none;
  text-decoration: none;
}
html,body {
  width: 100%;
  height: 100%;
}
#app {
  width: 100%;
  height: 100%;
}
a {
  text-decoration: none;
}

input {
  outline: none;
  border: 0;
}

button {
  outline: none;
  border: 0;
}
select {
  outline: none;
  border: 0;
}
</style>
