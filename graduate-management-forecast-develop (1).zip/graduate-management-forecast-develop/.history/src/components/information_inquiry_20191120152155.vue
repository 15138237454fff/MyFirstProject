<template>
  <!--联系方式查询-->
  <div class="information_inquiry">
    <navigation :title="title" />
    <div class="information_see">
      <ul class="ul_container">
        <li v-for="(services,index) in service" :key="index">
          <span>{{services.name}}</span>
          <p id="inputright">
            <a href="http://www.zjut.edu.cn/">{{services.msg}}</a>
          </p>
        </li>
        <li>
          <span>校方电话</span>
          <p id="inputright">
            <a href="tel:0578-123456">0578-123456</a>
          </p>
        </li>
        <li>
          <span>新生答疑社群</span>
          <p id="inputright">
            <a href="http://wpa.qq.com/msgrd?v=3&uin=3419803745&site=qq&menu=yes">3419803745</a>
          </p>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue"
export default {
  name:'information_inquiry',
  components:{
      navigation
  },
  data() {
    return {
      ti
      service: [
        {
          name: "学校官网",
          msg: "http://www.zjut.edu.cn"
        },
        {
          name: "研究生综合服务平台",
          msg: "http://www.zjut-edu.com"
        }
      ]
    };
  },
  methods: {
    golast() {
      this.$router.go(-1);
    }
  },
  created() {
    document.title = "联系方式查询";
  }
};
</script>

<style scoped>
@import url("../../static/css/information_inquiry/information_inquiry.css");
</style>