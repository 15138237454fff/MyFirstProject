<template>
  <!--联系方式查询-->
  <div class="information_inquiry">
    <navigation :title="title" />
    <div class="information_see">
      <ul class="ul_container">
        <li v-for="(item, index) in service" :key="index">
          <span>{{ item.name }}</span>
          <p id="inputright">
            <a :href="item.href">{{ item.msg }}</a>
          </p>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue";
export default {
  name: "information_inquiry",
  components: {
    navigation
  },
  data() {
    return {
      title: "联系方式查询",
      service: [
        {
          name: "学校官网",
          href:"http://www.zjut.edu.cn/",
          msg: "http://www.zjut.edu.cn"
        },
        {
          name: "研究生综合服务平台",
          href:"http://www.zjut-edu.com",
          msg: "http://www.zjut-edu.com"
        },
        {
          name: "校方电话",
          href:"tel:0578-123456",
          msg: "0578-123456"
        },
        {
          name: "新生答疑社群",
          href:"http://wpa.qq.com/msgrd?v=3&uin=3419803745&site=qq&menu=yes",
          msg: "3419803745"
        },
      ]
    };
  },
  methods: {
  },
  created() {
  }
};
</script>

<style scoped>
.information_inquiry {
  width: 100%;
  height: 100%;
  background-color: #f5f5f5;
}
.ul_container {
  position: relative;
  top: 0.55rem;
  font-size: 0.16rem;
  color: #333333;
}
li{
  padding: 0.1rem 0.1rem;
  background-color: #fff;
}
a {
  color: #999999;
}
span{
  font-weight: 
}
#inputright {
  text-align: right;
  float: right;
  color: #999999;
  font-size: 0.14rem;
}
</style>
