<template>
  <!--报道二维码-->
  <div class="er_code">
    <navigation :title="title" />
    <div class="underline"></div>
    <div class="er_code_safe">
      <!--使用qrcode自动生成二维码-->
      <div id="qrCode">
        <div id="code"></div>
        <canvas id="canvas"></canvas>
      </div>
      <p>迎新报到时请出示报到二维码</p>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue"
import QRCode from "qrcode";
export default {
   name: "er_code",
  components: {
    navigation
  },
  data() {
    return {
      title:'报道二维码',
      codes: "" //默认二维码中间图片
    };
  },
  methods: {
    useqrcode() {
      var canvas = document.getElementById("canvas");
      QRCode.toCanvas(canvas, this.sfzh.toString(), function(error) {
        console.log(error);
      });
    }
  },
  components: {
    //使用生成二维码的形式
    QRCode: QRCode
  },
  created() {
  },
  mounted() {
    this.useqrcode();
  },
  computed: {
    sfzh() {
      return sessionStorage.getItem("sfzh");
    }
  }
};
</script>

<style scoped>
@import url("../../static/css/er_code/er_code.css");
</style>