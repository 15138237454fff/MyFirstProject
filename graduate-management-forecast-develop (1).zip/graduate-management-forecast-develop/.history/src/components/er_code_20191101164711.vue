<template>
	<!--报道二维码-->
	<div class="er_code">
		<van-nav-bar title="报道二维码">
			<router-link to slot="left">
				<button icon="back" @click="golast"></button>
			</router-link>
		</van-nav-bar>
		<div class="underline"></div>
		<div class="er_code_safe">
			<!--使用qrcode自动生成二维码-->
			<div id="qrCode">
				<div id='code'></div>
				<canvas id="canvas"></canvas>
			</div>
			<p>迎新报到时请出示报到二维码</p>
		</div>
	</div>
</template>
<script>
	import QRCode from 'qrcode'
	export default {
		data() {
			return {
				codes: '', //默认二维码中间图片
			}
		},
		methods: {
			useqrcode() {
				var canvas = document.getElementById('canvas')
				QRCode.toCanvas(canvas, this.sfzh.toString(), function (error) {
					console.log(error)
				})
			},
			golast
		},
		components: { //使用生成二维码的形式
			QRCode: QRCode
		},
		created() {
			document.title = "报道二维码";
		},
		mounted() {
			this.useqrcode();
		},
		computed: {
			sfzh() {
				return sessionStorage.getItem("sfzh");
			},
		}
	}
</script>

<style scoped="scoped">
	@import url("../../static/css/public.css");
	@import url("../../static/css/er_code/er_code.css");
</style>