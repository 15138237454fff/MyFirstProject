<template>
	<!--联系方式查询-->
	<div class="information_inquiry">
		<van-nav-bar title="联系方式查询">
			<router-link to slot="left">
				<button @click="golast" style="background:#fff;"><span style="font-size:0.2rem;"><</span></button>
			</router-link>
		</van-nav-bar>
		<div class="information_see">
			<ul class="ul_container">
				<li v-for="(services,index) in service" :key="index">
					<span>{{services.name}}</span>
					<p id="inputright">
						<a href="http://www.zjut.edu.cn/">{{services.msg}}</a>
					</p>
				</li>
				<li>
					<span>校方电话</span>
					<p id="inputright">
						<a href="tel:0578-123456">0578-123456</a>
					</p>
				</li>
				<li>
					<span>新生答疑社群</span>
					<p id="inputright">
						<a href="http://wpa.qq.com/msgrd?v=3&uin=3419803745&site=qq&menu=yes">3419803745</a>
					</p>
				</li>
			</ul>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				service: [{
					name: '学校官网',
					msg: 'http://www.zjut.edu.cn'
				}, {
					name: '研究生综合服务平台',
					msg: 'http://www.zjut-edu.com'
				}]
			}
		},
		methods: {
			golast()
		},
		created() {
			document.title = "联系方式查询";
		}
	}
</script>

<style scoped="scoped">
	@import url("../../static/css/public.css");
	@import url("../../static/css/information_inquiry/information_inquiry.css");
</style>