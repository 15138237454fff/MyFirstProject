<template>
<!--个人信息补充-->
<div class="information_supplement" :style="{ height: bodyHeight + 'px' }">
<navigation :title="title" />
<!--个人信息补充的安全区-->
<div class="information_supplement_safe">
<!--学生姓名-->
<div class="stu_name">
		<!--学生图片-->
<div class="stu_name_manu">
<div class="stu_img">
	<img id="moimg" @click="appear" :src="basic.zp" />
	<!--点击上传头像，以模态框的形式呈现-->
	<div class="motai" id="mo" @click="closeimg">
		<img class="imgzp" :src="basic.zp" />
	</div>
</div>
<p class="stuname">{{basic.xsxm}}</p>
<p class="stuid">{{basic.xh}}</p>
</div>
</div>
<div class="undeline1"></div>
<!--学生综合信息-->
<div class="student_information">
	<!--学生基本信息-->
<div class="basic_information">
	<div class="basic_information_safe">
	<p class="basic"><span class="username">|</span> 基本信息</p>
	<div class="undeline"></div>
	<ul class="ul_container">
		<li>
			<span>性别</span>
			<p id="inputright">{{basic.xbm}}</p>
		</li>
		<li>
			<span>民族</span>
			<p id="inputright">{{basic.mz}}</p>
		</li>
		<li>
			<span>证件类型</span>
			<p id="inputright">{{basic.sfzjlxmc}}</p>
		</li>
		<li>
			<span>证件号码</span>
			<p id="inputright">{{basic.sfzh}}</p>
		</li>
		<li>
			<span>学院</span>
			<p id="inputright">{{basic.xy}}</p>
		</li>
		<li>
			<span>专业</span>
			<p id="inputright">{{basic.zy}}</p>
		</li>
		<li>
			<span>研究方向</span>
			<p id="inputright">{{basic.yjfx}}</p>
		</li>
		<li>
			<span>学生类别</span>
			<p id="inputright">{{basic.xslbmc}}</p>
		</li>
		<li>
			<span>培养层次</span>
			<p id="inputright">{{basic.pycc}}</p>
		</li>
		<li>
			<span>导师</span>
			<p id="inputright">{{basic.dsxm}}</p>
		</li>
	</ul>
</div>
<!--联系方式-->
<div class="basic_information_safe">
<div class="undeline1"></div>
<p class="basic"><span class="username">|</span> 联系方式</p>
<div class="undeline"></div>
<ul class="ul_container">
	<li>
		<span>电话号码</span>
		<input type="text" name="" id="inputright" value="" v-model="basic.dh" />
	</li>
	<li>
		<span>电子邮箱</span>
		<input type="text" name="" id="inputright" value="" v-model="basic.dzxx" />
	</li>
	<li>
		<span>家庭住址</span>
		<input type="text" name="" id="inputright" value="110101" v-model="basic.jtzz" />
	</li>
</ul>
</div>
				<!--家庭成员信息-->
				<div class="home" v-for="(home,index) in home" :key="index">
					<div class="undeline1"></div>
					<p class="home_p">
						<span class="home_span"></span> 家庭成员信息{{index+1}}
						<button @click="add" class="add">添加</button>
						<button @click="del(index)" v-if="index!==0" class="del">删除</button>
					</p>
					<div class="undeline"></div>
					<div class="home_safe2">
						<ul class="ul_container">
							<li>
								<span>姓名</span>
								<input type="text" name="" id="inputright" value="" v-model="home.cyxm" placeholder="请输入姓名" />
							</li>
							<li style="color:#333333;">
								<span>与本人关系</span>
								<select name="select" v-model="home.gxm" id="inputright" class="select1" style="width:auto;padding:0 2%;margin: 0;">
									<option :value="relationships.value" v-for="(relationships,index) in myrelationship" :key="index" style="text-align: center;">{{relationships.label}}</option>
								</select>
							</li>
							<li>
								<span>联系方式</span>
								<input type="text" name="" id="inputright" value="" v-model="home.lxfs" placeholder="请输入联系方式" />
							</li>
							<li>
								<span>工作单位</span>
								<input type="text" name="" id="inputright" value="" v-model="home.gzdw" placeholder="请输入工作单位" />
							</li>
							<li>
								<span>职业</span>
								<select name="select" v-model="home.zy" id="inputright" class="select1" style="width:1.25rem;padding:0 2%;margin: 0;">
									<option :value="familyzy.value" v-for="(familyzy,index) in family" :key="index" style="text-align: center;">{{familyzy.label}}</option>
								</select>
							</li>
						</ul>
					</div>
				</div>
				<!--上传毕业证-->
				<div class="undeline1"></div>
				<div class="upload_graduation">
					<p class="upload_graduation_p">
						<span class="upload_graduation_span">*</span>上传毕业证
						<span id="inputright">支持上传图片格式：png、jpg、jpeg</span>
					</p>
					<div class="undeline"></div>
					<div id="removeimg1">
						<div class="filedate">
							<div class="fileson" v-for="(item,index) in fileList" :key="index" id="son1">
								<img id="remove1" @click="rem1(fileList,index)" src="../../static/images/remove.png" />
								<img :src="item.url" class="fileimg" />
							</div>
							<van-uploader :before-read="beforeRead" :max-count="1" />
						</div>
					</div>
				</div>
				<div class="undeline1"></div>
				<div class="upload_degree">
					<!--上传学位证-->
					<p class="upload_degree_p">
						<span class="upload_degree_span"><span class="degree_red">*</span>上传学位证</span>
						<span id="inputright">支持上传图片格式：png、jpg、jpeg</span>
					</p>
					<div class="undeline"></div>
					<div id="removeimg2">
						<div class="filedate">
							<div class="fileson" v-for="(item,index) in confiurl" :key="index" id="son2">
								<img id="remove2" @click="rem2(confiurl,index)" src="../../static/images/remove.png"></img>
								<img :src="item.url" class="fileimg" />
							</div>
							<van-uploader :before-read="beforeRead1" :max-count="1" />
						</div>
					</div>
				</div>
				<!--提交数据-->
				<div class="follter">
					<button @click="tijiao">提交</button>
				</div>
			</div>
		</div>
	</div>
</div>
</template>
<script>
import VueCropper from 'vue-cropperjs'
import 'cropperjs/dist/cropper.css'
import navigation from "@/components/navigation.vue"
export default {
	name:'information_supplement',
	components: {
		VueCropper,
		navigation
	},
	name: 'App',
	data() {
		return {
			title:'个人信息补充',
			imageUrl: '',
			bodyHeight: '',
			basic: {},
			home: [],
			myrelationship: [],
			family: [],
			confiurl: [],
			files: '',
			fileList: []
		}
	},
	methods: {
		beforeRead(file) {
			this.fileList = [];
			let param = new FormData(); //创建form对象
			param.append("file", file); //通过append向form对象添加数据
			this.$http.post('/urlcode/system/upload', param).then(res => {
				if (res.data.code == 200) {
				this.fileList.push(res.data.data)
				} else {
				this.$toast("上传附件失败");
				}
			})
		},
		beforeRead1(file) {
			this.confiurl = [];
			let param = new FormData(); //创建form对象
			param.append('file', file); //通过append向form对象添加数据
			this.$http.post('/urlcode/system/upload', param).then(res => {
				if (res.data.code == 200) {
				this.confiurl.push(res.data.data)
				} else {
				this.$toast("上传附件失败");
				}
			})
		},
		add() {
			var obj = [{
				cyxm: '',
				gxm: '',
				lxfs: '',
				gzdw: '',
				zy: '',
			}];
			this.home.push(obj)
		},
		del(index) {
			this.home.splice(index, 1); //数组删除根据索引值
		},
		//提交学生信息的内容
		tijiao() {
			var files = sessionStorage.getItem('fileurl');
			var filesxw = sessionStorage.getItem('fileurl2');
			var arr = [];
			var obj = {};
			this.home.map((v) => {
				obj = {
					cyxm: v.cyxm, //成员姓名
					gxm: v.gxm, //关系码
					gzdw: v.gzdw, //工作单位
					lxfs: v.lxfs, //联系方式
					zy: v.zy, //职业码
				}
				arr.push(obj);
			});
			this.$http.put('/urlcode/orientation/nic', {
					'byz': files,
					'xwz': filesxw,
					'jtcy': arr,
				})
				.then((res) => {
					if(res.data.code == 200) {
						this.$toast("提交成功！")
						this.$router.push('/prediction_channel'); //提交完成后跳转至主页面
					} else {
						this.$toast(res.data.message)
					}
				})
		},
		appear() {
			var motai1 = document.getElementById("mo");
			motai1.style.display = "block";
		},
		closeimg() {
			var motai1 = document.getElementById("mo");
			motai1.style.display = "none";
		},
		rem1(fileList,index) {
			fileList.splice(index, 1);
		},
		rem2(confiurl,index) {
			confiurl.splice(index, 1);
		},
	},
	created() {},
	mounted(){
		// this.$http.get('/urlcode/orientation/nic/' + this.xh) //学生的基本信息
		this.$http.get('/urlcode/orientation/nic/1110501012') //学生的基本信息
			.then((res) => {
				this.basic = res.data.data;
				this.home = res.data.data.jtcy;
			})
		this.$http.get('/urlcode/system/dict/select/jtgx') //与本人关系   系统数据字典信息查询---数据字典下拉框查询
			.then((res) => {
				this.myrelationship = res.data.data;
			})
		//职业代码
		this.$http.get('/urlcode/system/dict/select/zyfly')
			.then((res) => {
				this.family = res.data.data;
			})
	},
	computed: {
		xh() {
			return sessionStorage.getItem("xh");
		},
	}
}
</script>

<style scoped>
/* @import url("../../static/css/information_supplement/information_supplement.css"); */
.information_supplement {
  width: 100%;
  height: 100%;
  position: relative;
  background: #f5f5f5;
  color: #333333;
  font-size: 0.16rem;
}
.undeline {
  width: 100%;
  height: 0.02rem;
  background-color: #f5f5f5;
}
.undeline1 {
  width: 100%;
  height: 0.1rem;
  background: #f5f5f5;
}
.stu_name {
  margin-top: 0.45rem;
}
.stu_name_manu {
  padding: 0.1rem 0;
  text-align: center;
  background-color: #ffffff;
}
.stu_name_manu #moimg {
  width: 1rem;
  height: 1rem;
  border-radius: 50%;
}
.stu_name_manu #mo {
  display: none;
  width: 100%;
  height: 100%;
  position: fixed;
  overflow: auto;
  background-color: #afaeae;
  top: 0px;
  left: 0px;
  z-index: 1;
}
#mo .imgzp {
  width: 2.8rem;
  height: 2.8rem;
  border-radius: 50% 50%;
  margin: 0 auto;
  margin-top: 1.4rem;
}
.stu_name_manu .stuid {
  margin-top: 0.05rem;
}
.basic_information_safe{
	background-color: #fff;
}
.basic{
	padding: 0 0.1rem;
	height: 0.4rem;
	line-height: 0.4rem;
}
</style>