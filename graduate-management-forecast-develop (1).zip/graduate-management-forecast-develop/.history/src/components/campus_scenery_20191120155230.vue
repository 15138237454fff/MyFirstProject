<template>
  <!--校园风采-->
  <div class="campus_scenery">
    <navigation :title="title" />
    <div>
      <div class="campus_safe" v-for="(item, index) in imageList" :key="index">
        <viewer @click="setBackground">
          <div>
            <img :src="item.url" />
          </div>
          <p>
            <span>{{ item.fileName }}</span>
          </p>
        </viewer>
      </div>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue";
export default {
  name: "campus_scenery",
  components: {
    navigation
  },
  data() {
    return {
      title: "校园风采",
      actibeimg: true,
      imageList: []
    };
  },
  methods: {
    setBackground() {
      this.Style.background = "#333";
    },
    golast() {
      this.$router.go(-1);
    }
  },
  created(index) {
    this.$http.get("/urlcode/orientation/csc/list").then(res => {
      this.imageList = res.data.data;
    });
  }
};
</script>
<style scoped>
.campus_scenery {
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: #f5f5f5;
}
.campus_safe {
  width: 100%;
  height: 2.4rem;
  background-color: #ffffff;
  text-align: center;
}
img {
  width: 90%;
  height: 2.2rem;
  border-radius: 0.06rem;
  margin-top: 0.1rem;
}
p {
  font-size: 0.16rem;
  color: #ffffff;
  width: 90%;
  margin: 0 auto;
  height: 0.3rem;
  line-height: 0.3rem;
  background: rgba(0, 0, 0, 0.5);
  position: relative;
  bottom: 0.3rem;
  text-align: left;
  border-radius: 0 0 0.06rem 0.06rem;
}
span {
  margin-left: 0.1rem;
}
/deep/ .viewer-backdrop {
  background-color: black;
}
</style>
