<template>
  <!--校园风采-->
  <div class="campus_scenery">
    <navigation :title="title" />
    <van-nav-bar title="校园风采">
      <router-link to slot="left">
        <button @click="golast" style="background:#fff;">
          <span style="font-size:0.2rem;"><</span>
        </button>
      </router-link>
    </van-nav-bar>
    <div class="campus_safe" v-for="(item,index) in imageList" :key="index">
      <viewer @click="setBackground">
        <div>
          <img :src="item.url" />
        </div>
        <p>
          <span>{{item.fileName}}</span>
        </p>
      </viewer>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue";
export default {
  name: "campus_scenery",
  components: {
    navigation
  },
  data() {
    return {
      titk
      
      actibeimg: true,
      imageList: []
    };
  },
  methods: {
    setBackground() {
      this.Style.background = "#333";
    },
    golast() {
      this.$router.go(-1);
    }
  },
  created(index) {
    document.title = "校园风光";
    this.$http.get("/urlcode/orientation/csc/list").then(res => {
      this.imageList = res.data.data;
      console.log(res.data.data);
    });
  }
};
</script>
<style scoped>
@import url("../../static/css/public.css");
@import url("../../static/css/campus_scenery/campus_scenery.css");
/deep/ .viewer-backdrop {
  background-color: black;
}
</style>