<template>
  <!--联系方式查询-->
  <div class="information_inquiry">
    <navigation :title="title" />
    <div class="information_see">
      <ul class="ul_container">
        <li v-for="(services,index) in service" :key="index">
          <span>{{services.name}}</span>
          <p id="inputright">
            <a href="http://www.zjut.edu.cn/">{{services.msg}}</a>
          </p>
        </li>
        <li>
          <span>校方电话</span>
          <p id="inputright">
            <a href="tel:0578-123456">0578-123456</a>
          </p>
        </li>
        <li>
          <span>新生答疑社群</span>
          <p id="inputright">
            <a href="http://wpa.qq.com/msgrd?v=3&uin=3419803745&site=qq&menu=yes">3419803745</a>
          </p>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue"
export default {
  name:'information_inquiry',
  components:{
      navigation
  },
  data() {
    return {
      title:'报道信息采集',
      service: [
        {
          name: "学校官网",
          msg: "http://www.zjut.edu.cn"
        },
        {
          name: "研究生综合服务平台",
          msg: "http://www.zjut-edu.com"
        }
      ]
    };
  },
  methods: {
    golast() {
      this.$router.go(-1);
    }
  },
  created() {
    document.title = "联系方式查询";
  }
};
</script>

<style scoped>
@import url("../../static/css/information_inquiry/information_inquiry.css");
@mixin clearfix {
    clear: both;
    display: block;
    content: "";
}
.information_inquiry {
    width: 100%;
    height: 100%;
    background-color: #F5F5F5;
    .information_see {
        width: 100%;
        height: 1.7rem;
        background-color: #FFFFFF;
        position: relative;
        top: 0.1rem;
        .ul_container {
            width: 90%;
            margin: auto;
            height: 0.42rem;
            line-height: 0.42rem;
            font-size: 0.16rem;
            font-weight: 400;
            color:#333333;
            @include clearfix;
        }
            a{
                color: #999999;
            }
             #inputright {
            text-align: right;
            float: right;
            color: #999999;
            font-size: 0.14rem;
        }
</style>