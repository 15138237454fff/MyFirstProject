<template>
  <!--报道二维码-->
  <div class="er_code">
    <navigation :title="title" />
    <div class="underline"></div>
    <div class="er_code_safe">
      <!--使用qrcode自动生成二维码-->
      <div id="qrCode">
        <div id="code"></div>
        <canvas id="canvas"></canvas>
      </div>
      <p>迎新报到时请出示报到二维码</p>
    </div>
  </div>
</template>
<script>
import navigation from "@/components/navigation.vue";
import QRCode from "qrcode";
export default {
  name: "er_code",
  components: {
    navigation,
    QRCode: QRCode
  },
  data() {
    return {
      title: "报道二维码",
      codes: "" //默认二维码中间图片
    };
  },
  methods: {
    useqrcode() {
      var canvas = document.getElementById("canvas");
      QRCode.toCanvas(canvas, this.sfzh.toString(), function(error) {
        console.log(error);
      });
    }
  },
  created() {},
  mounted() {
    this.useqrcode();
  },
  computed: {
    sfzh() {
      return sessionStorage.getItem("sfzh");
    }
  }
};
</script>

<style scoped>
.er_code {
  width: 100%;
  background-color: #ffffff;
}
.underline {
  width: 100%;
  height: 0.1rem;
  background-color: #f5f5f5;
}
.er_code_safe {
  width: 100%;
  padding-top: 1.4rem;
  text-align: center;
}
p {
  width: 100%;
  padding-top: 0.1rem;
  font-size: 0.18rem;
  font-family: SF Pro Text;
  font-weight: 600;
  color: #000000;
}
</style>
