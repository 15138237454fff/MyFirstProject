<template>
  <!--录取通知书-->
  <div class="admission" :style="{ height: bodyHeight + 'px' }">
    <div class="notice">
      <h3>录取通知书</h3>
      <p class="notice_book">{{ xsxm }}同学</p>
      <p class="notice_book">
        &nbsp;&nbsp;&nbsp;欢迎你加入
        <span>浙江工业大学</span>
      </p>
      <p class="notice_book">
        攻读
        <span>硕士研究生</span>&nbsp;&nbsp;,&nbsp;&nbsp;录取信息
      </p>
      <p class="notice_book">如下：</p>
      <div type="text" class="college">{{ szxy }}</div>
      <div type="text" class="professional">{{ szzy }}</div>
      <div class="entrance" @click="test">
        <div class="button">
          <span>预报到入口</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      bodyHeight: "",
      student: {
        username: "", //学生姓名
        xyName: "", //学生所在学院
        lqName: "", //学生所在专业
        ticket: "", //学生的身份号码
        userName: "", //学生的学号
        id: "", //学生的id号
        name: ""
      }
    };
  },
  methods: {
    test() {
      this.$http
        .get("/urlcode/orientation/yxcswj/init?xh=" + this.xh) //判断学生是否已经答过题，若未答过继续答题。若已答过无需再答题
        .then(res => {
          this.data = res.data;
          if (res.data.data == 0) {
            this.$router.push("/moral_test");
          } else {
            this.$router.push("/prediction_channel");
          }
        });
    }
  },
  created() {
    document.title = "录取通知书";
    this.$http
      .get("/urlcode/usermanage/user/login/" + this.sfzh) //根据学生的身份证号码，获取学生的信息
      .then(res => {
        sessionStorage.setItem("xh", res.data.data.userName); //将学生的学号用sessionStroage缓存起来方便各个接口的调用
        localStorage.setItem("token", res.data.data.userToken); //将学生的学号用sessionStroage缓存起来方便各个接口的调用
      });
  },
  mounted() {
    this.bodyHeight = document.documentElement.clientHeight;
  },
  computed: {
    sfzh() {
      return sessionStorage.getItem("sfzh");
    },
    xh() {
      return sessionStorage.getItem("xh");
    },
    xsxm() {
      return sessionStorage.getItem("xsxm");
    },
    szxy() {
      return sessionStorage.getItem("szxy");
    },
    szzy() {
      return sessionStorage.getItem("szzy");
    }
  }
};
</script>
<style scoped>
/* @import url("../../static/css/admission/admission.css"); */
.admission {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: auto;
  background-image: url(../../static/images/admission_bg.png);
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.notice {
  width: 56%;
  margin: 0 auto;
  position: relative;
  overflow: auto;
  padding-top: 1.5rem;
  font-size: 0;
}
.notice h3 {
  font-size: 0.18rem;
  font-weight: 800;
  color: #ffffff;
  width: 100%;
  text-align: center;
}
.notice_book {
  text-align: left;
  font-size: 0.16rem;
  color: #ffffff;
}
.notice_book span {
  color: #d14e4c;
}
.college {
  display: inline-block;
  width: 95%;
  border-radius: 5px;
  height: 0.42rem;
  line-height: 0.42rem;
  color: #666666;
  font-size: 0.16rem;
  background-color: #ffffff;
  text-align: center;
  margin-top: 0.05rem;
}
.professional {
  display: inline-block;
  width: 95%;
  border-radius: 5px;
  height: 0.42rem;
  line-height: 0.42rem;
  color: #666666;
  font-size: 0.16rem;
  background-color: #ffffff;
  text-align: center;
  margin-top: 0.1rem;
}
.entrance {
  width: 100%;
  text-align: center;
  font-size: 0.16rem;
  color: #ffffff;
  margin-top: 0.05rem;
}
.button {
  width: 90%;
  margin: 0 auto;
  height: 0.8rem;
  background-image: url(../../static/images/button.png);
  background-size: 100% 100%;
  background-repeat: no-repeat;
}
.button span {
  position: relative;
  top: 0.3rem;
  font-size: 0.24rem;
}
</style>
