<template>
  <div class="main_header">
    <van-nav-bar title="" left-arrow @click-left="onClickLeft" />
  </div>
</template>
<script>
export default {
  name:'header',
  methods: {
    onClickLeft() {
      this.$router.go(-1)
    }
  }
};
</script>
<style lang="scss" scoped></style>
