<template>
    <div class="progress-box" v-if="progressData.length>0">
        <van-steps direction="vertical" :active="active" active-icon="checked"  active-color="#64A7FF" inactive-icon="checked">
            <van-step v-for="(item,index) in progressData" :key="index">
                <div class="content">
                    <div class="left">{{item.name}}({{item.assignee}})</div>
                    <div class="right">{{item.startTime}}</div>
                </div>
            </van-step>
        </van-steps>
    </div>
</template>
<script>
export default {
    name:'shlc',
    data(){
        return {
            active:0,
            progressData:[]
        }
    },
    methods:{
        getData(){
            this.$http.get('/api/cultivate/pygrpyjhb/hisByLcid',{params:{lcid:this.lcid}})
            .then(res=>{
                this.progressData = res.data.data
                this.active = this.progressData.length - 1
            })
        }
    },
    created(){
        this.getData()
    }
}
</script>
<style lang="scss">
    .progress-box{
        padding:0 5%;
    }
    .van-steps .van-steps__items{
        .van-hairline{
            height:0.6rem!important;
            line-height: 0.6rem;
        }
        // height:0.6rem!important;
        // display: flex;
        // flex-direction: column;
        // align-items: center;
        .van-step__title{
            .content{
                display:flex;
                justify-content: space-between;
                align-items: center;
                .left{
                    font-size:0.15rem;
                    font-weight: 400;
                }
                .right{
                    font-size:0.14rem;
                    color:#999;
                }
            }
        }
        .van-step__circle-container{
            top:40px;
            font-size:20px;
            color:#64A7FF;
        }
        .van-step__line{
            top:48px;
            height: 78%;
        }
    } 
</style>
