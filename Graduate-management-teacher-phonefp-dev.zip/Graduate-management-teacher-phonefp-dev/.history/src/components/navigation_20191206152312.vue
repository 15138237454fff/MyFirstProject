<template>
  <div class="main_header">
    <van-nav-bar title="title" left-arrow @click-left.prevent="goBack" fixed />
  </div>
</template>
<script>
export default {
  name: "na",
  props: { title: "" },
  methods: {
    goBack() {
      this.$router.go(-1);
    }
  }
};
</script>
<style lang="scss" scoped>
.van-nav-bar {
  z-index: 999 !important;
  color: #333;
}
.van-nav-bar__title {
  font-weight: 600;
}
.van-nav-bar .van-icon {
  color: #323233;
  font-weight: 600;
}
</style>
