<template>
<<<<<<< HEAD
    <div>
        <van-steps direction="vertical" :active="active" active-icon="success" active-color="#38f">
            <van-step>
                <h3>【城市】物流状态1</h3>
                <p>2016-07-12 12:40</p>
            </van-step>
            <van-step>
                <h3>【城市】物流状态2</h3>
                <p>2016-07-11 10:00</p>
            </van-step>
            <van-step>
                <h3>快件已发货</h3>
                <p>2016-07-10 09:30</p>
=======
    <div class="progress-box" v-if="progressData.length>0">
        <van-steps direction="vertical" :active="active" active-icon="checked"  active-color="#64A7FF" inactive-icon="checked">
            <van-step v-for="(item,index) in progressData" :key="index">
                <div class="content">
                    <div class="left">{{item.name}}({{item.assignee}})</div>
                    <div class="right">{{item.startTime}}</div>
                </div>
>>>>>>> d4dc1edcf1d2ef70d0ba20e1c6d18680c75a6305
            </van-step>
        </van-steps>
    </div>
</template>
<script>
export default {
    name:'shlc',
    data(){
        return {
<<<<<<< HEAD
            active:1
        }
    }
}
</script>
=======
            active:0,
            progressData:[]
        }
    },
    methods:{
        getData(){
            this.$http.get('/api/cultivate/pygrpyjhb/hisByLcid',{params:{lcid:this.lcid}})
            .then(res=>{
                this.progressData = res.data.data
                this.active = this.progressData.length - 1
            })
        }
    },
    created(){
        this.getData()
    }
}
</script>
<style lang="scss">
    .progress-box{
        padding:0 5%;
    }
    .van-steps .van-steps__items{
        .van-hairline{
            height:0.6rem!important;
            line-height: 0.6rem;
        }
        // height:0.6rem!important;
        // display: flex;
        // flex-direction: column;
        // align-items: center;
        .van-step__title{
            .content{
                display:flex;
                justify-content: space-between;
                align-items: center;
                .left{
                    font-size:0.15rem;
                    font-weight: 400;
                }
                .right{
                    font-size:0.14rem;
                    color:#999;
                }
            }
        }
        .van-step__circle-container{
            top:40px;
            font-size:20px;
            color:#64A7FF;
        }
        .van-step__line{
            top:48px;
            height: 78%;
        }
    } 
</style>
>>>>>>> d4dc1edcf1d2ef70d0ba20e1c6d18680c75a6305
