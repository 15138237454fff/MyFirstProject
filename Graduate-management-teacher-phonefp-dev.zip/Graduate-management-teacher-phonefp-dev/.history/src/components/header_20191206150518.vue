<template>
  <div class="main_header">
    <van-nav-bar :title="title" left-arrow @click-left.prevent="goBack" fixed />
  </div>
</template>
<script>
export default {
  name:'header',

  methods: {
    onClickLeft() {
      this.$router.go(-1)
    }
  }
};
</script>
<style lang="scss" scoped>

</style>
