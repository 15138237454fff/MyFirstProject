<template>
  <div class="main_header">
    <van-nav-bar title="标题" left-arrow @click-left="onClickLeft" />
  </div>
</template>
<script>
export default {
  name:'',
  methods: {
    onClickLeft() {
      this.$router.go(-1)
    }
  }
};
</script>
<style lang="scss" scoped></style>
