<template>
  <div>
    <div class="training_plan_bottom">
      <span @click.self="showPopup(2)" class="pass" color="#FF5050">退回</span>
      <span @click.self="showPopup(1)" class="agree" color="#64A7FF">通过</span>
    </div>
    <van-dialog v-model="show" title :showConfirmButton="false" width="100%">
      <div class="body">
        <div class="title">
          <span v-if="type==2">确认退回？</span>
          <span v-if="type==1 || type==0">确认通过？</span>
          <span>请输入审核意见：</span>
        </div>
        <textarea class="advise" v-model="comment"></textarea>
        <div class="footer">
          <span @click="cancle">取消</span>
          <span @click="confirm">确认</span>
        </div>
      </div>
    </van-dialog>
  </div>
</template>
<script>
export default {
  name: "auditSubmit",
  props:{
    dataObj:{
      type: Object,
    },
    routerAdress:{//审核后跳转的地址
      type:String,
    }
  },
  data() {
    return {
      show: false,
      type: "1",
      comment: "",
      loading: true
    };
  },
  methods: {
    showPopup(val) {
      this.type = val;
      this.show = !this.show;
    },
    cancle() {
      this.showPopup();
    },
    confirm() {
      if (this.comment == "") {
        this.$toast("请输入审核意见！");
        return;
      }
      if (this.type == 2) {
        this.back();
      } else if(this.type == 1 || this.type == 0){
        this.saveOrder();
      }
      //  this.$router.push('/studyInfoCheck')
    },
        sumbitAudit () {
      if (this.writeInfo.comment === '') {
        this.$message.warning('请填写审核意见')
        return false
      }
      if (this.writeInfo.check == '1') {
        this.writeInfo.taskId = this.$route.query.taskId
        this.writeInfo.taskKey = this.$route.query.key
        // console.log(this.writeInfo)
        this.$http
          .post('/api/cultivate/activityCultivate/saveOrder', this.writeInfo)
          .then(res => {
            // console.log(res.data)
            if (res.data.code === 200) {
              this.$message.success('提交审核成功')
              this.writeInfo = {
                check: '1',
                type: '0'
              }
              // this.writeInfo.check = '1'
              this.$router.go(-1)
            } else {
              this.$message.error('提交审核失败')
            }
          })
      }
      if (this.writeInfo.check == '2') {
        this.$http
          .post('/api/cultivate/activityCultivate/back', {
            businesskey: this.$route.query.businesskey,
            check: '2',
            comment: this.writeInfo.comment,
            executionId: this.$route.query.executionId,
            processDefinitionId: this.$route.query.processDefinitionId,
            processInstanceId: this.$route.query.lcid,
            taskId: this.$route.query.taskId,
            taskKey: this.$route.query.key,
            name: this.$route.query.name
          })
          .then(res => {
            // console.log(res.data)
            if (res.data.code === 200) {
              this.$message.success('提交审核成功')
              this.writeInfo = {
                check: '1',
                type: '0'
              }
              // this.writeInfo.check = '1'
              this.$router.go(-1)
            } else {
              this.$message.error('提交审核失败')
            }
          })
      }
    }
    saveOrder() {
      let params = {
        checked: this.type,
        comment: this.comment,
        taskId: this.dataObj.taskId,
        taskKey: this.dataObj.taskKey
      };
      console.log(this.dataObj)
      this.$http
        .post("/api/cultivate/activityCultivate/saveOrder", params)
        .then(res => {
          console.log(res, "11111111111");
          if (res.data.code == 200) {
            // console.log('审核成功');
            this.$toast('审核成功');
            this.$router.push(this.routerAdress)
          } else {
            this.$toast(res.message);
          }
          this.show = false;
        })
        .catch(err => {
          this.$toast(err.error);
        });
    },
    back() {
      let params = {
        checked: this.type,
        comment: this.comment,
        executionId: this.dataObj.lcid,
        processDefinitionId: this.dataObj.processDefinitionId,
        processInstanceId: this.dataObj.processInstanceId,
        taskId: this.dataObj.taskId,
        taskKey: this.dataObj.taskKey,
        name: this.dataObj.name
      };
      this.$http
        .post("/api/cultivate/activityCultivate/back", params)
        .then(res => {
          if (res.data.code == 200) {
            this.$toast('审核成功');
            this.$router.push(this.routerAdress)
          } else {
            this.$toast(res.message);
          }
          this.show = false;
        })
        .catch(err => {
          this.$toast(err.error);
        });
    }
  },
  created() {
      console.log(this.$route.query.taskId)
      console.log(this.$route.query.taskKey)
  }
};
</script>
<style lang="scss" scoped>
.training_plan_bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 0.45rem;
  background: #fff;
  display: flex;
  span {
    display: inline-block;
    box-sizing: border-box;
    text-align: center;
    width: 50% !important;
    height: 0.45rem;
    line-height: 0.45rem;
    border: 0;
    border-radius: 0;
    padding: 0;
    margin: 0;
  }
  .back {
    background: #ff5050;
    color: #fff;
  }
  .pass {
    background: #fff;
    color: red;
  }
  .agree {
    background: #64a7ff;
    color: #fff;
  }
  .isShow{
    display: none;
  }
  .isThree{
    background: #ff5050;
    color: #fff;
  }
  .van-button--normal {
    // width:calc(50% - 0.02rem);
    padding: 0;
    margin: 0;
  }
}
.van-dialog {
  border: 0;
  border-radius: 0;
  height: 2.1rem;
  top: calc(100% - 1.05rem);
  .body {
    width: 100%;
    height: 100%;
    padding-top: 0.2rem;
    .title {
      display: flex;
      flex-direction: column;
      span {
        font-size: 0.14rem;
        font-weight: 400;
        line-height: 0.2rem;
        margin-bottom: 0.05rem;
        margin-left: 0.15rem;
      }
    }
    .advise {
      width: calc(100% - 0.3rem);
      height: 0.8rem;
      margin-left: 0.15rem;
      margin-bottom: 0.16rem;
    }
    .footer {
      width: 100%;
      height: 0.4rem;
      display: flex;
      span {
        display: inline-block;
        width: 50%;
        box-sizing: border-box;
        border: 1px solid #ccc;
        line-height: 0.4rem;
        text-align: center;
        color: #2779e3;
      }
    }
  }
}
</style>