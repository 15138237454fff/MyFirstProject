<template>
  <div class="main_header">
    <van-nav-bar title="标题" left-arrow @click-left="onClickLeft" />
  </div>
</template>
<script>
export default {
  methods: {
    onClickLeft() {
      this.$touter.go
    },
    onClickRight() {
      Toast("按钮");
    }
  }
};
</script>
<style lang="scss" scoped></style>
