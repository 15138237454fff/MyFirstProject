import Vue from 'vue'
import Router from 'vue-router'
import store from '../store'
import index from '@/component/login'//
import index from '@/views/login'//登录
import homepage from '@/views/homepage'//主页面
import forgotPassword from '@/views/forgotPsd/forgotPassword'//忘记密码
import reset from '@/views/forgotPsd/reset'//重置密码
import announcements from '@/views/homePage/tzgg/announcements'//通知公告
import announcements_details from '@/views/homePage/tzgg/announcements_details'//通知公告详情
import message_center from '@/views/homePage/xxzx/message_center'//消息中心
import toDothings from '@/views/homePage/dbsx/toDothings'//待办事项
import personal_center from '@/views/homePage/grzx/personal_center'//个人中心
import change_password from '@/views/homePage/grzx/change_password'//修改密码
import studyInfoView from '@/views/studyinfo/studyInfoView/index'
import stuInfoDetails from '@/views/studyinfo/studyInfoView/stuInfoDetails'
import studyInfoCheck from '@/views/studyinfo/studyInfoCheck/index'
import studyInfoCheckDetail from '@/views/studyinfo/studyInfoCheck/studyInfoDetail'
import pyjhsh from '@/views/jxpygl/pyjhsh/index'
import pyjhshDetail from '@/views/jxpygl/pyjhsh/detail'
import studentAchievement from '@/views/jxpygl/xscj/studentAchievement'
import schedule from '@/views/jxpygl/wdkb/schedule'
import pyjhcx from '@/views/jxpygl/pyjhcx/index'
import pyjhcxDetail from '@/views/jxpygl/pyjhcx/detail'
import xwlwsh from '@/views/xwgl/xwlwsh/index'
import xwlwshDetail from '@/views/xwgl/xwlwsh/detail'
import xwzgshDetail from '@/views/xwgl/xwzgsh/detail'
import xwzgsh from '@/views/xwgl/xwzgsh/index'
import xmsb from '@/views/jyjsxm/xmsb/index'
import xmsbDetail from '@/views/jyjsxm/xmsb/detail'
import wdxm from '@/views/jyjsxm/wdxm'
import xmjt from '@/views/jyjsxm/xmjt'
import xscgcx from '@/views/xscggl/xscgcx'
Vue.use(Router)

const router = new Router({
    mode: "history",
    routes: [{
            path: '/',
            name: 'index',
            component: index,
            meta: {
                title: '登录页',
                requireAuth: true
            }
        },
        {
            path: '/homepage',
            name: 'homepage',
            component: homepage,
            meta: {
                title: '主页',
                requireAuth: true
            }
        },
        {
            path: '/forgotPassword',
            name: 'forgotPassword',
            component: forgotPassword,
            meta: {
                title: '忘记密码',
                requireAuth: true
            }
        },
        {
            path: '/reset',
            name: 'reset',
            component: reset,
            meta: {
                title: '重置密码',
                requireAuth: true
            }
        },
        {
            path: '/announcements',
            name: 'announcements',
            component: announcements,
            meta: {
                title: '通知公告列表',
                requireAuth: true
            }
        },
        {
            path: '/announcements_details',
            name: 'announcements_details',
            component: announcements_details,
            meta: {
                title: '通知公告详情',
                requireAuth: true
            }
        },
        {
            path: '/message_center',
            name: 'message_center',
            component: message_center,
            meta: {
                title: '消息中心',
                requireAuth: true
            }
        },
        {
            path: '/personal_center',
            name: 'personal_center',
            component: personal_center,
            meta: {
                title: '个人中心',
                requireAuth: true
            }
        },
        {
            path: '/change_password',
            name: 'change_password',
            component: change_password,
            meta: {
                title: '修改密码',
                requireAuth: true
            }
        },
        {
            path: '/toDothings',
            name: 'toDothings',
            component: toDothings,
            meta: {
                title: '待办事项',
                requireAuth: true
            }
        },
        {
            path: '/studyInfoView',
            name: 'studyInfoView',
            component: studyInfoView,
            meta: {
                title: '学生信息查看'
            }
        },
        {
            path: '/stuInfoDetails',
            name: 'stuInfoDetails',
            component: stuInfoDetails,
            meta: {
                title: '学生信息详情'
            }
        },
        {
            path: '/studyInfoCheck',
            name: 'studyInfoCheck',
            component: studyInfoCheck,
            meta: {
                title: '学生信息审核'
            }
        },
        {
            path: '/studyInfoCheckDetail',
            name: 'studyInfoCheckDetail',
            component: studyInfoCheckDetail,
            meta: {
                title: '学生信息审核详情',
                requireAuth: true
            }
        },
        {
            path: '/pyjhsh',
            name: 'pyjhsh',
            component: pyjhsh,
            meta: {
                title: '培养计划审核',
                requireAuth: true
            }
        },
        {
            path: '/pyjhshDetail',
            name: 'pyjhshDetail',
            component: pyjhshDetail,
            meta: {
                title: '培养计划审核详情',
                requireAuth: true
            }
        },
        {
            path: '/schedule',
            name: 'schedule',
            component: schedule,
            meta: {
                title: '我的课表',
                requireAuth: true
            }
        },
        {
            path: '/pyjhcx',
            name: 'pyjhcx',
            component: pyjhcx,
            meta: {
                title: '培养计划查询',
                requireAuth: true
            }
        },
        {
            path: '/studentAchievement',
            name: 'studentAchievement',
            component: studentAchievement,
            meta: {
                title: '学生成绩',
                requireAuth: true
            }
        },
        {
            path: '/pyjhcxDetail',
            name: 'pyjhcxDetail',
            component: pyjhcxDetail,
            meta: {
                title: '培养计划审核详情',
                requireAuth: true
            }
        },
        {
            path: '/xwlwsh',
            name: 'xwlwsh',
            component: xwlwsh,
            meta: {
                title: '学位论文审核',
                requireAuth: true
            }
        },
        {
            path: '/xwlwshDetail',
            name: 'xwlwshDetail',
            component: xwlwshDetail,
            meta: {
                title: '学位论文审核详情',
                requireAuth: true
            }
        },
        {
            path: '/xwzgsh',
            name: 'xwzgsh',
            component: xwzgsh,
            meta: {
                title: '学位终稿审核',
                requireAuth: true
            }
        },
        {
            path: '/xwzgshDetail',
            name: 'xwzgshDetail',
            component: xwzgshDetail,
            meta: {
                title: '学位终稿审核详情',
                requireAuth: true
            }
        },
        {
            path: '/xmsb',
            name: 'xmsb',
            component: xmsb,
            meta: {
                title: '项目申报',
                requireAuth: true
            }
        },
        {
            path: '/xmsbDetail',
            name: 'xmsbDetail',
            component: xmsbDetail,
            meta: {
                title: '项目要求',
                requireAuth: true
            }
        },
        {
            path: '/wdxm',
            name: 'wdxm',
            component: wdxm,
            meta: {
                title: '我的项目',
                requireAuth: true
            }
        },
        {
            path: '/xmjt',
            name: 'xmjt',
            component: xmjt,
            meta: {
                title: '项目结题',
                requireAuth: true
            }
        },
        {
            path: '/xscgcx',
            name: 'xscgcx',
            component: xscgcx,
            meta: {
                title: '学术成果查询',
                requireAuth: true
            }
        },
        {
            path: '*',
            redirect: "/",
        }
    ]
})
router.beforeEach((to, from, next) => {
    if (to.path !== '/' && !store.getters.getXH) {
        next('/')
    } else {
        next()
    }
})
export default router
