// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import rem from '@/utils/rem.js'
import { Indicator } from 'mint-ui'
import 'mint-ui/lib/style.css'
import store from './store' //引入配置好的vuex
import Vant, { Toast } from 'vant'
import 'vant/lib/index.css'
import axios from 'axios'
import * as filters from './utils/filter.js' // global filters

Vue.component(Indicator)
    // 解决移动端300s延迟
import fastclick from "fastclick";
fastclick.attach(document.body);

Vue.use(Vant)
Vue.prototype.$http = axios

Object.keys(filters).forEach(key => {
    Vue.filter(key, filters[key])
})
axios.defaults.timeout = 50000;
axios.defaults.baseURL = "";
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
axios.interceptors.request.use((config) => {
    let token = store.state.userLoginMsg.userToken; //加入全局的token验证
    if (token != null) {
        config.headers['userToken'] = token;
    }
    // Indicator.open({
    //     text: "加载中...",
    //     spinnerType: "fading-circle"
    // });
    return config;
}, (error) => {
    Toast('请求超时')
    return Promise.reject(error);
});
axios.interceptors.response.use((response) => {
    // Indicator.close();
    return response;
}, (error) => {
    // Indicator.close();
    if (error.response.status == 401) {
        // this.$toast('重新登录')
        router.push({
            path: '/'
        });
    }
    return Promise.reject(error);
});


Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    rem,
    store,
    components: { App },
    template: '<App/>'
})