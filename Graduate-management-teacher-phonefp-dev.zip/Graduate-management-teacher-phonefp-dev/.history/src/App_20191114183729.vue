<template>
  <div id="app">
    <transition name="slide-fade" mode="out-in">
      <!-- <keep-alive> -->
        <router-view></router-view>
      <!-- </keep-alive> -->
    </transition>
    <!-- <footer-bar class="footer"></footer-bar> -->
  </div>
</template>

<script>
export default {
  name: "App"
};
</script>

<style>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  list-style: none;
  text-decoration: none;
}
html,body {
  width: 100%;
  height: 100%;
}
#app {
  width: 100%;
  height: 100%;
}
a {
  text-decoration: none;
}

input {
  outline: none;
  border: 0;
}

button {
  outline: none;
  border: 0;
}
select {
  outline: none;
  border: 0;
}
.slide-fade-enter-active {
  transition: all 0.2s ease;
}
.slide-fade-leave-active {
  transition: all 0.2s cubic-bezier(1, 0.5, 0.8, 1);
}
.slide-fade-enter,
    .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */
 {
  /* transform: translateX(2px); */
  opacity: 0;
}
.mint-indicator{
  font-size: 0 !important
}
</style>
