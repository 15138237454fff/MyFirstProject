import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '@/views/index.vue';
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'index',
    component: Index,
    redirect: '/home',
    children: [
      {
        path: "/home",
        name: "home",
        component: () => import("@/views/home.vue")
      },
      {
        path: "/listPage",
        name: "listPage",
        component: () => import("@/views/listPage.vue"),
        props: true
      },
      {
        path: "/teacherDetail/:id",
        name: "teacherDetail",
        component: () => import("@/views/teacherDetail.vue"),
        props: true
      },
    ]
  },
  {
    path: "/phoneDetail",
    name: "phoneDetail",
    component: () => import("@/views/phoneDetail.vue"),
  },
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})

export default router
