import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios';
import ViewUI from 'view-design';
import 'view-design/dist/styles/iview.css';
import '@babel/polyfill';
// 如果请求超过5s认为超时
axios.defaults.timeout = 5000;
Vue.prototype.$axios = axios;
// 公共方法
import baseMethod from './global/baseMethod';
// 单独全局加载message组件
import { Message } from 'view-design';

Vue.config.productionTip = false
Vue.use(ViewUI);
Vue.use(baseMethod);
const SUCCESS_CODE = 10000,
  NOLOGIN = 20001,
  FORCED_OFF = 20009,
  msgRelay = 2000
// 添加一个响应拦截器
axios.interceptors.response.use(
  response => {
    let err = {};
    let data = response.data;
    // 如果是直接返回的数据，没有状态码
    if (data.code === undefined) {
      return response;
    }
    switch (data.code) {
      // 成功
      case SUCCESS_CODE:
        return response;
      // 未登录
      case NOLOGIN:
        baseMethod.debounce(() => { Message.error(data.msg) }, msgRelay);
        err.message = data.msg;
        store.commit('skb/updateLogin', false);
        return Promise.reject(err);
      // 强制下线
      case FORCED_OFF:
        baseMethod.debounce(() => { Message.error(data.msg) }, msgRelay);
        err.message = data.msg;
        store.commit('skb/updateLogin', false);
        return Promise.reject(err);
      // 其他错误
      default:
        baseMethod.debounce(() => {
          Message.error(data.msg)
        }, msgRelay);
        err.message = data.msg;
        return Promise.reject(err);
    }
  },
  err => {
    if (err && err.response) {
      err.message = err.response.data.msg;
    } else {
      err.message = "请求超时";
    }
    baseMethod.debounce(() => { Message.error(err.message) }, msgRelay);
    return Promise.reject(err);
  }
);

new Vue({
  router,
  store,
  axios,
  render: h => h(App)
}).$mount('#app')
