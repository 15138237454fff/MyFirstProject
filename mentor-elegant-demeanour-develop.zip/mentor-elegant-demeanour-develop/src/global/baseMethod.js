export default {
  install(Vue) {
    // 验证数据是否为空
    Vue.prototype.$isEmpty = function (value) {
      // 判断字符串是否为空
      switch (typeof value) {
        case "undefined":
          return true
        case "boolean":
          return false
        case "string":
          return value === ""
        case "number":
          return isNaN(value)
        case "object":
          // 数组
          if (Array.isArray(value)) {
            return value.length === 0
          } else {
            // null
            if (value === null) {
              return true
            }
            // 其他对象统一不认为为空
            if (Object.prototype.toString.call(value) !== "[object Object]") {
              return false
            }
            // 普通对象如果可枚举属性为空认为该对象为空
            return Object.keys(value).length === 0
          }
        default:
          console.error("未知")
          return true
      }
    };
    // 转换字符
    Vue.prototype.$replaceAllStr = function (value, regexp, substr) {
      if (this.$isEmpty(value)) {
        return '';
      }
      return value.replace(new RegExp(regexp, 'gm'), substr);
    };
    // 根据value从List中获取对应label值
    Vue.prototype.$getListValue = function (value, list) {
      // 对象数组的类型不是数组
      if (!Array.isArray(list)) {
        console.error("对应的对象数组格式错误");
        return "";
      }
      let result = list.find(el => value === el.value);
      // 如果找不到对应对象获取对象的label属性为空
      if (!result || !result.label) {
        return "";
      }
      return result.label;
    };
    Vue.prototype.$regSpecial = str => {
      //
      if (typeof str !== 'string') {
        return { value: false, msg: '请传入一个字符串类型数据' };
      }
      if (str === "") {
        return { value: false, msg: '请传入非空数据' };
      }
      let regEn = /[`~!@#$%^&*()_+<>?:"{},./;'[\]]/im,
        regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;
      if (regEn.test(str) || regCn.test(str)) {
        return { value: false, msg: '包含特殊字符' };
      } else {
        return { value: true, msg: '验证成功' };
      }
    };
    // 数组去重
    Vue.prototype.$removal = arr => {
      if (!Array.isArray(arr)) {
        return arr
      }
      return Array.from(new Set(arr))
    }
    // 时间段查询时截至时间增加到当天23：59：59
    Vue.prototype.$endTime = endTime => {
      if (endTime) {
        endTime = Vue.prototype.$tagTime(endTime, "yyyy-MM-dd") + " " + "23:59:59";
      }
      return new Date(endTime);
    }
    Vue.prototype.$debounce = (() => {
      let lastTime = new Date()
      return (callback, wait) => {
        let currentTime = new Date()
        let remaining = currentTime - lastTime - wait
        if (remaining >= 0) {
          callback()
          lastTime = currentTime
        }
      }
    })()
    /**
     * time 时间对象
     * tag 传入想要得到的时间格式 yyyy-MM-dd HH-mm-ss
     */
    Vue.prototype.$tagTime = (time, tag) => {
      if (!tag) {
        return ""
      }
      if (!time) {
        return ""
      }
      let tmpTime = new Date(time)
      if (isNaN(tmpTime)) {
        return ""
      }
      let year = tmpTime.getFullYear(),
        month = tmpTime.getMonth() + 1,
        date = tmpTime.getDate(),
        hour = tmpTime.getHours(),
        minute = tmpTime.getMinutes(),
        second = tmpTime.getSeconds()
      // 不足10前面补0
      if (month < 10) {
        month = "0" + month
      }
      // 不足10前面补0
      if (date < 10) {
        date = "0" + date
      }
      // 不足10前面补0
      if (hour < 10) {
        hour = "0" + hour
      }
      // 不足10前面补0
      if (minute < 10) {
        minute = "0" + minute
      }
      // 不足10前面补0
      if (second < 10) {
        second = "0" + second
      }
      return tag.replace("yyyy", year).replace("MM", month).replace("dd", date).replace("HH", hour).replace("mm", minute).replace("ss", second)
    },
      Vue.prototype.$splicing = (tag, ...arr) => {
        arr = arr.filter(el => el)
        return arr.join(tag)
      }
    Vue.prototype.$isPC = () => {
      let userAgentInfo = navigator.userAgent,
        Agents = ["Android", "iPhone",
          "SymbianOS", "Windows Phone",],
        flag = true;
      for (let v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
          flag = false;
          break;
        }
      }
      return flag;
    }
  },
  // 防抖
  debounce: (() => {
    let lastTime = new Date()
    return (callback, wait) => {
      let currentTime = new Date()
      let remaining = currentTime - lastTime - wait
      if (remaining >= 0) {
        callback()
        lastTime = currentTime
      }
    }
  })()
};
