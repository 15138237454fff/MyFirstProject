import Vue from 'vue'
import Vuex from 'vuex'
import axios from "axios"

Vue.use(Vuex)
export default new Vuex.Store({
  state: {
    manAvatar: "man.png",
    womanAvatar: "woman.png",
    defaultAvatar: "default.png",
    year: new Date().getFullYear()
  },
  getters: {
    getManAvatar(state) {
      return state.manAvatar
    },
    getWomanAvatar(state) {
      return state.womanAvatar
    },
    getDefaultAvatar(state) {
      return state.defaultAvatar
    },
    getCurrentYear(state) {
      return state.year
    }
  },
  mutations: {
    updateCurrentYear(state, value) {
      state.year = value
    }
  },
  actions: {
    requireCurrentYear({ commit }) {
      axios.get("/api/teacher/year")
        .then(res => {
          let data = res.data.data
          console.log(data)
          commit("updateCurrentYear", data)
        })
        .catch(err => {
          console.log(err.message)
        })
    }
  },
})
