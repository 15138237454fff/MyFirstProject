<template>
  <div class="listPage">
    <my-header></my-header>
    <div class="list-page-content">
      <div class="left">
        <div>
          <div class="title">
            高级搜索
          </div>
          <div>
            <Poptip
              title="Title"
              content="content"
              placement="right"
              v-model="xmPoptip"
              @on-popper-show="handleShowPop('xm')"
            >
              <div class="query-item cursor-pointer">
                <div>
                  <span style="margin-right:0.5vw">姓名</span>
                  <Tag
                    v-if="formData.xm"
                    closable
                    @on-close="handleCloseXm"
                    size="large"
                    :transfer="true"
                  >
                    {{ formData.xm }}
                  </Tag>
                </div>
                <Icon type="ios-arrow-forward" />
              </div>
              <div slot="title"></div>
              <div slot="content">
                <Input
                  placeholder="请输入姓名"
                  v-model="tmpData.xm"
                  style="margin-right:5px;width:200px"
                  ref="xm"
                  @on-enter="clickInputXm"
                />
                <Button type="primary" @click="clickInputXm">确定</Button>
              </div>
            </Poptip>
            <Poptip
              title="Title"
              content="content"
              placement="right"
              v-model="xyPoptip"
            >
              <div class="query-item cursor-pointer">
                <div>
                  <span style="margin-right:5px">学院</span>
                  <Tag
                    v-if="formData.xy"
                    closable
                    @on-close="handleCloseXy"
                    size="large"
                  >
                    {{ formData.xy }}
                  </Tag>
                </div>
                <Icon type="ios-arrow-forward" />
              </div>
              <div slot="title"></div>
              <div slot="content">
                <i-select
                  v-model="tmpData.xy"
                  size="large"
                  filterable
                  placeholder="请选择培养学院"
                  style="margin-right:5px;width:200px !important"
                  ref="xy"
                  @keyup.enter.native="clickInputXy"
                >
                  <i-option
                    v-for="(item, index) of xyList"
                    :key="index"
                    :value="item.label"
                    >{{ item.label }}</i-option
                  >
                </i-select>
                <Button type="primary" @click="clickInputXy">确定</Button>
              </div>
            </Poptip>
            <Poptip
              title="Title"
              content="content"
              placement="right"
              v-model="zyPoptip"
            >
              <div class="query-item cursor-pointer">
                <div>
                  <span style="margin-right:5px">学科专业</span>
                  <Tag
                    v-if="formData.zy"
                    closable
                    @on-close="handleCloseZy"
                    size="large"
                  >
                    {{ formData.zy }}
                  </Tag>
                </div>
                <Icon type="ios-arrow-forward" />
              </div>
              <div slot="title"></div>
              <div slot="content">
                <i-select
                  v-model="tmpData.zy"
                  size="large"
                  filterable
                  placeholder="请选择学科专业"
                  style="margin-right:5px;width:200px !important"
                  @keyup.enter.native="clickInputZy"
                  ref="zy"
                >
                  <i-option
                    v-for="(item, index) of zyList"
                    :key="index"
                    :value="item.label"
                    >{{ `${item.value} ${item.label}` }}</i-option
                  >
                </i-select>
                <Button type="primary" @click="clickInputZy">确定</Button>
              </div>
            </Poptip>
            <Poptip
              title="Title"
              content="content"
              placement="right"
              v-model="yjfxPoptip"
              @on-popper-show="handleShowPop('yjfx')"
            >
              <div class="query-item cursor-pointer">
                <div>
                  <span style="margin-right:5px">研究方向</span>
                  <Tag
                    v-if="formData.yjfx"
                    closable
                    @on-close="handleCloseYjfx"
                    size="large"
                  >
                    {{ formData.yjfx }}
                  </Tag>
                </div>
                <Icon type="ios-arrow-forward" />
              </div>
              <div slot="title"></div>
              <div slot="content">
                <Input
                  placeholder="请输入研究方向"
                  v-model="tmpData.yjfx"
                  style="margin-right:5px;width:200px"
                  @on-enter="clickInputYjfx"
                  ref="yjfx"
                />
                <Button type="primary" @click="clickInputYjfx">确定</Button>
              </div>
            </Poptip>
          </div>
        </div>
        <div>
          <RadioGroup
            v-model="formData.range"
            type="button"
            size="large"
            @on-change="initLoadTable"
          >
            <Radio :label="1">只显示校内导师</Radio>
            <Radio :label="2">只显示校外导师</Radio>
          </RadioGroup>
          <Checkbox
            v-model="formData.check"
            @on-change="initLoadTable"
            :true-value="1"
            :false-value="0"
            >{{ $store.getters.getCurrentYear }}年度招生资格</Checkbox
          >
        </div>
      </div>
      <div class="right" @mousewheel="hualun" ref="list">
        <teacher-card
          v-for="(item, index) of tableData"
          :key="index"
          v-bind="item"
          class="cursor-pointer"
          @click.native="clickDetail(item.id)"
        ></teacher-card>
        <div v-if="allLoaded"></div>
        <Spin size="large" v-if="allLoaded" style="width:100%">
          已经全部加载完成
        </Spin>
        <Spin size="large" v-if="loading" style="width:100%">
          <Icon type="ios-loading" size="18" class="demo-spin-icon-load"></Icon>
          <div>加载中</div>
        </Spin>
      </div>
      <Button
        type="primary"
        @click="loadMore"
        class="load-more"
        :disabled="allLoaded"
        >加载更多</Button
      >
    </div>
  </div>
</template>
<script>
import myHeader from "@/components/myHeader.vue";
import teacherCard from "@/components/teacherCard.vue";
export default {
  name: "listPage",
  props: {
    xy: {},
    zy: {},
    check: {}
  },
  components: {
    "my-header": myHeader,
    "teacher-card": teacherCard
  },
  data() {
    return {
      tableData: [],
      formData: {
        xm: "",
        xy: "",
        zy: "",
        yjfx: "",
        check: 0,
        range: 1
      },
      limitQuery: {
        pageNum: 1,
        pageSize: 12
      },
      xyList: [],
      zyList: [],
      allLoaded: false,
      loading: false,
      xmPoptip: false,
      xyPoptip: false,
      zyPoptip: false,
      yjfxPoptip: false,
      tmpData: {
        xm: "",
        zy: "",
        xy: "",
        yjfx: ""
      }
    };
  },
  mounted() {
    if (this.xy !== undefined) {
      this.formData.xy = this.xy;
      this.formData.zy = this.zy;
      this.formData.check = this.check;
    }
    this.requireXyList();
    this.requireZyList();
    this.loadTable();
  },
  methods: {
    hualun() {
      console.log("allLoaded:" + this.allLoaded);
      if (this.allLoaded) {
        return;
      }
      if (this.loading) {
        return;
      }
      // 获取距离元素底部距离
      // let deltaY = $event.height - $event.deltaY;
      let element = this.$refs.list,
        height = element.offsetHeight,
        scrollTop = element.scrollTop,
        scrollHeight = element.scrollHeight;
      if (scrollTop === 0) {
        return;
      }
      if (scrollHeight - scrollTop < height + 50) {
        this.$debounce(() => {
          this.loadMore();
        }, 2000);
      }
    },
    loadMore() {
      this.limitQuery.pageNum++;
      this.loadTable();
    },
    clickDetail(id) {
      // this.$router.push(`/teacherDetail/${id}`);
      let routes = this.$router.resolve({
        path: `/teacherDetail/${id}`
      });
      window.open(routes.href, "_blank");
    },
    loadTable() {
      console.log("获取列表");
      let { xm, xy, zy, yjfx, check, range } = this.formData,
        { pageNum, pageSize } = this.limitQuery,
        tmpObj = {
          attribute: range,
          collegeCode: xy,
          majorCode: zy,
          pageNum,
          pageSize,
          recruit: check,
          research: yjfx,
          query: xm
        };
      this.loading = true;
      this.$axios
        .post("/api/teacher/list", tmpObj)
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          if (!Array.isArray(data.list)) {
            this.$Message.error("教师列表数据获取失败");
            return;
          }
          if (data.list.length < this.limitQuery.pageSize) {
            this.allLoaded = true;
          }
          this.tableData = this.tableData.concat(data.list);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.tableData = [];
      this.allLoaded = false;
      this.loadTable();
    },
    requireXyList() {
      this.$axios
        .get("/api/department/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            this.$Message.error("获取学院列表失败");
            return;
          }
          this.xyList = data;
        })
        .catch(err => {
          console.log(err.message);
        });
    },
    requireZyList() {
      this.$axios
        .get("/api/department/major/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            this.$Message.error("获取专业列表失败");
            return;
          }
          console.log(data);
          this.zyList = data;
        })
        .catch(err => {
          console.log(err.message);
        });
    },
    clickInputXm() {
      this.formData.xm = this.tmpData.xm;
      this.initLoadTable();
      this.clearTmpData();
      this.xmPoptip = false;
    },
    clickInputXy() {
      this.formData.xy = this.tmpData.xy;
      this.initLoadTable();
      this.clearTmpData();
      this.xyPoptip = false;
    },
    clickInputZy() {
      this.formData.zy = this.tmpData.zy;
      this.initLoadTable();
      this.clearTmpData();
      this.zyPoptip = false;
    },
    clickInputYjfx() {
      this.formData.yjfx = this.tmpData.yjfx;
      this.initLoadTable();
      this.clearTmpData();
      this.yjfxPoptip = false;
    },
    handleCloseXm() {
      this.formData.xm = "";
      this.initLoadTable();
    },
    handleCloseXy() {
      this.formData.xy = "";
      this.formData.zy = "";
      this.initLoadTable();
    },
    handleCloseZy() {
      this.formData.zy = "";
      this.initLoadTable();
    },
    handleCloseYjfx() {
      this.formData.yjfx = "";
      this.initLoadTable();
    },
    handleShowPop(name) {
      console.log(name);
      this.$nextTick(() => {
        this.$refs[name].focus();
      });
    },
    clearTmpData() {
      this.tmpData = {
        xm: "",
        zy: "",
        xy: "",
        yjfx: ""
      };
    }
  }
  // computed: {
  //   zyList() {
  //     let tmpObj = this.xyList.find(el => {
  //       return el.label === this.formData.xy;
  //     });
  //     if (tmpObj) {
  //       return tmpObj.children;
  //     } else {
  //       return [];
  //     }
  //   }
  // }
};
</script>
<style lang="scss" scoped>
.listPage {
  display: flex;
  flex-direction: column;
  .list-page-content {
    height: 76vh;
    background: #f0f2f5;
    padding: 3vh $left-padding;
    padding-right: 8vw;
    display: flex;
    justify-content: space-between;
    .left {
      box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
      background: #fff;
      color: #023364;
      width: 24vw;
      height: 100%;
      padding: 2vw;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      margin-right: 2vw;
      .title {
        font-weight: bold;
        font-family: Segoe UI;
        font-size: 2vw;
        text-align: center;
        border-bottom: 1px solid #cccccc;
        padding-bottom: 2vh;
      }
      .ivu-poptip {
        width: 100%;
        /deep/ .ivu-poptip-rel {
          width: 100%;
        }
        /deep/ .ivu-poptip-title {
          display: none;
        }
      }
      .query-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 10vh;
        line-height: 10vh;
        border-bottom: 1px solid #cccccc;
        font-size: 1vw;
        .ivu-icon {
          color: #cccccc;
          line-height: 10vh;
        }
      }
      .ivu-radio-group-button .ivu-radio-wrapper {
        font-size: 1vw;
        padding: 0 0.8vw;
        height: 5vh;
        line-height: 5vh;
      }
      .ivu-checkbox-wrapper {
        font-size: 1vw;
        margin-top: 2vh;
        color: #666666;
        /deep/ .ivu-checkbox {
          margin-right: 5px;
        }
      }
      // /deep/ .ivu-select-dropdown {
      //   max-height: 100vh;
      // }
    }
    .right {
      position: relative;
      flex: 1;
      height: 100%;
      overflow-y: auto;
      flex-wrap: wrap;
      display: flex;
      margin-bottom: -24px;
      & > div {
        margin-bottom: 24px;
      }
      /deep/ .ivu-spin-main {
        display: flex;
        justify-content: center;
      }
    }
    .load-more.ivu-btn {
      position: absolute;
      bottom: 80px;
      right: 20px;
    }
  }
}
.myHeader {
  padding: 0 $left-padding;
  margin: 0;
  background: #023364;
  /deep/ .logo {
    height: 14vh;
    img {
      height: 100%;
    }
  }
}
</style>
