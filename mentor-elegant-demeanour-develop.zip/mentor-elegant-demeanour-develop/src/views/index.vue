<template>
  <div class="index">
    <div class="index-content">
      <router-view></router-view>
    </div>
    <my-footer></my-footer>
  </div>
</template>
<script>
import myFooter from "@/components/myFooter.vue";
export default {
  name: "index",
  data() {
    return {};
  },
  components: {
    "my-footer": myFooter
  },
  mounted() {
    this.$store.dispatch("requireCurrentYear");
  },
  methods: {}
};
</script>
<style lang="scss" scoped>
.index {
  display: flex;
  flex-direction: column;
  height: 100%;
  .index-content {
    flex: 1;
  }
}
</style>
