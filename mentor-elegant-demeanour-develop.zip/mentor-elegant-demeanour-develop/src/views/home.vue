<template>
  <div class="home clear">
    <my-header></my-header>
    <div class="select-box">
      <i-select
        v-model="formData.xy"
        size="large"
        placeholder="请选择培养学院"
        filterable
      >
        <i-option
          v-for="(item, index) of xyList"
          :key="index"
          :value="item.label"
          >{{ item.label }}</i-option
        >
      </i-select>
      <i-select
        v-model="formData.zy"
        size="large"
        placeholder="请选择学科专业"
        filterable
      >
        <i-option
          v-for="(item, index) of zyList"
          :key="index"
          :value="item.label"
          >{{ `${item.value} ${item.label}` }}</i-option
        >
      </i-select>
      <i-button size="large" @click="clickSearch">
        搜索
        <Icon type="ios-search" />
      </i-button>
    </div>
    <div class="check-box">
      <Checkbox v-model="formData.check" :true-value="1" :false-value="0"
        >{{ $store.getters.getCurrentYear }}年度招生资格</Checkbox
      >
    </div>
  </div>
</template>
<script>
import myHeader from "@/components/myHeader.vue";
export default {
  name: "home",
  components: {
    "my-header": myHeader
  },
  data() {
    return {
      xyList: [],
      year: new Date().getFullYear(),
      // zyList: [],
      formData: {
        xy: null,
        zy: null,
        check: 0
      }
    };
  },
  mounted() {
    this.requireXyList();
    // this.requireZyList();
  },
  methods: {
    clickSearch() {
      console.log("搜索");
      this.$router.push({ name: "listPage", params: this.formData });
    },
    requireXyList() {
      this.$axios
        .get("/api/department/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            this.$Message.error("获取学院列表失败");
            return;
          }
          this.xyList = data;
        })
        .catch(err => {
          console.log(err.message);
        });
    }
    // requireZyList() {
    //   this.$axios
    //     .get("/api/department/major/select")
    //     .then(res => {
    //       let data = res.data.data;
    //       if (!Array.isArray(data)) {
    //         this.$Message.error("获取专业列表失败");
    //         return;
    //       }
    //       console.log(data);
    //       this.zyList = data;
    //     })
    //     .catch(err => {
    //       console.log(err.message);
    //     });
    // }
  },
  computed: {
    zyList() {
      let tmpObj = this.xyList.find(el => {
        return el.label === this.formData.xy;
      });
      if (tmpObj) {
        return tmpObj.children;
      } else {
        return [];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
$height: 8vh;
$padding-left: 4vh;
.home {
  height: 100%;
  background: url("../assets/bg.png") no-repeat;
  background-size: cover;
  position: relative;
  .select-box {
    margin-top: 12vh;
    margin-left: 21vw;
    .ivu-select {
      width: 26vw !important;
      height: $height;
      text-align: left;
    }
    /deep/ .ivu-select-large.ivu-select-single .ivu-select-selection {
      height: $height;
      & > div {
        height: $height;
        line-height: $height;
      }
      .ivu-select-placeholder {
        height: $height;
        line-height: $height;
        padding-left: $padding-left;
      }
      .ivu-select-input {
        top: 0;
      }
      .ivu-select-arrow {
        font-size: 1.5vw;
        top: 53%;
      }
      .ivu-select-input {
        padding-left: $padding-left;
      }
      .ivu-select-selected-value {
        height: $height;
        line-height: $height;
        padding-left: $padding-left;
      }
    }
    .ivu-btn {
      width: 8vw;
      height: $height;
      font-size: 1.5vw;
      font-weight: bold;
      background: #ffcc00;
      &:hover {
        color: #333;
        background: #ffcc00;
        border-color: #ffcc00;
      }
    }
  }
  .check-box {
    margin-top: 1.3vw;
    margin-left: 21vw;
    .ivu-checkbox-wrapper {
      font-size: 1.2vw;
      color: #333;
      /deep/ .ivu-checkbox {
        margin-right: 0.5vw;
      }
    }
  }
  .myHeader {
    margin: 4vw 5vw 0 5vw;
    /deep/ .logo {
      height: 20vh;
      img {
        height: 100%;
      }
    }
  }
}
</style>
