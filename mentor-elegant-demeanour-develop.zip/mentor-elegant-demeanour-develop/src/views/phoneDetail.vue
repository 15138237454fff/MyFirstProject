<template>
  <div class="phoneDetail">
    <div class="top">
      <div class="avatar">
        <img :src="'/api' + formData.picture" v-if="formData.picture" />
        <!-- <img :src="sex === '2' ? woman : man" v-else /> -->
        <img :src="defaultPng" v-else />
      </div>
      <div class="right">
        <div class="name">
          <span>{{ formData.name }}</span>
          <Tag color="primary" v-if="formData.degree"
            >{{ formData.degree }}
          </Tag>
          <Icon
            type="md-list-box"
            :size="30"
            @click="modalVisiable = true"
          ></Icon>
          <Modal v-model="modalVisiable" footer-hide>
            <div>
              <Icon type="md-call" />
              <span> 办公电话 ：</span>
              <span>{{ formData.officePhone }}</span>
            </div>
            <div>
              <Icon type="md-phone-portrait" />
              <span> 移动电话 ：</span>
              <span>{{ formData.mobilePhone }}</span>
            </div>
            <div>
              <Icon type="md-mail" />
              <span> 电子邮箱 ：</span>
              <span>{{ formData.emailAddress }}</span>
            </div>
            <div>
              <Icon type="md-pin" />
              <span> 办公地址 ：</span>
              <span>{{ formData.businessAddress }}</span>
            </div>
          </Modal>
        </div>
        <div>
          <span class="zc">{{ formData.title }} </span>
          <span class="green" v-if="formData.recruit === 1">
            |
            <Icon type="md-checkmark-circle" class="green" />{{
              $store.getters.getCurrentYear
            }}年度招生资格
          </span>
        </div>
        <div class="info">
          <div>
            <span
              v-if="
                formData.department !== '' ||
                  formData.college !== '' ||
                  formData.college2 !== ''
              "
              >所在单位 ：</span
            >
            <Tooltip
              :content="
                `${$splicing(
                  ' | ',
                  formData.department,
                  formData.college,
                  formData.college2
                )}`
              "
              v-if="formData.department"
              :transfer="true"
              theme="light"
              placement="bottom-end"
            >
              <span>{{
                $splicing(
                  " | ",
                  formData.department,
                  formData.college,
                  formData.college2
                )
              }}</span>
            </Tooltip>
          </div>
          <div>
            <span
              v-if="
                formData.firstDiscipline1 !== '' ||
                  formData.secondaryDiscipline1 !== '' ||
                  formData.firstDiscipline2 !== '' ||
                  formData.secondaryDiscipline2 !== ''
              "
              >学科专业 ：</span
            >
            <span
              v-if="
                formData.firstDiscipline1 !== '' ||
                  formData.secondaryDiscipline1 !== '' ||
                  formData.firstDiscipline2 !== '' ||
                  formData.secondaryDiscipline2 !== ''
              "
            >
              <Tooltip :transfer="true" placement="bottom-end" theme="light">
                <span
                  >{{
                    $splicing(
                      " | ",
                      formData.firstDiscipline1,
                      formData.secondaryDiscipline1,
                      formData.firstDiscipline2,
                      formData.secondaryDiscipline2
                    )
                  }}
                </span>
                <div slot="content">
                  <span
                    >{{
                      $splicing(
                        " | ",
                        formData.firstDiscipline1,
                        formData.secondaryDiscipline1,
                        formData.firstDiscipline2,
                        formData.secondaryDiscipline2
                      )
                    }}
                  </span>
                </div>
              </Tooltip>
            </span>
          </div>
          <div>
            <span
              v-if="
                formData.researchDirection1 !== '' ||
                  formData.researchDirection2 !== '' ||
                  formData.researchDirection3 !== '' ||
                  formData.researchDirection4 !== ''
              "
              >研究方向 ：</span
            >
            <Tooltip
              :transfer="true"
              :max-width="300"
              theme="light"
              v-if="
                formData.researchDirection1 !== '' ||
                  formData.researchDirection2 !== '' ||
                  formData.researchDirection3 !== '' ||
                  formData.researchDirection4 !== ''
              "
            >
              <span
                >{{
                  $splicing(
                    " | ",
                    formData.researchDirection1,
                    formData.researchDirection2,
                    formData.researchDirection3,
                    formData.researchDirection4
                  )
                }}
              </span>
              <div slot="content">
                <span
                  >{{
                    $splicing(
                      " | ",
                      formData.researchDirection1,
                      formData.researchDirection2,
                      formData.researchDirection3,
                      formData.researchDirection4
                    )
                  }}
                </span>
              </div>
            </Tooltip>
          </div>
          <div>
            <span v-if="formData.executive">行政职务 ：</span>
            <Tooltip
              :transfer="true"
              placement="bottom-end"
              theme="light"
              :content="`${formData.executive}`"
              v-if="formData.executive"
            >
              {{ formData.executive }}
            </Tooltip>
          </div>
        </div>
      </div>
    </div>
    <div class="bottom">
      <Tabs type="card">
        <TabPane label="个人简介">
          <div class="tabs-content">
            <pre>{{ formData.individualResume }}</pre>
          </div>
        </TabPane>
        <TabPane label="在研课题">
          <div class="tabs-content">
            <pre>{{ formData.researchTopic }}</pre>
          </div>
        </TabPane>
        <TabPane label="获奖情况">
          <div class="tabs-content">
            <pre>{{ formData.awards }}</pre>
          </div>
        </TabPane>
        <TabPane label="科研项目">
          <div class="tabs-content">
            <pre>{{ formData.researchProject }}</pre>
          </div>
        </TabPane>
        <TabPane label="发表论文">
          <div class="tabs-content">
            <pre>{{ formData.publications }}</pre>
          </div>
        </TabPane>
        <TabPane label="其他">
          <div class="tabs-content">
            <pre>{{ formData.others }}</pre>
          </div>
        </TabPane>
      </Tabs>
    </div>
  </div>
</template>
<script>
export default {
  name: "phoneDetail",
  data() {
    return {
      formData: {
        researchDirection1: "",
        researchDirection2: "",
        researchDirection3: "",
        researchDirection4: "",
        // 行政部门
        college2: "",
        // 获奖情况
        awards: "",
        // 办公地址
        businessAddress: "",
        // 学院
        college: "",
        // 院系
        department: "",
        // 电子邮箱
        emailAddress: "",
        sex: "",
        // 行政职务
        executive: "",
        // 一级学科1
        firstDiscipline1: "",
        // 一级学科2
        firstDiscipline2: "",
        // ID
        id: "",
        degree: "",
        // 个人简介
        individualResume: "",
        // 移动电话
        mobilePhone: "",
        // 姓名
        name: "",
        // 办公电话
        officePhone: "",
        // 其他
        others: "",
        // 照片
        picture: "",
        // 发表论文
        publications: "",
        // 是否招生 1:是 0:否
        recruit: "",
        // 科研项目
        researchProject: "",
        // 在研课题
        researchTopic: "",
        // 二级学科1
        secondaryDiscipline1: "",
        // 二级学科2
        secondaryDiscipline2: "",
        // 职称
        title: ""
      },
      modalVisiable: false
    };
  },
  mounted() {
    this.requireTeacherDetail();
  },
  methods: {
    requireTeacherDetail() {
      this.loadingDetail = true;
      this.$axios
        .get(`/api/teacher/${this.id}`)
        .then(res => {
          let data = res.data.data;
          this.loadingDetail = false;
          if (this.$isEmpty(data)) {
            this.$Message.error("获取教师详情失败");
            return;
          }
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
        })
        .catch(err => {
          console.log(err.message);
          this.loadingDetail = false;
        });
    }
  },
  computed: {
    id() {
      return this.$route.query.id;
    },
    man() {
      console.log(this.$store);
      return require(`../assets/${this.$store.getters.getManAvatar}`);
    },
    woman() {
      return require(`../assets/${this.$store.getters.getWomanAvatar}`);
    },
    defaultPng() {
      return require(`../assets/${this.$store.getters.getDefaultAvatar}`);
    }
  }
};
</script>
<style lang="scss" scoped>
.phoneDetail {
  background: #f5f5f5;
  font-size: 4vw;
  width: 100vw;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  .top {
    background: #fff;
    height: 60vw;
    display: flex;
    justify-content: space-between;
    padding: 5vw;
    .avatar {
      height: 100%;
      width: 32vw;
      margin-right: 5vw;
      padding-top: 20px;
      img {
        height: 100%;
        max-width: 100%;
      }
    }
    .right {
      display: flex;
      flex: 1;
      flex-direction: column;
      justify-content: space-between;
      color: #666666;
      .name {
        color: #000;
        font-size: 6vw;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
      }
      .info > div {
        display: flex;
        /deep/ .ivu-tooltip-rel {
          width: 30vw;
          @extend .text-ellipsis;
        }
        &:not(:last-child) {
          margin-bottom: 0.5vw;
        }
      }
    }
  }
  .bottom {
    flex: 1;
    background: #fff;
    .ivu-tabs {
      height: 100vw;
      overflow-y: auto;
      .tabs-content {
        height: 80vw;
        padding: 5vw;
        overflow-y: auto;
      }
    }
  }
}
</style>
<style lang="scss">
#app.app {
  width: 100%;
  min-width: 100%;
}
.ivu-modal-body {
  padding: 5vw;
  padding-top: 8vw;
  & > div {
    margin-bottom: 3vw;
  }
}

.ivu-tooltip-inner {
  width: 70vw;
  max-width: 300px;
  white-space: pre-line;
}
</style>
