<template>
  <div class="teacherDetail">
    <my-header></my-header>
    <div class="teacher-detail-content">
      <div class="left">
        <div class="top">
          <div class="avatar">
            <img :src="'/api' + formData.picture" v-if="formData.picture" />
            <!-- <img :src="sex === '2' ? woman : man" v-else /> -->
            <img :src="defaultPng" v-else />
          </div>
          <div class="teacher-msg">
            <div class="msg-top">
              <div class="name">
                <span>{{ formData.name }}</span>
                <div>
                  <span class="zc">{{ formData.title }} </span>
                  <span class="green" v-if="formData.recruit === 1">
                    |
                    <Icon type="md-checkmark-circle" class="green" />{{
                      $store.getters.getCurrentYear
                    }}年度招生资格
                  </span>
                </div>
              </div>
              <div class="info">
                <div>
                  <span
                    v-if="
                      formData.department !== '' ||
                        formData.college !== '' ||
                        formData.college2 !== ''
                    "
                    >所在单位 ：</span
                  >
                  <Tooltip
                    v-if="
                      formData.department !== '' ||
                        formData.college !== '' ||
                        formData.college2 !== ''
                    "
                    :transfer="true"
                    :max-width="300"
                    :content="
                      `${$splicing(
                        ' | ',
                        formData.department,
                        formData.college,
                        formData.college2
                      )}`
                    "
                  >
                    <span>{{
                      $splicing(
                        " | ",
                        formData.department,
                        formData.college,
                        formData.college2
                      )
                    }}</span>
                  </Tooltip>
                </div>
                <div>
                  <span
                    v-if="
                      formData.firstDiscipline1 !== '' ||
                        formData.secondaryDiscipline1 !== '' ||
                        formData.firstDiscipline2 !== '' ||
                        formData.secondaryDiscipline2 !== ''
                    "
                    >学科专业 ：</span
                  >
                  <span
                    v-if="
                      formData.firstDiscipline1 !== '' ||
                        formData.secondaryDiscipline1 !== '' ||
                        formData.firstDiscipline2 !== '' ||
                        formData.secondaryDiscipline2 !== ''
                    "
                  >
                    <Tooltip :transfer="true" :max-width="300">
                      <span
                        >{{
                          $splicing(
                            " | ",
                            formData.firstDiscipline1,
                            formData.secondaryDiscipline1,
                            formData.firstDiscipline2,
                            formData.secondaryDiscipline2
                          )
                        }}
                      </span>
                      <div slot="content">
                        <span
                          >{{
                            $splicing(
                              " | ",
                              formData.firstDiscipline1,
                              formData.secondaryDiscipline1,
                              formData.firstDiscipline2,
                              formData.secondaryDiscipline2
                            )
                          }}
                        </span>
                      </div>
                    </Tooltip>
                  </span>
                </div>
                <div>
                  <span
                    v-if="
                      formData.researchDirection1 !== '' ||
                        formData.researchDirection2 !== '' ||
                        formData.researchDirection3 !== '' ||
                        formData.researchDirection4 !== ''
                    "
                    >研究方向 ：</span
                  >
                  <Tooltip
                    :transfer="true"
                    :max-width="300"
                    v-if="
                      formData.researchDirection1 !== '' ||
                        formData.researchDirection2 !== '' ||
                        formData.researchDirection3 !== '' ||
                        formData.researchDirection4 !== ''
                    "
                  >
                    <span
                      >{{
                        $splicing(
                          " | ",
                          formData.researchDirection1,
                          formData.researchDirection2,
                          formData.researchDirection3,
                          formData.researchDirection4
                        )
                      }}
                    </span>
                    <div slot="content">
                      <span
                        >{{
                          $splicing(
                            " | ",
                            formData.researchDirection1,
                            formData.researchDirection2,
                            formData.researchDirection3,
                            formData.researchDirection4
                          )
                        }}
                      </span>
                    </div>
                  </Tooltip>
                </div>
                <div>
                  <span v-if="formData.executive">行政职务 ：</span>
                  <Tooltip
                    :transfer="true"
                    :content="`${formData.executive}`"
                    :max-width="300"
                    v-if="formData.executive"
                  >
                    {{ formData.executive }}
                  </Tooltip>
                </div>
              </div>
            </div>
            <div class="msg-bottom">
              <div class="msg-bottom-left">
                <div>
                  <Icon type="md-call" />
                  <span> 办公电话 ：</span>
                  <span>{{ formData.officePhone }}</span>
                </div>
                <div>
                  <Icon type="md-phone-portrait" />
                  <span> 移动电话 ：</span>
                  <span>{{ formData.mobilePhone }}</span>
                </div>
                <div>
                  <Icon type="md-mail" />
                  <span> 电子邮箱 ：</span>
                  <span>{{ formData.emailAddress }}</span>
                </div>
                <div>
                  <Icon type="md-pin" />
                  <span> 办公地址 ：</span>
                  <span>{{ formData.businessAddress }}</span>
                </div>
              </div>
              <div class="code">
                <vue-qr :text="phoneUrl"></vue-qr>
              </div>
            </div>
          </div>
        </div>
        <div class="bottom">
          <Tabs type="card">
            <TabPane label="个人简介">
              <div class="tabs-content">
                <pre>{{ formData.individualResume }}</pre>
              </div>
            </TabPane>
            <TabPane label="在研课题">
              <div class="tabs-content">
                <pre>{{ formData.researchTopic }}</pre>
              </div>
            </TabPane>
            <TabPane label="获奖情况">
              <div class="tabs-content">
                <pre>{{ formData.awards }}</pre>
              </div>
            </TabPane>
            <TabPane label="科研项目">
              <div class="tabs-content">
                <pre>{{ formData.researchProject }}</pre>
              </div>
            </TabPane>
            <TabPane label="发表论文">
              <div class="tabs-content">
                <pre>{{ formData.publications }}</pre>
              </div>
            </TabPane>
            <TabPane label="其他">
              <div class="tabs-content">
                <pre>{{ formData.others }}</pre>
              </div>
            </TabPane>
          </Tabs>
        </div>
      </div>
      <div class="right">
        <div class="top">
          <span>相关导师</span>
          <span class="cursor-pointer" @click="clickChange"
            >换一批<Icon type="md-refresh"
          /></span>
        </div>
        <div class="bottom">
          <Row :gutter="24" type="flex">
            <i-col span="12" v-for="(item, index) of tableData" :key="index">
              <avatar-card
                v-bind="item"
                @click.native="clickDetail(item.id)"
                class="cursor-pointer"
              >
              </avatar-card>
            </i-col>
          </Row>
          <Spin size="large" fix v-if="loading"></Spin>
        </div>
      </div>
      <Spin size="large" fix v-if="loadingDetail"></Spin>
    </div>
  </div>
</template>
<script>
import myHeader from "@/components/myHeader.vue";
import vueQr from "@/components/vueQr.vue";
import avatarCard from "@/components/avatarCard.vue";
export default {
  name: "teacherDetail",
  props: {
    id: {}
  },
  components: {
    "my-header": myHeader,
    "vue-qr": vueQr,
    "avatar-card": avatarCard
  },
  data() {
    return {
      phoneUrl: `${location.origin}/tutor/#/phoneDetail?id=${this.id}`,
      // phoneUrl: `${location.origin}/#/phoneDetail?id=${this.id}`,
      tableData: [],
      loading: false,
      loadingDetail: false,
      formData: {
        researchDirection1: "",
        researchDirection2: "",
        researchDirection3: "",
        researchDirection4: "",
        // 行政部门
        college2: "",
        // 获奖情况
        awards: "",
        // 办公地址
        businessAddress: "",
        // 学院
        college: "",
        // 院系
        department: "",
        // 电子邮箱
        emailAddress: "",
        sex: "",
        // 行政职务
        executive: "",
        // 一级学科1
        firstDiscipline1: "",
        // 一级学科2
        firstDiscipline2: "",
        // ID
        id: "",
        // 个人简介
        individualResume: "",
        // 移动电话
        mobilePhone: "",
        // 姓名
        name: "",
        // 办公电话
        officePhone: "",
        // 其他
        others: "",
        // 照片
        picture: "",
        // 发表论文
        publications: "",
        // 是否招生 1:是 0:否
        recruit: "",
        // 科研项目
        researchProject: "",
        // 在研课题
        researchTopic: "",
        // 二级学科1
        secondaryDiscipline1: "",
        // 二级学科2
        secondaryDiscipline2: "",
        // 职称
        title: ""
      }
    };
  },
  mounted() {
    this.requireTeacherDetail(this.id);
    this.loadTable();
  },
  methods: {
    clickChange() {
      console.log("换一批");
      this.loadTable();
    },
    clickDetail(id) {
      this.$router.push(`/teacherDetail/${id}`);
      this.phoneUrl = `${location.origin}/tutor/#/phoneDetail?id=${id}`;
      this.requireTeacherDetail(id);
      this.loadTable();
    },
    loadTable() {
      this.loading = true;
      this.$axios
        .get(`/api/teacher/correlation/${this.id}?time=${new Date().getTime()}`)
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          if (!Array.isArray(data)) {
            this.$Message.error("教师列表数据获取失败");
            return;
          }
          this.tableData = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    requireTeacherDetail(id) {
      this.loadingDetail = true;
      this.$axios
        .get(`/api/teacher/${id}`)
        .then(res => {
          let data = res.data.data;
          this.loadingDetail = false;
          if (this.$isEmpty(data)) {
            this.$Message.error("获取教师详情失败");
            return;
          }
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
        })
        .catch(err => {
          console.log(err.message);
          this.loadingDetail = false;
        });
    }
  },
  computed: {
    man() {
      console.log(this.$store);
      return require(`../assets/${this.$store.getters.getManAvatar}`);
    },
    woman() {
      return require(`../assets/${this.$store.getters.getWomanAvatar}`);
    },
    defaultPng() {
      return require(`../assets/${this.$store.getters.getDefaultAvatar}`);
    }
  }
  // beforeRouteEnter(to, from, next) {
  //   next(vm => {
  //     let isPC = vm.$isPC();
  //     if (!isPC) {
  //       location.href = vm.phoneUrl;
  //     }
  //   });
  // }
};
</script>
<style lang="scss" scoped>
.teacherDetail {
  height: 100%;
  display: flex;
  flex-direction: column;
  .teacher-detail-content {
    background: #f0f2f5;
    flex: 1;
    padding: 3vh $left-padding;
    display: flex;
    justify-content: space-between;
    position: relative;
    .left {
      flex: 1;
      height: 70vh;
      width: 62vw;
      margin-right: 2vw;
      .top {
        height: 30vh;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
        background: #fff;
        margin-bottom: 1vh;
        padding: 1vw;
        display: flex;
        // align-items: center;
        .avatar {
          height: 100%;
          margin-right: 2vw;
          text-align: center;
          padding-top: 1vw;
          border: 1px solid rgba(204, 204, 204, 1);
          img {
            height: 100%;
            width: 10vw;
            max-width: 100%;
          }
        }
        .teacher-msg {
          flex: 1;
          display: flex;
          flex-direction: column;
          .msg-top {
            border-bottom: 1px solid rgba(204, 204, 204, 1);
            height: 13vh;
            display: flex;
            // justify-content: space-between;
            padding-bottom: 1vh;
            .name {
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              & > span:first-child {
                font-size: 1.5vw;
                color: #023364;
                font-weight: bold;
              }
              .zc {
                color: #023364;
                font-size: 0.9vw;
              }
              .green {
                font-size: 0.9vw;
              }
            }
            .info {
              padding-left: 1.5vw;
              margin-left: 1.5vw;
              border-left: 1px solid #707070;
              color: #707070;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              flex: 1;
              font-size: 0.8vw;
              & > div {
                display: flex;
                flex: 1;
              }
              /deep/ .ivu-tooltip-rel {
                width: 22vw;
                @extend .text-ellipsis;
              }
            }
          }
          .msg-bottom {
            display: flex;
            justify-content: space-between;
            .msg-bottom-left {
              flex: 1;
              font-size: 0.8vw;
              padding-top: 1vh;
              color: #707070;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              .ivu-icon {
                padding-right: 5px;
              }
            }
          }
        }
      }
      .bottom {
        height: 39vh;
        box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
        background: #fff;
        .ivu-tabs {
          height: 39vh;
          overflow-y: hidden;
          .tabs-content {
            height: 30vh;
            padding: 0 1.5vw;
            overflow-y: auto;
          }
        }
      }
    }
    .right {
      width: 30vw;
      height: 70vh;
      box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
      background: #fff;
      padding: 1.5vw;
      padding-top: 0;
      .top {
        height: 10vh;
        border-bottom: 1px solid rgba(204, 204, 204, 1);
        color: #023364;
        display: flex;
        justify-content: space-between;
        align-items: center;
        & > span:first-child {
          font-size: 2vw;
          font-weight: bold;
        }
        & > span:last-child {
          font-size: 1vw;
        }
      }
      .bottom {
        height: 60vh;
        overflow-y: auto;
        overflow-x: hidden;
        position: relative;
        padding-top: 1vh;
        padding-right: 0.5vw;
        /deep/ .ivu-row-flex {
          margin-bottom: -1vh;
          .ivu-col {
            margin-bottom: 1vh;
          }
        }
      }
    }
  }
}
.myHeader {
  padding: 0 $left-padding;
  margin: 0;
  background: #023364;
  /deep/ .logo {
    height: 14vh;
    img {
      height: 100%;
    }
  }
}
</style>
