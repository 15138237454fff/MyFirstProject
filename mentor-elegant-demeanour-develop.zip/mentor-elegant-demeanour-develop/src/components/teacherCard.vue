<template>
  <div class="teacherCard">
    <div class="card-content">
      <div class="avatar">
        <img :src="'/api' + picture" alt="" v-if="picture" />
        <!-- <img :src="sex === '2' ? woman : man" v-else /> -->
        <img :src="defaultPng" v-else />
      </div>
      <div class="msg">
        <div class="xm">{{ name }}</div>
        <div class="zc">{{ title }}</div>
        <div class="xy">{{ department }}</div>
        <div class="xy">
          <span>{{ college }}</span>
          <span v-if="college && college2"> | </span>
          <span>{{ college2 }}</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "teacherCard",
  props: {
    title: {},
    picture: {},
    name: {},
    department: {},
    college: {},
    college2: {},
    sex: {}
  },
  computed: {
    man() {
      return require(`../assets/${this.$store.getters.getManAvatar}`);
    },
    woman() {
      return require(`../assets/${this.$store.getters.getWomanAvatar}`);
    },
    defaultPng() {
      return require(`../assets/${this.$store.getters.getDefaultAvatar}`);
    }
  }
};
</script>
<style lang="scss" scoped>
.teacherCard {
  width: 25%;
  .card-content {
    box-sizing: border-box;
    height: 35vh;
    box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.16);
    margin-right: 1vw;
    .avatar {
      height: 20vh;
      background: #fff;
      text-align: center;
      padding-top: 1.2vw;
      img {
        height: 100%;
        max-width: 100%;
        width: 7vw;
      }
    }
    .msg {
      height: 15vh;
      background: #023364;
      color: #fff;
      text-align: center;
      padding: 1.2vw;
      .xm {
        font-size: 1.2vw;
        line-height: 4vh;
        height: 4vh;
      }
      .zc,
      .xy {
        font-size: 0.8vw;
        line-height: 2.2vh;
        height: 2.2vh;
      }
      .zc {
        line-height: 2.2vh;
        height: 2.2vh;
      }
    }
  }
}
</style>
