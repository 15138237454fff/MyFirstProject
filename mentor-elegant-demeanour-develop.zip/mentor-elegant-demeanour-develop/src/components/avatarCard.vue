<template>
  <div class="avatarCard">
    <div class="avatar">
      <img :src="'/api' + picture" alt="" v-if="picture" />
      <!-- <img :src="sex === '2' ? woman : man" v-else /> -->
      <img :src="defaultPng" v-else />
    </div>
    <div class="name">{{ name }}</div>
    <div class="xy">{{ college }}</div>
  </div>
</template>
<script>
export default {
  name: "avatarCard",
  props: {
    title: {},
    picture: {},
    name: {},
    department: {},
    college: {},
    college2: {},
    sex: {}
  },
  computed: {
    man() {
      return require(`../assets/${this.$store.getters.getManAvatar}`);
    },
    woman() {
      return require(`../assets/${this.$store.getters.getWomanAvatar}`);
    },
    defaultPng() {
      return require(`../assets/${this.$store.getters.getDefaultAvatar}`);
    }
  }
};
</script>
<style lang="scss" scoped>
.avatarCard {
  text-align: center;
  .avatar {
    height: 18vh;
    text-align: center;
    border: 1px solid rgba(204, 204, 204, 1);
    margin-bottom: 1vh;
    padding-top: 1vh;
    img {
      height: 100%;
      max-width: 100%;
    }
  }
  .name,
  .xy {
    color: #666666;
    font-size: 0.8vw;
    line-height: 1vw;
    height: 2vh;
  }
}
</style>
