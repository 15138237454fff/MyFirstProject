<template>
  <div class="vueQr">
    <vue-qr
      :margin="0"
      :size="80"
      :text="text"
      :logoSrc="logoSrc"
      :logoScale="0.2"
    ></vue-qr>
  </div>
</template>
<script>
import VueQr from "vue-qr";
export default {
  name: "vueQr",
  props: {
    text: {
      default: ""
    }
  },
  data() {
    return {
      logoSrc: require("../assets/logo1.png")
    };
  },
  components: {
    "vue-qr": VueQr
  }
};
</script>
<style lang="scss" scope>
.vueQr {
  padding-top: 0.1vw;
  height: 13vh;
  height: 13vh;
  box-sizing: border-box;
  img {
    height: 100%;
  }
}
</style>
