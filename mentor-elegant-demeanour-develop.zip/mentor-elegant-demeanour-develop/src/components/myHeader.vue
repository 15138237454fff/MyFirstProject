<template>
  <div class="myHeader">
    <div class="logo cursor-pointer" @click="clickLogo">
      <img :src="logo" alt="" />
    </div>
    <div class="nav">
      <a :href="index" target="_blank">首页</a>
      <a :href="enroll" target="_blank">招生网</a>
      <a :href="login" target="_blank">登录</a>
    </div>
  </div>
</template>
<script>
export default {
  name: "myHeader",
  data() {
    return {
      logo: require("../assets/logo.png"),
      index: "https://yjsy.cjlu.edu.cn/",
      enroll: "http://yjsb.cjlu.edu.cn/yjsy/zsnet/",
      login:
        "http://ids1.cjlu.edu.cn:81/amserver/UI/Login?goto=http%3a%2f%2fyjsb.cjlu.edu.cn%2fyjsjsb%2fdstylogin"
    };
  },
  methods: {
    clickLogo() {
      this.$router.push("/home");
    }
  }
};
</script>
<style lang="scss" scoped>
.myHeader {
  display: flex;
  justify-content: space-between;
  align-items: center;
  .nav {
    font-size: 1.2vw;
    a {
      color: #fff;
      margin-right: 4vw;
    }
  }
}
</style>
