<template>
  <div class="myFooter">
    <div class="copy">
      版权所有 Copyright &copy; {{ $store.getters.getCurrentYear }}-{{
        $store.getters.getCurrentYear + 1
      }}
      中国计量大学研究生院
    </div>
    <div class="jszc">&copy; 技术支持：杭州毕为科技有限公司</div>
    <div class="msg">
      <span>联系电话：0571-87676168</span>
      <span>电子邮箱：yjsy@cjlu.edu.cn</span>
      <span>传真：0571-86836065</span>
    </div>
  </div>
</template>
<script>
export default {
  name: "myFooter"
};
</script>
<style lang="scss" scoped>
.myFooter {
  background: #01172e;
  height: 10vh;
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding: 5vh $left-padding;
  align-items: center;
  color: #fff;
  .jszc {
    color: #fff;
  }
  .msg {
    display: flex;
    width: 40vw;
    justify-content: space-between;
  }
}
</style>
