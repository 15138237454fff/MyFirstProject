<template>
  <div id="app" class="app">
    <router-view />
  </div>
</template>
<style lang="scss" scoped>
#app {
  height: 100vh;
}
</style>
<style lang="scss">
pre {
  margin: 0;
  white-space: pre-wrap;
  tab-size: 4;
}
</style>
