# py-front

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

在行间设置当前激活的路由的style，以及修改默认生成的a标签
```
<router-link tag="li" active-class="isActive">
```

## 路由配置

> 个人信息管理  personalInfo
> 
> 日常工作  routine
> 
> 教学培养  teachTrain
> 
> 国际化培养  interTrain
> 
> 优博培育项目  youboProject
> 
> 学术成果  academicAchieve
> 
> 学位论文  dissertation
> 
> 离校就业服务  employService

### 个人信息管理

> 个人信息管理  personalInfo
> - 个人基本信息  baseInfo
> - 学籍异动申请  stuChange
> - 研究生证补办  cardReapply
> - 硕博连读申请  suoboApply
> - 更换导师申请  changeTutor

### 日常工作

> 日常工作  routine
> - 勤工岗位申请  jobApply
> - 学生活动报名  eventEnroll
> - 入党申请  partyApply

### 教学培养

> 教学培养  teachTrain
> - 个人培养计划  personalPlan
> - 在线选课  onlineSelection
> - 免修/重修/缓考  exemptionRebuild
> - 在线评教  onlineEvalution
> - 个人课表  personalTimetable
> - 个人成绩单  personalTranscript
> - 英语四六级报名  applyCET

### 国际化培养

> 国际化培养  interTrain
> - 项目申请  interApply
> - 出国报备申请  goAbroad
> - 成果录入  resultInput
> - 国际化培养查询  interQuery

### 优博培育项目

> 优博培育项目  youboProject
> - 优博项目申报  youboApply

### 学术成果

> 学术成果  academicAchieve
> - 学术成果录入  achieveInput
> - 个人成果查询  achieveQuery

### 学位论文

> 学位论文  dissertation
> - 开题报告申请  reportApply
> - 学位申请  degreeApply
> - 毕业论文上传  paperUpload
> - 优秀论文申请  excellentPapersApply
> - 论文定稿  paperFinal

### 离校就业服务

> 离校就业服务  employService
> - 电子离校单  leaveSchoolList
> - 毕业档案查询  archivesQuery

## 导师部分

### 招生资格申请

### 学生信息管理

> 学生信息管理  stuInfoManage  
> - 学生信息查看  stuInfoView  
> - 学生信息审核  stuInfoAudit

### 教学培养管理

> 教学培养管理  teaTrainManage  
> - 培养计划审核  trainPlanAudit  
> - 学生课程审核  stuCourseAudit  
> - 培养计划查询  trainPlanQuery  
> - 课程管理  courseManage  
> - 学生成绩管理  stuScoreManage 

### 国际化培养管理

### 教育建设项目

### 学术成果管理

### 学位论文管理

## 导师审核学生个人信息管理10张申请表

> 1. 研究生证补办      ReplaceCardApplystuInfo(不用在导师审核页面展示)
> 2. 学生更换导师申请   stuInfoServiceChangeTeacherApply
> 3. 学生延迟毕业申请   stuInfoServiceDelayGraduateApply
> 4. 学生硕博连读申请   stuInfoServiceDoctorAndMesterApply
> 5. 学生退学申请      stuInfoServiceDropOutApply
> 6. 学生结业申请      stuInfoServiceFinishGraduateApply
> 7. 学生复学申请      stuInfoServiceGoBackSchoolApply
> 8. 学生休学申请      stuInfoServiceQuitSchoolApply
> 9. 学生转专业申请    stuInfoServiceSwitchMajorApply
> 10. 学生肄业申请     stuInfoServiceYiYeApply
