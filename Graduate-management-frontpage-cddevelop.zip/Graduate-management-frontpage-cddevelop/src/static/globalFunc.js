export default {
  install(Vue) {
    /**
     * 挂载一个动态添加实例data中对象的属性的方法到Vue原型上
     * data:待添加的新对象
     * object:实例的data中已经声明的对象
     */
    Vue.prototype.$addObjectKey = (data, object) => {
      // 要求传入的参数必须都为对象
      if (Object.prototype.toString.call(data) === '[object Object]' && Object.prototype.toString.call(object) === '[object Object]') {
        Object.keys(data).forEach(key => {
          Vue.set(object, key, data[key])
        })
      } else {
        console.error('请正确传入参数，要求都为对象')
      }
    }
    // 设置表头颜色的方法
    Vue.prototype.$tableHeaderColor = ({
      rowIndex
    }) => {
      if (rowIndex == 0) {
        return 'background-color:#f2f2f2;font-weight:500'
      }
    }
    // 根据value从List中获取对应label值
    Vue.prototype.$getListValue = function (value, list) {
      // 对象数组的类型不是数组
      if (!Array.isArray(list)) {
        console.error("对应的对象数组格式错误");
        return "";
      }
      let result = list.find(el => value === el.value);
      // 如果找不到对应对象获取对象的label属性为空
      if (!result || !result.label) {
        return "";
      }
      return result.label;
    };
    /**
     * time 时间对象
     * tag 传入想要得到的时间格式 yyyy-MM-dd HH-mm-ss
     */
    Vue.prototype.$tagTime = (time, tag) => {
      if (!tag) {
        return ""
      }
      if (!time) {
        return ""
      }
      let tmpTime = new Date(time)
      if (isNaN(tmpTime)) {
        return ""
      }
      let year = tmpTime.getFullYear(),
        month = tmpTime.getMonth() + 1,
        date = tmpTime.getDate(),
        hour = tmpTime.getHours(),
        minute = tmpTime.getMinutes(),
        second = tmpTime.getSeconds()
      // 不足10前面补0
      if (month < 10) {
        month = "0" + month
      }
      // 不足10前面补0
      if (date < 10) {
        date = "0" + date
      }
      // 不足10前面补0
      if (hour < 10) {
        hour = "0" + hour
      }
      // 不足10前面补0
      if (minute < 10) {
        minute = "0" + minute
      }
      // 不足10前面补0
      if (second < 10) {
        second = "0" + second
      }
      return tag.replace("yyyy", year).replace("MM", month).replace("dd", date).replace("HH", hour).replace("mm", minute).replace("ss", second)
    }
  },
  // 节流
  debounce: (() => {
    let lastTime = new Date()
    return (callback, wait) => {
      let currentTime = new Date()
      let remaining = currentTime - lastTime - wait
      if (remaining >= 0) {
        callback()
        lastTime = currentTime
      }
    }
  })()
}
