import Vue from 'vue'
// import App from './App.vue'
import router from './router'
import store from './store'
import axios from 'axios'

import globalFunc from './static/globalFunc'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

import '@/styles/index.scss' // global css

import * as filters from './filters' // global filters
import bus from './components/bus'
import Log from '@/common/log.js'
// 添加自定义的全局方法
Vue.use(Log)
Vue.use(globalFunc)
Vue.prototype.$http = axios
Vue.prototype.$bus = bus
Vue.config.productionTip = false
Vue.use(ElementUI)
// register global utility filters.加载全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})
// 添加一个请求拦截器
axios.interceptors.request.use(
  config => {
    if (store.state.userLoginMsg.xh === '' && router.history.current.fullPath !== "/forgotPassword") {
      router.push('/login')
    }
    if (store.state.userLoginMsg.userToken === undefined) {
      config.headers.userToken = ""
    } else {
      config.headers.userToken = store.state.userLoginMsg.userToken
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)
// 添加一个响应拦截器
axios.interceptors.response.use(function (res) {
  return res
}, function (error) {
  if (error.response.status === 401) {
    globalFunc.debounce(() => {
      ElementUI.Message.error('登录信息失效，请重新登录')
    }, 100)
    store.commit('updatedUser', {})
    router.push('/login')
  } else {
    ElementUI.Message.error(error.response.data.message)
  }
  return Promise.reject(error)
})

new Vue({
  router,
  axios,
  store
}).$mount('#app')
