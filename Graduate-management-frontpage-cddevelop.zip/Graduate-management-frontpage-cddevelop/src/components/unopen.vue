<template>
  <div class="unopen-box">
    <div class="card">
      <img src="../assets/images/unopen.png" />
      <span>程序员小哥哥正在加班开发中,敬请期待!</span>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {}
  }
}
</script>
<style lang="scss" scoped>
.unopen-box {
  width: 100%;
  // height: 84vh;
  height: 100%;
  margin-top: 146px;
  display: flex;
  // position: absolute;
  // left: 0;
  justify-content: center;
  align-items: center;
  margin: 0 auto;
  background: #fff;
  .card {
    width: 477px;
    height: 350px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    span {
      margin-top: 10px;
      font-size: 18px;
      color: #999999;
      white-space: nowrap;
    }
  }
}
</style>
