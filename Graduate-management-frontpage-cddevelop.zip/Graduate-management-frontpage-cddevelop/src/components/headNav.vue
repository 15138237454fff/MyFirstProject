<template>
  <div class="header-nav-content">
    <el-header class="header">
      <el-row type="flex" justify="space-between" style="height:80px">
        <el-col :span="8">
          <img :src="loGoUrls" class="logo-img" />
        </el-col>
        <el-col :span="8" style="text-align:center;font-size:25px">
          <span style="white-space:nowrap">浙江财经大学研究生院综合服务平台</span>
        </el-col>
        <el-col :span="8" style="text-align:right;font-size:14px">
          <div style="height:40px;line-height:40px;margin-top:7px">
            <span @click="toIndex" :class="{ isActive: this.$route.name == 'index' }">首页</span>
            <el-divider direction="vertical" v-if="userStatus === '1'"></el-divider>
            <el-popover placement="top-end" trigger="click">
              <el-table height="170" :data="newMsgList" :show-header="false" @row-click="readMsg">
                <el-table-column prop="msg" width="300"></el-table-column>
              </el-table>
              <span slot="reference" class="hasMsg">
                消息中心
                <span v-show="!!newMsgList.length" style="font-size:10px;">{{
                  newMsgList.length
                }}</span>
              </span>
            </el-popover>
            <el-divider direction="vertical"></el-divider>
            <span @click="modifyMM">修改密码</span>
            <el-divider direction="vertical"></el-divider>
            <span @click="logoutComfirm = true" v-show="!!xh">退出</span>
          </div>
          <div style="height:40px;line-height:40px;margin-top:-10px">
            <span>
              欢迎 {{ name }}({{ xh }})
              <span v-if="userStatus === '1'">研究生</span>
              <span v-else-if="userStatus === '2'">教职工</span>
              <span v-else>管理员</span>
            </span>
            登录
            <!-- <router-link to="/login" class="login">登录</router-link> -->
          </div>
        </el-col>
      </el-row>
    </el-header>
    <el-dialog title="修改密码" :visible.sync="modifyMMDialogVisible" width="380px">
      <el-form :model="form" ref="ruleForm" status-icon>
        <el-form-item label="用户名：" :label-width="formLabelWidth" prop="userName">
          <span>{{ form.userName }}</span>
        </el-form-item>
        <el-form-item label="姓 名：" :label-width="formLabelWidth" prop="name">
          <span>{{ form.name }}</span>
        </el-form-item>
        <el-form-item label="原密码：" :label-width="formLabelWidth" prop="password">
          <el-input v-model="form.password" show-password></el-input>
        </el-form-item>
        <el-form-item label="新密码：" :label-width="formLabelWidth" prop="newpassword">
          <el-input v-model="form.newpassword" show-password></el-input>
          <div class="tishi">密码长度为8-16位</div>
          <div class="tishi">新密码必须至少包含字母、数字、特殊字符中的2种</div>
        </el-form-item>
        <el-form-item label="确认密码：" :label-width="formLabelWidth" prop="qrpassword">
          <el-input v-model="form.qrpassword" show-password></el-input>
        </el-form-item>
      </el-form>
      <div class="confirmBTN" slot="footer">
        <el-button type="primary" @click="confirmMM">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="logoutComfirm" width="20%" title="退出登录" class="logout">
      <span>是否退出登录</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="logoutComfirm = false">取 消</el-button>
        <el-button type="primary" @click="logout">确 定</el-button>
      </span>
    </el-dialog>
    <my-modal v-bind="ConfirmModalOption" @visiableChange="handleConfirmVisiableChange">
      <div class="modal-content">
        <p>{{ ConfirmModalOption.msg }}</p>
      </div>
      <p slot="footer">
        <el-button size="large" @click="handleCancel">取消</el-button>
        <el-button size="large" type="primary" @click="ConfirmModalOption.handleOk">确定</el-button>
      </p>
    </my-modal>
  </div>
</template>

<script>
import mrLogo from "../assets/mrLogo.png";
import myModal from "@/components/common/myModal";
export default {
  name: "headNav",
  data() {
    return {
      // 修改密码框可见性
      modifyMMDialogVisible: false,
      // 退出登录时确认
      logoutComfirm: false,
      // 新密码格式验证
      newPassRegx: /^(?![\d]+$)(?![a-zA-Z]+$)(?![^\da-zA-Z]+$).{6,20}$/,
      // form表单值
      form: {
        // 用户编号
        id: "",
        // 用户名
        userName: "",
        // 姓名
        name: "",
        // 旧密码
        password: "",
        // 新密码
        newpassword: "",
        // 确认密码
        qrpassword: ""
      },
      formLabelWidth: "100px",
      // 新的消息列表
      newMsgList: [],
      // 学生消息路由对照表
      newStuMsgMap: {
        // 通知列表
        tzList: "/noticeList",
        // 个人培养计划
        grxxjh: "/teachTrain/personalPlan/1",
        // 退、补选
        tbxsj: "/teachTrain/onlineSelection/1",
        // 老生注册时间
        lszc: "/register",
        // 学生选课时间
        xsxksj: "/teachTrain/onlineSelection/1",
        // 教学评教时间
        jypjsj: "/teachTrain/onlineEvalution/1",
        // 四六级报名
        cet: "/teachTrain/applyCET/1",
        // 学位资格申请
        DegreeApplication: "/",
        // 学术成果申请
        academicApply: "/academicAchieve/achieveInput/2",
        // 研究生证补办
        stuInfoReplaceCardApply: "/personalInfo/cardReapply/2",
        // 学生更换导师申请
        stuInfoServiceChangeTeacherApply: "/personalInfo/changeTutor/2",
        // 学生延迟毕业申请
        stuInfoServiceDelayGraduateApply: "/personalInfo/stuChange/2",
        // 学生硕博连读申请
        stuInfoServiceDoctorAndMesterApply: "/personalInfo/suoboApply/2",
        // 学生退学申请
        stuInfoServiceDropOutApply: "/personalInfo/stuChange/2",
        // 学生结业申请
        stuInfoServiceFinishGraduateApply: "/personalInfo/stuChange/2",
        // 学生复学申请
        stuInfoServiceGoBackSchoolApply: "/personalInfo/stuChange/2",
        // 学生休学申请
        stuInfoServiceQuitSchoolApply: "/personalInfo/stuChange/2",
        // 学生转专业申请
        stuInfoServiceSwitchMajorApply: "/personalInfo/stuChange/2",
        // 学生肄业申请
        stuInfoServiceYiYeApply: "/personalInfo/stuChange/2",
        // 重修申请
        stuKcsqRebuildApply: "/teachTrain/exemptionRebuild/2",
        // 个人培养计划课程调整申请
        stuKcsqServiceChangeCourseApply: "/teachTrain/personalPlan/4",
        // 缓考申请
        stuKcsqServiceDelayedExamApply: "/teachTrain/exemptionRebuild/2",
        // 免修申请
        stuKcsqServiceExemptionApply: "/teachTrain/exemptionRebuild/2",
        // 个人培养计划申请
        stuTrainingPlanApply: "/teachTrain/personalPlan/2"
      },
      // 教师消息路由对照表
      newTeaMsgMap: {
        // 通知列表
        tzList: "/teacherNoticeList",
        // 录入信息
        cglrsj: "/stuScoreManage",
        // 个人培养计划申请
        stuTrainingPlanApply: "/trainPlanAudit",
        // 个人培养计划课程调整申请
        stuKcsqServiceChangeCourseApply: "/stuCourseAudit",
        // 教师调课申请
        teaSwitchClassApply: "/courseManage?query=3",
        // 免修申请
        stuKcsqServiceExemptionApply: "/stuCourseAudit",
        // 缓考申请
        stuKcsqServiceDelayedExamApply: "/stuCourseAudit",
        // 重修申请
        stuKcsqRebuildApply: "/stuCourseAudit",
        // 学生肄业申请
        stuInfoServiceYiYeApply: "/stuInfoAudit",
        // 学生转专业申请
        stuInfoServiceSwitchMajorApply: "/stuInfoAudit",
        // 学生休学申请
        stuInfoServiceQuitSchoolApply: "/stuInfoAudit",
        // 学生复学申请
        stuInfoServiceGoBackSchoolApply: "/stuInfoAudit",
        // 学生结业申请
        stuInfoServiceFinishGraduateApply: "/stuInfoAudit",
        // 学位资格申请
        DegreeApplication: "/academicDegreeAduit/2",
        // 学术成果申请
        academicApply: "/academicAchieveAduit",
        // 研究生证补办
        stuInfoReplaceCardApply: "/teacherHome",
        // 学生更换导师申请
        stuInfoServiceChangeTeacherApply: "/stuInfoAudit",
        // 学生延迟毕业申请
        stuInfoServiceDelayGraduateApply: "/stuInfoAudit",
        // 学生硕博连读申请
        stuInfoServiceDoctorAndMesterApply: "/stuInfoAudit",
        // 学生退学申请
        stuInfoServiceDropOutApply: "/stuInfoAudit"
      },
      // 老师的角色列表
      roleTeacherList: [],
      loGoURl: mrLogo
    };
  },
  components: {
    "my-modal": myModal
  },
  mounted() {
    console.log("当前登录的是" + (this.userStatus === "1" ? "学生" : "老师"));
    this.getXxList();
  },
  methods: {
    // 对话框取消的处理方法
    handleCancel() {
      // 隐藏模态框
      this.$store.commit("common/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 点击首页
    toIndex() {
      let path = "";
      if (this.userStatus === "1") path = "/";
      else if (this.userStatus === "2") path = "/teacherHome";
      this.$router.push({
        path
      });
    },
    // 根据用户名获取用户信息
    getUserInfo() {
      this.form.userName = this.xh;
      this.form.name = this.name;
      this.form.id = this.userId;
    },
    // 点击修改密码
    modifyMM() {
      // 对话框显示
      this.modifyMMDialogVisible = true;
      // 清空之前的表单值
      this.form = {};
      // 获取基本信息
      this.getUserInfo();
    },
    // 确认修改密码
    confirmMM() {
      // console.log(this.form);
      // 如果新密码格式不正确
      if (!this.newPassRegx.test(this.form.newpassword)) {
        this.$message.error("新密码必须至少包含字母、数字、特殊字符中的2种");
        return false;
      }
      // 发送请求修改密码
      this.$http
        .put("/api/system/home/updatePassword", this.form)
        .then(result => {
          // console.log(result);
          if (result.data.code === 200) {
            this.modifyMMDialogVisible = false;
            this.$message.success(result.data.data);
          } else {
            this.$message.error(result.data.message);
          }
        });
    },
    // 获取消息列表
    getXxList() {
      this.$http
        .get("/api/system/xxzx/xxList", { params: { type: 0 } })
        .then(result => {
          let data = result.data.data;
          let ztArray = ["失败", "成功", "审核中", "待审核", "退回"];
          // console.log(data);
          // data.forEach(el=>//console.log(el))
          // 对数据进行非空验证
          if (!data) {
            return false;
          }
          // 遍历消息的关键词数组
          Object.keys(data).forEach(key => {
            switch (key) {
              // 申请状态
              case "sqztXxList":
                data[key].forEach(el => {
                  if (this.userStatus === "1" && el.type === "1") {
                    // console.log(el);
                    el.msg = `您的${el.proDefName}${ztArray[el.zt]}！`;
                    this.newMsgList.push(el);
                  } else if (
                    this.userStatus === "2" &&
                    (el.type === "2" || el.type === "1")
                  ) {
                    el.msg = `您的${el.proDefName}${ztArray[el.zt]}！`;
                    this.newMsgList.push(el);
                  }
                });
                break;
              // 待审核
              case "dshXxList":
                if (this.userStatus === "2") {
                  data[key].forEach(el => {
                    el.msg = `您有${el.count}条${el.proDefName}待审核！`;
                    this.newMsgList.push(el);
                  });
                }
                break;
              // 参数变动
              case "csXxList":
                data[key].forEach(el => {
                  el.msg = `可以开始${el.title}了`;
                  // 测试时间
                  el.starTime = "2019-7-20";
                  el.endTime = "2020-7-21";
                  // 当前为学生
                  if (this.userStatus === "1" && el.type === "4") {
                    this.newMsgList.push(el);
                  }
                  // 当前为老师
                  else if (this.userStatus === "2" && el.type === "2") {
                    this.newMsgList.push(el);
                  }
                });
                break;
              // 收到通知公告
              case "tz":
                if (data[key].count !== 0) {
                  data[key].msg = `您有${data[key].count}条新通知！`;
                  data[key].childType = "tzList";
                  this.newMsgList.push(data[key]);
                }
                break;
            }
          });
          // 根据消息的type进行排序
          this.newMsgList.sort((a, b) => a.type - b.type);
        });
    },

    // 点击消息前往查看
    readMsg(row) {
      // console.log(row);
      let path;
      // 如果有childType属性
      if (row.childType) {
        // 学生
        if (this.userStatus === "1") {
          path = this.newStuMsgMap[row.childType];
          console.log(path);
          console.log("newMsgList", this.newMsgList);
          // 获取当前时间
          let now = new Date();
          let starTime = new Date(row.starTime);
          let endTime = new Date(row.endTime);
          // 如果不在时间段内
          if (now < starTime || now > endTime) {
            // 提示
            this.$message.error("不在时间段内");
            return false;
          }
        }
        // 老师
        else {
          // console.log(this.newTeaMsgMap[row.childType],'教师')
          path = this.newTeaMsgMap[row.childType];
          // //如果是老师的待审核通知
          // if (row.type === "2") {
          //   path = "/trainPlanAudit";
          // }
        }
      }
      this.$router.push({ path });
    },
    // 退出登录
    logout() {
      // console.log("正在退出登录。。。");
      this.$http
        .get("/api/usermanage/user/loginOut/" + this.userLoginMsg)
        .then(res => {
          if (res.status != 200) {
            this.$message.error("系统错误！请联系管理员");
          } else {
            // 提示消息
            this.$message.success("退出登录成功");
            // 清空用户登录信息
            this.$store.commit("updatedUser", {
              xh: "",
              token: "",
              userSsy: "",
              id: "",
              name: "",
              userStatus: ""
            });
            // 跳转到登录页
            this.$router.push("/login");
          }
        });
    },
    // 对话框可见性改变的处理方法
    handleConfirmVisiableChange(bool) {
      this.$store.commit("common/updateConfirmModalOption", {
        modalVisiabal: bool
      });
    }
  },
  computed: {
    ConfirmModalOption() {
      return this.$store.getters["common/getConfirmModalOption"];
    },
    // 返回当前学号/工号
    xh() {
      return this.$store.getters.getXH;
    },
    // 返回当前用户的名字
    name() {
      return this.$store.getters.getName;
    },
    // 返回用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    },
    // 返回用户的id
    userId() {
      return this.$store.getters.getId;
    },
    // 返回当前用户的登录信息
    userLoginMsg() {
      let id = this.$store.getters.getId;
      let ssy = this.$store.getters.getSsy;
      // let token = this.$store.getters.getToken
      console.log(id);
      // return [id, ssy, token].join('/')
      return [id, ssy].join("/");
    },
    loGoUrls() {
      return this.$store.state.logoImgUrl
        ? this.$store.state.logoImgUrl
        : this.loGoURl;
    }
  }
};
</script>

<style lang="scss" scoped>
.header-nav-content {
  width: 100%;
  .el-header {
    padding: 0 40px;
  }
  .el-header,
  .header {
    // background:#237ae4;
    background: linear-gradient(
      90deg,
      rgba(24, 144, 255, 1) 0%,
      rgba(24, 144, 255, 1) 0%,
      rgba(136, 199, 255, 1) 100%,
      rgba(136, 199, 255, 1) 100%
    );
    height: 80px !important;
    color: #fff;
    line-height: 80px;
    // margin-bottom: 20px;
    & > div > div:last-child > div:first-child span {
      cursor: pointer;
    }
    .logo-img {
      vertical-align: top;
      width: 300px;
      margin-top: 16px;
    }
  }
}
.userRole {
  display: block;
  height: 40px;
  line-height: 40px;
  padding: 0 10px;
  border-bottom: 1px solid #ddd;
  img {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    vertical-align: middle;
  }
}
//当前选中的角色样式
.activeRole {
  background-color: rgba(223, 240, 255, 1);
  // color: #f00;
  &::after {
    content: "✔";
    color: #2496ff;
  }
}
.isActive {
  color: #2b94ff;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  border-top: 1px solid #ddd;
  text-align: center;
}
/deep/ .el-dialog__body {
  padding-bottom: 0;
}
.logout {
  /deep/ .el-dialog__body {
    border-bottom: 1px solid #ddd;
    padding: 50px 20px;
    text-align: center;
    p {
      line-height: 32px;
    }
  }
}
.confirmBTN {
  text-align: center;
}
.tishi {
  font-size: 10px;
  color: #f00;
  float: left;
  line-height: 15px;
  height: 15px;
}
/deep/ .el-badge__content.is-fixed {
  top: 5px;
  right: 17px;
}
.hasMsg {
  position: relative;
  span {
    display: block;
    width: 12px;
    height: 12px;
    background: #f00;
    border-radius: 50%;
    position: absolute;
    right: -4px;
    top: -4px;
    font-size: 10px;
    line-height: 12px;
    text-align: center;
    // display:
  }
}
.login {
  color: #fff;
}
</style>

<style lang="scss">
html,
body {
  margin: 0;
  padding: 0;
}
.modal-confirm {
  .el-dialog__body {
    height: 10vh;
    text-align: center;
  }
  &.el-dialog {
    width: 400px !important;
  }
  .modal-content {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>
