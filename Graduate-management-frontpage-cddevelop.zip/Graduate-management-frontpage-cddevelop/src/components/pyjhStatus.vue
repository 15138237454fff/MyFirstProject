<template>
  <!-- hhh -->
  <div class="main">
    <div :class="status | statusFilter">
      <div class="text">{{status | ztFilter}}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'pyjhStatus',
  props: {
    status: {},
    status1: {},
    tableTitle: {},
    time: { default: '' }
  },
  data () {
    return {}
  },
  created () {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.wait,
.ing,
.yes,
.back {
  width: 100px;
  height: 47px;
  // background-color: #FBBD6A;
  display: inline-block;
  float: left;
  transform: translateY(0px) translateX(-13px) skew(-30deg);

  .text {
    color: #fff;
    font-size: 13px;
    text-align: center;
    transform: translateX(5px) skew(30deg);
  }
}

.wait {
  background-color: $blue;
}

.ing {
  background-color: $orange;
}

.back {
  background-color: $red;
}

.yes {
  background-color: $success;
}
</style>
