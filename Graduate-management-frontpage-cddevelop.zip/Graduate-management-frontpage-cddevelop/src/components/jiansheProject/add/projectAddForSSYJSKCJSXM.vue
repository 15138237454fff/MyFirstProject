<template>
  <div class="projectAddForKCALKJSXM">
    <div class="title">
      浙江财经大学研究生 · 硕士研究生课程建设项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>课程名称</td>
          <td class="no-indent">
            <el-input
              v-model="formData.ktmc"
              placeholder="请输入"
              :maxlength="50"
            ></el-input>
          </td>
          <td>课程性质</td>
          <td>
            <el-select v-model="formData.ktxz" placeholder="请选择">
              <el-option
                v-for="(item, index) in ktxzList"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </td>
        </tr>
        <tr>
          <td>所属专业</td>
          <td class="no-indent">
            <el-select
              v-model="formData.zym"
              filterable
              placeholder="请输入关键词"
              @change="handleZySelectChange"
            >
              <el-option
                v-for="(item, index) in zyList"
                :key="index"
                :label="`${item.label}(${item.value})`"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </td>
          <td>学位性质</td>
          <td class="indent">
            <el-radio-group v-model="formData.xwxz">
              <el-radio :label="1">学科学位</el-radio>
              <el-radio :label="2">专业学位 </el-radio>
            </el-radio-group>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <table class="charge-man">
        <tr>
          <td>姓名</td>
          <td>
            {{ personInfo.xm }}
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.xbm | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>出生年月</td>
          <td>
            {{ $tagTime(personInfo.csrq, "yyyy年MM月dd日") }}
          </td>
          <td>最终学历/学位</td>
          <td>
            {{ personInfo.zhxw }}
          </td>
        </tr>
        <tr>
          <td>是否为硕导/博导</td>
          <td>
            <span v-if="personInfo.dslb">{{
              personInfo.dslb === 1 ? "硕导" : "博导"
            }}</span>
            <span v-else>未知</span>
          </td>
          <td>聘为硕导/博导时间</td>
          <td>
            {{ personInfo.hdny }}
          </td>
        </tr>
        <tr>
          <td>职务</td>
          <td>
            {{ personInfo.zw }}
          </td>
          <td>职称</td>
          <td>
            {{ personInfo.zc }}
          </td>
        </tr>
        <tr>
          <td>联系电话</td>
          <td>
            {{ personInfo.yddh }}
          </td>
          <td>电子信箱</td>
          <td>
            {{ personInfo.dzyx }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="本课程的主要特色">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.zytsFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjZyts"
            :on-remove="removeFjZyts"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.zytsFj.url"
            target="_blank"
            class="primary"
            :download="formData.zytsFj.fileName"
            >{{ formData.zytsFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjZyts"
          ></span>
        </template>
      </div>
      <el-input
        v-model="formData.zyts"
        placeholder="请输入"
        type="textarea"
        :maxlength="500"
        :autosize="{ minRows: 6, maxRows: 8 }"
      ></el-input>
    </project-card>
    <project-card title="预期达到的建设目标">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jsmbFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJsmb"
            :on-remove="removeFjJsmb"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jsmbFj.url"
            target="_blank"
            class="primary"
            :download="formData.jsmbFj.fileName"
            >{{ formData.jsmbFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjJsmb"
          ></span>
        </template>
      </div>
      <el-input
        v-model="formData.jsmb"
        placeholder="请输入"
        type="textarea"
        :maxlength="500"
        :autosize="{ minRows: 6, maxRows: 8 }"
      ></el-input>
    </project-card>
    <project-card title="课程建设主要内容">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.zynrFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjZynr"
            :on-remove="removeFjZynr"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.zynrFj.url"
            target="_blank"
            class="primary"
            :download="formData.zynrFj.fileName"
            >{{ formData.zynrFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjZynr"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span> 1.师资队伍；</span>
          <span>2.课程教学大纲、教材、教学案例库和参考文献库；</span>
          <span>3.教学范式改革；</span>
          <span>4.教学方法和教学辅助手段；</span>
          <span>5.实践环节和其他教学环节设计等。不够可加页，限4000字</span>
          <el-input
            v-model="formData.zynr"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="本课程的建设目标、步骤、课程资源上网计划等">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.bzjhFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjBzjh"
            :on-remove="removeFjBzjh"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.bzjhFj.url"
            target="_blank"
            class="primary"
            :download="formData.bzjhFj.fileName"
            >{{ formData.bzjhFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjBzjh"
          ></span>
        </template>
      </div>
      <el-input
        v-model="formData.bzjh"
        placeholder="请输入"
        type="textarea"
        :maxlength="2000"
        :autosize="{ minRows: 6, maxRows: 8 }"
      ></el-input>
    </project-card>
    <project-card title="课程负责人的教学和科研情况（附近三年科研成果清单）">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.kyqkFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjKyqk"
            :on-remove="removeFjKyqk"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.kyqkFj.url"
            target="_blank"
            class="primary"
            :download="formData.kyqkFj.fileName"
            >{{ formData.kyqkFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjKyqk"
          ></span>
        </template>
      </div>
      <el-input
        v-model="formData.kyqk"
        placeholder="请输入"
        type="textarea"
        :maxlength="2000"
        :autosize="{ minRows: 6, maxRows: 8 }"
      ></el-input>
    </project-card>
    <project-card title="主要参加人员的教学和科研情况（附近三年科研成果清单）">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.rykyFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjRyky"
            :on-remove="removeFjRyky"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.rykyFj.url"
            target="_blank"
            class="primary"
            :download="formData.rykyFj.fileName"
            >{{ formData.rykyFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjRyky"
          ></span>
        </template>
      </div>
      <el-input
        v-model="formData.ryky"
        placeholder="请输入"
        type="textarea"
        :maxlength="2000"
        :autosize="{ minRows: 6, maxRows: 8 }"
      ></el-input>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "projectAddForKCALKJSXM",
  components: {
    "project-card": projectCard
  },
  props: {
    xmId: {}
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      formData: null,
      zyList: [],
      ktxzList: [],
      getPath: "jiansheProject/getFormDataForSSYJSKCJSXM",
      clearPath: "jiansheProject/clearFormDataForSSYJSKCJSXM",
      updatePath: "jiansheProject/updateFormDataForSSYJSKCJSXM",
      loading: false,
      personInfo: {
        csrq: "",
        dslb: "",
        dzyx: "",
        gh: "",
        hdny: "",
        rjnx: "",
        ssyxh: "",
        ssyxmc: "",
        xbm: "",
        xm: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zhxw: "",
        zw: ""
      },
      pickerOptionsStart: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() < new Date().getTime() - 86400000;
        }
      }
    };
  },
  mounted() {
    // 请求个人信息
    this.requirePersonInfo();
    // 请求课程性质列表
    this.requireKtxzList();
    // 请求专业列表
    this.requireZyList();
  },
  methods: {
    // 接收的上传名称和地址
    receiveFjZyts(res) {
      this.formData.zytsFj = res.data;
    },
    // 文件移除时清空附件
    removeFjZyts() {
      this.formData.zytsFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjJsmb(res) {
      this.formData.jsmbFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJsmb() {
      this.formData.jsmbFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjZynr(res) {
      this.formData.zynrFj = res.data;
    },
    // 文件移除时清空附件
    removeFjZynr() {
      this.formData.zynrFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjBzjh(res) {
      this.formData.bzjhFj = res.data;
    },
    // 文件移除时清空附件
    removeFjBzjh() {
      this.formData.bzjhFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjKyqk(res) {
      this.formData.kyqkFj = res.data;
    },
    // 文件移除时清空附件
    removeFjKyqk() {
      this.formData.kyqkFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjRyky(res) {
      this.formData.rykyFj = res.data;
    },
    // 文件移除时清空附件
    removeFjRyky() {
      this.formData.rykyFj = { url: "", fileName: "" };
    },
    // 请求负责人信息
    requirePersonInfo() {
      this.$http.get(`/api/baseservice/jzg/education/${this.gh}`).then(res => {
        let data = res.data.data;
        if (!data) {
          console.error("教职工信息数据获取失败");
          return false;
        }
        this.personInfo = data;
      });
    },
    // 请求课程性质列表
    requireKtxzList() {
      this.$http.get(`/api/system/dict/select/kcxz`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("课程性质列表数据获取失败");
          return false;
        }
        this.ktxzList = data;
      });
    },
    // 请求专业列表
    requireZyList() {
      this.$http.get(`/api/system/dict/select/education/major`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.zyList = data;
      });
    },
    handleZySelectChange(val) {
      this.zyList.forEach(el => {
        if (val === el.value) {
          this.formData.zy = el.label;
        }
      });
    },
    // 表单校验
    testForm() {
      let sign = true,
        data = this.formData,
        testKey = ["ktmc", "ktxz", "zym", "xwxz", "zy"];
      testKey.forEach(key => {
        if (data[key] === "") {
          sign = false;
        }
      });
      // 校验本课程的主要特色
      if (data.zytsFj.url === "" && data.zyts === "") {
        sign = false;
      }
      // 校验项目预期达到的建设目标
      if (data.jsmbFj.url === "" && data.jsmb === "") {
        sign = false;
      }
      // 校验项目课程建设主要内容
      if (data.zynrFj.url === "" && data.zynr === "") {
        sign = false;
      }
      // 校验项目本课程的建设目标、步骤、课程资源上网计划等
      if (data.bzjhFj.url === "" && data.bzjh === "") {
        sign = false;
      }
      // 校验项目课程负责人的教学和科研情况（附近三年科研成果清单）
      if (data.kyqkFj.url === "" && data.kyqk === "") {
        sign = false;
      }
      // 校验项目主要参加人员的教学和科研情况（附近三年科研成果清单）
      if (data.rykyFj.url === "" && data.ryky === "") {
        sign = false;
      }
      console.log(data);
      return sign;
    },
    // 提交表单数据
    handleSubmit() {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/education/curriculum", {
          ...this.formData,
          xmId: this.xmId
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("申请成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 更新表单数据
    handleUpdate(executionId) {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "修改中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put(`/api/education/curriculum/${executionId}`, this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    },
    gh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>
<style lang="scss" scoped>
.projectAddForKCALKJSXM {
  .title {
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
    }
    td.indent {
      padding-left: 10px;
    }
    .el-radio {
      margin-right: 14px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
}
</style>
