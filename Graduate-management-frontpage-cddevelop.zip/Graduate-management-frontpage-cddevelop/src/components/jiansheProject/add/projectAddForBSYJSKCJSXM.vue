<template>
  <div class="projectAddForBSYJSKCJSXM">
    <div class="title">
      浙江财经大学研究生 · 博士研究生课程建设项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>课程名称</td>
          <td class="no-indent">
            <el-input
              v-model="formData.kcmc"
              placeholder="请输入"
              :maxlength="50"
            ></el-input>
          </td>
          <td>课程性质</td>
          <td>
            <el-select v-model="formData.kcxz" placeholder="请选择">
              <el-option
                v-for="(item, index) in kcxzList"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </td>
        </tr>
        <tr>
          <td>所属专业</td>
          <td class="no-indent">
            <el-select
              v-model="formData.zym"
              filterable
              placeholder="请输入关键词"
              @change="handleZySelectChange"
            >
              <el-option
                v-for="(item, index) in zyList"
                :key="index"
                :label="`${item.label}(${item.value})`"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </td>
          <td>计划开设时间</td>
          <td>
            <el-date-picker
              v-model="formData.kssj"
              type="date"
              prefix-icon="el-icon-date"
              placeholder="选择日期"
              style="width:100%"
              :picker-options="pickerOptionsStart"
              :editable="false"
            >
            </el-date-picker>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <table class="charge-man">
        <tr>
          <td>姓名</td>
          <td>
            {{ `${personInfo.xm}(${personInfo.gh})` }}
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.xbm | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>任教年限</td>
          <td>
            {{ personInfo.rjnx }}
          </td>
          <td>是否博导</td>
          <td>
            <span v-if="personInfo.dslb">{{
              personInfo.dslb === 1 ? "硕导" : "博导"
            }}</span>
            <span v-else>未知</span>
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ personInfo.ssyxmc }}
          </td>
          <td>职务</td>
          <td>
            {{ personInfo.zw }}
          </td>
        </tr>
        <tr>
          <td>职称</td>
          <td>
            {{ personInfo.zc }}
          </td>
          <td>最后学位</td>
          <td>
            {{ personInfo.zhxw }}
          </td>
        </tr>
        <tr>
          <td>研究方向</td>
          <td>
            {{ personInfo.yjfx }}
          </td>
          <td>联系电话</td>
          <td>
            {{ personInfo.yddh }}
          </td>
        </tr>
        <tr>
          <td>电子信箱</td>
          <td colspan="3">
            {{ personInfo.dzyx }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="主要参加者">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td style="width:200px">姓名</td>
          <td>职务</td>
          <td>职称</td>
          <td>研究方向</td>
          <td>所属学院或单位</td>
          <td>联系电话</td>
          <td width="50px">操作</td>
        </tr>
        <tr v-for="(item, index) of formData.cjzxx" :key="index">
          <td class="no-indent">
            <el-select
              v-model="item.zdjsgh"
              filterable
              remote
              placeholder="请输入关键词"
              :remote-method="requireTeacherList"
              :loading="loading"
              @change="
                zdjsgh => {
                  handleCjzxxChange(zdjsgh, index);
                }
              "
            >
              <el-option
                v-for="(item, index) in teacherList"
                :key="index"
                :label="`${item.zdjsxm}(${item.zdjsgh})`"
                :value="item.zdjsgh"
              >
              </el-option>
            </el-select>
          </td>
          <td>{{ item.zw }}</td>
          <td>
            {{ item.zc }}
          </td>
          <td>
            {{ item.yjfx }}
          </td>
          <td>
            {{ item.ssyxmc }}
          </td>
          <td>
            {{ item.yddh }}
          </td>
          <td>
            <reduce-btn
              @click.native="clickReduceRowForCjzxx"
              v-if="index !== 0"
            ></reduce-btn>
            <add-btn @click.native="clickAddRowForCjzxx" v-else></add-btn>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="相关任教课程">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td>课程名称</td>
          <td>任教教师</td>
          <td>授课时间</td>
          <td width="50px">操作</td>
        </tr>
        <tr v-for="(item, index) of formData.rjkcxx" :key="index">
          <td class="no-indent">
            <el-select
              v-model="item.kch"
              filterable
              remote
              placeholder="请输入关键词"
              :remote-method="requireCourseList"
              :loading="loading"
              @change="
                kch => {
                  handleCourseSelectChange(kch, index);
                }
              "
            >
              <el-option
                v-for="(val, ind) in courseList"
                :key="ind"
                :label="`${val.kcmc}(${val.kch})`"
                :value="val.kch"
              >
              </el-option>
            </el-select>
          </td>
          <td>
            <el-select v-model="item.teacher.id" placeholder="请选择">
              <el-option
                v-for="(val, ind) of courseTeacherList[index].teacherVOList"
                :key="ind"
                :label="val.jsxm"
                :value="val.id"
              >
              </el-option>
            </el-select>
          </td>
          <td>
            <span v-html="courseDetailList[index]"></span>
          </td>
          <td>
            <reduce-btn
              @click.native="clickReduceRowForRjkcxx"
              v-if="index !== 0"
            ></reduce-btn>
            <add-btn @click.native="clickAddRowForRjkcxx" v-else></add-btn>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="立项依据">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.lxyjFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjLxyj"
            :on-remove="removeFjLxyj"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.lxyjFj.url"
            target="_blank"
            class="primary"
            :download="formData.lxyjFj.fileName"
            >{{ formData.lxyjFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjLxyj"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span>拟建设课程的建设意义、前期已开展的相关工作等 </span>
          <el-input
            v-model="formData.lxyj"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="建设方案">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jsfaFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJsfa"
            :on-remove="removeFjJsfa"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jsfaFj.url"
            target="_blank"
            class="primary"
            :download="formData.jsfaFj.fileName"
            >{{ formData.jsfaFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjJsfa"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span>拟建设课程的教学内容、教学方法、实践环节、进度安排等</span>
          <el-input
            v-model="formData.jsfa"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="建设目标与成果">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jsmbFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJsmb"
            :on-remove="removeFjJsmb"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jsmbFj.url"
            target="_blank"
            class="primary"
            :download="formData.jsmbFj.fileName"
            >{{ formData.jsmbFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjJsmb"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span>拟建设课程的预期成果及教学计划等</span>
          <el-input
            v-model="formData.jsmb"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
import reduceBtn from "@/components/common/reduceBtn";
import addBtn from "@/components/common/addBtn";
export default {
  name: "projectAddForBSYJSKCJSXM",
  components: {
    "project-card": projectCard,
    "reduce-btn": reduceBtn,
    "add-btn": addBtn
  },
  props: {
    xmId: {}
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      formData: null,
      zyList: [],
      kcxzList: [],
      teacherList: [],
      courseList: [],
      getPath: "jiansheProject/getFormDataForBSYJSKCJSXM",
      clearPath: "jiansheProject/clearFormDataForBSYJSKCJSXM",
      updatePath: "jiansheProject/updateFormDataForBSYJSKCJSXM",
      loading: false,
      personInfo: {
        csrq: "",
        dslb: "",
        dzyx: "",
        gh: "",
        hdny: "",
        rjnx: "",
        ssyxh: "",
        ssyxmc: "",
        xbm: "",
        xm: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zhxw: "",
        zw: ""
      },
      statusMap: {
        "1": "星期一",
        "2": "星期二",
        "3": "星期三",
        "4": "星期四",
        "5": "星期五",
        "6": "星期六",
        "7": "星期日"
      },
      pickerOptionsStart: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() < new Date().getTime() - 86400000;
        }
      }
    };
  },
  mounted() {
    // 请求个人信息
    this.requirePersonInfo();
    // 请求课程性质列表
    this.requireKcxzList();
    // 请求专业列表
    this.requireZyList();
    // 请求教师工列表
    this.requireTeacherList("");
    // 请求课程列表
    this.requireCourseList("");
  },
  methods: {
    // 接收的上传名称和地址
    receiveFjJsfa(res) {
      this.formData.jsfaFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJsfa() {
      this.formData.jsfaFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjJsmb(res) {
      this.formData.jsmbFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJsmb() {
      this.formData.jsmbFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjLxyj(res) {
      this.formData.lxyjFj = res.data;
    },
    // 文件移除时清空附件
    removeFjLxyj() {
      this.formData.lxyjFj = { url: "", fileName: "" };
    },
    clickAddRowForCjzxx() {
      this.formData.cjzxx.push({
        dzyx: "",
        ssyxh: "",
        ssyxmc: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zdjsgh: "",
        zdjsxm: "",
        zw: ""
      });
    },
    clickReduceRowForCjzxx() {
      this.formData.cjzxx.pop();
    },
    clickAddRowForRjkcxx() {
      this.formData.rjkcxx.push({
        kch: "",
        kcmc: "",
        teacher: {
          gh: "",
          id: "",
          jsxm: "",
          sksjList: [
            {
              id: "",
              kj: "",
              pksjid: "",
              sfmz: "",
              skdd: "",
              xq: "",
              zc: ""
            }
          ]
        }
      });
    },
    clickReduceRowForRjkcxx() {
      this.formData.rjkcxx.pop();
    },
    testForm() {
      let sign = true,
        data = this.formData,
        testKey = ["kcmc", "zy", "zym", "kcxz", "kssj"];
      testKey.forEach(key => {
        if (data[key] === "") {
          sign = false;
        }
      });
      //  建设方案
      if (data.jsfaFj.url === "" && data.jsfa === "") {
        sign = false;
      }
      // 建设目标与成果
      if (data.jsmbFj.url === "" && data.jsmb === "") {
        sign = false;
      }
      //  立项依据
      if (data.lxyjFj.url === "" && data.lxyj === "") {
        sign = false;
      }
      // 参加者信息验证
      this.formData.cjzxx.forEach(el => {
        if (el.zdjsgh === "") {
          sign = false;
        }
      });
      // 任教课程信息验证
      this.formData.rjkcxx.forEach(el => {
        if (!sign) {
          return;
        }
        if (el.kch === "") {
          sign = false;
          return;
        }
        if (el.teacher.id === "") {
          sign = false;
        }
      });
      return sign;
    },
    // 提交表单数据
    handleSubmit() {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      let tmpObj = { ...this.formData };
      tmpObj.rjkcxx = tmpObj.rjkcxx.map((el, index) => {
        return {
          kch: el.kch,
          kcmc: el.kcmc,
          teacher: this.courseTeacherList[index].teacherVOList.find(obj => {
            return obj.id === el.teacher.id;
          })
        };
      });
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/education/doctoral", {
          ...tmpObj,
          xmId: this.xmId
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("申请成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 更新表单数据
    handleUpdate(executionId) {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      let tmpObj = { ...this.formData };
      tmpObj.rjkcxx = tmpObj.rjkcxx.map((el, index) => {
        return {
          kch: el.kch,
          kcmc: el.kcmc,
          teacher: this.courseTeacherList[index].teacherVOList.find(obj => {
            return obj.id === el.teacher.id;
          })
        };
      });
      const loading = this.$loading({
        lock: true,
        text: "修改中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put(`/api/education/doctoral/${executionId}`, tmpObj)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    handleCjzxxChange(zdjsgh, index) {
      let tmpObj = this.teacherList.find(el => el.zdjsgh === zdjsgh);
      Object.keys(tmpObj).forEach(key => {
        this.formData.cjzxx[index][key] = tmpObj[key];
      });
    },
    handleCourseSelectChange(kch, index) {
      this.formData.rjkcxx[index].teacher.id = "";
      let tmpObj = this.courseList.find(el => el.kch === kch);
      if (tmpObj) {
        this.formData.rjkcxx[index].kcmc = tmpObj.kcmc;
      }
    },
    requireCourseList(query) {
      this.$http
        .get(`/api/cultivate/kc/selectForEduSearch`, {
          params: {
            query
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("课程列表数据获取失败");
            return false;
          }
          this.courseList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求教职工列表
    requireTeacherList(query) {
      console.log(query);
      this.loading = true;
      this.$http
        .get(`/api/baseservice/jzg/education/search`, {
          params: {
            query
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (!Array.isArray(data)) {
            console.error("教职工列表数据获取失败");
            return false;
          }
          this.teacherList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求负责人信息
    requirePersonInfo() {
      this.$http.get(`/api/baseservice/jzg/education/${this.gh}`).then(res => {
        let data = res.data.data;
        if (!data) {
          console.error("教职工信息数据获取失败");
          return false;
        }
        this.personInfo = data;
      });
    },
    // 请求课程性质列表
    requireKcxzList() {
      this.$http.get(`/api/system/dict/select/kcxz`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("课程性质列表数据获取失败");
          return false;
        }
        this.kcxzList = data;
      });
    },
    // 请求专业列表
    requireZyList() {
      this.$http.get(`/api/system/dict/select/education/major`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.zyList = data;
      });
    },
    handleZySelectChange(val) {
      this.zyList.forEach(el => {
        if (val === el.value) {
          this.formData.zy = el.label;
        }
      });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  destroyed() {
    this.handleClear();
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    },
    gh() {
      return this.$store.getters.getXH;
    },
    courseTeacherList() {
      let tmpArr = this.formData.rjkcxx.map(item => {
        let tmpObj = this.courseList.find(obj => {
          return obj.kch === item.kch;
        });
        if (!tmpObj) {
          tmpObj = {};
        }
        return tmpObj;
      });
      return tmpArr;
    },
    courseDetailList() {
      let tmpArr = this.formData.rjkcxx.map(item => {
        let tmpObj = this.courseList.find(obj => {
          return obj.kch === item.kch;
        });
        if (!tmpObj) {
          return null;
        }
        tmpObj = tmpObj.teacherVOList.find(el => {
          return el.id === item.teacher.id;
        });
        if (!tmpObj) {
          return null;
        }
        return tmpObj.sksjList
          .map(el => {
            return `${el.zc}周（${
              el.sfmz === 1 ? "每周" : el.sfmz === 2 ? "单周" : "双周"
            }） ${this.statusMap[el.xq]} ${el.kj}节`;
          })
          .join("<br/>");
      });
      return tmpArr.filter(el => el);
    }
  }
};
</script>
<style lang="scss" scoped>
.projectAddForBSYJSKCJSXM {
  .title {
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
      padding: 0;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
}
</style>
