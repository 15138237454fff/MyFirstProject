<template>
  <div class="conclusionAddForSSYJSKCJSXM">
    <div class="title">
      浙江财经大学研究生 · 硕士研究生课程建设项目结题
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>课题名称</td>
          <td>
            {{ projectInfo.ktmc }}
          </td>
          <td>
            所属专业
          </td>
          <td>
            {{ projectInfo.zy }}
          </td>
        </tr>
        <tr>
          <td>课程性质</td>
          <td>
            {{ projectInfo.ktxz }}
          </td>
          <td>学位性质</td>
          <td>
            {{ projectInfo.xwxz === 1 ? "学科学位" : "专业学位" }}
          </td>
        </tr>
        <tr>
          <td>负责人姓名</td>
          <td>
            {{ `${projectInfo.xm}(${projectInfo.gh})` }}
          </td>
          <td>联系电话</td>
          <td>
            {{ projectInfo.yddh }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card
      title="建设目标、内容与申报时的《硕士研究生课程建设申报表》是否相符"
    >
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.sfxfFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjSfxf"
            :on-remove="removeFjSfxf"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.sfxfFj.url"
            target="_blank"
            class="primary"
            :download="formData.sfxfFj.fileName"
            >{{ formData.sfxfFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjSfxf"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >立项时《硕士研究生课程建设申报表》确定了哪些要完成的目标，现在目标完成情况。如有目标未完成，请说明原因。</span
          >
          <el-input
            v-model="formData.sfxfNr"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card
      title="该课程项目的进展和完成情况、取得的成果和效果（不够可加附页，限4000字）"
    >
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.qdcgFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjQdcg"
            :on-remove="removeFjQdcg"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.qdcgFj.url"
            target="_blank"
            class="primary"
            :download="formData.qdcgFj.fileName"
            >{{ formData.qdcgFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjQdcg"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span> 1.师资队伍；</span>
          <span>2.课程教学大纲、教材、教学案例库和参考文献库；</span>
          <span>3.教学范式改革；</span>
          <span>4.教学方法和教学辅助手段；</span>
          <span>5.实践环节和其他教学环节设计等。不够可加页，限4000字</span>
          <el-input
            v-model="formData.qdcgNr"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="课程建设经费的使用情况">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jfsyqkFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJfsyqk"
            :on-remove="removeFjJfsyqk"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jfsyqkFj.url"
            target="_blank"
            class="primary"
            :download="formData.jfsyqkFj.fileName"
            >{{ formData.jfsyqkFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjJfsyqk"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >购买或复制的教学参考资料目录，购置的教学辅助设备和仪器，编写讲义或教材、举办教学研讨会、国内调研差旅费、成果鉴定费等方面的经费支出等。</span
          >
          <el-input
            v-model="formData.jfsyqkNr"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "conclusionAddForSSYJSKCJSXM",
  components: {
    "project-card": projectCard
  },
  props: {
    xmId: {},
    lcid: {}
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      formData: {},
      projectInfo: {
        gh: "",
        ktmc: "",
        ktxz: "",
        xm: "",
        xwxz: "",
        yddh: "",
        zy: ""
      },
      getPath: "jiansheProject/getFormDataIsConclusionForSSYJSKCJSXM",
      clearPath: "jiansheProject/clearFormDataIsConclusionForSSYJSKCJSXM",
      updatePath: "jiansheProject/updateFormDataIsConclusionForSSYJSKCJSXM"
    };
  },
  mounted() {
    this.requireProjectInfo();
  },
  methods: {
    // 接收的上传名称和地址
    receiveFjJfsyqk(res) {
      this.formData.jfsyqkFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJfsyqk() {
      this.formData.jfsyqkFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjQdcg(res) {
      this.formData.qdcgFj = res.data;
    },
    // 文件移除时清空附件
    removeFjQdcg() {
      this.formData.qdcgFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjSfxf(res) {
      this.formData.sfxfFj = res.data;
    },
    // 文件移除时清空附件
    removeFjSfxf() {
      this.formData.sfxfFj = { url: "", fileName: "" };
    },
    requireProjectInfo() {
      this.$http
        .get(`/api/education/curriculum/conclusion/${this.lcid}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          console.log(data);
          this.projectInfo = data.data;
        });
    },
    testForm() {
      let sign = true,
        data = this.formData;
      //  课程建设经费的使用情况
      if (data.jfsyqkFj.url === "" && data.jfsyqkNr === "") {
        sign = false;
      }
      // 该课程项目的进展和完成情况、取得的成果和效果
      if (data.qdcgFj.url === "" && data.qdcgNr === "") {
        sign = false;
      }
      //  建设目标、内容与申报时的《硕士研究生课程建设申报表》是否相符
      if (data.sfxfFj.url === "" && data.sfxfNr === "") {
        sign = false;
      }
      return sign;
    },
    // 提交表单数据
    handleSubmit() {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      let tmpObj = { ...this.formData };
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/education/classEstablish/apply", {
          ...tmpObj,
          xmId: this.xmId,
          lcid: this.lcid
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("申请成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 更新表单数据
    handleUpdate(executionId) {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "修改中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let tmpObj = { ...this.formData };
      this.$http
        .put(`/api/education/classEstablish/${executionId}`, tmpObj)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAddForSSYJSKCJSXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-weight: bold;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }

    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
    .el-input-number {
      width: 120px;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
}
</style>
