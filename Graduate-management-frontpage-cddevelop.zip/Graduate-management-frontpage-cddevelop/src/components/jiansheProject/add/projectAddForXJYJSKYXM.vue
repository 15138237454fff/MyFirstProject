<template>
  <div class="projectAddForXJYJSKYXM">
    <div class="title">
      浙江财经大学研究生 · 校级研究生科研项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>项目名称</td>
          <td>
            <el-input
              v-model="formData.xmmc"
              placeholder="请输入"
              :maxlength="50"
            ></el-input>
          </td>
        </tr>
        <tr>
          <td>主题词</td>
          <td>
            <el-input
              v-model="formData.ztc"
              placeholder="请输入"
              :maxlength="50"
            ></el-input>
          </td>
        </tr>
        <tr>
          <td>预期成果</td>
          <td class="indent">
            <el-checkbox-group v-model="formData.yqcg">
              <el-checkbox
                v-for="(item, index) of resultType"
                :key="index"
                :label="item.value"
                >{{ item.label }}</el-checkbox
              >
            </el-checkbox-group>
          </td>
        </tr>
        <tr>
          <td>论文字数</td>
          <td>
            <el-input-number
              v-model="formData.lwzs"
              controls-position="right"
              :min="0"
              :max="50"
              :precision="2"
            ></el-input-number>
            <span style="padding-left:5px">万</span>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <table class="charge-man">
        <tr>
          <td>负责人</td>
          <td>
            <span v-if="personInfo.name">{{
              `${personInfo.name}(${personInfo.studentNumber})`
            }}</span>
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.sex | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ personInfo.collegeName }}
          </td>
          <td>所学专业</td>
          <td>
            {{ personInfo.majorName }}
          </td>
        </tr>
        <tr>
          <td>入学年份</td>
          <td>
            {{ personInfo.grade }}
          </td>
          <td>联系电话</td>
          <td>
            {{ personInfo.phone }}
          </td>
        </tr>
        <tr>
          <td>项目指导教师</td>
          <td class="no-indent">
            <el-select
              v-model="formData.zdjsgh"
              filterable
              remote
              placeholder="请输入关键词"
              :remote-method="requireTeacherList"
              :loading="loading"
            >
              <el-option
                v-for="(item, index) in teacherList"
                :key="index"
                :label="`${item.zdjsxm}(${item.zdjsgh})`"
                :value="item.zdjsgh"
              >
              </el-option>
            </el-select>
          </td>
          <td>指导教师职称</td>
          <td>
            {{ selectedTeacherObj.zc }}
          </td>
        </tr>
        <tr>
          <td>指导教师研究方向</td>
          <td colspan="3">
            {{ selectedTeacherObj.dzyx }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="项目组成员">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>性别</td>
          <td>所在学院</td>
          <td>所学专业</td>
          <td>联系电话</td>
          <td width="50px">操作</td>
        </tr>
        <tr v-for="(item, index) of formData.xmzxx" :key="index">
          <td class="no-indent">
            <el-select
              v-model="item.studentNumber"
              remote
              placeholder="请输入关键词"
              :remote-method="requireStudentList"
              :loading="loading"
              @change="
                studentNumber => {
                  handleXmzxxChange(studentNumber, index);
                }
              "
              filterable
            >
              <el-option
                v-for="(obj, ind) in studentList"
                :key="ind"
                :label="`${obj.name}(${obj.studentNumber})`"
                :value="obj.studentNumber"
              >
              </el-option>
            </el-select>
          </td>
          <td>{{ item.sex | sexFilter }}</td>
          <td>
            {{ item.collegeName }}
          </td>
          <td>
            {{ item.majorName }}
          </td>
          <td>
            {{ item.phone }}
          </td>
          <td>
            <reduce-btn
              @click.native="clickReduceRow"
              v-if="index !== 0"
            ></reduce-btn>
            <add-btn @click.native="clickAddRow" v-else></add-btn>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="项目设计论证">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.sjlzFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjSjlz"
            :on-remove="removeFjSjlz"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.sjlzFj.url"
            target="_blank"
            class="primary"
            :download="formData.sjlzFj.fileName"
            >{{ formData.sjlzFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px;"
            @click="removeFjSjlz"
          ></span>
        </template>
      </div>
      <div class="project-design">
        <div>
          <span>
            项目研究的基本思路、主要内容、理论与实际意义、创新之处和预期成果（不超过1500字）。</span
          >
          <el-input
            v-model="formData.sjlzNr"
            placeholder="请输入"
            type="textarea"
            :maxlength="1500"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="经费使用计划">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <span class="totalMoney">总计申请经费：{{ sumMoney.toFixed(2) }}元</span>
      </div>
      <table class="project-plan-coast">
        <tr>
          <td>资料费（元）</td>
          <td>调研差旅费（元）</td>
          <td>计算机使用费（元）</td>
          <td>其它费用（元）</td>
          <td>文印费（元）</td>
          <td>备注说明</td>
        </tr>
        <tr>
          <td>
            <el-input-number
              v-model="formData.jfZl"
              controls-position="right"
              :min="0"
              :max="1000000"
              :precision="2"
            ></el-input-number>
          </td>
          <td>
            <el-input-number
              v-model="formData.jfCl"
              controls-position="right"
              :min="0"
              :max="1000000"
              :precision="2"
            ></el-input-number>
          </td>
          <td>
            <el-input-number
              v-model="formData.jfJsjsy"
              controls-position="right"
              :min="0"
              :max="1000000"
              :precision="2"
            ></el-input-number>
          </td>
          <td>
            <el-input-number
              v-model="formData.jfQa"
              controls-position="right"
              :min="0"
              :max="1000000"
              :precision="2"
            ></el-input-number>
          </td>
          <td>
            <el-input-number
              v-model="formData.jfWy"
              controls-position="right"
              :min="0"
              :max="1000000"
              :precision="2"
            ></el-input-number>
          </td>
          <td>
            <el-input
              v-model="formData.jfBz"
              placeholder="请输入"
              :maxlength="100"
            ></el-input>
          </td>
        </tr>
      </table>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
import reduceBtn from "@/components/common/reduceBtn";
import addBtn from "@/components/common/addBtn";
export default {
  name: "projectAddForXJYJSKYXM",
  components: {
    "project-card": projectCard,
    "reduce-btn": reduceBtn,
    "add-btn": addBtn
  },
  props: {
    xmId: {}
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      getPath: "jiansheProject/getFormDataForXJYJSKYXM",
      clearPath: "jiansheProject/clearFormDataForXJYJSKYXM",
      updatePath: "jiansheProject/updateFormDataForXJYJSKYXM",
      // 教职工列表
      teacherList: [],
      studentList: [],
      formData: null,
      loading: false,
      personInfo: {
        birthDate: "",
        collegeName: "",
        collegeNum: "",
        email: "",
        grade: "",
        majorName: "",
        majorNum: "",
        name: "",
        phone: "",
        sex: "",
        studentNumber: "",
        tasks: "",
        trainingLevel: "",
        trainingLevelNum: ""
      },
      resultType: [
        { label: "论文", value: 1 },
        { label: "专著", value: 2 },
        { label: "译著", value: 3 },
        { label: "研究报告", value: 4 },
        { label: "工具书", value: 5 },
        { label: "电脑软件", value: 6 }
      ]
    };
  },
  mounted() {
    // 请求个人信息
    this.requirePersonInfo();
    // 请求学生列表
    this.requireStudentList("");
    // 请求教师列表
    this.requireTeacherList("");
  },
  methods: {
    // 接收的上传名称和地址
    receiveFjSjlz(res) {
      this.formData.sjlzFj = res.data;
    },
    // 文件移除时清空附件
    removeFjSjlz() {
      this.formData.sjlzFj = { url: "", fileName: "" };
    },
    clickAddRow() {
      this.formData.xmzxx.push({
        // 院系所名称
        collegeName: "",
        // 院系所号
        collegeNum: "",
        // 专业名称
        majorName: "",
        // 专业代码
        majorNum: "",
        // 姓名
        name: "",
        // 联系电话
        phone: "",
        // 性别
        sex: "",
        // 学号
        studentNumber: "",
        // 承担任务
        tasks: "",
        // 培养层次
        trainingLevel: "",
        // 培养层次
        trainingLevelNum: ""
      });
    },
    clickReduceRow() {
      this.formData.xmzxx.pop();
    },
    // 项目下拉选改变
    handleXmzxxChange(val, index) {
      let tmpObj = this.studentList.find(el => el.studentNumber === val);
      Object.keys(tmpObj).forEach(key => {
        this.formData.xmzxx[index][key] = tmpObj[key];
      });
    },
    // 请求学生列表
    requireStudentList(query) {
      this.loading = true;
      this.$http
        .get(`/api/baseservice/stu/education/search`, {
          params: {
            query
          }
        })
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (!Array.isArray(data)) {
            console.error("学生列表数据获取失败");
            return false;
          }
          this.studentList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求教职工列表
    requireTeacherList(query) {
      this.loading = true;
      this.$http
        .get(`/api/baseservice/jzg/education/search`, {
          params: {
            query
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (!Array.isArray(data)) {
            console.error("教职工列表数据获取失败");
            return false;
          }
          this.teacherList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求负责人信息
    requirePersonInfo() {
      this.$http
        .get(`/api/baseservice/stu/education/search`, {
          params: {
            query: this.xh
          }
        })
        .then(res => {
          let data = res.data;
          if (!Array.isArray(data)) {
            console.error("学生列表数据获取失败");
            return false;
          }
          this.personInfo = data[0];
        });
    },
    testForm() {
      let sign = true,
        data = this.formData,
        testKey = ["jfBz", "xmmc", "ztc", "lwzs", "zdjsgh"];
      testKey.forEach(key => {
        if (data[key] === "") {
          sign = false;
        }
      });
      console.log(data);
      //  项目设计论证
      if (data.sjlzFj.url === "" && data.sjlzNr === "") {
        sign = false;
      }
      // 项目组信息验证
      this.formData.xmzxx.forEach(el => {
        if (el.studentNumber === "") {
          sign = false;
        }
      });
      // 预期成果验证
      if (this.formData.yqcg.length === 0) {
        sign = false;
      }
      return sign;
    },
    // 提交表单数据
    handleSubmit() {
      this.formData.jfZj = this.sumMoney;
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/education/university", {
          ...this.formData,
          xmId: this.xmId
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("申请成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 更新表单数据
    handleUpdate(executionId) {
      this.formData.jfZj = this.sumMoney;
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "修改中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put(`/api/education/university/${executionId}`, this.formData)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    // 离开页面时清空数据
    this.handleClear();
  },
  computed: {
    sumMoney() {
      let { jfZl, jfWy, jfQa, jfJsjsy, jfCl } = this.formData;
      return -(0 - jfWy - jfQa - jfZl - jfJsjsy - jfCl);
    },
    storeFormData() {
      return this.$store.getters[this.getPath];
    },
    selectedTeacherObj() {
      let tmp = this.teacherList.find(el => el.zdjsgh === this.formData.zdjsgh);
      if (tmp === undefined) {
        return {};
      } else {
        return tmp;
      }
    },
    xh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>
<style lang="scss" scoped>
.projectAddForXJYJSKYXM {
  .title {
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
    box-sizing: border-box;
  }
  .el-input,
  .el-select {
    width: 100%;
  }
  .project-info {
    td:first-child {
      width: 200px;
      background: #f5f5f5;
    }
    td:last-child {
      padding: 0;
    }
    td.indent {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
    .no-indent {
      padding: 0;
    }
  }
  .project-design {
    & > div {
      display: flex;
      flex-direction: column;
      margin-bottom: 14px;
      span {
        line-height: 30px;
      }
    }
  }
  .totalMoney {
    font-weight: normal;
  }
  .project-plan-coast {
    td {
      text-align: center;
      &:not(:last-child) {
        width: 160px;
      }
      &:last-child {
        padding: 0;
      }
    }
    .el-input-number {
      width: 140px;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
}
</style>
