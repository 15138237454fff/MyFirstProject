<template>
  <div class="projectAddForKCALKJSXM">
    <div class="title">
      浙江财经大学研究生 · 专业学位研究生课程案例库建设项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr class="display-none">
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td>案例名称</td>
          <td colspan="3">
            <el-input
              v-model="formData.almc"
              placeholder="请输入"
              :maxlength="2000"
            ></el-input>
          </td>
        </tr>
        <tr>
          <td>适用课程</td>
          <td class="no-indent">
            <el-select
              v-model="formData.kcdm"
              filterable
              remote
              placeholder="请输入关键词"
              :remote-method="requireCourseList"
              :loading="loading"
              @change="handleCourseSelectChange"
            >
              <el-option
                v-for="(val, ind) in courseList"
                :key="ind"
                :label="`${val.kcmc}(${val.kch})`"
                :value="val.kch"
              >
              </el-option>
            </el-select>
          </td>
          <td>建设起止时间</td>
          <td>
            <el-date-picker
              v-model="computedTime"
              type="daterange"
              prefix-icon="el-icon-date"
              placeholder="选择日期时间"
              style="width:100%"
              :editable="false"
            >
            </el-date-picker>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jxcgFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJxcg"
            :on-remove="removeFjJxcg"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jxcgFj.url"
            target="_blank"
            class="primary"
            :download="formData.jxcgFj.fileName"
            >{{ formData.jxcgFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjJxcg"
          ></span>
        </template>
      </div>
      <table class="charge-man">
        <tr>
          <td>姓名</td>
          <td>
            {{ `${personInfo.xm}(${personInfo.gh})` }}
          </td>
          <td>所属专业</td>
          <td class="no-indent">
            <el-select
              v-model="formData.zym"
              filterable
              placeholder="请输入关键词"
              @change="handleZySelectChange"
            >
              <el-option
                v-for="(item, index) in zyList"
                :key="index"
                :label="`${item.label}(${item.value})`"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </td>
        </tr>
        <tr>
          <td>职称</td>
          <td>
            {{ personInfo.zc }}
          </td>
          <td>研究方向</td>
          <td>
            {{ personInfo.yjfx }}
          </td>
        </tr>
      </table>

      <div class="textarea-area">
        <div>
          <span>负责人主要教学经历（授课名称、起止时间等）和教学成果</span>
          <el-input
            v-model="formData.jxcg"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="成员情况">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.cyjxcgFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjCyjxcg"
            :on-remove="removeFjCyjxcg"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.cyjxcgFj.url"
            target="_blank"
            class="primary"
            :download="formData.cyjxcgFj.fileName"
            >{{ formData.cyjxcgFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjCyjxcg"
          ></span>
        </template>
      </div>
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>所属专业</td>
          <td>研究方向</td>
          <td>主要负责内容</td>
          <td width="50px">操作</td>
        </tr>
        <tr v-for="(item, index) of formData.cyxx" :key="index">
          <td class="no-indent">
            <el-select
              v-model="item.zdjsgh"
              filterable
              remote
              placeholder="请输入关键词"
              :remote-method="requireTeacherList"
              :loading="loading"
              @change="
                zdjsgh => {
                  handleCyxxChange(zdjsgh, index);
                }
              "
            >
              <el-option
                v-for="(item, index) in teacherList"
                :key="index"
                :label="`${item.zdjsxm}(${item.zdjsgh})`"
                :value="item.zdjsgh"
              >
              </el-option>
            </el-select>
          </td>
          <td>
            <el-select
              v-model="item.zym"
              filterable
              placeholder="请输入关键词"
              @change="
                zym => {
                  handleCyxxZySelectChange(zym, index);
                }
              "
            >
              <el-option
                v-for="(item, index) in zyList"
                :key="index"
                :label="`${item.label}(${item.value})`"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </td>
          <td>
            {{ formData.yjfx }}
          </td>
          <td>
            <el-input
              v-model="item.responsible"
              placeholder="请输入"
              :maxlength="100"
            ></el-input>
          </td>
          <td>
            <reduce-btn
              @click.native="clickReduceRow"
              v-if="index !== 0"
            ></reduce-btn>
            <add-btn @click.native="clickAddRow" v-else></add-btn>
          </td>
        </tr>
      </table>

      <div class="textarea-area">
        <div>
          <span>
            项目组成员的教学经历和教学成果（主讲的研究生课程、编写的教材、获奖情况等）</span
          >
          <el-input
            v-model="formData.cyjxcg"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="立项依据">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.lxyjFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjLxyj"
            :on-remove="removeFjLxyj"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.lxyjFj.url"
            target="_blank"
            class="primary"
            :download="formData.lxyjFj.fileName"
            >{{ formData.lxyjFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjLxyj"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >项目建设的意义；国内外建设概况、发展趋势；案例的应用前景及实用价值；前期已开展的相关工作。</span
          >
          <el-input
            v-model="formData.lxyj"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="建设方案">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jsfaFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJsfa"
            :on-remove="removeFjJsfa"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jsfaFj.url"
            target="_blank"
            class="primary"
            :download="formData.jsfaFj.fileName"
            >{{ formData.jsfaFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjJsfa"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >拟建设的相关案例内容、重点、特色、创新性、教学效果及教学价值；建设计划及进度安排。</span
          >
          <el-input
            v-model="formData.jsfa"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="建设目标与成果">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.jscgFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjJscg"
            :on-remove="removeFjJscg"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.jscgFj.url"
            target="_blank"
            class="primary"
            :download="formData.jscgFj.fileName"
            >{{ formData.jscgFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjJscg"
          ></span>
        </template>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >项目建设拟达成的目标，预期成果及形式，案例库的教学应用计划等。</span
          >
          <el-input
            v-model="formData.jscg"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
import reduceBtn from "@/components/common/reduceBtn";
import addBtn from "@/components/common/addBtn";
export default {
  name: "projectAddForKCALKJSXM",
  components: {
    "project-card": projectCard,
    "reduce-btn": reduceBtn,
    "add-btn": addBtn
  },
  props: {
    xmId: {}
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      formData: {},
      teacherList: [],
      courseList: [],
      zyList: [],
      loading: false,
      personInfo: {
        dzyx: "",
        gh: "",
        rjnx: "",
        sfbd: 0,
        ssyxh: "",
        ssyxmc: "",
        xm: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zhxw: "",
        zw: ""
      },
      getPath: "jiansheProject/getFormDataForKCALKJSXM",
      clearPath: "jiansheProject/clearFormDataForKCALKJSXM",
      updatePath: "jiansheProject/updateFormDataForKCALKJSXM",
      pickerOptionsEnd: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() > new Date().getTime();
        }
      },
      pickerOptionsStart: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() < new Date().getTime() - 86400000;
        }
      }
    };
  },
  mounted() {
    // 请求课程列表
    this.requireCourseList("");
    // 请求个人信息
    this.requirePersonInfo();
    // 请求专业列表
    this.requireZyList();
    // 请求教师列表
    this.requireTeacherList("");
  },
  methods: {
    // 接收的上传名称和地址
    receiveFjCyjxcg(res) {
      this.formData.cyjxcgFj = res.data;
    },
    // 文件移除时清空附件
    removeFjCyjxcg() {
      this.formData.cyjxcgFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjJxcg(res) {
      this.formData.jxcgFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJxcg() {
      this.formData.jxcgFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjLxyj(res) {
      this.formData.lxyjFj = res.data;
    },
    // 文件移除时清空附件
    removeFjLxyj() {
      this.formData.lxyjFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjJsfa(res) {
      this.formData.jsfaFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJsfa() {
      this.formData.jsfaFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjJscg(res) {
      this.formData.jscgFj = res.data;
    },
    // 文件移除时清空附件
    removeFjJscg() {
      this.formData.jscgFj = { url: "", fileName: "" };
    },
    clickAddRow() {
      this.formData.cyxx.push({
        dzyx: "",
        ssyxh: "",
        ssyxmc: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zdjsgh: "",
        zdjsxm: "",
        zw: "",
        zy: "",
        zym: "",
        responsible: ""
      });
    },
    clickReduceRow() {
      this.formData.cyxx.pop();
    },
    testForm() {
      let sign = true,
        data = this.formData,
        testKey = ["almc", "kcdm", "kcmc", "kssj", "zy", "zym"];
      testKey.forEach(key => {
        if (data[key] === "") {
          sign = false;
        }
      });
      console.log(this.formData);
      //  负责人主要教学经历（授课名称、起止时间等）和教学成果
      if (data.jxcgFj.url === "" && data.jxcg === "") {
        sign = false;
      }
      // 项目组成员的教学经历和教学成果（主讲的研究生课程、编写的教材、获奖情况等）
      if (data.cyjxcgFj.url === "" && data.cyjxcg === "") {
        sign = false;
      }
      //  立项依据
      if (data.lxyjFj.url === "" && data.lxyj === "") {
        sign = false;
      }
      //  建设方案
      if (data.jscgFj.url === "" && data.jscg === "") {
        sign = false;
      }
      //  建设目标与成果
      if (data.jsfaFj.url === "" && data.jsfa === "") {
        sign = false;
      }
      // 成员信息验证
      this.formData.cyxx.forEach(el => {
        if (el.zy === "" || el.zym === "") {
          sign = false;
        }
        if (el.responsible === "") {
          sign = false;
        }
        if (el.zdjsgh === "") {
          sign = false;
        }
      });

      return sign;
    },
    handleCyxxChange(zdjsgh, index) {
      let tmpObj = this.teacherList.find(el => el.zdjsgh === zdjsgh);
      Object.keys(tmpObj).forEach(key => {
        this.formData.cyxx[index][key] = tmpObj[key];
      });
    },
    // 提交表单数据
    handleSubmit() {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      let tmpObj = { ...this.formData };
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post("/api/education/casebase", {
          ...tmpObj,
          xmId: this.xmId
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("申请成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 更新表单数据
    handleUpdate(executionId) {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      let tmpObj = { ...this.formData };
      const loading = this.$loading({
        lock: true,
        text: "修改中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .put(`/api/education/casebase/${executionId}`, tmpObj)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    requireCourseList(query) {
      this.$http
        .get(`/api/cultivate/kc/selectForEduSearch`, {
          params: {
            query
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("课程列表数据获取失败");
            return false;
          }
          this.courseList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求教职工列表
    requireTeacherList(query) {
      console.log(query);
      this.loading = true;
      this.$http
        .get(`/api/baseservice/jzg/education/search`, {
          params: {
            query
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data;
          if (!Array.isArray(data)) {
            console.error("教职工列表数据获取失败");
            return false;
          }
          this.teacherList = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求负责人信息
    requirePersonInfo() {
      this.$http.get(`/api/baseservice/jzg/education/${this.gh}`).then(res => {
        let data = res.data.data;
        if (!data) {
          console.error("教职工信息数据获取失败");
          return false;
        }
        this.personInfo = data;
      });
    },
    // 请求专业列表
    requireZyList() {
      this.$http.get(`/api/system/dict/select/education/major`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("专业列表数据获取失败");
          return false;
        }
        this.zyList = data;
      });
    },
    handleZySelectChange(val) {
      this.zyList.forEach(el => {
        if (val === el.value) {
          this.formData.zy = el.label;
        }
      });
    },
    handleCyxxZySelectChange(val, index) {
      this.zyList.forEach(el => {
        if (val === el.value) {
          this.formData.cyxx[index].zy = el.label;
        }
      });
    },
    handleCourseSelectChange(val) {
      let tmpObj = this.courseList.find(el => {
        return el.kch === val;
      });
      if (!tmpObj) {
        return;
      }
      this.formData.kcmc = tmpObj.kcmc;
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    },
    gh() {
      return this.$store.getters.getXH;
    },
    computedTime: {
      get() {
        return [this.formData.kssj, this.formData.jssj];
      },
      set(arr) {
        if (arr === null) {
          arr = ["", ""];
        }
        this.formData.kssj = arr[0];
        this.formData.jssj = arr[1];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.projectAddForKCALKJSXM {
  .title {
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
    }
  }
  .charge-man {
    margin-bottom: 14px;
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
    td.no-indent {
      padding-left: 0;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
  .group-man {
    margin-bottom: 14px;
    td {
      text-align: center;
      padding: 0;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .display-none {
    td {
      visibility: hidden;
      height: 0px;
    }
  }
}
</style>
