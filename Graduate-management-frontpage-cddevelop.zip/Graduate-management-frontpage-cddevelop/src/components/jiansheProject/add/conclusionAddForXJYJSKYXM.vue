<template>
  <div class="conclusionAddForXJYJSKYXM">
    <div class="title">
      浙江财经大学研究生 · 校级科研项目结题
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>课题名称</td>
          <td>
            {{ projectInfo.xmmc }}
          </td>
        </tr>
        <tr>
          <td>负责人</td>
          <td>
            {{ `${projectInfo.xm}(${projectInfo.xh})` }}
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ projectInfo.yxsmc }}
          </td>
        </tr>
        <tr>
          <td>所学专业</td>
          <td>
            {{ projectInfo.zy }}
          </td>
        </tr>
        <tr>
          <td>年级</td>
          <td>
            {{ projectInfo.sznj }}
          </td>
        </tr>
        <tr>
          <td>联系电话</td>
          <td>
            {{ projectInfo.yddh }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="主要参加者">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>性别</td>
          <td>所在学院</td>
          <td>所学专业</td>
          <td>联系电话</td>
        </tr>
        <tr v-for="(item, index) of projectInfo.xmzxx" :key="index">
          <td>
            {{ `${item.name}(${item.studentNumber})` }}
          </td>
          <td>{{ item.sex | sexFilter }}</td>
          <td>
            {{ item.collegeName }}
          </td>
          <td>
            {{ item.majorName }}
          </td>
          <td>{{ item.phone }}</td>
        </tr>
      </table>
    </project-card>
    <project-card title="研究过程中进行的工作">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.yjgcgzFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjYjgcgz"
            :on-remove="removeFjYjgcgz"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.yjgcgzFj.url"
            target="_blank"
            class="primary"
            :download="formData.yjgcgzFj.fileName"
            >{{ formData.yjgcgzFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjYjgcgz"
          ></span>
        </template>
      </div>
      <div class="project-design">
        <div>
          <span>调研、搜集材料、学术讨论、征求意见等情况</span>
          <el-input
            v-model="formData.yjgcgzNr"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
    <project-card title="成果发表">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td>刊物论著名称</td>
          <td>发表时间</td>
          <td width="120px">卷期号</td>
          <td width="120px">本人排序</td>
          <td>采用情况及反映</td>
          <td>备注</td>
          <td width="50px">操作</td>
        </tr>
        <tr v-for="(item, index) of formData.cgfb" :key="index">
          <td>
            <el-input
              v-model="item.paperName"
              placeholder="请输入"
              :maxlength="50"
            ></el-input>
          </td>
          <td>
            <el-date-picker
              v-model="item.publishTime"
              type="date"
              prefix-icon="el-icon-date"
              placeholder="选择日期"
              style="width:100%"
              :editable="false"
            >
            </el-date-picker>
          </td>
          <td>
            <el-input
              v-model="item.journalNumber"
              placeholder="请输入"
              :maxlength="20"
            ></el-input>
          </td>
          <td style="width:120px;">
            <el-input
              v-model="item.sort"
              placeholder="请输入"
              :maxlength="20"
            ></el-input>
          </td>
          <td>
            <el-input
              v-model="item.feedback"
              placeholder="请输入"
              :maxlength="100"
            ></el-input>
          </td>
          <td>
            <el-input
              v-model="item.remark"
              placeholder="请输入"
              :maxlength="100"
            ></el-input>
          </td>
          <td>
            <reduce-btn
              @click.native="clickReduceRow"
              v-if="index !== 0"
            ></reduce-btn>
            <add-btn @click.native="clickAddRow" v-else></add-btn>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="研究工作总结">
      <span slot="tag" class="required"></span>
      <div slot="btn">
        <template v-if="formData.yjgzzjFj.url === ''">
          <el-upload
            class="upload-demo"
            action="/api/system/upload"
            :limit="1"
            :on-success="receiveFjYjgzzj"
            :on-remove="removeFjYjgzzj"
            ref="upload"
            :headers="headers"
          >
            <el-button
              size="large"
              type="primary"
              :plain="true"
              style="padding:10px"
              >上传附件</el-button
            >
          </el-upload>
        </template>
        <template v-else>
          <a
            :href="formData.yjgzzjFj.url"
            target="_blank"
            class="primary"
            :download="formData.yjgzzjFj.fileName"
            >{{ formData.yjgzzjFj.fileName }}</a
          >
          <span
            class="el-icon-circle-close cursor-pointer"
            style="margin-left:5px"
            @click="removeFjYjgzzj"
          ></span>
        </template>
      </div>
      <div class="project-design">
        <div>
          <span
            >成果提出的新观点、新方案、研究中突破的难点，成果的社会效益，经济效益，存在的不足之处等</span
          >
          <el-input
            v-model="formData.yjgzzjNr"
            placeholder="请输入"
            type="textarea"
            :maxlength="2000"
            :autosize="{ minRows: 6, maxRows: 8 }"
          ></el-input>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
import reduceBtn from "@/components/common/reduceBtn";
import addBtn from "@/components/common/addBtn";
export default {
  name: "conclusionAddForXJYJSKYXM",
  components: {
    "project-card": projectCard,
    "reduce-btn": reduceBtn,
    "add-btn": addBtn
  },
  props: {
    xmId: {},
    lcid: {}
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      formData: {},
      projectInfo: {
        sznj: "",
        xh: "",
        xm: "",
        xmmc: "",
        xmzxx: [
          {
            birthDate: "",
            collegeName: "",
            collegeNum: "",
            email: "",
            grade: "",
            majorName: "",
            majorNum: "",
            name: "",
            phone: "",
            sex: "",
            studentNumber: "",
            tasks: "",
            trainingLevel: "",
            trainingLevelNum: ""
          }
        ],
        yddh: "",
        yxsmc: "",
        zy: ""
      },
      getPath: "jiansheProject/getFormDataIsConclusionForXJYJSKYXM",
      clearPath: "jiansheProject/clearFormDataIsConclusionForXJYJSKYXM",
      updatePath: "jiansheProject/updateFormDataIsConclusionForXJYJSKYXM"
    };
  },
  mounted() {
    this.requireProjectInfo();
  },
  methods: {
    // 接收的上传名称和地址
    receiveFjYjgcgz(res) {
      this.formData.yjgcgzFj = res.data;
    },
    // 文件移除时清空附件
    removeFjYjgcgz() {
      this.formData.yjgcgzFj = { url: "", fileName: "" };
    },
    // 接收的上传名称和地址
    receiveFjYjgzzj(res) {
      this.formData.yjgzzjFj = res.data;
    },
    // 文件移除时清空附件
    removeFjYjgzzj() {
      this.formData.yjgzzjFj = { url: "", fileName: "" };
    },
    clickAddRow() {
      this.formData.cgfb.push({
        feedback: "",
        journalNumber: "",
        paperName: "",
        publishTime: "",
        remark: "",
        sort: ""
      });
    },
    clickReduceRow() {
      this.formData.cgfb.pop();
    },
    requireProjectInfo() {
      this.$http
        .get(`/api/education/university/conclusion/${this.lcid}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          console.log(data);
          this.projectInfo = data.data;
        });
    },
    testForm() {
      let sign = true,
        data = this.formData;
      // 项目组信息验证
      this.formData.cgfb.forEach(el => {
        Object.keys(el).forEach(key => {
          if (el[key] === "") {
            sign = false;
          }
        });
      });
      // 研究过程中进行的工作(文本)--调研、搜集材料、学术讨论、征求意见等情况
      if (data.yjgcgzFj.url === "" && data.yjgcgzNr === "") {
        sign = false;
      }
      // 研究工作总结(文本)--成果提出的新观点、新方案、研究中突破的难点，成果的社会效益，经济效益，存在的不足之处等
      if (data.yjgzzjFj.url === "" && data.yjgzzjNr === "") {
        sign = false;
      }
      return sign;
    },
    // 提交表单数据
    handleSubmit() {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let tmpObj = { ...this.formData };
      this.$http
        .post("/api/education/universityTask/apply", {
          ...tmpObj,
          xmId: this.xmId,
          lcid: this.lcid
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("申请成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 更新表单数据
    handleUpdate(executionId) {
      // 获取表单校验结果
      let result = this.testForm();
      if (!result) {
        this.$message.error("请填写完整后再尝试提交");
        return;
      }
      const loading = this.$loading({
        lock: true,
        text: "修改中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let tmpObj = { ...this.formData };
      this.$http
        .put(`/api/education/universityTask/${executionId}`, tmpObj)
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success("修改成功");
          this.$router.go(-1);
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAddForXJYJSKYXM {
  .title {
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
    box-sizing: border-box;
  }
  .project-info {
    td:first-child {
      width: 200px;
      background: #f5f5f5;
    }
    td:last-child {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }

    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
      padding: 0;
    }
    tr:first-child {
      background: #f5f5f5;
    }
    .el-input-number {
      width: 120px;
    }
  }
  .project-design {
    & > div {
      display: flex;
      flex-direction: column;
      margin-bottom: 14px;
      span {
        line-height: 30px;
      }
    }
  }
  .totalMoney {
    font-weight: normal;
  }
  .project-plan-coast {
    td {
      text-align: center;
      &:not(:last-child) {
        width: 120px;
      }
    }
    .el-input-number {
      width: 120px;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
}
</style>
