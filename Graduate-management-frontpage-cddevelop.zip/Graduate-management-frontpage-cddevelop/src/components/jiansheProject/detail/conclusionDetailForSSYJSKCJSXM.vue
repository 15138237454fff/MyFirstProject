<template>
  <div class="conclusionDetailForSSYJSKCJSXM">
    <div class="title">
      浙江财经大学研究生 · 硕士研究生课程建设项目结题
    </div>
    <project-card title="项目基本信息">
      <table class="project-info">
        <tr>
          <td>课题名称</td>
          <td>
            {{ projectInfo.ktmc }}
          </td>
          <td>
            所属专业
          </td>
          <td>
            {{ projectInfo.zy }}
          </td>
        </tr>
        <tr>
          <td>课程性质</td>
          <td>
            {{ $getListValue(projectInfo.ktxz, this.kcxzList) }}
          </td>
          <td>学位性质</td>
          <td>
            {{ projectInfo.xwxz === 1 ? "学科学位" : "专业学位" }}
          </td>
        </tr>
        <tr>
          <td>负责人姓名</td>
          <td>
            {{ `${projectInfo.xm}(${projectInfo.gh})` }}
          </td>
          <td>联系电话</td>
          <td>
            {{ projectInfo.yddh }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card
      title="建设目标、内容与申报时的《硕士研究生课程建设申报表》是否相符"
    >
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.sfxfFj.url !== ''">
        <a
          :href="formData.sfxfFj.url"
          target="_blank"
          class="primary"
          :download="formData.sfxfFj.fileName"
          >{{ formData.sfxfFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >立项时《硕士研究生课程建设申报表》确定了哪些要完成的目标，现在目标完成情况。如有目标未完成，请说明原因。</span
          >
          <div class="content-box">{{ formData.sfxfNr }}</div>
        </div>
      </div>
    </project-card>
    <project-card
      title="该课程项目的进展和完成情况、取得的成果和效果（不够可加附页，限4000字）"
    >
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.qdcgFj.url !== ''">
        <a
          :href="formData.qdcgFj.url"
          target="_blank"
          class="primary"
          :download="formData.qdcgFj.fileName"
          >{{ formData.qdcgFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span> 1.师资队伍；</span>
          <span>2.课程教学大纲、教材、教学案例库和参考文献库；</span>
          <span>3.教学范式改革；</span>
          <span>4.教学方法和教学辅助手段；</span>
          <span>5.实践环节和其他教学环节设计等。不够可加页，限4000字</span>
          <div class="content-box">{{ formData.qdcgNr }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="课程建设经费的使用情况">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jfsyqkFj.url !== ''">
        <a
          :href="formData.jfsyqkFj.url"
          target="_blank"
          class="primary"
          :download="formData.jfsyqkFj.fileName"
          >{{ formData.jfsyqkFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span
            >购买或复制的教学参考资料目录，购置的教学辅助设备和仪器，编写讲义或教材、举办教学研讨会、国内调研差旅费、成果鉴定费等方面的经费支出等。</span
          >
          <div class="content-box">{{ formData.jfsyqkNr }}</div>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "conclusionDetailForSSYJSKCJSXM",
  components: {
    "project-card": projectCard
  },
  props: {
    lcid: {}
  },
  data() {
    return {
      formData: {},
      kcxzList: [],
      projectInfo: {
        gh: "",
        ktmc: "",
        ktxz: "",
        xm: "",
        xwxz: "",
        yddh: "",
        zy: ""
      },
      getPath: "jiansheProject/getFormDataIsConclusionForSSYJSKCJSXM",
      clearPath: "jiansheProject/clearFormDataIsConclusionForSSYJSKCJSXM"
    };
  },
  mounted() {
    this.requireProjectInfo();
    // 请求课程性质列表
    this.requireKcxzList();
  },
  methods: {
    requireProjectInfo() {
      this.$http
        .get(`/api/education/curriculum/conclusion/${this.lcid}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          console.log(data);
          this.projectInfo = data.data;
        });
    },
    // 请求课程性质列表
    requireKcxzList() {
      this.$http.get(`/api/system/dict/select/kcxz`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("课程性质列表数据获取失败");
          return false;
        }
        this.kcxzList = data;
      });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionDetailForSSYJSKCJSXM {
  .title {
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }

    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
    .el-input-number {
      width: 120px;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    white-space: pre-wrap;
    border: 1px solid #ccc;
  }
}
</style>
