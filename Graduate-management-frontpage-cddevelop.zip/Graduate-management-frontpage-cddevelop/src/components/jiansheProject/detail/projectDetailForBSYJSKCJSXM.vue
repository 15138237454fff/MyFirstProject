<template>
  <div class="projectDetailForBSYJSKCJSXM">
    <div class="title">
      浙江财经大学研究生 · 博士研究生课程建设项目
    </div>
    <project-card title="项目基本信息">
      <span slot="tag" class="required"></span>
      <table class="project-info">
        <tr>
          <td>课程名称</td>
          <td>
            {{ formData.kcmc }}
          </td>
          <td>课程性质</td>
          <td>
            {{ $getListValue(formData.kcxz, this.kcxzList) }}
          </td>
        </tr>
        <tr>
          <td>所属专业</td>
          <td>
            {{ `${formData.zy}(${formData.zym})` }}
          </td>
          <td>计划开设时间</td>
          <td>
            {{ $tagTime(formData.kssj, "yyyy-MM-dd") }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <span slot="tag" class="required"></span>
      <table class="charge-man">
        <tr>
          <td>姓名</td>
          <td>
            {{ `${personInfo.xm}(${personInfo.gh})` }}
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.xbm | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>任教年限</td>
          <td>
            {{ personInfo.rjnx }}
          </td>
          <td>是否博导</td>
          <td>
            <span v-if="personInfo.dslb">{{
              personInfo.dslb === 1 ? "硕导" : "博导"
            }}</span>
            <span v-else>未知</span>
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ personInfo.ssyxmc }}
          </td>
          <td>职务</td>
          <td>
            {{ personInfo.zw }}
          </td>
        </tr>
        <tr>
          <td>职称</td>
          <td>
            {{ personInfo.zc }}
          </td>
          <td>最后学位</td>
          <td>
            {{ personInfo.zhxw }}
          </td>
        </tr>
        <tr>
          <td>研究方向</td>
          <td>
            {{ personInfo.yjfx }}
          </td>
          <td>联系电话</td>
          <td>
            {{ personInfo.yddh }}
          </td>
        </tr>
        <tr>
          <td>电子信箱</td>
          <td colspan="3">
            {{ personInfo.dzyx }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="主要参加者">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>职务</td>
          <td>职称</td>
          <td>研究方向</td>
          <td>所属学院或单位</td>
          <td>联系电话</td>
        </tr>
        <tr v-for="(item, index) of formData.cjzxx" :key="index">
          <td>
            {{ `${item.zdjsxm}(${item.zdjsgh})` }}
          </td>
          <td>{{ item.zw }}</td>
          <td>
            {{ item.zc }}
          </td>
          <td>
            {{ item.yjfx }}
          </td>
          <td>
            {{ item.ssyxmc }}
          </td>
          <td>
            {{ item.yddh }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="相关任教课程">
      <span slot="tag" class="required"></span>
      <table class="group-man">
        <tr>
          <td>课程名称</td>
          <td>任教教师</td>
          <td>授课时间</td>
        </tr>
        <tr v-for="(item, index) of formData.rjkcxx" :key="index">
          <td>
            {{ `${item.kcmc}(${item.kch})` }}
          </td>
          <td>
            {{ item.teacher && item.teacher.jsxm }}
          </td>
          <td>
            <span v-html="courseDetailList[index]"></span>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="立项依据">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.lxyjFj.url !== ''">
        <a
          :href="formData.lxyjFj.url"
          target="_blank"
          class="primary"
          :download="formData.lxyjFj.fileName"
          >{{ formData.lxyjFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span>拟建设课程的建设意义、前期已开展的相关工作等 </span>
          <div class="content-box">{{ formData.lxyj }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="建设方案">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jsfaFj.url !== ''">
        <a
          :href="formData.jsfaFj.url"
          target="_blank"
          class="primary"
          :download="formData.jsfaFj.fileName"
          >{{ formData.jsfaFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span>拟建设课程的教学内容、教学方法、实践环节、进度安排等</span>
          <div class="content-box">{{ formData.jsfa }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="建设目标与成果">
      <span slot="tag" class="required"></span>
      <div slot="btn" v-if="formData.jsmbFj.url !== ''">
        <a
          :href="formData.jsmbFj.url"
          target="_blank"
          class="primary"
          :download="formData.jsmbFj.fileName"
          >{{ formData.jsmbFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="textarea-area">
        <div>
          <span>拟建设课程的预期成果及教学计划等</span>
          <div class="content-box">{{ formData.jsmb }}</div>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "projectDetailForBSYJSKCJSXM",
  components: {
    "project-card": projectCard
  },
  data() {
    return {
      formData: {},
      kcxzList: [],
      getPath: "jiansheProject/getFormDataForBSYJSKCJSXM",
      clearPath: "jiansheProject/clearFormDataForBSYJSKCJSXM",
      updatePath: "jiansheProject/updateFormDataForBSYJSKCJSXM",
      personInfo: {
        csrq: "",
        dslb: "",
        dzyx: "",
        gh: "",
        hdny: "",
        rjnx: "",
        ssyxh: "",
        ssyxmc: "",
        xbm: "",
        xm: "",
        yddh: "",
        yjfx: "",
        zc: "",
        zhxw: "",
        zw: ""
      },
      statusMap: {
        "1": "星期一",
        "2": "星期二",
        "3": "星期三",
        "4": "星期四",
        "5": "星期五",
        "6": "星期六",
        "7": "星期日"
      },
      pickerOptionsStart: {
        disabledDate: date => {
          if (!date) {
            return false;
          }
          return date.getTime() < new Date().getTime() - 86400000;
        }
      }
    };
  },
  mounted() {
    // 请求课程性质列表
    this.requireKcxzList();
  },
  methods: {
    // 请求负责人信息
    requirePersonInfo() {
      this.$http
        .get(`/api/baseservice/jzg/education/${this.formData.gh}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("教职工信息数据获取失败");
            return false;
          }
          this.personInfo = data;
        });
    },
    // 请求课程性质列表
    requireKcxzList() {
      this.$http.get(`/api/system/dict/select/kcxz`).then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          console.error("课程性质列表数据获取失败");
          return false;
        }
        this.kcxzList = data;
      });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
        if (this.formData.gh !== "") {
          this.requirePersonInfo();
        }
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    },
    courseDetailList() {
      let tmpArr = this.formData.rjkcxx.map(item => {
        if (!item.teacher) {
          return null;
        }
        return item.teacher.sksjList
          .map(el => {
            return `${el.zc}周（${
              el.sfmz === 1 ? "每周" : el.sfmz === 2 ? "单周" : "双周"
            }） ${this.statusMap[el.xq]} ${el.kj}节`;
          })
          .join("<br/>");
      });
      return tmpArr.filter(el => el);
    }
  }
};
</script>
<style lang="scss" scoped>
.projectDetailForBSYJSKCJSXM {
  .title {
    text-align: center;
    font-weight: bold;
    margin-bottom: 20px;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
      padding: 0;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .textarea-area {
    div {
      display: flex;
      flex-direction: column;
      span {
        line-height: 30px;
      }
    }
    div:not(:last-child) {
      margin-bottom: 14px;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    white-space: pre-wrap;
    border: 1px solid #ccc;
  }
}
</style>
