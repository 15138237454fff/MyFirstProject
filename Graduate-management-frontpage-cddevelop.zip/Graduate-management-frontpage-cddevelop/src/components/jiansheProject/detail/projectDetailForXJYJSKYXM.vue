<template>
  <div class="projectAddForXJYJSKYXM">
    <div class="title">
      浙江财经大学研究生 · 校级研究生科研项目
    </div>
    <project-card title="项目基本信息">
      <table class="project-info">
        <tr>
          <td>项目名称</td>
          <td>
            {{ formData.xmmc }}
          </td>
        </tr>
        <tr>
          <td>主题词</td>
          <td>
            {{ formData.ztc }}
          </td>
        </tr>
        <tr>
          <td>预期成果</td>
          <td style="text-align:left">
            <span v-if="Array.isArray(formData.yqcg)">{{
              formData.yqcg
                .map(el => {
                  return this.$getListValue(el, this.resultType);
                })
                .join("，")
            }}</span>
          </td>
        </tr>
        <tr>
          <td>论文字数</td>
          <td>
            {{ formData.lwzs }}
            <span>万</span>
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <table class="charge-man">
        <tr>
          <td>负责人</td>
          <td>
            <span v-if="personInfo.name">{{
              `${personInfo.name}(${personInfo.studentNumber})`
            }}</span>
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.sex | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ personInfo.collegeName }}
          </td>
          <td>所学专业</td>
          <td>
            {{ personInfo.majorName }}
          </td>
        </tr>
        <tr>
          <td>入学年份</td>
          <td>
            {{ personInfo.grade }}
          </td>
          <td>联系电话</td>
          <td>
            {{ personInfo.phone }}
          </td>
        </tr>
        <tr>
          <td>项目指导教师</td>
          <td class="no-indent">
            {{ `${teacherInfo.zdjsxm}(${teacherInfo.zdjsgh})` }}
          </td>
          <td>指导教师职称</td>
          <td>
            {{ teacherInfo.zc }}
          </td>
        </tr>
        <tr>
          <td>指导教师研究方向</td>
          <td colspan="3">
            {{ teacherInfo.dzyx }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="项目组成员">
      <!-- <span slot="tag" class="required"></span> -->
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>性别</td>
          <td>所在学院</td>
          <td>所学专业</td>
          <td>联系电话</td>
        </tr>
        <tr v-for="(item, index) of formData.xmzxx" :key="index">
          <td>
            {{ `${item.name}(${item.studentNumber})` }}
          </td>
          <td>{{ item.sex | sexFilter }}</td>
          <td>
            {{ item.collegeName }}
          </td>
          <td>
            {{ item.majorName }}
          </td>
          <td>
            {{ item.phone }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="项目设计论证">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.sjlzFj.url !== ''">
        <a
          :href="formData.sjlzFj.url"
          target="_blank"
          class="primary"
          :download="formData.sjlzFj.fileName"
          >{{ formData.sjlzFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="project-design">
        <div>
          <span>
            项目研究的基本思路、主要内容、理论与实际意义、创新之处和预期成果（不超过1500字）。</span
          >
          <div class="content-box">{{ formData.sjlzNr }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="经费使用计划">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn">
        <span class="totalMoney">总计申请经费：{{ sumMoney.toFixed(2) }}元</span>
      </div>
      <table class="project-plan-coast">
        <tr>
          <td>资料费（元）</td>
          <td>调研差旅费（元）</td>
          <td>计算机使用费（元）</td>
          <td>其它费用（元）</td>
          <td>文印费（元）</td>
          <td>备注说明</td>
        </tr>
        <tr>
          <td>
            {{ formData.jfZl }}
          </td>
          <td>
            {{ formData.jfCl }}
          </td>
          <td>
            {{ formData.jfJsjsy }}
          </td>
          <td>
            {{ formData.jfQa }}
          </td>
          <td>
            {{ formData.jfWy }}
          </td>
          <td>
            {{ formData.jfBz }}
          </td>
        </tr>
      </table>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "projectAddForXJYJSKYXM",
  components: {
    "project-card": projectCard
  },
  data() {
    return {
      getPath: "jiansheProject/getFormDataForXJYJSKYXM",
      clearPath: "jiansheProject/clearFormDataForXJYJSKYXM",
      updatePath: "jiansheProject/updateFormDataForXJYJSKYXM",
      // 教职工列表
      teacherList: [],
      studentList: [],
      formData: null,
      loading: false,
      personInfo: {
        birthDate: "",
        collegeName: "",
        collegeNum: "",
        email: "",
        grade: "",
        majorName: "",
        majorNum: "",
        name: "",
        phone: "",
        sex: "",
        studentNumber: "",
        tasks: "",
        trainingLevel: "",
        trainingLevelNum: ""
      },
      teacherInfo: {
        zc: "",
        dzyx: "",
        zdjsxm: "",
        zdjsgh: ""
      },
      resultType: [
        { label: "论文", value: 1 },
        { label: "专著", value: 2 },
        { label: "译著", value: 3 },
        { label: "研究报告", value: 4 },
        { label: "工具书", value: 5 },
        { label: "电脑软件", value: 6 }
      ]
    };
  },
  mounted() {
    this.formData = this.$store.getters[this.getPath];
  },
  methods: {
    // 请求教职工列表
    requireTeacherInfo() {
      this.loading = true;
      this.$http
        .get(`/api/baseservice/jzg/education/search`, {
          params: {
            query: this.formData.zdjsgh
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data[0];
          if (!data) {
            console.error("教职工数据获取失败");
            return false;
          }
          this.teacherInfo = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求负责人信息
    requirePersonInfo() {
      this.$http
        .get(`/api/baseservice/stu/education/search`, {
          params: {
            query: this.formData.xh
          }
        })
        .then(res => {
          let data = res.data[0];
          if (!data) {
            console.error("学生数据获取失败");
            return false;
          }
          this.personInfo = data;
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  destroyed() {
    this.handleClear();
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
        if (this.formData.xh !== "") {
          this.requirePersonInfo();
        }
        if (this.formData.zdjsgh !== "") {
          this.requireTeacherInfo();
        }
      },
      immediate: true,
      deep: true
    }
  },
  computed: {
    sumMoney() {
      let { jfZl, jfWy, jfQa, jfJsjsy, jfCl } = this.formData;
      return -(0 - jfWy - jfQa - jfZl - jfJsjsy - jfCl);
    },
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.projectAddForXJYJSKYXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .project-info {
    td:first-child {
      width: 200px;
      background: #f5f5f5;
    }
    td:last-child {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .project-design {
    & > div {
      display: flex;
      flex-direction: column;
      margin-bottom: 14px;
      span {
        line-height: 30px;
      }
    }
  }
  .totalMoney {
    font-weight: normal;
  }
  .project-plan-coast {
    td {
      text-align: center;
      &:not(:last-child) {
        width: 120px;
      }
    }
    .el-input-number {
      width: 120px;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    word-break: break-all;
    border: 1px solid #ccc;
  }
}
</style>
