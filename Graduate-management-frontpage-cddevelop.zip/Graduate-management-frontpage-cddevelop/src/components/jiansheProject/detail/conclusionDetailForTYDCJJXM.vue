<template>
  <div class="conclusionDetailForTYDCJJXM">
    <div class="title">
      浙江财经大学研究生 · 田野调查基金项目结题
    </div>
    <project-card title="项目基本信息">
      <table class="project-info">
        <tr>
          <td>课题名称</td>
          <td>
            {{ projectInfo.ktmc }}
          </td>
        </tr>
        <tr>
          <td>负责人</td>
          <td>
            {{ `${projectInfo.xm}(${projectInfo.xh})` }}
          </td>
        </tr>
        <tr>
          <td>所在学院</td>
          <td>
            {{ projectInfo.yxsmc }}
          </td>
        </tr>
        <tr>
          <td>所学专业</td>
          <td>
            {{ projectInfo.zy }}
          </td>
        </tr>
        <tr>
          <td>所在年级</td>
          <td>
            {{ projectInfo.sznj }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="主要参加者">
      <table class="group-man">
        <tr>
          <td>姓名</td>
          <td>性别</td>
          <td>培养层次</td>
          <td>所在学院</td>
          <td>所学专业</td>
          <td>联系电话</td>
          <td>承担任务</td>
        </tr>
        <tr v-for="(item, index) of projectInfo.xmzxx" :key="index">
          <td>
            {{ `${item.name}(${item.studentNumber})` }}
          </td>
          <td>{{ item.sex | sexFilter }}</td>
          <td>
            {{ item.trainingLevel }}
          </td>
          <td>
            {{ item.collegeName }}
          </td>
          <td>
            {{ item.majorName }}
          </td>
          <td>{{ item.phone }}</td>
          <td>
            {{ item.tasks }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="项目实施情况总结">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.dcgzzjFj.url !== ''">
        <a
          :href="formData.dcgzzjFj.url"
          target="_blank"
          class="primary"
          :download="formData.dcgzzjFj.fileName"
          >{{ formData.dcgzzjFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="project-design">
        <div>
          <span>调查内容、调查方法、调查结论、征求意见等情况</span>
          <div class="content-box">{{ formData.dcgzzjNr }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="成果发表">
      <!-- <span slot="tag" class="required"></span> -->
      <table class="group-man">
        <tr>
          <td>刊物论著名称</td>
          <td>发表时间</td>
          <td width="120px">卷期号</td>
          <td width="120px">本人排序</td>
          <td>采用情况及反映</td>
          <td>备注</td>
        </tr>
        <tr v-for="(item, index) of formData.cgfb" :key="index">
          <td>
            {{ item.paperName }}
          </td>
          <td>
            {{ $tagTime(item.publishTime, "yyyy-MM-dd") }}
          </td>
          <td>
            {{ item.journalNumber }}
          </td>
          <td style="width:120px;">
            {{ item.sort }}
          </td>
          <td>
            {{ item.feedback }}
          </td>
          <td>
            {{ item.remark }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="调查工作总结">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.xmssqkzjFj.url !== ''">
        <a
          :href="formData.xmssqkzjFj.url"
          target="_blank"
          class="primary"
          :download="formData.xmssqkzjFj.fileName"
          >{{ formData.xmssqkzjFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="project-design">
        <div>
          <span
            >成果提出的新观点、新方案、研究中突破的难点，成果的社会效益，经济效益，存在的不足之处等</span
          >
          <div class="content-box">{{ formData.xmssqkzjNr }}</div>
        </div>
      </div>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";

export default {
  name: "conclusionDetailForTYDCJJXM",
  components: {
    "project-card": projectCard
  },
  props: {
    lcid: {}
  },
  data() {
    return {
      formData: {},
      projectInfo: {
        ktmc: "",
        sznj: "",
        xh: "",
        xm: "",
        xmzxx: [
          {
            birthDate: "",
            collegeName: "",
            collegeNum: "",
            email: "",
            grade: "",
            majorName: "",
            majorNum: "",
            name: "",
            phone: "",
            sex: "",
            studentNumber: "",
            tasks: "",
            trainingLevel: "",
            trainingLevelNum: ""
          }
        ],
        yxsmc: "",
        zy: ""
      },
      getPath: "jiansheProject/getFormDataIsConclusionForTYDCJJXM",
      clearPath: "jiansheProject/clearFormDataIsConclusionForTYDCJJXM",
      updatePath: "jiansheProject/updateFormDataIsConclusionForTYDCJJXM"
    };
  },
  mounted() {
    this.requireProjectInfo();
    console.log(this.formData);
  },
  methods: {
    requireProjectInfo() {
      this.$http
        .get(`/api/education/fieldwork/conclusion/${this.lcid}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.projectInfo = data.data;
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionDetailForTYDCJJXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .project-info {
    td:first-child {
      width: 200px;
      background: #f5f5f5;
    }
    td:last-child {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding: 0;
      padding-left: 10px;
    }

    td.no-indent {
      padding-left: 0;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
    .el-input-number {
      width: 120px;
    }
  }
  .project-design {
    & > div {
      display: flex;
      flex-direction: column;
      margin-bottom: 14px;
      span {
        line-height: 30px;
      }
    }
  }
  .totalMoney {
    font-weight: normal;
  }
  .project-plan-coast {
    td {
      text-align: center;
      &:not(:last-child) {
        width: 120px;
      }
    }
    .el-input-number {
      width: 120px;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    white-space: pre-wrap;
    border: 1px solid #ccc;
  }
}
</style>
