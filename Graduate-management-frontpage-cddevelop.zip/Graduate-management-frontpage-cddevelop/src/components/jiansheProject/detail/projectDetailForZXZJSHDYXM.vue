<template>
  <div class="projectAddForZXZJSHDYXM">
    <div class="title">
      浙江财经大学研究生 · 知行浙江社会调研项目
    </div>
    <project-card title="项目基本信息">
      <table class="project-info">
        <tr>
          <td>课题名称</td>
          <td>
            {{ formData.ktmc }}
          </td>
          <td>预期完成时间</td>
          <td>
            {{ $tagTime(formData.yjwcsj, "yyyy年MM月dd日") }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="负责人情况">
      <table class="charge-man">
        <tr>
          <td>负责人</td>
          <td class="no-indent">
            <span v-if="personInfo.name">{{
              `${personInfo.name}(${personInfo.studentNumber})`
            }}</span>
          </td>
          <td>性别</td>
          <td>
            {{ personInfo.sex | sexFilter }}
          </td>
        </tr>
        <tr>
          <td>出生年月</td>
          <td>
            {{ $tagTime(personInfo.birthDate, "yyyy年MM月dd日") }}
          </td>
          <td>联系电话</td>
          <td>
            {{ personInfo.phone }}
          </td>
        </tr>
        <tr>
          <td>电子信箱</td>
          <td>
            {{ personInfo.email }}
          </td>
          <td>所在学院</td>
          <td>
            {{ personInfo.collegeName }}
          </td>
        </tr>
        <tr>
          <td>所学专业</td>
          <td>
            {{ personInfo.majorName }}
          </td>
          <td>项目指导教师</td>
          <td class="no-indent">
            {{ `${teacherInfo.zdjsxm}(${teacherInfo.zdjsgh})` }}
          </td>
        </tr>
        <tr>
          <td>指导教师联系电话</td>
          <td>
            {{ teacherInfo.yddh }}
          </td>
          <td>通讯地址</td>
          <td>
            {{ formData.zdjsdz }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="项目组成员">
      <!-- <span slot="tag" class="required"></span> -->
      <table class="group-man">
        <tr>
          <td style="width:200px">姓名</td>
          <td style="width:80px">性别</td>
          <td>培养层次</td>
          <td>所在学院</td>
          <td>所学专业</td>
          <td>联系电话</td>
          <td>承担任务</td>
        </tr>
        <tr v-for="(item, index) of formData.xmzxx" :key="index">
          <td class="no-indent">
            {{ `${item.name}(${item.studentNumber})` }}
          </td>
          <td>{{ item.sex | sexFilter }}</td>
          <td>
            {{ item.trainingLevel }}
          </td>
          <td>
            {{ item.collegeName }}
          </td>
          <td>
            {{ item.majorName }}
          </td>
          <td>
            {{ item.phone }}
          </td>
          <td>
            {{ item.tasks }}
          </td>
        </tr>
      </table>
    </project-card>
    <project-card title="申报活动主要内容简介（限500字）">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.jjfj.url !== ''">
        <a
          :href="formData.jjfj.url"
          target="_blank"
          class="primary"
          :download="formData.jjfj.fileName"
          >{{ formData.jjfj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.nrjj }}</div>
    </project-card>
    <project-card title="项目设计论证">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.sjlzFj.url !== ''">
        <a
          :href="formData.sjlzFj.url"
          target="_blank"
          class="primary"
          :download="formData.sjlzFj.fileName"
          >{{ formData.sjlzFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>

      <div class="project-design">
        <div>
          <span>1. 选题：本社会调研活动的选题背景和意义</span>
          <div class="content-box">{{ formData.sjlzXt }}</div>
        </div>
        <div>
          <span
            >2.
            内容：本调研项目的主要内容、调研方法、任务分工、组织管理和活动流程</span
          >
          <div class="content-box">{{ formData.sjlzNr }}</div>
        </div>
        <div>
          <span> 3. 预期价值：本社会调研活动的预期价值和效益</span>
          <div class="content-box">{{ formData.sjlzJz }}</div>
        </div>
      </div>
    </project-card>
    <project-card title="完成项目的条件和保证">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn" v-if="formData.wcxmFj.url !== ''">
        <a
          :href="formData.wcxmFj.url"
          target="_blank"
          class="primary"
          :download="formData.wcxmFj.fileName"
          >{{ formData.wcxmFj.fileName }}</a
        >
        <span class="el-icon-download"></span>
      </div>
      <div class="content-box">{{ formData.wcxmTj }}</div>
    </project-card>
    <project-card title="经费使用计划">
      <!-- <span slot="tag" class="required"></span> -->
      <div slot="btn">
        <span class="totalMoney"
          >总计申请经费：{{ sumMoney.toFixed(2) }}元</span
        >
      </div>
      <table class="project-plan-coast">
        <tr>
          <td>交通费（元）</td>
          <td>住宿费（元）</td>
          <td>资料费（元）</td>
          <td>其它费用（元）</td>
          <td>备注说明</td>
        </tr>
        <tr>
          <td>
            {{ formData.jfJt }}
          </td>
          <td>
            {{ formData.jfZs }}
          </td>
          <td>
            {{ formData.jfZl }}
          </td>
          <td>
            {{ formData.jfQt }}
          </td>
          <td>
            {{ formData.jfBz }}
          </td>
        </tr>
      </table>
    </project-card>
  </div>
</template>
<script>
import projectCard from "../common/projectCard";
export default {
  name: "projectAddForZXZJSHDYXM",
  components: {
    "project-card": projectCard
  },
  data() {
    return {
      getPath: "jiansheProject/getFormDataForZXZJSHDYXM",
      clearPath: "jiansheProject/clearFormDataForZXZJSHDYXM",
      updatePath: "jiansheProject/updateFormDataForZXZJSHDYXM",
      formData: null,
      personInfo: {
        birthDate: "",
        collegeName: "",
        collegeNum: "",
        email: "",
        grade: "",
        majorName: "",
        majorNum: "",
        name: "",
        phone: "",
        sex: "",
        studentNumber: "",
        tasks: "",
        trainingLevel: "",
        trainingLevelNum: ""
      },
      teacherInfo: {
        yddh: "",
        zdjsgh: "",
        zdjsxm: ""
      }
    };
  },
  mounted() {
    this.formData = this.$store.getters[this.getPath];
  },
  methods: {
    // 请求教职工列表
    requireTeacherInfo() {
      this.loading = true;
      this.$http
        .get(`/api/baseservice/jzg/education/search`, {
          params: {
            query: this.formData.zdjsgh
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data[0];
          if (!data) {
            console.error("教职工数据获取失败");
            return false;
          }
          this.teacherInfo = data;
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求负责人信息
    requirePersonInfo() {
      this.$http
        .get(`/api/baseservice/stu/education/search`, {
          params: {
            query: this.formData.xh
          }
        })
        .then(res => {
          let data = res.data[0];
          if (!data) {
            console.error("学生数据获取失败");
            return false;
          }
          this.personInfo = data;
        });
    },
    // 清空表单数据
    handleClear() {
      this.$store.commit(this.clearPath);
    }
  },
  watch: {
    storeFormData: {
      handler(val) {
        this.formData = val;
        if (this.formData.xh !== "") {
          this.requirePersonInfo();
        }
        if (this.formData.zdjsgh !== "") {
          this.requireTeacherInfo();
        }
      },
      immediate: true,
      deep: true
    }
  },
  destroyed() {
    this.handleClear();
  },
  computed: {
    sumMoney() {
      let { jfJt, jfQt, jfZl, jfZs } = this.formData;
      return -(0 - jfJt - jfQt - jfZl - jfZs);
    },
    storeFormData() {
      return this.$store.getters[this.getPath];
    }
  }
};
</script>
<style lang="scss" scoped>
.projectAddForZXZJSHDYXM {
  .title {
    text-align: center;
    margin-bottom: 20px;
    font-weight: bold;
    color: $blue;
    font-size: 20px;
  }
  td {
    border: 1px solid #ccc;
    height: 40px;
  }
  .el-select {
    width: 100%;
  }
  .project-info {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .charge-man {
    td:nth-child(odd) {
      width: 200px;
      background: #f5f5f5;
    }
    td:nth-child(even) {
      padding-left: 10px;
    }
  }
  .group-man {
    td {
      text-align: center;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .project-design {
    & > div {
      display: flex;
      flex-direction: column;
      margin-bottom: 14px;
      span {
        line-height: 30px;
      }
    }
  }
  .totalMoney {
    font-weight: normal;
  }
  .project-plan-coast {
    td {
      text-align: center;
      &:not(:last-child) {
        width: 120px;
      }
    }
    .el-input-number {
      width: 120px;
    }
    tr:first-child {
      background: #f5f5f5;
    }
  }
  .content-box {
    width: 100%;
    height: 150px;
    padding: 10px;
    overflow: auto;
    word-break: break-all;
    border: 1px solid #ccc;
  }
}
</style>
