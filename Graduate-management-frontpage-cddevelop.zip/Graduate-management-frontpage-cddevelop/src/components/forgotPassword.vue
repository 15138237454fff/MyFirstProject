<template>
  <div class="forgotPassword">
    <el-header class="header">
      <el-row style="height:80px">
        <el-col :span="8">
          <img src="../assets/images/university.png" class="logo-img" />
        </el-col>
        <el-col :span="8" style="text-align:center;font-size:25px">
          <span style="white-space:nowrap"
            >浙江财经大学研究生院综合服务平台</span
          >
        </el-col>
      </el-row>
    </el-header>
    <div class="bix">
      <header>
        <div style="text-align:right;padding-right:30px">
          <img
            src="../assets/icons/lock.png"
            alt
            style="width:80px;height:80px;margin-top:20px;"
          />
        </div>
        <div style="font-size:24px;line-height:120px">找回密码</div>
      </header>
      <div>
        <safety
          v-if="safetycompent"
          @safetycompentent="safetycompentent"
        ></safety>
        <resetpsd
          v-if="resetpsdcompent"
          @resetpsdcompentent="resetpsdcompentent"
          @finshdcompentent="finshdcompentent"
        ></resetpsd>
        <finshd v-if="finshdcompent"></finshd>
      </div>
    </div>
  </div>
</template>
<script>
import safety from "./safety";
import resetpsd from "./resetpsd";
import finshd from "./finshd";
export default {
  name: "forgotPassword",
  data() {
    return {
      percentage: 20,
      customColor: "#409eff",
      safetycompent: true,
      resetpsdcompent: false,
      finshdcompent: false
    };
  },
  components: {
    safety: safety,
    resetpsd: resetpsd,
    finshd: finshd
  },
  methods: {
    safetycompentent(val) {
      this.resetpsdcompent = val;
      this.safetycompent = !val;
    },
    resetpsdcompentent(val) {
      this.resetpsdcompent = !val;
      this.safetycompent = val;
    },
    finshdcompentent(val) {
      this.resetpsdcompent = !val;
      this.finshdcompent = val;
    }
  }
};
</script>
<style lang="scss" scoped>
.forgotPassword {
  .el-header {
    padding: 0 40px;
  }
  .el-header,
  .header {
    background: linear-gradient(
      90deg,
      rgba(24, 144, 255, 1) 0%,
      rgba(24, 144, 255, 1) 0%,
      rgba(136, 199, 255, 1) 100%,
      rgba(136, 199, 255, 1) 100%
    );
    height: 80px !important;
    color: #fff;
    line-height: 80px;
    & > div > div:last-child > div:first-child span {
      cursor: pointer;
    }
    .logo-img {
      vertical-align: top;
      width: 300px;
      margin-top: 16px;
    }
  }
  .bix {
    width: 80%;
    height: 800px;
    background: rgba(255, 255, 255, 1);
    margin: 0 auto;
    header {
      width: 100%;
      height: 120px;
      display: flex;
      line-height: 100px;
      border-bottom: 1px solid rgba(217, 217, 217, 1);
      div {
        flex: 1;
        font-weight: bold;
      }
    }
  }
}
</style>
