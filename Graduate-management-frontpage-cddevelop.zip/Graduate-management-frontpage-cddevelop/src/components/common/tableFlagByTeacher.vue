<template>
  <!-- 表格左上角的标志（审核中，通过，不通过等状态） -->
  <div class="table-flag">
    <div :class="status | flagZtFilter(1)">
      <div class="text">【{{ status | flagZtFilter(0) }}】</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "tableFlag",
  props: {
    status: {}
  },
  filters: {
    flagZtFilter(val, type) {
      // 转为数字类型
      val = parseInt(val);
      if (type === 0) {
        switch (val) {
          case 0:
            return "不通过";
          case 1:
            return "通过";
          case 2:
            return "退回";
          case 3:
            return "审核中";
          case 4:
            return "已立项";
        }
      } else {
        switch (val) {
          case 0:
            return "back";
          case 1:
            return "yes";
          case 2:
            return "back";
          case 3:
            return "ing";
          case 4:
            return "blue";
        }
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.table-flag {
  position: absolute;
  top: 24px;
  right: 20px;
  .wait,
  .ing,
  .yes,
  .back {
    display: inline-block;
  }
  .wait {
    color: $blue;
  }

  .ing {
    color: $orange;
  }

  .back {
    color: $red;
  }

  .yes {
    color: $success;
  }
}
</style>
