<template>
  <div class="reduceBtn">
    <span class="el-icon-minus"></span>
  </div>
</template>
<script>
export default {
  name: "reduceBtn"
};
</script>
<style lang="scss" scoped>
.reduceBtn {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: red;
  text-align: center;
  line-height: 24px;
  cursor: pointer;
  margin: auto;
  span {
    font-size: 24px;
    color: #fff;
    font-weight: bold;
  }
}
</style>
