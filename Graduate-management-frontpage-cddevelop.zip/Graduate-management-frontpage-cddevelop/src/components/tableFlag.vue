<template>
  <!-- 表格左上角的标志（审核中，通过，不通过等状态） -->
  <div class="main">
    <div :class="status | statusFilter">
      <div class="text">{{status | ztFilter}}</div>
    </div>
    <div class="title">
      <span>{{ tableTitle }}</span>
      <span style="margin-left:5px" v-if="time">{{ `(${time})` }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tableFlag',
  props: {
    status: {},
    status1: {},
    tableTitle: {},
    time: {
      default: ''
    }
  },
  data () {
    return {}
  },
  created () {},
  methods: {},
  watch: {
    status (val) {
      console.log('申请状态为' + val)
    }
  }
}
</script>

<style lang="scss" scoped>
.wait,
.ing,
.yes,
.back {
  width: 100px;
  height: 40px;
  // background-color: #FBBD6A;
  display: inline-block;
  float: left;
  transform: translateY(-10px) translateX(-30px) skew(-30deg);
  .text {
    color: #fff;
    font-size: 13px;
    text-align: center;
    transform: translateX(5px) skew(30deg);
  }
}
.title {
  margin-right: 95px;
}
.wait {
  background-color: $blue;
}

.ing {
  background-color: $orange;
}

.back {
  background-color: $red;
}

.yes {
  background-color: $success;
}
</style>
