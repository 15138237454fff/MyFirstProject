<template>
  <div class="myBreadcrumb">
    <div class="left">
      <slot name="left"></slot>
    </div>
    <div class="right">
      <slot name="right"></slot>
    </div>
  </div>
</template>
<script>
export default {
  name: "myBreadcrumb",
  data() {
    return {};
  }
};
</script>
<style lang="scss" scoped>
.myBreadcrumb {
  height: $student-nav-height;
  line-height: $student-nav-height;
  display: flex;
  justify-content: space-between;
  align-items: center;
  .left {
    flex: 5;
    line-height: 40px;
    /deep/ .el-input {
      width: 210px;
    }
  }
  .right {
    flex: 1;
    text-align: right;
    font-size: 14px;
    .el-icon-edit {
      margin-right: 5px;
      color: #409eff;
    }
  }
}
</style>
