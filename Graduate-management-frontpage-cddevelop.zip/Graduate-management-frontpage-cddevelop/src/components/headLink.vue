<template>
  <div class="header-link">
    <!-- 研究生证补办 cardReapply -->
    <!-- 个人信息管理,日常工作,教学培养,国际化培养 -->
    <!-- 优博培育项目,学术成果,学位论文,离职就业服务 -->
    <el-dropdown @command="handleCommand1" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/personalInfo') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('personalInfo')">个人信息管理</span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="a">个人基本信息</el-dropdown-item>
        <!-- <el-dropdown-item command="b" divided>学籍异动申请</el-dropdown-item>
        <el-dropdown-item command="e" divided>研究生证补办</el-dropdown-item>
        <el-dropdown-item command="d" divided>更换导师申请</el-dropdown-item>
        <el-dropdown-item command="c" divided>硕博连读申请</el-dropdown-item> -->
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand2" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/routine') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('routine')">日常工作</span>
      <el-dropdown-menu slot="dropdown">
        <!-- <el-dropdown-item command="a">勤工岗位申请</el-dropdown-item>
        <el-dropdown-item command="b" divided>学生活动报名</el-dropdown-item>
        <el-dropdown-item command="c" divided>入党申请</el-dropdown-item> -->
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand3" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/teachTrain') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('teachTrain')">教学培养</span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="a">个人培养计划</el-dropdown-item>
        <el-dropdown-item command="b" divided>在线选课</el-dropdown-item>
        <!-- <el-dropdown-item command="c" divided>免修/重修/缓考</el-dropdown-item> -->
        <el-dropdown-item command="d" divided>在线评教</el-dropdown-item>
        <el-dropdown-item command="e" divided>个人课表</el-dropdown-item>
        <el-dropdown-item command="f" divided>个人成绩单</el-dropdown-item>
        <el-dropdown-item command="g" divided>英语四六级报名</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand4" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/interTrain') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('interTrain')">国际化培养</span>
      <el-dropdown-menu slot="dropdown">
        <!-- <el-dropdown-item command="a">项目申请</el-dropdown-item>
        <el-dropdown-item command="b" divided>出国报备申请</el-dropdown-item>
        <el-dropdown-item command="c" divided>成果录入</el-dropdown-item>
        <el-dropdown-item command="d" divided>国际化培养查询</el-dropdown-item> -->
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand5" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/jiansheProject') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('jiansheProject')">教育建设项目</span>
      <el-dropdown-menu slot="dropdown">
        <!-- <el-dropdown-item command="a">项目申报</el-dropdown-item>
        <el-dropdown-item command="b" divided>我的项目</el-dropdown-item>
        <el-dropdown-item command="c" divided>结题申请</el-dropdown-item> -->
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand6" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/academicAchieve') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('academicAchieve')">学术成果</span>
      <el-dropdown-menu slot="dropdown">
        <!-- <el-dropdown-item command="a">学术成果录入</el-dropdown-item>
        <el-dropdown-item command="b" divided>个人成果查询</el-dropdown-item> -->
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand7" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/academicDegree') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('academicDegree')">学位申请</span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="b" divided>送审论文上传</el-dropdown-item>
        <el-dropdown-item command="c" divided>教育满意度调查</el-dropdown-item>
        <el-dropdown-item command="d" divided>论文终稿上传</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    <!-- <el-col :span="1">
          <el-divider direction="vertical"></el-divider>
    </el-col>-->
    <el-dropdown @command="handleCommand8" placement="bottom" :class="{ isActive: this.$route.path.indexOf('/employService') > -1 }">
      <span class="el-dropdown-link" @click="titleClick('employService')">离校就业服务</span>
      <el-dropdown-menu slot="dropdown">
        <!-- <el-dropdown-item command="a">电子离校单</el-dropdown-item>
        <el-dropdown-item command="b" divided>毕业档案查询</el-dropdown-item> -->
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
export default {
  name: "headLink",
  data() {
    return {
      mainShow: true,
      mainFix: false
    };
  },
  mounted() {
    this.mainFix = this.$store.state.titlePosition;
  },
  computed: {
    titlePosition() {
      return this.$store.state.titlePosition;
    }
  },
  watch: {
    titlePosition() {
      this.mainFix = this.titlePosition;
    }
  },
  methods: {
    // 点击标题各个子页面切换
    titleClick(t) {
      this.titleValue = t;
      switch (t) {
        case "personalInfo":
          this.$router.push({
            path: "/personalInfo/baseInfo"
          });
          this.showMain = false;
          break;
        case "routine":
          this.$router.push({
            name: "routine"
          });
          this.showMain = false;
          break;
        case "teachTrain":
          this.$router.push({
            path: "/teachTrain/personalPlan/1"
          });
          this.showMain = false;
          break;
        case "interTrain":
          this.$router.push({
            name: "interTrain"
          });
          this.showMain = false;
          break;
        case "jiansheProject":
          this.$router.push({
            path: "/jiansheProject/projectReport"
          });
          this.showMain = false;
          break;
        case "academicAchieve":
          this.$router.push({
            path: "/academicAchieve/achieveInput/1"
          });
          this.showMain = false;
          break;
        case "academicDegree":
          this.$router.push({
            name: "academicDegreePaperUpload"
          });
          this.showMain = false;
          break;
        case "employService":
          this.$router.push({
            name: "employService"
          });
          this.showMain = false;
          break;
      }
    },
    // 个人信息管理
    handleCommand1(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/personalInfo/baseInfo"
          });
          break;
        case "b":
          this.$router.push({
            path: "/personalInfo/stuChange/1"
          });
          break;
        case "c":
          this.$router.push({
            path: "/personalInfo/suoboApply/1"
          });
          break;
        case "d":
          this.$router.push({
            path: "/personalInfo/changeTutor/1"
          });
          break;
        case "e":
          this.$router.push({
            path: "/personalInfo/cardReapply/1"
          });
          break;
      }
    },
    // 日常工作
    handleCommand2(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/personalInfo/baseInfo/1"
          });
          break;
        case "b":
          this.$router.push({
            path: "/personalInfo/stuChange/1"
          });
          break;
      }
    },
    // 教学培养
    handleCommand3(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/teachTrain/personalPlan/1"
          });
          break;
        case "b":
          this.$router.push({
            path: "/teachTrain/onlineSelection/1"
          });
          break;
        case "c":
          this.$router.push({
            path: "/teachTrain/exemptionRebuild/1"
          });
          break;
        case "d":
          this.$router.push({
            path: "/teachTrain/onlineEvalution/1"
          });
          break;
        case "e":
          this.$router.push({
            path: "/teachTrain/personalTimetable/1"
          });
          break;
        case "f":
          this.$router.push({
            path: "/teachTrain/personalTranscript/1"
          });
          break;
        case "g":
          this.$router.push({
            path: "/teachTrain/applyCET/1"
          });
          break;
      }
    },
    // 国际化培养
    handleCommand4(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/interApply"
          });
          break;
        case "b":
          this.$router.push({
            path: "/goAbroad"
          });
          break;
        case "c":
          this.$router.push({
            path: "/resultInput"
          });
          break;
        case "d":
          this.$router.push({
            path: "/interQuery"
          });
          break;
      }
    },
    // 优博培育项目
    handleCommand5(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/jiansheProject/projectReport"
          });
          break;
        case "b":
          this.$router.push({
            path: "/jiansheProject/myProject"
          });
          break;
        case "c":
          this.$router.push({
            path: "/jiansheProject/conclusionApply"
          });
          break;
      }
    },
    // 学术成果
    handleCommand6(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/academicAchieve/achieveInput/1"
          });
          break;
        case "b":
          this.$router.push({
            path: "/academicAchieve/achieveQuery/2"
          });
          break;
      }
    },
    // 学位申请
    handleCommand7(command) {
      switch (command) {
        case "b":
          this.$router.push({
            path: "/academicDegree/academicDegreePaperUpload"
          });
          break;
        case "c":
          this.$router.push({
            path: "/academicDegree/degreeAnwserPaper"
          });
          break;
        case "d":
          this.$router.push({
            path: "/academicDegree/academicDegreePaperFinal"
          });
          break;
      }
    },
    // 离校就业服务
    handleCommand8(command) {
      switch (command) {
        case "a":
          this.$router.push({
            path: "/personalInfo/baseInfo"
          });
          break;
        case "b":
          this.$router.push({
            path: "/personalInfo/stuChange"
          });
          break;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.header-link {
  padding: 0 10%;
  height: $student-nav-height;
  line-height: $student-nav-height;
  color: #999999;
  font-size: 16px;
  background-color: #fff;
  span {
    cursor: pointer;
    // width: 10%;
    &:hover {
      color: #409eff;
    }
  }
  .el-divider--horizontal {
    margin-bottom: 0;
  }
  .el-dropdown {
    width: 12.5%;
    font-size: 16px;
    text-align: center;
    &.isActive {
      color: $blue;
      border-bottom: 2px solid $blue;
      background-image: linear-gradient(#fff 50%, rgba(64, 157, 255, 0.2) 150%);
    }
    span {
      cursor: pointer;
      white-space: nowrap;
      outline: none;
      // &:hover {
      //     color: #409eff;
      // }
    }
  }
}
// 修改下拉框背景色，popper小箭头的颜色
.el-dropdown-menu {
  background-color: rgba(170, 215, 255, 0.9) !important;
  .el-dropdown-menu__item {
    // color: dodgerblue;
    color: #1890ff;
  }
}
.el-popper[x-placement^="bottom"] /deep/ .popper__arrow {
  &:after {
    border-bottom-color: transparent !important;
  }
}
.el-popper /deep/ .popper__arrow,
.el-popper /deep/ .popper__arrow::after {
  border-color: transparent transparent rgba(170, 215, 255, 0.9) !important;
  overflow: hidden !important;
  border-width: 8px !important;
}
.el-popper[x-placement^="bottom"] /deep/ .popper__arrow {
  top: -16px !important;
}
.el-dropdown-menu__item--divided {
  margin-top: 0 !important;
}
.el-dropdown-menu__item--divided:before {
  height: 0 !important;
}
.el-dropdown-menu__item:focus,
.el-dropdown-menu__item:not(.is-disabled):hover {
  background-color: rgba(70, 166, 255, 1) !important;
  color: #fff !important;
}
</style>
