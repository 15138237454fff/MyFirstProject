<template>
  <!-- 表格左上角的标志（审核中，通过，不通过等状态） -->
  <div class="table-flag">
    <div>
      <div :class="status | flagZtFilter(1)" v-if="status">
        <div class="text">{{status | flagZtFilter(0)}}</div>
      </div>
      <div class="time" v-else-if="time">
        请于
        <span v-if="time">{{ time }}</span> 前完成学位申请
      </div>
    </div>
    <div class="table-title">
      <span>{{ tableTitle }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tableFlag',
  props: {
    status: {},
    tableTitle: {},
    time: {
      default: ''
    }
  },
  filters: {
    flagZtFilter (val, type) {
      // 转为数字类型
      val = parseInt(val)
      if (type === 0) {
        switch (val) {
          case 0:
            return '不通过'
          case 1:
            return '通过'
          case 2:
            return '退回'
          case 3:
            return '审核中'
        }
      } else {
        switch (val) {
          case 0:
            return 'back'
          case 1:
            return 'yes'
          case 2:
            return 'back'
          case 3:
            return 'ing'
        }
      }
    }
  },
  data () {
    return {}
  },
  created () {},
  methods: {},
  watch: {
    status (val) {
      console.log('申请状态为' + val)
    }
  }
}
</script>

<style lang="scss" scoped>
.table-flag {
  position: relative;
  .wait,
  .ing,
  .yes,
  .back {
    width: 100px;
    height: 40px;
    // background-color: #FBBD6A;
    display: inline-block;
    float: left;
    transform: translateY(-10px) translateX(-30px) skew(-30deg);
    .text {
      color: #fff;
      font-size: 13px;
      text-align: center;
      transform: translateX(5px) skew(30deg);
    }
  }
  .table-title {
    margin-right: 95px;
    display: flex;
    justify-content: center;
  }
  .time {
    font-weight: 400;
    font-size: 14px;
    line-height: 40px;
    color: #999999;
    position: absolute;
    span {
      color: #1890ff;
    }
  }

  .wait {
    background-color: $blue;
  }

  .ing {
    background-color: $orange;
  }

  .back {
    background-color: $red;
  }

  .yes {
    background-color: $success;
  }
}
</style>
