<template>
  <div class="sidebar">
    <!-- 侧边导航 -->
    <!-- <div > -->
    <el-menu background-color="#001c2d" :collapse="isCollapse" :default-active="defaultActive" router unique-opened :collapse-transition="true" class="sidebar-el-menu">
      <!-- 折叠按钮 -->
      <div class="collapse-btn">
        <div @click="handleCollapse">
          <img src="../../assets/icons/left.png" alt v-show="!isCollapse" />
          <img src="../../assets/icons/right.png" alt v-show="isCollapse" />
        </div>
      </div>
      <el-submenu v-for="(item, index) in menuList" :key="index" :index="item.index">
        <template slot="title">
          <i :class="item.icon"></i>
          <span slot="title">{{ item.name }}</span>
        </template>
        <el-menu-item-group  v-for="(subitem, sub) in menuList[index].sub" :key="sub">
          <el-menu-item :index="subitem.path">{{ subitem.name }}</el-menu-item>
        </el-menu-item-group>
      </el-submenu>
    </el-menu>
    <!-- </div> -->
  </div>
</template>

<script>
export default {
  name: "sideBar",
  data() {
    return {
      isCollapse: false,
      menuList: [
        // {
        //   icon: "el-icon-setting",
        //   index: "1",
        //   name: "招生资格申请"
        // },
        {
          icon: "el-icon-tickets",
          index: "2",
          name: "学生信息管理",
          sub: [
            {
              index: "2-1",
              name: "• 学生信息查看",
              path: "/stuInfoView"
            },
            // {
            //   index: "2-2",
            //   name: "• 学生信息审核",
            //   path: "/stuInfoAudit"
            // }
          ]
        },
        {
          icon: "el-icon-reading",
          index: "3",
          name: "教学培养管理",
          sub: [
            {
              index: "3-1",
              name: "• 培养计划审核",
              path: "/trainPlanAudit"
            },
            // {
            //   index: "3-2",
            //   name: "• 学生课程审核",
            //   path: "/stuCourseAudit"
            // },
            {
              index: "3-3",
              name: "• 培养计划查询",
              path: "/trainPlanQuery"
            },
            {
              index: "3-4",
              name: "• 课程教学管理",
              path: "/courseManage"
            },
            {
              index: "3-5",
              name: "• 学生成绩录入",
              path: "/stuScoreManage"
            }
          ]
        },
        // {
        //   icon: "el-icon-office-building",
        //   index: "4",
        //   name: "国际化培养管理"
        // },
        // {
        //   icon: "el-icon-school",
        //   index: "5",
        //   name: "教育建设项目",
        //   url:"/projectReportByTeacher",
        //   sub: [
        //     {
        //       index: "5-1",
        //       name: "• 项目申报",
        //       path: "/projectReportByTeacher"
        //     },
        //     { index: "5-2", name: "• 我的项目", path: "/myProjectByTeacher" },
        //     {
        //       index: "5-3",
        //       name: "• 结题申请",
        //       path: "/conclusionApplyByTeacher"
        //     },
        //     { index: "5-4", name: "• 项目申报审核", path: "/projectAduit" },
        //     { index: "5-5", name: "• 项目结题审核", path: "/conclusionAduit" }
        //   ]
        // },
        // {
        //   icon: "el-icon-trophy-1",
        //   index: "6",
        //   name: "学术成果管理",
        //   sub: [
        //     {
        //       index: "3-1",
        //       name: "• 学术成果审核",
        //       path: "/academicAchieveAduit"
        //     },
        //     {
        //       index: "3-2",
        //       name: "• 学术成果查询",
        //       path: "/academicAchieveSee/2"
        //     }
        //   ]
        // },
        {
          icon: "el-icon-collection",
          index: "7",
          name: "学位论文管理",
          sub: [
            // {
            //   index: '4-1',
            //   name: '• 学位申请审核',
            //   path: '/academicDegreeAduit/2'
            // },
            {
              index: "4-2",
              name: "• 学位论文审核",
              path: "/academicDegreePaperAduit/2"
            },
            {
              index: "4-3",
              name: "• 论文终稿审核",
              path: "/paperFinalAduit/2"
            }
            // {
            //   index: '4-4',
            //   name: '• 优秀论文评审',
            //   path: '/goodPaperAduit/2'
            // }
          ]
        }
      ]
    };
  },
  computed: {
    defaultActive() {
      if (!this.$route.meta.alias) {
        return this.$route.path.replace("/teacher", "");
      } else return this.$route.meta.alias;
    }
    // menuList() {
    //   return this.$store.getters.getMenuList;
    // }
  },
  created() {},

  methods: {
    handleCollapse() {
      this.isCollapse = !this.isCollapse;
      this.$bus.$emit("collapse", this.isCollapse);
    }
  }
};
</script>

<style lang="scss" scoped>
.sidebar {
  display: block;
  position: absolute;
  left: 0;
  top: 80px;
  bottom: 0;
  overflow-y: scroll;
  overflow-x: hidden;
  color: $success;
  /deep/ .el-menu {
    @extend .sider-nav-bg;
  }
}
/deep/ .el-menu--popup {
  @extend .sider-nav-bg;
}
.sidebar::-webkit-scrollbar {
  width: 0;
}
.sidebar /deep/ .el-submenu__title {
  color: $white;
  @extend .normal-font;
  @extend .normal-nav-view;
  height: 50px;
  line-height: 50px;
  &:hover {
    @extend .selected-nav-bg;
    @extend .selected-nav-view;
  }
}
/deep/ .el-menu-item-group__title {
  padding: 0;
  @extend .normal-nav-view;
}
.sidebar /deep/ .el-menu-item {
  padding-left: 56px !important;
}
.sidebar /deep/ .el-menu-item .is-active {
  padding-left: 56px !important;
}
/deep/ .el-menu-item {
  @extend .normal-nav-view;
  &.is-active {
    @extend .selected-nav-bg;
    @extend .selected-nav-view;
    color: $white;
  }
  &:hover {
    @extend .selected-nav-bg;
    @extend .selected-nav-view;
  }
  color: $white;
}

.sidebar /deep/ .el-submenu [class^="el-icon-"] {
  margin-right: 12px;
  // background-color: pink;
  width: 24px;
  height: 24px;
  line-height: 24px;
  text-align: center;
}
.collapse-btn {
  text-align: center;
  border-bottom: 1px solid rgb(83, 104, 129);
  img {
    width: 20px;
    height: 20px;
    margin: 8px;
  }
}
</style>

<style scoped>
.sidebar-el-menu:not(.el-menu--collapse) {
  width: 230px !important;
}
.sidebar > ul {
  height: 100%;
}
</style>
