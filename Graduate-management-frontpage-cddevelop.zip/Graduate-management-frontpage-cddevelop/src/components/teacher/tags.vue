<template>
  <!-- 标签导航栏 -->
  <div class="tag-nav">
    <!-- v-if="showTags" -->
    <div class="tags">
      <div class="tagsArea" @mousewheel="hualun" ref="tagsArea">
        <ul>
          <li
            class="tags-li"
            v-for="(item,index) in tagsList"
            :key="index"
            :class="{ 'active':isActive(item.title),'index':item.title === '首页' }"
            :ref="'tag'+index"
          >
            <router-link :to="item.path" class="tags-li-title">{{ item.title }}</router-link>
            <span class="tags-li-icon" @click="closeTags(item)" v-if="item.title !== '首页'">
              <i class="el-icon-close"></i>
            </span>
          </li>
        </ul>
      </div>
      <div class="tags-close-box">
        <el-dropdown @command="handleTags">
          <el-button>
            标签选项
            <i class="el-icon-arrow-down el-icon--right"></i>
          </el-button>
          <el-dropdown-menu size="small" slot="dropdown">
            <el-dropdown-item command="other">关闭其它</el-dropdown-item>
            <el-dropdown-item command="all">关闭所有</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: '',
  data () {
    return {
      tagsList: [{ name: 'teacherHome', path: '/teacherHome', title: '首页' }],
      homeClass: 'tags-li'
    }
  },
  watch: {
    $route (newValue) {
      this.setTags(newValue)
    }
  },
  created () {
    this.setTags(this.$route)
  },

  methods: {
    isActive (title) {
      // console.log(this.$route);
      if (
        this.$route.path === '/teacherNoticeList' ||
        this.$route.name === 'teacherNoticeDetail' ||
        this.$route.path === '/waitThing'
      ) {
        return true
      }
      return title == this.$route.meta.title
    },
    // 关闭单个标签
    closeTags (obj) {
      let index = this.tagsList.indexOf(obj)
      const delItem = this.tagsList.splice(index, 1)[0]
      const item = this.tagsList[index]
        ? this.tagsList[index]
        : this.tagsList[index - 1]
      if (item) {
        // console.log(delItem.name);
        // console.log(this.$route.name);
        // 改为判断路由名字
        delItem.name == this.$route.name && this.$router.push(item.path)
      } else {
        this.$router.push('/teacherHome')
      }
      // this.leftMove();
    },
    // 关闭所有标签
    closeAll () {
      this.tagsList = []
      this.$router.push('/teacherHome')
      // this.startInd = 0;
    },
    // 关闭其它标签
    closeOther () {
      const curItem = this.tagsList.filter(item => {
        return item.path == this.$route.path
      })
      this.tagsList = curItem
      // this.startInd = 0;
    },
    // 设置标签
    setTags (route) {
      if (!route.meta.title) {
        return false
      }
      const isExist = this.tagsList.some(item => {
        return item.path == route.path
      })
      let tmpRoute = {
        title: route.meta.title,
        path: route.path,
        name: route.matched[1].components.default.name
      }
      let tmpInd
      // 如果要设置的标签不存在列表中
      if (!isExist) {
        // 不添加重复名称的标签
        if (
          !this.tagsList.some(el => {
            return el.title === route.meta.title
          })
        ) {
          this.tagsList.push(tmpRoute)
          // 最新的标签默认显示在最右侧
          this.$nextTick(() => {
            this.$refs.tagsArea.scrollLeft += 150
          })
        }
      } else {
        let index = this.tagsList.findIndex(el => {
          return el.path == route.path
        })
        this.$nextTick(() => {
          this.$refs.tagsArea.scrollLeft = this.$refs[
            'tag' + index
          ][0].offsetLeft
        })
      }

      this.$bus.$emit('tags', this.tagsList)
    },
    handleHome () {
      this.$router.push('/teacherHome')
      this.homeClass = 'tags-li active'
    },
    handleTags (command) {
      command == 'other' ? this.closeOther() : this.closeAll()
    },
    hualun ($event) {
      // 获取滚轮滚动距离
      let deltaY = $event.deltaY
      // 将距离赋给横向滚动距离
      this.$refs.tagsArea.scrollLeft += deltaY / 4
    }
  }
}
</script>

<style lang="scss" scoped>
.homeBtn {
  background: none;
  border: none;
  outline: none;
  cursor: pointer;
}
.tag-nav {
  height: $tab-height;
}
.tags {
  position: relative;
  width: 100%;
  height: $tab-height;
  @extend .header-bg;
  padding-right: $other-tag-width;
  // border-bottom: 1px solid #cccccc;
  display: flex;
}
.tagsArea {
  width: 100%;
  overflow: hidden;
  overflow-x: auto;
  position: relative;
}
.tags ul {
  box-sizing: border-box;
  height: $tab-height;
  position: absolute;
  left: 0;
  white-space: nowrap;
  z-index: 9;
  // border-bottom: 1px solid #cccccc;
}
.tags-li {
  display: inline-block;
  // margin: 3px 2px 2px 3px;
  min-width: $other-tag-width;
  border-radius: 3px;
  font-size: 12px;
  overflow: hidden;
  cursor: pointer;
  height: $tab-height;
  @extend .normal-font;
  line-height: $tab-height;
  border: 1px solid #e9eaec;
  @extend .header-bg;
  padding: 0 20px;
  vertical-align: middle;
  color: #666;
  transition: all 0.3s ease-in;
  box-sizing: border-box;
}
.tags-li.index {
  width: 70px;
  min-width: 70px;
}
.tags-li:not(.active):hover {
  background: #f8f8f8;
}
.tags-li.active {
  background-color: $white;
  border-bottom: 1px solid #fff;
  color: $blue;
  a {
    color: $blue;
  }
}
.tags-li-title {
  float: left;
  max-width: 80px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  margin-right: 5px;
  color: #666;
}
.tags-close-box {
  box-sizing: border-box;
  padding-top: 1px;
  text-align: center;
  width: $other-tag-width;
  height: $tab-height;
  background: #fff;
  border: 1px solid #ccc;
  z-index: 10;
  .el-button {
    @extend .header-bg;
    color: #666;
    opacity: 1;
    outline: none;
    border: none;
  }
}
</style>
