<template>
  <!-- 提交审核意见 -->
  <div class="audit" v-show="$route.query.check !=1">
    <div class="dashed"></div>
    <el-form>
      <el-form-item label="审核：" class="tuige" prop="name">
        <!-- <el-input v-model="input"></el-input> -->
        <el-radio-group v-model="writeInfo.check" size="medium">
          <el-radio-button :label="1">通过</el-radio-button>
          <el-radio-button :label="0">不通过</el-radio-button>
          <el-radio-button :label="2" v-if="canBack">退回</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：" prop="name">
        <el-input
          type="textarea"
          v-model="writeInfo.comment"
          placeholder="请输入审核意见"
          :autosize="{ minRows: 6, maxRows: 8}"
        ></el-input>
      </el-form-item>
    </el-form>
    <div class="bottom">
      <el-button type="primary" @click="sumbitAudit">提交</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'auditSubmit',
  props: {
    // 是否显示退回按钮
    canBack: { type: Boolean }
  },
  components: {},
  data () {
    return {
      input: '',
      writeInfo: {
        check: 1,
        comment: ''
      }
    }
  },
  created () {},
  mounted () {
    this.writeInfo.check = 1
  },
  computed: {},
  methods: {
    // 提交审核
    sumbitAudit () {
      if ( this.writeInfo.comment === '' && this.writeInfo.check != 1) {
        this.$message.warning('请填写审核意见')
        return false
      }
      // if (this.writeInfo.check !== '1' && this.writeInfo.comment === '') {
      //   this.$message.warning('请填写审核意见')
      //   return
      // }
      if (this.writeInfo.check == '0' || this.writeInfo.check == '1') {
        // //console.log(this.$route)
        this.writeInfo.taskId = this.$route.query.taskId
        this.writeInfo.taskKey = this.$route.query.key
        // //console.log(this.writeInfo)
        this.$http
          .post('/api/frontpage/activity/saveOrder', this.writeInfo)
          .then(res => {
            // //console.log(res.data)
            if (res.data.code === 200) {
              this.$message.success('提交审核成功')
              this.writeInfo = {
                check: 1,
                comment: ''
              }
              // this.writeInfo.check = '1'
              this.$router.go(-1)
            }
          })
      }
      if (this.writeInfo.check == '2') {
        // console.log(this.$route);
        this.writeInfo.taskId = this.$route.query.taskId
        this.writeInfo.taskKey = this.$route.query.key
        // //console.log(this.writeInfo)
        this.$http
          .post('/api/frontpage/activity/back', {
            businesskey: this.$route.query.businesskey,
            check: '2',
            comment: this.writeInfo.comment,
            executionId: this.$route.query.executionId,
            processDefinitionId: this.$route.query.processDefinitionId,
            processInstanceId: this.$route.query.id,
            taskId: this.$route.query.taskId,
            taskKey: this.$route.query.key,
            name: this.$route.query.name,
            type:'0'
          })
          .then(res => {
            // //console.log(res.data)
            if (res.data.code === 200) {
              this.$message.success('提交审核成功')
              this.writeInfo = {
                check: 1,
                comment: ''
              }
              // this.writeInfo.check = '1'
              this.$router.go(-1)
            }
          })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dashed {
  margin-top: 25px;
  margin-bottom: 20px;
  height: 1px;
  background: linear-gradient(
    to right,
    rgba(204, 204, 204, 1),
    rgba(204, 204, 204, 1) 5px,
    transparent 5px,
    transparent
  );
  background-size: 10px 100%;
}
.audit /deep/ .el-textarea {
  width: 90%;
}
.audit /deep/ .el-button {
  margin-left: 82px;
  width: 30%;
}
.audit {
  .bottom {
    text-align: center;
  }
}
</style>
