import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import axios from 'axios'
import jiansheProject from './jiansheProject'
import common from './common'
Vue.use(Vuex)

const state = {
  // 存储用户登录信息
  userLoginMsg: {
    xh: '',
    userToken: '',
    userSsy: '',
    id: '',
    name: '',
    userStatus: '',
    currentRoleId: ''
  },
  changeTutor: true,
  titlePosition: false,
  sqlxm: '',
  auditList: [],
  kctzInfo: {},
  // 保存对话框信息
  dialogMsg: {
    title: '确认提交',
    msgOne: '是否确认提交？',
    msgTwo: '提交后请在申请记录中查看审核状态',
    visible: false,
    successCallback: () => { }
  },
  // 保存菜单列表
  menuList: [],
  // 保存学位资格申请时间信息
  degreeTime: {},
  // 是否开启学位资格申请
  degreeIng: null,
  // 表格高度
  tableHeight: null,
  logoImgUrl: '',
  // 获取当前的学年学期
  userxnxq: {}
}

const getters = {
  // 外部访问学号的方法
  getXH(state) {
    return state.userLoginMsg.xh
  },
  // 外部获取token的方法
  getToken(state) {
    return state.userLoginMsg.userToken
  },
  // 外部获取userSsy
  getSsy(state) {
    return state.userLoginMsg.userSsy
  },
  // 外部获取id
  getId(state) {
    return state.userLoginMsg.id
  },
  // 外部获取name
  getName(state) {
    return state.userLoginMsg.name
  },
  // 外部获取用户状态
  getStatus(state) {
    return state.userLoginMsg.userStatus
  },
  // 外部获取用户的角色id
  getcurrentRoleId(state) {
    return state.userLoginMsg.currentRoleId
  },
  // 外部获取对话框信息
  getDialog(state) {
    return state.dialogMsg
  },
  // 外部获取学位结束时间
  getDegreeEndTime(state) {
    return state.degreeTime.endTime
  },
  // 外部获取是否开启学位资格申请
  getDegreeIng(state) {
    return state.degreeIng
  },
  // 外部获取表格高度
  getTableHeight(state) {
    return state.tableHeight
  }
}
const mutations = {
  // 获取当前的学年学期
  uplodexnxq(state) {
    axios.get('/api/cultivate/pycssz/getnNowTerm').then(res => {
      state.userxnxq = res.data.data
    })
  },
  // 更新登录用户的信息的方法
  updatedUser(state, val) {
    state.userLoginMsg = val
  },

  // 更新表格高度
  updateTableHeight(state) {
    state.tableHeight = document.documentElement.clientHeight - 258
  },
  // 更新对话框参数
  updateDialog(state, {
    title,
    msgOne,
    msgTwo,
    visible,
    successCallback
  }) {
    !!title && (state.dialogMsg.title = title), !!msgOne && (state.dialogMsg.msgOne = msgOne), !!msgTwo && (state.dialogMsg.msgTwo = msgTwo),
      visible !== undefined && (state.dialogMsg.visible = visible), !!successCallback && (state.dialogMsg.successCallback = successCallback)
  },
  // 切换组件显示状态
  INCREMENT(state, key) {
    state[key] = !state[key]
  },

  // 更改学位资格申请时间信息对象
  updateDegree(state, val) {
    state.degreeTime = val
  },
  // 更改是否开启学位资格申请
  updateDegreeIng(state, val) {
    state.degreeIng = val
  },
  logoImg(state, url) {
    state.logoImgUrl = url
  }
}

const actions = {
  // 登录的方法
  login(context, loginForm) {
    // 返回一个promise对象
    return new Promise((resolve, reject) => {
      // 发送登录请求
      axios
        .post(
          '/api/usermanage/user/loginQt', loginForm
        )
        .then(result => {
          console.log(result);
          // 如果登录成功
          if (result.data.code === 200) {
            let data = result.data.data
            // console.log(result.data.data)
            if (!data) {
              reject('成功登陆后，用户信息返回失败')
            }
            let tmpObject = {
              id: data.id,
              userToken: data.userToken,
              userSsy: data.userSsy,
              xh: data.userName,
              name: data.name,
              userStatus: data.userStatus,
              currentRoleId: data.currentRoleId
            }
            // //当前角色id不为空

            context.commit('updatedUser', tmpObject)
            // axios.put(`api/system/home/saveLogin/${data.userName}/${data.userStatus}`)//登录有问题时会出错
            resolve('登录成功')
          } else {
            reject(result.data.message)
          }
        })
    })
  },
  // 获取学位资格申请时间
  requireDegreeTime(context) {
    axios.get('/api/cultivate/pycssz/degree').then(res => {
      let data = res.data.data
      // 如果data为空
      if (!data) {
        return
      }
      if (data.userToken === undefined) {
        data.userToken = ""
      }
      let tmpObject = {
        id: data.id,
        userToken: data.userToken,
        userSsy: data.userSsy,
        xh: data.userName,
        name: data.name,
        userStatus: data.userStatus,
        currentRoleId: data.currentRoleId
      }
    })
  }
}

export default new Vuex.Store({
  state,
  getters,
  mutations,
  actions,
  // 添加插件在F5刷新前将数据存储入sessionStorage中，刷新后将数据恢复
  plugins: [createPersistedState({
    storage: window.sessionStorage
  })],
  modules: {
    jiansheProject,
    common
  }
})