export default {
  state: {
    // 确认对话框参数
    confirmModalOption: {
      // 对话框显示状态
      modalVisiabal: false,
      // 标题内容
      title: "",
      // 内容
      msg: "",
      className: "modal-confirm",
      handleOk: () => { }
    }
  },
  getters: {
    // 外部获取确认对话框参数
    getConfirmModalOption(state) {
      return state.confirmModalOption
    }
  },
  mutations: {
    // 更新对话框参数
    updateConfirmModalOption(state, obj) {
      let { modalVisiabal, title, handleOk, msg } = obj
      if (modalVisiabal !== undefined) {
        state.confirmModalOption.modalVisiabal = modalVisiabal
      }
      if (title) {
        state.confirmModalOption.title = title
      }
      if (handleOk) {
        state.confirmModalOption.handleOk = handleOk
      }
      if (msg) {
        state.confirmModalOption.msg = msg
      }
    }
  },
  actions: {

  },
  namespaced: true
}
