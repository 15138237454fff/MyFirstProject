<template>
  <!-- 查看详情 -->
  <div class="table-box">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button type="primary">导出</el-button>
      </div>
    </div>
    <div class="table-area">
      <table>
        <tr>
          <td
            class="listcss"
            colspan="6"
            style="text-align:left;font-weight:bold"
          >
            | 基本信息
          </td>
          <td rowspan="4">
            <img
              :src="resetForm.zp"
              alt
              style="width:100px;height:100px;display: inline;"
            />
          </td>
        </tr>
        <tr>
          <td class="listcss">学号</td>
          <td>{{ form.xh }}</td>
          <td class="listcss">姓名</td>
          <td>{{ form.xsxm }}</td>
          <td class="listcss">姓名拼音</td>
          <td>{{ resetForm.xmpy }}</td>
        </tr>
        <tr>
          <td class="listcss">性别</td>
          <td>{{ resetForm.xbm | xbm }}</td>
          <td class="listcss">民族</td>
          <td>{{ resetForm.mzmc }}</td>
          <td class="listcss">出生日期</td>
          <td>{{ resetForm.csrq }}</td>
        </tr>
        <tr>
          <td class="listcss">婚姻状况</td>
          <td>{{ resetForm.hyzkmc }}</td>
          <td class="listcss">政治面貌</td>
          <td>{{ resetForm.zzmmmc }}</td>
          <td class="listcss">健康状况</td>
          <td>{{ resetForm.jkzkmc }}</td>
        </tr>
        <tr>
          <td class="listcss">国籍</td>
          <td>{{ resetForm.gjmc }}</td>
          <td class="listcss">证件类型</td>
          <td>{{ resetForm.sfzjlxm }}</td>
          <td class="listcss">证件号码</td>
          <td colspan="2">{{ resetForm.sfzh }}</td>
        </tr>
        <tr>
          <td class="listcss">籍贯</td>
          <td>{{ resetForm.jgmc }}</td>
          <td class="listcss">出生地</td>
          <td>{{ resetForm.csdmc }}</td>
          <td class="listcss">户口所在地</td>
          <td colspan="2">{{ resetForm.hkszdmc }}</td>
        </tr>
        <tr>
          <td class="listcss">户口详细地址</td>
          <td colspan="6">{{ resetForm.hkxxdz }}</td>
        </tr>
        <tr>
          <td class="listcss">移动电话</td>
          <td>{{ resetForm.yddh }}</td>
          <td class="listcss">固定电话</td>
          <td>{{ resetForm.dh }}</td>
          <td class="listcss">电子邮箱</td>
          <td colspan="2">{{ resetForm.dzxx }}</td>
        </tr>
        <tr>
          <td class="listcss">邮政编码</td>
          <td>{{ resetForm.yzbm }}</td>
          <td class="listcss">通讯地址</td>
          <td colspan="4">{{ resetForm.txdz }}</td>
        </tr>
      </table>

      <table>
        <tr>
          <td
            class="listcss"
            colspan="8"
            style="text-align:left;font-weight:bold"
          >
            | 学籍信息
          </td>
        </tr>
        <tr>
          <td class="listcss">学生类别</td>
          <td>{{ form.xslbmc }}</td>
          <td class="listcss">学习方式</td>
          <td>{{ form.xxfsmc }}</td>
          <td class="listcss">培养层次</td>
          <td colspan="4">{{ form.pyccmc }}</td>
        </tr>
        <tr>
          <td class="listcss">入学年月</td>
          <td>{{ form.rxny }}</td>
          <td class="listcss">年级</td>
          <td>{{ form.sznj }}</td>
          <td class="listcss">学制</td>
          <td colspan="4">{{ form.xz }}</td>
        </tr>
        <tr>
          <td class="listcss">所属学院</td>
          <td>{{ form.ssyxmc }}</td>
          <td class="listcss">所属专业</td>
          <td>{{ form.zy }}</td>
          <td class="listcss">研究方向</td>
          <td colspan="4">{{ form.yjfx }}</td>
        </tr>
        <tr>
          <td class="listcss">班级</td>
          <td>{{ form.bjmc }}</td>
          <td class="listcss">导师</td>
          <td>{{ form.dsxm }}</td>
          <td class="listcss">当前状态</td>
          <td>{{ form.xsdqztmc }}</td>
        </tr>
      </table>

      <table>
        <tr>
          <td
            class="listcss"
            colspan="8"
            style="text-align:left;font-weight:bold"
          >
            | 其他信息
          </td>
        </tr>
        <tr>
          <td class="listcss">何时何地何原因受过何种奖励或处分</td>
          <td colspan="7">{{ resetForm.jcnr }}</td>
        </tr>
        <tr>
          <td class="listcss" :rowspan="resetForm.qtList.length + 1">
            学习和工作经历
          </td>
          <td class="listcss" colspan="2">起止时间</td>
          <td class="listcss" colspan="2">学习或工作单位</td>
          <td class="listcss" colspan="2">职务</td>
        </tr>
        <template v-for="(item, index) in resetForm.qtList">
          <tr>
            <td colspan="2">
              {{ item.kssj | kssj }} 至 {{ item.jssj | jssj }}
            </td>
            <td colspan="2">{{ item.gzdw }}</td>
            <td colspan="2">{{ item.zw }}</td>
          </tr>
        </template>
        <tr>
          <td class="listcss" :rowspan="resetForm.jtcy.length + 1">
            家庭主要成员
          </td>
          <td class="listcss">姓名</td>
          <td class="listcss">关系</td>
          <td class="listcss">工作单位</td>
          <td class="listcss">职务</td>
          <td class="listcss">联系方式</td>
        </tr>
        <template v-for="(item, index) in resetForm.jtcy">
          <tr>
            <td>{{ item.cyxm }}</td>
            <td>
              <span v-if="resetForm.jtcy.length">{{
                item.gxm | jtgxlist(jtgxlist)
              }}</span
              ><span v-else>未知</span>
            </td>
            <td>{{ item.gzdw }}</td>
            <td>
              <span v-if="resetForm.jtcy.length">{{
                item.zy | zylist(zylist)
              }}</span
              ><span v-else>未知</span>
            </td>
            <td colspan="2">{{ item.lxfs }}</td>
          </tr>
        </template>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: "stuDetail",
  data() {
    return {
      userInfo: {},
      form: {},
      resetForm: {
        qtList: [],
        jtcy: []
      },
      jtgxlist: [],
      zylist: [],
      hkszd: ""
    };
  },
  filters: {
    xbm(val) {
      switch (val) {
        case "1":
          return "男";
          break;
        case "2":
          return "女";
          break;
        default:
          break;
      }
    },
    kssj(val) {
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jssj(val) {
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jtgxlist(val, index) {
      const valindex = index.find((el, index) => el.value === val);
      if (valindex) {
        return valindex.label;
      } else {
        return "";
      }
    },
    zylist(val, index) {
      const valindex = index.find((el, index) => el.value === val);
      if (valindex) {
        return valindex.label;
      } else {
        return "";
      }
    }
  },
  watch: {
    $route(to) {
      if (to.query.xh) {
        this.takeList();
      }
    }
  },
  methods: {
    // 返回列表
    handleBack() {
      this.$router.go(-1);
    },
    // getData() {
    //   this.$http
    //     .get("/api/frontpage/student/selectInfoByXh", {
    //       params: {
    //         xh: this.$route.query.xh
    //       }
    //     })
    //     .then(res => {
    //       let data = res.data.data;
    //       // console.log(data)
    //       this.userInfo = data;
    //     });
    // },
    takeList() {
      this.$http
        .get("/api/cultivate/stu/xjsj/" + this.$route.query.xh)
        .then(res => {
          this.form = res.data.data;
        });
      this.$http
        .get("/api/cultivate/stu/jbxx/" + this.$route.query.xh)
        .then(res => {
          this.resetForm = res.data.data;
          console.log(this.resetForm, 999);
          this.$http.get("/api/system/dict/select/all").then(res => {
            // 关系
            this.jtgxlist = res.data.data.jtgx;
            //职业码
            this.zylist = res.data.data.zw;
          });
        });
    }
  },
  created() {
    if (this.$route.query.xh) {
      this.takeList();
    }
  },
  mounted() {
    this.takeList();
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  box-sizing: border-box;

  .table-area {
    height: calc(100vh - 208px);
    overflow: auto;
    margin-top: $top;
  }
  .header {
    height: 40px;
    display: flex;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: 10px;
    }
  }
  table {
    width: 98%;
    margin: 20px auto;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    table-layout: auto;
    th {
      text-align: left;
      background-color: rgba(242, 242, 242, 1);
    }
    td {
      height: 40px;
      line-height: 40px;
      border: 1px solid #e0e0e0;
      width: 100px;
      text-align: center;
      .avatar {
        width: 100px;
        height: 125px;
      }
    }
    .listcss {
      background: #f2f2f2;
      width: 150px;
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
</style>
