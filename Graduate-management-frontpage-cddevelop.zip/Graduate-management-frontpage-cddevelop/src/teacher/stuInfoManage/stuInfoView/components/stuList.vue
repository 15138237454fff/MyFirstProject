<template>
  <!-- 学生列表 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          suffix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
      </div>
      <div class="header-right">
        <el-button type="primary">导出</el-button>
      </div>
    </div>
    <el-table :data="tableData" border :header-cell-style="tableHeaderColor" :height="tableHeight">
      <el-table-column prop="xh" label="学号" align="center"></el-table-column>
      <el-table-column prop="xsxm" label="姓名" align="center"></el-table-column>
      <el-table-column prop="xslbmc" label="学生类别" align="center"></el-table-column>
      <el-table-column prop="yxsh" label="所属学院" align="center"></el-table-column>
      <el-table-column prop="zy" label="所属专业" align="center"></el-table-column>
      <el-table-column prop="sznj" label="年级" align="center"></el-table-column>
      <el-table-column prop="szbh" label="班级" align="center"></el-table-column>
      <el-table-column prop="xsdqztm" label="当前状态" align="center"></el-table-column>
      <el-table-column prop="cz" label="操作" width="120" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="handleSee(scope.row)">查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'stuList',
  data () {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ''
      },
      msgCount: 0
    }
  },
  components: {
    'my-pagination': myPagination
  },
  mounted () {
    this.loadTable()
  },
  methods: {
    // 查询
    handleSearch () {
      this.loadTable()
    },
    // 清空搜索框
    handleClear () {
      this.limitQuery.search = ''
      this.loadTable()
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 加载数据
    loadTable () {
      console.log('请求数据')
      this.$http
        .get('/api/frontpage/student/selectStuListByDsh', {
          params: {
            pageNum: this.limitQuery.pageNum,
            pageSize: this.limitQuery.pageSize,
            query: this.limitQuery.search
          }
        })
        .then(res => {
          // console.log(res.data.data)
          let data = res.data.data
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    },
    // 查看详情
    handleSee (row) {
      this.$router.push({
        path: '/stuInfoView',
        query: {
          check: 1,
          xh: row.xh
        }
      })
    }
  },
  computed: {
    xh () {
      return this.$store.getters.getXH
    },
    tableHeight () {
      return this.$store.getters.getTableHeight
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  display: flex;
  margin-bottom: 10px;
  // padding-bottom: 10px;
  // margin-bottom: $top;
  .header-left {
    flex: 5;
    .el-icon-d-arrow-left {
      // margin-right: 5px;
      color: #409eff;
    }
  }
  .header-right {
    flex: 1;
    text-align: right;
  }
  .el-input {
    @extend .form-component;
  }
  /deep/ .el-icon-search:before,
  /deep/ .el-icon-circle-close:before {
    @extend .insert-icon;
  }
}
</style>
