<template>
  <!-- 学生信息查看 -->
  <div class="stuTable">
    <stu-list v-show="!$route.query.check"></stu-list>
    <stu-detail v-show="$route.query.check == 1"></stu-detail>
  </div>
</template>

<script>
import stuList from './components/stuList'
import stuDetail from './components/stuDetail'
export default {
  name: 'stuInfoView',
  components: {
    stuList,
    stuDetail
  },
  data () {
    return {}
  },
  created () {},
  methods: {}
}
</script>

<style lang="scss" scoped>
.stuTable {

}
</style>
