<template>
  <!-- 学生信息待审核列表 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
        <el-select v-model="value" placeholder="全部申请类别" @change="handleSelect">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- <div class="header-right">
                <el-button type="primary">导出</el-button>
      </div>-->
    </div>
    <div class="table-area">
      <el-table
        :data="tableData"
        border
        v-loading="loading"
        element-loading-text="加载中"
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
      >
        <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
        <el-table-column prop="processDefinitionName" label="申请类别" align="center" width="160"></el-table-column>
        <el-table-column prop="xh" label="学号" width="180" align="center"></el-table-column>
        <el-table-column prop="xm" label="姓名" width="120" align="center"></el-table-column>
        <el-table-column prop="xslb" label="学生类别" width="180" align="center"></el-table-column>
        <el-table-column prop="xy" label="所属学院" align="center"></el-table-column>
        <el-table-column prop="zy" label="所属专业" align="center"></el-table-column>
        <el-table-column prop="nj" label="年级" width="120" align="center"></el-table-column>
        <el-table-column prop="createTime" label="申请时间" width="160" align="center" show-overflow-tooltip></el-table-column>
        <el-table-column prop="cz" label="当前审核环节" align="center">
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="handleSee(scope.row)">{{scope.row.name}}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "stuList",
  components: {},
  data() {
    return {
      tableData: [],
      options: [
        {
          value: "stuInfoService",
          label: "全部申请类别"
        },
        {
          value: "stuInfoServiceChangeTeacherApply",
          label: "学生更换导师申请"
        },
        {
          value: "stuInfoServiceDelayGraduateApply",
          label: "学生延迟毕业申请"
        },
        {
          value: "stuInfoServiceDoctorAndMesterApply",
          label: "学生硕博连读申请"
        },
        {
          value: "stuInfoServiceDropOutApply",
          label: "学生退学申请"
        },
        {
          value: "stuInfoServiceFinishGraduateApply",
          label: "学生结业申请"
        },
        {
          value: "stuInfoServiceGoBackSchoolApply",
          label: "学生复学申请"
        },
        {
          value: "stuInfoServiceQuitSchoolApply",
          label: "学生休学申请"
        },
        {
          value: "stuInfoServiceSwitchMajorApply",
          label: "学生转专业申请"
        },
        {
          value: "stuInfoServiceYiYeApply",
          label: "学生肄业申请"
        }
      ],
      value: "stuInfoService",
      stuInfo: "stuInfo", // 加载列表参数
      loading: false,
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 50, // 分页中每页显示条数
        search: ""
      },
      msgCount: 0,
      name: [
        "ReplaceCardApplystuInfo",
        "stuInfoServiceChangeTeacherApply",
        "stuInfoServiceDelayGraduateApply",
        "stuInfoServiceDoctorAndMesterApply",
        "stuInfoServiceDropOutApply",
        "stuInfoServiceFinishGraduateApply",
        "stuInfoServiceGoBackSchoolApply",
        "stuInfoServiceQuitSchoolApply",
        "stuInfoServiceSwitchMajorApply",
        "stuInfoServiceYiYeApply"
      ]
    };
  },
  components: {
    "my-pagination": myPagination
  },
  created() {
    this.loadTable();
  },

  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 56;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },

    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 查看详情
    handleSee(row) {
      // //console.log(row.processDefinitionId.split(':'))
      // console.log(row)
      let lcName = row.processDefinitionId.split(":")[0];
      switch (lcName) {
        case "ReplaceCardApplystuInfo":
          break;
        case "stuInfoServiceChangeTeacherApply":
          // console.log(2)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 2
            }
          });
          break;
        case "stuInfoServiceDelayGraduateApply":
          // console.log(3)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 3
            }
          });
          break;
        case "stuInfoServiceDoctorAndMesterApply":
          // console.log(4)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 4
            }
          });
          break;
        case "stuInfoServiceDropOutApply":
          // console.log(5)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 5
            }
          });
          break;
        case "stuInfoServiceFinishGraduateApply":
          // console.log(6)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 6
            }
          });
          break;
        case "stuInfoServiceGoBackSchoolApply":
          // console.log(7)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 7
            }
          });
          break;
        case "stuInfoServiceQuitSchoolApply":
          // console.log(8)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 8
            }
          });
          break;
        case "stuInfoServiceSwitchMajorApply":
          // console.log(9)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 9
            }
          });
          break;
        case "stuInfoServiceYiYeApply":
          // console.log(10)
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 0,
              id: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 10
            }
          });
          break;
      }
    },
    // 加载列表
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/frontpage/activity/taskStuInfoList", {
          params: {
            definitionKeyLike: this.value,
            pageNum: this.limitQuery.pageNum,
            pageSize: this.limitQuery.pageSize,
            query: this.limitQuery.search,
            type: 0
          }
        })
        .then(res => {
          this.loading = false;
          console.log(res.data.data);
          let data = res.data.data;
          this.tableData = data.list;
          this.msgCount = data.total;
        });
    },
    // 查询
    handleSearch() {
      // if (this.limitQuery.search.length == 0) {
      //   this.$message.error("请输入搜索内容");
      // }
      this.loadTable();
    },
    // 下拉框查询
    handleSelect() {
      this.loadTable();
    },
    // 清空搜索框
    handleClear() {
      this.value = "stuInfoService";
      this.loadTable();
    }
  }
};
</script>

<style lang="scss" scoped>
.main-table {
  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      @extend .form-component;
    }
    .el-button {
      margin-right: $left;
    }
    .el-table{
      width:100%;
    }
  }
}
</style>
