<template>
  <!-- 学生信息审核详情 -->
  <div class>
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button type="primary">导出</el-button>
      </div>
    </div>
    <div class="table-area">
      <change-tutor-save v-if="$route.query.mark == 2" :status="$route.query.sqzt"></change-tutor-save>
      <ycbysq-save v-if="$route.query.mark == 3" :status="$route.query.sqzt"></ycbysq-save>
      <suobo-apply-save v-if="$route.query.mark == 4" :status="$route.query.sqzt"></suobo-apply-save>
      <txsq-save v-if="$route.query.mark == 5" :status="$route.query.sqzt"></txsq-save>
      <jysq-save v-if="$route.query.mark == 6" :status="$route.query.sqzt"></jysq-save>
      <fxsq-save v-if="$route.query.mark == 7" :status="$route.query.sqzt"></fxsq-save>
      <xxsq-save v-if="$route.query.mark == 8" :status="$route.query.sqzt"></xxsq-save>
      <zzysq-save v-if="$route.query.mark == 9" :status="$route.query.sqzt"></zzysq-save>
      <yysq-save v-if="$route.query.mark == 10" :status="$route.query.sqzt"></yysq-save>
      <apply-status :status="$route.query.sqzt"></apply-status>
      <audit-submit :canBack="$route.query.mark != 9 && $route.query.mark != 2"></audit-submit>
    </div>
  </div>
</template>

<script>
// 1
import changeTutorSave from '../../../../pages/personalInfo/changeTutor/components/applySave' // 2
import ycbysqSave from '../../../../pages/personalInfo/stuChange/components/ycbysqSave' // 3
import suoboApplySave from '../../../../pages/personalInfo/suoboApply/components/applySave' // 4
import txsqSave from '../../../../pages/personalInfo/stuChange/components/txsqSave' // 6
import jysqSave from '../../../../pages/personalInfo/stuChange/components/jysqSave' // 5
import fxsqSave from '../../../../pages/personalInfo/stuChange/components/fxsqSave' // 7
import xxsqSave from '../../../../pages/personalInfo/stuChange/components/xxsqSave' // 8
import zzysqSave from '../../../../pages/personalInfo/stuChange/components/zzysqSave' // 9
import yysqSave from '../../../../pages/personalInfo/stuChange/components/yysqSave' // 10

import applyStatus from '../../../../components/applyStatus'
import auditSubmit from '../../../../components/teacher/auditSubmit'
export default {
  name: 'stuDetail',
  components: {
    changeTutorSave,
    ycbysqSave,
    suoboApplySave,
    txsqSave,
    jysqSave,
    fxsqSave,
    xxsqSave,
    zzysqSave,
    yysqSave,
    applyStatus,
    auditSubmit
  },
  data () {
    return {
      status: ''
    }
  },
  methods: {
    // 返回列表
    handleBack () {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  height: $tab-height;
  display: flex;
  .header-left {
    flex: 5;
    .el-icon-d-arrow-left {
      // margin-right: 5px;
      color: #409eff;
    }
  }
  .header-right {
    flex: 1;
    text-align: right;
  }
  .el-input {
    width: 200px;
  }
  .el-button {
    margin-left: 10px;
  }
}
.table-area {
  height: calc(100vh - 208px);
  overflow: auto;
  margin-top: $top;
}
</style>
