<template>
  <!-- 学生信息审核：已审核 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
        <el-select v-model="value" placeholder="全部申请类别" @change="handleSelect">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- <div class="header-right">
                <el-button type="primary">导出</el-button>
      </div>-->
    </div>
    <el-table
      :data="tableData"
      border style="width: 100%"
      v-loading="loading"
      element-loading-text="加载中"
      :header-cell-style="tableHeaderColor"
      :height="tableHeight"
    >
      <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
      <el-table-column prop="processDefinitionName" width="150" label="申请类别" align="center"></el-table-column>
      <el-table-column prop="xh" label="学号" width="150" align="center"></el-table-column>
      <el-table-column prop="xm" label="姓名" width="120" align="center"></el-table-column>
      <el-table-column prop="xslb" label="学生类别" width="150" align="center"></el-table-column>
      <el-table-column prop="xy" label="所属学院" align="center" width="120"></el-table-column>
      <el-table-column prop="zy" label="所属专业" align="center"></el-table-column>
      <el-table-column prop="nj" label="年级" align="center"></el-table-column>
      <el-table-column prop="startTime" label="申请时间" align="center" show-overflow-tooltip></el-table-column>
      <el-table-column prop="state" label="审核结果" align="center">
        <template slot-scope="scope">
          <span
            style="cursor:pointer"
            @click="handleSee(scope.row)"
            :class="scope.row.state | statusFilter"
          >{{ scope.row.state | dsztFilter }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "stuAudited",
  data() {
    return {
      loading: false,
      tableData: [],
      options: [
        {
          value: "stuInfoService",
          label: "全部申请类别"
        },
        {
          value: "stuInfoServiceChangeTeacherApply",
          label: "学生更换导师申请"
        },
        {
          value: "stuInfoServiceDelayGraduateApply",
          label: "学生延迟毕业申请"
        },
        {
          value: "stuInfoServiceDoctorAndMesterApply",
          label: "学生硕博连读申请"
        },
        {
          value: "stuInfoServiceDropOutApply",
          label: "学生退学申请"
        },
        {
          value: "stuInfoServiceFinishGraduateApply",
          label: "学生结业申请"
        },
        {
          value: "stuInfoServiceGoBackSchoolApply",
          label: "学生复学申请"
        },
        {
          value: "stuInfoServiceQuitSchoolApply",
          label: "学生休学申请"
        },
        {
          value: "stuInfoServiceSwitchMajorApply",
          label: "学生转专业申请"
        },
        {
          value: "stuInfoServiceYiYeApply",
          label: "学生肄业申请"
        }
      ],
      value: "stuInfoService",
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ""
      },
      msgCount: 0,
      stuInfo: "stuInfo"
    };
  },
  components: {
    "my-pagination": myPagination
  },
  created() {
    this.loadTable();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 56;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },

    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 加载列表
    loadTable() {
      this.loading = true;
      this.$http
        .get("/api/frontpage/activity/getHistoryAudit2", {
          params: {
            pageNum: this.limitQuery.pageNum,
            pageSize: this.limitQuery.pageSize,
            processKey: this.value,
            query: this.limitQuery.search
          }
        })
        .then(res => {
          this.loading = false;
          // console.log(res.data.data);
          let data = res.data.data;
          this.tableData = data.list;
          // this.pageList.pageNum = data.pageNum
          // this.pageList.pageSize = data.pageSize
          this.msgCount = data.total;
        });
    },
    // 查询
    handleSearch() {
      // if (this.limitQuery.search.length == 0) {
      //   this.$message.error("请输入搜索内容");
      // }
      this.loadTable();
    },
    // 下拉框查询
    handleSelect() {
      this.loadTable();
    },
    // 清空搜索框
    handleClear() {
      this.value = "stuInfoService";
      this.loadTable();
    },
    // 查看详情params：已审核5，待审核6
    handleSee(row) {
      // //console.log(row.processDefinitionId.split(':'))
      // console.log(row);
      let lcName = row.processDefinitionId.split(":")[0];
      // console.log("stuAudited:235:" + lcName);
      switch (lcName) {
        case "ReplaceCardApplystuInfo":
          // console.log(1);
          // this.$router.push({
          //     path: '/stuInfoAudit',
          //     query: {
          //         id: row.processInstanceId,
          //         mark: 1
          //     }
          // })
          break;
        case "stuInfoServiceChangeTeacherApply":
          // console.log(2);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 2
            }
          });
          break;
        case "stuInfoServiceDelayGraduateApply":
          // console.log(3);
          // console.log("stuAudited:261:" + row.state);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 3
            }
          });
          break;
        case "stuInfoServiceDoctorAndMesterApply":
          // console.log(4);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 4
            }
          });
          break;
        case "stuInfoServiceDropOutApply":
          // console.log(5);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 5
            }
          });
          break;
        case "stuInfoServiceFinishGraduateApply":
          // console.log(6);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 6
            }
          });
          break;
        case "stuInfoServiceGoBackSchoolApply":
          // this.getData6(row)
          // console.log(7);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 7
            }
          });
          break;
        case "stuInfoServiceQuitSchoolApply":
          // console.log(8);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 8
            }
          });
          break;
        case "stuInfoServiceSwitchMajorApply":
          // console.log(9);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 9
            }
          });
          break;
        case "stuInfoServiceYiYeApply":
          // console.log(10);
          this.$router.push({
            path: "/stuInfoAudit",
            query: {
              check: 1,
              id: row.processInstanceId,
              sqzt: row.state,
              mark: 10
            }
          });
          break;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.main-table {
  .header {
    height: $tab-height;
    margin-bottom: $top;
    display: flex;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
    /deep/ .el-select {
      margin-left: $left;
    }
  }
}
</style>
