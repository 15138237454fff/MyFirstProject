<template>
  <!-- 学生信息审核 -->
  <div class="stuTable">
    <el-tabs v-show="!$route.query.mark" v-model="activeName" @tab-click="tabClick">
      <el-tab-pane label="待审核" name="first">
        <stu-list
          ref="myChild1"
          v-if="activeName === 'first' && $route.fullPath === '/stuInfoAudit?check=0' || $route.fullPath === '/stuInfoAudit'"
        ></stu-list>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="second">
        <stu-audited
          ref="myChild2"
          v-if="activeName === 'second' && $route.fullPath === '/stuInfoAudit?check=1'"
        ></stu-audited>
      </el-tab-pane>
    </el-tabs>

    <stu-detail v-show="$route.query.mark"></stu-detail>
  </div>
</template>

<script>
import stuList from './components/stuList'
import stuAudited from './components/stuAudited'
import stuDetail from './components/stuDetail'

export default {
  name: 'stuInfoAudit',
  components: {
    stuList,
    stuAudited,
    stuDetail
  },
  data () {
    return {
      activeName: 'first'
    }
  },
  mounted () {
    // 将当前显示的tab标签与路由地址绑定，防止页面在f5刷新后组件不挂载
    let to = this.$route
    if (to.fullPath === '/stuInfoAudit?check=1') {
      this.activeName = 'second'
    } else if (
      to.fullPath === '/stuInfoAudit?check=0' ||
      to.fullPath === '/stuInfoAudit'
    ) {
      this.activeName = 'first'
    }
  },
  methods: {
    // tab切换
    // 已审核：1
    tabClick (t) {
      if (t.label == '待审核') {
        this.activeName = 'first'
        this.$router.push({
          path: '/stuInfoAudit',
          query: {
            check: 0
          }
        })
        // this.$refs.myChild1.loadTable();
      }
      if (t.label == '已审核') {
        this.activeName = 'second'
        this.$router.push({
          path: '/stuInfoAudit',
          query: {
            check: 1
          }
        })
        // this.$refs.myChild2.loadTable();
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.stuTable {
  /deep/ .el-tabs__nav-wrap {
    background:$white
  }
  /deep/ .el-tabs__nav {
    margin-left: $left;
  }
  /deep/ .el-tabs__item {
    @extend .min-tab-view;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin-bottom: $top;
  }
}
</style>
