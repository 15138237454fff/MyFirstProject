<template>
  <div class="main">
    <div class="title">
      <div class="back">
        <i class="el-icon-d-arrow-left"></i>
        <el-button @click="goBack">返回</el-button>
      </div>
    </div>
    <div class="box">
      <div class="box-title">· {{noticeMsg.bt}} ·</div>
      <div class="box-content" v-html="noticeMsg.zw"></div>
      <div class="fjList">
        相关附件：
        <div v-for="(item,index) of noticeMsg.fj" :key="index">
          <a :href="item.url" class="file-link" :download="item.fileName">{{item.fileName}}</a>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'noticeDetail',
  props: {
    id: { default: 0 }
  },
  data () {
    return {
      noticeMsg: { bt: '', zw: '', fj: [] }
    }
  },
  mounted () {
    this.requireNoticeDetail()
  },
  methods: {
    // 点击返回后退
    goBack () {
      this.$router.go(-1)
    },
    // 请求公告详情
    requireNoticeDetail () {
      this.$http.get('/api/system/notice/selectUp/' + this.id).then(result => {
        // console.log(result);
        let data = result.data.data
        // console.log(data,55) //接口报500
        if (!data) {
          this.$message.error('获取通知详情数据失败')
          return false
        }
        this.noticeMsg.bt = data.bt
        this.noticeMsg.zw = data.zw
        this.noticeMsg.fj = data.xtWjscjlbVos
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.main {
  flex-wrap: wrap;
  .title {
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: 52px;
    background: #eee;
    margin-bottom: 20px;
    .back {
      padding-left: 20px;
      line-height: 52px;
      font-weight: 400;
      .el-button,
      i {
        border: none;
        outline: none;
        font-size: 14px;
        color: #1890ff;
        padding: 0;
        &:hover {
          background: #fff;
        }
      }
    }
  }
  .box {
    width: 96%;
    padding: 20px;
    border: 1px solid #ddd;
    margin: 0 auto;
    .box-title {
      font-size: 16px;
      color: #1e1e1e;
      font-weight: 700;
      border-bottom: 1px solid #ddd;
      padding-bottom: 20px;
      text-align: center;
    }
    .box-content {
      padding-top: 20px;
      height: 500px;
    }
    .file-link {
      text-decoration: underline;
      color: #1890ff;
    }
    .fjList {
      display: flex;
      div:not(:first-child) {
        &:before {
          content: "，";
        }
      }
    }
  }
}
</style>
