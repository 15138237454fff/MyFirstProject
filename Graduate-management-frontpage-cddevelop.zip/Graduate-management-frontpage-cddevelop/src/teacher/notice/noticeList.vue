<template>
  <div class="main">
    <div class="title">
      <div class="back">
        <i class="el-icon-d-arrow-left"></i>
        <el-button @click="goBack">返回</el-button>
      </div>
    </div>
    <div class="box">
      <div class="box-title">通知公告</div>
      <ul class="box-content">
        <li class="msgItem" v-for="(item,index) of msgList" :key="item.bt" @click="goDetail(item.id)">
          <span class="content">· {{item.bt}}</span>
          <span class="time">{{item.cjsj|toDate}}</span>
        </li>
      </ul>
      <!-- 分页 -->
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="msgCount"
      ></my-pagination>
    </div>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'noticeList',
  data () {
    return {
      // 分页查询参数
      limitQuery: {
        pageNum: 1,
        pageSize: 10,
        zt: 1,
        query: ''
      },
      // 通知消息列表
      msgList: [],
      // 通知消息总条数
      newCount: 0
    }
  },
  mounted () {
    this.requireMsgList()
  },
  components: {
    'my-pagination': myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.requireMsgList()
    },
    // 请求通知公告消息列表
    requireMsgList () {
      this.$http
        .post('/api/system/notice/list', this.limitQuery)
        .then(result => {
          let data = result.data.data
          // 非空验证
          if (!data.list) {
            this.$message.error('通知公告消息获取失败')
            return false
          }
          this.msgList = data.list
          this.newCount = data.total
          // console.log(this.msgList);
        })
    },
    // 后退
    goBack () {
      this.$router.go(-1)
    },
    // 前往对应通知详情
    goDetail (id) {
      // console.log(id);
      this.$router.push('/teacherNoticeDetail/' + id)
    }
  },
  
}
</script>
<style lang="scss" scoped>
.main {
  flex-wrap: wrap;
  .title {
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: $tab-height;
    margin-bottom: $top;
    .back {
      font-weight: 400;
      line-height: $tab-height;
      .el-button,
      i {
        border: none;
        outline: none;
        font-size: 14px;
        color: #1890ff;
        padding: 0;
        &:hover {
          background: #fff;
        }
      }
    }
  }
  .box {
    padding: $top;
    border: 1px solid #ddd;
    .box-title {
      font-size: 16px;
      color: #1e1e1e;
      font-weight: 700;
      border-bottom: 1px solid #ddd;
      height: $tab-height;

    }
    .box-content {
      height: calc(100vh - 332px);
      overflow: auto;
    }
    .msgItem {
      border-bottom: 1px dashed #ddd;
      display: flex;
      justify-content: space-between;
      height: $tab-height;
      line-height: $tab-height;
      .content {
        font-weight: 700;
      }
      .time {
        font-size: 12px;
      }
    }
  }
}
</style>
