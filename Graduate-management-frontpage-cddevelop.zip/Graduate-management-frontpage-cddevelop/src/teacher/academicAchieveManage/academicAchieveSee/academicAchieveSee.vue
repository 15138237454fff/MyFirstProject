<template>
  <div class="academicAchieveSee">
    <!-- 个人成果查询 achieveQuery -->
    <div class="head">
      <div class="btnGroup" v-if="id == 2">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          v-model="limitQuery.query"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select v-model="limitQuery.status" placeholder="全部申请类别" @change="loadTable">
          <el-option
            v-for="item in genre"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <div class="change" v-else>
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回</el-button>
      </div>
      <div class="btn-right">
        <el-button type="primary" @click="output">导出</el-button>
      </div>
    </div>
    <div class="table-area">
      <div v-if="id == 2" class="tableList">
        <el-table
          :data="tableData"
          tooltip-effect="dark"
          border
          v-loading="loading"
          element-loading-text="加载中"
          style="width: 100%;"
          :height="tableHeight"
          :header-cell-style="$tableHeaderColor"
        >
          <el-table-column type="index" width="50" align="center" label="序号"></el-table-column>
          <el-table-column prop="studentNumber" label="学号"></el-table-column>
          <el-table-column prop="name" label="姓名"></el-table-column>
          <el-table-column prop="college" label="所属学院"></el-table-column>
          <el-table-column prop="major" label="所属专业"></el-table-column>
          <el-table-column prop="resultsName" label="成果名称"></el-table-column>
          <el-table-column prop="resultsType" label="成果类型">
            <template slot-scope="scope">
              <span>{{scope.row.resultsType | resultsType}}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="120">
            <template slot-scope="scope">
              <el-button
                @click="$router.push(`/academicAchieveSee/3/${scope.row.executionId}?resultsType=${scope.row.resultsType}`)"
                type="text"
                size="small"
              >查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div v-else>
        <xslw v-if="resultsType === '1'" :id="id" :executionId="executionId"></xslw>
        <jszl v-if="resultsType === '2'" :id="id" :executionId="executionId"></jszl>
        <fbzz v-if="resultsType === '3'" :id="id" :executionId="executionId"></fbzz>
        <kyxm v-if="resultsType === '4'" :id="id" :executionId="executionId"></kyxm>
      </div>
    </div>
    <!-- 分页 -->
    <my-pagination
      v-if="id == 2"
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import fbzz from '../../../pages/academicAchieve/achieveInput/components/fbzz'
import jszl from '../../../pages/academicAchieve/achieveInput/components/jszl'
import kyxm from '../../../pages/academicAchieve/achieveInput/components/kyxm'
import xslw from '../../../pages/academicAchieve/achieveInput/components/xslw'
import myPagination from '@/components/myPagination'
export default {
  name: 'academicAchieveSee',
  props: {
    id: {},
    executionId: {}
  },
  data () {
    return {
      // 表格显示的数据
      tableData: [],
      // 数据加载状态
      loading: false,
      // 分页查询的参数
      limitQuery: {
        pageNum: 1,
        pageSize: 10,
        query: '',
        status: null
      },
      // 总条数
      msgCount: 0,
      // 学术成果类型可选列表
      genre: [
        {
          value: null,
          label: '全部成果类型'
        },
        {
          value: '1',
          label: '学术论文'
        },
        {
          value: '2',
          label: '技术专利'
        },
        {
          value: '3',
          label: '发表著作'
        },
        {
          value: '4',
          label: '科研项目'
        }
      ]
    }
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight
    }
  },
  components: {
    fbzz,
    jszl,
    kyxm,
    xslw,
    'my-pagination': myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 导出的方法
    output () {
      console.log('导出。。。')
    },
    // 查询列表数据
    loadTable () {
      this.loading = true
      this.$http.post('/api/academic/aac/view', this.limitQuery).then(res => {
        console.log(res)
        this.loading = false
        let data = res.data.data
        // 非空验证
        if (!data) {
          this.$message.error('获取个人学术成果列表数据失败，请重试')
          return
        }
        // 记录消息总数
        this.msgCount = data.total
        this.tableData = data.list
      })
    },
    detailStatus () {
      if (this.id === '3') {
        this.resultsType = this.$route.query.resultsType
        // 如果进入查看/修改详情页面，请求对应流程id的审核状态
        this.$http
          .get('/api/academic/aac/' + this.$route.params.executionId)
          .then(res => {
            let data = res.data.data
            if (!Array.isArray(data)) {
              this.$message.error('获取审核具体流程数据失败，请刷新重试')
              return
            }
            // 将审核具体流程数据发送给applyStatus
            this.$bus.$emit('stepList', data)
          })
      }
    }
  },
  created () {
    this.loadTable()
    this.detailStatus()
  },
  watch: {
    $route (to) {
      if (to.name === 'academicAchieveSee') {
        this.loadTable()
        this.detailStatus()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.academicAchieveSee {
  // background-color: rgb(247, 251, 255);
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    white-space: nowrap;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  .head {
    height: $tab-height;
    display: flex;
    margin-bottom: 10px;
    // margin-bottom: $top;
    justify-content: space-between;
    align-items: center;
    .btnGroup {
      display: flex;
      justify-content: left;
      align-items: center;
      // padding: 5px;
      .el-input {
        width: 200px;
      }
      .el-button {
        margin: 0 $left;
        height: 40px;
      }
    }
    .change {
      font-size: 14px;
      .el-icon-document,
      .el-icon-d-arrow-left {
        margin-right: 5px;
        color: #409eff;
      }
    }
  }
  .table-area {
    display: flex;
    flex-direction: column;
    height: calc(100vh - 208px);
    overflow: auto;
  }

  /deep/ .table-box {
    font-size: 14px;
    width: 100%;
    box-sizing: border-box;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        span {
          color: #1890ff;
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        .kh,
        .khdm {
          display: inline-block;
        }
        .kh {
          width: 45%;
          margin-right: 5px;
        }
        .khdm {
          width: 50%;
        }
        .qklb {
          width: 100%;
        }
        &.contentTd {
          background: #fff;
          padding: 0 10px;
        }
        .add {
          font-size: 24px;
          color: #1e6fd9;
          border-radius: 50%;
          padding-left: 20px;
          background: #fff;
          outline: none;
          border: none;
        }
        /deep/ .el-textarea__inner {
          font-size: 14px;
          color: #333;
        }
      }
    }
    .tx-msg {
      line-height: 30px;
      color: #ff5a5a;
    }
    .submitBtn {
      text-align: right;
    }
    [type="textarea"] {
      resize: none;
    }
  }
}
</style>
