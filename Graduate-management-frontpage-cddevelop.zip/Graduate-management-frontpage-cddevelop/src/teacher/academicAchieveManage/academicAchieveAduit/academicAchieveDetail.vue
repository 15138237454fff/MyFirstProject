<template>
  <div class="academicAchieveDetail">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
    </div>
    <div class="table-area" v-if="id == 3">
      <my-xslw
        v-if="resultsType == 1"
        :id="id"
        :executionId="executionId"
      ></my-xslw>
      <my-jszl
        v-if="resultsType == 2"
        :id="id"
        :executionId="executionId"
      ></my-jszl>
      <my-fbzz
        v-if="resultsType == 3"
        :id="id"
        :executionId="executionId"
      ></my-fbzz>
      <my-kyxm
        v-if="resultsType == 4"
        :id="id"
        :executionId="executionId"
      ></my-kyxm>
      <apply-status></apply-status>
      <academic-submit v-if="check == 0" :lcid="executionId"></academic-submit>
    </div>
  </div>
</template>
<script>
import fbzz from "../../../pages/academicAchieve/achieveInput/components/fbzz";
import jszl from "../../../pages/academicAchieve/achieveInput/components/jszl";
import kyxm from "../../../pages/academicAchieve/achieveInput/components/kyxm";
import xslw from "../../../pages/academicAchieve/achieveInput/components/xslw";
import academicSubmit from "./components/academicSubmit";
import applyStatus from "../../../components/applyStatus";
export default {
  name: "academicAchieveDetail",
  props: {
    id: {},
    executionId: {},
    check: {}
  },
  components: {
    "my-fbzz": fbzz,
    "my-jszl": jszl,
    "my-kyxm": kyxm,
    "my-xslw": xslw,
    "academic-submit": academicSubmit,
    "apply-status": applyStatus
  },
  data() {
    return {
      resultsType: "",
      from:''
    };
  },
  created(){
    console.log(this.$route.query.from)
    this.from = this.$route.query.from ? this.$route.query.from : ''
  },
  mounted() {
    this.detailStatus();
    console.log(this.check);
  },
  methods: {
    detailStatus() {
      if (this.id == 3) {
        // console.log("hahah");
        this.resultsType = this.$route.query.resultsType;
        // 如果进入查看/修改详情页面，请求对应流程id的审核状态
        this.$http.get("/api/academic/aac/" + this.executionId).then(res => {
          // console.log("aaaa");
          let data = res.data.data;
          // console.log(data);
          if (!Array.isArray(data)) {
            this.$message.error("获取审核具体流程数据失败，请刷新重试");
            return;
          }
          // 将审核具体流程数据发送给applyStatus
          this.$bus.$emit("stepList", data);
        });
      }
    },
    goBack(){
      this.$router.push({path:'/academicAchieveAduit',query:{from:this.from}})
    }
  }
};
</script>
<style lang="scss" scoped>
.academicAchieveDetail {
  .header {
    height: $tab-height;
    display: flex;
    // background: #f0f2f5;
    align-items: center;
    margin-bottom: 10px;
    // margin-bottom: $top;
    .header-left {
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
  }
  .table-area {
    background-color: #fff;
    height: calc(100vh - 208px);
    overflow: auto;
    /deep/ .el-tabs__item {
      width: 25% !important;
    }
    /deep/ .table-box {
      font-size: 14px;
      width: 100%;
      box-sizing: border-box;
      table {
        width: 100%;
        border-collapse: collapse;
        color: #333;
        border: none;
        border-color: rgba(228, 228, 228, 1);
        thead > th {
          text-align: center;
          font-size: 20px;
          padding: 10px;
          line-height: 40px;
          overflow: hidden;
        }
        tbody > th {
          text-align: left;
          font-weight: 700;
          padding: 11px 2px 11px 10px;
          span {
            color: #1890ff;
          }
        }
        td {
          width: 200px;
          height: 40px;
          &:nth-child(odd) {
            background: #f2f2f2;
            padding-left: 10px;
          }
          &:nth-child(even) {
            text-align: center;
          }
          .range /deep/ .el-input {
            width: 25%;
          }
          .kh,
          .khdm {
            display: inline-block;
          }
          .kh {
            width: 45%;
            margin-right: 5px;
          }
          .khdm {
            width: 50%;
          }
          .qklb {
            width: 100%;
          }
          &.contentTd {
            background: #fff;
            padding: 0 10px;
          }
          .add {
            font-size: 24px;
            color: #1e6fd9;
            border-radius: 50%;
            padding-left: 20px;
            background: #fff;
            outline: none;
            border: none;
          }
          /deep/ .el-textarea__inner {
            font-size: 14px;
            color: #333;
          }
        }
      }
      .tx-msg {
        line-height: 30px;
        color: #ff5a5a;
      }
      .submitBtn {
        text-align: right;
      }
      [type="textarea"] {
        resize: none;
      }
    }
  }
}
</style>
