<template>
  <div class="academicAchieveAduit">
    <el-tabs v-model="tabName">
      <el-tab-pane label="待审核" name="waitAduit">
        <wait-aduit v-if="tabName === 'waitAduit'"></wait-aduit>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="isAduited">
        <is-aduited v-if="tabName === 'isAduited'"></is-aduited>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import waitAduit from './components/waitAduit'
import isAduited from './components/isAduited'
export default {
  name: 'academicAchieveAduit',
  components: {
    waitAduit,
    isAduited
  },
  data () {
    return {
      tabName: 'waitAduit'
    }
  },
  created(){
    this.tabName = this.$route.query.from ? this.$route.query.from : 'waitAduit'
  }
}
</script>
<style scoped lang="scss">
.academicAchieveAduit {
  /deep/ .el-tabs__nav-wrap {
    background:$white
  }
  /deep/ .el-tabs__nav {
    margin-left: $left;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    // margin: 0 0 $top;
    margin-bottom: 10px;
  }
}
</style>
