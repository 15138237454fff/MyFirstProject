<template>
  <div class="isAduit">
    <div class="header">
      <div class="header-left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入学号/姓名"
          clearable
          @clear="limitQuery.query = ''"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select v-model="limitQuery.status" placeholder="全部成果类型" clearable @change="loadTable">
          <el-option
            :label="item.label"
            :value="item.value"
            v-for="(item,index) in genre"
            :key="index"
          ></el-option>
        </el-select>
      </div>
    </div>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$tableHeaderColor"
    >
      <el-table-column label="序号" type="index" width="50"></el-table-column>
      <el-table-column label="成果类型">
        <template slot-scope="scope">
          <span>{{scope.row.resultsType | resultsType}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="resultsName" label="成果名称"></el-table-column>
      <el-table-column prop="name" label="申请人"></el-table-column>
      <el-table-column prop="studentNumber" label="申请人学号"></el-table-column>
      <el-table-column prop="applyDate" label="申请时间"></el-table-column>
      <el-table-column label="审核状态">
        <template slot-scope="scope">
          <el-button
            @click="goSee(scope.$index)"
            type="text"
            size="small"
            :class="scope.row.status|dsstatusFilter"
          >{{scope.row.status|dsztFilter}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'isAduit',
  data () {
    return {
      // 表格展示的数据
      tableData: [],
      // 分页查询的参数
      limitQuery: {
        query: '',
        pageSize: 10,
        pageNum: 1,
        status: null
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 学术成果类型列表
      genre: [
        {
          value: null,
          label: '全部成果类型'
        },
        {
          value: 1,
          label: '学术论文'
        },
        {
          value: 2,
          label: '技术专利'
        },
        {
          value: 3,
          label: '发表著作'
        },
        {
          value: 4,
          label: '科研项目'
        }
      ]
    }
  },
  components: {
    'my-pagination': myPagination
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 56
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 改变列表页条数大小回调函数
    handleSizeChange (val) {
      this.limitQuery.pageSize = val
      // 重新请求列表数据
      this.loadTable()
    },
    // 改变当前页
    handleCurrentChange (val) {
      this.limitQuery.pageNum = val
      // 重新请求列表数据
      this.loadTable()
    },
    // 请求列表数据的方法
    loadTable () {
      this.loading = true
      this.$http
        .post('/api/academic/aac/checked', this.limitQuery)
        .then(res => {
          this.loading = false
          let data = res.data
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message)
            return
          }
          data = data.data
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.info)) {
            this.$message.error('待审核数据请求失败，请刷新')
            return
          }
          this.tableData = data.info
          this.msgCount = data.total
        })
    },
    // 前往查看的方法
    goSee (index) {
      console.log('正在前往审核学生：' + this.tableData[index].executionId)
      this.$router.push({
        name: 'academicAchieveDetail',
        params: {
          executionId: this.tableData[index].executionId,
          check: 1,
          id: '3'
        },
        query: {
          resultsType: this.tableData[index].resultsType,
          from:'isAduited'
        }
      })
    }
  },
  created () {
    this.loadTable()
  },
  watch: {
    $route (to) {
      if (to.name === 'academicAchieveAduit') this.loadTable()
    }
  }
}
</script>
<style scoped lang="scss">
.isAduit {
  width: 100%;
  .block {
    text-align: center;
    margin-bottom: 20px;
  }

  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: 10px;
    // margin-bottom: $top;
    /deep/ .el-select {
      margin-left: $left;
    }
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
}
</style>
