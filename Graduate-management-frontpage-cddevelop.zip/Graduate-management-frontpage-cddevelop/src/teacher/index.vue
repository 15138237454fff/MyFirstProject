<template>
  <!-- <div style="height:100%"> -->
  <!-- 导师主页 -->
  <div class="layout">
    <head-nav></head-nav>
    <side-bar></side-bar>
    <div class="inside" :class="{ 'content-collapse': collapse }">
      <tags></tags>
      <div class="content-area">
        <transition
          :duration="300"
          mode="out-in"
          appear
          enter-active-class="animated fadeIn"
          leave-active-class="animated fadeOut"
          appear-active-class="animated zoomInDown"
        >
          <keep-alive :include="tagsList">
            <router-view></router-view>
          </keep-alive>
        </transition>
      </div>
    </div>
    <my-dialog></my-dialog>
  </div>
  <!-- </div> -->
</template>

<script>
import headNav from "../components/headNav";
import sideBar from "../components/teacher/sideBar";
import tags from "../components/teacher/tags";
import myDialog from "../components/myDialog";
export default {
  name: "teacher",
  components: {
    headNav,
    sideBar,
    tags,
    myDialog
  },
  data() {
    return {
      collapse: false,
      tagsList: [],
      waitTime: 30 * 60 * 1000,
      timer: null
    };
  },
  created() {
    this.$bus.$on("collapse", msg => {
      this.collapse = msg;
    });
    // 只有在标签页列表里的页面才使用keep-alive，即关闭标签之后就不保存到内存中了。
    // this.$bus.$on("tags", msg => {
    //   let arr = [];
    //   for (let i = 0, len = msg.length; i < len; i++) {
    //     msg[i].name && arr.push(msg[i].name);
    //   }
    //   this.tagsList = arr;
    // });
  },
  mounted() {
    // 页面挂载后获取表格高度
    this.$store.commit("updateTableHeight");
    // 窗口大小改变后获取表格高度
    window.onresize = () => {
      return (() => {
        this.$store.commit("updateTableHeight");
      })();
    };
    this.startTimeOut();
  },
  methods: {
    throttle() {
      console.log("重置定时器");
      clearTimeout(this.timer);
      this.timer = setTimeout(this.handleOutlog, this.waitTime);
    },
    handleOutlog() {
      console.log("退出登录");
      clearTimeout(this.timer);
      this.endTimeOut();
      // 清空用户登录信息
      this.$store.commit("updatedUser", {
        xh: "",
        token: "",
        userSsy: "",
        id: "",
        name: "",
        userStatus: ""
      });
      if (this.$route.path === "/login") {
        return;
      }
      this.$message.error("长时间无操作，强制退出");
      this.$router.push("/login");
    },
    startTimeOut() {
      document.body.onmousemove = this.throttle;
    },
    endTimeOut() {
      this.timer = null;
      document.body.onmousemove = null;
    }
  },
  destroyed() {
    this.endTimeOut();
  }
};
</script>

<style lang="scss" scoped>
.layout {
  height: 100%;
  // position: relative;
}
.layout /deep/ .el-main {
  padding: 0;
}
.inside {
  // width: 100%;
  display: block;
  position: absolute;
  top: 80px;
  right: 0;
  bottom: 0;
  left: 230px;
  transition: left 0.3s ease-in-out;
  overflow: hidden;
  // background: #f0f0f0;
  background: #fff;
  .content-area {
    position: relative;
    overflow: hidden;
    height: calc(100vh - 120px);
    padding: 10px 20px;
    box-sizing: border-box;
  }
}
/deep/ .el-table td {
  height: 43px;
}
.content-collapse {
  // width: 64px;
  left: 64px;
  // transition: left .3s ease-in-out;
}
</style>
