<template>
  <div class="main">
    <div class="title">
      <div class="back">
        <i class="el-icon-d-arrow-left"></i>
        <el-button @click="goBack">返回</el-button>
      </div>
    </div>
    <div class="box">
      <div class="box-title">待办事项</div>
      <ul class="box-content">
        <li
          class="msgItem"
          v-for="(item, index) of msgList"
          :key="index"
          @click="goDetail(item)"
        >
          <span class="content"
            >· 您有1条{{ item.xm }}的{{ item.processDefinitionName }}</span
          >
          <span class="time">{{ item.createTime }}</span>
        </li>
      </ul>
      <!-- 分页 -->
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="msgCount"
      ></my-pagination>
    </div>
  </div>
</template>
<script>
import myPagination from "@/components/myPagination";
export default {
  name: "waitThing",
  data() {
    return {
      // 代办消息列表
      msgList: [],
      // 分页参数
      limitQuery: {
        pageNum: 1,
        pageSize: 10
      },
      // 总消息条数
      msgCount: 0,
      // 待办事项消息路由对照表
      newTeaMsgMap: {
        // 通知列表
        tzList: "/teacherNoticeList",
        // 录入信息
        cglrsj: "/stuScoreManage",
        // 个人培养计划申请
        stuTrainingPlanApply: "/trainPlanAudit",
        // 个人培养计划课程调整申请
        stuKcsqServiceChangeCourseApply: "/stuCourseAudit",
        // 教师调课申请
        teaSwitchClassApply: "/courseManage?query=3",
        // 免修申请
        stuKcsqServiceExemptionApply: "/stuCourseAudit",
        // 缓考申请
        stuKcsqServiceDelayedExamApply: "/stuCourseAudit",
        // 重修申请
        stuKcsqRebuildApply: "/stuCourseAudit",
        // 学生肄业申请
        stuInfoServiceYiYeApply: "/stuInfoAudit",
        // 学生转专业申请
        stuInfoServiceSwitchMajorApply: "/stuInfoAudit",
        // 学生休学申请
        stuInfoServiceGoBackSchoolApply: "/stuInfoAudit",
        // 学生复学申请
        stuInfoServiceGoBackSchoolApply: "/stuInfoAudit",
        // 学生结业申请
        stuInfoServiceFinishGraduateApply: "/stuInfoAudit",
        // 学位资格申请
        DegreeApplication: "/academicDegreeAduit/2",
        // 学术成果申请
        academicApply: "/academicAchieveAduit",
        // 研究生证补办
        stuInfoReplaceCardApply: "/teacherHome",
        // 学生更换导师申请
        stuInfoServiceDelayGraduateApply: "/stuInfoAudit",
        // 学生延迟毕业申请
        stuInfoServiceDoctorAndMesterApply: "/stuInfoAudit",
        // 学生硕博连读申请
        stuInfoServiceDoctorAndMesterApply: "/stuInfoAudit",
        // 学生退学申请
        stuInfoServiceDropOutApply: "/stuInfoAudit",
      }
    };
  },
  components: {
    "my-pagination": myPagination
  },
  mounted() {
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    // 请求代办事项消息列表
    loadTable() {
      this.$http
        .get(
          "/api/system/dbsx/selectRuTaskList/" +
            this.limitQuery.pageNum +
            "/" +
            this.limitQuery.pageSize,
          {
            params: {
              type: 0
            }
          }
        )
        .then(result => {
          this.msgCount = result.data.data.total;
          let data = result.data.data.list;
          // console.log(data);
          // 非空验证
          if (!data) {
            this.$message.error("待办事项消息获取失败");
            return false;
          }
          // data.sort((a, b) => {
          //   return new Date(b.createTime) - new Date(a.createTime)
          // })
          this.msgList = data;
          // console.log(this.msgList);
        });
    },
    // 后退
    goBack() {
      this.$router.go(-1);
    },
    // 前往对应的通知公告详情
    goDetail(row) {
      let path = row.processDefinitionId.split(":")[0];
      this.$router.push({ path: this.newTeaMsgMap[path] });
    },
    // 分页功能
    handlePageNumChange(pno) {
      this.limitQuery.pageNum = pno;
      this.loadTable();
    },
    handlePageSizeChange(size) {
      this.limitQuery.pageSize = size;
      this.loadTable();
    }
  }
};
</script>
<style lang="scss" scoped>
.main {
  flex-wrap: wrap;
  .title {
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: $tab-height;
    margin-bottom: $top;
    // background: #eee;
    .back {
      line-height: $tab-height;
      font-weight: 400;
      .el-button,
      i {
        border: none;
        outline: none;
        font-size: 14px;
        color: #1890ff;
        padding: 0;
        &:hover {
          background: #fff;
        }
      }
    }
  }
  .box {
    padding: $top;
    border: 1px solid #ddd;

    .box-title {
      font-size: 16px;
      color: #1e1e1e;
      font-weight: 700;
      border-bottom: 1px solid #ddd;
      height: $tab-height;
    }
    .msgItem {
      border-bottom: 1px dashed #ddd;
      display: flex;
      justify-content: space-between;
      height: $tab-height;
      line-height: $tab-height;
      .content {
        font-weight: 700;
      }
      .time {
        font-size: 12px;
      }
    }
    .box-content {
      height: calc(100vh - 332px);
      overflow: auto;
      li {
        cursor: pointer;
      }
    }
  }
}
</style>
