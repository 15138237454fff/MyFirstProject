<template>
  <div class="projectReport">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.xmlx" @change="initLoadTable">
          <el-option
            v-for="item in typeOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%;margin-top:16px"
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        ref="box"
      >
        <el-table-column
          prop="xmMc"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="xmlx"
          label="项目类型"
          align="center"
          :width="250"
        >
          <template slot-scope="scope">
            {{ scope.row.xmlx | xmlxFilter }}
          </template>
        </el-table-column>
        <el-table-column
          label="项目要求"
          align="center"
          show-overflow-tooltip
          width="120px"
        >
          <template slot-scope="scope">
            <span
              @click="clickProjectRequest(scope.row.xmId)"
              class="blue under-line cursor-pointer"
              >项目要求</span
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="pjdja"
          label="有效时间"
          align="center"
          :width="200"
        >
          <template slot-scope="scope">
            <span
              >{{ $tagTime(scope.row.yssjKssj, "yyyy.MM.dd") }} 至
              {{ $tagTime(scope.row.yssjJssj, "yyyy.MM.dd") }}</span
            >
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" width="120px">
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="small"
              @click="clickToApplay(scope.row.xmlx, scope.row.xmId)"
              v-if="scope.row.id === null"
              >申请</el-button
            >
            <el-button class="grey" size="small" v-else disabled
              >已申请</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <div>
          <span>项目名称：</span>
          <span>{{ formData.xmMc }}</span>
        </div>
        <div>
          <span>项目类型：</span>
          <span>{{ formData.xmlx | xmlxFilter }}</span>
        </div>
        <div>
          <span>有效时间：</span>
          <span
            >{{ this.$tagTime(formData.yssjKssj, "yyyy-MM-dd") }} 至
            {{ this.$tagTime(formData.yssjJssj, "yyyy-MM-dd") }}</span
          >
        </div>
        <div class="project-request">
          <span>项目要求：</span>
          <div class="request-content" v-html="formData.xmyq"></div>
        </div>
        <div>
          <span>相关附件：</span>
          <span v-for="(item, index) of formData.files" :key="index"
            ><a
              :href="item.url"
              class="under-line"
              target="_blank"
              :download="formData.fileName"
              >{{ item.fileName }}</a
            ><span v-if="index !== formData.files.length - 1">，</span></span
          >
        </div>
      </div>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
import myModal from "@/components/common/myModal";
export default {
  name: "projectReport",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        xmlx: null
      },
      formData: {
        // 有效时间-结束
        yssjJssj: "",
        // 有效时间-开始时间
        yssjKssj: "",
        // 发布对象 0-教职工 1-学生
        fbdx: "",
        files: [],
        // 项目名称
        xmMc: "",
        // 项目类型
        xmlx: "",
        // 项目要求
        xmyq: ""
      },
      typeOptions: [
        { label: "全部项目类型", value: null },
        { label: "硕士研究生课程建设项目", value: 1 },
        { label: "博士研究生课程建设项目", value: 2 },
        { label: "专业学位研究生课程案例库建设项目", value: 3 }
      ],
      loading: false,
      msgCount: 0,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-project-detail"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-modal": myModal
  },
  mounted() {
    this.loadTable();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 10;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/teacherApply/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击查看项目要求
    clickProjectRequest(id) {
      this.modalOption.title = `项目要求`;
      this.requireProjectRequest(id);
    },
    // 请求项目要求详情
    requireProjectRequest(id) {
      this.$http
        .get(`/api/education/projectPublish/getInfo/${id}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("项目要求详情数据获取失败");
            return false;
          }
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.modalOption.modalVisiabal = true;
        })
        .catch(err => {
          this.$message(err.response.data.msg);
        });
    },
    // 点击前往申请页
    clickToApplay(type, id) {
      this.$router.push(`/projectReportDetailByTeacher/${type}/${id}`);
    },
    clickOk() {
      this.modalOption.modalVisiabal = false;
    },
    clickCancel() {
      this.modalOption.modalVisiabal = false;
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.projectReport {
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-project-detail {
  width: 720px;
  .modal-content {
    display: flex;
    flex-direction: column;
    padding: 20px;
    & > div {
      height: 30px;
      line-height: 30px;
      & > span:first-child {
        width: 80px;
      }
    }
    .project-request {
      display: flex;
      height: auto;
      .request-content {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        height: 300px;
        margin-top: 8px;
        overflow: auto;
      }
    }
  }
  .el-dialog__footer {
    display: none;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
