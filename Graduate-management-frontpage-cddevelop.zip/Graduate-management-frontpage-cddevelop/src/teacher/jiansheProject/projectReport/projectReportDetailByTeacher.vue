<template>
  <div class="projectReportDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right">
        <el-button type="primary" @click="clickSubmit" size="small"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <project-add-ssyjskcjsxm
        v-if="type === '1'"
        :xmId="id"
        ref="add"
      ></project-add-ssyjskcjsxm>
      <project-add-bsyjskcjsxm
        v-if="type === '2'"
        :xmId="id"
        ref="add"
      ></project-add-bsyjskcjsxm>
      <project-add-kcalkjsxm
        v-if="type === '3'"
        :xmId="id"
        ref="add"
      ></project-add-kcalkjsxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import projectAddForKCALKJSXM from "@/components/jiansheProject/add/projectAddForKCALKJSXM";
import projectAddForBSYJSKCJSXM from "@/components/jiansheProject/add/projectAddForBSYJSKCJSXM";
import projectAddForSSYJSKCJSXM from "@/components/jiansheProject/add/projectAddForSSYJSKCJSXM";
export default {
  name: "projectReportDetail",
  props: {
    type: {
      type: String
    },
    id: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-add-kcalkjsxm": projectAddForKCALKJSXM,
    "project-add-bsyjskcjsxm": projectAddForBSYJSKCJSXM,
    "project-add-ssyjskcjsxm": projectAddForSSYJSKCJSXM
  },
  methods: {
    clickSubmit() {
      // 调用子组件的提交方法
      this.$refs.add.handleSubmit();
    }
  }
};
</script>
<style lang="scss" scoped>
.projectReportDetail {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
