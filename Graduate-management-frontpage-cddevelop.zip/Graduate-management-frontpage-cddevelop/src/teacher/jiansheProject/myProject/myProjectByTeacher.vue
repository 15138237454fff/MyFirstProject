<template>
  <div class="myProject">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.status" @change="initLoadTable">
          <el-option
            v-for="item in typeOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button type="danger" @click="clickDelete">删除</el-button>
      </div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        @selection-change="handleSelectionChange"
        ref="box"
      >
        <el-table-column type="selection" align="center"></el-table-column>
        <el-table-column
          prop="xmmc"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="xmLx"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            {{ scope.row.xmLx | xmlxFilter }}
          </template>
        </el-table-column>
        <el-table-column
          prop="kcmc"
          label="项目要求"
          align="center"
          show-overflow-tooltip
          width="120px"
        >
          <template slot-scope="scope">
            <span
              @click="clickProjectRequest(scope.row.xmId)"
              class="blue under-line cursor-pointer"
              >项目要求</span
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="cjsj"
          label="申报时间"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.cjsj, "yyyy.MM.dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="zt" label="状态" align="center" width="120px">
          <template slot-scope="scope">
            <span :class="scope.row.zt | ztClassFilter">{{
              scope.row.zt | ztValueFilter
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" width="120px">
          <template slot-scope="scope">
            <el-button
              type="danger"
              size="small"
              :plain="true"
              v-if="scope.row.sflx === 0 && scope.row.zt === 2"
              @click="
                clickToModify(scope.row.xmLx, scope.row.lcid, scope.row.zt)
              "
              >点击修改</el-button
            >
            <span
              v-else
              @click="
                clickToDetail(scope.row.xmLx, scope.row.lcid, scope.row.zt)
              "
              class="blue under-line cursor-pointer"
              >查看详情</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <div>
          <span>项目名称：</span>
          <span>{{ formData.xmMc }}</span>
        </div>
        <div>
          <span>项目类型：</span>
          <span>{{ formData.xmlx | xmlxFilter }}</span>
        </div>
        <div>
          <span>有效时间：</span>
          <span
            >{{ this.$tagTime(formData.yssjKssj, "yyyy-MM-dd") }} 至
            {{ this.$tagTime(formData.yssjJssj, "yyyy-MM-dd") }}</span
          >
        </div>
        <div class="project-request">
          <span>项目要求：</span>
          <div class="request-content" v-html="formData.xmyq"></div>
        </div>
        <div>
          <span>相关附件：</span>
          <span v-for="(item, index) of formData.files" :key="index"
            ><a
              :href="item.url"
              class="under-line"
              target="_blank"
              :download="formData.fileName"
              >{{ item.fileName }}</a
            ><span v-if="index !== formData.files.length - 1">，</span></span
          >
        </div>
      </div>
    </my-modal>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
import myModal from "@/components/common/myModal";
export default {
  name: "myProject",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        status: null
      },
      formData: {
        // 有效时间-结束
        yssjJssj: "",
        // 有效时间-开始时间
        yssjKssj: "",
        // 发布对象 0-教职工 1-学生
        fbdx: "",
        files: [],
        // 项目名称
        xmMc: "",
        // 项目类型
        xmlx: "",
        // 项目要求
        xmyq: ""
      },
      typeOptions: [
        { label: "全部项目类型", value: null },
        { label: "硕士研究生课程建设项目", value: 1 },
        { label: "博士研究生课程建设项目", value: 2 },
        { label: "专业学位研究生课程案例库建设项目", value: 3 }
      ],
      msgCount: 0,
      loading: false,
      selectedHistoryList: [],
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-project-detail"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-modal": myModal
  },
  mounted() {
    this.loadTable();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 10;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/myproject/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          data.list.forEach(el => {
            if (el.sflx === 1) {
              el.zt = 4;
            }
          });
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击查看项目要求
    clickProjectRequest(id) {
      this.modalOption.title = `项目要求`;
      this.requireProjectRequest(id);
    },
    // 请求项目要求详情
    requireProjectRequest(id) {
      this.$http
        .get(`/api/education/projectPublish/getInfo/${id}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("项目要求详情数据获取失败");
            return false;
          }
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.modalOption.modalVisiabal = true;
        })
        .catch(err => {
          this.$message(err.response.data.msg);
        });
    },
    // 点击前往申请页
    clickToModify(type, id, zt) {
      this.$router.push(`/myProjectModifyByTeacher/${type}/${id}/${zt}`);
    },
    // 点击前往申请页
    clickToDetail(type, id, zt) {
      this.$router.push(`/myProjectDetailByTeacher/${type}/${id}/${zt}`);
    },
    clickDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("common/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    handleDelete() {
      const loading = this.$loading({
        lock: true,
        text: "提交中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .delete("/api/education/myproject", {
          data: this.selectedHistoryList.map(el => el.lcid)
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
          } else {
            this.$message.success("删除成功");
            // 清空勾选
            this.$refs.box.clearSelection();
            this.loadTable();
          }
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
      // 隐藏模态框
      this.$store.commit("common/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.selectedHistoryList = val;
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  filters: {
    ztValueFilter(val) {
      switch (val) {
        case 0:
          return "不通过";
        case 1:
          return "通过申请";
        case 2:
          return "退回";
        case 3:
          return "审核中";
        case 4:
          return "已立项";
        default:
          return "";
      }
    },
    ztClassFilter(val) {
      switch (val) {
        case 0:
          return "red";
        case 1:
          return "green";
        case 2:
          return "red";
        case 3:
          return "orange";
        case 4:
          return "blue";
        default:
          return "";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.myProject {
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-project-detail {
  width: 720px;
  .modal-content {
    display: flex;
    flex-direction: column;
    padding: 20px;
    & > div {
      height: 30px;
      line-height: 30px;
      & > span:first-child {
        width: 80px;
      }
    }
    .project-request {
      display: flex;
      height: auto;
      .request-content {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        height: 300px;
        margin-top: 8px;
        overflow: auto;
      }
    }
  }
  .el-dialog__footer {
    display: none;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .right {
    line-height: 40px;
    .el-button {
      height: 40px;
    }
  }
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
