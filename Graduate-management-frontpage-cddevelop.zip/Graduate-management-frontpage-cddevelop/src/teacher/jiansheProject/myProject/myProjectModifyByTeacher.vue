<template>
  <div class="myProjectModify">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right">
        <el-button type="primary" @click="clickUpdate" size="small"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <table-flag :status="projectStatus"></table-flag>
      <project-add-ssyjskcjsxm
        v-if="type === '1'"
        ref="add"
      ></project-add-ssyjskcjsxm>
      <project-add-bsyjskcjsxm
        v-if="type === '2'"
        ref="add"
      ></project-add-bsyjskcjsxm>
      <project-add-kcalkjsxm
        v-if="type === '3'"
        ref="add"
      ></project-add-kcalkjsxm>
      <apply-status-bottom v-bind="aduit"></apply-status-bottom>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import tableFlag from "@/components/common/tableFlagByTeacher";
import applyStatusBottom from "@/components/common/applyStatusBottom";
import projectAddForSSYJSKCJSXM from "@/components/jiansheProject/add/projectAddForSSYJSKCJSXM";
import projectAddForBSYJSKCJSXM from "@/components/jiansheProject/add/projectAddForBSYJSKCJSXM";
import projectAddForKCALKJSXM from "@/components/jiansheProject/add/projectAddForKCALKJSXM";
export default {
  name: "myProjectModify",
  props: {
    type: {
      type: String
    },
    id: {},
    projectStatus: {}
  },
  data() {
    return {
      aduit: {
        status: null,
        name: "",
        endTime: "",
        comment: "",
        assignee: ""
      },
      loading: false,
      updatePathForSSYJSKCJSXM: "jiansheProject/updateFormDataForSSYJSKCJSXM",
      updatePathForBSYJSKCJSXM: "jiansheProject/updateFormDataForBSYJSKCJSXM",
      updatePathForKCALKJSXM: "jiansheProject/updateFormDataForKCALKJSXM",
      detailPathForSSYJSKCJSXM: "curriculum",
      detailPathForBSYJSKCJSXM: "doctoral",
      detailPathForKCALKJSXM: "casebase"
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "table-flag": tableFlag,
    "apply-status-bottom": applyStatusBottom,
    "project-add-kcalkjsxm": projectAddForKCALKJSXM,
    "project-add-bsyjskcjsxm": projectAddForBSYJSKCJSXM,
    "project-add-ssyjskcjsxm": projectAddForSSYJSKCJSXM
  },
  mounted() {
    this.dataCallBack();
    if (this.projectStatus === 0) {
      this.requireAduitDetail();
    }
  },
  methods: {
    clickUpdate() {
      // 调用子组件的提交方法
      this.$refs.add.handleUpdate(this.id);
    },
    dataCallBack() {
      switch (this.type) {
        case "1":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "2":
          this.requirePorjectDetail(
            this.detailPathForBSYJSKCJSXM,
            this.updatePathForBSYJSKCJSXM
          );
          return;
        case "3":
          this.requirePorjectDetail(
            this.detailPathForKCALKJSXM,
            this.updatePathForKCALKJSXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http.get(`/api/education/process/history/${this.id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!Array.isArray(data.data)) {
          console.log("审核历史记录数据获取失败");
          return;
        }
        Object.keys(this.aduit).forEach(key => {
          this.aduit[key] = data.data[data.data.length - 1][key];
        });
        this.aduit.status = data.data.state;
        console.log(this.aduit);
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.myProjectModify {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
