<template>
  <div class="conclusionApplyAdd">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right">
        <el-button type="primary" @click="clickSubmit" size="small"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <conclusion-add-ssyjskcjsxm
        v-if="type === '1'"
        :xmId="id"
        :lcid="lcid"
        ref="add"
      ></conclusion-add-ssyjskcjsxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import conclusionAddForSSYJSKCJSXM from "@/components/jiansheProject/add/conclusionAddForSSYJSKCJSXM";
export default {
  name: "conclusionApplyAdd",
  props: {
    type: {
      type: String
    },
    id: {},
    lcid: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "conclusion-add-ssyjskcjsxm": conclusionAddForSSYJSKCJSXM
  },
  methods: {
    clickSubmit() {
      // 调用子组件的提交方法
      this.$refs.add.handleSubmit();
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionApplyAdd {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
