<template>
  <div class="conclusionApply">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.xmlx" @change="initLoadTable">
          <el-option
            v-for="item in typeOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        ref="box"
      >
        <el-table-column
          prop="xmMC"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="xmLx"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ $getListValue(scope.row.xmLx, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="pjdja"
          label="立项时间"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.lxsj, "yyyy-MM-dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="kcmc"
          label="项目详情"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span
              @click="clickProjectDetail(scope.row.xmLx, scope.row.lcid)"
              class="blue under-line cursor-pointer"
              >查看详情</span
            >
          </template>
        </el-table-column>
        <el-table-column prop="zt" label="结题状态" align="center" :width="120">
          <template slot-scope="scope">
            <span :class="scope.row.zt | ztClassFilter">{{
              scope.row.zt | ztValueFilter
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="pjrk" label="操作" align="center" :width="120">
          <template slot-scope="scope">
            <el-button
              type="danger"
              size="small"
              :plain="true"
              v-if="scope.row.zt === 2"
              @click="
                clickToModify(
                  scope.row.xmLx,
                  scope.row.lcid,
                  scope.row.zt,
                  scope.row.jtLcid
                )
              "
              >点击修改</el-button
            >
            <el-button
              type="primary"
              size="small"
              :plain="true"
              v-else-if="scope.row.zt === null"
              @click="
                clickToAdd(scope.row.xmLx, scope.row.xmId, scope.row.lcid)
              "
              >点击添加</el-button
            >
            <span
              v-else
              @click="
                clickToDetail(
                  scope.row.xmLx,
                  scope.row.lcid,
                  scope.row.zt,
                  scope.row.jtLcid
                )
              "
              class="blue under-line cursor-pointer"
              >结题报告</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "conclusionApply",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        xmlx: null
      },
      loading: false,
      typeOptions: [
        { label: "全部项目", value: null },
        { label: "硕士研究生课程建设项目", value: "1" }
      ],
      msgCount: 0
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.loadTable();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 10;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/projectTaskAudit/teacherTaskList", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击查看项目详情
    clickProjectDetail(type, id) {
      console.log(type);
      this.$router.push(`/conclusionProjectDetailByTeacher/${type}/${id}`);
    },
    // 点击前往修改页
    clickToModify(type, id, zt, jtId) {
      this.$router.push(
        `/conclusionApplyModifyByTeacher/${type}/${id}/${zt}/${jtId}`
      );
    },
    // 点击前往详情页
    clickToDetail(type, id, zt, jtId) {
      this.$router.push(
        `/conclusionApplyDetailByTeacher/${type}/${id}/${zt}/${jtId}`
      );
    },
    // 点击前往添加页
    clickToAdd(type, id, lcid) {
      this.$router.push(`/conclusionApplyAddByTeacher/${type}/${id}/${lcid}`);
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  filters: {
    ztValueFilter(val) {
      switch (val) {
        case null:
          return "待提交";
        case 0:
          return "不通过";
        case 1:
          return "通过";
        case 2:
          return "退回";
        case 3:
          return "审核中";
        default:
          return "";
      }
    },
    ztClassFilter(val) {
      switch (val) {
        case null:
          return "blue";
        case 0:
          return "red";
        case 1:
          return "green";
        case 2:
          return "red";
        case 3:
          return "orange";
        default:
          return "";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.conclusionApply {
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.modal-project-request {
  .modal-content {
    display: flex;
    flex-direction: column;
    padding: 20px;
    & > div {
      height: 30px;
      line-height: 30px;
      & > span:first-child {
        width: 80px;
      }
    }
    .project-request {
      display: flex;
      height: auto;
      .request-content {
        width: 100%;
        border: 1px solid #ccc;
        height: 300px;
        margin-top: 8px;
        overflow: auto;
      }
    }
  }
  .el-dialog__footer {
    display: none;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
