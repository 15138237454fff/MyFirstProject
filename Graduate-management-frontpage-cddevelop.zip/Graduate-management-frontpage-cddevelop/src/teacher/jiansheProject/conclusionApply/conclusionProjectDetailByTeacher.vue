<template>
  <div class="myProjectDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <project-detail-ssyjskcjsxm
        v-if="type === '1'"
      ></project-detail-ssyjskcjsxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import projectDetailForSSYJSKCJSXM from "@/components/jiansheProject/detail/projectDetailForSSYJSKCJSXM";
export default {
  name: "myProjectDetail",
  props: {
    type: {
      type: String
    },
    id: {
      type: String
    }
  },
  data() {
    return {
      loading: false,
      detailPathForSSYJSKCJSXM: "curriculum",
      updatePathForSSYJSKCJSXM: "jiansheProject/updateFormDataForSSYJSKCJSXM"
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-detail-ssyjskcjsxm": projectDetailForSSYJSKCJSXM
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "1":
          this.requirePorjectDetail(
            this.detailPathForSSYJSKCJSXM,
            this.updatePathForSSYJSKCJSXM
          );
          return;
        case "2":
          this.requirePorjectDetail(
            this.detailPathForBSYJSKCJSXM,
            this.updatePathForBSYJSKCJSXM
          );
          return;
        case "3":
          this.requirePorjectDetail(
            this.detailPathForKCALKJSXM,
            this.updatePathForKCALKJSXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(updatePath);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.myProjectDetail {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
