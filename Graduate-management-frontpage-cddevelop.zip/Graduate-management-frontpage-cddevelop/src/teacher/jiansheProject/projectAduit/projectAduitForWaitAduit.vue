<template>
  <div class="projectAduitForWaitAduit">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称/申请人"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.status" @change="initLoadTable">
          <el-option
            v-for="item in typeOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        ref="box"
      >
        <el-table-column
          prop="projectName"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="projectType"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            {{ scope.row.projectType | xmlxFilter }}
          </template>
        </el-table-column>
        <el-table-column
          prop="name"
          label="申请人"
          align="center"
          :width="150"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="collegeName"
          label="所属学院"
          align="center"
          show-overflow-tooltip
          :width="150"
        >
        </el-table-column>
        <el-table-column
          prop="applyDate"
          label="申请时间"
          align="center"
          :width="120"
        >
        </el-table-column>
        <el-table-column
          prop="nodeName"
          label="当前审核环节"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              @click="
                clickToApplay(
                  scope.row.projectType,
                  scope.row.executionId,
                  scope.row.taskId
                )
              "
              >{{ scope.row.nodeName }}</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "projectAduitForWaitAduit",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        status: null
      },
      loading: false,
      typeOptions: [
        {
          label: "全部项目",
          value: null
        },
        {
          label: "田野调查基金项目",
          value: 4
        },
        {
          label: "校级研究生科研项目",
          value: 5
        },
        {
          label: "知行浙江社会调研项目",
          value: 6
        }
      ],
      msgCount: 0,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "projectAduitForWaitAduit"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.loadTable();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 60;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/process/teacher/toAudit/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          console.log(data);
          // 获得的参数验证
          if (!data || !Array.isArray(data.info)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.info;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击前往审核页
    clickToApplay(type, id, taskId) {
      this.$router.push(`/projectAduitAdd/${type}/${id}/${taskId}`);
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.projectReport {
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
