<template>
  <div class="myProjectDetail">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <project-detail-tydcjjxm v-if="type === '4'"></project-detail-tydcjjxm>
      <project-detail-xjyjskyxm v-if="type === '5'"></project-detail-xjyjskyxm>
      <project-detail-zxzjshdyxm
        v-if="type === '6'"
      ></project-detail-zxzjshdyxm>
      <apply-status :aduitList="aduitList"></apply-status>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import projectDetailForTYDCJJXM from "@/components/jiansheProject/detail/projectDetailForTYDCJJXM";
import projectDetailForXJYJSKYXM from "@/components/jiansheProject/detail/projectDetailForXJYJSKYXM";
import projectDetailForZXZJSHDYXM from "@/components/jiansheProject/detail/projectDetailForZXZJSHDYXM";
import applyStatus from "@/components/common/applyStatus";
export default {
  name: "myProjectDetail",
  props: {
    type: {
      type: String
    },
    id: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-detail-tydcjjxm": projectDetailForTYDCJJXM,
    "project-detail-xjyjskyxm": projectDetailForXJYJSKYXM,
    "project-detail-zxzjshdyxm": projectDetailForZXZJSHDYXM,
    "apply-status": applyStatus
  },
  data() {
    return {
      detailPathForTYDCJJXM: "fieldwork",
      detailPathForXJYJSKYXM: "university",
      detailPathForZXZJSHDYXM: "social",
      updatePathForTYDCJJXM: "jiansheProject/updateFormDataForTYDCJJXM",
      updatePathForXJYJSKYXM: "jiansheProject/updateFormDataForXJYJSKYXM",
      updatePathForZXZJSHDYXM: "jiansheProject/updateFormDataForZXZJSHDYXM",
      aduitList: [],
      loading: false
    };
  },
  mounted() {
    this.dataCallBack();
    this.requireAduitDetail();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "4":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "5":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
          return;
        case "6":
          this.requirePorjectDetail(
            this.detailPathForZXZJSHDYXM,
            this.updatePathForZXZJSHDYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(data.data);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http.get(`/api/education/process/history/${this.id}`).then(res => {
        let data = res.data;
        if (data.code !== 200) {
          this.$message.error(data.message);
          return;
        }
        if (!Array.isArray(data.data)) {
          console.log("审核历史记录数据获取失败");
          return;
        }
        this.aduitList = data.data;
      });
    },
    goBack() {
      this.$router.push(`/projectAduit?activeTab=aduited`);
    }
  }
};
</script>
<style lang="scss" scoped>
.myProjectDetail {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
