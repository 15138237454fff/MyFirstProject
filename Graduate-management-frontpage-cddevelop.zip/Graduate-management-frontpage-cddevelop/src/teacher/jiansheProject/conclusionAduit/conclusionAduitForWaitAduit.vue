<template>
  <div class="conclusionAduitForAduited">
    <my-breadcrumb>
      <div slot="left">
        <el-input
          placeholder="请输入项目名称/申请人"
          prefix-icon="el-icon-search"
          clearable
          @clear="loadTable"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
        ></el-input>
        <el-button @click="initLoadTable">查询</el-button>
        <el-select v-model="limitQuery.status" @change="initLoadTable">
          <el-option
            v-for="(item, index) in typeOptions"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right"></div>
    </my-breadcrumb>
    <div class="box">
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        ref="box"
      >
        <el-table-column
          prop="projectName"
          label="项目名称"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="projectType"
          label="项目类型"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ $getListValue(scope.row.projectType, typeOptions) }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="name"
          label="申请人"
          align="center"
          :width="150"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="collegeName"
          label="所属学院"
          align="center"
          :width="150"
          show-overflow-tooltip
        >
        </el-table-column>
        <el-table-column
          prop="applyDate"
          label="申请时间"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span>{{ $tagTime(scope.row.applyDate, "yyyy-MM-dd") }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="pjrk"
          label="项目详情"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              @click="
                clickToProjectDetail(
                  scope.row.projectType,
                  scope.row.sqExecutionId
                )
              "
              >查看详情</span
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="pjrk"
          label="总结报告"
          align="center"
          :width="120"
        >
          <template slot-scope="scope">
            <span
              class="blue under-line cursor-pointer"
              @click="
                clickToAduit(
                  scope.row.projectType,
                  scope.row.sqExecutionId,
                  scope.row.taskId,
                  scope.row.executionId
                )
              "
              >{{ scope.row.nodeName }}</span
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "conclusionAduitForAduited",
  data() {
    return {
      tableData: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        query: "",
        status: null
      },
      typeOptions: [
        {
          label: "全部项目",
          value: null
        },
        {
          label: "田野调查基金项目",
          value: "8"
        },
        {
          label: "校级研究生科研项目",
          value: "9"
        }
      ],
      loading: false,
      msgCount: 0,
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "conclusionAduitForAduited"
      }
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.loadTable();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 60;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      // 发送请求列表数据的请求
      this.$http
        .post("/api/education/projectTaskAudit/teacher/toAudit/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.info)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.info;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 点击前往项目详情页
    clickToProjectDetail(type, id) {
      this.$router.push(`/conclusionAduitProjectDetailByTeacher/${type}/${id}`);
    },
    // 点击前往审核
    clickToAduit(type, id, taskId, jtId) {
      this.$router.push(`/conclusionAduitAdd/${type}/${id}/${taskId}/${jtId}`);
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.conclusionAduitForAduited {
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
<style lang="scss">
.myBreadcrumb {
  height: 40px !important;
  margin-bottom: 10px;
  .left {
    & > div {
      display: flex;
      :not(:last-child) {
        margin-right: 10px;
      }
    }
    flex: 3;
    display: flex;
  }
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
