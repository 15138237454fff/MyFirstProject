<template>
  <div class="conclusionAduitAdd">
    <my-breadcrumb>
      <div slot="left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="goBack">返回列表</el-button>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <conclusion-detail-for-tydcjjxm
        v-if="type === '8'"
        :lcid="id"
      ></conclusion-detail-for-tydcjjxm>
      <conclusion-detail-for-xjyjskyxm
        v-if="type === '9'"
        :lcid="id"
      ></conclusion-detail-for-xjyjskyxm>
      <apply-status :aduitList="aduitList"></apply-status>
      <audit-submit @submit="handleSubmit"></audit-submit>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import conclusionDetailForTYDCJJXM from "@/components/jiansheProject/detail/conclusionDetailForTYDCJJXM";
import conclusionDetailForXJYJSKYXM from "@/components/jiansheProject/detail/conclusionDetailForXJYJSKYXM";
import applyStatus from "@/components/common/applyStatus";
import auditSubmit from "@/components/common/aduitSubmit";
export default {
  name: "conclusionAduitAdd",
  props: {
    type: {
      type: String
    },
    id: {
      type: String
    },
    taskId: {
      type: String
    },
    jtId: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "conclusion-detail-for-tydcjjxm": conclusionDetailForTYDCJJXM,
    "conclusion-detail-for-xjyjskyxm": conclusionDetailForXJYJSKYXM,
    "apply-status": applyStatus,
    "audit-submit": auditSubmit
  },
  data() {
    return {
      aduitList: [],
      loading: false,
      detailPathForTYDCJJXM: "fieldworkTask",
      detailPathForXJYJSKYXM: "universityTask",
      updatePathForTYDCJJXM:
        "jiansheProject/updateFormDataIsConclusionForTYDCJJXM",
      updatePathForXJYJSKYXM:
        "jiansheProject/updateFormDataIsConclusionForXJYJSKYXM"
    };
  },
  mounted() {
    this.dataCallBack();
    this.requireAduitDetail();
  },
  methods: {
    goBack() {
      this.$router.push(`/conclusionAduit`);
    },
    dataCallBack() {
      switch (this.type) {
        case "8":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "9":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(data.data);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http
        .get(`/api/education/process/history/${this.jtId}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!Array.isArray(data.data)) {
            console.log("审核历史记录数据获取失败");
            return;
          }
          this.aduitList = data.data;
        });
    },
    handleSubmit(obj) {
      const loading = this.$loading({
        lock: true,
        text: "提交审核中，请稍后",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$http
        .post(`/api/education/process/audit`, {
          taskId: this.taskId,
          lcid: this.jtId,
          check: obj.status,
          comment: obj.comment,
          type: "0" // 前端标志
        })
        .then(res => {
          let data = res.data;
          loading.close();
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          this.$message.success(data.message);
          this.goBack();
        })
        .catch(err => {
          console.log(err.message);
          loading.close();
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionAduitAdd {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
  .el-icon-d-arrow-left {
    line-height: 40px;
    margin-right: 0 !important;
    color: #409eff;
  }
}
</style>
