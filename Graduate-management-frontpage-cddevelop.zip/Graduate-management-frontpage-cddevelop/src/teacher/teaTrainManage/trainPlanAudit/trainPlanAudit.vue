<template>
  <!-- 培养计划审核 trainPlanAudit -->
  <div class="stuTable">
    <el-tabs v-show="!$route.query.mark" v-model="activeName" @tab-click="tabClick">
      <el-tab-pane label="待审核" name="first">
        <stu-list ref="myChild1" v-if="activeName === 'first'"></stu-list>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="second">
        <stu-audited ref="myChild2" v-if="activeName === 'second'"></stu-audited>
      </el-tab-pane>
    </el-tabs>
    <!-- 在展示详情时分为两种情况 1、第一次提交之后的详情展示 2、提交之后再次调整之后的详情展示 -->
    <stu-detail v-if="$route.query.mark"></stu-detail>
  </div>
</template>

<script>
import stuList from './components/stuList'
import stuAudited from './components/stuAudited'
import stuDetail from './components/stuDetail'

export default {
  name: 'trainPlanAudit',
  components: {
    stuList,
    stuAudited,
    stuDetail
  },
  data () {
    return {
      activeName: '',
      //接收是否保存的数据
      sftzzt:''
    }
  },
  mounted () {
    this.routeToTab()
  },
  created(){},
  watch: {
    $route () {
      this.routeToTab()
    }
  },
  methods: {
    // tab切换
    tabClick (t) {
      if (t.label == '待审核') {
        this.activeName = 'first'
        this.$router.push({
          path: '/trainPlanAudit',
          query: {
            check: 0,

          }
        })
        // this.$refs.myChild1.loadTable();
      }
      if (t.label == '已审核') {
        this.activeName = 'second'
        this.$router.push({
          path: '/trainPlanAudit',
          query: {
            check: 1
          }
        })
        // this.$refs.myChild2.loadTable();
      }
    },
    // 根据当前路由设置tab页控制变量的值
    routeToTab () {
      // 待审核列表页
      if (
        this.$route.fullPath == '/trainPlanAudit?check=0' ||
        this.$route.fullPath == '/trainPlanAudit'
      ) {
        this.activeName = 'first'
      }
      // 已审核列表页
      else if (this.$route.fullPath == '/trainPlanAudit?check=1') {
        this.activeName = 'second'
      }
      // 其他页面
      else {
        this.activeName = ''
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.stuTable {
  /deep/ .el-tabs__nav-wrap {
    background: $white;
  }
  /deep/ .el-tabs__nav {
    margin-left: $left;
  }
  /deep/ .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  /deep/ .el-tabs__header {
    margin-bottom: $top;
  }
}
</style>
