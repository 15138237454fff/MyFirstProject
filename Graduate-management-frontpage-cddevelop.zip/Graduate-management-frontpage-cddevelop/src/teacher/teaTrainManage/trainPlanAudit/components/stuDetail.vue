<template>
  <!-- 培养计划审核 -->
  <div >
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
    </div>
    <div class="table-area">
      <!-- 第一次提交后的详情展示 当接口中返回的包含stuTrainingPlanApply说明是第一次提交后的数据-->
      <apply-detail v-if="$route.query.lcid && this.$route.query.processDefinitionId.indexOf('stuTrainingPlanApply') !==-1"></apply-detail>
      <!-- 第一次提交后调整之后的详情展示 当接口中返回的包含stuTrainingPlanChangeApply说明是培养提交之后的数据-->
      <apply-adjustclass v-if="$route.query.lcid && this.$route.query.processDefinitionId.indexOf('stuTrainingPlanChangeApply') !==-1" ></apply-adjustclass>
      <applyid :lcid="$route.query.lcid" v-if="$route.query.lcid" :xh="$route.query.xh"></applyid>
      <pyjh-submit></pyjh-submit>
    </div>
  </div>
</template>

<script>
import applyDetail from "../../../../pages/teachTrain/personalPlan/components/applyDetail";
import applyAdjustclass from "../../../../pages/teachTrain/personalPlan/components/applyAdjustclass";
import pyjhSubmit from "../../../../components/teacher/pyjhSubmit";
import applyid from "./applyid";
export default {
  name: "stuDetail",
  components: {
    applyDetail,
    pyjhSubmit,
    applyAdjustclass,
    applyid: applyid,
    stuTrainingPlanApply:false,
    stuTrainingPlanChangeApply:false
  },
  data() {
    return {};
  },
  created() {},
  mounted() {
    console.log(this.$route.query)
  },
  computed: {},
  methods: {
    // 返回列表
    handleBack() {
      this.$router.go(-1);
    }
  }
};
</script>

<style lang="scss" scoped>
.header {
  height: $tab-height;
  display: flex;
  margin-bottom: $top;
  .header-left {
    flex: 5;
    .el-icon-d-arrow-left {
      // margin-right: 5px;
      color: #409eff;
    }
  }
  .header-right {
    flex: 1;
    text-align: right;
  }
  .el-input {
    width: 200px;
  }
  .el-button {
    margin-left: 10px;
  }
}
.table-area {
  height: calc(100vh - 208px);
  overflow: auto;
}
</style>
