<template>
  <div>
    <!-- 申请进度 -->
    <div class="main" v-loading="loading" style="min-height:100px;">
      <div class="dashed"></div>
      <div class="step">
        <el-steps :active="active" :space="200">
          <el-step v-for="(item, index) in auditList" :key="index">
            <!-- <div slot="title">{{item.name}}</div> -->
            <div slot="title" class="text-ellipsis">
              {{ `${item.name}(${item.assignee})` }}
            </div>
            <span
              v-if="item.taskDefinitionKey !== 'apply'"
              slot="description"
              :class="item.state | dsstatusFilter"
              >{{ item.state | dsztFilter }}</span
            >
            <span slot="description" class="time">{{ item.endTime }}</span>
            <div slot="description" class="comment">{{ item.comment }}</div>
            <i v-if="item.state === null" slot="icon" class="el-icon-check"></i>
            <i
              v-else-if="item.state == '1'"
              slot="icon"
              class="el-icon-check"
            ></i>
            <i
              v-else-if="item.state == '2'"
              slot="icon"
              class="el-icon-d-arrow-left"
            ></i>
            <i
              v-else-if="item.state == '0'"
              slot="icon"
              class="el-icon-close"
            ></i>
          </el-step>
        </el-steps>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "applyStatus",
  props: ["lcid"],
  data() {
    return {
      active: 1,
      auditList: [],
      loading: false
    };
  },
  mounted() {
    console.log(this.lcid);
    // //console.log(this.$store.state.auditList)
    this.getList();
    // console.log(5364156)
  },
  methods: {
    getList() {
      // 判断当前是学生还是导师登录，若是学生则需要走选过的历史id的接口
      this.loading = true;
      if (
        this.$route.query.processDefinitionId.indexOf(
          "stuTrainingPlanApply"
        ) !== -1
      ) {
        this.$http
          .get("/api/cultivate/pygrpyjhb/hisByLcid", {
            params: { xh: this.$route.query.xh }
          })
          .then(res => {
            this.loading = false;
            this.auditList = res.data.data;
            this.active = this.auditList.length;
          })
          .catch(err => {
            console.log(err.message);
            this.loading = false;
          });
      } else {
        this.$bus.$on("changeHistoryList", list => {
          this.loading = false;
          this.auditList = list;
          this.active = this.auditList.length;
          console.log(list);
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  .text-ellipsis {
    width: 200px;
    color: #333;
    font-weight: 500;
  }
  .dashed {
    margin-top: 25px;
    height: 1px;
    background: linear-gradient(
      to right,
      rgba(204, 204, 204, 1),
      rgba(204, 204, 204, 1) 5px,
      transparent 5px,
      transparent
    );
    background-size: 10px 100%;
  }
  .step {
    margin-top: 25px;
    margin-left: 15px;
    .wait {
      margin-right: 15px;
    }
    .yes {
      margin-right: 15px;
    }
    .ing {
      margin-right: 15px;
    }
    .back {
      margin-right: 15px;
    }
    .time {
      // margin-left: 15px;
      color: #333;
      font-size: 13px;
    }
    .comment {
      margin-top: 8px;
      color: #333;
      font-size: 13px;
    }
  }
}
.step /deep/ .el-step__title .is-success {
  color: #409eff;
}
.step /deep/ .el-step__head .is-success {
  color: #409eff;
  border-color: #409eff;
}
.step /deep/ .el-step__description .is-success {
  color: #409eff;
}
.step /deep/ .el-icon-d-arrow-left:before,
.step /deep/ .el-icon-close:before {
  color: #fff;
  background-color: #f56c6c;
  font-size: 16px;
  border-radius: 50%;
  padding: 4px;
}
.step /deep/ .el-step__head.is-process .el-step__icon.is-text {
  color: #fff;
  background-color: $blue;
  border-color: $blue;
}
.step /deep/ .el-steps {
  overflow-x: auto;
}
// 重点：flex-shrink 属性指定了 flex 元素的收缩规则。
// flex 元素仅在默认宽度之和 > 容器的时候才会发生收缩，其收缩的大小是依据 flex-shrink 的值。
// flex-shrink默认值为1
.step /deep/ .el-step {
  flex-shrink: 0;
}
</style>
