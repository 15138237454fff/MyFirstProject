<template>
  <!-- 学生培养计划 待审核列表 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
      </div>
    </div>
    <div class="table-area">
      <el-table
        :data="tableData"
        border
        v-loading="loading"
        element-loading-text="加载中"
        :height="tableHeight"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column
          label="序号"
          type="index"
          width="50"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="xh"
          label="学号"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="xm"
          label="姓名"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="xslb"
          label="学生类别"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="xy"
          label="学院"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="zy"
          label="专业"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="sznj"
          label="年级"
          align="center"
          show-overflow-tooltip
        ></el-table-column>

        <el-table-column
          prop="zxf"
          label="已选总学分"
          align="center"
        ></el-table-column>

        <el-table-column
          prop="cz"
          label="当前审核环节"
          width="120"
          align="center"
        >
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="handleSee(scope.row)">{{
              scope.row.name
            }}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "stuList",
  data() {
    return {
      tableData: [],
      loading: true,
      stuInfo: "stuTrainingPlan", // 加载列表参数
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ""
      },
      // 分页总记录数
      msgCount: 0,
      //保存调整前后的数据并展示
      adjustMessage: ""
    };
  },
  components: {
    "my-pagination": myPagination
  },
  created() {
    this.loadTable();
  },
  mounted() {},
  watch: {
    $route(to) {
      if (to.path == "/stuInfoAudit") {
        this.loadTable();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 56;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },

    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 查看详情
    handleSee(row) {
      this.adjustMessage = row.processDefinitionName;
      this.$router.push({
        path: "/trainPlanAudit",
        query: {
          check: 0,
          lcid: row.processInstanceId,
          xh: row.xh,
          taskId: row.id,
          key: row.taskDefinitionKey,
          businesskey: row.processVariables.businesskey,
          name: row.processVariables.name,
          executionId: row.executionId,
          processDefinitionId: row.processDefinitionId,
          mark: 2
        }
      });
    },
    // 加载列表
    loadTable() {
      this.$http
        .post("/api/cultivate/activityCultivate/taskStuInfoList", {
          definitionKeyLike: this.stuInfo,
          pageNum: this.limitQuery.pageNum,
          pageSize: this.limitQuery.pageSize,
          query: this.limitQuery.search,
          zy: "",
          nj: "",
          dwh: "",
          type: 0
        })
        .then(res => {
          // console.log(res.data);
          let data = res.data.data;
          if (!Array.isArray(data.list)) {
            this.$message.error("获取所有待审核的学生列表数据失败");
            return false;
          }
          this.tableData = data.list;
          this.msgCount = data.total;
          this.loading = false;
        });
    },
    // 查询
    handleSearch() {
      this.loadTable();
    },

    // 清空搜索框
    handleClear() {
      this.loadTable();
    }
  }
};
</script>

<style lang="scss" scoped>
.main-table {
  .header {
    height: $tab-height;
    margin-bottom: $top;
    display: flex;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
    /deep/ .el-select {
      margin-left: 15px;
    }
  }
}
</style>
