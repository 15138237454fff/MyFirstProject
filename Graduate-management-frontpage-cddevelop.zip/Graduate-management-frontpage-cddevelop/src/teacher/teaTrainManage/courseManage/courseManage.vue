<template>
  <div>
    <!-- 课程教学管理 courseManage -->
    <div class="courseManage" v-show="$route.query.query == undefined">
      <div class="header">
        <div class="header-left">
          <el-input placeholder="请输入课程号/课程名称" prefix-icon="el-icon-search" clearable @clear="handleClear" v-model="limitQuery.search" @keyup.delete.native="handleClear" @keyup.enter.native="handleSearch"></el-input>
          <el-button @click="handleSearch">查询</el-button>
          <el-select v-model="value" @change="handleSelect">
            <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </div>
        <div class="header-right">
          <!-- <el-button type="primary" @click="teachPlan">授课计划</el-button>
          <el-button type="primary" @click="classAdjust">调课</el-button>
          <el-button type="primary" @click="applyRecord">申请记录</el-button> -->
          <el-button type="primary" @click="createTimetable">生成课表</el-button>
        </div>
      </div>
      <el-table :data="tableData" border :height="tableHeight" v-loading="loading" element-loading-text="加载中" :header-cell-style="tableHeaderColor">
        <el-table-column label="课程号" align="center" width="200">
          <template slot-scope="scope">
            {{scope.row.kcInfo}}
          </template>
        </el-table-column>
        <el-table-column prop="dwmc" label="开课学院" align="center" width="150"></el-table-column>
        <el-table-column prop="pyccm" label="培养层次" align="center" width="100"></el-table-column>
        <el-table-column prop="xknj" label="年级" align="center" width="100"></el-table-column>
        <el-table-column prop="zy" label="专业" align="center" show-overflow-toolti></el-table-column>
        <el-table-column prop="kkxnd" label="学年学期" align="center"></el-table-column>
        <el-table-column prop="bjmc" label="教学班" align="center"></el-table-column>
        <el-table-column prop="sksj" label="上课时间、地点" align="center" width="280" show-overflow-tooltip>
          <template slot-scope="scope">
            <div v-for="(item,index) in scope.row.infoList" :key="index">
              <span style="margin-left:7px">{{ item.zc}}周</span>
              <span style="margin-left:7px">{{ item.sfmz == 1? '每周' : item.sfmz == 2? '单周' :item.sfmz == 3? '双周' :'' }}</span>
              <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
              <span style="margin-left:7px">{{ item.kj }}节</span>
              <span style="margin-left:7px">{{ `(${item.jsmc})` }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="xkrsxd" label="听课人数" align="center" show-overflow-tooltip width="100"></el-table-column>
      </el-table>
      <!-- 分页 -->
      <my-pagination @paginate="handlePaginate" :pageSize="limitQuery.pageSize" :pageNum="limitQuery.pageNum" :msgCount="msgCount"></my-pagination>
    </div>
    <div>
      <course-adjust v-show="$route.query.query == 2"></course-adjust>
      <apply-record v-if="$route.query.query == 3"></apply-record>
    </div>
  </div>
</template>

<script>
import courseAdjust from "./components/courseAdjust";
import applyRecord from "./components/applyRecord";
import myPagination from "@/components/myPagination";
export default {
  name: "courseManage",
  components: {
    courseAdjust,
    applyRecord,
    "my-pagination": myPagination
  },
  data() {
    return {
      tableData: [],
      options: [],
      indexShow: true,
      courseShow: false,
      value: "",
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ""
      },
      msgCount: 0,
      // 加载数据状态
      loading: false
    };
  },
  mounted() {
    this.acadYearTermHisList();
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight;
    }
  },
  methods: {
    acadYearTermHisList() {
      this.$http.get("api/cultivate/kc/selectDistinctTerm").then(res => {
        this.options = res.data.data;
        this.value = res.data.data[0].value;
        this.loadTable();
      });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.loadTable();
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 加载列表
    loadTable() {
      this.$http
        .post("/api/cultivate/kcjxgl/selectList", {
          pageNum: this.limitQuery.pageNum,
          pageSize: this.limitQuery.pageSize,
          query: this.limitQuery.search,
          xnxq: this.value
        })
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          this.tableData = data.list;
          this.msgCount = data.total;
        });
    },
    // 查询
    handleSearch() {
      this.loadTable();
    },
    // 下拉框查询
    handleSelect() {
      this.loadTable();
    },
    // 清空搜索框
    handleClear() {
      // this.value = 'stuInfoService'
      this.loadTable();
    },
    // 授课计划
    teachPlan() {},
    // 调课
    classAdjust() {
      this.$router.push({
        path: "/courseManage",
        query: {
          query: 2
        }
      });
    },
    // 申请记录
    applyRecord() {
      this.$router.push({
        path: "/courseManage",
        query: {
          query: 3
        }
      });
    },
    // 生成课表
    createTimetable() {
      window.location.href = `api/cultivate/kcjxgl/exportExcel?gh=${this.$store.state.userLoginMsg.xh}&query=${this.limitQuery.search}&xnxq=${this.value}`;
    }
  }
};
</script>

<style lang="scss" scoped>
.courseManage {
  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 220px;
    }
    .el-button {
      margin-left: $left;
    }
    /deep/ .el-select {
      margin-left: $left;
    }
  }
}
</style>
