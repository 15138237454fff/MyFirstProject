<template>
  <!-- 课程教学管理 申请记录 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
    </div>
    <el-table
      :data="tableData"
      border
      :height="tableHeight"
      v-loading="loading"
      element-loading-text="加载中"
      :header-cell-style="tableHeaderColor"
    >
      <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
      <el-table-column prop="processDefinitionName" label="课程号" align="center" width="120"></el-table-column>
      <el-table-column prop="xh" label="课程名称" align="center" width="100" show-overflow-tooltip></el-table-column>
      <el-table-column prop="xm" label="开课单位" align="center"></el-table-column>
      <el-table-column prop="xslb" label="教学班" align="center"></el-table-column>
      <el-table-column prop="xy" label="申请时间" align="center" show-overflow-tooltip></el-table-column>
      <el-table-column prop="zy" label="审核状态" align="center"></el-table-column>
      <el-table-column prop="cz" label="查看详情" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="handleSee(scope.row)">审核</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'applyRecord',
  data () {
    return {
      tableData: [],
      // loading: true,
      options: [
        {
          value: 'stuKcsqService',
          label: '全部申请类别'
        },
        {
          value: 'stuKcsqServiceChangeCourseApply',
          label: '课程调整'
        },
        {
          value: 'stuKcsqServiceExemptionApply',
          label: '免修'
        },
        {
          value: 'stuKcsqServiceDelayedExamApply',
          label: '缓考'
        }
      ],
      value: 'stuKcsqService',
      stuInfo: 'stuKcsqService', // 加载列表参数
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ''
      },
      msgCount: 0,
      // 加载数据状态
      loading: true
    }
  },
  created () {
    this.loadTable()
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight
    }
  },
  components: {
    'my-pagination': myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 返回列表
    handleBack () {
      this.$router.go(-1)
    },
    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    },
    // 查看详情
    handleSee (row) {
      // console.log(row)
      let lcName = row.processDefinitionId.split(':')[0]
      switch (lcName) {
        case 'stuKcsqServiceExemptionApply':
          this.$router.push({
            path: '/stuCourseAudit',
            query: {
              check: 0,
              lcid: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 2
            }
          })
          break
        case 'stuKcsqServiceDelayedExamApply':
          this.$router.push({
            path: '/stuCourseAudit',
            query: {
              check: 0,
              lcid: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 4
            }
          })
          break
      }
    },
    // 加载列表
    loadTable () {
      this.$http
        .get('/api/cultivate/activityCultivate/taskKcList', {
          params: {
            definitionKeyLike: this.value,
            pageNum: this.limitQuery.pageNum,
            pageSize: this.limitQuery.pageSize,
            query: this.limitQuery.search,
            type: 0
          }
        })
        .then(res => {
          // console.log(res.data.data)
          this.loading = false
          let data = res.data.data
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 查询
    handleSearch () {
      // if(this.limitQuery.search.length == 0){
      //     this.$message.error('请输入搜索内容')
      // }
      this.loadTable()
    },
    // 下拉框查询
    handleSelect () {
      this.loadTable()
    },
    // 清空搜索框
    handleClear () {
      this.value = 'stuKcsqService'
      this.loadTable()
    }
  }
}
</script>

<style lang="scss" scoped>
.main-table {
  .header {
    height: $tab-height;
    margin-bottom: $top;
    display: flex;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
    /deep/ .el-select {
      margin-left: $left;
    }
  }
}
</style>
