<template>
  <!-- 点击调课 -->
  <div class="inside">
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="applySubmit">提交申请</el-button>
      </div>
    </div>
    <div class="table-area">
      <div class="head">
        <div class="center">
          <span class="title">浙江财经大学研究生课程调课申请表</span>
        </div>
      </div>
      <div class="table-box">
        <table border="1" cellspacing="0" cellpadding="10">
          <thead></thead>
          <tbody>
            <tr>
              <td>工号</td>
              <td>{{ userInfo.xh }}</td>
              <td>姓名</td>
              <td>{{ userInfo.xm }}</td>
            </tr>
            <tr>
              <td>所属单位</td>
              <td>{{ userInfo.yjfx }}</td>
              <td>课程</td>
              <td>{{ userInfo.xz }}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="table-box1">
        <table border="1" cellspacing="0" cellpadding="10">
          <thead></thead>
          <tbody>
            <tr style="background: #f2f2f2">
              <td>课程安排</td>
              <td style="width:150px">上课教师</td>
              <td>起始周</td>
              <td>结束周</td>
              <td>星期</td>
              <td>节次</td>
            </tr>
            <tr>
              <td>原课程安排</td>
              <td></td>
              <td>
                <el-select v-model="value" placeholder="请选择">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td>
                <el-select v-model="value" placeholder="请选择">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td>
                <el-select v-model="value" placeholder="请选择">
                  <el-option
                    v-for="item in xqOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td>{{ oldOption.kcxzh }}</td>
            </tr>
            <tr>
              <td>调课后安排</td>
              <td>
                <el-select
                  v-model="newValue"
                  clearable
                  filterable
                  remote
                  reserve-keyword
                  placeholder="请输入工号/姓名"
                  :remote-method="remoteMethod2"
                  @change="selectChange2"
                  @clear="selectClear2"
                >
                  <el-option
                    v-for="item in newOptions"
                    :key="item.kcmc"
                    :label="item.kcmc"
                    :value="item.kcmc"
                  ></el-option>
                </el-select>
              </td>
              <td>
                <el-select v-model="value" placeholder="请选择">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td>
                <el-select v-model="value" placeholder="请选择">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td>
                <el-select v-model="value" placeholder="请选择">
                  <el-option
                    v-for="item in xqOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td>
                <el-row>
                  <el-col :span="10">
                    <el-select v-model="value" placeholder width="50px">
                      <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </el-col>
                  <el-col
                    :span="1"
                    style="line-height:40px;box-sizing:border-box;margin-left:3%;margin-right:3%;"
                  >
                    <span>~</span>
                  </el-col>
                  <el-col :span="10">
                    <el-select v-model="value" placeholder>
                      <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </el-col>
                </el-row>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="table-box">
        <table border="1" cellspacing="0" cellpadding="10">
          <thead></thead>
          <tbody>
            <tr>
              <td colspan="6">调课原因</td>
            </tr>
            <tr>
              <td style="background: #fff">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 6, maxRows: 8}"
                  placeholder="请输入调课原因"
                  v-model="writeInfo.ggyy"
                ></el-input>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'courseAdjust',
  data () {
    return {
      userInfo: {},
      loading: false,
      list: [],
      value: '',
      newValue: '',
      val: '',
      val2: '',
      newOptions: [],
      oldOption: {},
      newOption: {},
      newCourse: {
        faId: '',
        kcsxh: '',
        nr: ''
      },
      writeInfo: {
        ggyy: '',
        min: '',
        nr: '',
        type: '',
        yjhkc: '',
        xggkc: ''
      },
      time: '2019/2/28',
      activeName: 'first',
      input: '',
      dynamicTags: ['课程一', '课程二'],
      inputVisible: false,
      inputValue: '',
      tableData: [],
      options: [
        {
          value: '1',
          label: '1'
        },
        {
          value: '2',
          label: '2'
        },
        {
          value: '3',
          label: '3'
        },
        {
          value: '4',
          label: '4'
        },
        {
          value: '5',
          label: '5'
        },
        {
          value: '6',
          label: '6'
        },
        {
          value: '7',
          label: '7'
        },
        {
          value: '8',
          label: '8'
        },
        {
          value: '9',
          label: '9'
        }
      ],
      xqOptions: [
        {
          value: '1',
          label: '一'
        },
        {
          value: '2',
          label: '二'
        },
        {
          value: '3',
          label: '三'
        },
        {
          value: '4',
          label: '四'
        },
        {
          value: '5',
          label: '五'
        },
        {
          value: '6',
          label: '六'
        },
        {
          value: '7',
          label: '日'
        }
      ],
      msg: false
    }
  },
  created () {},
  mounted () {
    this.getData()
    // this.list = this.states.map(item => {
    //     return {
    //                 value: item,
    //                 label: item
    //             }
    // })
  },
  methods: {
    getData () {
      // this.$http.get('/api/cultivate/kctz/init')
      //     .then(res=>{
      //         let data = res.data.data
      //         //console.log(data)
      //         this.userInfo = data
      //     })
    },
    // 返回列表
    handleBack () {
      // this.$emit('listen',this.msg)
      this.$router.go(-1)
    },
    // 提交申请
    applySubmit () {},
    remoteMethod (query) {
      this.val = ''
      this.val = query
      if (query != '') {
        this.getCourseList()
        this.query = ''
      } else {
        this.options = []
      }
    },
    getCourseList () {
      this.$http
        .get('/api/cultivate/kctz/search', {
          params: {
            query: this.val
          }
        })
        .then(res => {
          let data = res.data.data
          // //console.log(data)
          this.options = data
          // console.log(this.options)
        })
    },
    selectChange () {
      this.oldOption = this.options.find(item => {
        return item.kcmc == this.value
      })
      this.newCourse.faId = this.oldOption.faId
      this.newCourse.kcsxh = this.oldOption.kcsxh
      this.newCourse.nr = this.oldOption.nr
      this.writeInfo.min = this.oldOption.min
      this.writeInfo.nr = this.oldOption.nr
      this.writeInfo.type = this.oldOption.type
      this.writeInfo.yjhkc = this.oldOption.kcId
      this.writeInfo.math = this.oldOption.math
      // //console.log(this.newCourse)
      // //console.log(this.writeInfo)
      // console.log(this.oldOption)
    },
    selectClear () {
      this.oldOption = {}
    },
    // 新课程搜索
    remoteMethod2 (query) {
      this.val2 = ''
      this.val2 = query
      if (query != '') {
        this.getCourseList2()
        this.query = ''
      } else {
        this.newOptions = []
      }
    },
    getCourseList2 () {
      this.$http
        .get('/api/cultivate/kctz/search', {
          params: {
            faId: this.newCourse.faId,
            kcsxh: this.newCourse.kcsxh,
            nr: this.newCourse.nr,
            query: this.val2
          }
        })
        .then(res => {
          let data = res.data.data
          // console.log(data)
          this.newOptions = data
          // console.log(this.newOptions)
        })
    },
    selectChange2 () {
      this.newOption = this.newOptions.find(item => {
        return item.kcmc == this.newValue
      })
      this.writeInfo.xggkc = this.newOption.kcId
      // console.log(this.writeInfo)
    },
    selectClear2 () {
      this.newOption = {}
    },
    handleClose (tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },
    showInput () {
      this.inputVisible = true
      this.$nextTick(() => {
        this.$refs.saveTagInput.$refs.input.focus()
      })
    },
    handleInputConfirm () {
      let inputValue = this.inputValue
      if (inputValue) {
        this.dynamicTags.push(inputValue)
      }
      this.inputVisible = false
      this.inputValue = ''
    },
    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.inside {
  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    // background: #f2f2f2;
    line-height: 40px;
    // border-bottom: 1px solid #ccc;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
  }
  .head {
    text-align: center;
    height: 50px;
    line-height: 50px;
    .left {
      // line-height: 63px;
      flex: 1;
    }
    .center {
      // line-height: 63px;
      .title {
        font-size: 20px;
        font-weight: 700;
        // color: $blue;
        color: #333;
        margin-left: 5px;
        margin-right: 5px;
      }
    }
  }
  .mark {
    color: $blue;
  }
  .block {
    font-size: 16px;
    width: 10px;
    height: 10px;
    background-color: $blue;
    display: inline-block;
  }
  .table-box {
    width: 100%;
    box-sizing: border-box;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      font-size: 14px;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      td {
        width: 100px;
        &:nth-child(odd) {
          background: #f2f2f2;
        }
      }
    }
  }
  .table-box1 {
    width: 100%;
    box-sizing: border-box;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      font-size: 14px;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      td {
        width: 100px;
      }
    }
  }
  .table-box1 /deep/ .el-select {
    width: 100%;
  }
  .timetable {
    border: 1px solid rgba(228, 228, 228, 1);
    margin-top: 15px;
    .table-top {
      background: #f2f2f2;
      padding: 10px;
      margin-bottom: 15px;
      .sum-left {
        margin-left: 30px;
      }
      .sum-right {
        text-align: right;
        padding-right: 15px;
        box-sizing: border-box;
      }
      .sum-num {
        color: $blue;
      }
    }
  }
  .timetable /deep/ .el-tabs__nav {
    width: 100%;
  }
  .timetable /deep/ .el-tabs__item {
    width: 100px;
  }
  .timetable /deep/ .el-tabs__item {
    text-align: center;
  }
  .table-area {
    height: calc(100vh - 208px);
    overflow: auto;
  }
}
</style>
