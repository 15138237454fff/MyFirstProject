<template>
  <div
    v-if="flag === null"
    class="stuScoreManage"
    style="height:100%;"
    v-loading="loadingBody"
  ></div>
  <!-- 学生成绩录入 stuScoreManage -->
  <div class="stuScoreManage" v-else-if="!flag">
    <my-blank msg="成绩录入时间暂未开启" picUrl="blank.png"></my-blank>
  </div>
  <div class="stuScoreManage" v-else>
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
        <el-select
          v-model="limitQuery.courseCode"
          placeholder="某一课程名称"
          @change="handleSelect"
        >
          <el-option
            v-for="item in kcList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <div class="end-scale" v-if="needExam && !isFinish">
          <el-checkbox
            v-model="formData.isScale"
            :true-label="1"
            :false-label="0"
            @change="handleScaleChange"
            >启用比例</el-checkbox
          >
          <span>期末占比(%)：</span>
          <!-- <el-radio-group v-model="formData.isScale">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group> -->
          <el-input-number
            v-if="formData.isScale === 1"
            v-model="formData.scale"
            controls-position="right"
            :min="1"
            :max="99"
          ></el-input-number>
        </div>
      </div>
      <div class="header-right">
        <el-button
          type="primary"
          @click="resultInput"
          :plain="true"
          :disabled="isFinish"
          >成绩录入</el-button
        >
        <el-button type="primary" @click="handleSave" :disabled="isFinish"
          >保存</el-button
        >
        <el-button type="primary" @click="clickSubmit" :disabled="isFinish"
          >一键提交</el-button
        >
      </div>
    </div>
    <div class="table-area">
      <el-table
        :data="tableData"
        border
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column
          label="序号"
          type="index"
          width="50"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="xh"
          label="学号"
          align="center"
          width="150"
        ></el-table-column>
        <el-table-column
          prop="xsxm"
          label="姓名"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="yxsmc"
          label="所属学院"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="zy"
          label="所属专业"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="kcmc"
          label="课程名称"
          align="center"
        ></el-table-column>
        <el-table-column prop="cj" label="平时成绩" align="center">
          <template slot-scope="scope">
            <span v-if="!needExam || !formData.isScale || !showInput">
              {{ scope.row.pscj }}
            </span>
            <el-input-number
              v-else
              v-model="scope.row.pscj"
              controls-position="right"
              :min="0"
              :max="100"
              :precision="1"
              :ref="`ps${scope.$index}`"
              @keyup.enter.native="handlePs(scope.$index)"
            ></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="cj" label="期末成绩" align="center">
          <template slot-scope="scope">
            <span v-if="!needExam || !showInput">{{ scope.row.qmcj }}</span>
            <el-input-number
              v-else
              v-model="scope.row.qmcj"
              controls-position="right"
              :min="0"
              :max="100"
              :precision="1"
              :ref="'qm' + scope.$index"
              @keyup.enter.native="handleQm(scope.$index)"
            ></el-input-number>
          </template>
        </el-table-column>
        <el-table-column prop="cj" label="最终成绩" align="center">
          <template slot-scope="scope">
            <span v-if="!isFinish && needExam">
              <span v-if="formData.isScale === 1">{{
                computedZzcj(scope.row.pscj, scope.row.qmcj)
              }}</span>
              <span v-else>{{ scope.row.qmcj }}</span>
            </span>
            <el-select
              v-model="scope.row.zzcj"
              v-else-if="!isFinish && !needExam && showInput"
            >
              <el-option value="1" label="通过"></el-option>
              <el-option value="0" label="不通过"></el-option>
            </el-select>
            <span v-else-if="!isFinish && !needExam && !showInput">
              {{
                scope.row.zzcj === "1"
                  ? "通过"
                  : scope.row.zzcj === "0"
                  ? "不通过"
                  : ""
              }}
            </span>
            <span v-else>
              {{ scope.row.zzcj }}
            </span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <time-common :year="year"></time-common>
  </div>
</template>

<script>
import timecommon from "@/components/timecommon.vue";
import blank from "@/components/blank";
export default {
  name: "stuScoreManage",
  data() {
    return {
      tableData: [],
      // 显示成绩输入框
      showInput: false,
      // 需要考试的课程
      needExam: false,
      // 已经一键提交过
      isFinish: false,
      kcList: [], // 课程下拉框
      year: "",
      // 列表分页传参
      limitQuery: {
        search: "",
        courseCode: "",
        type: ""
      },
      formData: {
        isScale: 0,
        scale: null
      },
      msgCount: 0,
      // 加载数据状态
      loading: false,
      loadingBody: true,
      flag: null
    };
  },
  mounted() {
    this.getKcList();
    this.getXnxq();
    this.kqgb();
  },
  components: {
    "my-blank": blank,
    "time-common": timecommon
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight;
    }
  },
  methods: {
    kqgb() {
      this.loadingBody = true;
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=cglrsj")
        .then(res => {
          this.loadingBody = false;
          if (res.data.data.isOpen == 1) {
            this.flag = true;
          } else {
            this.flag = false;
          }
        })
        .catch(err => {
          console.log(err.message);
          this.loadingBody = false;
        });
    },
    // 下拉框获取课程
    getKcList() {
      this.$http.get("/api/cultivate/srec/select").then(res => {
        let data = res.data.data;
        if (!data || data.length === 0) {
          return;
        }
        this.kcList = data;
        this.limitQuery.courseCode = data[0].value;
        this.needExam = data[0].ksxs === "1";
        this.limitQuery.type = data[0].type;
        this.formData.isScale = data[0].sfzb;
        this.formData.scale = data[0].rate;
        this.loadTable();
      });
    },
    // 获取当前学年学期
    getXnxq() {
      this.$http.get("/api/cultivate/pycssz/acadmic").then(res => {
        let data = res.data.data;
        this.year =
          data.main.year +
          "年 " +
          (data.main.semester === 1 ? "秋季学期" : "春季学期");
      });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 加载列表
    loadTable() {
      this.$http
        .post("/api/cultivate/srec/forEntry", {
          courseCode: this.limitQuery.courseCode,
          query: this.limitQuery.search,
          type: this.limitQuery.type
        })
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          // console.log(data)
          this.tableData = data.data;
          if (this.tableData.length === 0) {
            this.isFinish = true;
          } else {
            this.isFinish = false;
          }
        });
    },
    // 保存
    handleSave() {
      let list = this.tableData.map(el => {
        let zzcj;
        if (this.needExam) {
          zzcj = this.computedZzcj(el.pscj, el.qmcj);
        } else {
          zzcj = el.zzcj;
        }
        console.log(this.needExam);
        console.log(zzcj);
        return {
          id: el.id,
          pscj: el.pscj,
          qmcj: el.qmcj,
          zzcj,
          xh: el.xh
        };
      });
      let tmpObj = {
        type: this.limitQuery.type,
        list,
        blDTO: {
          kch: this.limitQuery.courseCode,
          qmzb: this.formData.scale,
          sfzb: this.formData.isScale
        }
      };
      console.log(tmpObj);
      this.$http.post("/api/cultivate/srec/save", tmpObj).then(res => {
        if (res.data.code === 200) {
          this.$message.success("保存成功");
          this.showInput = false;
        } else {
          this.$message.error("保存失败");
        }
      });
    },
    clickSubmit() {
      console.log(1232);
      this.$store.commit("updateDialog", {
        msgOne: "是否提交全部成绩？",
        msgTwo: " ",
        visible: true,
        successCallback: this.handleSubmit
      });
    },
    // 一键提交
    handleSubmit() {
      this.$store.commit("updateDialog", { visible: false });
      this.$http.put("/api/cultivate/srec/upload").then(res => {
        if (res.data.code === 200) {
          this.$message.success("提交成功");
          this.loadTable();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 查询
    handleSearch() {
      this.loadTable();
    },
    handleScaleChange() {
      if (this.formData.isScale === 0) {
        this.tableData.forEach(el => {
          el.pscj = "";
        });
      }
    },
    computedZzcj(pscj, qmcj) {
      pscj = parseInt(pscj);
      qmcj = parseInt(qmcj);
      let scale = this.formData.scale / 100;
      if (!this.formData.isScale) {
        return qmcj;
      } else {
        let result = (qmcj * scale + pscj * (1 - scale)).toFixed(1);
        if (isNaN(result)) {
          result = "";
        }
        return result;
      }
    },
    // 下拉框查询
    handleSelect(val) {
      this.showInput = false;
      let tmpObj = this.kcList.find(el => {
        return el.value === val;
      });
      if (tmpObj) {
        this.needExam = tmpObj.ksxs === "1";
        this.limitQuery.type = tmpObj.type;
        this.formData.isScale = tmpObj.sfzb;
        this.formData.scale = tmpObj.rate;
      }
      this.loadTable();
    },
    // 清空搜索框
    handleClear() {
      this.loadTable();
    },
    // 成绩录入
    resultInput() {
      this.showInput = true;
    },
    // 处理平时成绩输入回车事件
    handlePs(index) {
      if (index === this.tableData.length - 1) {
        return;
      }
      this.$refs[`ps${index + 1}`].focus();
    },
    // 处理期末成绩输入回车事件
    handleQm(index) {
      if (index === this.tableData.length - 1) {
        return;
      }
      this.$refs[`qm${index + 1}`].focus();
    },
    // 对话框可见性改变
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    }
  }
};
</script>

<style lang="scss" scoped>
.stuScoreManage {
  position: relative;
  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    .header-left {
      flex: 7;
      display: flex;
      .end-scale {
        margin-left: 14px;
        display: flex;
        align-items: center;
        .el-radio {
          margin-right: 10px;
          line-height: 19px;
        }
        .el-input-number {
          width: 120px;
        }
      }
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
    /deep/ .el-select {
      margin-left: $left;
    }
  }
  .table-area {
    /deep/ td .cell {
      height: 43px;
      line-height: 43px;
    }
    .el-input-number {
      width: 120px;
      padding-right: 0px;
      /deep/ .el-input {
        padding-right: 0px;
      }
    }
    .el-select {
      width: 150px;
      /deep/ .el-input__suffix {
        right: 14px;
      }
    }
  }
}
</style>
<style lang="scss">
.modal-set-scale {
  width: 720px;
}
</style>
