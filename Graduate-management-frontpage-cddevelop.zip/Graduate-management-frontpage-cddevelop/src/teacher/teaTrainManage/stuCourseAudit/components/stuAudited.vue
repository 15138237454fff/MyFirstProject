<template>
  <!-- 学生课程审核：已审核 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
        <el-select v-model="value" placeholder="全部申请类别" @change="handleSelect">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- <div class="header-right">
                <el-button type="primary">导出</el-button>
      </div>-->
    </div>
    <el-table
      :data="tableData"
      border
      :height="tableHeight"
      :header-cell-style="tableHeaderColor"
      v-loading="loading"
      element-loading-text="加载中"
    >
      <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
      <el-table-column prop="processDefinitionName" label="申请类别" align="center" width="120"></el-table-column>
      <el-table-column prop="xh" label="学号" align="center"></el-table-column>
      <el-table-column prop="xm" label="姓名" align="center"></el-table-column>
      <el-table-column prop="xslb" label="学生类别" align="center"></el-table-column>
      <el-table-column prop="xy" label="所属学院" align="center" width="120"></el-table-column>
      <el-table-column prop="zy" label="所属专业" align="center"></el-table-column>
      <el-table-column prop="sznj" label="年级" align="center" show-overflow-tooltip></el-table-column>
      <el-table-column prop="endTime" label="申请时间" align="center" show-overflow-tooltip></el-table-column>
      <el-table-column prop="state" label="审核结果" align="center">
        <template slot-scope="scope">
          <span
            style="cursor:pointer"
            @click="handleSee(scope.row)"
            :class="scope.row.state | statusFilter"
          >{{ scope.row.state | dsztFilter }}</span>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'stuAudited',
  data () {
    return {
      tableData: [],
      options: [
        {
          value: 'stuKcsqService',
          label: '全部申请类别'
        },
        {
          value: 'stuKcsqServiceChangeCourseApply',
          label: '课程调整'
        },
        {
          value: 'stuKcsqServiceExemptionApply',
          label: '免修'
        },
        {
          value: 'stuKcsqServiceDelayedExamApply',
          label: '缓考'
        }
      ],
      value: 'stuKcsqService',
      stuInfo: 'stuKcsqService', // 加载列表参数
      // loading: true,
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ''
      },
      // 分页
      pageList: {
        pageNum: 1,
        pageSize: 10,
        total: 0,
        pages: null
      },
      msgCount: 0,
      loading: false // 表格数据加载状态
    }
  },
  mounted () {
    this.loadTable()
  },
  components: {
    'my-pagination': myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    },
    // 查看详情query：已审核1，待审核0
    handleSee (row) {
      // console.log(row);
      let lcName = row.processDefinitionId.split(':')[0]
      switch (lcName) {
        case 'stuKcsqServiceExemptionApply':
          this.$router.push({
            path: '/stuCourseAudit',
            query: {
              check: 1,
              lcid: row.processInstanceId,
              sqzt: row.state,
              mark: 2
            }
          })
          break
        case 'stuKcsqServiceDelayedExamApply':
          this.$router.push({
            path: '/stuCourseAudit',
            query: {
              check: 1,
              lcid: row.processInstanceId,
              sqzt: row.state,
              mark: 4
            }
          })
          break
      }
    },
    // 加载列表
    loadTable () {
      this.loading = true
      // console.log(this.value);
      this.$http
        .post('/api/cultivate/activityCultivate/getKcsqServiceHistoryAudit', {
          pageNum: this.limitQuery.pageNum,
          pageSize: this.limitQuery.pageSize,
          definitionKeyLike: this.value,
          query: this.limitQuery.search,
          type: 0
        })
        .then(res => {
          this.loading = false
          // console.log(res.data.data);
          let data = res.data.data
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 查询
    handleSearch () {
      this.loadTable()
    },
    // 下拉框查询
    handleSelect () {
      this.loadTable()
    },
    // 清空搜索框
    handleClear () {
      this.value = 'stuKcsqService'
      this.loadTable()
    }
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 56
    }
  }
}
</script>

<style lang="scss" scoped>
// .main-table /deep/ .el-table th > .cell {
//   height: 40px !important;
//   line-height: 40px !important;
// }
.main-table {
  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
    .el-select {
      margin-left: $left;
    }
  }
}
</style>
