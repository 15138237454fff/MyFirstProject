<template>
  <!-- 学生课程审核 待审核列表 -->
  <div class="main-table">
    <div class="header">
      <div class="header-left">
        <el-input
          placeholder="请输入学号/姓名"
          prefix-icon="el-icon-search"
          clearable
          @clear="handleClear"
          v-model="limitQuery.search"
          @keyup.delete.native="handleClear"
          @keyup.enter.native="handleSearch"
        ></el-input>
        <el-button @click="handleSearch">查询</el-button>
        <el-select v-model="value" placeholder="全部申请类别" @change="handleSelect">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
      <!-- <div class="header-right">
                <el-button type="primary">导出</el-button>
      </div>-->
    </div>
    <div class="table-area">
      <el-table
        :data="tableData"
        border
        :height="tableHeight"
        v-loading="loading"
        element-loading-text="加载中"
        :header-cell-style="tableHeaderColor"
      >
        <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
        <el-table-column prop="processDefinitionName" label="申请类别" align="center" width="120"></el-table-column>
        <el-table-column prop="xh" label="学号" align="center" width="100"></el-table-column>
        <el-table-column prop="xm" label="姓名" align="center"></el-table-column>
        <el-table-column prop="xslb" label="学生类别" align="center"></el-table-column>
        <el-table-column prop="xy" label="所属学院" align="center" show-overflow-tooltip></el-table-column>
        <el-table-column prop="zy" label="所属专业" align="center"></el-table-column>
        <el-table-column prop="sznj" label="年级" align="center" show-overflow-tooltip></el-table-column>
        <el-table-column prop="createTime" label="申请时间" align="center" show-overflow-tooltip></el-table-column>
        <el-table-column prop="cz" label="当前审核环节" width="120" align="center">
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="handleSee(scope.row)">{{scope.row.name}}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'stuList',
  data () {
    return {
      tableData: [],
      // loading: true,
      options: [
        {
          value: 'stuKcsqService',
          label: '全部申请类别'
        },
        {
          value: 'stuKcsqServiceChangeCourseApply',
          label: '课程调整'
        },
        {
          value: 'stuKcsqServiceExemptionApply',
          label: '免修'
        },
        {
          value: 'stuKcsqServiceDelayedExamApply',
          label: '缓考'
        }
      ],
      value: 'stuKcsqService',
      stuInfo: 'stuKcsqService', // 加载列表参数
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 分页中每页显示条数
        search: ''
      },
      // 分页
      pageList: {
        pageNum: null,
        pageSize: null,
        total: null,
        pages: null
      },
      msgCount: 0,

      // 加载数据状态
      loading: false
    }
  },
  components: {
    'my-pagination': myPagination
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 56
    }
  },
  mounted () {
    this.loadTable()
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },

    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    },
    // 查看详情
    handleSee (row) {
      // console.log(row)
      let lcName = row.processDefinitionId.split(':')[0]
      switch (lcName) {
        case 'stuKcsqServiceExemptionApply':
          this.$router.push({
            path: '/stuCourseAudit',
            query: {
              check: 0,
              lcid: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 2
            }
          })
          break
        case 'stuKcsqServiceDelayedExamApply':
          this.$router.push({
            path: '/stuCourseAudit',
            query: {
              check: 0,
              lcid: row.processInstanceId,
              taskId: row.id,
              key: row.taskDefinitionKey,
              businesskey: row.processVariables.businesskey,
              name: row.processVariables.name,
              executionId: row.executionId,
              processDefinitionId: row.processDefinitionId,
              mark: 4
            }
          })
          break
      }
    },
    // 加载列表
    loadTable () {
      this.loading = true
      this.$http
        .get('/api/cultivate/activityCultivate/taskKcList', {
          params: {
            definitionKeyLike: this.value,
            pageNum: this.limitQuery.pageNum,
            pageSize: this.limitQuery.pageSize,
            query: this.limitQuery.search,
            type: 0
          }
        })
        .then(res => {
          // console.log(res.data.data)
          this.loading = false
          let data = res.data.data
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 查询
    handleSearch () {
      this.loadTable()
    },
    // 下拉框查询
    handleSelect () {
      this.loadTable()
    },
    // 清空搜索框
    handleClear () {
      this.value = 'stuKcsqService'
      this.loadTable()
    }
  }
}
</script>

<style lang="scss" scoped>
.main-table {
  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    .header-left {
      flex: 5;
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
    .header-right {
      flex: 1;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
    .el-select {
      margin-left: $left;
    }
  }
}
</style>
