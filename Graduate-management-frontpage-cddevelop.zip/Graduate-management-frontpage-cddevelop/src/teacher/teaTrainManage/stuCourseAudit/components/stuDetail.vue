<template>
  <!-- 学生课程审核 -->
  <div class>
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
      <div class="header-right">
        <!-- <el-button type="primary">导出</el-button> -->
      </div>
    </div>
    <div class="table-area">
      <mxsq-save v-if="$route.query.mark == 2" :status="$route.query.sqzt" :userInfo="userInfo"></mxsq-save>
      <hksq-save v-if="$route.query.mark == 4" :status="$route.query.sqzt" :userInfo="userInfo"></hksq-save>
      <apply-status></apply-status>
      <xskc-submit></xskc-submit>
    </div>
  </div>
</template>

<script>
import mxsqSave from '../../../../pages/teachTrain/exemptionRebuild/components/mxsqSave' // 2
import cxsqSave from '../../../../pages/teachTrain/exemptionRebuild/components/cxsqSave' // 2
import hksqSave from '../../../../pages/teachTrain/exemptionRebuild/components/hksqSave' // 2

import applyStatus from '../../../../components/applyStatus'
import xskcSubmit from '../../../../components/teacher/xskcSubmit'
export default {
  name: 'stuDetail',
  components: {
    mxsqSave,
    cxsqSave,
    hksqSave,
    applyStatus,
    xskcSubmit
  },
  data () {
    return {
      userInfo: {}
    }
  },
  created () {},
  mounted () {
    this.getData()
  },
  watch: {
    $route (to) {}
  },
  computed: {},
  methods: {
    // 返回列表
    handleBack () {
      this.$router.go(-1)
    },
    // 免修初始化数据
    getData () {
      this.$http.get('/api/cultivate/kcsq/init').then(res => {
        // console.log(res.data.data)
        this.userInfo = res.data.data
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  height: $tab-height;
  margin-bottom: $top;
  display: flex;
  .header-left {
    flex: 5;
    .el-icon-d-arrow-left {
      // margin-right: 5px;
      color: #409eff;
    }
  }
  .header-right {
    flex: 1;
    text-align: right;
  }
  .el-input {
    width: 200px;
  }
  .el-button {
    margin-left: $left;
  }
}
.table-area {
  height: calc(100vh - 208px);
  overflow: auto;
}
</style>
