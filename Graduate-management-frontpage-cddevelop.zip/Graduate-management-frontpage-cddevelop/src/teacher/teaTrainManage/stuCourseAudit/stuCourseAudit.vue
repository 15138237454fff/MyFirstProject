<template>
  <!-- 学生课程审核 stuCourseAudit -->
  <div class="stuCourseAudit">
    <!-- 学生课程审核 -->
    <el-tabs v-show="!$route.query.mark" v-model="activeName" @tab-click="tabClick">
      <el-tab-pane label="待审核" name="first">
        <stu-list ref="myChild1" v-if="activeName === 'first'"></stu-list>
      </el-tab-pane>
      <el-tab-pane label="已审核" name="second">
        <stu-audited ref="myChild2" v-if="activeName === 'second'"></stu-audited>
      </el-tab-pane>
    </el-tabs>
    <stu-detail v-show="$route.query.mark"></stu-detail>
  </div>
</template>

<script>
import stuList from './components/stuList'
import stuAudited from './components/stuAudited'
import stuDetail from './components/stuDetail'

export default {
  name: 'stuCourseAudit',
  components: {
    stuList,
    stuAudited,
    stuDetail
  },
  data () {
    return {
      activeName: ''
    }
  },
  mounted () {
    this.routeToTab()
  },
  watch: {
    $route () {
      this.routeToTab()
    }
  },
  methods: {
    // tab切换
    tabClick (t) {
      if (t.label == '待审核') {
        this.activeName = 'first'
        this.$router.push({
          path: '/stuCourseAudit',
          query: {
            check: 0
          }
        })
        // this.$refs.myChild1.loadTable();
      }
      if (t.label == '已审核') {
        this.activeName = 'second'
        this.$router.push({
          path: '/stuCourseAudit',
          query: {
            check: 1
          }
        })
        // this.$refs.myChild2.loadTable();
      }
    },
    // 根据当前路由设置tab页控制变量的值
    routeToTab () {
      // 待审核列表页
      if (
        this.$route.fullPath == '/stuCourseAudit?check=0' ||
        this.$route.fullPath == '/stuCourseAudit'
      ) {
        this.activeName = 'first'
      }
      // 已审核列表页
      else if (this.$route.fullPath == '/stuCourseAudit?check=1') {
        this.activeName = 'second'
      }
      // 其他页面
      else {
        this.activeName = ''
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.stuCourseAudit /deep/ {
  .el-tabs__nav-wrap {
    background:$white
  }
  .el-tabs__nav {
    margin-left: $left;
  }
  .el-tabs__item {
    width: 100px;
    text-align: center;
  }
  .el-tabs__header {
    margin-bottom: $top;
  }
}
</style>
