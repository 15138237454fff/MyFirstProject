<template>
  <!-- 培养计划查询：查看详情 -->
  <div class>
    <div class="header">
      <div class="header-left">
        <i class="el-icon-d-arrow-left"></i>
        <el-button type="text" @click="handleBack">返回列表</el-button>
      </div>
      <div class="header-right"></div>
    </div>
    <div class="table-area">
      <apply-detail></apply-detail>
    </div>
  </div>
</template>

<script>
import applyDetail from '../../../../pages/teachTrain/personalPlan/components/applyDetail'
export default {
  name: 'stuDetail',
  components: {
    applyDetail
  },
  methods: {
    // 返回列表
    handleBack () {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.header {
  height: $tab-height;
  margin-bottom: $top;
  display: flex;
  .header-left {
    flex: 5;
    .el-icon-d-arrow-left {
      color: #409eff;
    }
  }
  .header-right {
    flex: 1;
    text-align: right;
  }
  .el-input {
    width: 200px;
  }
  .el-button {
    margin-left: 10px;
  }
}
.table-area {
  height: calc(100vh - 208px);
  overflow: auto;
}
</style>
