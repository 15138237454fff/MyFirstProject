<template>
  <!-- 培养计划查询 -->
  <div class="stuTable">
    <stu-list v-if="!$route.query.lcid"></stu-list>
    <stu-detail v-if="$route.query.lcid"></stu-detail>
  </div>
</template>

<script>
import stuList from './components/stuList'
import stuDetail from './components/stuDetail'
export default {
  name: 'trainPlanQuery',
  components: {
    stuList,
    stuDetail
  },
  data () {
    return {}
  },
  created () {},
  methods: {
    // 返回列表
    handleBack () {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
.stuTable {
  .el-button {
    margin-left: $left;
  }
  /deep/ .el-tabs__header {
    margin-bottom: $top;
  }
}
// .stuTable /deep/ .el-table th>.cell {
//     height: 40px;
//     line-height: 40px;
// }
</style>
