  `<template>
  <div class="goodTable">
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              table-title="浙江财经大学研究生优秀论文申请"
              :status="userStatus == 1 ? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6">
            <span>|</span> 基本信息
          </th>
          <tr>
            <td>学号</td>
            <td>{{author.xh}}</td>
            <td>姓名</td>
            <td>{{author.xsxm}}</td>
            <td>所属学院</td>
            <td>{{author.yxsmc}}</td>
          </tr>
          <tr>
            <td>论文中文题目</td>
            <td colspan="5">{{goodForm.lwzwtm}}</td>
          </tr>
          <tr>
            <td>论文英文题目</td>
            <td colspan="5">{{goodForm.lwywtm}}</td>
          </tr>
          <tr>
            <td>论文答辩日期</td>
            <td>{{goodForm.lwdbrq|toYMD}}</td>
            <td>论文涉及的研究方向</td>
            <td>{{goodForm.lwsjyjfx}}</td>
            <td>论文公开时间</td>
            <td>{{goodForm.lwgksj}}</td>
          </tr>

          <tr>
            <td>一级学科（专业）名称</td>
            <td>{{goodForm.yjxk}}</td>
            <td>二级学科名称</td>
            <td>{{goodForm.ejxk}}</td>
            <td>
              指导教师姓名
              <br />(如导师组按序填入）
            </td>
            <td>{{goodForm.dsxm}}</td>
          </tr>
          <tr>
            <td>指导教师研究方向</td>
            <td colspan="5">{{goodForm.dsyjfx}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 论文评审情况
          </th>
          <tr>
            <td>同意答辩人数</td>
            <td>{{goodForm.tydbrs}}</td>
            <td>同意修改后答辩人数</td>
            <td>{{goodForm.tyxghdbrs}}</td>
            <td>推荐校优人数</td>
            <td>{{goodForm.tjxyrs}}</td>
          </tr>
          <tr>
            <td>推荐省优人数</td>
            <td>{{goodForm.tjsyrs}}</td>
            <td>答辩委员会是否推优</td>
            <td>{{goodForm.dbwyhsfty === 1 ? '是' : '否'}}</td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td>备注</td>
            <td colspan="5">{{goodForm.bz}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6" class="connect-academic">
            <div>
              <span>|</span> 作者攻博期间及获博士学位后一年内获得与博士学位论文密切相关的代表性成果
            </div>
          </th>
          <tr>
            <td colspan="6">
              <el-table :header-cell-style="$tableHeaderColor" border :data="goodForm.cgxx">
                <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
                <el-table-column prop="resultsName" label="成果名称" align="center"></el-table-column>
                <el-table-column prop="resultsType" label="成果类型" align="center">
                  <template slot-scope="scope">
                    <span>{{scope.row.resultsType|resultsType}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="applyDate" label="时间" align="center">
                  <template slot-scope="scope">
                    <span>{{scope.row.applyDate|toDate}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="attachment" label="相关附件" align="center">
                  <template slot-scope="scope">
                    <a
                      target="_blank"
                      :href="scope.row.attachment.url"
                      class="primary"
                      :download="scope.row.attachment.fileName"
                    >{{scope.row.attachment.fileName}}</a>
                  </template>
                </el-table-column>
              </el-table>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <div>
              <span>|</span> 论文创新点
            </div>
          </th>
          <tr>
            <td colspan="6">{{goodForm.lwcxd}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <div>
              <span>|</span> 相关附件
            </div>
          </th>
          <tr>
            <td>论文</td>

            <td>
              <a
                :href="goodForm.lw.url"
                target="_blank"
                class="primary"
                :download="goodForm.lw.fileName"
              >{{goodForm.lw.fileName}}</a>
            </td>
            <td>评阅表</td>
            <td>
              <a
                :href="goodForm.pyb.url"
                target="_blank"
                class="primary"
                :download="goodForm.pyb.fileName"
              >{{goodForm.pyb.fileName}}</a>
            </td>
            <td>答辩记录表</td>
            <td>
              <a
                :href="goodForm.dbjlb.url"
                target="_blank"
                class="primary"
                :download="goodForm.dbjlb.fileName"
              >{{goodForm.dbjlb.fileName}}</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
import applyStatusBottom from "@/components/applyStatusBottom";
export default {
  name: "goodTable",
  components: {
    "table-flag": tableFlag
  },
  data() {
    return {
      // 表单是否可写
      writeable: false,
      // 优秀论文提交表单
      goodForm: {
        // 备注
        bz: "",
        // 成果信息
        cgxx: [],
        // 答辩记录表
        dbjlb: {
          url: "",
          fileName: ""
        },
        // 答辩委员会是否推优
        dbwyhsfty: 1,
        // 导师研究方向
        dsyjfx: "",
        // 二级学科
        ejxk: "",
        // 论文
        lw: {
          url: "",
          fileName: ""
        },
        // 论文创新点
        lwcxd: "",
        // 论文答辩日期
        lwdbrq: "",
        // 论文公开时间
        lwgksj: "立即公开",
        // 论文涉及研究方向
        lwsjyjfx: "",
        // 论文英文题目
        lwywtm: "",
        // 论文中文题目
        lwzwtm: "",
        // 评阅表
        pyb: {
          url: "",
          fileName: ""
        },
        // 推荐省优人数
        tjsyrs: "",
        // 推荐校优人数
        tjxyrs: "",
        // 同意答辩人数
        tydbrs: "",
        // 同意修改后答辩人数
        tyxghdbrs: "",
        // 一级学科
        yjxk: "",
        // 导师姓名
        dsxm: ""
      },
      // 审核状态
      status: null,
      // 流程id
      lcid: "",
      // 作者信息
      author: {
        yxsmc: "", // 学院名称
        xh: "", // 学号
        xsxm: "" // 学生姓名
      },
      // 可选的公开时间
      openTimeOptions: ["立即公开", "一年", "两年", "三年"]
    };
  },
  created() {
    this.historyByXH();
  },
  computed: {
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    },
    // 返回学生学号
    xh() {
      return this.$route.query.xh;
    }
  },
  methods: {
    // 通过学号查询优秀论文申请提交信息
    historyByXH() {
      this.$http.get(`/api/degree/dpcr/${this.xh}`).then(res => {
        console.log(res);
        let data = res.data.data;
        // 如果学生没有上传定稿
        if (data === null) {
          return;
        }
        // 如果上传过定稿，将论文信息定稿，并保存状态和流程id
        Object.keys(this.goodForm).forEach(key => {
          this.goodForm[key] = data[key];
        });
        // 取出审核信息
        this.lcid = data.lcid;
        this.status = data.zt;
        // 取出学生信息
        this.author.xsxm = data.xsxm;
        this.author.xh = data.xh;
        this.author.yxsmc = data.yxsmc;
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.goodTable {
  .title {
    display: flex;
    justify-content: space-between;
    width: 100%;
    .el-breadcrumb {
      margin-left: 30px;
      flex: 5;
      line-height: 40px;
    }
    .right {
      margin-right: 30px;
    }
  }
  .box {
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        &.uploadArea {
          height: 280px;
          background: #fff;
          box-sizing: border-box;
          & > div {
            margin-top: 20px;
            text-align: center;
            color: #00000072;
          }
        }
        &.paperShow {
          height: 85px;
          background: #fff;
        }
      }
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    line-height: 22px;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ebebeb;
  }
  /deep/ .el-dialog__body {
    padding-top: 10px;
    padding-bottom: 10px;
  }
  .confirmBTN {
    margin-top: 10px;
    text-align: center;
  }
}
</style>
