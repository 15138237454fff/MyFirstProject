<template>
  <div class="waitAduit">
    <div class="header">
      <div class="header-left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入学号/姓名"
          clearable
          @clear="limitQuery.query = ''"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
      </div>
    </div>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$tableHeaderColor"
    >
      <el-table-column type="index" width="50" label="序号"></el-table-column>
      <el-table-column prop="studentNumber" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="所属学院"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="lwzwtm" label="论文题目"></el-table-column>
      <el-table-column label="当前审核环节" width="120">
        <template slot-scope="scope">
          <el-button
            @click="goAduit(scope.$index)"
            type="text"
            size="small"
          >{{scope.row.nodeName}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'waitAduit',
  data () {
    return {
      // 表格展示的数据
      tableData: [],
      // 分页查询的参数
      limitQuery: {
        query: '',
        pageSize: 10,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    }
  },
  components: {
    'my-pagination': myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 请求列表数据的方法
    loadTable () {
      this.loading = true
      this.$http
        .post('/api/degree/dpcr/toAudit', this.limitQuery)
        .then(res => {
          this.loading = false
          let data = res.data
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message)
            return
          }
          data = data.data
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.info)) {
            this.$message.error('待审核数据请求失败，请刷新')
            return
          }
          console.log(data.info,6);
          this.tableData = data.info
          this.msgCount = data.total
        })
    },
    // 前往审核的方法
    goAduit (index) {
      console.log('正在前往审核学生：' + this.tableData[index].executionId)
      this.$router.push({
        name: 'goodPaperAduit',
        params: {
          id: '3',
          executionId: this.tableData[index].executionId
        },
        query: {
          check: 0,
          taskId: this.tableData[index].taskId,
          xh: this.tableData[index].studentNumber
        }
      })
    }
  },
  created () {
    this.loadTable()
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 56
    }
  },
  watch: {
    $route (to) {
      if (to.name === 'goodPaperAduit') this.loadTable()
    }
  }
}
</script>
<style scoped lang="scss">
.waitAduit {
  width: 100%;
  overflow: hidden;
  /deep/ .el-select {
    margin-left: $left;
  }

  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: 10px;
    // margin-bottom: $top;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .header-right {
      flex: 3;
      text-align: right;
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
}
</style>
