<template>
  <div class="isAduit">
    <div class="header">
      <div class="header-left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入学号/姓名"
          clearable
          @clear="limitQuery.query = ''"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
      </div>
    </div>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$tableHeaderColor"
    >
      <el-table-column label="序号" type="index" width="50"></el-table-column>
      <el-table-column prop="studentNumber" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="所属学院"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="hdzxf" label="取得总学分">
        <template slot-scope="scope">
          <span :class="scope.row.hdzxf>=minZxf?'primary':'danger'">{{scope.row.hdzxf}}</span>
          (>{{minZxf}})
        </template>
      </el-table-column>
      <el-table-column prop="xwkzxf" label="学位课总学分">
        <template slot-scope="scope">
          <span :class="scope.row.xwkzxf>=minXwkZxf?'primary':'danger'">{{scope.row.xwkzxf}}</span>
          (>{{minXwkZxf}})
        </template>
      </el-table-column>
      <el-table-column prop="xwkzpjf" label="学位课平均分"></el-table-column>
      <el-table-column label="审核状态">
        <template slot-scope="scope">
          <el-button
            @click="goSee(scope.$index)"
            type="text"
            size="small"
            :class="scope.row.status|dsstatusFilter"
          >{{scope.row.status|dsztFilter}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'isAduit',
  data () {
    return {
      // 表格展示的数据
      tableData: [],
      // 分页查询的参数
      limitQuery: {
        query: '',
        pageSize: 10,
        pageNum: 1,
        // 后台参数
        // 学院代码
        collegeCode: '',
        // 学生类别
        studentStatus: null,
        type:0
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 写死变量
      // 最小总学分
      minZxf: 20,
      // 最小学位课总学分
      minXwkZxf: 10
    }
  },
  components: {
    'my-pagination': myPagination
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 56
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 请求列表数据的方法
    loadTable () {
      this.$http
        .post('/api/degree/degree/checked', this.limitQuery)
        .then(res => {
          this.loading = true
          let data = res.data
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message)
            return
          }
          data = data.data
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.info)) {
            this.$message.error('待审核数据请求失败，请刷新')
            return
          }
          this.tableData = data.info
          this.msgCount = data.total
          this.loading = false
        })
    },
    // 前往查看的方法
    goSee (index) {
      console.log('正在前往审核学生：' + this.tableData[index].executionId)
      this.$router.push({
        name: 'academicDegreeAduit',
        params: {
          executionId: this.tableData[index].executionId,
          id: '3'
        },
        query: {
          check: 1,
          xh: this.tableData[index].studentNumber
        }
      })
    }
  },
  created () {
    this.loadTable()
  },
  watch: {
    $route (to) {
      if (to.name === 'academicDegreeAduit') this.loadTable()
    }
  }
}
</script>
<style scoped lang="scss">
.isAduit {
  width: 100%;
  overflow: hidden;
  /deep/ .el-select {
    margin-left: $left;
  }

  .header {
    height: $tab-height;
    margin-bottom: $top;
    display: flex;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
}
</style>
