<template>
  <!-- 提交审核意见 -->
  <div class="audit" v-show="$route.query.check != 1">
    <div class="dashed"></div>
    <el-form>
      <el-form-item label="审核：" class="tuige" prop="name">
        <el-radio-group v-model="writeInfo.check" size="medium">
          <el-radio-button label="1">通过</el-radio-button>
          <el-radio-button label="0">不通过</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="审核意见：" prop="name">
        <el-input
          type="textarea"
          v-model="writeInfo.comment"
          placeholder="请输入审核意见"
          :autosize="{ minRows: 6, maxRows: 8}"
        ></el-input>
      </el-form-item>
    </el-form>
    <div class="bottom">
      <el-button type="primary" @click="sumbitAudit">提交</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'academicDegreeSubmit',
  components: {},
  data () {
    return {
      writeInfo: {
        check: 1,
        comment: '',
        taskId: ''
      }
    }
  },
  created () {
    this.writeInfo.taskId = this.$route.query.taskId
    console.log(this.writeInfo)
  },
  methods: {
    // 提交审核
    sumbitAudit () {
      // 验证非空
      if (this.writeInfo.comment === '') {
        this.$message.error('请填写审核意见后在尝试提交审核')
        return
      }
      this.$http
        .post('/api/degree/degree/audit', this.writeInfo)
        .then(res => {
          // console.log(res.data);
          if (res.data.code === 200) {
            this.$message.success('提交审核成功')
            this.writeInfo.comment = ''
            this.writeInfo.check = 1
            this.$router.go(-1)
          } else {
            this.$message.error('提交审核失败')
          }
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.dashed {
  margin-top: 25px;
  margin-bottom: 20px;
  height: 1px;
  background: linear-gradient(
    to right,
    rgba(204, 204, 204, 1),
    rgba(204, 204, 204, 1) 5px,
    transparent 5px,
    transparent
  );
  background-size: 10px 100%;
}
.audit /deep/ .el-textarea {
  width: 90%;
}
.audit /deep/ .el-button {
  margin-left: 82px;
  width: 30%;
}
.audit {
  .bottom {
    text-align: center;
  }
}
</style>
