<template>
  <!-- 学位申请审核 academicDegreeAduit -->
  <div class="main">
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag table-title="浙江财经大学研究生学位资格申请"></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6">
            <span>|</span> 学生基本信息
          </th>
          <tr>
            <td>学号</td>
            <td>{{studentInfo.xh}}</td>
            <td>姓名</td>
            <td>{{studentInfo.xm}}</td>
            <td>性别</td>
            <td>{{studentInfo.xbm === "1" ? "男" : "女"}}</td>
          </tr>
          <tr>
            <td>出生年月</td>
            <td>{{studentInfo.csrq}}</td>
            <td>身份证号</td>
            <td>{{studentInfo.sfzh}}</td>
            <td>学生类别</td>
            <td>{{studentInfo.xslbmc}}</td>
          </tr>
          <tr>
            <td>所属学院</td>
            <td>{{studentInfo.yxsmc}}</td>
            <td>所属专业</td>
            <td>{{studentInfo.zy}}</td>
            <td>导师</td>
            <td>{{studentInfo.dsxm }}</td>
          </tr>
          <tr>
            <td>取得总学分</td>
            <td>
              <span :class="studentInfo.hdzxf>=minZxf?'primary':'danger'">{{studentInfo.hdzxf}}</span>
              (>{{minZxf}})
            </td>
            <td>学位课总学分</td>
            <td>
              <span :class="studentInfo.hdzxf>=minXwkZxf?'primary':'danger'">{{studentInfo.xwkzxf}}</span>
              (>{{minXwkZxf}})
            </td>
            <td>学位课平均分</td>
            <td>{{studentInfo.xwkzpjf }}</td>
          </tr>
          <tr>
            <td>最后学历</td>
            <td>{{studentInfo.zhxlmc}}</td>
            <td>已获学位</td>
            <td>{{studentInfo.qxwmc}}</td>
            <td>已获学位一级学科</td>
            <td>{{studentInfo.qxwxk }}</td>
          </tr>
          <tr>
            <td>已获学位证书号</td>
            <td>{{studentInfo.qxwzsh}}</td>
            <td>学位授予日期</td>
            <td>{{studentInfo.xwsyrq}}</td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 就业信息
          </th>
          <tr>
            <td>单位名称</td>
            <td>{{degreeForm.jydw}}</td>
            <td>单位性质</td>
            <td>{{degreeForm.dwxz}}</td>
            <td>单位所在地</td>
            <td>{{degreeForm.dwszd}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6" class="connect-academic">
            <div>
              <span>|</span> 取得代表性成果
            </div>
          </th>
        </tbody>
      </table>
      <el-table :header-cell-style="$tableHeaderColor" border :data="degreeForm.dbxcg">
        <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
        <el-table-column prop="resultsName" label="成果名称" align="center"></el-table-column>
        <el-table-column prop="resultsType" label="成果类型" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.resultsType|resultsType}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="applyDate" label="时间" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.applyDate|toDate}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="attachment" label="相关附件" align="center">
          <template slot-scope="scope">
            <a
              target="_blank"
              :href="scope.row.attachment.url"
              class="primary"
              :download="scope.row.attachment.fileName"
            >{{scope.row.attachment.fileName}}</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "degreeTable",
  components: {
    "table-flag": tableFlag
  },
  data() {
    return {
      // 表单是否可写
      writeable: false,
      // 学位表单
      degreeForm: {
        // 代表性成果数组
        dbxcg: [
          // {
          //   //创建时间
          //   applyDate: "",
          //   //文件
          //   attachment: { fileName: "", url: "" },
          //   id: "",
          //   //成果名称
          //   resultsName: "",
          //   //成果类型
          //   resultsType: 0
          // }
        ],
        // 单位所在地
        dwszd: "",
        // 单位性质
        dwxz: "",
        // 就业单位
        jydw: ""
      },
      // 学生基本信息
      studentInfo: {},
      // 写死变量
      // 最小总学分
      minZxf: 20,
      // 最小学位课总学分
      minXwkZxf: 10
    };
  },
  created() {
    // 获取历史申请记录
    this.requireHistoryApply();
    // 获取学生基本信息
    this.requireStudentInfo();
  },
  computed: {
    // 接收路由传递的参数
    // 学号
    xh() {
      return this.$route.query.xh;
    }
  },
  methods: {
    // 请求历史学位申请记录
    requireHistoryApply() {
      this.$http.get(`/api/degree/degree/${this.xh}`).then(res => {
        let data = res.data.data;
        // 如果为null，即没有申请记录
        if (data === null) {
          this.writeable = true;
        }
        // 已经申请学位
        else {
          this.writeable = false;
          // 更新表单中的信息
          Object.keys(this.degreeForm).forEach(key => {
            this.degreeForm[key] = data[key];
          });
          // 保存审核状态
          this.status = data.zt;
        }
      });
    },
    // 获取申请学生基本信息
    requireStudentInfo() {
      this.$http
        .get(`/api/degree/degree/student/basic/${this.xh}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            this.$message.error("获取学生基本信息失败，请重试");
            return;
          }
          this.studentInfo = Object.assign({}, this.studentInfo, data);
        });
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  // padding: 30px;
  // padding-top: 10px;
  // padding-bottom: 0;
  display: flex;
  flex-direction: column;

  .box {
    background-color: #fff;

    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }

        .add {
          font-size: 24px;
          color: #1e6fd9;
          border-radius: 50%;
          padding-left: 20px;
          background: #fff;
          outline: none;
          border: none;
        }
        /deep/ .el-textarea__inner {
          font-size: 14px;
          color: #333;
        }
      }
    }
  }
}
</style>
