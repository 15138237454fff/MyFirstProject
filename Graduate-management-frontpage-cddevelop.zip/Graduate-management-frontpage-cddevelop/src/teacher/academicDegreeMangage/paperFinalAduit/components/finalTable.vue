<template>
  <div class="uploadTable">
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              table-title="浙江财经大学研究生学位论文终稿"
              :status="userStatus == 1 ? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6"><span>|</span> 论文关键信息</th>
          <tr>
            <td>论文中文题目</td>
            <td colspan="5">{{ paperForm.lwzwtm }}</td>
          </tr>
          <tr>
            <td>论文英文题目</td>
            <td colspan="5">{{ paperForm.lwywtm }}</td>
          </tr>
          <tr>
            <td>论文字数</td>
            <td>{{ paperForm.lwzs }}万</td>
            <td>论文类型</td>
            <td>{{ paperForm.lwlx }}</td>
            <td>选题来源</td>
            <td>{{ paperForm.xtly }}</td>
          </tr>
          <!-- <tr>
            <td>论文起始日期</td>
            <td>{{paperForm.lwkssj|toYMD}}</td>
            <td>论文终止日期</td>
            <td>{{paperForm.lwzzsj|toYMD}}</td>
            <td></td>
            <td></td>
          </tr> -->
          <tr>
            <td>论文关键词</td>
            <td colspan="5">{{ paperForm.lwgjz }}</td>
          </tr>
          <tr>
            <td>论文研究方向</td>
            <td colspan="5">{{ paperForm.lwyjfx }}</td>
          </tr>
          <!-- <tr>
            <td>中文摘要</td>
            <td colspan="5">{{paperForm.zwzy}}</td>
          </tr>
          <tr>
            <td>英文摘要</td>
            <td colspan="5">{{paperForm.ywzy}}</td>
          </tr> -->
        </tbody>
        <tbody>
          <th colspan="6"><span>|</span> 论文附件上传</th>
          <tr>
            <td colspan="6" class="paperShow">
              <a
                :href="paperForm.fj.url"
                target="_blank"
                class="primary"
                :download="paperForm.fj.fileName"
                >{{ paperForm.fj.fileName }}</a
              >
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "finalTable",
  components: {
    tableFlag
  },
  data() {
    return {
      // 是否可以写入
      writeable: false,
      // 待提交的表单数据
      paperForm: {
        fj: { url: "", fileName: "" },
        // 论文关键字
        lwgjz: "",
        // 论文类型
        lwlx: "",
        // 论文字数
        lwzs: "",
        // 论文英文题目
        lwywtm: "",
        // 选题来源
        xtly: "",
        // 论文中文题目
        lwzwtm: "",
        // 论文开始时间
        lwkssj: "",
        // 论文终止时间
        lwzzsj: "",
        // 英文摘要
        ywzy: "",
        // 中文摘要
        zwzy: "",
        lwyjfx: ""
      },
      // 审核状态
      status: null,
      // 流程id
      lcid: "",
      originOption: []
    };
  },
  mounted() {
    this.historyByXH();
  },
  methods: {
    // 通过学号查询论文定稿申请提交信息
    historyByXH() {
      this.$http.get(`/api/degree/pfc/${this.xh}`).then(res => {
        console.log(res);
        let data = res.data.data;
        // 如果学生没有上传定稿
        if (data === null) {
          return;
        }
        // 如果上传过定稿，将论文信息定稿，并保存状态和流程id
        Object.keys(this.paperForm).forEach(key => {
          this.paperForm[key] = data[key];
        });
        this.lcid = data.lcid;
        this.status = data.zt;
      });
    }
  },
  computed: {
    // 获取学生学号
    xh() {
      return this.$route.query.xh;
    },
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>
<style lang="scss" scoped>
.uploadTable {
  .box {
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-degree {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        &.uploadArea {
          height: 280px;
          background: #fff;
          box-sizing: border-box;
          & > div {
            margin-top: 20px;
            text-align: center;
            color: #00000072;
          }
        }
        .danwei {
          line-height: 40px;
          margin-right: 5px;
          color: #ccc;
        }
        &.paperShow {
          height: 85px;
          background: #fff;
        }
      }
    }
  }
}
</style>
