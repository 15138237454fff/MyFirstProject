<template>
  <div class="isAduit">
    <div class="header">
      <div class="header-left">
        <el-input
          prefix-icon="el-icon-search"
          v-model="limitQuery.query"
          placeholder="请输入学号/姓名"
          clearable
          @clear="limitQuery.query = ''"
          @keyup.enter.native="loadTable"
        ></el-input>
        <el-button @click="loadTable">查询</el-button>
        <el-select v-model="limitQuery.yxsh" placeholder="全部学院" @change="chooseYxsh">
          <el-option
            v-for="item in collegeCodeList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
        <el-select v-model="limitQuery.zym" placeholder="全部专业" @change="selGrade">
          <el-option
            v-for="item in majorCodeList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
         <el-select v-model="limitQuery.sznj" placeholder="全部年级" @change="changeSznj">
          <el-option
            v-for="(item,index) in grade"
            :key="index"
            :label="item.label"
            :value="item.value"
          ></el-option>
        </el-select>
      </div>
    </div>
    <el-table
      :data="tableData"
      tooltip-effect="dark"
      border
      v-loading="loading"
      element-loading-text="加载中"
      ref="multipleTable"
      style="width: 100%;"
      :height="tableHeight"
      :header-cell-style="$tableHeaderColor"
    >
      <el-table-column prop="studentNumber" label="学号"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="collegeName" label="学院"></el-table-column>
      <el-table-column prop="majorName" label="专业"></el-table-column>
      <el-table-column prop="grade" label="年级"></el-table-column>
      <el-table-column prop="studentStutus" label="学生类别"></el-table-column>
      <el-table-column prop="dsxm" label="导师"></el-table-column>
      <el-table-column prop="lwzwtm" label="论文中文题目"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            @click="goSee(scope.$index)"
            type="text"
            size="small"
            :class="scope.row.status|dsstatusFilter"
          >查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'isAduit',
  data () {
    return {
      // 表格展示的数据
      tableData: [],
      // 分页查询的参数
      limitQuery: {
        query: '',
        pageSize: 10,
        pageNum: 1,
        type:"0",
        yxsh:'',//学院
        zym:'',//专业
        sznj:''//年纪
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      value: "",
      grade:[],//年级列表
      gradeCode:'',
      collegeCodeList:[],//学院列表
    }
  },
  components: {
    'my-pagination': myPagination
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 改变列表页条数大小回调函数
    handleSizeChange (val) {
      this.limitQuery.pageSize = val
      // 重新请求列表数据
      this.loadTable()
    },
    // 改变当前页
    handleCurrentChange (val) {
      this.limitQuery.pageNum = val
      // 重新请求列表数据
      this.loadTable()
    },
    // 请求列表数据的方法
    loadTable () {
      this.loading = true
      this.$http
        .post('/api/degree/pfc/success', this.limitQuery)
        .then(res => {
          this.loading = false
          let data = res.data
          // 如果返回错误信息
          if (data.code === 400) {
            this.$message.error(data.data.message)
            return
          }
          data = data.data
          // 如果返回的数据不是数组类型
          if (!Array.isArray(data.list)) {
            this.$message.error('已审核数据请求失败，请刷新')
            return
          }
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 前往查看的方法
    goSee (index) {
      console.log('正在前往查看学生：' + this.tableData[index].executionId)
      this.$router.push({
        name: 'paperFinalAduit',
        params: {
          executionId: this.tableData[index].executionId,
          id: '3'
        },
        query: {
          check: 1,
          xh: this.tableData[index].studentNumber
        }
      })
    },
    //请求学院和专业中的数据
    tomsg(){
      this.$http.get('/api/system/dict/noPermission').then((res) =>{
        this.collegeCodeList = res.data.data
      })
    },
    chooseYxsh(){
      this.limitQuery.zym = ''
      this.loadTable();
    },
     //筛选年级信息
    selGrade(){
      this.$http.get('/api/system/dict/select/grade').then((res) =>{
        this.grade = res.data.data.reverse()
        this.grade.unshift({value:'',label:'全部年级'})
        this.loadTable();
      })
    },
    changeSznj(){
      this.loadTable();
    }
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 56
    },
    majorCodeList(){
      let collade = this.collegeCodeList.find((el) =>{
        return this.limitQuery.yxsh === el.value
      })
      if (!collade) {
        return []
      }
      return collade.children
    }
  },
  created () {
    this.loadTable()
    this.tomsg()
  },
  mounted(){
    this.selGrade()
  },
  watch: {
    $route (to) {
      if (to.name === 'paperFinalAduit') this.loadTable()
    }
  }
}
</script>
<style scoped lang="scss">
.isAduit {
  width: 100%;

  /deep/ .el-select {
    margin-left: $left;
  }

  .header {
    height: $tab-height;
    display: flex;
    margin-bottom: $top;
    .header-left {
      flex: 3;
      .el-icon-d-arrow-left {
        color: #409eff;
      }
    }
    .el-input {
      width: 200px;
    }
    .el-button {
      margin-left: $left;
    }
  }
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
}
</style>
