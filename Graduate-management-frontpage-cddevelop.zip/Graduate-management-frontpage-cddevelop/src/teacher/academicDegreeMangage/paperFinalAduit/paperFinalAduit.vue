<template>
  <!-- 学位论文定稿 paperFinalAduit -->
  <div class="paperFinalAduit">
    <div class="tabs" v-if="id==2">
      <el-tabs v-model="tabName">
        <el-tab-pane label="待审核论文" name="waitAduit">
          <wait-aduit v-if="tabName === 'waitAduit'"></wait-aduit>
        </el-tab-pane>
        <el-tab-pane label="已通过论文" name="isAduited">
          <is-aduited v-if="tabName === 'isAduited'"></is-aduited>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div v-if="id==3">
      <div class="header">
        <div class="header-left">
          <i class="el-icon-d-arrow-left"></i>
          <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
        </div>
      </div>
      <div class="table-area">
        <final-table></final-table>
        <apply-status></apply-status>
        <final-aduit-submit></final-aduit-submit>
      </div>
    </div>
  </div>
</template>

<script>
import waitAduit from './components/waitAduit'
import isAduited from './components/isAduited'
import finalTable from './components/finalTable'
import applyStatus from '@/components/applyStatus'
import finalAduitSubmit from './components/finalAduitSubmit'
export default {
  name: 'paperFinalAduit',
  props: {
    id: {},
    // 流程id
    executionId: {}
  },
  components: {
    waitAduit,
    isAduited,
    finalTable,
    finalAduitSubmit,
    applyStatus
  },
  data () {
    return {
      tabName: 'waitAduit'
    }
  },
  mounted () {
    this.detailStatus()
  },
  watch: {
    $route () {
      this.detailStatus()
    }
  },
  methods: {
    // 获取审核的历史记录，并将审核的流程数据通过bus进行传值
    detailStatus () {
      if (this.id == 3 && this.$route.name === 'paperFinalAduit') {
        // 如果进入查看/修改详情页面，请求对应流程id的审核状态
        this.$http
          .get('/api/degree/pfc/history/' + this.executionId)
          .then(res => {
            // console.log("aaaa");
            let data = res.data.data
            // console.log(data);
            if (!Array.isArray(data)) {
              this.$message.error('获取审核具体流程数据失败，请刷新重试')
              return
            }
            // 将审核具体流程数据发送给applyStatus
            this.$bus.$emit('stepList', data)
          })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.paperFinalAduit {
  .table-area {
    height: calc(100vh - 208px);
    overflow: auto;
  }
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      background:$white
    }
    /deep/ .el-tabs__nav {
      margin-left: $left;
    }
    /deep/ .el-tabs__item {
      width: 100px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 $top;
    }
  }
  .header {
    height: $tab-height;
    display: flex;
    // background: #f0f2f5;
    align-items: center;
    margin-bottom: $top;
    .header-left {
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
  }
}
</style>
