<template>
  <!-- 学位申请审核 academicDegreeAduit -->
  <div class="academicDegreePaperAduit">
    <div class="tabs" v-if="id==2">
      <el-tabs v-model="tabName">
        <el-tab-pane label="待审核论文" name="waitAduit">
          <wait-aduit v-if="tabName === 'waitAduit'"></wait-aduit>
        </el-tab-pane>
        <el-tab-pane label="已通过论文" name="isAduited">
          <is-aduited v-if="tabName === 'isAduited'"></is-aduited>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div v-if="id==3">
      <div class="header">
        <div class="header-left">
          <i class="el-icon-d-arrow-left"></i>
          <el-button type="text" @click="$router.go(-1)">返回列表</el-button>
        </div>
      </div>
      <div class="table-area">
        <upload-table></upload-table>
        <apply-status></apply-status>
        <paper-aduit-submit></paper-aduit-submit>
      </div>
    </div>
  </div>
</template>

<script>
import waitAduit from './components/waitAduit'
import isAduited from './components/isAduited'
import uploadTable from './components/uploadTable'
import applyStatus from '@/components/applyStatus'
import paperAduitSubmit from './components/paperAduitSubmit'

export default {
  name: 'academicDegreePaperAduit',
  props: {
    id: {},
    // 流程id
    executionId: {}
  },
  components: {
    waitAduit,
    isAduited,
    uploadTable,
    paperAduitSubmit,
    applyStatus
  },
  data () {
    return {
      tabName: 'waitAduit'
    }
  },
  mounted () {
    this.detailStatus()
  },
  watch: {
    $route () {
      this.detailStatus()
    }
  },
  methods: {
    // 获取审核的历史记录，并将审核的流程数据通过bus进行传值
    detailStatus () {
      if (this.id == 3 && this.$route.name === 'academicDegreePaperAduit') {
        // 如果进入查看/修改详情页面，请求对应流程id的审核状态
        this.$http
          .get('/api/degree/duc/history/' + this.executionId)
          .then(res => {
            // console.log("aaaa");
            let data = res.data.data
            // console.log(data);
            if (!Array.isArray(data)) {
              this.$message.error('获取审核具体流程数据失败，请刷新重试')
              return
            }
            // 将审核具体流程数据发送给applyStatus
            this.$bus.$emit('stepList', data)
          })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.academicDegreePaperAduit {
  .table-area {
    height: calc(100vh - 208px);
    overflow: auto;
  }
  .tabs {
    /deep/ .el-tabs__nav-wrap {
      background:$white
    }
    /deep/ .el-tabs__nav {
      margin-left: $left;
    }
    /deep/ .el-tabs__item {
      width: 100px;
      text-align: center;
    }
    /deep/ .el-tabs__header {
      margin: 0 0 $top;
    }
  }
  .header {

    height: $tab-height;
    margin-bottom: $top;
    display: flex;
    // background: #f0f2f5;
    align-items: center;
    .header-left {
      .el-icon-d-arrow-left {
        // margin-right: 5px;
        color: #409eff;
      }
    }
  }
}
</style>
