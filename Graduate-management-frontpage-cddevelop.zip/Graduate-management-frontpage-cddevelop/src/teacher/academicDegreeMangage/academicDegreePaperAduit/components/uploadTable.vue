<template>
  <div class="uploadTable" v-loading="loading">
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              table-title="浙江财经大学研究生论文上传"
              :status="userStatus == 1 ? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6"><span>|</span> 论文关键信息</th>
          <tr>
            <td>论文中文题目</td>
            <td colspan="5">{{ paperForm.xwlwtm }}</td>
          </tr>
          <tr>
            <td>论文英文题目</td>
            <td colspan="5">{{ paperForm.xwlwywtm }}</td>
          </tr>
          <tr>
            <td>论文字数</td>
            <td>{{ paperForm.lwzs }}万</td>
            <td>论文类型</td>
            <td>{{ paperForm.lwlx }}</td>
            <td>选题来源</td>
            <td>{{ paperForm.xtly }}</td>
          </tr>
          <tr>
            <td>论文关键词</td>
            <td colspan="5">{{ paperForm.lwgjz }}</td>
          </tr>
          <tr>
            <td>论文研究方向</td>
            <td colspan="5">{{ paperForm.lwyjfx }}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6"><span>|</span> 论文附件上传</th>
          <tr>
            <td colspan="6" class="paperShow">
              <a
                :href="paperForm.fj.url"
                target="_blank"
                class="primary"
                :download="paperForm.fj.fileName"
                >{{ paperForm.fj.fileName }}</a
              >
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "uploadTable",
  props: {
    id: { default: 0 }
  },
  components: {
    tableFlag
  },
  data() {
    return {
      // 是否可以写入
      writeable: false,
      // 是否已经上传过论文
      // hasUpload:false,
      // 待提交的表单数据
      paperForm: {
        fj: { url: "", fileName: "" },
        // 论文关键字
        lwgjz: "",
        // 论文类型
        lwlx: "",
        // 论文字数
        lwzs: "",
        // 选题来源
        xtly: "",
        // 学位论文题目
        xwlwtm: "",
        xwlwywtm: "",
        lwyjfx: ""
      },
      // 审核状态
      status: null,
      // 流程id
      lcid: "",
      originOption: [],
      loading: true
    };
  },
  mounted() {
    this.historyByXH();
  },
  methods: {
    // 通过学号查询学位论文上传申请提交信息
    historyByXH() {
      this.$http
        .get(`/api/degree/duc/${this.xh}`)
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          // 如果学生没有上传过论文
          if (data === null) {
            return;
          }
          // 如果上传过论文，将论文信息保存，并保存状态和流程id
          Object.keys(this.paperForm).forEach(key => {
            this.paperForm[key] = data[key];
          });
          this.lcid = data.lcid;
          this.status = data.zt;
        })
        .catch(err => {
          this.loading = false;
          this.$message.error(err.data.message);
        });
    }
  },
  computed: {
    // 获取学生学号
    xh() {
      return this.$route.query.xh;
    },
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>
<style lang="scss" scoped>
.uploadTable {
  .box {
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: left;
          padding-left: 10px;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        .danwei {
          line-height: 40px;
          margin-right: 5px;
          color: #ccc;
        }
        &.uploadArea {
          height: 280px;
          background: #fff;
          box-sizing: border-box;
          & > div {
            margin-top: 20px;
            text-align: center;
            color: #00000072;
          }
        }
        &.paperShow {
          height: 85px;
          background: #fff;
        }
      }
    }
  }
}
</style>
