// 学生列表审核状态颜色过滤
export function listStatusFilter(sqzt) {
  sqzt = parseInt(sqzt)
  const statusMap = {
    3: 'info',
    2: 'warning',
    1: 'primary',
    0: 'danger',
    4: 'danger'
  }
  return statusMap[sqzt]
}
// 学生列表审核状态名称过滤
export function ztFilter(sqzt) {
  sqzt = parseInt(sqzt)
  const statusMap = {
    2: '审核中',
    1: '通过',
    0: '不通过',
    4: '退回'
  }
  return statusMap[sqzt]
}
export function statusFilter(sqzt) {
  sqzt = parseInt(sqzt)
  const statusMap = {
    2: 'ing',
    1: 'yes',
    0: 'back',
    4: 'back'
  }
  return statusMap[sqzt]
}

export function dsstatusFilter(sqzt) {
  sqzt = parseInt(sqzt)
  switch (sqzt) {
    case 1:
      return 'yes'
    case 2:
      return 'back'
    case 0:
      return 'back'
  }
}

// 导师列表审核状态颜色过滤
export function dslistStatusFilter(sqzt) {
  sqzt = parseInt(sqzt)
  const statusMap = {
    '1': 'primary',
    '0': 'danger',
    '2': 'danger'
  }
  return statusMap[sqzt]
}
// 导师列表审核状态名称过滤
export function dsztFilter(sqzt) {
  sqzt = parseInt(sqzt)
  switch (sqzt) {
    case 1:
      return '通过'
    case 2:
      return '退回'
    case 0:
      return '不通过'
  }
}

// 导师调课：星期过滤
export function xqFilter(xq) {
  const statusMap = {
    '1': '星期一',
    '2': '星期二',
    '3': '星期三',
    '4': '星期四',
    '5': '星期五',
    '6': '星期六',
    '7': '星期日'
  }
  return statusMap[xq]
}
// 周星期过滤
export function zXqFilter(xq) {
  const statusMap = {
    '1': '周一',
    '2': '周二',
    '3': '周三',
    '4': '周四',
    '5': '周五',
    '6': '周六',
    '7': '周日'
  }
  return statusMap[xq]
}
// 时间转为日期格式
export function toDate(time) {
  let tmpTime = new Date(time)
  return `${tmpTime.getFullYear()}.${tmpTime.getMonth() + 1}.${tmpTime.getDate()}`
}
// 时间转为年月日格式
export function toYMD(time) {
  let tmpTime = new Date(time)
  if (isNaN(tmpTime)) {
    return ""
  }
  return `${tmpTime.getFullYear()}年${tmpTime.getMonth() + 1}月${tmpTime.getDate()}日`
}
// 根据sxw上午下午晚上的编码来转化为对应中文
export function sxwToChinese(sxw) {
  switch (sxw) {
    case '0':
      return '上午'
    case '1':
      return '下午'
    case '2':
      return '晚上'
  }
}
// 根据sxw上午下午晚上的编码来转化为对应中文
export function sfmzToChinese(sfmz) {
  switch (sfmz) {
    case '1':
      return '每周'
    case '2':
      return '单周'
    case '3':
      return '双周'
    default:
      return sfmz
  }
}
//
export function resultsType(type) {
  switch (type) {
    case 1:
      return '学术论文'
    case 2:
      return '技术专利'
    case 3:
      return '发表著作'
    case 4:
      return '科研项目'
    default:
      return type
  }
}

export function sexFilter(val) {
  val = parseInt(val)
  switch (val) {
    case 1:
      return '男'
    case 2:
      return '女'
    default:
      return "未知"
  }
}
export function xmlxFilter(type) {
  type = parseInt(type)
  switch (type) {
    case 1:
      return '硕士研究生课程建设项目'
    case 2:
      return '博士研究生课程建设项目'
    case 3:
      return '专业学位研究生课程案例库建设项目'
    case 4:
      return '田野调查基金项目'
    case 5:
      return '校级研究生科研项目'
    case 6:
      return '知行浙江社会调研项目'
    case 7:
      return '硕士研究生课程建设项目结题'
    case 8:
      return '田野调查基金项目结题'
    case 9:
      return '校级科研项目结题'
    default:
      return ""
  }
}
