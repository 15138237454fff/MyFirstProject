<template>
    <div class="gjhBox">
        <!-- 国际化培养 interTrain -->
        <unopen/>
    </div>
</template>

<script>
import unopen from '@/components/unopen'
export default {
  name: 'interTrain',
  components:{unopen}
}
</script>

<style lang="scss" scoped>
  .gjhBox{
    height: 100%;
    width: 100%;
  }
</style>
