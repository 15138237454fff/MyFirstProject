<template>
  <div class="main" :style="{
      'background-image':
        'url(' +
        (backbg.backgroundImage ? backbg.backgroundImage : coverImgUrl) +
        ')'
    }">
    <!-- 登录页 login -->
    <div class="box">
      <p class="box_p">欢迎登录</p>
      <el-form :model="loginForm" :rules="rules" ref="loginForm">
        <el-form-item lable="用户名" prop="username">
          <el-input v-model="loginForm.username" placeholder="请输入教职工号/学号" type="text" prefix-icon="el-icon-user"></el-input>
        </el-form-item>
        <el-form-item lable="密码" prop="password" style="margin-top:20px">
          <el-input type="password" placeholder="请输入密码" v-model="loginForm.password" @keyup.enter.native="loginCLick" prefix-icon="el-icon-unlock" show-password></el-input>
        </el-form-item>
        <el-form-item lable="yan" prop="changeCode" style="margin-top:20px">
          <el-row>
            <el-col :span="14">
              <el-input v-model="loginForm.changeCode" placeholder="验证码" type="text" @keyup.enter.native="loginCLick"></el-input>
            </el-col>
            <el-col :span="9" :offset="1" style="border:1px solid #f4f4f4;height:40px">
              <img :src="imgurl" @click="changeImg" style="width:100%;height:100%" />
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>
      <el-button class="login-Button" @click="loginCLick" type="primary">登录</el-button>
      <div class="mind">
        <el-checkbox v-model="checked" style="color:#333;" @click="remind" id="remid">一周内记住密码</el-checkbox>
        <!-- <label><input type="checkbox" value="0" @change="remind" id="remid"></label> -->
        <span @click="forgot" class="forgotpassword">忘记密码?</span>
      </div>
      <div class="bottom">
        <span>© 技术支持：杭州毕为科技有限公司</span>
      </div>
    </div>
  </div>
</template>

<script>
import bgloGo from "../../assets/background_loGo.png";
export default {
  data() {
    return {
      loginForm: {
        username: "",
        password: "",
        // changeCode: '',
        week: 0
      },
      app: {
        backgroundImage: "url(" + require("../../assets/images/qtbg.jpg") + ")",
        backgroundRepeat: "no-repeat",
        backgroundSize: "100% 100%"
      },
      backbg: {
        backgroundImage: ""
      },
      imgurl: "",
      rules: {},
      checked: false,
      coverImgUrl: bgloGo
    };
  },
  created() {
    this.backgrounduRl();
    this.changeImg();
  },
  methods: {
    loginCLick() {
      if (Object.values(this.loginForm).includes("")) {
        this.$message.warning("请将登录信息填写完整");
        return;
      }
      this.$store
        .dispatch("login", this.loginForm) // dispatch：含有异步操作，例如向后台提交数据，写法： this.$store.dispatch('action方法名',值)
        .then(result => {
          this.$message.success(result);
          this.loginSuccessInit();
          // 根据用户的登录状态，确定是导师还是学生
          let path = this.userStatus === "1" ? "/" : "/teacherHome";
          this.$router.push({
            path
          });
        })
        .catch(err => {
          // console.log("登录失败");
          this.changeImg()
          this.$message.error(err);
        });
    },
    // 登录成功后初始化
    loginSuccessInit() {
      this.$http.get("/api/system/home/initData");
    },
    // 修改验证码图片
    changeImg() {
      // console.log("更新验证码");
      this.$http
        .get("api/usermanage/user/changeCode?t=" + Math.random(), {
          responseType: "arraybuffer"
        })
        .then(response => {
          return (
            "data:image/png;base64," +
            btoa(
              new Uint8Array(response.data).reduce(
                (data, byte) => data + String.fromCharCode(byte),
                ""
              )
            )
          );
        })
        .then(res => {
          // //console.log(res);
          this.imgurl = res;
        });
    },
    remind() {
      // 记住密码，有7天的有效期限
      if (checked == true) {
        $.cookie("userid", this.loginForm.password, { expires: 7 }); // 存储一个带7天期限的 cookie
      }
      if ($.cookie("this.loginForm.password") != null) {
        $.cookie("userid");
      }
    },

    forgot() {
      this.$router.push("/forgotPassword");
    },
    backgrounduRl() {
      this.$http.get("/api/system/xxinfo/getInfo").then(res => {
        this.backbg.backgroundImage = res.data.data.fudlbjt;
        this.$store.commit("logoImg", res.data.data.logo);
      });
    }
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  width: 100%;
  height: 100%;
  background-repeat: no-repeat;
  background-size: cover;
  .box {
    width: 28%;
    max-width: 330px;
    min-width: 250px;
    // height: 300px;
    border-radius: 8px;
    background-color: rgba(255, 255, 255, 0.4);
    padding: 50px 30px 20px;
    float: right;
    margin-right: 140px;
    // transform: translateY(50%);
    margin-top: 340px;
    .box_p {
      color: #fff;
      font-weight: 500;
      font-size: 36px;
      width: 100%;
      text-align: center;
      margin-bottom: 30px;
    }
    // .el-form{
    //   .el-form-item{
    //     margin-top: 5px !important;
    //   }
    // }
    .el-button {
      width: 100%;
    }
    .mind {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      .forgotpassword:hover {
        color: #45a8fe;
      }
    }
    .bottom {
      text-align: center;
      margin-top: 40px;
      font-size: 12px;
    }
  }
  // .box /deep/ .el-input__inner {
  //     background-color: rgba(255, 255, 255, .3);
  //     color: #fff;
  // }
}
</style>
<style lang="scss">
.box .el-input__icon {
  font-size: 20px !important;
}
</style>
