<template>
  <div style="height:100%">
    <div class="content">
      <head-nav></head-nav>
      <div v-show="!showMain">
        <head-link></head-link>
      </div>
      <div v-if="showMain && !tzggShowMore">
        <section class="main-index">
          <section class="content-left">
            <div
              class="item-box"
              v-for="(item, index) in menuList"
              :key="index"
            >
              <div class="box-img">
                <img
                  src="../assets/images/person.png"
                  alt
                  v-show="item.title == '个人信息管理'"
                />
                <img
                  src="../assets/images/date.png"
                  alt
                  v-show="item.title == '日常工作'"
                />
                <img
                  src="../assets/images/train.png"
                  alt
                  v-show="item.title == '教学培养'"
                />
                <img
                  src="../assets/images/i18n.png"
                  alt
                  v-show="item.title == '国际化培养'"
                />
                <img
                  src="../assets/images/youbo.png"
                  alt
                  v-show="item.title == '教育建设项目'"
                />
                <img
                  src="../assets/images/achieve.png"
                  alt
                  v-show="item.title == '学术成果'"
                />
                <img
                  src="../assets/images/degree.png"
                  alt
                  v-show="item.title == '学位申请'"
                />
                <img
                  src="../assets/images/server.png"
                  alt
                  v-show="item.title == '离校就业服务'"
                />
              </div>
              <div class="box-content">
                <div class="box-title">
                  <h4 @click="titleClick(item.url)">{{ item.title }}</h4>
                </div>
                <div class="box-main">
                  <span
                    v-for="(i, index) in menuList[index].list"
                    :key="index"
                    @click="nameClick(i.url, item.url)"
                    >{{ i.name }}</span
                  >
                </div>
              </div>
            </div>
          </section>
          <section class="content-right">
            <div class="box-right">
              <div class="header">
                <img src="../assets/images/notice.png" alt />
                <h3>通知公告</h3>
                <el-button class="tzggShowMore" @click="goToNotice"
                  >查看更多</el-button
                >
              </div>
              <el-divider></el-divider>
              <!-- 通知公告内容主体 -->
              <div class="main-tzgg">
                <ul>
                  <li
                    v-for="(item, index) in tzgg"
                    :key="item.bt"
                    @click="goDetail(item.id)"
                  >
                    <span class="text-ellipsis">• {{ item.bt }}</span>
                    <span class="timeShow">{{
                      $tagTime(item.cjsj, "yyyy-MM-dd")
                    }}</span>
                  </li>
                </ul>
              </div>
            </div>
            <div class="box-right">
              <div class="header">
                <img src="../assets/images/process.png" alt />
                <h3>申请进度</h3>
                <!-- <el-button
                  type="text"
                  @click="shjdShowMore = !shjdShowMore"
                >{{shjdShowMore ? "取消查看" :"查看更多"}}</el-button>-->
              </div>
              <el-divider></el-divider>
              <!-- 申请进度内容主体 -->
              <div class="main-dbsx">
                <ul class="overAuto">
                  <li v-for="(item, index) of shjd" :key="index">
                    <span class="text-ellipsis"
                      >• {{ item.processDefinitionName }}</span
                    >
                    <span>进度：</span>
                    <el-progress
                      :percentage="50"
                      :show-text="false"
                    ></el-progress>
                    <span class="timeShow">{{ item.createTime }}</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>
        </section>
      </div>
      <div class="view-box" v-else>
        <router-view></router-view>
      </div>
    </div>
    <my-dialog></my-dialog>
  </div>
</template>
<script>
import headNav from "../components/headNav";
import headLink from "../components/headLink";
import myDialog from "../components/myDialog";

export default {
  name: "index",
  components: {
    headNav,
    headLink,
    myDialog
  },
  data() {
    return {
      imgUrl: {
        imgurl1: "../assets/images/home-1.png"
      },
      menuList: [
        {
          img: "",
          title: "个人信息管理",
          url: "personalInfo",
          id: "1",
          list: [
            {
              name: "个人基本信息",
              url: "baseInfo",
              id: "1-1"
            },
            {
              name: "学籍异动申请",
              url: "stuChange",
              id: "1-2"
            },
            {
              name: "研究生证补办",
              url: "cardReapply",
              id: "1-3"
            },
            {
              name: "硕博连读申请",
              url: "suoboApply",
              id: "1-4"
            },
            {
              name: "更换导师申请",
              url: "changeTutor",
              id: "1-5"
            }
          ]
        },
        {
          img: "",
          title: "日常工作",
          url: "routine",
          id: "2",
          list: [
            {
              name: "勤工岗位申请",
              // url: 'baseInfo',
              id: "2-1"
            },
            {
              name: "学生活动报名",
              // url: 'stuChange',
              id: "2-2"
            },
            {
              name: "入党申请",
              // url: 'cardReapply',
              id: "2-3"
            }
          ]
        },
        {
          img: "",
          title: "教学培养",
          url: "teachTrain",
          id: "3",
          list: [
            {
              name: "个人培养计划",
              url: "personalPlan",
              id: "3-1"
            },
            {
              name: "在线选课",
              url: "onlineSelection",
              id: "3-2"
            },
            {
              name: "免修/重修/缓考",
              url: "exemptionRebuild",
              id: "3-3"
            },
            {
              name: "在线评教",
              url: "onlineEvalution",
              id: "3-4"
            },
            {
              name: "个人课表",
              url: "personalTimetable",
              id: "3-5"
            },
            {
              name: "个人成绩单",
              url: "personalTranscript",
              id: "3-6"
            },
            {
              name: "英语四六级报名",
              url: "applyCET",
              id: "3-7"
            }
          ]
        },
        {
          img: "",
          title: "国际化培养",
          url: "interTrain",
          id: "4",
          list: [
            {
              name: "项目申请",
              // url: 'baseInfo',
              id: "4-1"
            },
            {
              name: "出国报备申请",
              // url: 'stuChange',
              id: "4-2"
            },
            {
              name: "成果录入",
              // url: 'cardReapply',
              id: "4-3"
            },
            {
              name: "国际化培养查询",
              // url: 'suoboApply',
              id: "4-4"
            }
          ]
        },
        {
          img: "",
          title: "教育建设项目",
          url: "jiaoyujianshe",
          id: "5",
          list: [
            {
              name: "项目申报",
              url: "projectReport",
              id: "5-1"
            },
            {
              name: "我的项目",
              url: "myProject",
              id: "5-1"
            },
            {
              name: "结题申请",
              url: "conclusionApply",
              id: "5-1"
            }
          ]
        },
        {
          img: "",
          title: "学术成果",
          url: "academicAchieve",
          id: "6",
          list: [
            {
              name: "学术成果录入",
              url: "achieveInput",
              id: "6-1"
            },
            {
              name: "个人成果查询",
              url: "achieveQuery",
              id: "6-2"
            }
          ]
        },
        {
          img: "",
          title: "学位申请",
          url: "academicDegree",
          id: "7",
          list: [
            {
              name: "送审论文上传",
              url: "academicDegreePaperUpload",
              id: "7-2"
            },
            {
              name: "教育满意度调查",
              url: "degreeAnwserPaper",
              id: "7-3"
            },
            {
              name: "论文终稿上传",
              url: "academicDegreePaperFinal",
              id: "7-4"
            }
          ]
        },
        {
          img: "",
          title: "离校就业服务",
          url: "employService",
          id: "8",
          list: [
            {
              name: "电子离校单",
              // url: 'baseInfo',
              id: "8-1"
            },
            {
              name: "毕业档案查询",
              // url: 'stuChange',
              id: "8-2"
            }
          ]
        }
      ],
      submenuList: [],
      showMain: true, // 卡片显示
      isactive: false, // 动态绑定class
      titleValue: "", // 记录标题的名字
      enterShow: false, // 鼠标移入显示与隐藏
      isActivated: false, // 鼠标移入具体的li
      // 通知公告
      tzgg: [],
      // 审核进度
      shjd: [],
      waitTime: 30 * 60 * 1000,
      timer: null,
      // 通知公告查看更多
      tzggShowMore: false
      // //审核进度查看更多
      // shjdShowMore: false
    };
  },
  mounted() {
    // console.log(this.$route);
    if (this.$route.path == "/") {
      this.showMain = true;
      this.tzggShowMore = false;
    } else if (
      this.$route.path == "/noticeList" ||
      this.$route.name == "noticeDetail"
    ) {
      this.showMain = true;
      this.tzggShowMore = true;
    } else {
      this.showMain = false;
    }
    // this.getList()
    // 验证是否在主页
    // if (this.showMain) {
    // 获取通知信息
    this.requserTZGG();
    // 获取审核进度
    this.requserSH();
    // }
    // 页面挂载后获取表格高度
    this.$store.commit("updateTableHeight");
    // 窗口大小改变后获取表格高度
    window.onresize = () => {
      return (() => {
        this.$store.commit("updateTableHeight");
      })();
    };
    this.startTimeOut();
  },

  watch: {
    $route() {
      if (this.$route.path == "/") {
        this.showMain = true;
        this.tzggShowMore = false;
      } else if (
        this.$route.path == "/noticeList" ||
        this.$route.name == "noticeDetail"
      ) {
        this.showMain = true;
        this.tzggShowMore = true;
      } else {
        this.showMain = false;
      }
    }
  },
  methods: {
    throttle() {
      console.log("重置定时器");
      clearTimeout(this.timer);
      this.timer = setTimeout(this.handleOutlog, this.waitTime);
    },
    handleOutlog() {
      console.log("退出登录");
      this.endTimeOut();
      clearTimeout(this.timer);
      // 清空用户登录信息
      this.$store.commit("updatedUser", {
        xh: "",
        token: "",
        userSsy: "",
        id: "",
        name: "",
        userStatus: ""
      });
      if (this.$route.path === "/login") {
        return;
      }
      this.$message.error("长时间无操作，强制退出");
      this.$router.push("/login");
    },
    startTimeOut() {
      document.body.onmousemove = this.throttle;
    },
    endTimeOut() {
      document.body.onmousemove = null;
    },
    // 请求通知公告
    requserTZGG() {
      // 如果没有角色ID
      // console.log(this.userRoleId);
      // if (!this.userRoleId) {
      //   return false;
      // }
      this.$http
        .get("/api/system/deskHome/getDeskNotice/" + this.currentRoleId)
        .then(result => {
          let list = result.data.data;
          // console.log(result.data.data);
          // 对通知消息进行格式验证
          if (!Array.isArray(list)) {
            this.$message.error("通知信息列表参数格式不正确");
            return false;
          }
          this.tzgg = list;
          // 对正文内容进行过滤
          this.tzgg.forEach(el => {
            if (typeof el.bt === "string") {
              el.bt = el.bt.replace(/<[a-zA-Z]+\/?>|<\/[a-zA-Z]+>/g, "");
            }
          });
          // 通知消息按照时间排序，先展示近期消息
          // this.tzgg.sort((a, b) => {
          //   return new Date(b.cjsj) - new Date(a.cjsj);
          // });
        });
    },
    // 通知公告通过id跳转页面
    // 前往对应通知详情
    goDetail(id) {
      // console.log(id);
      this.$router.push("/noticeDetail/" + id);
    },
    // 请求审核进度
    requserSH() {
      // 接口请求错了，还没有对应接口
      // this.$http.get("/api/system/dbsx/selectRuTask?type=0").then(result => {
      //   let data = result.data.data;
      //   let tmpArr = [];
      //   // 数据验证
      //   if (!Array.isArray(data)) {
      //     this.$message.error("未获取审核进度数据");
      //     return false;
      //   }
      //   data.forEach(el => {
      //     if (this.xh === el.xh) {
      //       tmpArr.push(el);
      //     }
      //   });
      //   tmpArr.sort((a, b) => {
      //     return new Date(b.createTime) - new Date(a.createTime);
      //   });
      //   // console.log(tmpArr);
      //   this.shjd = tmpArr;
      // });
    },
    // 点击标题各个子页面切换
    titleClick(t) {
      this.titleValue = t;
      switch (t) {
        case "personalInfo":
          this.$router.push({
            path: "/personalInfo/baseInfo"
          });
          this.showMain = false;
          break;
        case "routine":
          // this.$router.push({
          //   name: "routine"
          // });
          // this.showMain = false;
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "teachTrain":
          this.$router.push({
            path: "/teachTrain/personalPlan/1"
          });
          this.showMain = false;
          break;
        case "interTrain":
          // this.$router.push({
          //   name: "interTrain"
          // });
          // this.showMain = false;
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "jiaoyujianshe":
          // this.$router.push("/jiansheProject/projectReport");
          // this.showMain = false;
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "academicAchieve":
          // this.$router.push("/academicAchieve/achieveInput/1");
          // this.showMain = false;
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "academicDegree":
          this.$router.push({
            name: "academicDegreePaperFinal"
          });
          this.showMain = false;
          break;
        case "employService":
          // this.$router.push({
          //   name: "employService"
          // });
          // this.showMain = false;
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
      }
    },
    // 点击标题下方标签跳转,根据url判断跳转地址
    nameClick(t, parentTitle) {
      console.log(t, parentTitle);
      if (t == undefined) {
        this.titleClick(parentTitle);
      }
      switch (t) {
        // 个人信息管理
        case "baseInfo":
          this.$router.push({
            path: "/personalInfo/baseInfo"
          });
          break;
        case "stuChange":
          // this.$router.push({
          //   path: "/personalInfo/stuChange/1"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "cardReapply":
          // this.$router.push({
          //   path: "/personalInfo/cardReapply/1"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "suoboApply":
          // this.$router.push({
          //   path: "/personalInfo/suoboApply/1"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "changeTutor":
          // this.$router.push({
          //   path: "/personalInfo/changeTutor/1"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "onlineRegister":
          // this.$router.push({
          //   name: "/onlineRegister"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        // 教学培养
        case "personalPlan":
          this.$router.push({
            path: "/teachTrain/personalPlan/1"
          });
          break;
        case "onlineSelection":
          this.$router.push({
            path: "/teachTrain/onlineSelection/1"
          });
          break;
        case "exemptionRebuild":
          // this.$router.push({
          //   path: "/teachTrain/exemptionRebuild/1"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "onlineEvalution":
          this.$router.push({
            path: "/teachTrain/onlineEvalution/1"
          });
          break;
        case "personalTimetable":
          this.$router.push({
            path: "/teachTrain/personalTimetable/1"
          });
          break;
        case "personalTranscript":
          this.$router.push({
            path: "/teachTrain/personalTranscript/1"
          });
          break;
        case "applyCET":
          this.$router.push({
            path: "/teachTrain/applyCET/1"
          });
          break;
        // 教育建设项目
        case "projectReport":
          // this.$router.push({
          //   path: "/jiansheProject/projectReport"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "myProject":
          // this.$router.push({
          //   path: "/jiansheProject/myProject"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "conclusionApply":
          // this.$router.push({
          //   path: "/jiansheProject/conclusionApply"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        // 学术成果
        case "achieveInput":
          // this.$router.push({
          //   path: "/academicAchieve/achieveInput/1"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        case "achieveQuery":
          // this.$router.push({
          //   path: "/academicAchieve/achieveQuery/2"
          // });
          this.$message.warning("该模块暂未开放,敬请期待!");
          break;
        // 学位申请
        case "academicDegreePaperFinal":
          this.$router.push({
            path: "/academicDegree/academicDegreePaperFinal"
          });
          break;
        case "degreeAnwserPaper":
          this.$router.push({
            path: "/academicDegree/degreeAnwserPaper"
          });
          break;
        case "academicDegreePaperUpload":
          this.$router.push({
            path: "/academicDegree/academicDegreePaperUpload"
          });
          break;
      }
    },
    // 鼠标移入事件
    enter() {
      this.enterShow = true;
    },
    // 鼠标移出事件
    leave() {
      this.enterShow = false;
    },
    mouseover() {
      // console.log(this.$refs.mouseover);
      this.isActivated = true;
    },
    // 跳转到通知公告列表页面
    goToNotice() {
      this.tzggShowMore = true;
      this.$router.push({
        path: "/noticeList"
      });
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    currentRoleId() {
      return this.$store.getters.getcurrentRoleId;
    }
  },
  destroyed() {
    this.endTimeOut();
  }
};
</script>

<style lang="scss" scoped>
.main-index {
  display: flex;
  margin-top: 25px;
  padding: 0px 10%;
  // overflow: hidden;
  height: 100%;
  color: #333;
  // .content-left {
  //   flex: 1;
  //   margin-left: 30px;
  // }
  // .content-right {
  //   flex: 0.6;
  // }
}
.active {
  &:hover {
    color: #409eff;
  }
  &:visited {
    color: #409eff;
  }
  &:focus {
    color: #409eff;
  }
}
.isActive {
  color: #409eff;
}
.content {
  min-width: 1440px;
  background-color: #f5f5f5;
  min-height: 100%;
  .linkHover {
    .triangle {
      border-width: 10px;
      border-style: solid;
      border-color: transparent transparent rgba(170, 215, 255, 0.8);
      position: absolute;
      top: -20px;
      left: 44px;
    }
    position: absolute;
    left: 150px;
    top: 133px;
    background-color: rgba(170, 215, 255, 0.8);
    ul {
      list-style: none;
      padding: 0;
      margin: 0;
      li {
        cursor: pointer;
        margin: 10px;
        color: #1890ff;
        font-size: 14px;
        .activated {
          color: #fff !important;
        }
        .linkActive {
          color: #fff;
        }
      }
    }
  }

  .view-box {
    height: calc(100vh - 80px - 60px);
    padding: 0 10% 20px;
    box-sizing: border-box;
    overflow: hidden;
  }
  .content-left {
    width: calc(60% - 20px);
    margin-left: 20px;
    // margin-left: 30px;
    display: flex;
    flex-wrap: wrap;
    .item-box {
      cursor: pointer;
      transition: 0.7s;
      &:hover {
        transform: scale(1.06);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2), 0 0px 6px rgba(0, 0, 0, 0.1);
      }
      // cursor: move;
      width: 47%;
      height: 184px;
      margin-right: 3%;
      margin-bottom: 25px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
      // overflow: hidden;
      display: flex;
      .box-img {
        float: left;
        padding: 10px 20px;
        img {
          width: 48px;
        }
      }
      .box-content {
        width: 100%;
        // float: right;
        .box-title {
          margin-top: 30px;
          h4 {
            cursor: pointer;
          }
        }
        .box-main {
          width: 100%;
          margin-top: 14px;
          span {
            display: inline-block;
            width: 50%;
            color: #666666;
            font-size: 13px;
            line-height: 22px;
            cursor: pointer;
            &:hover {
              color: #409eff;
            }
          }
        }
      }
    }
  }
  .content-right {
    width: calc(40% - 20px);
    margin-right: 20px;
    // padding: 0 0 0 35px;
    .box-right {
      width: 100%;
      position: relative;
      margin-bottom: 25px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
      height: 393px;
      overflow: hidden;
      box-sizing: border-box;
      .header {
        display: flex;
        padding: 12px 25px 12px 20px;
        h3 {
          margin: 0;
          flex: 2;
        }
        img {
          width: 22px;
          height: 22px;
          margin-right: 5px;
        }
        .el-button {
          padding: 0;
        }
      }
      .el-divider--horizontal {
        margin: 0;
      }
      .main-tzgg {
        position: relative;
        height: calc(100% - 50px);
        ul {
          padding: 10px 20px;
          height: 93%;
          overflow: hidden;
          // list-style: none;
          li {
            display: flex;
            line-height: 40px;
            // display: flex;
            // justify-content: space-between;
            span {
              font-size: 14px;
              flex: 4;
            }
            .el-button {
              flex: 0.5;
              font-size: 15px;
              margin-right: 20px;
            }
          }
        }
      }
      .main-dbsx {
        ul {
          padding: 10px 20px;
        }
        li {
          display: flex;
          line-height: 40px;
          span {
            font-size: 14px;
            &:nth-child(1) {
              font-weight: bold;
              flex: 1.8;
              padding-right: 20px;
            }
            &:nth-child(3) {
              flex: 1.4;
            }
          }
          .el-progress {
            flex: 2;
            line-height: 42px;
          }
          .el-button {
            flex: 0.5;
            font-size: 15px;
            margin-left: 0;
            margin-right: 20px;
          }
        }
      }
    }
  }
}
.timeShow {
  font-size: 10px !important;
  text-align: right;
  color: #666;
  padding-left: 20px;
}
/deep/ .el-progress--without-text .el-progress-bar {
  display: inline-block;
}
//查看更多样式
.overAuto {
  overflow: auto;
  height: 315px;
}
.tzggShowMore {
  color: #1890ff;
  font-size: 14px;
  border: none;
  outline: none;
  &:hover {
    background: #fff;
  }
}
</style>
