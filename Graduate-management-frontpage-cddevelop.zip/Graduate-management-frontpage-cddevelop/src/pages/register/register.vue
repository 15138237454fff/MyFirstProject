<template>
  <!-- 注册页面 -->
  <div :style="app" v-if="flag == true">
    <my-blank msg="还没到注册时间哦！" picUrl="blank.png"></my-blank>
  </div>
  <div :style="app" class="main" v-else>
    <div>
      <h1>请完成入学注册</h1>
      <div class="box">
        <div>
          <h3>
            当前学期:
            <span>{{ dqxq }}</span>
          </h3>
          <div class="avator">
            <img src="../../assets/images/avator.png" alt />
            <div class="red">
              <div class="text">未注册</div>
            </div>
          </div>
          <div class="main-right">
            <ul>
              <li>
                姓名：
                <span>{{ userInfo.name }}</span>
              </li>
              <li>
                学院：
                <span>{{ userInfo.xh }}</span>
              </li>
              <li>
                专业：
                <span>{{ userInfo.zy }}</span>
              </li>
              <li>
                学号：
                <span>{{ userInfo.xh }}</span>
              </li>
              <li>
                年级：
                <span>{{ userInfo.nj }}</span>
              </li>
            </ul>
          </div>
          <el-button type="primary" @click="registerClick">在线注册</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import blank from "@/components/blank";
export default {
  name: "Register",
  components: {
    "my-blank": blank
  },
  data() {
    return {
      flag: true,
      app: {
        backgroundImage: "url(" + require("../../assets/images/cdbg.png") + ")",
        backgroundRepeat: "no-repeat",
        backgroundSize: "100% 100%"
      },
      dqxq: "2019年上半学期",
      userInfo: {
        name: "申请人姓名",
        xy: "所在学院",
        zy: "专业名称",
        xh: "2010203232",
        nj: "2018级"
      },
      user: {
        name: "申请人姓名",
        xy: "所在学院",
        zy: "专业名称",
        xh: "2010203232",
        nj: "2018级"
      }
    };
  },
  mounted() {
    this.getData();
    this.kqgb();
  },
  methods: {
    kqgb() {
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=lszc")
        .then(res => {
          if (res.data.data.isOpen == 1) {
            this.flag = false;
          } else {
            this.flag = true;
          }
        });
    },
    registerClick() {
      this.$http.put("/api/frontpage/lszc/" + this.xh).then(res => {
        if (res.data.code === 200) {
          this.$router.push({
            path: "/"
          });
        }
      });
    },
    // 获取基本信息
    getData() {
      this.$http.get("/api/frontpage/lszc/" + this.xh).then(res => {
        console.log(res.data.data);
        this.userInfo = res.data.data;
      });
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  h1 {
    color: #fff;
    text-align: center;
  }
  .box {
    padding: 20px 80px;
    box-sizing: border-box;
    border-radius: 8px;
    min-width: 500px;
    height: 300px;
    // opacity: 0.4;
    background-color: rgba(255, 255, 255, 0.4);
    overflow: hidden;
    .avator {
      width: 130px;
      height: 130px;
      background: #fff;
      float: left;
      margin-right: -40px;
      overflow: hidden;
      position: relative;
      img {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
      .red {
        width: 100px;
        height: 70px;
        background-color: #f56c6c;
        transform: translateY(100px) skew(30deg);
        .text {
          color: #fff;
          font-size: 13px;
          text-align: center;
          transform: translateY(5px) skew(-30deg);
        }
      }
    }
    .main-right {
      float: right;
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        li {
          padding-bottom: 5px;
        }
      }
    }
    .el-button {
      margin-top: 20px;
      width: 100%;
    }
  }
}
</style>
