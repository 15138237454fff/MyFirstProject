<template>
  <div class="conclusionApplyAdd">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>教育建设项目</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/jiansheProject/conclusionApply' }"
            >结题申请</el-breadcrumb-item
          >
          <el-breadcrumb-item>结题申请详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="$router.go(-1)"
          plain
          size="small"
          icon="el-icon-d-arrow-left"
          >返回</el-button
        >
        <el-button type="primary" @click="clickSubmit" size="small"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <conclusion-add-tydcjjxm
        v-if="type === '4'"
        :xmId="id"
        :lcid="lcid"
        ref="add"
      ></conclusion-add-tydcjjxm>
      <conclusion-add-xjyjskyxm
        v-if="type === '5'"
        :xmId="id"
        :lcid="lcid"
        ref="add"
      ></conclusion-add-xjyjskyxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import conclusionAddForTYDCJJXM from "@/components/jiansheProject/add/conclusionAddForTYDCJJXM";
import conclusionAddForXJYJSKYXM from "@/components/jiansheProject/add/conclusionAddForXJYJSKYXM";
export default {
  name: "conclusionApplyAdd",
  props: {
    type: {
      type: String
    },
    id: {},
    lcid: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "conclusion-add-tydcjjxm": conclusionAddForTYDCJJXM,
    "conclusion-add-xjyjskyxm": conclusionAddForXJYJSKYXM
  },
  methods: {
    clickSubmit() {
      // 调用子组件的提交方法
      this.$refs.add.handleSubmit();
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionApplyAdd {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
  }
}
</style>
