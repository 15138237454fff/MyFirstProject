<template>
  <div class="myProjectDetail">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>教育建设项目</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/jiansheProject/conclusionApply' }"
            >结题申请</el-breadcrumb-item
          >
          <el-breadcrumb-item>申报详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="$router.go(-1)"
          plain
          size="small"
          icon="el-icon-d-arrow-left"
          >返回</el-button
        >
      </div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <project-detail-tydcjjxm v-if="type === '4'"></project-detail-tydcjjxm>
      <project-detail-xjyjskyxm v-if="type === '5'"></project-detail-xjyjskyxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import projectDetailForTYDCJJXM from "@/components/jiansheProject/detail/projectDetailForTYDCJJXM";
import projectDetailForXJYJSKYXM from "@/components/jiansheProject/detail/projectDetailForXJYJSKYXM";
export default {
  name: "myProjectDetail",
  props: {
    type: {
      type: String
    },
    id: {
      type: String
    }
  },
  data() {
    return {
      loading: false,
      updatePathForTYDCJJXM: "jiansheProject/updateFormDataForTYDCJJXM",
      updatePathForXJYJSKYXM: "jiansheProject/updateFormDataForXJYJSKYXM",
      updatePathForZXZJSHDYXM: "jiansheProject/updateFormDataForZXZJSHDYXM",
      detailPathForTYDCJJXM: "fieldwork",
      detailPathForXJYJSKYXM: "university",
      detailPathForZXZJSHDYXM: "social"
    };
  },
  mounted() {
    this.dataCallBack();
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "4":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "5":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
          return;
        case "6":
          this.requirePorjectDetail(
            this.detailPathForZXZJSHDYXM,
            this.updatePathForZXZJSHDYXM
          );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    }
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-detail-tydcjjxm": projectDetailForTYDCJJXM,
    "project-detail-xjyjskyxm": projectDetailForXJYJSKYXM
  }
};
</script>
<style lang="scss" scoped>
.myProjectDetail {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
    position: relative;
  }
}
</style>
