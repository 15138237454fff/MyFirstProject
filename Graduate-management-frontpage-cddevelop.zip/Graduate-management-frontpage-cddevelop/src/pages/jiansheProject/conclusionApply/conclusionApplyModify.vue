<template>
  <div class="conclusionApplyAdd">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>教育建设项目</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/jiansheProject/conclusionApply' }"
            >结题申请</el-breadcrumb-item
          >
          <el-breadcrumb-item>结题申请详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="$router.go(-1)"
          plain
          size="small"
          icon="el-icon-d-arrow-left"
          >返回</el-button
        >
        <el-button type="primary" @click="clickSubmit" size="small"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loading"
      element-loading-text="拼命加载中"
    >
      <table-flag :status="projectStatus"></table-flag>
      <conclusion-add-tydcjjxm
        v-if="type === '4'"
        ref="add"
        :lcid="id"
      ></conclusion-add-tydcjjxm>
      <conclusion-add-xjyjskyxm
        v-if="type === '5'"
        ref="add"
        :lcid="id"
      ></conclusion-add-xjyjskyxm>
      <apply-status-bottom v-bind="aduit"></apply-status-bottom>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import tableFlag from "@/components/common/tableFlag";
import applyStatusBottom from "@/components/common/applyStatusBottom";
import conclusionAddForTYDCJJXM from "@/components/jiansheProject/add/conclusionAddForTYDCJJXM";
import conclusionAddForXJYJSKYXM from "@/components/jiansheProject/add/conclusionAddForXJYJSKYXM";
export default {
  name: "conclusionApplyAdd",
  props: {
    type: {
      type: String
    },
    id: {},
    projectStatus: {},
    jtId: {}
  },
  data() {
    return {
      aduit: {
        status: null,
        name: "",
        endTime: "",
        comment: "",
        assignee: ""
      },
      loading: false,
      updatePathForTYDCJJXM:
        "jiansheProject/updateFormDataIsConclusionForTYDCJJXM",
      detailPathForTYDCJJXM: "fieldworkTask",
      updatePathForXJYJSKYXM:
        "jiansheProject/updateFormDataIsConclusionForXJYJSKYXM",
      detailPathForXJYJSKYXM: "universityTask"
    };
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "table-flag": tableFlag,
    "apply-status-bottom": applyStatusBottom,
    "conclusion-add-tydcjjxm": conclusionAddForTYDCJJXM,
    "conclusion-add-xjyjskyxm": conclusionAddForXJYJSKYXM
  },
  mounted() {
    this.dataCallBack();
    if (this.projectStatus === 0) {
      this.requireAduitDetail();
    }
  },
  methods: {
    dataCallBack() {
      switch (this.type) {
        case "4":
          this.requirePorjectDetail(
            this.detailPathForTYDCJJXM,
            this.updatePathForTYDCJJXM
          );
          return;
        case "5":
          this.requirePorjectDetail(
            this.detailPathForXJYJSKYXM,
            this.updatePathForXJYJSKYXM
          );
        // return;
        // case "3":
        //   this.requirePorjectDetail(
        //     this.detailPathForKCALKJSXM,
        //     this.updatePathForKCALKJSXM
        //   );
      }
    },
    // 请求项目详情
    requirePorjectDetail(detailPath, updatePath) {
      this.loading = true;
      this.$http
        .get(`/api/education/${detailPath}/${this.id}`)
        .then(res => {
          let data = res.data;
          this.loading = false;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!data.data) {
            console.log("申请详情数据获取失败");
            return;
          }
          console.log(updatePath);
          this.$store.commit(updatePath, data.data);
        })
        .catch(err => {
          console.log(err.message);
          this.loading = false;
        });
    },
    // 请求审核历史记录
    requireAduitDetail() {
      this.$http
        .get(`/api/education/process/history/${this.jtId}`)
        .then(res => {
          let data = res.data;
          if (data.code !== 200) {
            this.$message.error(data.message);
            return;
          }
          if (!Array.isArray(data.data)) {
            console.log("审核历史记录数据获取失败");
            return;
          }
          Object.keys(this.aduit).forEach(key => {
            this.aduit[key] = data.data[data.data.length - 1][key];
          });
          this.aduit.status = data.data.state;
          console.log(this.aduit);
        });
    },
    clickSubmit() {
      // 调用子组件的提交方法
      this.$refs.add.handleUpdate(this.jtId);
    }
  }
};
</script>
<style lang="scss" scoped>
.conclusionApplyAdd {
  .box {
    position: relative;
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
  }
}
</style>
