<template>
  <div class="projectReport">
    <unopen/>
  </div>
</template>

<script>
import unopen from '@/components/unopen'
export default {
  name: "projectReport",
  data() {
    return {}
  },
  components: {
    unopen
  },
};
</script>

<style lang="scss" scoped>
.projectReport {
 width: 100%;
 height: 100%;
}
</style>
