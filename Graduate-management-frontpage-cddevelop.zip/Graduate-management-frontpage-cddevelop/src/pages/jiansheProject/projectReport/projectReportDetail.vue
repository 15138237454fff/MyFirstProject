<template>
  <div class="projectReportDetail">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>教育建设项目</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/jiansheProject/projectReport' }"
            >项目申报</el-breadcrumb-item
          >
          <el-breadcrumb-item>申报详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button
          type="primary"
          @click="$router.go(-1)"
          plain
          size="small"
          icon="el-icon-d-arrow-left"
          >返回</el-button
        >
        <el-button type="primary" @click="clickSubmit" size="small"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <project-add-tydcjjxm
        v-if="type === '4'"
        :xmId="id"
        ref="add"
      ></project-add-tydcjjxm>
      <project-add-xjyjskyxm
        v-if="type === '5'"
        :xmId="id"
        ref="add"
      ></project-add-xjyjskyxm>
      <project-add-zxzjshdyxm
        v-if="type === '6'"
        :xmId="id"
        ref="add"
      ></project-add-zxzjshdyxm>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
import projectAddForTYDCJJXM from "@/components/jiansheProject/add/projectAddForTYDCJJXM";
import projectAddForXJYJSKYXM from "@/components/jiansheProject/add/projectAddForXJYJSKYXM";
import projectAddForZXZJSHDYXM from "@/components/jiansheProject/add/projectAddForZXZJSHDYXM";
export default {
  name: "projectReportDetail",
  props: {
    type: {
      type: String
    },
    id: {}
  },
  components: {
    "my-breadcrumb": myBreadcrumb,
    "project-add-tydcjjxm": projectAddForTYDCJJXM,
    "project-add-xjyjskyxm": projectAddForXJYJSKYXM,
    "project-add-zxzjshdyxm": projectAddForZXZJSHDYXM
  },
  methods: {
    clickSubmit() {
      // 调用子组件的提交方法
      this.$refs.add.handleSubmit();
    }
  }
};
</script>
<style lang="scss" scoped>
.projectReportDetail {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 20px;
    height: calc(100vh - 256px);
    overflow: auto;
  }
}
</style>
