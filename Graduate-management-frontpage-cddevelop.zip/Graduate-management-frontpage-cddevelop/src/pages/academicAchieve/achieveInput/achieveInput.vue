<template>
  <div class="achieveInput">
    <unopen/>
  </div>
</template>

<script>
import unopen from '@/components/unopen'
export default {
  name: "achieveInput",
  data() {
    return {}
  },
  components: {
    unopen
  },
};
</script>

<style lang="scss" scoped>
.achieveInput {
 width: 100%;
 height: 100%;
}
</style>
