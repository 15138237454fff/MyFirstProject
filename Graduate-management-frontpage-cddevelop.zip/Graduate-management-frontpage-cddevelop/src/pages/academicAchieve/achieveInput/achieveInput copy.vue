<template>
  <div>
    <!-- 学术成果录入 achieveInput -->
    <div class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/academicAchieve/achieveInput/1' }">学术成果</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/academicAchieve/achieveInput/1' }">学术成果录入</el-breadcrumb-item>
            <el-breadcrumb-item v-if="id == 2">申请记录</el-breadcrumb-item>
            <el-breadcrumb-item v-if="id == 3">查看详情</el-breadcrumb-item>
            <el-breadcrumb-item v-if="id == 4">修改</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right">
          <div v-show="id === '1'">
            <i class="el-icon-document"></i>
            <el-button type="text" @click="seeRecord">
              <el-badge is-dot class="item">查看申请记录</el-badge>
            </el-button>
          </div>
          <div v-show="id !== '1'">
            <i class="el-icon-d-arrow-left"></i>
            <el-button type="text" @click="handleBack">返回</el-button>
          </div>
        </div>
      </my-breadcrumb>
      <!-- 提交审核申请 -->
      <div class="box change" v-if="id === '1'">
        <div>
          <!-- 学术申请 -->
          <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="学术论文" name="xslw">
              <xslw v-if="activeName === 'xslw'" :id="id"></xslw>
            </el-tab-pane>
            <el-tab-pane label="技术专利" name="jszl">
              <jszl v-if="activeName === 'jszl'" :id="id"></jszl>
            </el-tab-pane>
            <el-tab-pane label="发表著作" name="fbzz">
              <fbzz v-if="activeName === 'fbzz'" :id="id"></fbzz>
            </el-tab-pane>
            <el-tab-pane label="科研项目" name="kyxm">
              <kyxm v-if="activeName === 'kyxm'" :id="id"></kyxm>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
      <!-- 审核列表页面 -->
      <div class="aduit-list box" v-if="id === '2'">
        <achieve-record></achieve-record>
      </div>
      <!-- 审核详情进度 -->
      <div v-if="id === '3' || id === '4'" class="box">
        <xslw v-if="resultsType === '1'" :id="id" :executionId="executionId"></xslw>
        <jszl v-if="resultsType === '2'" :id="id" :executionId="executionId"></jszl>
        <fbzz v-if="resultsType === '3'" :id="id" :executionId="executionId"></fbzz>
        <kyxm v-if="resultsType === '4'" :id="id" :executionId="executionId"></kyxm>
        <apply-status-bottom></apply-status-bottom>
      </div>
    </div>
  </div>
</template>

<script>
import kyxm from "./components/kyxm";
import fbzz from "./components/fbzz";
import jszl from "./components/jszl";
import xslw from "./components/xslw";
import achieveRecord from "./components/achieveRecord";
import applyStatusBottom from "../../../components/applyStatusBottom";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "achieveInput",
  props: {
    id: {},
    executionId: {}
  },
  components: {
    kyxm,
    fbzz,
    jszl,
    xslw,
    applyStatusBottom,
    achieveRecord,
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      // 当前选中的tab页面
      activeName: "xslw",
      // 详情页的类型
      resultsType: ""
    };
  },
  methods: {
    // 查看申请记录
    seeRecord() {
      this.applyShow = false;
      this.$router.push({
        path: "/academicAchieve/achieveInput/2"
      });
    },
    // 新建申请(返回)
    handleBack() {
      this.$router.go(-1);
    },
    // tab页面切换
    handleClick(tab) {
      this.activeName = tab.name;
    },
    detailStatus() {
      if (this.id === "3" || this.id === "4") {
        this.resultsType = this.$route.query.resultsType;
        // 如果进入查看/修改详情页面，请求对应流程id的审核状态
        this.$http
          .get("/api/academic/aac/" + this.$route.params.executionId)
          .then(res => {
            let data = res.data.data;
            if (!Array.isArray(data)) {
              this.$message.error("获取审核具体流程数据失败，请刷新重试");
              return;
            }
            // 将审核具体流程数据发送给applyStatus
            this.$bus.$emit("stepList", data);
          });
      }
    }
  },
  created() {
    this.detailStatus();
  },
  watch: {
    $route(to) {
      if (to.name === "achieveInput") this.detailStatus();
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  .el-icon-document,
  .el-icon-d-arrow-left {
    margin-right: 5px;
    color: #409eff;
  }
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    padding-top: 0;
    /deep/ .el-tabs__item {
      width: 25% !important;
    }
    height: calc(100vh - 220px);
    overflow: auto;
    /deep/ .el-tabs__item {
      width: 25% !important;
      text-align: center;
    }
    /deep/ .el-tabs__nav {
      width: 100%;
      height: $student-tab-height;
      line-height: $student-tab-height;
    }
  }
}

/deep/ .table-box {
  font-size: 14px;
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    thead > th {
      text-align: center;
      font-size: 20px;
      padding: 10px;
      line-height: 40px;
      overflow: hidden;
    }
    tbody > th {
      text-align: left;
      font-weight: 700;
      padding: 11px 2px 11px 10px;
      span {
        color: #1890ff;
      }
    }
    td {
      width: 200px;
      height: 40px;
      &:nth-child(odd) {
        background: #f2f2f2;
        padding-left: 10px;
      }
      &:nth-child(even) {
        text-align: center;
        
      }
      a{
        display: inline-block;
        width:100%;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .range /deep/ .el-input {
        width: 25%;
      }
      .kh,
      .khdm {
        display: inline-block;
      }
      .kh {
        width: 45%;
        margin-right: 5px;
      }
      .khdm {
        width: 50%;
      }
      .qklb {
        width: 100%;
      }
      &.contentTd {
        background: #fff;
        padding: 0 10px;
        text-align: center;
      }
      .add,
      .reduce {
        font-size: 24px;
        color: #1e6fd9;
        border-radius: 50%;
        padding-left: 20px;
        background: #fff;
        outline: none;
        border: none;
      }
      .reduce {
        color: $red;
      }
      /deep/ .el-textarea__inner {
        font-size: 14px;
        color: #333;
      }
    }
  }
  .tx-msg {
    line-height: 30px;
    color: #ff5a5a;
  }
  .submitBtn {
    text-align: right;
  }
  [type="textarea"] {
    resize: none;
  }
}
</style>
