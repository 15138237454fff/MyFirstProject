<template>
  <div>
    <!-- 科研项目申请表 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              :table-title="achieveTitle"
              :status="$route.matched[1].name === 'achieveInput' && id != 1? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6">
            <span>|</span> 个人信息
          </th>
          <tr>
            <td>姓名</td>
            <td>{{author.xsxm}}</td>
            <td>学号</td>
            <td>{{author.xh}}</td>
            <td>所属学院</td>
            <td>{{author.ssyxmc}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 关键信息
          </th>
          <tr>
            <td :class=" writeable ? 'required' : '' ">项目名称</td>
            <td colspan="5">
              <el-input type="text" v-model="kyxmForm.xmmc" placeholder="请输入项目名称" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.xmmc}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">项目类型</td>
            <td>
              <div>
                <el-select v-model="kyxmForm.xmlx" v-if="writeable" style="width:100%;">
                  <el-option
                    :label="item.title"
                    :value="item.title"
                    v-for="(item,index) of xmList"
                    :key="index"
                  ></el-option>
                </el-select>
                <span v-else>{{kyxmForm.xmlx}}</span>
              </div>
            </td>
            <td :class=" writeable ? 'required' : '' ">项目具体类型</td>
            <td>
              <div>
                <el-select v-model="kyxmForm.xmjtlx" v-if="writeable" style="width:100%;">
                  <el-option
                    :label="item.title"
                    :value="item.title"
                    v-for="(item,index) of xmjtList"
                    :key="index"
                  ></el-option>
                </el-select>
                <span v-else>{{kyxmForm.xmjtlx}}</span>
              </div>
            </td>
            <td :class=" writeable ? 'required' : '' ">项目来源</td>
            <td>
              <div>
                <el-select v-model="kyxmForm.xmly" v-if="writeable" style="width:100%;">
                  <el-option
                    :label="item.title"
                    :value="item.title"
                    v-for="(item,index) of xmlyList"
                    :key="index"
                  ></el-option>
                </el-select>
                <span v-else>{{kyxmForm.xmly}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">项目编号</td>
            <td>
              <el-input v-model="kyxmForm.xmbh" placeholder="请输入项目编号" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.xmbh}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">是否是第一作者</td>
            <td>
              <div v-if="writeable">
                <el-radio v-model="kyxmForm.sfdyzz" :label="true">是</el-radio>
                <el-radio v-model="kyxmForm.sfdyzz" :label="false">否</el-radio>
              </div>
              <span v-else>{{kyxmForm.sfdyzz?'是':'否'}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">导师是否是第一作者</td>
            <td>
              <div v-if="writeable">
                <el-radio
                  v-model="kyxmForm.dsdyzz"
                  :label="true"
                  :disabled="kyxmForm.sfdyzz === true"
                >是</el-radio>
                <el-radio
                  v-model="kyxmForm.dsdyzz"
                  :label="false"
                  :disabled="kyxmForm.sfdyzz === true"
                >否</el-radio>
              </div>
              <span v-else>{{kyxmForm.dsdyzz? '是' : '否'}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">本人排名/总数</td>
            <td>
              <div class="range" v-if="writeable">
                <el-input v-model="kyxmForm.brpm" type="number"></el-input>&nbsp;&nbsp;/&nbsp;&nbsp;
                <el-input v-model="kyxmForm.zzzrs" type="number" v-if="writeable"></el-input>
              </div>
              <div v-else>
                <span>{{kyxmForm.brpm}}</span>&nbsp;&nbsp;/&nbsp;&nbsp;
                <span>{{kyxmForm.zzzrs}}</span>
              </div>
            </td>
            <td :class=" writeable ? 'required' : '' ">学生参与类别</td>
            <td>
              <div>
                <el-select v-model="kyxmForm.xscylb" v-if="writeable" style="width:100%;">
                  <el-option
                    :label="item.name"
                    :value="item.name"
                    v-for="(item,index) of cylbList"
                    :key="index"
                  ></el-option>
                </el-select>
                <span v-else>{{kyxmForm.xscylb}}</span>
              </div>
            </td>
            <td :class=" writeable ? 'required' : '' ">导师参与类别</td>
            <td>
              <div>
                <el-select v-model="kyxmForm.dscylb" v-if="writeable" style="width:100%;">
                  <el-option
                    :label="item.name"
                    :value="item.name"
                    v-for="(item,index) of cylbList"
                    :key="index"
                  ></el-option>
                </el-select>
                <span v-else>{{kyxmForm.dscylb}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">项目经费</td>
            <td>
              <el-input type="number" placeholder="请输入项目经费" v-model="kyxmForm.xmjf" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.xmjf}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">项目开始时间</td>
            <td>
              <el-date-picker
                v-if="writeable"
                v-model="kyxmForm.xmkssj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%;"
              ></el-date-picker>
              <span v-else>{{kyxmForm.xmkssj|toYMD}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">项目结束时间</td>
            <td>
              <el-date-picker
                v-if="writeable"
                v-model="kyxmForm.xmjssj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%;"
              ></el-date-picker>
              <span v-else>{{kyxmForm.xmjssj|toYMD}}</span>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 项目详细信息
          </th>
          <tr>
            <td class>中文关键字</td>
            <td class colspan="2">
              <el-input type="text" v-model="kyxmForm.zwgjz" placeholder="请输入" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.zwgjz}}</span>
            </td>
            <td class>英文关键字</td>
            <td class colspan="2">
              <el-input type="text" v-model="kyxmForm.ywgjz" placeholder="请输入" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.ywgjz}}</span>
            </td>
          </tr>
          <tr>
            <td class>中文摘要</td>
            <td class colspan="2">
              <el-input type="text" v-model="kyxmForm.zwzy" placeholder="请输入" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.zwzy}}</span>
            </td>
            <td class>英文摘要</td>
            <td class colspan="2">
              <el-input type="text" v-model="kyxmForm.ywzy" placeholder="请输入" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.ywzy}}</span>
            </td>
          </tr>
          <tr>
            <td class>网络收录地址</td>
            <td class colspan="5">
              <el-input type="text" v-model="kyxmForm.wlsldz" placeholder="请输入" v-if="writeable"></el-input>
              <span v-else>{{kyxmForm.wlsldz}}</span>
            </td>
          </tr>
          <tr>
            <td>附件</td>
            <td>
              <div v-if="writeable">
                <el-upload
                  class="upload-demo"
                  action="/api/system/upload"
                  multiple
                  :limit="1"
                  :on-success="receiveFJ"
                  :on-remove="removeFJ"
                  ref="upload"
                  :headers="headers"
                >
                  <el-button size="large" type="primary" :plain="true" style="padding:10px 60px 10px 60px;">点击上传附件</el-button>
                </el-upload>
              </div>
              <div v-else>
                <a
                  :href="kyxmForm.fj.url"
                  target="_blank"
                  class="primary"
                  :download="kyxmForm.fj.fileName"
                >{{kyxmForm.fj.fileName}}</a>
              </div>
            </td>
            <td class="contentTd"></td>
            <td></td>
            <td class="contentTd"></td>
            <td></td>
          </tr>
        </tbody>
      </table>
      <span class="tx-msg" v-if="userStatus == 1">注：{{txMsg}}</span>
      <div class="submitBtn">
        <el-button type="primary" @click="handleSubmit" v-if="id === '1'">提交请求</el-button>
        <!-- <el-button type="default" @click="resetForm" v-if="id==='4'">重置</el-button> -->
        <el-button type="primary" @click="handleSubmit" v-if="id==='4'">重新提交</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "kyxm",
  props: {
    id: {},
    executionId: {}
  },
  components: {
    tableFlag
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      kyxmForm: {
        brpm: "", // 本人排名
        dscylb: "", // 导师参与类别
        dsdyzz: "", // 导师是否第一作者
        fj: {}, // 附件
        sfdyzz: "", // 是否第一作者
        wlsldz: "", // 网络收录地址
        xmbh: "", // 项目编号
        xmjf: "", // 项目经费
        xmjssj: "", // 项目结束时间
        xmjtlx: "", // 项目具体类型
        xmkssj: "", // 项目开始时间
        xmlx: "", // 项目类型
        xmly: "", // 项目来源
        xmmc: "", // 项目名称
        xscylb: "", // 学生参与类别
        ywgjz: "", // 英文关键字
        ywzy: "", // 英文摘要
        zwgjz: "", // 中文关键字
        zwzy: "", // 中文摘要
        zzzrs: "" // 作者总人数
      },
      // 作者信息
      author: {
        ssyxmc: "", // 学院名称
        xh: "", // 学号
        xsxm: "" // 学生姓名
      },
      txMsg: "", // 提醒消息
      cylbList: [], // 参与类别列表
      xmList: [], // 项目类型列表
      xmjtList: [], // 项目具体类型列表
      xmlyList: [], // 项目来源列表
      achieveTitle: "浙江财经大学研究生科研项目申请表",
      writeable: false, // 表单是否可以更改
      status: null
    };
  },
  mounted() {
    // 确认是否可以写入数据
    this.confirmWrite();
    // 当前参数为提醒
    if (this.userStatus == 1) {
      // 请求学生(作者)信息
      this.requireAuthor();
      this.$http.get("/api/academic/apc/serve/" + "XS-33674").then(result => {
        this.txMsg = result.data.data;
      });
    }
    // 如果可写
    if (this.writeable) {
      // 当前参数为参与类别
      this.getTX("XS-07054").then(data => {
        this.cylbList = data;
      });
      // 当前参数为项目类型-具体类型-项目来源
      this.getTX("XS-20226").then(data => {
        this.xmList = data;
      });
    }
  },
  methods: {
    // 获取提示信息的方法
    getTX(id) {
      return new Promise(resolve => {
        this.$http.get("/api/academic/apc/serve/" + id).then(result => {
          let data = result.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("未获取的参数详情");
            return false;
          }
          resolve(data);
        });
      });
    },
    // 接收的上传名称和地址
    receiveFJ(res) {
      this.kyxmForm.fj = res.data;
    },
    // 文件移除时清空附件
    removeFJ() {
      this.kyxmForm.fj = { url: "", fileName: "" };
    },
    // 点击提交按钮
    handleSubmit() {
      this.$store.commit("updateDialog", {
        visible: true,
        successCallback: this.submit
      });
    },
    // 提交项目
    submit() {
      this.$store.commit("updateDialog", { visible: false });
      // 必填的属性名
      let requiredArr = [
        "xmmc",
        "xmlx",
        "xmjtlx",
        "xmly",
        "xmbh",
        "sfdyzz",
        "dsdyzz",
        "brpm",
        "zzzrs",
        "xscylb",
        "dscylb",
        "xmjf",
        "xmkssj",
        "xmjssj"
      ];
      let test = true;
      requiredArr.forEach(key => {
        if (this.kyxmForm[key] === "") {
          test = false;
        }
      });
      // 验证成功
      if (test) {
        const kyxmLoading = this.$loading({target:document.querySelector('.table-box')})
        // 如果流程id为空，即第一次提交申请
        if (!this.executionId) {
          // 发送请求申请科研项目
          this.$http.post("/api/academic/rpc", this.kyxmForm).then(res => {
            kyxmLoading.close()
            if (res.data.code === 200) {
              this.$message.success("申请成功");
              this.resetForm();
            } else {
              this.$message.error(res.data.message);
            }
          });
        } else {
          // 发送请求修改科研项目
          this.$http
            .put("/api/academic/rpc/" + this.executionId, this.kyxmForm)
            .then(res => {
              kyxmLoading.close()
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
      // 验证失败
      else {
        this.$message.warning("请填写完整后再尝试提交论文");
      }
    },
    // 数据回显
    dataBack() {
      this.$http.get(`/api/academic/rpc/${this.executionId}`).then(res => {
        let data = res.data.data;
        console.log(data);
        // 数据非空验证
        if (!data) {
          this.$message.error("历史申请详情数据获取失败，请重试");
          return;
        }
        // 保存回显的申请表单值
        Object.keys(this.kyxmForm).forEach(key => {
          this.kyxmForm[key] = data[key];
        });
        // 如果非学生
        if (this.userStatus != 1) {
          // 取出回显数据中的学生信息
          this.author.ssyxmc = data.xymc; // 学院名称
          this.author.xh = data.xh; // 学号
          this.author.xsxm = data.xsxm; // 学生姓名
        }
        // 提取审核状态保存
        this.status = data.zt;
      });
    },
    // 根据id值和用户状态判断是否可以修改表单数据
    confirmWrite() {
      console.log(this.id);
      switch (this.id) {
        case "1":
          this.writeable = true;
          break;
        case "2":
          this.writeable = false;
          break;
        case "3":
          this.writeable = false;
          this.dataBack();
          break;
        case "4":
          this.writeable = true;
          this.dataBack();
          break;
      }
    },

    // 重置form表单
    resetForm() {
      this.kyxmForm = {
        brpm: "", // 本人排名
        dscylb: "", // 导师参与类别
        dsdyzz: "", // 导师是否第一作者
        fj: {}, // 附件
        sfdyzz: "", // 是否第一作者
        wlsldz: "", // 网络收录地址
        xmbh: "", // 项目编号
        xmjf: "", // 项目经费
        xmjssj: "", // 项目结束时间
        xmjtlx: "", // 项目具体类型
        xmkssj: "", // 项目开始时间
        xmlx: "", // 项目类型
        xmly: "", // 项目来源
        xmmc: "", // 项目名称
        xscylb: "", // 学生参与类别
        ywgjz: "", // 英文关键字
        ywzy: "", // 英文摘要
        zwgjz: "", // 中文关键字
        zwzy: "", // 中文摘要
        zzzrs: "" // 作者总人数
      };
      this.$refs.upload.clearFiles();
    },
    // 获取作者信息
    requireAuthor() {
      // 请求学生个人信息
      this.$http.get("/api/academic/aac/basic/info").then(res => {
        let data = res.data.data;
        // 非空验证
        if (!data) {
          this.$message.error("获取学生信息失败，请重试");
          return;
        }
        // 保存学生信息
        this.author = data;
      });
    }
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  },
  // 控制第一作者选择
  watch: {
    "kyxmForm.sfdyzz": {
      handler(val) {
        if (val) {
          this.kyxmForm.dsdyzz = false;
        } else {
          this.kyxmForm.dsdyzz = "";
        }
      }
    },
    // 当项目类型改变时
    "kyxmForm.xmlx": {
      handler(val) {
        console.log(1);
        // 将项目来源的待选列表清空
        this.xmlyList = [];
        // 更新项目具体类型的待选列表
        let tmp = this.xmList.filter(el => {
          return el.title === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.xmjtList = tmp[0].children;
        // 清空项目具体类型的选中值
        this.kyxmForm.xmjtlx = "";
        // 清空项目来源的选中值
        this.kyxmForm.xmly = "";
      }
    },
    "kyxmForm.xmjtlx": {
      handler(val) {
        console.log(2);
        let tmp = this.xmjtList.filter(el => {
          return el.title === val;
        });
        if (!tmp[0]) {
          return;
        }
        this.xmlyList = tmp[0].children;
        // 清空项目来源的选中值
        this.kyxmForm.xmly = "";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
