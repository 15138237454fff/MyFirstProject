<template>
  <div>
    <!-- 发表著作申请表 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              :table-title="achieveTitle"
              :status="$route.matched[1].name === 'achieveInput' && id != 1? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6">
            <span>|</span> 个人信息
          </th>
          <tr>
            <td>姓名</td>
            <td>{{author.xsxm}}</td>
            <td>学号</td>
            <td>{{author.xh}}</td>
            <td>所属学院</td>
            <td>{{author.ssyxmc}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 关键信息
          </th>
          <tr>
            <td :class=" writeable ? 'required' : '' ">著作名称</td>
            <td colspan="5">
              <el-input type="text" v-model="fbzzForm.zzmc" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.zzmc}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">著作类型</td>
            <td>
              <div v-if="writeable">
                <el-select v-model="fbzzForm.zzlx" style="width:100%;">
                  <el-option
                    :label="item.name"
                    :value="item.name"
                    v-for="(item,index) of zzlxList"
                    :key="index"
                  ></el-option>
                </el-select>
              </div>
              <span v-else>{{fbzzForm.zzlx}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">出版状态</td>
            <td>
              <div v-if="writeable">
                <el-radio
                  v-model="fbzzForm.cbzt"
                  :label="item.name"
                  v-for="(item,index) of cbztList"
                  :key="index"
                ></el-radio>
              </div>
              <span v-else>{{fbzzForm.cbzt}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">排序/总人数</td>
            <td>
              <div class="range" v-if="writeable">
                <el-input v-model="fbzzForm.brpm" type="number"></el-input>&nbsp;&nbsp;/&nbsp;&nbsp;
                <el-input v-model="fbzzForm.zzzrs" type="number"></el-input>
              </div>
              <div v-else>
                <span>{{fbzzForm.brpm}}</span>&nbsp;&nbsp;/&nbsp;&nbsp;
                <span>{{fbzzForm.zzzrs}}</span>
              </div>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">是否是第一作者</td>
            <td>
              <div v-if="writeable">
                <el-radio v-model="fbzzForm.sfdyzz" :label="true">是</el-radio>
                <el-radio v-model="fbzzForm.sfdyzz" :label="false">否</el-radio>
              </div>
              <span v-else>{{fbzzForm.sfdyzz ? '是' : '否'}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">导师是否是第一作者</td>
            <td>
              <div v-if="writeable">
                <el-radio
                  v-model="fbzzForm.dsdyzz"
                  :label="true"
                  :disabled="fbzzForm.sfdyzz === true"
                >是</el-radio>
                <el-radio
                  v-model="fbzzForm.dsdyzz"
                  :label="false"
                  :disabled="fbzzForm.sfdyzz === true"
                >否</el-radio>
              </div>
              <span v-else>{{fbzzForm.dsdyzz ? '是' : '否'}}</span>
            </td>
            <td class="contentTd"></td>
            <td></td>
          </tr>
          <tr>
            <td>备注</td>
            <td colspan="5">
              <el-input v-model="fbzzForm.bz" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.bz}}</span>
            </td>
          </tr>
        </tbody>
        <tbody v-show="fbzzForm.cbzt === '已出版'">
          <th colspan="6">
            <span>|</span> 出版信息
          </th>
          <tr>
            <td :class=" writeable ? 'required' : '' ">出版社</td>
            <td class>
              <el-input type="text" v-model="fbzzForm.cbs" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.cbs}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">出版级别</td>
            <td>
              <el-select v-model="fbzzForm.cbjb" v-if="writeable" style="width:100%;">
                <el-option
                  :label="item.name"
                  :value="item.name"
                  v-for="(item,index) of cbjbList"
                  :key="index"
                ></el-option>
              </el-select>
              <span v-else>{{fbzzForm.cbjb}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">出版时间</td>
            <td>
              <el-date-picker
                v-if="writeable"
                v-model="fbzzForm.cbsj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%;"
              ></el-date-picker>
              <span v-else>{{fbzzForm.cbsj|toYMD}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">ISBN</td>
            <td>
              <el-input v-model="fbzzForm.isbn" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.isbn}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">印刷次数</td>
            <td>
              <el-input v-model="fbzzForm.yscs" type="number" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.yscs}}</span>
            </td>
            <td class="contentTd"></td>
            <td></td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 项目资助信息
          </th>
          <tr>
            <td class>资助来源名称</td>
            <td class>
              <el-input type="text" v-model="fbzzForm.zzlymc" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.zzlymc}}</span>
            </td>
            <td>资助号码</td>
            <td>
              <el-input type="text" v-model="fbzzForm.zzhm" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.zzhm}}</span>
            </td>
            <td>资助单位</td>
            <td>
              <el-input type="text" v-model="fbzzForm.zzdw" v-if="writeable"></el-input>
              <span v-else>{{fbzzForm.zzdw}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">附件</td>
            <td>
              <div v-if="writeable">
                <el-upload
                  class="upload-demo"
                  action="/api/system/upload"
                  multiple
                  :limit="1"
                  :on-success="receiveFJ"
                  :on-remove="removeFJ"
                  ref="upload"
                  :headers="headers"
                >
                  <el-button size="large" type="primary" :plain="true" style="padding:10px 60px 10px 60px;">点击上传附件</el-button>
                </el-upload>
              </div>
              <div v-else>
                <a
                  :href="fbzzForm.fj.url"
                  target="_blank"
                  class="primary"
                  :download="fbzzForm.fj.fileName"
                >{{fbzzForm.fj.fileName}}</a>
              </div>
            </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
      </table>
      <span class="tx-msg" v-if="userStatus == 1">注：{{txMsg}}</span>
      <div class="submitBtn">
        <el-button type="primary" @click="handleSubmit" v-if="id === '1'">提交请求</el-button>
        <!-- <el-button type="default" @click="resetForm" v-if="id==='4'">重置</el-button> -->
        <el-button type="primary" @click="handleSubmit" v-if="id==='4'">重新提交</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "fbzz",
  props: {
    id: {},
    executionId: {}
  },
  components: {
    tableFlag
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      fbzzForm: {
        brpm: "", // 本人排名
        bz: "", // 备注
        cbjb: "", // 出版级别
        cbs: "", // 出版社
        cbsj: "", // 出版时间
        cbzt: "", // 出版状态
        dsdyzz: "", // 导师是否第一作者
        fj: {
          fileName: "",
          url: ""
        }, // 上传附件
        isbn: "", // ISBN
        sfdyzz: "", // 是否第一作者
        yscs: "", // 印刷次数
        zzdw: "", // 资助单位
        zzhm: "", // 资助号码
        zzlx: "", // 著作类型
        zzlymc: "", // 资助来源名称
        zzmc: "", // 著作名称
        zzzrs: "" // 作者总人数
      },
      // 作者信息
      author: {
        ssyxmc: "", // 学院名称
        xh: "", // 学号
        xsxm: "" // 学生姓名
      },
      txMsg: "",
      cbztList: [],
      zzlxList: [],
      cbjbList: [],
      achieveTitle: "浙江财经大学研究生发表著作申请表",
      writeable: false, // 表单是否可以更改
      status: null
    };
  },
  mounted() {
    // 确认是否可以写入数据
    this.confirmWrite();
    // 如果可写
    if (this.writeable) {
      // 当前参数为出版级别
      this.getTX("XS-44593").then(data => {
        this.cbjbList = data;
      });
      // 当前参数为著作类型
      this.getTX("XS-13519").then(data => {
        this.zzlxList = data;
      });
    }
    // 当前参数为出版状态
    this.getTX("XS-08759").then(data => {
      this.cbztList = data;
    });
    // 当前参数为提醒
    if (this.userStatus == 1) {
      // 请求学生(作者)信息
      this.requireAuthor();
      this.$http.get("/api/academic/apc/serve/" + "XS-35510").then(result => {
        this.txMsg = result.data.data;
      });
    }
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  },
  methods: {
    // 获取提示信息的方法
    getTX(id) {
      return new Promise(resolve => {
        this.$http.get("/api/academic/apc/serve/" + id).then(result => {
          let data = result.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("未获取的参数详情");
            return false;
          }
          resolve(data);
        });
      });
    },
    // 点击提交按钮
    handleSubmit() {
      this.$store.commit("updateDialog", {
        visible: true,
        successCallback: this.submit
      });
    },
    // 提交著作
    submit() {
      this.$store.commit("updateDialog", { visible: false });
      let requiredArr = [
        "zzmc",
        "zzlx",
        "cbzt",
        "brpm",
        "zzzrs",
        "sfdyzz",
        "dsdyzz",
        "fj"
      ];
      let cbxxArr = ["cbs", "cbjb", "cbsj", "isbn", "yscs"];
      let test = true;
      if (this.fbzzForm.cbzt === "已出版") {
        requiredArr = requiredArr.concat(cbxxArr);
      }
      requiredArr.forEach(key => {
        // 如果是附件为空
        if (key === "fj") {
          if (Object.values(this.fbzzForm.fj).includes("")) {
            test = false;
          }
        } else {
          // 如果其他参数为空
          if (this.fbzzForm[key] === "") {
            test = false;
          }
        }
      });
      // 如果验证通过
      if (test) {
        const fbzzLoading = this.$loading({target:document.querySelector('.table-box')})
        // 如果流程id为空，即第一次提交申请
        if (!this.executionId) {
          // 发送请求发表发表著作
          this.$http.post("/api/academic/pwc", this.fbzzForm).then(res => {
            fbzzLoading.close()
            if (res.data.code === 200) {
              this.$message.success("申请成功");
              this.resetForm();
            } else {
              this.$message.error(res.data.message);
            }
          });
        } else {
          // 发送请求修改发表著作
          this.$http
            .put("/api/academic/pwc/" + this.executionId, this.fbzzForm)
            .then(res => {
              fbzzLoading.close()
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
      // 否则
      else {
        // 提示消息
        this.$message.warning("请填写完整后再尝试提交论文");
      }
    },
    // 接收的上传名称和地址
    receiveFJ(res) {
      this.fbzzForm.fj = res.data;
    },
    // 文件移除时清空附件
    removeFJ() {
      this.fbzzForm.fj = { url: "", fileName: "" };
    },
    // 根据id值和用户状态判断是否可以修改表单数据
    confirmWrite() {
      console.log(this.id);
      switch (this.id) {
        case "1":
          this.writeable = true;
          break;
        case "2":
          this.writeable = false;
          break;
        case "3":
          this.writeable = false;
          this.dataBack();
          break;
        case "4":
          this.writeable = true;
          this.dataBack();
          break;
      }
    },
    // 数据回显
    dataBack() {
      this.$http.get(`/api/academic/pwc/${this.executionId}`).then(res => {
        let data = res.data.data;
        console.log(data);
        // 数据非空验证
        if (!data) {
          this.$message.error("历史申请详情数据获取失败，请重试");
          return;
        }
        // 保存回显的申请表单值
        Object.keys(this.fbzzForm).forEach(key => {
          this.fbzzForm[key] = data[key];
        });
        // 如果非学生
        if (this.userStatus != 1) {
          // 取出回显数据中的学生信息
          this.author.ssyxmc = data.xymc; // 学院名称
          this.author.xh = data.xh; // 学号
          this.author.xsxm = data.xsxm; // 学生姓名
        }
        // 提取审核状态保存
        this.status = data.zt;
      });
    },
    // 重置form表单
    resetForm() {
      this.fbzzForm = {
        brpm: "", // 本人排名
        bz: "", // 备注
        cbjb: "", // 出版级别
        cbs: "", // 出版社
        cbsj: "", // 出版时间
        cbzt: "", // 出版状态
        dsdyzz: "", // 导师是否第一作者
        fj: {
          fileName: "",
          url: ""
        }, // 上传附件
        isbn: "", // ISBN
        sfdyzz: "", // 是否第一作者
        yscs: "", // 印刷次数
        zzdw: "", // 资助单位
        zzhm: "", // 资助号码
        zzlx: "", // 著作类型
        zzlymc: "", // 资助来源名称
        zzmc: "", // 著作名称
        zzzrs: "" // 作者总人数
      };
      // 清空附件
      this.$refs.upload.clearFiles();
    },
    // 获取作者信息
    requireAuthor() {
      // 请求学生个人信息
      this.$http.get("/api/academic/aac/basic/info").then(res => {
        let data = res.data.data;
        // 非空验证
        if (!data) {
          this.$message.error("获取学生信息失败，请重试");
          return;
        }
        // 保存学生信息
        this.author = data;
      });
    }
  },
  // 控制第一作者选择
  watch: {
    "fbzzForm.sfdyzz": {
      handler(val) {
        if (val) {
          this.fbzzForm.dsdyzz = false;
        } else {
          this.fbzzForm.dsdyzz = "";
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
