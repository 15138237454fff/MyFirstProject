<template>
  <div>
    <!-- 技术专利申请表 -->
    <div class="table-box">
      <!-- 学术论文申请表 -->
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              :table-title="achieveTitle"
              :status="$route.matched[1].name === 'achieveInput' && id != 1? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6">
            <span>|</span> 个人信息
          </th>
          <tr>
            <td>姓名</td>
            <td>{{author.xsxm}}</td>
            <td>学号</td>
            <td>{{author.xh}}</td>
            <td>所属学院</td>
            <td>{{author.ssyxmc}}</td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 关键信息
          </th>
          <tr>
            <td :class=" writeable ? 'required' : '' ">专利号</td>
            <td class>
              <el-input type="text" v-model="jszlForm.zlh" v-if="writeable"></el-input>
              <span v-else>{{jszlForm.zlh}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">专利名称</td>
            <td colspan="3">
              <el-input type="text" v-model="jszlForm.zlmc" v-if="writeable"></el-input>
              <span v-else>{{jszlForm.zlmc}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">专利类型</td>
            <td>
              <div v-if="writeable">
                <el-select v-model="jszlForm.zllx" style="width:100%;">
                  <el-option
                    :label="item.name"
                    :value="item.name"
                    v-for="(item,index) of zllxList"
                    :key="index"
                  ></el-option>
                </el-select>
              </div>
              <span v-else>{{jszlForm.zllx}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">本人排名/总数</td>
            <td>
              <div class="range" v-if="writeable">
                <el-input v-model="jszlForm.brpm" type="number"></el-input>&nbsp;&nbsp;/&nbsp;&nbsp;
                <el-input v-model="jszlForm.zzzrs" type="number"></el-input>
              </div>
              <div v-else>
                <span>{{jszlForm.brpm}}</span>&nbsp;&nbsp;/&nbsp;&nbsp;
                <span>{{jszlForm.zzzrs}}</span>
              </div>
            </td>
            <td :class=" writeable ? 'required' : '' ">申请时间</td>
            <td>
              <el-date-picker
                v-if="writeable"
                v-model="jszlForm.zlsqsj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%;"
              ></el-date-picker>
              <span v-else>{{jszlForm.zlsqsj|toYMD}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">状态</td>
            <td>
              <div v-if="writeable">
                <el-select v-model="jszlForm.zlzt" placeholder="请选择" style="width:100%;">
                  <el-option
                    :label="item.name"
                    :value="item.name"
                    v-for="(item,index) of zlztList"
                    :key="index"
                  ></el-option>
                </el-select>
              </div>
              <span v-else>{{jszlForm.zlzt}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">{{jszlForm.zlzt === "授权"?"授权号":"申请号"}}</td>
            <td>
              <el-input v-model="jszlForm.sqh" v-if="writeable"></el-input>
              <span v-else>{{jszlForm.sqh}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">{{jszlForm.zlzt === "授权"?"授权时间":"公开时间"}}</td>
            <td>
              <el-date-picker
                v-model="jszlForm.sqsj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%;"
                v-if="writeable"
              ></el-date-picker>
              <span v-else>{{jszlForm.sqsj|toYMD}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">是否是第一作者</td>
            <td>
              <div v-if="writeable">
                <el-radio v-model="jszlForm.sfdyzz" :label="true">是</el-radio>
                <el-radio v-model="jszlForm.sfdyzz" :label="false">否</el-radio>
              </div>
              <span v-else>{{jszlForm.sfdyzz?'是':'否'}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">导师是否是第一作者</td>
            <td>
              <div v-if="writeable">
                <el-radio
                  v-model="jszlForm.dsdyzz"
                  :label="true"
                  :disabled="jszlForm.sfdyzz === true"
                >是</el-radio>
                <el-radio
                  v-model="jszlForm.dsdyzz"
                  :label="false"
                  :disabled="jszlForm.sfdyzz === true "
                >否</el-radio>
              </div>
              <span v-else>{{jszlForm.dsdyzz? '是' : '否'}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">专利所有单位</td>
            <td>
              <el-input v-model="jszlForm.zlsydw" v-if="writeable"></el-input>
              <span v-else>{{jszlForm.zlsydw}}</span>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">上传收录佐证</td>
            <td>
              <div v-if="writeable">
                <el-upload
                  class="upload-demo"
                  action="/api/system/upload"
                  multiple
                  :limit="1"
                  :on-success="receiveFJ"
                  :on-remove="removeFJ"
                  ref="upload"
                  :headers="headers"
                >
                  <el-button size="large" type="primary" :plain="true" style="padding:12px 62px 12px 62px;">点击上传附件</el-button>
                </el-upload>
              </div>
              <div v-else>
                <a
                  :href="jszlForm.fj.url"
                  target="_blank"
                  class="primary"
                  :download="jszlForm.fj.fileName"
                >{{jszlForm.fj.fileName}}</a>
              </div>
            </td>
            <td class="contentTd"></td>
            <td></td>
            <td class="contentTd"></td>
            <td></td>
          </tr>
        </tbody>
      </table>
      <span class="tx-msg" v-if="userStatus == 1">注：{{txMsg}}</span>
      <div class="submitBtn">
        <el-button type="primary" @click="handleSubmit" v-if="id === '1'">提交请求</el-button>
        <!-- <el-button type="default" @click="resetForm" v-if="id === '4'">重置</el-button> -->
        <el-button type="primary" @click="handleSubmit" v-if="id === '4'">重新提交</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "jszl",
  props: {
    id: {},
    executionId: {}
  },
  components: {
    tableFlag
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      jszlForm: {
        zlh: "", // 专利号
        zlmc: "", // 专利名称
        zllx: "发明专利", // 专利类型
        brpm: "", // 本人排名
        zzzrs: "", // 排名总人数
        zlsqsj: "", // 专利申请时间
        zlzt: "", // 专利状态
        sqh: "", // 申请号/授权号
        sqsj: "", // 公开/授权时间
        sfdyzz: "", // 是否第一作者
        dsdyzz: "", // 是否导师第一作者
        zlsydw: "", // 专利所属单位
        fj: { fileName: "", url: "" } // 附件
      },
      // 作者信息
      author: {
        ssyxmc: "", // 学院名称
        xh: "", // 学号
        xsxm: "" // 学生姓名
      },
      txMsg: "", // 提醒消息
      zlztList: [], // 专利状态列表
      zllxList: [], // 专利类别列表
      achieveTitle: "浙江财经大学研究生技术专利申请表",
      writeable: false, // 表单是否可以更改
      status: null
    };
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  },
  mounted() {
    // 确认是否可以写入数据
    this.confirmWrite();
    // 如果可写
    if (this.writeable) {
      // 当前参数为专利状态
      this.getTX("XS-46843").then(data => {
        this.zlztList = data;
      });
      // 当前参数为专利类别
      this.getTX("XS-26500").then(data => {
        this.zllxList = data;
      });
    }
    // 当前参数为提醒
    if (this.userStatus == 1) {
      // 请求学生(作者)信息
      this.requireAuthor();
      this.$http.get("/api/academic/apc/serve/" + "XS-02549").then(result => {
        this.txMsg = result.data.data;
      });
    }
  },
  methods: {
    // 提交专利
    submit() {
      this.$store.commit("updateDialog", { visible: false });
      console.log(this.jszlForm);
      // 验证的结果，默认为true
      let test = true;
      Object.keys(this.jszlForm).forEach(key => {
        // 如果为空字符串
        if (this.jszlForm[key] === "") {
          test = false;
        }
        // 如果是对象
        else if (typeof this.jszlForm[key] === "object") {
          if (Object.values(this.jszlForm[key]).includes("")) {
            test = false;
          }
        }
      });
      // 如果验证通过
      if (test) {
        const jszlLoading = this.$loading({target:document.querySelector('.table-box')})
        // 如果流程id为空，即第一次提交申请
        if (!this.executionId) {
          // 发送请求提交技术专利
          this.$http.post("/api/academic/ptc", this.jszlForm).then(res => {
            jszlLoading.close()
            if (res.data.code === 200) {
              this.$message.success("申请成功");
              this.resetForm();
            } else {
              this.$message.error(res.data.message);
            }
          });
        } else {
          // 发送请求修改技术专利
          this.$http
            .put("/api/academic/ptc/" + this.executionId, this.jszlForm)
            .then(res => {
              jszlLoading.close()
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
      // 验证未通过
      else {
        this.$message.warning("请填写完整后再尝试提交论文");
      }
    },
    // 获取提示信息的方法
    getTX(id) {
      return new Promise(resolve => {
        this.$http.get("/api/academic/apc/serve/" + id).then(result => {
          let data = result.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("未获取的参数详情");
            return false;
          }
          resolve(data);
        });
      });
    },
    // 点击提交按钮
    handleSubmit() {
      // 展示对话框并更新点击确定时执行的方法
      this.$store.commit("updateDialog", {
        visible: true,
        successCallback: this.submit
      });
    },
    // 接收一个收录佐证的上传名称和地址
    receiveFJ(res) {
      this.jszlForm.fj = res.data;
    },
    // 文件移除时清空附件
    removeFJ() {
      this.jszlForm.fj = { url: "", fileName: "" };
    },
    // 根据id值和用户状态判断是否可以修改表单数据
    confirmWrite() {
      console.log(this.id);
      switch (this.id) {
        case "1":
          this.writeable = true;
          break;
        case "2":
          this.writeable = false;
          break;
        case "3":
          this.writeable = false;
          this.dataBack();
          break;
        case "4":
          this.writeable = true;
          this.dataBack();
          break;
      }
    },
    // 数据回显
    dataBack() {
      this.$http.get(`/api/academic/ptc/${this.executionId}`).then(res => {
        let data = res.data.data;
        console.log(data);
        // 数据非空验证
        if (!data) {
          this.$message.error("历史申请详情数据获取失败，请重试");
          return;
        }
        // 保存回显的申请表单值
        Object.keys(this.jszlForm).forEach(key => {
          this.jszlForm[key] = data[key];
        });
        // 如果非学生
        if (this.userStatus != 1) {
          // 取出回显数据中的学生信息
          this.author.ssyxmc = data.xymc; // 学院名称
          this.author.xh = data.xh; // 学号
          this.author.xsxm = data.xsxm; // 学生姓名
        }
        // 提取审核状态保存
        this.status = data.zt;
      });
    },
    // 重置form表单
    resetForm() {
      this.jszlForm = {
        zlh: "", // 专利号
        zlmc: "", // 专利名称
        zllx: "发明专利", // 专利类型
        brpm: "", // 本人排名
        zzzrs: "", // 排名总人数
        zlsqsj: "", // 专利申请时间
        zlzt: "", // 专利状态
        sqh: "", // 申请号/授权号
        sqsj: "", // 公开/授权时间
        sfdyzz: "", // 是否第一作者
        dsdyzz: "", // 是否导师第一作者
        zlsydw: "", // 专利所属单位
        fj: { fileName: "", url: "" } // 附件
      };
      this.$refs.upload.clearFiles();
    },
    // 获取作者信息
    requireAuthor() {
      // 请求学生个人信息
      this.$http.get("/api/academic/aac/basic/info").then(res => {
        let data = res.data.data;
        // 非空验证
        if (!data) {
          this.$message.error("获取学生信息失败，请重试");
          return;
        }
        // 保存学生信息
        this.author = data;
      });
    }
  },
  // 控制第一作者选择
  watch: {
    "jszlForm.sfdyzz": {
      handler(val) {
        if (val) {
          this.jszlForm.dsdyzz = false;
        } else {
          this.jszlForm.dsdyzz = "";
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
