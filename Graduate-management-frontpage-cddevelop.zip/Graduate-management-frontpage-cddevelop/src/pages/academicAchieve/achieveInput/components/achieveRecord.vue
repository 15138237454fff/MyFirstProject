<template>
  <!-- 研究生证补办申请记录 applyRecord -->
  <div class="achieveRecord"
   v-loading="loading">
    <el-table
      :data="tableData"
      border
      style="width: 100%"
      :header-cell-style="$tableHeaderColor"
      :height="tableHeight"
    >
      <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
      <el-table-column label="申请类型" prop="resultsType" align="center">
        <template slot-scope="scope">
          <span>{{scope.row.resultsType|resultsTypeFilter}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="applyDate" label="申请日期" align="center"></el-table-column>
      <el-table-column prop="status" label="申请状态" align="center">
        <template slot-scope="scope">
          <span :class="scope.row.status|statusFilter(1)">{{scope.row.status|statusFilter(0)}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="操作" width="120" align="center">
        <template slot-scope="scope">
          <el-button
            type="text"
            v-if="scope.row.status == '2'"
            @click="$router.push(`/academicAchieve/achieveInput/4/${scope.row.executionId}?resultsType=${scope.row.resultsType}`)"
          >修改</el-button>
          <el-button
            type="text"
            v-else
            @click="$router.push(`/academicAchieve/achieveInput/3/${scope.row.executionId}?resultsType=${scope.row.resultsType}`)"
          >查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'achieveDetail',
  data () {
    return {
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10, // 页大小
        query: '', // 关键字
        status: 0 // 类型
      },
      // 消息总数量
      msgCount: 0,
      // 审核列表信息
      tableData: [],
      loading:true
    }
  },
  created () {
    this.loadTable()
  },
  components: {
    'my-pagination': myPagination
  },
  filters: {
    // 成果类型的过滤
    resultsTypeFilter (val) {
      switch (val) {
        case 1:
          return '学术论文'
        case 2:
          return '技术专利'
        case 3:
          return '发表著作'
        case 4:
          return '科研项目'
        default:
          return val
      }
    },
    // 审核结果的过滤，type = 0控制返回中文，type =1 返回样式
    statusFilter (val, type) {
      if (type === 0) {
        switch (val) {
          case 0:
            return '不通过'
          case 1:
            return '通过'
          case 2:
            return '退回'
          case 3:
            return '审核中'
          default:
            return val
        }
      } else {
        switch (val) {
          case 0:
          case 2:
            return 'red'
          case 1:
            return 'blue'
          case 3:
            return 'orange'
          default:
            return ''
        }
      }
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 请求申请记录
    loadTable () {
      this.$http
        .post('/api/academic/aac/record', this.limitQuery)
        .then(res => {
          this.loading = false
          // console.log(res);
          let data = res.data.data
          // 获取数据验证
          if (!data || !Array.isArray(data.list)) {
            this.$message.error('获取审核记录数据失败，请刷新')
            return
          }
          // 保存获取的数据
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 改变列表页条数大小回调函数
    handleSizeChange (val) {
      this.limitQuery.pageSize = val
      // 重新请求列表数据
      this.loadTable()
    },
    // 改变当前页
    handleCurrentChange (val) {
      this.limitQuery.pageNum = val
      // 重新请求列表数据
      this.loadTable()
    }
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 24
    }
  }
}
</script>
<style lang="scss" scoped>
.achieveRecord {
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }
  .red {
    color: #f00;
  }
  .orange {
    color: #ff9900;
  }
  .blue {
    color: #1890ff;
  }
}
</style>
