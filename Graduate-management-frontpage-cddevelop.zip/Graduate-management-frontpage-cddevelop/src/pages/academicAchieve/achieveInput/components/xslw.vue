<template>
  <div class="table-box">
    <!-- 学术论文申请表 -->
    <table border="1" cellspacing="0" cellpadding="0">
      <thead>
        <th colspan="6">
          <table-flag
            :table-title="achieveTitle"
            :status="$route.matched[1].name === 'achieveInput' && id != 1? `${status}` : null"
          ></table-flag>
        </th>
      </thead>
      <tbody>
        <th colspan="6">
          <span>|</span> 个人信息
        </th>
        <tr>
          <td>姓名</td>
          <td>{{author.xsxm}}</td>
          <td>学号</td>
          <td>{{author.xh}}</td>
          <td>所属学院</td>
          <td>{{author.ssyxmc}}</td>
        </tr>
      </tbody>
      <tbody>
        <th colspan="6">
          <span>|</span> 关键信息
        </th>
        <tr>
          <td :class=" writeable ? 'required' : '' ">论文题目</td>
          <td colspan="5">
            <el-input type="text" v-model="thesisnDTO.lwmc" placeholder="请输入论文题目" v-if="writeable"></el-input>
            <span v-else>{{thesisnDTO.lwmc}}</span>
          </td>
        </tr>
        <tr>
          <td :class=" writeable ? 'required' : '' ">本人排名/总数</td>
          <td>
            <div class="range" v-if="writeable">
              <el-input v-model="thesisnDTO.brpm" type="number"></el-input>&nbsp;&nbsp;/&nbsp;&nbsp;
              <el-input v-model="thesisnDTO.zzzrs" type="number"></el-input>
            </div>
            <div v-else>
              <span>{{thesisnDTO.brpm}}</span>&nbsp;&nbsp;/&nbsp;&nbsp;
              <span>{{thesisnDTO.zzzrs}}</span>
            </div>
          </td>
          <td :class=" writeable ? 'required' : '' ">是否是第一作者</td>
          <td>
            <div v-if="writeable">
              <el-radio v-model="thesisnDTO.sfdyzz" :label="true">是</el-radio>
              <!-- 默认选中的是否的状态 -->
              <el-radio v-model="thesisnDTO.sfdyzz" :label="false" :checked='thesisnDTO.sfdyzz.checked'>否</el-radio>
            </div>
            <span v-else>{{thesisnDTO.sfdyzz? '是' : '否'}}</span>
          </td>
          <td :class=" writeable ? 'required' : '' ">导师是否是第一作者</td>
          <td>
            <div v-if="writeable">
              <el-radio
                v-model="thesisnDTO.dsdyzz"
                :label="true"
                :disabled="thesisnDTO.sfdyzz === true"
              >是</el-radio>
              <el-radio
                v-model="thesisnDTO.dsdyzz"
                :label="false"
                :disabled="thesisnDTO.sfdyzz === true"
              >否</el-radio>
            </div>
            <span v-else>{{thesisnDTO.dsdyzz? '是' : '否'}}</span>
          </td>
        </tr>
        <tr v-if="thesisnDTO.dsdyzz ===false && thesisnDTO.sfdyzz === false">
          <td :class=" writeable ? 'required' : '' ">第一作者</td>
          <td colspan="5">
            <el-input placeholder="请输入" v-model="thesisnDTO.dyzz" v-if="writeable"></el-input>
            <span v-else>{{thesisnDTO.dyzz}}</span>
          </td>
        </tr>
        <tr>
          <td :class=" writeable ? 'required' : '' ">刊号</td>
          <td>
            <div class="kh">
              <el-select v-model="thesisnDTO.kh" placeholder="请选择" v-if="writeable">
                <el-option label="ISSN" value="ISSN"></el-option>
                <el-option label="ISBN" value="ISBN"></el-option>
              </el-select>
              <span v-else>{{thesisnDTO.kh}}</span>
            </div>
            <div class="khdm">
              <el-input placeholder="0000-0000" v-model="thesisnDTO.khdm" v-if="writeable"></el-input>
              <span v-else>{{thesisnDTO.khdm}}</span>
            </div>
          </td>
          <td :class=" writeable ? 'required' : '' ">出版期刊名称</td>
          <td colspan="3">
            <el-input placeholder="请输入刊物名称" v-model="thesisnDTO.cbqkmc" v-if="writeable"></el-input>
            <span v-else>{{thesisnDTO.cbqkmc}}</span>
          </td>
        </tr>
        <tr>
          <td :class=" writeable ? 'required' : '' ">发表/录用状态</td>
          <td>
            <div v-if="writeable">
              <el-radio v-model="thesisnDTO.lwzt" :label="2">已发表</el-radio>
              <el-radio v-model="thesisnDTO.lwzt" :label="1">已录用</el-radio>
            </div>
            <span v-else>{{thesisnDTO.lwzt === 2 ? '已发表' : '已录用'}}</span>
          </td>
          <td :class=" writeable ? 'required' : '' ">{{thesisnDTO.lwzt === 2 ?'发表日期':'拟刊出时间'}}</td>
          <td>
            <el-date-picker
              v-if="writeable"
              v-model="thesisnDTO.sj"
              type="date"
              placeholder="请选择"
              prefix-icon="el-icon-date"
              style="width:100%;"
            ></el-date-picker>
            <span v-else>{{thesisnDTO.sj|toYMD}}</span>
          </td>
          <td :class=" writeable ? 'required' : '' " v-if="thesisnDTO.lwzt === 2">刊出卷号</td>
          <td v-else></td>
          <td>
            <div v-if="writeable">
              <el-input v-model="thesisnDTO.kcjh" v-if="thesisnDTO.lwzt === 2"></el-input>
            </div>
            <span v-else>{{thesisnDTO.kcjh}}</span>
          </td>
        </tr>
        <tr>
          <td :class=" writeable ? 'required' : '' ">{{thesisnDTO.lwzt === 2 ?'上传收录佐证':'上传录用佐证'}}</td>
          <td>
            <div v-if="writeable">
              <el-upload
                class="upload-demo"
                :headers="headers"
                action="/api/system/upload"
                multiple
                :limit="1"
                :on-success="receiveFJ"
                :on-remove="removeFJ"
                ref="uploadFJ"
              >
                <el-button size="large" type="primary" :plain="true">点击上传附件</el-button>
              </el-upload>
            </div>
            <div v-else>
              <a
                :href="thesisnDTO.zz.url"
                target="_blank"
                class="primary"
                :download="thesisnDTO.zz.fileName"
              >{{thesisnDTO.zz.fileName}}</a>
            </div>
          </td>
          <td :class=" writeable ? 'required' : '' ">期刊类别</td>
          <td colspan="3">
            <el-select
              v-model="thesisnDTO.qklb"
              multiple
              placeholder="请选择"
              class="qklb"
              v-if="writeable"
              style="width:100%;"
            >
              <el-option
                v-for="(item,index) in qklbList[thesisnDTO.kh]"
                :key="index"
                :label="item.name"
                :value="item.name"
              ></el-option>
            </el-select>
            <span v-else>{{thesisnDTO.qklb.join("，")}}</span>
          </td>
        </tr>
        <tr v-for="(item,index) of thesisnDTO.slxx" :key="index">
          <!-- <td :class=" writeable ? 'required' : '' ">收录级别/影响因子/佐证</td> -->
          <td class="moralHeight"><span style="color:red;">*</span>&nbsp;&nbsp;收录级别/影响因子/佐证</td>
          <td class="moralHeight">
            <el-select
              v-model="item.sljb"
              placeholder="请选择收录级别"
              v-if="writeable"
              style="width:100%;"
            >
              <el-option
                v-for="(val,ind) in sljbList"
                :key="ind"
                :label="val.name"
                :value="val.name"
              ></el-option>
            </el-select>
            <span v-else>{{item.sljb}}</span>
          </td>
          <td class="contentTd" style="padding；0;height:40px;">
            <el-input v-model="item.yxyz" placeholder="请输入影响因子" v-if="writeable" style="width:100%;"></el-input>
            <span v-else>{{item.yxyz}}</span>
          </td>
          <td class="moralHeight">
            <div v-if="writeable">
              <el-upload
                class="upload-demo"
                :headers="headers"
                action="/api/system/upload"
                multiple
                :limit="1"
                :on-success="receiveSLFJ"
                :on-remove="removeSLFJ"
                ref="uploadSLFJ"
                style="width:100%"
              >
                <el-button
                  size="large"
                  type="primary"
                  :plain="true"
                  @click="saveFJIndex(index)"
                  style="width:100%"
                >点击上传附件</el-button>
              </el-upload>
            </div>
            <div v-else>
              <a
                :href="item.scfj.url"
                target="_blank"
                :download="item.scfj.fileName"
              >{{item.scfj.fileName}}</a>
            </div>
          </td>
          <td class="contentTd" style="padding:0;height:40px;">
            <div v-if="writeable">
              <el-button icon="el-icon-circle-plus" @click="addSlxx" class="add" v-if="index === 0"></el-button>
              <el-button
                icon="el-icon-remove"
                @click="removeSlxx(index)"
                class="reduce"
                v-if="index !== 0"
              ></el-button>
            </div>
          </td>
          <td class="moralHeight"></td>
        </tr>
        <tr rowspan="3">
          <td colspan="6" class="contentTd" v-if="writeable">
            <el-input type="textarea" :rows="6" :value="`备注：${thesisnDTO.bz}`" @input="changeText"></el-input>
          </td>
          <td v-if="!writeable">备注</td>
          <td v-if="!writeable" colspan="5">{{thesisnDTO.bz}}</td>
        </tr>
      </tbody>
    </table>
    <span class="tx-msg" v-if="userStatus == 1">注：{{txMsg}}</span>
    <div class="submitBtn">
      <el-button type="primary" @click="handleSubmit" v-if="id === '1'">提交请求</el-button>
      <!-- <el-button type="default" @click="resetForm" v-if="id==='4'">重置</el-button> -->
      <el-button type="primary" @click="handleSubmit" v-if="id==='4'">重新提交</el-button>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
export default {
  name: "xslw",
  props: {
    id: {},
    executionId: {}
  },
  components: {
    tableFlag
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      // 待提交的学术论文参数对象
      thesisnDTO: {
        lwmc: "", // 论文名称
        brpm: "", // 本人排名
        zzzrs: "", // 作者总人数
        sfdyzz: "", // 是否第一作者
        dsdyzz: "", // 导师是否第一作者
        cbqkmc: "", // 出版期刊名称
        kh: "", // 刊号
        khdm: "", // 刊号代码
        dyzz: "", // 第一作者名字
        lwzt: 2, // 论文状态
        sj: "", // 发表日期
        kcjh: "", // 刊出卷号
        zz: { fileName: "", url: "" }, // 收录附件
        qklb: [], // 期刊类别
        slxx: [{ sljb: "", yxyz: "", scfj: { fileName: "", url: "" } }], // 收录信息
        bz: ""
      },
      // 作者信息
      author: {
        ssyxmc: "", // 学院名称
        xh: "", // 学号
        xsxm: "" // 学生姓名
      },
      // 待选的期刊类别,与刊号关联
      qklbList: { ISSN: [], ISBN: [] },
      // 收录级别
      sljbList: [],
      slxxIndex: 0,
      // 收录信息条数
      slxxCount: 1,
      // 提醒消息
      txMsg: "",
      achieveTitle: "浙江财经大学研究生学术论文申请表",
      writeable: false, // 表单是否可以更改
      status: null
    };
  },
  mounted() {
    // 确认是否可以写入数据
    this.confirmWrite();
    // 如果可写
    if (this.writeable) {
      // 当参数为ISSN期刊
      this.getTX("XS-15766").then(data => {
        this.qklbList.ISSN = data;
      });
      // 当参数为ISBN期刊
      this.getTX("XS-46747").then(data => {
        this.qklbList.ISBN = data;
      });
      // 当前参数为收录级别
      this.getTX("XS-39972").then(data => {
        this.sljbList = data;
      });
    }
    if (this.userStatus == 1) {
      // 请求学生(作者)信息
      this.requireAuthor();
      // 当前参数为提醒
      this.$http.get("/api/academic/apc/serve/" + "XS-11104").then(result => {
        this.txMsg = result.data.data;
      });
    }
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  },
  methods: {
    // 获取
    // 获取提示信息的方法
    getTX(id) {
      return new Promise(resolve => {
        this.$http.get("/api/academic/apc/serve/" + id).then(result => {
          let data = result.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("未获取的参数详情");
            return false;
          }
          resolve(data);
        });
      });
    },
    // 添加一行收录信息
    addSlxx() {
      this.thesisnDTO.slxx.push({
        sljb: "",
        yxyz: "",
        scfj: { fileName: "", url: "" }
      });
    },
    // 移除一行收录信息
    removeSlxx(index) {
      this.thesisnDTO.slxx.splice(index, 1);
    },
    // 文本域输入修改内容
    changeText(val) {
      this.thesisnDTO.bz = val.slice(3);
    },
    // 提交论文
    submit() {
      this.$store.commit("updateDialog", { visible: false });
      let test = true;
      // console.log(this.thesisnDTO);
      Object.keys(this.thesisnDTO).forEach(key => {
        // 取出待提交的表单值的一项
        let data = this.thesisnDTO[key];
        // 如果这一项是个数组
        // console.log(data);
        if (Array.isArray(data)) {
          // 数组为空
          if (data.length === 0) {
            test = false;
          } // 数组不为空
          else {
            // console.log(2);
            data.forEach(el => {
              // 如果数组中的元素为一个对象
              // console.log(typeof el);
              if (typeof el === "object") {
                // 如果有一项未填写
                if (Object.values(el).includes("")) {
                  // console.log(1);
                  test = false;
                  return;
                }
                if (Object.values(el.scfj).includes("")) {
                  test = false;
                }
              }
            });
          }
        }
        // 如果不是数组
        else {
          // 如果是附件内容为空
          if (key === "zz") {
            if (Object.values(data).includes("")) {
              test = false;
              return;
            }
          }
          // 如果是第一作者
          if (key === "dyzz") {
            // 在是否第一作者和导师是否第一作者都为否的情况下，第一作者为空
            if (
              this.thesisnDTO.dsdyzz === false &&
              this.thesisnDTO.sfdyzz === false &&
              this.thesisnDTO.dyzz === ""
            ) {
              test = false;
              return;
            }
          }
          // 如果是刊出卷号
          if (key === "kcjh") {
            // 并且录用状态未录用状态为已发表，并且刊出卷号为空
            if (this.thesisnDTO.lwzt === 2 && data === "") {
              test = false;
            }
          }
          // 否则，值为空,且不是备注信息和第一作者
          else if (data === "" && key !== "bz" && key !== "dyzz") {
            test = false;
          }
        }
      });
      // 如果验证通过
      if (test) {
        const xslwLoading = this.$loading({target:document.querySelector('.table-box')})
        if (!this.executionId) {
          // 发送请求提交论文
          this.$http
            .post("/api/academic/thesisn", this.thesisnDTO)
            .then(res => {
              xslwLoading.close()
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.resetForm();
              } else {
                this.$message.error(res.data.message);
              }
            });
        } else {
          // 发送请求修改论文
          this.$http
            .put("/api/academic/thesisn/" + this.executionId, this.thesisnDTO)
            .then(res => {
              xslwLoading.close()
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.$router.go(-1);
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
      // 验证未通过
      else {
        // 提示消息
        this.$message.warning("请填写完整后再尝试提交论文");
      }
    },
    handleSubmit() {
      this.$store.commit("updateDialog", {
        visible: true,
        successCallback: this.submit
      });
    },
    // 接收一个收录佐证的上传名称和地址
    receiveFJ(res) {
      this.thesisnDTO.zz = res.data;
    },
    // 接收一个收录级别附件的上传名称和地址
    receiveSLFJ(res) {
      // console.log(res.data);
      this.thesisnDTO.slxx[this.slxxIndex].scfj = res.data;
      console.log(this.thesisnDTO.slxx);
    },
    // 文件移除时清空附件
    removeFJ() {
      this.thesisnDTO.zz = { url: "", fileName: "" };
    },
    removeSLFJ() {
      this.thesisnDTO.slxx[this.slxxIndex].scfj = { url: "", fileName: "" };
    },
    // 保存收录佐证当前点击上传的下标
    saveFJIndex(index) {
      this.slxxIndex = index;
    },
    // 根据id值和用户状态判断是否可以修改表单数据
    confirmWrite() {
      // console.log(this.id);
      switch (this.id) {
        case "1":
          this.writeable = true;
          break;
        case "2":
          this.writeable = false;
          break;
        case "3":
          this.writeable = false;
          this.dataBack();
          break;
        case "4":
          this.writeable = true;
          this.dataBack();
          break;
      }
    },
    // 数据回显
    dataBack() {
      this.$http.get(`/api/academic/thesisn/${this.executionId}`).then(res => {
        let data = res.data.data;
        console.log(data);
        // 数据非空验证
        if (!data) {
          this.$message.error("历史申请详情数据获取失败，请重试");
          return;
        }
        // 保存回显的申请表单值
        Object.keys(this.thesisnDTO).forEach(key => {
          this.thesisnDTO[key] = data[key];
        });
        // 如果非学生
        if (this.userStatus != 1) {
          // 取出回显数据中的学生信息
          this.author.ssyxmc = data.xymc; // 学院名称
          this.author.xh = data.xh; // 学号
          this.author.xsxm = data.xsxm; // 学生姓名
        }
        // 提取审核状态保存
        this.status = data.zt;
      });
    },
    // 重置form表单
    resetForm() {
      this.thesisnDTO = {
        lwmc: "", // 论文名称
        brpm: "", // 本人排名
        zzzrs: "", // 作者总人数
        sfdyzz: "", // 是否第一作者
        dsdyzz: "", // 导师是否第一作者
        cbqkmc: "", // 出版期刊名称
        kh: "", // 刊号
        khdm: "", // 刊号代码
        lwzt: "", // 论文状态
        sj: "", // 发表日期
        kcjh: "", // 刊出卷号
        zz: { fileName: "", url: "" }, // 收录附件
        qklb: [], // 期刊类别
        slxx: [{ sljb: "", yxyz: "", scfj: { fileName: "", url: "" } }], // 收录信息
        bz: ""
      };
      // 清空附件
      this.$refs.uploadFJ.clearFiles();
      this.$refs.uploadSLFJ.forEach(el => {
        el.clearFiles();
      });
    },
    // 获取作者信息
    requireAuthor() {
      // 请求学生个人信息
      this.$http.get("/api/academic/aac/basic/info").then(res => {
        let data = res.data.data;
        // 非空验证
        if (!data) {
          this.$message.error("获取学生信息失败，请重试");
          return;
        }
        // 保存学生信息
        this.author = data;
      });
    }
  },
  // 控制第一作者选择
  watch: {
    "thesisnDTO.sfdyzz": {
      handler(val) {
        if (val) {
          this.thesisnDTO.dsdyzz = false;
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.moralHeight{
  padding:0;
  height: 40px;
}

</style>
<style lang="scss">
  .input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
}
input[type="number"]{
  -moz-appearance: textfield;
}
</style>
