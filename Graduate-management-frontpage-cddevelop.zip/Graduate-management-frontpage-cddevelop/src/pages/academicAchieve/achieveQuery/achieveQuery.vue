<template>
  <div>
    <div class="main">
      <!-- 个人成果查询 achieveQuery -->
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/academicAchieve/achieveQuery/2' }">学术成果</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/academicAchieve/achieveQuery/2' }">个人成果查询</el-breadcrumb-item>
            <el-breadcrumb-item v-if="id == 3">查看详情</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right" v-if="id == 3">
          <i class="el-icon-d-arrow-left"></i>
          <el-button type="text" @click="$router.go(-1)">返回</el-button>
        </div>
      </my-breadcrumb>
      <div class="box">
        <div v-if="id == 2">
          <div class="head">
            <div></div>
            <div>
              <span class="block"></span>
              <span class="header-title">个人学术成果汇总</span>
              <span class="block"></span>
            </div>
            <div>
              <el-button type="primary" @click="output">导出</el-button>
            </div>
          </div>
          <div class="btnGroup">
            <el-input
              placeholder="请输入成果名称"
              prefix-icon="el-icon-search"
              clearable
              v-model="limitQuery.query"
              @keyup.enter.native="loadTable"
            ></el-input>
            <el-button @click="loadTable">查询</el-button>
            <el-select
              v-model="limitQuery.status"
              placeholder="全部申请类别"
              @change="loadTable"
              style="width:200px;"
            >
              <el-option
                v-for="item in genre"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </div>
          <el-table
            :data="tableData"
            tooltip-effect="dark"
            border
            v-loading="loading"
            element-loading-text="加载中"
            style="width: 100%;"
            :height="tableHeight"
            :header-cell-style="$tableHeaderColor"
          >
            <el-table-column type="index" width="50" align="center" label="序号"></el-table-column>
            <el-table-column prop="resultsName" label="成果名称"></el-table-column>
            <el-table-column prop="resultsType" label="成果类型">
              <template slot-scope="scope">
                <span>{{scope.row.resultsType | resultsType}}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="120">
              <template slot-scope="scope">
                <el-button
                  @click="$router.push(`/academicAchieve/achieveQuery/3/${scope.row.executionId}?resultsType=${scope.row.resultsType}`)"
                  type="text"
                  size="small"
                  v-if="scope.row.status == 1"
                >查看详情</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <my-pagination
            @paginate="handlePaginate"
            :pageSize="limitQuery.pageSize"
            :pageNum="limitQuery.pageNum"
            :msgCount="msgCount"
          ></my-pagination>
        </div>
        <div v-else>
          <xslw v-if="resultsType === '1'" :id="id" :executionId="executionId"></xslw>
          <jszl v-if="resultsType === '2'" :id="id" :executionId="executionId"></jszl>
          <fbzz v-if="resultsType === '3'" :id="id" :executionId="executionId"></fbzz>
          <kyxm v-if="resultsType === '4'" :id="id" :executionId="executionId"></kyxm>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import fbzz from '../achieveInput/components/fbzz'
import jszl from '../achieveInput/components/jszl'
import kyxm from '../achieveInput/components/kyxm'
import xslw from '../achieveInput/components/xslw'
import myPagination from '@/components/myPagination'
import myBreadcrumb from '@/components/myBreadcrumb'
export default {
  name: 'achieveQuery',
  props: {
    id: {},
    executionId: {}
  },
  data () {
    return {
      // 表格显示的数据
      tableData: [],
      // 数据加载状态
      loading: false,
      // 分页查询的参数
      limitQuery: {
        pageNum: 1,
        pageSize: 10,
        query: '',
        status: null
      },
      // 总条数
      msgCount: 0,
      // 学术成果类型可选列表
      genre: [
        {
          value: null,
          label: '全部成果类型'
        },
        {
          value: '1',
          label: '学术论文'
        },
        {
          value: '2',
          label: '技术专利'
        },
        {
          value: '3',
          label: '发表著作'
        },
        {
          value: '4',
          label: '科研项目'
        }
      ]
    }
  },
  created () {
    this.loadTable()
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 134
    }
  },
  components: {
    fbzz,
    jszl,
    kyxm,
    xslw,
    'my-pagination': myPagination,
    'my-breadcrumb': myBreadcrumb
    // applyStatus
  },
  methods: {
    // 导出的方法
    output () {
      console.log('导出。。。')
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },
    // 查询列表数据
    loadTable () {
      console.log(this.limitQuery)
      this.loading = true
      this.$http
        .post('/api/academic/aac/achievement', this.limitQuery)
        .then(res => {
          this.loading = false
          console.log(res)
          let data = res.data.data
          // 非空验证
          if (!data) {
            this.$message.error('获取个人学术成果列表数据失败，请重试')
            return
          }
          // 记录消息总数
          this.msgCount = data.total
          this.tableData = data.list
        })
    },
    detailStatus () {
      if (this.id === '3') {
        this.resultsType = this.$route.query.resultsType
        // 如果进入查看/修改详情页面，请求对应流程id的审核状态
        this.$http
          .get('/api/academic/aac/' + this.$route.params.executionId)
          .then(res => {
            let data = res.data.data
            if (!Array.isArray(data)) {
              this.$message.error('获取审核具体流程数据失败，请刷新重试')
              return
            }
            // 将审核具体流程数据发送给applyStatus
            this.$bus.$emit('stepList', data)
          })
      }
    }
  },
  created () {
    this.loadTable()
    this.detailStatus()
  },
  watch: {
    $route (to) {
      if (to.name === 'achieveQuery') {
        this.loadTable()
        this.detailStatus()
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.main {
  /deep/ .el-table th > .cell,
  /deep/ .el-table .cell {
    text-align: center;
    white-space: nowrap;
  }
  /deep/ .el-table--border th {
    border-right: 1px solid #e5e5e5;
  }

  .el-icon-document,
  .el-icon-d-arrow-left {
    margin-right: 5px;
    color: #409eff;
  }
  .box {
    // position: relative;
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
    .head {
      height: 60px;
      line-height: 40px;
      display: flex;
      justify-content: space-between;
      .header-title {
        font-size: 20px;
        font-weight: 500;
        color: $blue;
        margin-left: 5px;
        margin-right: 5px;
      }
      .block {
        font-size: 16px;
        width: 10px;
        height: 10px;
        background-color: $blue;
        display: inline-block;
      }
    }
    .btnGroup {
      display: flex;
      justify-content: left;
      padding: 5px;
      background: #f2f2f2;
      border: 1px solid #e5e5e5;
      .el-input {
        width: 200px;
      }
      .el-button {
        margin: 0 10px;
      }
    }
  }

  /deep/ .table-box {
    font-size: 14px;
    width: 100%;
    box-sizing: border-box;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        span {
          color: #1890ff;
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        .kh,
        .khdm {
          display: inline-block;
        }
        .kh {
          width: 45%;
          margin-right: 5px;
        }
        .khdm {
          width: 50%;
        }
        .qklb {
          width: 100%;
        }
        &.contentTd {
          background: #fff;
          padding: 0 10px;
        }
        .add {
          font-size: 24px;
          color: #1e6fd9;
          border-radius: 50%;
          padding-left: 20px;
          background: #fff;
          outline: none;
          border: none;
        }
        /deep/ .el-textarea__inner {
          font-size: 14px;
          color: #333;
        }
      }
    }
    .tx-msg {
      line-height: 30px;
      color: #ff5a5a;
    }
    .submitBtn {
      text-align: right;
    }
    [type="textarea"] {
      resize: none;
    }
  }
}
</style>
