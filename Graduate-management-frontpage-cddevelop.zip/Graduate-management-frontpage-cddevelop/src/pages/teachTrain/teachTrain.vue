<template>
    <div>
        <!-- 教学培养 teachTrain -->
        教学培养
    </div>
</template>

<script>
export default {
  name: 'teachTrain'
}
</script>

<style lang="scss" scoped>

</style>
