<template>
  <div class="apply-cet">
    <!-- 英语四六级报名 applyCET-->
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }">教学培养</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/teachTrain/applyCET/1'}">英语四六级报名</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
    </my-breadcrumb>
    <div v-if="flag">
       <my-blank msg="还不能四六级报名哦！" picUrl="blank.png"></my-blank>
     </div>
    <div class="box" v-else>
      <div class="apply-box">
        <div class="apply-title">
          <span>全国大学英语四六级等级考试报名</span>
        </div>
        <div class="card">
          <div class="card-top">
            <div class="left">
              <div style="margin-bottom:10px;">
                <span class="card-margin">姓&nbsp;&nbsp;名：</span>
                <span>{{ userInfo.xsxm }}</span>
              </div>
              <div style="margin-bottom:10px;">
                <span class="card-margin">学&nbsp;&nbsp;院：</span>
                <span>{{ userInfo.xymc }}</span>
              </div>
              <div style="margin-bottom:10px;">
                <span class="card-margin">年&nbsp;&nbsp;级：</span>
                <span>{{ userInfo.sznj }}</span>
              </div>
            </div>
            <div class="right">
              <div style="margin-bottom:10px;">
                <span class="card-margin">学&nbsp;&nbsp;号：</span>
                <span>{{ userInfo.xh }}</span>
              </div>
              <div style="margin-bottom:10px;">
                <span class="card-margin">专&nbsp;&nbsp;业：</span>
                <span>{{ userInfo.zy }}</span>
              </div>
              <div style="margin-bottom:10px;">
                <span class="card-margin">电&nbsp;&nbsp;话：</span>
                <span>{{ userInfo.dh }}</span>
              </div>
            </div>
          </div>
          <div class="card-bottom">
            <div>
              <el-select v-model="form" placeholder="全国大学英语等级考试" @change="handleSelect">
                <el-option
                  v-for="item in list"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </div>
            <div>
              <el-button
                type="primary"
                @click="handleSubmit"
                :disabled="(cet4Status && form === 1) || (cet6Status && form === 2)"
              >报名</el-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import myBreadcrumb from '@/components/myBreadcrumb'
import blank from '@/components/blank'
export default {
  name: 'applyCET',
  data () {
    return {
      list: [
        {
          value: 1,
          label: '全国大学英语四级等级考试'
        },
        {
          value: 2,
          label: '全国大学英语六级等级考试'
        }
      ],
      form: '',
      userInfo: {
        xsxm: '',
        xymc: '',
        sznj: '',
        xh: '',
        zy: '',
        dh: '',
        cet4:false,
        cet6:false
      },
      cet4Status: false,
      cet6Status: false,
      flag:true
    }
  },
  components: {
    'my-breadcrumb': myBreadcrumb,
    'my-blank': blank,
  },
  methods: {
    // 四六级报名
    handleSubmit () {
      if (this.form == '') {
        this.$message.error('请选择报名英语四级或六级！')
        return false
      }
      this.$http.post('/api/cultivate/cet/' + this.form).then(res => {
        // console.log(res.data);
        if (res.data.code === 200 || res.data.code === 400) {
          // 如果报名成功，或之前就已经报名就将对应的四六级状态改为true,按钮置灰
          if (this.form === 1) this.cet4Status = true
          else this.cet6Status = true
          if (res.data.code === 200) {
            this.$message.success('报名成功')
          } else {
            this.$message.warning('请勿重复报名')
          }
        } else {
          this.$message.error('报名失败')
        }
      })
    },
    handleSelect (val) {
      if(val == 1 && this.cet4Status == true){
        this.$message.warning('请勿重复报名')
      }else if(val == 2 && this.cet6Status == true){
        this.$message.warning('请勿重复报名')
      }
    },
    getInfo(){
      this.$http
        .get("/api/cultivate/cet").then(res=>{
          if(res.data.code == 200){
             this.userInfo = res.data.data
             this.cet4Status = this.userInfo.cet4
             this.cet46tatus = this.userInfo.cet6
          }else{
            this.$message.error(res.data.message)
          }
        })
    },
    kqgb(){
      this.$http.get('/api/cultivate/pycssz/checkOpenMain?key=cet').then((res) =>{
        if (res.data.data.isOpen == 1) {
          this.flag = false
        }else{
          this.flag = true
        }
      })
    }
  },
  created(){
    this.kqgb()
    this.getInfo()
  }
}
</script>

<style lang="scss" scoped>
.apply-cet {
  width:100%;
  min-height: calc(100vh - 250px);
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    box-sizing: border-box;
    padding-top: 10%;
    height: calc(100vh - 202px);
    overflow: auto;
  }
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.apply-box {
  text-align: center;
  width: 100%;
  .apply-title {
    font-size: 20px;
    font-weight: 500;
  }
  .card {
    width: 35%;
    max-width: 400px;
    // height: 300px;
    color: #606266;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    margin: auto;
    margin-top: 30px;
    padding: 30px 50px 50px;
    .card-top {
      display: flex;
      text-align: left;
      justify-content: space-between;
      .card-margin {
        // display: block;
        margin-right: 15px;
        // letter-spacing: 15px;
      }
    }
    .card-bottom {
      margin-top: 30px;
    }
  }
}
.card-bottom /deep/ .el-select {
  width: 60%;
  border-radius: 10px;
}
.card-bottom /deep/ .el-button {
  width: 60%;
  margin-top: 15px;
}
</style>
