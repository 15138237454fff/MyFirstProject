<template>
    <!-- 修改，课程调整 调整个人培养计划-->
    <div>
        <apply-adjust ref="child"></apply-adjust>
    </div>
</template>

<script>
import applyAdjust from './applyAdjust'
export default {
  name: 'applyRecord',
  components: {
    applyAdjust
  },
  data () {
    return {
      time: '2019/2/28',
      activeName: 'first',
      input: '',
      dynamicTags: ['课程一', '课程二'],
      inputVisible: false,
      inputValue: '',
      tableData: []
    }
  },
  created () {},
  methods: {
    handleClose (tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },
    showInput () {
      this.inputVisible = true
      this.$nextTick(() => {
        this.$refs.saveTagInput.$refs.input.focus()
      })
    },
    handleInputConfirm () {
      let inputValue = this.inputValue
      if (inputValue) {
        this.dynamicTags.push(inputValue)
      }
      this.inputVisible = false
      this.inputValue = ''
    },
    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.head {
    text-align: center;
    height: 50px;
    line-height: 50px;
    .left {
        // line-height: 63px;
        flex: 1;
    }
    .center {
        // line-height: 63px;
        .title {
            font-size: 20px;
            font-weight: 500;
            color: $blue;
            margin-left: 5px;
            margin-right: 5px;
        }
    }
}
.mark {
    color: $blue;
}
.block {
    font-size: 16px;
    width: 10px;
    height: 10px;
    background-color: $blue;
    display: inline-block;
}
.table-box {
    width: 100%;
    box-sizing: border-box;
    margin-top: $top;
    table {
        width: 100%;
        border-collapse: collapse;
        color: #333;
        font-size: 14px;
        border: none;
        border-color: rgba(228,228,228,1);
        td {
            width: 100px;
            &:nth-child(odd){
                background: #f2f2f2;
            }
        }
    }
}
.table-box1 {
    width: 100%;
    box-sizing: border-box;
    table {
        width: 100%;
        border-collapse: collapse;
        color: #333;
        font-size: 14px;
        border: none;
        border-color: rgba(228,228,228,1);
        td {
            width: 100px;
        }
    }
}
.timetable {
    border: 1px solid rgba(228,228,228,1);
    margin-top: 15px;
    .table-top {
        background: #f2f2f2;
        padding: 10px;
        margin-bottom: 15px;
        .sum-left {
            margin-left: 30px;
        }
        .sum-right {
            text-align: right;
            padding-right: 15px;
            box-sizing: border-box;
        }
        .sum-num {
            color: $blue;
        }
    }
}
.timetable /deep/ .el-tabs__nav {
    width: 100%;
}
.timetable /deep/ .el-tabs__item {
    width: 100px;
}
.timetable /deep/ .el-tabs__item {
    text-align: center;
}
</style>
