<template>
  <!-- 指定个人培养计划 调整后退回的个人培养计划-->
  <div
    class="inside"
    v-loading="loading"
    element-loading-text="加载中"
  >
    <div class="head" v-if="$route.params.id == 6">
      <div class="left">
        <pyjh-status :status="status"></pyjh-status>
      </div>
      <div class="center">
        <span class="block"></span>
        <span class="title">调整个人培养计划</span>
        <span class="block"></span>
      </div>
    </div>
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <tr>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>所属学院</td>
            <td>{{userInfo.yxsh}}</td>
          </tr>
          <tr>
            <td>所属专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>研究方向</td>
            <td>{{ userInfo.yjfx }}</td>
            <td>学制</td>
            <td>{{ userInfo.xz }}</td>
          </tr>
          <tr>
            <td>导师</td>
            <td>{{ userInfo.dsxm }}</td>
            <td>已选总学分</td>
            <td>{{ sum.zxf }}</td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="timetable">
      <el-tabs v-model="activeName">
        <el-tab-pane label="学位课" name="first">
          <xwk-save
            ref="child1"
            :math="sum.xwkmath"
            :min="sum.xwkmin"
            :list="tableData"
            :groupRequireMsg="groupRequireMsg"
            :checked="sum.xwknr"
            v-if="sum.xwkmath && sum.xwkmin && tableData && sum.xwknr"
            @listenChild="listenChild1"
          ></xwk-save>
        </el-tab-pane>
        <el-tab-pane label="选修课" name="second">
          <xxk-save
            ref="child2"
            :math="sum.xxkmath"
            :min="sum.xxkmin"
            :list="list2"
            :checked="sum.xxknr"
            v-if="sum.xxkmath && sum.xxkmin && list2 && sum.xxknr"
            @listenChild="listenChild2"
          ></xxk-save>
        </el-tab-pane>
        <el-tab-pane label="必修环节" name="third">
          <bxhj-save
            ref="child3"
            :math="sum.bxhjmath"
            :min="sum.bxhjmin"
            :list="list3"
            :checked="sum.bxhjnr"
            v-if="sum.bxhjmath && sum.bxhjmin && list3 && sum.bxhjnr"
            @listenChild="listenChild3"
          ></bxhj-save>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <tr>
            <td colspan="6">更改原因</td>
          </tr>
          <tr>
            <td style="background: #fff;padding:0;" colspan="6">
              <el-input
                type="textarea"
                :autosize="{ minRows:8, maxRows: 12}"
                placeholder="请输入内容"
                v-model="ggyy"
                style="width:100%"
              ></el-input>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="exit"></div>
    <apply-status-bottom
      v-show="this.$route.params.id == 6"
      ref="applyStatus"
    ></apply-status-bottom>
  </div>
</template>

<script>
import xwkSave from "./xwkSave";
import xxkSave from "./xxkSave";
import bxhjSave from "./bxhjSave";
import pyjhStatus from "@/components/pyjhStatus";
import applyStatusBottom from "@/components/applyStatusBottom";

export default {
  name: "applyBack",
  components: {
    xwkSave,
    xxkSave,
    bxhjSave,
    pyjhStatus,
    applyStatusBottom
  },
  data() {
    return {
      loading: false,
      flag: false,
      time: "2019/2/28",
      activeName: "first",
      pyfaId: 0,
      tableData: [],
      groupRequireMsg: [], // 课程组需求列表
      status: "",
      userInfo: {},
      kchList: [], // 请求计划外课程传递课程号参数
      auditList: {}, // 审核流程图
      list1: {}, // 学位课列表
      list2: {}, // 选修课列表
      list3: {}, // 必修环节列表
      yxzxf1: 0,
      yxzxf2: 0,
      yxzxf3: 0,
      yxzxf4: 0,
      id: "",
      lcid: "",
      sum: {
        zxf: 0,
        xwkmath: "",
        xwkmin: "",
        xwknr: "",
        xwkms: 0,
        xwkxf: 0,
        xwkxs: 0,
        xxkmath: "",
        xxkmin: "",
        xxknr: "",
        bxhjmath: "",
        bxhjmin: "",
        bxhjnr: ""
      },
      zttype:'',
      ggyy:'',
      ywid:'',
      listArr:[]//所有已勾选的数据
    };
  },
  created() {},
  mounted() {
    if (this.$route.path == "/teachTrain/personalPlan/6") {
      this.getData();
    }
    this.$http.get("/api/cultivate/pyjhtz/selectInfoForChange").then(res => {
      // this.listArr = res.data.data;
      res.data.data.forEach((el) =>{
        this.listArr.push(el.id)
      })
    });
  },
  watch: {
    $route(to) {
      if (to.path == "/teachTrain/personalPlan/6") {
        this.getData();
      }
    }
  },
  methods: {
    listenChild1(data) {
      this.yxzxf1 = data;
      this.sum.zxf = (
        Number(this.yxzxf1) +
        Number(this.yxzxf2) +
        Number(this.yxzxf3)
      ).toFixed(1);
    },
    listenChild2(data) {
      this.yxzxf2 = data;
      this.sum.zxf = (
        Number(this.yxzxf1) +
        Number(this.yxzxf2) +
        Number(this.yxzxf3)
      ).toFixed(1);
    },
    listenChild3(data) {
      this.yxzxf3 = data;
      this.sum.zxf = (
        Number(this.yxzxf1) +
        Number(this.yxzxf2) +
        Number(this.yxzxf3)
      ).toFixed(1);
    },
    getData() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/pyjhtz/selectInfo")
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          this.userInfo = data.xsGrpyjhbsqListVo.xsGrpyjhbsqVo;
          this.auditList = data.list;
          this.$store.state.auditList = this.auditList;
          this.$bus.$emit("stepList", this.auditList);

          this.sum.zxf = data.kctzjlb.zxf;
          this.status = data.kctzjlb.zt;
          this.id = data.kctzjlb.id;
          this.lcid = data.kctzjlb.lcid;
          this.ggyy = data.kctzjlb.ggyy;
          this.ywid = data.kctzjlb.ywid;

          this.sum.xwkmath = data.kctzjlb.xwkmath.split(",");
          this.sum.xxkmath = data.kctzjlb.xxkmath.split(",");
          this.sum.bxhjmath = data.kctzjlb.bxhjmath.split(",");

          this.sum.xwkmin = data.xsGrpyjhbsqListVo.xsGrpyjhbsqVo.xwkMin;
          this.sum.xxkmin = data.xsGrpyjhbsqListVo.xsGrpyjhbsqVo.xxkMin;
          this.sum.bxhjmin = data.xsGrpyjhbsqListVo.xsGrpyjhbsqVo.bxhjMin;

          this.kchList = data.xsGrpyjhbsqListVo.xsGrpyjhbsqVo.kchList;
          this.pyfaId = data.xsGrpyjhbsqListVo.xsGrpyjhbsqVo.pyfaid;
          
          this.sum.xwknr = data.kctzjlb.xwknr.split(",");
          this.sum.xxknr = data.kctzjlb.xxknr.split(",");
          this.sum.bxhjnr = data.kctzjlb.bxhjnr.split(",");
          this.list1 = data.xsGrpyjhbsqListVo.xsXwkListVo;
          this.list2 = data.xsGrpyjhbsqListVo.xxkList;
          this.list2.forEach(el => {
          this.sum.xxknr.forEach((Element)=>{
            let indexof = this.listArr.find((item)=>item === Element)
            if(el.kcid === indexof){
               el.bxkDisable = true;
            }
          })
        });
          console.log(this.sum.xxknr,'选修课')
          this.list3 = data.xsGrpyjhbsqListVo.bxhjList;
          // 对学位课课程进行处理
          this.getList();
        });
    },
    // 对学位课处理的方法
    getList() {
      this.tableData = [];
      this.list1.outGroupList.forEach(el => {
        el.bxkDisable = true;
      });
      this.tableData = this.list1.outGroupList;
      this.list1.inGroupList.map(item => {
        //循环学位课课程组中的数据
        item.list.map(item1 => {
          this.sum.xwknr.forEach((Element)=>{
            let indexof = this.listArr.find((item)=>item === Element)
            if(item1.kcid === indexof){
               item1.bxkDisable = true;
            }
          })
          item.list[0].rowspan = this.tableData.length;
          item1.min = item.min;
          item1.rowspan = 0;
          console.log(this.sum.xwknr,'xwksv')
          // 用mark记录之前的课程组名
          item1.mark = item1.kcz;
          item1.kcz = `最少选择${item.min}门`;
          // console.log(this.groupRequireMsg)
          // 如果需求不存在
          if (
            this.groupRequireMsg.every(el => {
              return el.group !== item1.mark;
            })
          ) {
            // 添加需求
            this.groupRequireMsg.push({ group: item1.mark, count: item1.min });
          }
          return this.tableData.push(item1);
        });
      });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  .left {
    // line-height: 63px;
    flex: 1;
    overflow: hidden;
    margin-top: -17px;
    margin-left: -16px;
  }
  .center {
    flex: 1.5;
    // line-height: 63px;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  margin-top: $top;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    padding: 10px;
    margin-bottom: 15px;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.timetable /deep/ .el-tabs__nav {
  width: 100%;
}
.timetable /deep/ .el-tabs__item {
  width: 100px;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
.inside /deep/ .el-loading-spinner i {
  font-size: 25px;
}
</style>
