<template>
  <!-- 指定个人培养计划查看详情 审核中  通过的状态-->
  <div>
    <div class="inside-box" v-show="loading"></div>
    <div class="inside" v-show="!loading">
      <div class="head" v-if="$route.params.id == 2">
        <div class="left">
          <pyjh-status :status="status"></pyjh-status>
        </div>
        <div class="center">
          <span class="block"></span>
          <span class="title">个人培养计划</span>
          <span class="block"></span>
        </div>
      </div>
      <div class="table-box">
        <table border="1" cellspacing="0" cellpadding="10">
          <thead></thead>
          <tbody>
            <tr>
              <td>学号</td>
              <td>{{ userInfo.xh }}</td>
              <td>姓名</td>
              <td>{{ userInfo.xm }}</td>
              <td>学院</td>
              <td>{{ userInfo.yxsh }}</td>
            </tr>
            <tr>
              <td>专业</td>
              <td>{{ userInfo.zy }}</td>
              <td>研究方向</td>
              <td>{{ userInfo.yjfx }}</td>
              <td>学制</td>
              <td>{{ userInfo.xz }}</td>
            </tr>
            <tr>
              <td>导师</td>
              <td>{{ userInfo.dsxm }}</td>
              <td>已选总学分</td>
              <td>{{ sum.zxf }}</td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="timetable">
        <el-tabs v-model="activeName">
          <el-tab-pane label="学位课" name="first">
            <xwk-detail
              :math="sum.xwkmath"
              :min="sum.xwkmin"
              :list="list1"
              v-if="sum.xwkmath && sum.xwkmin && list1"
            ></xwk-detail>
          </el-tab-pane>
          <el-tab-pane label="选修课" name="second">
            <xxk-detail
              :math="sum.xxkmath"
              :min="sum.xxkmin"
              :list="list2"
              v-if="sum.xxkmath && sum.xxkmin && list2"
            ></xxk-detail>
          </el-tab-pane>
          <el-tab-pane label="必修环节" name="third">
            <bxhj-detail
              :math="sum.bxhjmath"
              :min="sum.bxhjmin"
              :list="list3"
              v-if="sum.bxhjmath && sum.bxhjmin && list3"
            ></bxhj-detail>
          </el-tab-pane>
        </el-tabs>
      </div>
      <apply-status-bottom
        v-show="this.$route.params.id == 2 || this.$route.params.id == 3"
        ref="applyStatus"
      ></apply-status-bottom>
    </div>
  </div>
</template>

<script>
import xwkDetail from "./xwkDetail";
import xxkDetail from "./xxkDetail";
import bxhjDetail from "./bxhjDetail";

import pyjhStatus from "@/components/pyjhStatus";
import applyStatusBottom from "@/components/applyStatusBottom";

export default {
  name: "applySave",
  props: ["lcid"],
  components: {
    xwkDetail,
    xxkDetail,
    bxhjDetail,
    pyjhStatus,
    applyStatusBottom
  },
  data() {
    return {
      loading: true,
      time: "2019/2/28",
      activeName: "first",
      tableData: [],
      status: "",
      shzt: "",
      tzlcid: "",
      userInfo: {},
      auditList: {}, // 审核流程图
      list1: {}, // 学位课列表
      list2: {}, // 选修课列表
      list3: {}, // 必修环节列表
      sum: {
        zxf: 0,
        xwkmath: "",
        xwkmin: "",
        xwkms: 0,
        xwkxf: 0,
        xwkxs: 0,
        xxkmath: "",
        xxkmin: "",
        bxhjmath: "",
        bxhjmin: ""
      }
    };
  },
  mounted() {
    console.log("init");
    this.getData();
  },
  methods: {
    // 初始化信息

    getData() {
      const applyDetailLoading = this.$loading({
        target: document.querySelector(".inside-box")
      });
      let xh;
      // 学生
      if (this.$store.getters.getStatus == 1) {
        xh = this.$store.getters.getXH;
      } else {
        // 老师
        xh = this.$route.query.xh;
      }
      this.$http
        .get("/api/cultivate/pygrpyjhb/infoByLcid2", {
          params: { xh }
        })
        .then(res => {
          this.loading = false;
          applyDetailLoading.close();
          this.shzt = res.data.data.status;
          this.tzlcid = res.data.data.lcid;
          // console.log(this.tzlcid,'ddddd')
          this.$bus.$emit("shzt", this.shzt);
          this.$bus.$emit("tzlcid", this.tzlcid);
          let data = res.data.data;
          this.userInfo = data.xsGrpyjhbsqVo;
          this.status = data.xsGrpyjhbsqVo.zt;
          // console.log(this.status,'状态')
          this.sum.zxf = data.xsGrpyjhbsqVo.zxf;

          this.sum.xwkmath = data.xsGrpyjhbsqVo.xwkmath.split(",");
          this.sum.xxkmath = data.xsGrpyjhbsqVo.xxkmath.split(",");
          this.sum.bxhjmath = data.xsGrpyjhbsqVo.bxhjmath.split(",");
          this.sum.xwkmin = data.xsGrpyjhbsqVo.xwkMin;
          this.sum.xxkmin = data.xsGrpyjhbsqVo.xxkMin;
          this.sum.bxhjmin = data.xsGrpyjhbsqVo.bxhjMin;

          this.list1 = data.xwkList;
          this.list2 = data.xxkList;
          this.list3 = data.bxhjList;
        })
        .catch(err => {
          this.loading = false;
        });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.inside-box {
  width: 100%;
  min-height: calc(100vh - 250px);
}
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  .left {
    // line-height: 63px;
    flex: 1;
    overflow: hidden;
    margin-top: -17px;
    margin-left: -16px;
  }
  .center {
    flex: 1.5;
    // line-height: 63px;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  margin-top: $top;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    padding: 10px;
    margin-bottom: 15px;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.timetable /deep/ .el-tabs__nav {
  width: 100%;
}
.timetable /deep/ .el-tabs__item {
  width: 100px;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
</style>
