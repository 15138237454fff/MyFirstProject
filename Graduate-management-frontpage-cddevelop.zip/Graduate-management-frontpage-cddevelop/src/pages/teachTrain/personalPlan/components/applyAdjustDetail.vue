<template>
  <!-- 课程调整查看详情  课程调整 -->
  <div class="inside">
    <div class="head">
      <div class="center">
        <span class="block"></span>
        <span class="title">个人培养计划</span>
        <span class="block"></span>
      </div>
    </div>
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <tr>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>所属学院</td>
            <td>{{userInfo.yxsh}}</td>
          </tr>
          <tr>
            <td>所属专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>研究方向</td>
            <td>{{ userInfo.yjfx }}</td>
            <td>学制</td>
            <td>{{ userInfo.xz }}</td>
          </tr>
          <tr>
            <td>导师</td>
            <td>{{ userInfo.dsxm }}</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="table-box1">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <tr style="background: #f2f2f2">
            <td></td>
            <td style="width:200px">课程名称</td>
            <td>课程号</td>
            <td>开课单位</td>
            <td>性质</td>
            <td>学分</td>
            <td>学时</td>
            <td>开课学期</td>
          </tr>
          <tr>
            <td>原计划课程</td>
            <td>{{ userInfo.kcmc }}</td>
            <td>{{ userInfo.kch }}</td>
            <td>{{ userInfo.dwmc }}</td>
            <td>{{ userInfo.kcxzh }}</td>
            <td>{{ userInfo.xf }}</td>
            <td>{{ userInfo.zxs }}</td>
            <td>{{ userInfo.kkxq }}</td>
          </tr>
          <tr>
            <td>现更改课程</td>
            <td>{{ userInfo.kcmc }}</td>
            <td>{{ userInfo.kch }}</td>
            <td>{{ userInfo.dwmc }}</td>
            <td>{{ userInfo.type }}</td>
            <td>{{ userInfo.xf }}</td>
            <td>{{ userInfo.zxs }}</td>
            <td>{{ userInfo.kkxq }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <tr>
            <td colspan="6">更改原因</td>
          </tr>
          <tr>
            <td style="background: #fff">
              <el-input
                type="textarea"
                :autosize="{ minRows: 6, maxRows: 8}"
                placeholder="请输入内容"
                v-model="userInfo.ggyy"
              ></el-input>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: 'applyAdjust',
  data () {
    return {
      userInfo: {},
      list: [],
      value: '',
      newValue: '',
      val: '',
      val2: '',
      options: [],
      newOptions: [],
      oldOption: {},
      newOption: {},
      newCourse: {
        faId: '',
        kcsxh: '',
        nr: ''
      },
      writeInfo: {
        ggyy: '',
        min: '',
        nr: '',
        type: '',
        yjhkc: '',
        xggkc: ''
      },
      time: '2019/2/28',
      activeName: 'first',
      input: '',
      dynamicTags: ['课程一', '课程二'],
      inputVisible: false,
      inputValue: '',
      tableData: []
    }
  },
  created () {},
  mounted () {
    this.getData()
  },
  methods: {
    getData () {
      this.$http.get('/api/cultivate/kctz/init').then(res => {
        let data = res.data.data
        // console.log(data)
        this.userInfo = data
      })
    },
    selectChange2 () {
      this.newOption = this.newOptions.find(item => {
        return item.kcmc == this.newValue
      })
      // //console.log(this.newOption)
    },
    selectClear2 () {
      this.newOption = {}
    },
    handleClose (tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },
    showInput () {
      this.inputVisible = true
      this.$nextTick(() => {
        this.$refs.saveTagInput.$refs.input.focus()
      })
    },
    handleInputConfirm () {
      let inputValue = this.inputValue
      if (inputValue) {
        this.dynamicTags.push(inputValue)
      }
      this.inputVisible = false
      this.inputValue = ''
    },
    // 自定义table表头颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return 'background-color:#f2f2f2;font-weight:500'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.head {
  text-align: center;
  height: 50px;
  line-height: 50px;
  .left {
    // line-height: 63px;
    flex: 1;
  }
  .center {
    // line-height: 63px;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 10px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  margin-top: $top;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.table-box1 {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
    }
  }
}
.table-box1 /deep/ .el-select {
  width: 100%;
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    padding: 10px;
    margin-bottom: 15px;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.timetable /deep/ .el-tabs__nav {
  width: 100%;
}
.timetable /deep/ .el-tabs__item {
  width: 100px;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
</style>
