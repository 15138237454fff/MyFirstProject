<template>
  <!-- 学位课 -->
  <div class>
    <div class="table-top">
      <el-row>
        <el-col :span="17">
          <span style="margin-left: 15px">已选门数:</span>
          <span class="sum-num">{{ sum.yxms }}</span>
          <span class="sum-left">已选学分:</span>
          <span class="sum-num">{{ sum.yxxf }}</span>
          <span class="sum-left">已选学时:</span>
          <span class="sum-num">{{ sum.yxxs }}</span>
        </el-col>
        <el-col :span="7" class="sum-right">
          <span>需完成学分</span>
          <span class="sum-num">{{ `>=${total}` }}</span>
        </el-col>
      </el-row>
    </div>
    <el-table
      :data="tableData"
      ref="xwkTable"
      border
      :header-cell-style="tableHeaderColor"
      :span-method="objectSpanMethod"
      @selection-change="handleSelectionChange"
    >
      <!-- <el-table-column prop="kch" label="课程号" align="center"></el-table-column> -->
      <el-table-column
        prop="kcmc"
        label="课程名称"
        align="center"
        width="200"
      ></el-table-column>
      <el-table-column prop="xf" label="学分" align="center"></el-table-column>
      <el-table-column prop="zxs" label="学时" align="center"></el-table-column>
      <el-table-column
        prop="kkxq"
        label="开课学期"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="kcsxh"
        label="课程属性"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="ksxs"
        label="考试形式"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="tgcj"
        label="通过成绩"
        align="center"
      ></el-table-column>
      <el-table-column prop="kcz" label="课程组" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.kcz }}</span>
        </template>
      </el-table-column>
      <el-table-column
        type="selection"
        width="50"
        :selectable="handleDisable"
      ></el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: "xwk",
  components: {},
  props: ["list", "total"],
  data() {
    return {
      tableData: [],
      // 课程组选择是否符合需求
      groupSelectRequire: false,
      pageHelp: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      // 分页
      pageList: {
        pageNum: null,
        pageSize: null,
        total: null,
        pages: null
      },
      // 合计学分学时
      sum: {
        total: 22.5,
        yxms: 0,
        msList: [],
        yxxf: 0,
        xfList: [],
        yxxs: 0,
        xsList: [],
        kcidList: [],
        kcid: ""
      },
      groupRequireMsg: [], // 课程组需求列表
      copySel: [],
      copySel1: [],
      xwkSave: {
        xwkmath: "",
        xwknr: ""
      },
      tmpList: []
    };
  },
  mounted() {},
  methods: {
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 学位课列表加载
    getList() {
      let data = this.list;
      data.outGroupList.forEach(el => {
        el.bxkDisable = true;
      });
      this.tableData = data.outGroupList;
      data.inGroupList.map(item => {
        item.list.map(item1 => {
          item.list[0].rowspan = item.list.length;
          item1.min = item.min;
          item1.rowspan = 0;
          // 用mark记录之前的课程组名
          item1.mark = item1.kcz;
          item1.kcz = `最少选择${item.min}门`;
          // 如果需求不存在
          if (
            this.groupRequireMsg.every(el => {
              return el.group !== item1.mark;
            })
          ) {
            // 添加需求
            this.groupRequireMsg.push({ group: item1.mark, count: item1.min });
          }
          return this.tableData.push(item1);
        });
      });
      // 自动勾选必选的学位课
      this.tableData
        .filter(el => el.bxkDisable)
        .forEach(el => {
          this.$nextTick(() => {
            this.$refs.xwkTable.toggleRowSelection(el, true);
          });
        });
    },

    // 列表选择改变事件
    handleSelectionChange(selection) {
      this.tmpList = selection;
      // 检查课程组是否符合要求
      this.checkGroup(selection);
      this.copySel = selection;
      this.copySel1 = selection;
      if (selection.length == 0) {
        this.sum.yxms = 0;
        this.sum.yxxf = 0;
        this.sum.yxxs = 0;
        this.sum.kcid = "";
        this.xwkSave.xwkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.xwkSave.xwknr = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
      }
      if (selection.length == 1) {
        this.sum.yxms = selection.length;
        this.sum.yxxf = selection[0].xf;
        this.sum.yxxs = selection[0].zxs;
        this.sum.kcid = selection[0].kcid;
        this.xwkSave.xwkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.xwkSave.xwknr = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
      }
      if (selection.length > 1) {
        this.sum.xfList = selection.map(item => {
          return Number(item.xf);
        });
        this.sum.xsList = selection.map(item => {
          return Number(item.zxs);
        });
        this.sum.kcidList = selection.map(item => {
          return item.kcid;
        });
        this.sum.yxms = selection.length;
        this.sum.yxxf = this.sumArr1(this.sum.xfList);
        this.sum.yxxs = this.sumArr1(this.sum.xsList);
        this.sum.kcid = this.sum.kcidList.join(",");
        this.xwkSave.xwkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.xwkSave.xwknr = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
      }
    },
    // 检查课程组的选择是否满足要求
    checkGroup(selection) {
      // 临时的状态为true
      let tmpSign = true;
      // 遍历需求数组
      this.groupRequireMsg.forEach(el => {
        // 取出当前需求的课程组号
        let group = el.group;
        // 统计当前选中该组号的课程数
        let count = selection.filter(obj => {
          return obj.mark === group;
        });
        count = count.length;
        // 如果选中的课程数少于需求的数量
        if (count < el.count) {
          // 不满足
          tmpSign = false;
        }
      });
      // 将需求的状态保存
      this.groupSelectRequire = tmpSign;
    },
    // 求和,
    // reduce方法有两个参数，一个是callback回调函数，二是设置prev的初始类型和初始值
    sumArr(arr) {
      return arr.reduce((prev, cur) => {
        return prev + cur;
      }, 0);
    },
    sumArr1(arr) {
      let sum = 0;
      arr.forEach(val => {
        sum += val;
      });
      // 保留小数点后面几位小数
      return sum.toFixed(1);
    },
    // selectable参数可以手动设置某些表格行不可选择
    // 有两个参数返回，表格的每一行对象和当前索引,true可选 false不可选
    handleDisable(row) {
      if (row.bxkDisable) {
        return false;
      } else {
        return true;
      }
    },
    // 提交
    handleSubmit() {
      this.xwkSave.xwkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
      this.xwkSave.xwknr = this.sum.kcid;
    },
    // 表格合并行或列
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      // 行，列，行号，列号
      if (columnIndex == 7) {
        let kczList = [];
        kczList.push(row.kcz);
        if (row.rowspan) {
          return {
            rowspan: row.rowspan,
            colspan: 1
          };
        } else if (row.rowspan == 0) {
          return {
            rowspan: 0,
            colspan: 0
          };
        }
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    height: 40px;
    line-height: 40px;
    margin-bottom: $top;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.bottom-submit {
  text-align: right;
  margin-top: 15px;
  margin-bottom: 15px;
  margin-right: 15px;
}
</style>
