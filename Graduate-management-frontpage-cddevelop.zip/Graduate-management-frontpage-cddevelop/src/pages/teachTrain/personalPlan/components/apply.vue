<template>
  <!-- 指定个人培养计划 第一次提交个人培养计划-->
  <div class="inside" v-loading="loading" element-loading-text="加载中">
    <div v-if="flag">
      <my-blank msg="还不可制定培养方案哦！" picUrl="blank.png"></my-blank>
    </div>
    <div v-else>
      <div class="head">
        <div class="left">
          请于
          <span class="mark">{{ time }}</span>
          前完成制定培养计划
        </div>
        <div class="center">
          <span class="block"></span>
          <span class="title">个人培养计划</span>
          <span class="block"></span>
        </div>
      </div>
      <div class="table-box">
        <table border="1" cellspacing="0" cellpadding="10">
          <thead></thead>
          <tbody>
            <tr>
              <td>学号</td>
              <td>{{ userInfo.xh }}</td>
              <td>姓名</td>
              <td>{{ userInfo.xm }}</td>
              <td>所属学院</td>
              <td>{{ userInfo.yxsh }}</td>
            </tr>
            <tr>
              <td>所属专业</td>
              <td>{{ userInfo.zy }}</td>
              <td>研究方向</td>
              <td>{{ userInfo.yjfx }}</td>
              <td>学制</td>
              <td>{{ userInfo.xz }}</td>
            </tr>
            <tr>
              <td>导师</td>
              <td>{{ userInfo.dsxm }}</td>
              <td>已选总学分</td>
              <td>{{ yxzxf }}</td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="timetable">
        <el-tabs v-model="activeName" @tab-click="tabClick">
          <el-tab-pane label="学位课" name="first">
            <xwk
              ref="child1"
              :list="xwkList"
              :total="total1"
              @listenChild="listenChild1"
            ></xwk>
          </el-tab-pane>
          <el-tab-pane label="选修课" name="second">
            <xxk
              ref="child2"
              :list="xxkList"
              :total="total2"
              @listenChild="listenChild2"
            ></xxk>
          </el-tab-pane>
          <el-tab-pane label="必修环节" name="third">
            <bxhj
              ref="child3"
              :list="bxhjList"
              :total="total3"
              @listenChild="listenChild3"
            ></bxhj>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import xwk from "./xwk";
import xxk from "./xxk";
import bxhj from "./bxhj";
import blank from "@/components/blank";

export default {
  name: "apply",
  components: {
    xwk,
    xxk,
    bxhj,
    "my-blank": blank
  },
  props: ["time"],
  computed: {
    yxzxfFilter() {
      return (
        Number(this.$refs.child1.sum.yxxf) +
        Number(this.$refs.child2.sum.yxxf) +
        Number(this.$refs.child3.sum.yxxf)
      ).toFixed(1);
    }
  },
  data() {
    return {
      flag: false,
      loading: false,
      // time: "2019/2/28",
      activeName: "first",
      pyfaId: 0,
      yxzxf: 0,
      yxzxf1: 0,
      yxzxf2: 0,
      yxzxf3: 0,
      // yxzxf4: 0,
      tableData: [],
      id: "",
      userInfo: {},
      xwkList: [], // 学位课
      xxkList: [], // 选修课
      bxhjList: [], // 必修环节
      total1: 0, // 学位课需完成学分
      total2: 0, // 选修课需完成学分
      total3: 0, // 必修环节需完成学分
      // 列表分页传参
      pageHelp: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      // 分页
      pageList: {
        pageNum: null,
        pageSize: null,
        total: null,
        pages: null
      },
      spanArr: [],
      position: 0
    };
  },
  created() {},
  mounted() {
    if (this.$route.path === "/teachTrain/personalPlan/1") this.getData();
  },
  methods: {
    listenChild1(data) {
      this.yxzxf1 = data;
      this.yxzxf = (
        Number(this.yxzxf1) +
        Number(this.yxzxf2) +
        Number(this.yxzxf3)
      ).toFixed(1);
    },
    listenChild2(data) {
      this.yxzxf2 = data;
      this.yxzxf = (
        Number(this.yxzxf1) +
        Number(this.yxzxf2) +
        Number(this.yxzxf3)
      ).toFixed(1);
    },
    listenChild3(data) {
      this.yxzxf3 = data;
      this.yxzxf = (
        Number(this.yxzxf1) +
        Number(this.yxzxf2) +
        Number(this.yxzxf3)
      ).toFixed(1);
    },
    tabClick(t) {
      this.handleSwitch(t);
    },
    handleSwitch(t) {
      switch (t.name) {
        case "first":
          this.tabName = "first";
          break;
        case "second":
          this.tabName = "second";
          break;
        case "third":
          this.tabName = "third";
          break;
      }
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 初始化信息
    getData() {
      // this.loading = true
      this.$http.get("/api/cultivate/pygrpyjhb/kcList").then(res => {
        this.loading = false;
        let data = res.data.data;
        sessionStorage.setItem("zt", data.xsGrpyjhbsqVo);
        if (data.xsGrpyjhbsqVo == null) {
          this.flag = true;
          return;
        }
        this.userInfo = data.xsGrpyjhbsqVo;
        this.total1 = data.xsGrpyjhbsqVo.xwkMin;
        this.total2 = data.xsGrpyjhbsqVo.xxkMin;
        this.total3 = data.xsGrpyjhbsqVo.bxhjMin;
        this.pyfaId = data.xsGrpyjhbsqVo.pyfaid;
        this.xwkList = data.xsXwkListVo;
        this.xxkList = data.xxkList;
        this.bxhjList = data.bxhjList;
        this.$nextTick(() => {
          this.$refs.child1.getList();
        });
      });
    },
    // 提交   //不包含计划外课程的提交 改变之后
    handleSubmit() {
      this.yxzxf = `${Number(this.$refs.child1.sum.yxxf) +
        Number(this.$refs.child2.sum.yxxf) +
        Number(this.$refs.child3.sum.yxxf)}`;
    }
  }
};
</script>

<style lang="scss" scoped>
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  .left {
    // line-height: 63px;
    flex: 1;
  }
  .center {
    flex: 1.5;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  margin-top: $top;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    padding: 10px;
    margin-bottom: 15px;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.timetable /deep/ .el-tabs__nav {
  width: 100%;
}
.timetable /deep/ .el-tabs__item {
  width: 100px;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
</style>
