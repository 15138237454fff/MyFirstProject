<template>
  <!-- 选修课退回修改 -->
  <div class>
    <div class="table-top">
      <el-row>
        <el-col :span="17">
          <span style="margin-left: 15px">已选门数:</span>
          <span class="sum-num">{{ sum.yxms }}</span>
          <span class="sum-left">已选学分:</span>
          <span class="sum-num">{{ sum.yxxf }}</span>
          <span class="sum-left">已选学时:</span>
          <span class="sum-num">{{ sum.yxxs }}</span>
        </el-col>
        <el-col :span="7" class="sum-right">
          <span>需完成学分</span>
          <span class="sum-num">{{ `>=${min}` }}</span>
        </el-col>
      </el-row>
    </div>
    <el-table
      :data="list"
      ref="tableCheck"
      border
      :header-cell-style="tableHeaderColor"
      @row-click="clickRow"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        label="序号"
        width="50"
        align="center"
        type="index"
        :index="indexMethod"
      ></el-table-column>
      <!-- <el-table-column prop="kch" label="课程号" align="center"></el-table-column> -->
      <el-table-column
        prop="kcmc"
        label="课程名称"
        align="center"
      ></el-table-column>
      <el-table-column prop="xf" label="学分" align="center"></el-table-column>
      <el-table-column prop="zxs" label="学时" align="center"></el-table-column>
      <el-table-column
        prop="kkxq"
        label="开课学期"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="kcsxh"
        label="课程属性"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="ksxs"
        label="考试形式"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="tgcj"
        label="通过成绩"
        align="center"
      ></el-table-column>
      <el-table-column
        prop="total"
        label="计划人数"
        align="center"
      ></el-table-column>
      <el-table-column
        type="selection"
        width="50"
        :selectable="handleDisable"
      ></el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: "xxkSave",
  components: {},
  props: ["list", "math", "min", "checked"],
  data() {
    return {
      currentPage: 1, // 当前页
      pageSize: 10, // 分页中每页显示条数
      list1: [],
      listFilter: [],
      pageHelp: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      // 分页
      pageList: {
        pageNum: null,
        pageSize: null,
        total: null,
        pages: null
      },
      // 合计学分学时
      sum: {
        total: 22.5,
        yxms: 0,
        msList: [],
        yxxf: 0,
        xfList: [],
        yxxs: 0,
        xsList: [],
        kcidList: [],
        kcid: ""
      },
      xxkSave: {
        xxkmath: "",
        xxknr: ""
      }
    };
  },
  mounted() {
    this.getData();
    this.getChecked();
  },
  watch: {
    $route(to) {}
  },
  computed: {},
  methods: {
    getList1() {
      this.list1 =
        this.list == undefined
          ? []
          : this.list.slice(
              (this.currentPage - 1) * this.pageSize,
              this.currentPage * this.pageSize
            );
    },
    // 改变列表页条数大小回调函数
    handleSizeChange(val) {
      this.pageSize = val;
      this.getList1();
    },
    // 改变列表页当前页回调函数
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage;
      this.getList1();
    },
    // 列表序号
    indexMethod(index) {
      return (this.currentPage - 1) * this.pageSize + index + 1;
    },
    // 获取列表头部数据
    getData() {
      this.sum.yxms = this.math[0];
      this.sum.yxxf = this.math[1];
      this.sum.yxxs = this.math[2];
    },
    getChecked() {
      // console.log(this.checked)
      let listFilter = [];
      this.list.filter(item => {
        this.checked.filter(v => {
          if (item.kcid == v) {
            listFilter.push(item);
          }
        });
      });
      this.toggleSelection(listFilter);
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          // console.log(99999999)
          this.$refs.tableCheck.toggleRowSelection(row);
        });
      } else {
        this.$refs.tableCheck.clearSelection();
      }
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 列表选择改变事件
    handleSelectionChange(selection) {
      // console.log(event)
      // console.log(selection)
      this.copySel = selection;
      this.copySel1 = selection;
      if (selection.length == 0) {
        this.sum.yxms = 0;
        this.sum.yxxf = 0;
        this.sum.yxxs = 0;
        this.sum.kcid = "";
        this.xxkSave.xxkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.xxkSave.xxknr = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
      }
      if (selection.length == 1) {
        this.sum.yxms = selection.length;
        this.sum.yxxf = selection[0].xf;
        this.sum.yxxs = selection[0].zxs;
        this.sum.kcid = selection[0].kcid;
        this.xxkSave.xxkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.xxkSave.xxknr = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
      }
      if (selection.length > 1) {
        this.sum.xfList = selection.map(item => {
          return Number(item.xf);
        });
        this.sum.xsList = selection.map(item => {
          return Number(item.zxs);
        });
        this.sum.kcidList = selection.map(item => {
          return item.kcid;
        });
        this.sum.yxms = selection.length;
        this.sum.yxxf = this.sumArr1(this.sum.xfList);
        this.sum.yxxs = this.sumArr1(this.sum.xsList);
        this.sum.kcid = this.sum.kcidList.join(",");
        this.xxkSave.xxkmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.xxkSave.xxknr = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
      }
    },
    sumArr1(arr) {
      let sum = 0;
      arr.forEach(val => {
        sum += val;
      });
      // 保留小数点后面几位小数
      return sum.toFixed(1);
    },
    // 点击列表选中
    clickRow(row) {
      // console.log(row.kcid)
      this.$refs.tableCheck.toggleRowSelection(row);
    },
    handleDisable(row) {
      if (row.bxkDisable) {
        return false;
      } else {
        return true;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    height: 40px;
    line-height: 40px;
    margin-bottom: $top;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
</style>
