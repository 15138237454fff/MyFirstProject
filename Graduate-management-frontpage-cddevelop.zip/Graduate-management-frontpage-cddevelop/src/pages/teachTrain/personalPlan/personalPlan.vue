<template>
  <div>
    <!-- 个人培养计划 personalPlan 主页面-->
    <div class="main">
      <!-- 个人培养计划 -->
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }">教学培养</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }">个人培养计划</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/4' }" v-if="$route.params.id == 4">调整个人培养计划</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <!-- 当状态是通过时可以进行课程调整，当状态是退回时需重新选择页面 -->
        <div slot="right">
          <div>
            <el-button
              type="primary"
              @click="handleSubmit"
              v-show="$route.params.id == 1 && zt !== null"
              >提交</el-button
            >
            <el-button
              type="primary"
              v-show="$route.params.id == 1 && zt == null"
              :disabled="disabled"
              style="background:#ccc;border:1px solid #ccc;height:34px;"
              >提交</el-button
            >
            <!-- 当个人培养计划被退回时可调整个人培养计划 -->
            <el-button
              type="primary"
              @click="handleUpdate"
              v-show="$route.params.id == 3"
              >提交</el-button
            >
            <el-button
              type="primary"
              @click="adjustClass"
              v-show="$route.params.id == 2 && zttype != '2' && zttype != '4'"
              :disabled="isshow"
              >培养计划调整</el-button
            >
            <el-button
              type="primary"
              class="returnto"
              @click="adjustReturn"
              style="background:#fff;color:#409eff"
              v-show="$route.params.id == 4 || $route.params.id == 5"
              ><div class="el-icon-d-arrow-left"></div>返回</el-button
            >
            <el-button
              type="primary"
              v-show="$route.params.id == 5"
              :disabled="toshow"
              >提交</el-button
            >
            <el-button
              type="primary"
              @click="adjustSubmit"
              v-show="$route.params.id == 4"
              >提交</el-button
            >
            <!-- 个人培养计划退回后再次调整提交 -->
            <el-button
              type="primary"
              @click="adjustBackReturn"
              class="returnto"
              style="background:#fff;color:#409eff"
              v-show="$route.params.id == 6"
              ><div class="el-icon-d-arrow-left"></div> 返回</el-button
            >
            <el-button
              type="primary"
              class="return"
              @click="adjustBackSubmit"
              v-show="$route.params.id == 6"
              >提交</el-button
            >
            <el-button
              type="primary"
              @click="review"
              v-if="$route.params.id == 2 && zttype == '2'"
              >调整审核中...</el-button
            >
            <el-button
              type="primary"
              @click="reviewReturn"
              v-if="$route.params.id == 2 && zttype == '4'"
              style="background-color:red;border:1px solid red;"
              >调整被退回</el-button
            >
          </div>
        </div>
      </my-breadcrumb>
      <template v-if="!loading">
        <div v-if="flagsj == true">
          <my-blank
            msg="还不可制定个人培养计划哦！"
            picUrl="blank.png"
          ></my-blank>
        </div>
        <div class="box" v-if="flagsj == false">
          <!-- 提交个人培养计划的修改 -->
          <apply
            v-show="$route.params.id == 1"
            ref="children1"
            :time="time"
          ></apply>

          <!-- 通过后的个人培养计划修改 -->
          <apply-detail
            v-if="$route.params.id == 2"
            :lcid="lcid"
            ref="applydel"
          ></apply-detail>
          <!-- 通过后的调整的个人培养计划修改 -->

          <apply-adjustclass v-if="$route.params.id == 5"></apply-adjustclass>
          <!-- 退回后的个人培养计划修改 -->
          <apply-save v-if="$route.params.id == 3" ref="children3"></apply-save>
          <!-- 调整个人培养计划 -->
          <apply-record
            v-if="$route.params.id == 4"
            ref="children4"
          ></apply-record>
          <!-- 调整后的退回页面 -->
          <apply-back v-if="$route.params.id == 6" ref="children6"></apply-back>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import apply from "./components/apply";
import applyDetail from "./components/applyDetail";
import applySave from "./components/applySave";
import applyRecord from "./components/applyRecord";
import myBreadcrumb from "@/components/myBreadcrumb";
import applyAdjustclass from "./components/applyAdjustclass";
import applyBack from "./components/applyBack";
import blank from "@/components/blank";

export default {
  name: "personalPlan",
  components: {
    apply,
    applyDetail,
    applySave,
    applyRecord,
    "my-breadcrumb": myBreadcrumb,
    "apply-adjustclass": applyAdjustclass,
    "apply-back": applyBack,
    "my-blank": blank
  },
  data() {
    return {
      disabled: true,
      titleShow: true,
      applyShow: true,
      writeInfo: {}, // 第一次提交的数据
      changeInfo: {}, // 退回后提交的数据
      changebackInfo: {}, // 退回后修改提交的数据
      adjustInfo: {}, // 调整后要提交的数据
      lcid: "",
      status: "",
      isshow: false,
      zttype: "",
      toshow: true,
      tztype: "",
      flag: true,
      flagsj: true,
      loading: true,
      time: ""
    };
  },
  created() {
    this.kqgb();
    this.$bus.$on("shzt", msg => {
      this.zttype = msg;
    });
    this.$bus.$on("tzlcid", msg => {
      this.tztype = msg;
    });
  },
  mounted() {
    console.log(this.$route.params)
  },
  updated() {
    // console.log(this.$refs.applydel.loading,'applydel')
  },
  watch: {
    $route(to) {
      if (to.path == "/teachTrain/personalPlan/1") {
        this.handleInit();
      }
    }
  },
  methods: {
    // 判断个人培养计划时间是否开启   flag == false(培养计划时间开启)  flagsj == false(不能查看详情)
    // 无论个人培养计划的时间是否开启都需要判断该学生的个人培养计划是否进行提交
    kqgb() {
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=grxxjh")
        .then(res => {
          if (res.data.data.isOpen == 1) {
            // 若培养计划时间开启给flag赋值
            this.flag = false;

            this.time = res.data.data.endTime
              ? res.data.data.endTime.substring(0, 10).replace(/-/g, "/")
              : "";
            this.handleInit();
          } else {
            // 若培养计划时间关闭给flag赋值
            this.flag = true;
            this.handleInit();
          }
        });
    },
    // 初始化判断是否已提交申请
    handleInit() {
      this.$http.get("/api/cultivate/pygrpyjhb/init").then(res => {
        this.loading = false;
        if (res.data.data == null) {
          if (this.flag == false) {
            // 若学生没有申请过个人培养计划并且个人培养计划时间开启，则学生跳转到个人培养计划的申请页面
            this.flagsj = false;
            this.$router.push({
              path: "/teachTrain/personalPlan/1"
            });
          } else {
            // 若学生没有申请过个人培养计划但时间是关闭的，则显示还没到申请培养计划的时间
            this.flagsj = true;
          }
        } else {
          // 若学生已申请过个人培养计划无论时间是否开启关闭都显示详情页
          this.flagsj = false;
          // 把获取的lcid 和当前的状态赋值
          this.lcid = res.data.data.lcid;
          this.status = res.data.data.zt;
        }
        // 若申请状态为审核中 则将按钮禁用  否则不禁用
        if (this.status == "2") {
          this.isshow = true;
        } else {
          this.isshow = false;
        }
        // 如果流程id不为空 并且获取的有状态值 则判断是否是退回的状况 若不是退回跳转到详情页面 若退回跳转到退回页面
        if (this.status != "") {
          if (this.status != 4) {
            this.$router.push({
              path: "/teachTrain/personalPlan/2",
              query: { lcid: this.lcid, zt: this.status }
            });
          } else {
            // 退回
            this.$router.push({
              path: "/teachTrain/personalPlan/3"
            });
          }
        }
        console.log(res.data.data);
        console.log(this.flag);
        console.log(this.flagsj);
      });
    },
    // 申请提交
    handleSubmit() {
      let sum1 = Number(this.$refs.children1.$refs.child1.sum.yxxf);
      let sum2 = Number(this.$refs.children1.$refs.child2.sum.yxxf);
      let sum3 = Number(this.$refs.children1.$refs.child3.sum.yxxf);

      let total1 = Number(this.$refs.children1.$refs.child1.total);
      let total2 = Number(this.$refs.children1.$refs.child2.total);
      let total3 = Number(this.$refs.children1.$refs.child3.total);

      let groupSelectRequire = this.$refs.children1.$refs.child1
        .groupSelectRequire;
      if (!groupSelectRequire) {
        this.$message.error("请按照课程组需求勾选课程");
        return;
      }
      if (sum1 < total1) {
        this.$message.error(
          `学位课已选学分需>=${this.$refs.children1.$refs.child1.total}`
        );
        return;
      }
      if (sum2 < total2) {
        this.$message.error(
          `选修课已选学分需>=${this.$refs.children1.$refs.child2.total}`
        );
        return;
      }
      if (sum3 < total3) {
        this.$message.error(
          `必修环节已选学分需>=${this.$refs.children1.$refs.child3.total}`
        );
      } else {
        this.writeInfo.xwkmath = this.$refs.children1.$refs.child1.xwkSave.xwkmath;
        this.writeInfo.xwknr = this.$refs.children1.$refs.child1.xwkSave.xwknr;
        this.writeInfo.xxkmath = this.$refs.children1.$refs.child2.xxkSave.xxkmath;
        this.writeInfo.xxknr = this.$refs.children1.$refs.child2.xxkSave.xxknr;
        this.writeInfo.bxhjmath = this.$refs.children1.$refs.child3.bxhjSave.bxhjmath;
        this.writeInfo.bxhjnr = this.$refs.children1.$refs.child3.bxhjSave.bxhjnr;
        this.writeInfo.zxf = this.$refs.children1.yxzxf;
        this.writeInfo.pyfahid = this.$refs.children1.pyfaId;
        // ywid 业务id
        // zt 状态
        // xh 学号
        // lcid 流程id
        // id ID
        // console.log(this.writeInfo);
        // return;
        this.$http
          .post("/api/cultivate/pygrpyjhb/start", this.writeInfo)
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("提交成功");
              this.handleInit();
            } else {
              this.$message.error("提交失败");
            }
          });
      }
    },
    // 退回修改提交
    handleUpdate() {
      let sum1 = Number(this.$refs.children3.$refs.child1.sum.yxxf);
      let sum2 = Number(this.$refs.children3.$refs.child2.sum.yxxf);
      let sum3 = Number(this.$refs.children3.$refs.child3.sum.yxxf);

      let total1 = Number(this.$refs.children3.$refs.child1.min);
      let total2 = Number(this.$refs.children3.$refs.child2.min);
      let total3 = Number(this.$refs.children3.$refs.child3.min);

      let groupSelectRequire = this.$refs.children3.$refs.child1
        .groupSelectRequire;
      if (!groupSelectRequire) {
        this.$message.error("请按照课程组需求勾选课程");
        return;
      }

      if (sum1 < total1) {
        this.$message.error(
          `学位课已选学分需>=${this.$refs.children3.$refs.child1.min}`
        );
        return;
      }
      if (sum2 < total2) {
        this.$message.error(
          `选修课已选学分需>=${this.$refs.children3.$refs.child2.min}`
        );
        return;
      }
      if (sum3 < total3) {
        this.$message.error(
          `必修环节已选学分需>=${this.$refs.children3.$refs.child3.min}`
        );
      } else {
        this.changeInfo.xwkmath = this.$refs.children3.$refs.child1.xwkSave.xwkmath;
        this.changeInfo.xwknr = this.$refs.children3.$refs.child1.xwkSave.xwknr;
        this.changeInfo.xxkmath = this.$refs.children3.$refs.child2.xxkSave.xxkmath;
        this.changeInfo.xxknr = this.$refs.children3.$refs.child2.xxkSave.xxknr;
        this.changeInfo.bxhjmath = this.$refs.children3.$refs.child3.bxhjSave.bxhjmath;
        this.changeInfo.bxhjnr = this.$refs.children3.$refs.child3.bxhjSave.bxhjnr;
        this.changeInfo.zxf = this.$refs.children3.sum.zxf;
        this.changeInfo.id = this.$refs.children3.id;
        this.changeInfo.lcid = this.$refs.children3.lcid;
        this.changeInfo.pyfahid = this.$refs.children3.pyfaId;
        // console.log(this.changeInfo)
        this.$http
          .post("/api/cultivate/pygrpyjhb/update", this.changeInfo)
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("提交成功");
              this.handleInit();
              // 修改成功后后退
              this.$router.go(-1);
            } else {
              this.$message.error("提交失败");
            }
          });
      }
    },
    // 审核成功课程调整
    handleAdjust() {
      // 通过
      this.$refs.children4.$refs.child.getData();
      this.$router.push({
        path: "/teachTrain/personalPlan/4"
      });
    },
    // 课程调整提交
    adjustSubmit() {
      // 调整时判断更改原因不能为空
      if (this.$refs.children4.$refs.child.writeInfo.ggyy == "") {
        this.$message.warning("请填写更改原因");
        return;
      }
      let sum1 = Number(this.$refs.children4.$refs.child.$refs.child1.sum.yxxf);
      let sum2 = Number(this.$refs.children4.$refs.child.$refs.child2.sum.yxxf);
      let sum3 = Number(this.$refs.children4.$refs.child.$refs.child3.sum.yxxf);

      let total1 = Number(this.$refs.children4.$refs.child.$refs.child1.min);
      let total2 = Number(this.$refs.children4.$refs.child.$refs.child2.min);
      let total3 = Number(this.$refs.children4.$refs.child.$refs.child3.min);

      let groupSelectRequire = this.$refs.children4.$refs.child.$refs.child1
        .groupSelectRequire;
      if (!groupSelectRequire) {
        this.$message.error("请按照课程组需求勾选课程");
        return;
      }

      if (sum1 < total1) {
        this.$message.error(
          `学位课已选学分需>=${this.$refs.children4.$refs.child.$refs.child1.min}`
        );
        return;
      }
      if (sum2 < total2) {
        this.$message.error(
          `选修课已选学分需>=${this.$refs.children4.$refs.child.$refs.child2.min}`
        );
        return;
      }
      if (sum3 < total3) {
        this.$message.error(
          `必修环节已选学分需>=${this.$refs.children4.$refs.child.$refs.child3.min}`
        );
      } else {
        this.adjustInfo.xwkmath = this.$refs.children4.$refs.child.$refs.child1.xwkSave.xwkmath;
        this.adjustInfo.xwknr = this.$refs.children4.$refs.child.$refs.child1.xwkSave.xwknr;
        this.adjustInfo.xxkmath = this.$refs.children4.$refs.child.$refs.child2.xxkSave.xxkmath;
        this.adjustInfo.xxknr = this.$refs.children4.$refs.child.$refs.child2.xxkSave.xxknr;
        this.adjustInfo.bxhjmath = this.$refs.children4.$refs.child.$refs.child3.bxhjSave.bxhjmath;
        this.adjustInfo.bxhjnr = this.$refs.children4.$refs.child.$refs.child3.bxhjSave.bxhjnr;
        this.adjustInfo.zxf = this.$refs.children4.$refs.child.sum.zxf;
        this.adjustInfo.id = this.$refs.children4.id;
        this.adjustInfo.lcid = this.$refs.children4.lcid;
        this.adjustInfo.pyfahid = this.$refs.children4.$refs.child.pyfaId;
        this.adjustInfo.ggyy = this.$refs.children4.$refs.child.writeInfo.ggyy;
      }
      this.$http
        .post("/api/cultivate/pyjhtz/start", this.adjustInfo)
        .then(res => {
          if (res.data.code === 200) {
            this.$message.success("提交成功");
            this.handleInit();
          } else {
            this.$message.error("提交失败");
          }
        });
    },
    // 点击课程调整进入培养计划调整的页面
    adjustClass() {
      // this.$refs.children4.$refs.child.getData()
      this.$router.push({
        path: "/teachTrain/personalPlan/4"
      });
    },
    review() {
      if ((this.zttype = "2")) {
        this.$router.push({
          path: "/teachTrain/personalPlan/5",
          query: { lcid: this.tztype }
        });
      }
    },
    reviewReturn() {
      if ((this.zttype = "4")) {
        this.$router.push({
          path: "/teachTrain/personalPlan/6",
          query: { lcid: this.tztype }
        });
      }
    },
    // 调整时的返回按钮
    adjustReturn() {
      this.$router.go(-1)
      // this.$router.push({
      //   path: "/teachTrain/personalPlan/1"
      // });
    },
    // 课程调整被退回后的提交
    adjustBackSubmit() {
      if (this.$refs.children6.ggyy == "") {
        this.$message.warning("请填写更改原因");
        return;
      }
      let sum1 = Number(this.$refs.children6.$refs.child1.sum.yxxf);
      let sum2 = Number(this.$refs.children6.$refs.child2.sum.yxxf);
      let sum3 = Number(this.$refs.children6.$refs.child3.sum.yxxf);

      let total1 = Number(this.$refs.children6.$refs.child1.min);
      let total2 = Number(this.$refs.children6.$refs.child2.min);
      let total3 = Number(this.$refs.children6.$refs.child3.min);

      let groupSelectRequire = this.$refs.children6.$refs.child1
        .groupSelectRequire;
      if (!groupSelectRequire) {
        this.$message.error("请按照课程组需求勾选课程");
        return;
      }

      if (sum1 < total1) {
        this.$message.error(
          `学位课已选学分需>=${this.$refs.children6.$refs.child1.min}`
        );
        return;
      }
      if (sum2 < total2) {
        this.$message.error(
          `选修课已选学分需>=${this.$refs.children6.$refs.child2.min}`
        );
        return;
      }
      if (sum3 < total3) {
        this.$message.error(
          `必修环节已选学分需>=${this.$refs.children6.$refs.child3.min}`
        );
      } else {
        this.changebackInfo.xwkmath = this.$refs.children6.$refs.child1.xwkSave.xwkmath;
        this.changebackInfo.xwknr = this.$refs.children6.$refs.child1.xwkSave.xwknr;
        this.changebackInfo.xxkmath = this.$refs.children6.$refs.child2.xxkSave.xxkmath;
        this.changebackInfo.xxknr = this.$refs.children6.$refs.child2.xxkSave.xxknr;
        this.changebackInfo.bxhjmath = this.$refs.children6.$refs.child3.bxhjSave.bxhjmath;
        this.changebackInfo.bxhjnr = this.$refs.children6.$refs.child3.bxhjSave.bxhjnr;
        this.changebackInfo.zxf = this.$refs.children6.sum.zxf;
        this.changebackInfo.id = this.$refs.children6.id;
        this.changebackInfo.lcid = this.$refs.children6.lcid;
        this.changebackInfo.pyfahid = this.$refs.children6.pyfaId;
        this.changebackInfo.ggyy = this.$refs.children6.ggyy;
        this.changebackInfo.xh = this.xh;
        this.changebackInfo.ywid = this.$refs.children6.ywid;
        this.$http
          .post("/api/cultivate/pyjhtz/update", this.changebackInfo)
          .then(res => {
            if (res.data.code === 200) {
              this.$message.success("提交成功");
              this.handleInit();
              // 修改成功后后退
              this.$router.go(-1);
            } else {
              this.$message.error("提交失败");
            }
          });
      }
    },
    // 被退回后再此调整
    adjustBackReturn() {
      this.$router.go(-1);
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    zt() {
      return sessionStorage.getItem("zt");
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  .el-icon-document,
  .el-icon-d-arrow-left {
    margin-right: 5px;
    color: #409eff;
  }
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
    .content {
      display: flex;
      text-align: center;
      .center,
      .right {
        ul {
          list-style: none;
          color: #606266;
          li {
            padding-bottom: 10px;
            font-size: 14px;
            text-align: left;
          }
        }
      }

      .left {
        flex: 1;
      }

      .center {
        flex: 1.5;
      }

      .right {
        flex: 1.5;
      }
     
      .bottom {
        transform: translateX(10%);
        .el-form {
          width: 80%;
        }
        .submit {
          width: 80%;
          text-align: right;
        }
      }
    
    }
  }
}
</style>
