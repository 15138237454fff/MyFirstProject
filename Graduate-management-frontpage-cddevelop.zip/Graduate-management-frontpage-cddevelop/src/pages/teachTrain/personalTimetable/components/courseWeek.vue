<template>
  <!-- 课程表：按周次 -->
  <div class="courseWeek">
    <div class="tableHead">
      <div></div>
      <div></div>
      <div v-for="(item, index) in dayList" :key="index">
        {{ item | xqFilter }}
      </div>
    </div>
    <div class="scrollArea">
      <table class="weekTable">
        <thead class="justWidth">
          <tr>
            <td height="1"></td>
            <td class="headerTd"></td>
            <td></td>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(obj, ind) in kbHearderList" :key="ind">
            <td class="headerTd">{{ obj.sxw | sxwToChinese }}</td>
            <td>
              <table>
                <tr v-for="(item, index) of obj.kjList" :key="index">
                  <td class="headerTd tdJc">第 {{ item }} 节</td>
                </tr>
              </table>
            </td>
            <td colspan="7">
              <table v-if="weekData[ind]">
                <tr
                  v-for="(jcItem, jcInd) of weekData[ind].xskbWeekZcVo"
                  :key="jcInd"
                >
                  <td v-for="(kcItem, kcInd) of jcItem.weekVoList" :key="kcInd">
                    <div class="kcArea">
                      <div v-for="(kc, index) of kcItem.kcList" :key="index">
                        <p>{{ kc.kcmc }}</p>
                        <!-- :content="
                            kc.sksjjd
                              .map(item => {
                                return `${item.zc}周 ${
                                  ['每周', '单周', '双周'][item.sfmz - 1]
                                } ${
                                  [
                                    '周一',
                                    '周二',
                                    '周三',
                                    '周四',
                                    '周五',
                                    '周六',
                                    '周日'
                                  ][item.xq - 1]
                                } ${item.kj}节`;
                              })
                              .join('<br />')
                          " -->
                        <el-tooltip placement="top">
                          <div slot="content">
                            <span
                              v-for="(item, index) of kc.sksjjd"
                              :key="index"
                            >
                              {{ item.zc }}周
                              {{ item.sfmz | sfmzToChinese }}
                              {{ item.xq | zXqFilter }} {{ item.kj }}节
                              <br />
                            </span>
                          </div>
                          <div>
                            <p v-for="(item, index) of kc.sksjjd" :key="index">
                              {{ item.zc }}周
                              {{ item.sfmz | sfmzToChinese }}
                              {{ item.xq | zXqFilter }} {{ item.kj }}节
                            </p>
                          </div>
                        </el-tooltip>
                        <p>{{ kc.jsxm }}</p>
                        <p>{{ kc.sksjjd.jsmc }}</p>
                      </div>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- <div v-if="noSureCount !== 0">
        <div class="head">
          <div class="center">
            <span class="block"></span>
            <span class="header-title">没有具体上课时间或地点的课程</span>
            <span class="block"></span>
          </div>
        </div>
        <el-table border :header-cell-style="tableHeaderColor" :data="noSureData">
          <el-table-column prop="kch" label="课程号" align="center"></el-table-column>
          <el-table-column prop="kcmc" label="课程名称" align="center"></el-table-column>
          <el-table-column prop="kcdw" label="开课单位" align="center"></el-table-column>
          <el-table-column prop="jsxm" label="任课老师" align="center"></el-table-column>
          <el-table-column prop="kcsx" label="课程属性" align="center"></el-table-column>
          <el-table-column prop="khfs" label="考核方式" align="center"></el-table-column>
          <el-table-column prop="xf" label="学分" align="center"></el-table-column>
          <el-table-column prop="xs" label="学时" align="center"></el-table-column>
          <el-table-column prop="sfhk" label="是否缓考" align="center"></el-table-column>
          <el-table-column prop="skdd" label="上课时间、地点" align="center" width="150"></el-table-column>
        </el-table>
      </div>-->
    </div>
  </div>
</template>

<script>
export default {
  name: "courseWeek",
  props: ["vallist"],
  components: {},
  data() {
    return {
      dsz: ["每周", "单周", "双周"],
      loading: false,
      tableData: [],
      // 表头信息
      dayList: [],
      kbHearderList: [],
      weekData: [],
      // 不确定时间、地点的课程
      noSureData: []
    };
  },
  mounted() {
    this.getHeader();
    this.getWeekData();
  },
  watch: {
    $route() {}
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    noSureCount() {
      return this.noSureData.length;
    }
  },
  methods: {
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f5f5f5;font-weight:400;font-size:14px;color:#333;";
      }
    },
    getHeader() {
      this.$http.get("/api/cultivate/xk/selectKbheader").then(res => {
        let data = res.data.data;
        this.dayList = data.dayList;
        this.kbHearderList = data.kbHearderList;
      });
    },
    getWeekData() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/xk/selectkbByWeek", {
          params: {
            xnxq: this.vallist
          }
        })
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          this.weekData = data;
          console.log(data);
        });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.courseWeek {
  position: relative;
  overflow: hidden;
  border: 1px solid #e5e5e5;
}
table {
  *border-style: solid;
  *border-color: #333;
  *border-width: 1px 0 0 1px;
  border-collapse: collapse;
  table-layout: auto;
}
.tableHead {
  // position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  background: #fff;
  z-index: 10;
  border: 1px solid #e5e5e5;
  height: 30px;
  line-height: 30px;
  div {
    text-align: center;
    border-right: 1px solid #e5e5e5;
    box-sizing: border-box;
    width: calc((100% - 72px) / 7);
    &:first-child {
      width: 36px;
    }
    &:nth-child(2) {
      width: 36px;
    }
  }
}
.justWidth td {
  height: 0px !important;
  border: none !important;
}
td {
  padding: 0;
}
.scrollArea {
  height: calc(100vh - 357px);
  overflow-y: auto;
  overflow-x: hidden;
}
.weekTable {
  width: 100%;
  height: 600px;
  text-align: center;
  word-break: break-all;
  *border-width: 0;
  td {
    border: 1px solid #e5e5e5;
    box-sizing: border-box;
    *border-width: 0 1px 1px 0;
    position: relative;
  }
  thead td {
    height: 30px;
  }
  .kcArea {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
    position: absolute;
    left: 0;
    top: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow-y: auto;
    height: 160px;

    & > div {
      width: 100%;
      box-sizing: border-box;
      border: 1px solid rgba(145, 213, 255, 1);
      background: rgba(230, 247, 255, 1);
      border-radius: 5px;
      padding: 2px 10px;
      &:not(:last-child) {
        margin-bottom: 5px;
      }
      &:hover {
        transform: scale(1.1);
      }
      p {
        text-align: left;
        color: #1890ff;
        font-size: 12px;
        white-space: nowrap; /*强制一行显示*/
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }
  }
  table {
    width: 100%;
    height: 100%;
    margin-left: -1px;
    margin-left: 0\9;
    *border-style: solid;
    border-style: hidden;
    table-layout: fixed;
  }

  .tdJc {
    height: 160px;
  }
  .headerTd {
    white-space: normal;
    width: 36px;
    vertical-align: middle;
    padding: 0 9px;
  }
}
.head {
  // display: flex;
  height: 50px;
  line-height: 50px;
  .center {
    text-align: center;
    // line-height: 63px;
    .header-title {
      font-size: 20px;
      font-weight: 500;
      color: #333;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: #333;
  display: inline-block;
}
</style>
