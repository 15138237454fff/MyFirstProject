<template>
  <!-- 个人课表：按列表显示 -->
  <div class="inside">
    <div class="table-box">
      <el-table
        :data="tableData"
        border
        :header-cell-style="tableHeaderColor"
        :height="tableHeight"
      >
        <!-- <el-table-column
          prop="kch"
          label="课程号"
          align="center"
        ></el-table-column> -->
        <el-table-column
          prop="kcmc"
          label="课程名称"
          align="center"
          width="150"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="kcxzh"
          label="课程性质"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="bjmc"
          label="教学班"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="jsxm"
          label="授课教师"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="xf"
          label="学分"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="zxs"
          label="学时"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="pyPkkcSksjs"
          label="上课时间、地点"
          align="center"
          width="300px"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <div v-for="(item, index) in scope.row.sksjjdList" :key="index">
              <span>{{ item.zc }}周</span>
              <span style="margin-left:7px">{{
                item.sfmz == 1
                  ? "(每周)"
                  : item.sfmz == 2
                  ? "(单周)"
                  : item.sfmz == 3
                  ? "(双周)"
                  : ""
              }}</span>
              <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
              <span style="margin-left:7px">{{ item.kj }}节</span>

              <span style="margin-left:7px" v-show="item.skdd">{{
                `${item.jsmc}`
              }}</span>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "courseList",
  props: ["vallist"],
  data() {
    return {
      tableData: [],
      value: "",
      radio: 1,
      xnxq: "2019年秋",
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      msgCount: 0
    };
  },
  components: {
    "my-pagination": myPagination
  },
  mounted() {
    console.log(1);
    this.getList();
  },
  created() {},
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    tableHeight() {
      return this.$store.getters.getTableHeight - 142;
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.getList();
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    // 加载对应学年学期的个人课表
    getList() {
      console.log(this.vallist);
      this.$http
        .get("/api/cultivate/xk/selectkb", {
          params: {
            xnxq: this.vallist,
            pageNum: this.limitQuery.pageNum,
            pageSize: this.limitQuery.pageSize
          }
        })
        .then(res => {
          this.tableData = res.data.data.list;
          this.msgCount = res.data.data.total;
        });
    }
  }
};
</script>

<style lang="scss" scoped>
.inside {
  height: calc(100vh - 236px);
  overflow: auto;
}
.head {
  // display: flex;
  height: 50px;
  line-height: 50px;
  .center {
    text-align: center;
    // line-height: 63px;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
.pageList {
  text-align: center;
  padding-top: 20px;
}
</style>
