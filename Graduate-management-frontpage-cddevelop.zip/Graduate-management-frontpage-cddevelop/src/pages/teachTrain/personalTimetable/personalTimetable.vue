<template>
  <!-- 个人课表 personalTimetable -->
  <div class="timetable">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }"
            >教学培养</el-breadcrumb-item
          >
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalTimetable/1' }"
            >个人课表</el-breadcrumb-item
          >
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button type="primary">导出</el-button>
      </div>
    </my-breadcrumb>
    <div class="box">
      <div class="head">
        <div class="center">
          <span class="block"></span>
          <span class="header-title">{{ xnxq.label }} 个人课表</span>
          <span class="block"></span>
        </div>
      </div>
      <div class="table-search">
        <div class="left">
          <el-select v-model="selvalue" @change="selectXnxq">
            <el-option
              v-for="(item, index) in options"
              :key="index"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </div>
        <div class="right">
          <el-radio-group v-model="radio" size="medium" @change="changeLayout">
            <el-radio-button label="1">按列表显示</el-radio-button>
            <el-radio-button label="2">按周次显示</el-radio-button>
          </el-radio-group>
        </div>
      </div>
      <template v-if="showList !== null">
        <course-list
          v-if="showList"
          ref="children1"
          :vallist="vallist"
        ></course-list>
        <course-week :vallist="vallist" v-else></course-week>
      </template>
    </div>
  </div>
</template>

<script>
import courseList from "./components/courseList";
import courseWeek from "./components/courseWeek";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "personalTimetable",
  components: {
    courseList,
    courseWeek,
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      showList: null,
      radio: 1,
      options: [],
      selvalue: "",
      vallist: ""
    };
  },
  created() {},
  mounted() {
    this.getXnxq();
    this.$store.commit("uplodexnxq");
  },
  methods: {
    // 获取学年学期
    getXnxq() {
      this.$http.get("/api/cultivate/xk/selectxnxq").then(res => {
        if (res.data.data == null) {
          this.$message.warning("选课后才会生成课表哦");
          return;
        }
        this.options = res.data.data;
        this.selvalue = this.options[0].value;
        this.vallist = this.options[0].value; //先默认获取第一个值
        this.showList = true;
      });
    },
    // 改变学年学期
    selectXnxq(val) {
      this.vallist = val;
      // this.$refs.children1.getList(val);
    },
    // 改变课程表格式
    changeLayout(t) {
      switch (t) {
        case "1":
          this.showList = true;
          break;
        case "2":
          this.showList = false;
          break;
      }
    }
  },
  computed: {
    xnxq() {
      return this.$store.state.userxnxq;
    }
  }
};
</script>

<style lang="scss" scoped>
.timetable {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    // height: calc(100vh - 236px);
    // overflow: auto;
  }
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.head {
  // display: flex;
  height: 50px;
  line-height: 50px;
  .center {
    text-align: center;
    // line-height: 63px;
    .header-title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
    .block {
      font-size: 16px;
      width: 10px;
      height: 10px;
      background-color: $blue;
      display: inline-block;
    }
  }
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    margin-top: $top;
    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
</style>
