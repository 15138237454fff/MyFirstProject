<template>
  <!-- 在线选课 秋季选课时间 第一次选课，若第一次已经选过课则直接跳转到详情展示的页面-->
  <div class="inside">
    <div class="head">
      <div class="left">
        请于
        <span class="mark">{{ this.$tagTime(time, "yyyy-MM-dd") }}</span>
        前完成选课
      </div>
      <div class="center">
        <span class="block"></span>
        <span class="title">{{ xnxq.label }} 选课</span>
        <span class="block"></span>
      </div>
      <div class="right"></div>
    </div>
    <div class="timetable">
      <el-tabs v-model="activeName" @tab-click="qiehuan">
        <el-tab-pane label="学位课" name="first">
          <el-table
            :data="list1"
            ref="tableRow1"
            border
            :height="tableHeight"
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            row-key="kch"
            @selection-change="handleSelectionChange1"
            v-loading="tableLoading1"
            element-loading-background="rgba(255, 255, 255,1)"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              label="教学班"
              align="center"
              :key="Math.random()"
              width="180"
            >
              <template slot-scope="scope">
                <div v-if="scope.row.jxbList.length > 0">
                  <el-select
                    v-model="scope.row.jxb"
                    filterable
                    placeholder="请选择"
                    @change="jxbSelect($event, scope.row)"
                  >
                    <el-option
                      v-for="item in scope.row.jxbList"
                      :key="item.pksjId"
                      :label="item.bjmc"
                      :value="item.pksjId"
                    ></el-option>
                  </el-select>
                </div>
                <!-- <span v-else-if="scope.row.jxbList.length === 1">{{
                  scope.row.jxbList[0].bjmc
                }}</span> -->
                <span v-else></span>
              </template>
            </el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    item.jsmc
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="50"
              :selectable="handleDisable"
              :reserve-selection="true"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="选修课" name="second">
          <el-table
            :data="list2"
            ref="tableRow2"
            border
            :height="tableHeight"
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            @row-click="clickRow2"
            @selection-change="handleSelectionChange2"
            v-loading="tableLoading2"
            element-loading-background="rgba(255, 255, 255,1)"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              label="教学班"
              align="center"
              :key="Math.random()"
              width="180"
            >
              <template slot-scope="scope">
                <div v-if="scope.row.jxbList.length > 0">
                  <el-select
                    v-model="scope.row.jxb"
                    filterable
                    placeholder="请选择"
                    @change="jxbSelect($event, scope.row)"
                  >
                    <el-option
                      v-for="item in scope.row.jxbList"
                      :key="item.pksjId"
                      :label="item.bjmc"
                      :value="item.pksjId"
                    ></el-option>
                  </el-select>
                </div>
                <!-- <span v-else-if="scope.row.jxbList.length === 1">{{
                  scope.row.jxbList[0].bjmc
                }}</span> -->
                <span v-else></span>
              </template>
            </el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    `${item.jsmc}`
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
            <el-table-column
              type="selection"
              width="50"
              :selectable="handleDisable1"
              align="center"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
      ref="page"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "apply",
  components: {
    "my-pagination": myPagination
  },
  props: ["time"],
  data() {
    return {
      activeName: "first",
      list1: [],
      list2: [],
      options: [], //教学班的选项
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      msgCount: 0,
      xwcount: 0,
      xxcount: 0,
      zyh: "081704",
      jxbList: [],
      id1: null,
      id2: null,
      // id3: null,
      ids: null,
      idList: [],
      idList1: [],
      idList2: [],
      // idList3: [],
      historyList1: [],
      historyList2: [],
      // historyList3: [],
      kclxList1: [],
      kclxList2: [],
      tableLoading1: true,
      tableLoading2: true
    };
  },
  created() {},
  mounted() {
    this.$nextTick(el => {
      this.getList1();
      this.getList2();
      console.log(this.$refs.page, "tableRow1");
    });
    this.$store.commit("uplodexnxq");
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      // this.msgCount = msgCount;
      // console.log(msgCount,8)
      // 重新请求列表数据
      this.getList1();
      this.getList2();
      // this.getList3()
    },
    getList1() {
      this.$http
        .get(
          "/api/cultivate/xk/selectXwk/" +
            this.limitQuery.pageNum +
            "/" +
            this.limitQuery.pageSize
        )
        .then(res => {
          this.tableLoading1 = false;
          this.xwcount = res.data.data.total;
          this.msgCount = this.xwcount;
          let tmpResult = res.data.data.list;
          tmpResult.forEach(item => {
            // console.log(item.jxbList);
            // if (item.jxbList.length == 1) {
            //   item.jxb = item.jxbList[0].pksjId;
            //   item.bjmc = item.jxbList[0].bjmc;
            //   item.jsxm = item.jxbList[0].jsxm;
            //   item.sksjddList = item.jxbList[0].sksjddList;
            //   item.xdrs = item.jxbList[0].xdrs;
            //   item.xkrsxd = item.jxbList[0].xkrsxd;
            // }
            if (item.jxbList.length >= 1) {
              item.jxb = item.jxbList[0].pksjId;
              item.bjmc = item.jxbList[0].bjmc;
              item.jsxm = item.jxbList[0].jsxm;
              item.sksjddList = item.jxbList[0].sksjddList;
              item.xdrs = item.jxbList[0].xdrs;
              item.xkrsxd = item.jxbList[0].xkrsxd;
            }
          });
          // 调用自定义全局的添加对象属性的方法
          this.list1 = tmpResult;
          //默认勾选所有的学位课
          this.list1.forEach(el =>
            this.$refs.tableRow1
              ? this.$refs.tableRow1.toggleRowSelection(el, true)
              : ""
          );
          // console.log(this.$refs.tableRow1, "tableRow1");
        });
    },
    getList2() {
      this.$http
        .get(
          "/api/cultivate/xk/selectXxk/" +
            this.limitQuery.pageNum +
            "/" +
            this.limitQuery.pageSize
        )
        .then(res => {
          this.tableLoading2 = false;
          this.xxcount = res.data.data.total;
          let tmpResult = res.data.data.list;
          tmpResult.forEach(item => {
            // if (item.jxbList.length == 1) {
            //   item.jxb = item.jxbList[0].pksjId;
            //   item.bjmc = item.jxbList[0].bjmc;
            //   item.jsxm = item.jxbList[0].jsxm;
            //   item.sksjddList = item.jxbList[0].sksjddList;
            //   item.xdrs = item.jxbList[0].xdrs;
            //   item.xkrsxd = item.jxbList[0].xkrsxd;
            // }
            if (item.jxbList.length >= 1) {
              item.jxb = item.jxbList[0].pksjId;
              item.bjmc = item.jxbList[0].bjmc;
              item.jsxm = item.jxbList[0].jsxm;
              item.sksjddList = item.jxbList[0].sksjddList;
              item.xdrs = item.jxbList[0].xdrs;
              item.xkrsxd = item.jxbList[0].xkrsxd;
            }
          });
          // 调用自定义全局的添加对象属性的方法
          this.list2 = tmpResult;
          // this.list2.forEach(el =>
          //   this.$refs.tableRow2.toggleRowSelection(el, true)
          // );
        });
    },
    qiehuan(val) {
      if (val.name == "second") {
        this.msgCount = this.xxcount;
      } else if (val.name == "first") {
        this.msgCount = this.xwcount;
      }
    },
    getRowKeys(row) {
      row.jxbList.map(item => {
        return item.pksjId;
      });
    },
    // 学位课教学班选择改变事件
    jxbSelect(val, row) {
      console.log(val, row, "学位课改变事件");
      row.jxbList.map(item => {
        if (val == item.pksjId) {
          row.pksjId = item.pksjId;
          row.jsxm = item.jsxm;
          row.sksjddList = item.sksjddList;
          row.xdrs = item.xdrs;
          row.xkrsxd = item.xkrsxd;
        }
      });
      this.idList1 = this.historyList1.map(item => {
        return item.jxb;
      });
      this.idList2 = this.historyList2.map(item => {
        return item.jxb;
      });
      // this.idList3 = this.historyList3.map(item => {
      //   return item.jxb;
      // });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    tableCellColor({ row, columnIndex }) {
      // //console.log(Number(row.yxrs)>Number(row.xdrs))
      if (Number(row.yxrs) >= Number(row.xdrs) && columnIndex == 8) {
        return "color:#F56C6C";
      }
    },
    // 有两个参数返回，表格的每一行对象和当前索引,true可选 false不可选
    handleDisable(row) {
      // //console.log(Number(row.yxrs)>Number(row.xdrs))
      if (Number(row.yxrs) >= Number(row.xdrs)) {
        return false;
      } else {
        // 学位课默认不可选
        if (this.activeName === "first") {
          return false;
        }
        return true;
      }
    },
    handleDisable1(row) {
      if (Number(row.yxrs) >= Number(row.xdrs)) {
        return false;
      } else {
        if (this.activeName === "second") {
          return true;
        }
      }
      if (row.jxbList.length === 0) {
        return false;
      }
    },
    handleSelectionChange1(selection) {
      this.historyList1 = selection;
      this.idList1 = selection.map(item => {
        return item.jxb;
      });
      this.idList1.forEach(el => {
        console.log(el, "每一项选中的数据");
        if (el === undefined) {
          this.idList1.splice(el, 1);
        }
      });
      console.log(this.idList1, "删除所选项为空的数据");
    },
    handleSelectionChange2(selection) {
      this.historyList2 = selection;
      this.idList2 = selection.map(item => {
        return item.jxb;
      });
      this.idList2.forEach(el => {
        // console.log(el, "每一项选中的数据");
        if (el === undefined) {
          this.idList2.splice(el, 1);
        }
      });
    },
    // 点击列表选中
    clickRow1(row) {
      this.$refs.tableRow1.toggleRowSelection(row);
    },
    clickRow2(row) {
      // this.$refs.tableRow2.toggleRowSelection(row);
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    tableHeight() {
      return this.$store.getters.getTableHeight - 144;
    },
    xnxq() {
      return this.$store.state.userxnxq;
    }
  }
};
</script>

<style lang="scss" scoped>
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  justify-content: space-between;
  .left {
    flex: 1;
  }
  .center {
    flex: 1;
    text-align: center;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
  .right {
    flex: 1;
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      height: 57px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: $top;
}
.timetable /deep/ .el-tabs__nav {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
</style>
