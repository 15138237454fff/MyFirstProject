<template>
  <!-- 在线选课 调整第一次选课的内容 -->
  <div class="inside">
    <div class="head">
      <div class="left">
        请于
        <span class="mark">{{ this.$tagTime(time,"yyyy-MM-dd") }}</span>
        前完成选课
      </div>
      <div class="center">
        <span class="block"></span>
        <span class="title">{{ xnxq.label }} 选课</span>
        <span class="block"></span>
      </div>
    </div>
    <div class="timetable">
      <el-tabs v-model="activeName" @tab-click="selClass">
        <el-tab-pane label="学位课" name="first">
          <el-table
            :data="list1"
            ref="tableRow1"
            border
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            :height="tableHeight"
            row-key="kch"
            @row-click="clickRow1"
            @selection-change="handleSelectionChange1"
            v-loading="tableLoading1"
            element-loading-background="rgba(255, 255, 255,1)"
          >
            </el-table-column>
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              :key="Math.random()"
              width="160"
            >
              <template slot-scope="scope">
                <el-select
                  v-if="scope.row.jxbList.length > 0"
                  v-model="scope.row.jxb"
                  filterable
                  placeholder="请选择"
                  @change="jxbSelect($event, scope.row)"
                >
                  <el-option
                    v-for="item in scope.row.jxbList"
                    :key="item.pksjId"
                    :label="item.bjmc"
                    :value="item.pksjId"
                  ></el-option>
                </el-select>
                <!-- <span v-else>{{ scope.row.jxbList[0].bjmc }}</span> -->
                 <span v-else></span>
              </template>
            </el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    item.jsmc
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="50"
              :selectable="handleDisable"
              :reserve-selection="true"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="选修课" name="second">
          <el-table
            :data="list2"
            ref="tableRow2"
            border
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            @row-click="clickRow2"
            :height="tableHeight"
            @selection-change="handleSelectionChange2"
            v-loading="tableLoading2"
            element-loading-background="rgba(255, 255, 255,1)"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              width="160"
            >
              <template slot-scope="scope">
                <el-select
                  v-if="scope.row.jxbList.length > 0"
                  v-model="scope.row.jxb"
                  filterable
                  placeholder="请选择"
                  :key="index"
                  @change="jxbSelect($event, scope.row)"
                >
                  <el-option
                    v-for="item in scope.row.jxbList"
                    :key="item.pksjId"
                    :label="item.bjmc"
                    :value="item.pksjId"
                  ></el-option>
                </el-select>
                <!-- <span v-else>{{ scope.row.jxbList[0].bjmc }}</span> -->
                <span v-else></span>
              </template>
            </el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    item.jsmc
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
            <el-table-column
              type="selection"
              :selectable="handleDisable1"
              width="50"
              align="center"
            ></el-table-column>
            <!-- :selectable="handleDisable1" -->
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "adjustClass",
  components: {
    "my-pagination": myPagination
  },
  props: {
    list: { type: Array },
    time: {}
  },
  data() {
    return {
      index: 0,
      activeName: "first",
      list1: [],
      list2: [],
      //   list3: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      // 分页
      msgCount: 0, // 学位课默认的分页数
      xwpage: 0, // 学位课的分页数量
      xxpage: 0, // 选修课分页数量
      zyh: "081704",
      jxbList: [],
      idList: [],
      idList1: [],
      idList2: [],
      idList3: [],
      historyList1: [],
      historyList2: [],
      historyList3: [],
      kclxList1: [],
      kclxList2: [],
      kclxList3: [],
      checkList: [],
      // checkall: [], //所有选中的课程对应的id的值
      // 选择的历史记录
      historySelect: [],
      tableLoading1: true,
      tableLoading2: true
    };
  },
  created() {},
  mounted() {
    this.selectedToggle();
    this.getChecked();
    this.$store.commit("uplodexnxq");
  },
  methods: {
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.historySelect = val;
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.getChecked();
      this.selectedToggle();
    },
    getChecked() {
      // 补退选前回显学生选课数据(显示的为已选数据)
      this.$http.get("/api/cultivate/xk/selectInfoByXh/1").then(res => {
        let data = res.data.data;
        this.checkList = data;
      });
    },
    selectedToggle() {
      Promise.all([this.getList1(), this.getList2()]).then(() => {
        this.getChecked1();
      });
    },
    getChecked1() {
      let listFilter = [];
      this.list1.forEach(item => {
        this.checkList.xwkList.forEach(v => {
          if (item.jxb == v) {
            listFilter.push(item);
          }
        });
      });
      listFilter.forEach(row => {
        this.$nextTick(() => {
          this.$refs.tableRow1
            ? this.$refs.tableRow1.toggleRowSelection(row)
            : "";
        });
      });
      listFilter = [];
      this.list2.filter(item => {
        this.checkList.xxkList.filter(v => {
          if (item.jxb == v) {
            listFilter.push(item);
          }
        });
      });
      listFilter.forEach(row => {
        this.$nextTick(() => {
          this.$refs.tableRow2
            ? this.$refs.tableRow2.toggleRowSelection(row)
            : "";
        });
      });
    },
    getList1() {
      return new Promise(resolve => {
        this.$http
          .get(
            "/api/cultivate/xk/selectXwk" +
              "/" +
              this.limitQuery.pageNum +
              "/" +
              this.limitQuery.pageSize
          )
          .then(res => {
            this.tableLoading1 = false;
            this.msgCount = res.data.data.total;
            this.xwpage = this.msgCount;
            this.list1 = res.data.data.list;
            if (this.list1.length > 0) {
              this.list1.forEach(item => {
                let tmpArr = item.jxbList.filter(el => {
                  return this.checkList.xwkList.includes(el.pksjId);
                });
                // if (tmpArr.length === 1) tmpArr = [item.jxbList[0]];
                if (tmpArr.length > 0) {
                  this.$set(item, "jxb", tmpArr[0].pksjId);
                  item.bjmc = tmpArr[0].bjmc;
                  item.jsxm = tmpArr[0].jsxm;
                  item.sksjddList = tmpArr[0].sksjddList;
                  item.xdrs = tmpArr[0].xdrs;
                  item.xkrsxd = tmpArr[0].xkrsxd;
                }
              });
            }
            resolve();
          });
      });
    },
    getList2() {
      return new Promise((resolve, reject) => {
        this.$http
          .get(
            "/api/cultivate/xk/selectXxk" +
              "/" +
              this.limitQuery.pageNum +
              "/" +
              this.limitQuery.pageSize
          )
          .then(res => {
            // this.msgCount = res.data.data.total;
            this.tableLoading2 = false;
            this.xxpage = res.data.data.total;
            this.list2 = res.data.data.list;
            if (this.list2.length > 0) {
              this.list2.forEach(item => {
                let tmpArr = item.jxbList.filter(el => {
                  return this.checkList.xxkList.includes(el.pksjId);
                });
                if (tmpArr.length === 0) tmpArr = [item.jxbList[0]];
                if (tmpArr.length > 0) {
                  this.$set(item, "jxb", tmpArr[0].pksjId);
                  item.bjmc = tmpArr[0].bjmc;
                  item.jsxm = tmpArr[0].jsxm;
                  item.sksjddList = tmpArr[0].sksjddList;
                  item.xdrs = tmpArr[0].xdrs;
                  item.xkrsxd = tmpArr[0].xkrsxd;
                }
              });
            }
            console.log(this.list2, "list2");
            resolve();
          });
      });
    },
    // 学位课教学班选择改变事件
    jxbSelect(val, row) {
      row.jxbList.map(item => {
        if (val == item.pksjId) {
          row.pksjId = item.pksjId;
          row.jsxm = item.jsxm;
          row.sksjddList = item.sksjddList;
          row.xdrs = item.xdrs;
          row.xkrsxd = item.xkrsxd;
        }
      });
      this.idList1 = this.historyList1.map(item => {
        return item.jxb;
      });
      this.idList2 = this.historyList2.map(item => {
        return item.jxb;
      });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    tableCellColor({ row, columnIndex }) {
      if (Number(row.yxrs) >= Number(row.xdrs) && columnIndex == 8) {
        return "color:#F56C6C";
      }
    },
    // 有两个参数返回，表格的每一行对象和当前索引,true可选 false不可选
    handleDisable(row) {
      if (Number(row.yxrs) >= Number(row.xdrs)) {
        return false;
      } else {
        // 学位课默认不可选
        if (this.activeName === "first") {
          return false;
        }
        // return true;
      }
      if (row.jxbList.length === 0) {
        return false
      }
    },
    // handleClick() {
    //   // 默认勾选已经选过的选修课.在tab表格上定义时间，当切换到选修课时再去查找当前的选修课是否已经选中
    //   if (this.activeName == "second") {
    //     this.list2.forEach((li, index) => {
    //       this.checkList.xxkList.forEach(els => {
    //         if (li.jxbList.find(el => el.pksjId === els))
    //           return this.$refs.tableRow2.toggleRowSelection(li);
    //           return true;
    //       });
    //     });
    //   }
    // },
    handleDisable1(row) {
      if (Number(row.yxrs) >= Number(row.xdrs)) {
        return false;
      }
      else {
        if (this.activeName === "second") {
          return true;
        }
      }
       if (row.jxbList.length === 0) {
        return false
      }
    },
    handleSelectionChange1(selection) {
      this.historyList1 = selection;
      this.idList1 = selection.map(item => {
        return item.jxb;
      });
    },
    handleSelectionChange2(selection) {
      this.historyList2 = selection;
      this.idList2 = selection.map(item => {
        return item.jxb;
      });
    },
    // 点击列表选中
    clickRow1(row) {
      this.$refs.tableRow1.toggleRowSelection(row);
    },
    clickRow2(row) {
      this.$refs.tableRow2.toggleRowSelection(row);
    },
    //监听切换课程时分页数据的条数变化
    selClass(val) {
      if (val.name == "second") {
        this.msgCount = this.xxpage;
      } else if (val.name == "first") {
        this.msgCount = this.xwpage;
      }
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    tableHeight() {
      return this.$store.getters.getTableHeight - 144;
    },
    userStatus() {
      return this.$store.getters.getStatus;
    },
    xnxq() {
      return this.$store.state.userxnxq;
    }
  }
};
</script>

<style lang="scss" scoped>
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  .left {
    flex: 1;
  }
  .center {
    flex: 1.5;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      height: 57px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    padding: 10px;
    margin-bottom: 15px;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.timetable /deep/ .el-tabs__nav {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
.timetable /deep/ .el-input__inner {
  padding: 0;
}
.timetable /deep/ .el-select {
  padding: 0;
  width: 80px;
}
</style>
