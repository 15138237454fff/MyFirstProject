<template>
  <!-- 在线选课 退选/补选 改选 -->
  <div class="inside">
    <div class="head">
      <div class="left">
        请于
        <span class="mark">{{ this.$tagTime(time,"yyyy-MM-dd") }}</span>
        前完成退补选课
      </div>
      <div class="center">
        <span class="block"></span>
        <span class="title">{{ xnxq.label }} 选课</span>
        <span class="block"></span>
      </div>
    </div>
    <div class="timetable">
      <el-button
        type="primary"
        class="showbtn"
        v-if="activeName == 'third'"
        @click="showfrom"
        >添加课程</el-button
      >
      <el-tabs v-model="activeName" @tab-click="selClass">
        <el-tab-pane label="学位课" name="first">
          <el-table
            :data="list1"
            ref="tableRow1"
            border
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            :height="tableHeight"
            row-key="kch"
            @row-click="clickRow1"
            v-loading="tableLoading1"
            element-loading-background="rgba(255, 255, 255,1)"
            @selection-change="handleSelectionChange1"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              :key="Math.random()"
              width="160"
            >
              <template slot-scope="scope">
                <el-select
                  v-if="scope.row.jxbList.length > 0"
                  v-model="scope.row.jxb"
                  filterable
                  placeholder="请选择"
                  @change="jxbSelect($event, scope.row)"
                >
                  <el-option
                    v-for="item in scope.row.jxbList"
                    :key="item.pksjId"
                    :label="item.bjmc"
                    :value="item.pksjId"
                  ></el-option>
                </el-select>
                <!-- <span v-else>{{ scope.row.jxbList[0].bjmc }}</span> -->
                <span v-else></span>
              </template>
            </el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div
                  v-for="(item, index) in scope.row.sksjddList"
                  :key="index"
                  v-if="scope.row.sksjddList.length > 0"
                >
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    `${item.jsmc}`
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="50"
              :selectable="handleDisable"
              :reserve-selection="true"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="选修课" name="second">
          <el-table
            :data="list2"
            ref="tableRow2"
            border
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            @row-click="clickRow2"
            :height="tableHeight"
            v-loading="tableLoading2"
            element-loading-background="rgba(255, 255, 255,1)"
            @selection-change="handleSelectionChange2"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              width="160"
            >
              <template slot-scope="scope">
                <el-select
                  v-if="scope.row.jxbList.length > 0"
                  v-model="scope.row.jxb"
                  filterable
                  placeholder="请选择"
                  :key="index"
                  @change="jxbSelect($event, scope.row)"
                >
                  <el-option
                    v-for="item in scope.row.jxbList"
                    :key="item.pksjId"
                    :label="item.bjmc"
                    :value="item.pksjId"
                  ></el-option>
                </el-select>
                <!-- <span v-else>{{ scope.row.jxbList[0].bjmc }}</span> -->
                <span v-else></span>
              </template>
            </el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div
                  v-for="(item, index) in scope.row.sksjddList"
                  :key="index"
                  v-if="scope.row.sksjddList.length > 0"
                >
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    `${item.jsmc}`
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
            <el-table-column
              type="selection"
              width="50"
              align="center"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="计划外课程" name="third">
          <el-table
            :data="list3"
            ref="tableRow3"
            border
            :height="tableHeight"
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            @row-click="clickRow3"
            v-loading="tableLoading3"
            element-loading-background="rgba(255, 255, 255,1)"
            @selection-change="handleSelectionChange3"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column label="教学班" align="center" width="150">
              <template slot-scope="scope">
                <span v-if="gridData.length == 0 && gridData.length">{{
                  scope.row.bjmc
                }}</span>
                <el-select
                  v-model="scope.row.bjmc0"
                  filterable
                  placeholder="请选择"
                  :key="index"
                  @change="jxbSelect1(scope.row, scope.row.bjmc0)"
                  v-else
                >
                  <el-option
                    v-for="(item, index) in scope.row.kcList"
                    :key="index"
                    :label="item.bjmc"
                    :value="item.bjmc"
                  ></el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column
              label="授课教师"
              align="center"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div>
                  <li v-if="gridData.length == 0 && gridData.length">
                    {{ scope.row.jsxm }}
                  </li>
                  <li v-else>{{ scope.row.skjszc.jzgXm }}</li>
                  <!-- {{scope.row.skjszc}} -->
                </div>
              </template>
            </el-table-column>
            <el-table-column
              filterable
              label="上课时间、地点"
              align="center"
              width="300"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div
                  v-for="(item, index) in scope.row.sjddList"
                  :key="index"
                  v-if="gridData.length == 0 && gridData.length"
                >
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px">{{ `${item.jsmc}` }}</span>
                </div>
                <div
                  v-for="(item, index) in scope.row.skjszc.sjjdList"
                  :key="index"
                  v-else
                >
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px">{{ `${item.jsmc}` }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="限定人数" align="center">
              <template slot-scope="scope">
                <div>
                  <li v-if="gridData.length == 0 && gridData.length">
                    {{ scope.row.xdrs }}
                  </li>
                  <li v-else>{{ scope.row.skjszc.xdrs }}</li>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="已选人数" align="center">
              <template slot-scope="scope">
                <div>
                  <li v-if="gridData.length == 0 && gridData.length">
                    {{ scope.row.xkrsxd }}
                  </li>
                  <li v-else>{{ scope.row.skjszc.xkrsxd }}</li>
                </div>
              </template>
            </el-table-column>
            <el-table-column width="50" align="center" label="操作">
              <template slot-scope="scope">
                <i
                  class="el-icon-remove"
                  style="color:#f56c6c"
                  @click="delRow(scope.$index, scope.row)"
                ></i>
              </template>
            </el-table-column>
          </el-table>
          <!-- 添加计划外课程 -->
          <el-dialog
            title="添加计划外课程"
            :visible.sync="connectDialogVisible"
            v-if="connectDialogVisible"
            width="70%"
          >
            <el-form :model="form">
              <el-row :gutter="20">
                <el-col :span="10">
                  <!-- 培养方案的制定学院 而不是课程的所属学院-->
                  <el-form-item label="选择学院：" label-width="120px">
                    <el-select
                      v-model="form.kkdw"
                      filterable
                      clearable
                      placeholder="请选择"
                      @change="selectChange"
                      @clear="selectClear1"
                    >
                      <el-option
                        v-for="item in dwList"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="10">
                  <el-form-item label="选择专业：" label-width="90px">
                    <el-select
                      v-model="form.sszy"
                      filterable
                      clearable
                      placeholder="请选择"
                      @clear="selectClear2"
                    >
                      <el-option
                        v-for="item in majorList"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      ></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="3">
                  <div style="line-height:37px">
                    <el-button type="primary" size="small" @click="handleFind"
                      >查询</el-button
                    >
                  </div>
                </el-col>
              </el-row>
            </el-form>
            <el-table
              :data="gridData"
              border
              :header-cell-style="tableHeaderColor"
              ref="jhwkcTable"
              :row-click="jhwkcTable"
              @selection-change="handleSelectionChange"
            >
              <el-table-column
                prop="kcmc"
                label="课程名称"
                align="center"
                width="200"
              ></el-table-column>
              <el-table-column
                prop="bjmc"
                label="教学班"
                align="center"
                width="150"
              >
                <template slot-scope="scope">
                  <el-select
                    v-model="scope.row.bjmc0"
                    filterable
                    placeholder="请选择"
                    :key="index"
                    @change="jxbSelect2(scope.row, scope.row.bjmc0)"
                  >
                    <el-option
                      v-for="(item, index) in scope.row.kcList"
                      :key="index"
                      :label="item.bjmc"
                      :value="item.bjmc"
                    ></el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column
                prop="jzgXm"
                label="授课教师"
                align="center"
                show-overflow-tooltip
              >
                <template slot-scope="scope">
                  <div>
                    <li>{{ scope.row.skjszc.jzgXm }}</li>
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                prop="kcList"
                filterable
                label="上课时间、地点"
                align="center"
                width="300"
                show-overflow-tooltip
              >
                <template slot-scope="scope">
                  <div v-if="scope.row.skjszc.sjjdList.length">
                    <span>{{ scope.row.skjszc.sjjdList[0].zc }}周</span>
                    <span style="margin-left:7px">{{
                      scope.row.skjszc.sjjdList[0].sfmz == 1
                        ? "(每周)"
                        : scope.row.skjszc.sjjdList[0].sfmz == 2
                        ? "(单周)"
                        : scope.row.skjszc.sjjdList[0].sfmz == 3
                        ? "(双周)"
                        : ""
                    }}</span>
                    <span style="margin-left:7px">{{
                      scope.row.skjszc.sjjdList[0].xq | xqFilter
                    }}</span>
                    <span style="margin-left:7px"
                      >{{ scope.row.skjszc.sjjdList[0].kj }}节</span
                    >
                    <span
                      style="margin-left:7px"
                      v-show="scope.row.skjszc.sjjdList[0].skdd"
                      >{{ `${scope.row.skjszc.sjjdList[0].jsmc}` }}</span
                    >
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xdrs" label="限定人数" align="center">
                <template slot-scope="scope">
                  <div>
                    <li>{{ scope.row.skjszc.xdrs }}</li>
                  </div>
                </template>
              </el-table-column>
              <el-table-column prop="xkrsxd" label="已选人数" align="center">
                <template slot-scope="scope">
                  <div>
                    <li>{{ scope.row.skjszc.xkrsxd }}</li>
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                type="selection"
                width="80"
                align="center"
              ></el-table-column>
            </el-table>
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              @paginate="handlePaginate2"
              layout="total, sizes, prev, pager, next, jumper"
              :pageNum="jhwkepage.pageNum"
              :page-size="jhwkepage.pageSize"
              :total="jhwkepage.msgCount"
              style="text-align:center;margin-top:15px;"
            ></el-pagination>
            <div slot="footer" class="dialog-footer" style="text-align:center;">
              <el-button @click="connectDialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="handleAdd">确 定</el-button>
            </div>
          </el-dialog>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
// import { resolve } from "dns";
export default {
  name: "applyDetail",
  components: {
    "my-pagination": myPagination
  },
  props: ["list", "time"],
  data() {
    return {
      gridData: [], // 添加计划外课程
      // 分页
      pageList: {
        pageNum: null,
        pageSize: null,
        total: null,
        pages: null
      },
      currentPage4: 4,
      // 合计学分学时
      sum: {
        total: 22.5,
        yxms: 0,
        msList: [],
        yxxf: 0,
        xfList: [],
        yxxs: 0,
        xsList: [],
        kcidList: [],
        kcid: ""
      },
      jhwSave: {
        jhwmath: "",
        jhwkc: ""
      },
      newValue: [],
      form: {
        kkdw: "",
        sszy: ""
      },
      dwList: [], // 所属学院下拉框
      majorList: [], // 所属单位下拉框
      jhwKchs: [], // 勾选的课程号
      copySel: [], // 记录勾选的数据
      tableData: [],
      index: 0,
      connectDialogVisible: false,
      activeName: "first",
      list1: [],
      list2: [],
      list3: [],
      list3id: [],
      // 列表分页传参  退补选选课的数据
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      // 添加退补选选课的分页数据
      jhwkepage: {
        pageNum: 1,
        pageSize: 10,
        msgCount: null
      },
      // 分页
      msgCount: 0, // 学位课默认的分页数量
      // 将学位课分页的数据和选修课，计划外课程分页的数据封装到一个变量中方便调用
      xwpage: 0, // 学位课分页数量
      xxpage: 0, // 选修课分页的数量
      jhwpage: 0, // 计划外课程分页的数量
      zyh: "081704",
      jxbList: [],
      idList: [],
      idList1: [],
      idList2: [],
      idList3: [],
      jhwList: [],
      historyList1: [],
      historyList2: [],
      historyList3: [],
      histroyjhw: [],
      kclxList1: [],
      kclxList2: [],
      kclxList3: [],
      checkList: [],
      // 选择的历史记录
      historySelect: [],
      // 将学生选过的课程号传递到查询中，避免重复选课
      repeatclass: [],
      tableLoading1: true,
      tableLoading2: true,
      tableLoading3: true
    };
  },
  created() {},
  mounted() {
    this.selectedToggle();
    this.getChecked();
    this.$store.commit("uplodexnxq");
  },
  methods: {
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.getChecked();
      this.selectedToggle();
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate2(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中

      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.getList();
    },
    getChecked() {
      // 补退选前回显学生选课数据(显示的为已选数据)
      this.$http.get("/api/cultivate/xk/selectInfoByXh/1").then(res => {
        let data = res.data.data;
        this.checkList = data;
        console.log(this.checkList, 2);
      });
    },
    getChecked1() {
      // 将学生已选过的课根据班级进行删除
      let listFilter = [];
      this.list1.forEach(item => {
        this.checkList.xwkList.forEach(v => {
          if (item.jxb == v) {
            listFilter.push(item);
            //  console.log(v,'hang')
          }
        });
      });
      listFilter.forEach(row => {
        this.$nextTick(() => {
          this.$refs.tableRow1.toggleRowSelection(row);
        });
      });
      listFilter = [];
      this.list2.filter(item => {
        this.checkList.xxkList.filter(v => {
          if (item.jxb == v) {
            listFilter.push(item);
          }
        });
      });
      listFilter.forEach(row => {
        this.$nextTick(() => {
          this.$refs.tableRow2.toggleRowSelection(row);
        });
      });
    },
    // 退补选通过学院、专业筛选计划外课程
    getList() {
      var gridData = []; // 将计划外课程声明到一个空的数组中，防止每次循环时都将数组重复累加
      // 通过将 vm.$data 传入 JSON.parse(JSON.stringify(...)) 得到深拷贝的原始数据对象。方式拷贝原来的数据
      let list11 = JSON.parse(JSON.stringify(this.list1));
      let list22 = JSON.parse(JSON.stringify(this.list2));
      let list33 = JSON.parse(JSON.stringify(this.list3));
      // 用数组将声明的三个数组连接起来
      let concat = list11.concat(list22).concat(list33);
      // 去循环这三个数组中的每一项，找到每一项中对应的教学班，添加到声明的数组中。  目的--防止再次选课时已选班级不会再次渲染到页面上
      this.repeatclass = []; // 将所选的课程声明到一个空的数组中，防止每次循环时都将数组重复累加
      concat.map(v => {
        this.repeatclass.push(v.kch);
      });
      this.$http
        .post("/api/cultivate/xk/selectJhwkc", {
          dwh: this.form.kkdw,
          pageNum: this.jhwkepage.pageNum,
          pageSize: this.jhwkepage.pageSize,
          zyh: this.form.sszy,
          kchs: this.repeatclass
        })
        .then(res => {
          this.gridData = res.data.data.list;
          this.jhwkepage.msgCount = res.data.data.total;
          console.log(this.gridData, "计划外课程的数据");
          // console.log(res.data.data.size,'计划外课程的大小')
          // 循环遍历计划外课程中的每一项，找到对应的值
          this.gridData.forEach(item => {
            this.$set(item, "bjmc0", item.kcList[0].bjmc); // 默认保存教学班下拉选的第一项，将它存起来。给它起一个bjmc0别名。在页面上可以直接取值。相当于缓存
            this.$set(item, "skjszc", item.kcList[0]); // 默认保存该门课的第一项，将它存起来。给它起一个skjszc别名。在页面上可以直接取值。相当于缓存
          });
        });
    },
    // 申请表信息动态添加行
    showfrom() {
      this.connectDialogVisible = true;
      // this.getList();
      this.getDwList();
      if (this.form.kkdw.length != 0 && this.form.sszy.length != 0) {
        // this.getList();
        this.getDwList();
      }
      this.copySel = [];
    },
    // 先获取学院的单位号，根据单位号再去过滤学院和专业
    getDwList() {
      this.$http.get("/api/cultivate/pygrpyjhb/selectDwList").then(res => {
        let data = res.data.data;
        this.dwList = [];
        data.map(item => {
          let obj = {
            value: item.dwh,
            label: item.dwmc
          };
          this.dwList.push(obj);
        });
      });
    },
    // 根据学院查询专业
    selectChange(val) {
      if (val != null) {
        this.$http
          .get("/api/cultivate/pygrpyjhb/selectZyByDwh", {
            params: {
              dwh: val
            }
          })
          .then(res => {
            let data = res.data.data;
            this.majorList = [];
            data.map(item => {
              let obj = {
                value: item.zyh,
                label: item.zymc
              };
              this.majorList.push(obj);
            });
            // 查询出新专业，原来选择的专业清空
            this.selectClear2();
          });
      }
    },
    // 查询
    handleFind() {
      if (this.form.kkdw.length == 0 || this.form.sszy.length == 0) {
        this.$message.error("请选择学院和专业！");
        return false;
      }
      // this.getDwList();
      this.getList(); // 点击查询时获取计划外课程中的数据
    },
    // 查询下拉框清除事件
    selectClear1() {
      this.form.kkdw = "";
      this.form.sszy = "";
      this.gridData = [];
      // this.getList();
    },
    selectClear2() {
      this.form.sszy = this.majorList[0].value;
      this.gridData = [];
    },
    // 申请表信息动态减少行
    delRow(index) {
      this.list3.splice(index, 1);
    },
    // 计算已选门数，学分，学时
    getSum() {
      if (this.list3.length == 0) {
        this.sum.yxms = 0;
        this.sum.yxxf = 0;
        this.sum.yxxs = 0;
        this.sum.kcid = "";
        this.jhwSave.jhwmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.jhwSave.jhwkc = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
        this.jhwKchs = [];
      }
      if (this.list3.length == 1) {
        this.sum.yxms = this.list3.length;
        this.sum.yxxf = this.list3[0].xf;
        this.sum.yxxs = this.list3[0].zxs;
        this.sum.kcid = this.list3[0].kcid;
        this.jhwSave.jhwmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.jhwSave.jhwkc = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
        this.jhwKchs = [];
        this.jhwKchs.push(this.list3[0].kch);
      }
      if (this.list3.length > 1) {
        this.sum.xfList = this.list3.map(item => {
          return Number(item.xf);
        });
        this.sum.xsList = this.list3.map(item => {
          return Number(item.zxs);
        });
        this.sum.kcidList = this.list3.map(item => {
          return item.kcid;
        });
        this.sum.yxms = this.list3.length;
        this.sum.yxxf = this.sumArr1(this.sum.xfList);
        this.sum.yxxs = this.sumArr1(this.sum.xsList);
        this.sum.kcid = this.sum.kcidList.join(",");
        this.jhwSave.jhwmath = `${this.sum.yxms},${this.sum.yxxf},${this.sum.yxxs}`;
        this.jhwSave.jhwkc = this.sum.kcid;
        this.$emit("listenChild", this.sum.yxxf);
        this.jhwKchs = [];
        this.list3.map(item => {
          this.jhwKchs.push(item.kch);
        });
      }
    },
    // 当计划外课程所选的值发生改变时，添加到外部的计划外课程也会做出相应的改变
    handleSelectionChange(selection) {
      this.copySel = [];
      this.copySel = selection;
      this.newValue = []; // 声明一个新的数组，将选中后的每一项通过循环都添加到这个数组中。防止累加
      selection.map(item => {
        this.newValue.push(item);
      });
    },
    sumArr1(arr) {
      // 计算学分
      let sum = 0;
      arr.forEach(val => {
        sum += val;
      });
      // 保留小数点后面几位小数
      return sum.toFixed(1);
    },
    getList1() {
      // 获取学位课里面的数据
      return new Promise(resolve => {
        this.$http
          .get(
            "/api/cultivate/xk/selectXwk/" +
              this.limitQuery.pageNum +
              "/" +
              this.limitQuery.pageSize
          )
          .then(res => {
            this.tableLoading1 = false;
            this.msgCount = res.data.data.total;
            this.xwpage = this.msgCount; // 将学位课的分页条数赋值给声明的学位课中
            this.list1 = res.data.data.list;
            if (this.list1.length > 0) {
              this.list1.forEach(item => {
                let tmpArr = item.jxbList.filter(el => {
                  return this.checkList.xwkList.includes(el.pksjId);
                });
                // if (tmpArr.length === 0) tmpArr = [item.jxbList[0]];
                if (tmpArr.length > 0) {
                  this.$set(item, "jxb", tmpArr[0].pksjId);
                  item.bjmc = tmpArr[0].bjmc;
                  item.jsxm = tmpArr[0].jsxm;
                  item.sksjddList = tmpArr[0].sksjddList;
                  item.xdrs = tmpArr[0].xdrs;
                  item.xkrsxd = tmpArr[0].xkrsxd;
                }
              });
              resolve();
            }
          });
      });
    },
    getList2() {
      // 获取选修课里面的数据
      return new Promise(resolve => {
        this.$http
          .get(
            "/api/cultivate/xk/selectXxk/" +
              this.limitQuery.pageNum +
              "/" +
              this.limitQuery.pageSize
          )
          .then(res => {
            this.tableLoading2 = false;
            // this.msgCount = res.data.data.total;
            this.xxpage = res.data.data.total; // 将选修课的条数赋值给声明的选修课的分页条数
            this.list2 = res.data.data.list;
            if (this.list2.length > 0) {
              this.list2.forEach(item => {
                let tmpArr = item.jxbList.filter(el => {
                  return this.checkList.xxkList.includes(el.pksjId);
                });
                if (tmpArr.length === 0) tmpArr = [item.jxbList[0]];
                this.$set(item, "jxb", tmpArr[0].pksjId);
                item.bjmc = tmpArr[0].bjmc;
                item.jsxm = tmpArr[0].jsxm;
                item.sksjddList = tmpArr[0].sksjddList;
                item.xdrs = tmpArr[0].xdrs;
                item.xkrsxd = tmpArr[0].xkrsxd;
              });
            }
            resolve();
            console.log(this.list2, "list2");
          });
      });
    },
    handleAdd() {
      this.connectDialogVisible = false;
      // 点击确定的时候将所选的课程传递到计划外课程的页面，没有选择的不推送
      // 将计划外课程数据进行循环，若该项没有选择则不推送这一项数组
      for (let i = 0, len = this.gridData.length; i < len; i++) {
        this.gridData.pop();
      }
      let obj = {}; // 因为弹窗中所选的计划外课程的数据和推送到外部的计划外课程的数据展示的数据不一致。所以声明一个新的对象再push到计划外课程中，以保证数据的一致性
      // this.newValue通过change事件改变后已选的一些数组。去循环已选的数组中的每一项。声明的obj中的内容与外部展示的内容保持一致
      this.newValue.forEach(item => {
        // console.log(item, "复制");
        obj = {
          bh: "",
          bjmc: item.bjmc0,
          id: item.skjszc.id,
          jsxm: item.skjszc.jzgXm,
          kch: item.skjszc.kch,
          kcmc: item.kcmc,
          kcxzh: "",
          sjddList: item.skjszc.sjjdList,
          xdrs: item.skjszc.xdrs,
          xkrsxd: item.skjszc.xkrsxd
        };
        this.list3.push(obj); // 将已选的计划外课程添加到外部的计划外课程中
      });
    },
    getList3() {
      return new Promise(resolve => {
        this.$http
          .get(
            "/api/cultivate/xk/selectJhwkc/" +
              this.limitQuery.pageNum +
              "/" +
              this.limitQuery.pageSize
          )
          .then(res => {
            this.tableLoading3 = false;
            if (res.data.data.list.length > 0) {
              this.jhwpage = res.data.data.total; // 将计划外课程的条数赋值给声明的计划外课程中
              this.list3 = res.data.data.list; // 取到计划外课程中所有的数据
            }
            resolve();
          });
      });
    },
    selectedToggle() {
      // 切换学位课、选修课、计划外课程时需要展示的数据
      Promise.all([this.getList1(), this.getList2(), this.getList3()]).then(
        () => {
          this.getChecked1();
        }
      );
    },
    // 学位课教学班选择改变事件
    jxbSelect(val, row) {
      row.jxbList.forEach(item => {
        if (val == item.pksjId) {
          row.pksjId = item.pksjId;
          row.bjmc = item.bjmc;
          row.jsxm = item.jsxm;
          row.sksjddList = item.sksjddList;
          row.xdrs = item.xdrs;
        }
      });
      this.idList1 = this.historyList1.map(item => {
        return item.jxb;
      });
      this.idList2 = this.historyList2.map(item => {
        return item.jxb;
      });
      this.idList3 = this.historyList3.map(item => {
        // console.log(this.idList3, "ddd");
        return item.jxb;
      });
    },
    jxbSelect1(row, valindex) {
      // 学位课、选修课的教学班里面的数据发生改变时做出相应的处理
      row.kcList.forEach(el => {
        if (el.bjmc === valindex) return (row.skjszc = el);
        if (el.sksjddList === valindex) return (row.sksjddList = el);
        if (el.xdrs === valindex) return (row.xdrs = el);
        if (el.xkrsxd === valindex) return (row.xkrsxd = el);
      });
      console.log(row, valindex);
    },
    jxbSelect2(row, valindex) {
      // 将要添加的计划外课程的数据发生改变时做出相应的处理
      console.log(this.gridData);
      row.kcList.map(el => {
        if (el.bjmc === valindex) return (row.skjszc = el);
      });
    },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    tableCellColor({ row, columnIndex }) {
      if (Number(row.yxrs) >= Number(row.xdrs) && columnIndex == 8) {
        return "color:#F56C6C";
      }
    },
    // 有两个参数返回，表格的每一行对象和当前索引,true可选 false不可选
    handleDisable(row) {
      if (Number(row.yxrs) >= Number(row.xdrs)) {
        return false;
      } else {
        // 学位课默认不可选
        if (this.activeName === "first") {
          return false;
        } else {
          console.log(this.activeName);
          return row.lx == 1;
        }
      }
    },
    // 学位课选中某一行时查找改行的jxb
    handleSelectionChange1(selection) {
      this.historyList1 = selection;
      this.idList1 = selection.map(item => {
        return item.jxb;
      });
    },
    // 选修课选中某一行时查找改行的jxb
    handleSelectionChange2(selection) {
      this.historyList2 = selection;
      this.idList2 = selection.map(item => {
        return item.jxb;
      });
    },
    // 计划外课程选中某一行时查找改行的jxb
    handleSelectionChange3(selection) {
      this.historyList3 = selection;
      this.idList3 = selection.map(item => {
        return item.jxb;
      });
      console.log();
    },
    // 点击列表选中
    clickRow1(row) {
      this.$refs.tableRow1.toggleRowSelection(row);
    },
    clickRow2(row) {
      this.$refs.tableRow2.toggleRowSelection(row);
    },
    clickRow3(row) {
      this.$refs.tableRow3.toggleRowSelection(row);
    },
    jhwkcTable(row) {
      // 计划外课程添加行
      this.$refs.tableData.toggleRowSelection(row);
    },
    // 监听三种课程分页条数的变化
    selClass(val) {
      if (val.name == "second") {
        this.msgCount = this.xxpage;
      } else if (val.name == "third") {
        this.msgCount = this.jhwpage;
      } else if (val.name == "first") {
        this.msgCount = this.xwpage;
      }
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    tableHeight() {
      return this.$store.getters.getTableHeight - 144;
    },
    userStatus() {
      return this.$store.getters.getStatus;
    },
    xnxq() {
      return this.$store.state.userxnxq;
    }
  }
};
</script>

<style lang="scss" scoped>
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  .left {
    flex: 1;
  }
  .center {
    flex: 1.5;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.showbtn {
  background-color: #fff;
  color: #409eff;
  border: 1px solid #409eff;
  position: absolute;
  right: 100px;
  height: 30px;
  line-height: 5px;
  margin-top: 5px;
  z-index: 1000;
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      height: 57px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.header {
  height: $tab-height;
  margin-bottom: $top;
  /deep/ .el-select {
    margin-left: 4px;
  }
  .el-button {
    margin-left: $left;
  }
}
/deep/ .el-input__suffix {
  right: 20px;
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
}
.timetable /deep/ .el-tabs__nav {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  width: 33.3%;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
.jhwkc /deep/ .el-form-item__label {
  padding: 0;
}
</style>
