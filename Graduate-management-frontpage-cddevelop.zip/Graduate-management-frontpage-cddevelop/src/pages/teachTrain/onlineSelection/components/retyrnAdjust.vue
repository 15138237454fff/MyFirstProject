<template>
  <!-- 在线选课 春季选课 点击调整跳转到提交页面-->
  <div class="inside">
    <div class="head">
      <div class="left">
        请于
        <span class="mark">{{ this.$tagTime(time, "yyyy-MM-dd") }}</span>
        前完成选课
      </div>
      <div class="center">
        <span class="block"></span>
        <span class="title">{{ xnxq.label }} 选课</span>
        <span class="block"></span>
      </div>
    </div>
    <div class="timetable">
      <el-tabs v-model="activeName" @tab-click="selClass">
        <el-tab-pane label="学位课" name="first">
          <el-table
            :data="list1"
            ref="tableRow1"
            border
            :height="tableHeight"
            :header-cell-style="tableHeaderColor"
            :cell-style="tableCellColor"
            v-loading="tableLoading1"
            element-loading-background="rgba(255, 255, 255,1)"
            row-key="kch"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              :key="Math.random()"
              width="160"
            ></el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    `${item.jsmc}`
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="选修课" name="second">
          <el-table
            :data="list2"
            ref="tableRow2"
            border
            :header-cell-style="tableHeaderColor"
            :height="tableHeight"
            :cell-style="tableCellColor"
            v-loading="tableLoading2"
            element-loading-background="rgba(255, 255, 255,1)"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              width="160"
            ></el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    `${item.jsmc}`
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="计划外课程" name="third">
          <el-table
            :data="list3"
            ref="tableRow3"
            border
            :header-cell-style="tableHeaderColor"
            :height="tableHeight"
            :cell-style="tableCellColor"
          >
            <el-table-column
              prop="kcmc"
              label="课程名称"
              align="center"
              width="150"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="kcxzh"
              label="课程性质"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="bjmc"
              label="教学班"
              align="center"
              width="160"
            ></el-table-column>
            <el-table-column
              prop="jsxm"
              label="授课教师"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="sksj"
              label="上课时间、地点"
              align="center"
              width="330"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <div v-for="(item, index) in scope.row.sksjddList" :key="index">
                  <span>{{ item.zc }}周</span>
                  <span style="margin-left:7px">{{
                    item.sfmz == 1
                      ? "(每周)"
                      : item.sfmz == 2
                      ? "(单周)"
                      : item.sfmz == 3
                      ? "(双周)"
                      : ""
                  }}</span>
                  <span style="margin-left:7px">{{ item.xq | xqFilter }}</span>
                  <span style="margin-left:7px">{{ item.kj }}节</span>
                  <span style="margin-left:7px" v-show="item.skdd">{{
                    `${item.jsmc}`
                  }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column
              prop="xdrs"
              label="限定人数"
              align="center"
            ></el-table-column>
            <el-table-column
              prop="xkrsxd"
              label="已选人数"
              align="center"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
export default {
  name: "applyDetail",
  components: {
    "my-pagination": myPagination
  },
  props: {
    time: {}
  },
  data() {
    return {
      activeName: "first",
      list1: [], // 学生选过课之后的学位课数组
      list2: [],
      list3: [],
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      xwpage: 0,
      xxpage: 0,
      jhwpage: 0,
      zyh: "081704",
      jxbList: [], // 学位课展示的集合
      id1: null,
      id2: null,
      id3: null,
      ids: null,
      idList: [],
      idList1: [],
      idList2: [],
      idList3: [],
      historyList1: [],
      historyList2: [],
      historyList3: [],
      kclxList1: [],
      kclxList2: [],
      kclxList3: [],
      msgCount: 0,
      tableLoading1: true,
      tableLoading2: true
    };
  },
  created() {
    this.getList();
  },
  computed() {
    this.$store.commit("uplodexnxq");
  },
  methods: {
    // 获取已选的课程，将选过的课展示在详情页面
    getList() {
      this.$http.get("/api/cultivate/xk/selectyxXwk/2").then(res => {
        this.tableLoading1 = false;
        this.tableLoading2 = false;
        let tmpResult = res.data.data.xwkList;
        // console.log(res.data.data,'xuewei')
        tmpResult.forEach(item => {
          if (item.length == 1) {
            item.jxb = item[0].pksjId;
            item.bjmc = item[0].bjmc;
            item.jsxm = item[0].jsxm;
            item.sksjddList = item[0].sksjddList;
            item.xdrs = item[0].xdrs;
            item.xkrsxd = item[0].xkrsxd;
          }
          if (item.length > 1) {
            item.jxb = item[0].pksjId;
            item.bjmc = item[0].bjmc;
            item.jsxm = item[0].jsxm;
            item.sksjddList = item[0].sksjddList;
            item.xdrs = item[0].xdrs;
            item.xkrsxd = item[0].xkrsxd;
          }
        });
        // 调用自定义全局的添加对象属性的方法
        this.list1 = tmpResult;
        this.msgCount = this.list1.length;
        this.xwpage = this.list1.length;
        this.list1.forEach(el =>
          this.$refs.tableRow1.toggleRowSelection(el, true)
        );
        let tmpResult1 = res.data.data.xxkList;
        //  console.log(res.data.data.xxkList,'xuanxiu')
        tmpResult1.forEach(item => {
          if (item.length == 1) {
            item.jxb = item[0].pksjId;
            item.bjmc = item[0].bjmc;
            item.jsxm = item[0].jsxm;
            item.sksjddList = item[0].sksjddList;
            item.xdrs = item[0].xdrs;
            item.xkrsxd = item[0].xkrsxd;
          }
          if (item.length > 1) {
            item.jxb = item[0].pksjId;
            item.bjmc = item[0].bjmc;
            item.jsxm = item[0].jsxm;
            item.sksjddList = item[0].sksjddList;
            item.xdrs = item[0].xdrs;
            item.xkrsxd = item[0].xkrsxd;
          }
        });
        // 调用自定义全局的添加对象属性的方法
        this.list2 = tmpResult1;
        this.xxpage = this.list2.length;
        this.list2.forEach(el =>
          this.$refs.tableRow2.toggleRowSelection(el, true)
        );
        // 计划外课程
        let tmpResult2 = res.data.data.jhwList;
        //  console.log(res.data.data.xxkList,'xuanxiu')
        tmpResult2.forEach(item => {
          if (item.length == 1) {
            item.jxb = item[0].pksjId;
            item.bjmc = item[0].bjmc;
            item.jsxm = item[0].jsxm;
            item.sksjddList = item[0].sksjddList;
            item.xdrs = item[0].xdrs;
            item.xkrsxd = item[0].xkrsxd;
          }
          if (item.length > 1) {
            item.jxb = item[0].pksjId;
            item.bjmc = item[0].bjmc;
            item.jsxm = item[0].jsxm;
            item.sksjddList = item[0].sksjddList;
            item.xdrs = item[0].xdrs;
            item.xkrsxd = item[0].xkrsxd;
          }
        });
        // 调用自定义全局的添加对象属性的方法
        this.list3 = tmpResult2;
        this.jhwpage = this.list3.length;
        this.list3.forEach(el =>
          this.$refs.tableRow3.toggleRowSelection(el, true)
        );
      });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      this.getList();
    },
    // getList1() {
    //   this.$http
    //     .get(
    //       "/api/cultivate/xk/selectXwk/" +
    //         this.xnxq +
    //         "/" +
    //         this.limitQuery.pageNum +
    //         "/" +
    //         this.limitQuery.pageSize
    //     )
    //     .then(res => {
    //       // //console.log(res.data.data)
    //       this.msgCount = res.data.data.total;
    //       let tmpResult = res.data.data.list;
    //       tmpResult.forEach(item => {
    //         // console.log(item);
    //         if (item.jxbList.length == 1) {
    //           item.jxb = item.jxbList[0].pksjId;
    //           item.bjmc = item.jxbList[0].bjmc;
    //           item.jsxm = item.jxbList[0].jsxm;
    //           item.sksjddList = item.jxbList[0].sksjddList;
    //           item.xdrs = item.jxbList[0].xdrs;
    //           item.xkrsxd = item.jxbList[0].xkrsxd;
    //         }
    //         if (item.jxbList.length > 1) {
    //           item.jxb = item.jxbList[0].pksjId;
    //           item.bjmc = item.jxbList[0].bjmc;
    //           item.jsxm = item.jxbList[0].jsxm;
    //           item.sksjddList = item.jxbList[0].sksjddList;
    //           item.xdrs = item.jxbList[0].xdrs;
    //           item.xkrsxd = item.jxbList[0].xkrsxd;
    //         }
    //       });
    //       // 调用自定义全局的添加对象属性的方法
    //       this.list1 = tmpResult;
    //       this.list1.forEach(el =>
    //         this.$refs.tableRow1.toggleRowSelection(el, true)
    //       );
    //     });
    // },
    // getList2() {
    //   this.$http
    //     .get(
    //       "/api/cultivate/xk/selectXxk/" +
    //         this.xnxq +
    //         "/" +
    //         this.limitQuery.pageNum +
    //         "/" +
    //         this.limitQuery.pageSize
    //     )
    //     .then(res => {
    //       // console.log(res.data.data);
    //       this.msgCount = res.data.data.total;
    //       let tmpResult = res.data.data.list;
    //       tmpResult.forEach(item => {
    //         if (item.jxbList.length == 1) {
    //           item.jxb = item.jxbList[0].pksjId;
    //           item.bjmc = item.jxbList[0].bjmc;
    //           item.jsxm = item.jxbList[0].jsxm;
    //           item.sksjddList = item.jxbList[0].sksjddList;
    //           item.xdrs = item.jxbList[0].xdrs;
    //           item.xkrsxd = item.jxbList[0].xkrsxd;
    //         }
    //         if (item.jxbList.length > 1) {
    //           item.jxb = item.jxbList[0].pksjId;
    //           item.bjmc = item.jxbList[0].bjmc;
    //           item.jsxm = item.jxbList[0].jsxm;
    //           item.sksjddList = item.jxbList[0].sksjddList;
    //           item.xdrs = item.jxbList[0].xdrs;
    //           item.xkrsxd = item.jxbList[0].xkrsxd;
    //         }
    //       });
    //       // 调用自定义全局的添加对象属性的方法
    //       this.list2 = tmpResult;
    //     });
    // },
    getRowKeys(row) {
      row.jxbList.map(item => {
        return item.pksjId;
      });
    },
    // 学位课教学班选择改变事件
    // jxbSelect(val, row) {
    //   row.jxbList.map(item => {
    //     if (val == item.pksjId) {
    //       row.pksjId = item.pksjId;
    //       row.jsxm = item.jsxm;
    //       row.sksjddList = item.sksjddList;
    //       row.xdrs = item.xdrs;
    //       row.xkrsxd = item.xkrsxd;
    //     }
    //   });
    //   this.idList1 = this.historyList1.map(item => {
    //     return item.jxb;
    //   });
    //   this.idList2 = this.historyList2.map(item => {
    //     return item.jxb;
    //   });
    //   this.idList3 = this.historyList3.map(item => {
    //     return item.jxb;
    //   });
    // },
    // 自定义table表头颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex == 0) {
        // #f5f7fa
        return "background-color:#f2f2f2;font-weight:500";
      }
    },
    tableCellColor({ row, columnIndex }) {
      // //console.log(Number(row.yxrs)>Number(row.xdrs))
      if (Number(row.yxrs) >= Number(row.xdrs) && columnIndex == 8) {
        return "color:#F56C6C";
      }
    },
    selClass(val) {
      if (val.name == "second") {
        this.msgCount = this.xxpage;
      } else if (val.name == "third") {
        this.msgCount = this.jhwpage;
      } else if (val.name == "first") {
        this.msgCount = this.xwpage;
      }
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    tableHeight() {
      return this.$store.getters.getTableHeight - 144;
    },
    xnxq() {
      return this.$store.state.userxnxq;
    }
  }
};
</script>

<style lang="scss" scoped>
.head {
  display: flex;
  height: 50px;
  line-height: 50px;
  .left {
    flex: 1;
  }
  .center {
    flex: 1.5;
    .title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
}
.mark {
  color: $blue;
}
.block {
  font-size: 16px;
  width: 10px;
  height: 10px;
  background-color: $blue;
  display: inline-block;
}
.table-box {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
}
.timetable {
  border: 1px solid rgba(228, 228, 228, 1);
  margin-top: 15px;
  .table-top {
    background: #f2f2f2;
    padding: 10px;
    margin-bottom: 15px;
    .sum-left {
      margin-left: 30px;
    }
    .sum-right {
      text-align: right;
      padding-right: 15px;
      box-sizing: border-box;
    }
    .sum-num {
      color: $blue;
    }
  }
}
.timetable /deep/ .el-tabs__nav {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  width: 50%;
}
.timetable /deep/ .el-tabs__item {
  text-align: center;
}
</style>
