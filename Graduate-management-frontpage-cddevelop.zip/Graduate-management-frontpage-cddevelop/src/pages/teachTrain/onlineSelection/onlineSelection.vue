<template>
  <!-- 在线选课 onlineSelection -->
  <div class="my-plan">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }"
            >教学培养</el-breadcrumb-item
          >
          <el-breadcrumb-item>在线选课</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <!-- 第一次选课时，显示退补选选课的按钮 -->
        <el-button type="primary" @click="applySubmit" v-if="writeable"
          >提交</el-button
        >
        <!-- 学生第一次选课后进入详情展示页面，若在选课期间内学生点击调整可以对所选课程进行更改 -->
        <div v-if="flag == false">
          <el-button
            type="primary"
            @click="applyModify"
            v-if="this.$route.params.id == 2 || this.$route.params.id == 4"
            >调整</el-button
          >
        </div>
        <!-- 若学生是第一次选课，且在第一次选课时间内则点击调整时跳转到第一次选课的页面进行调整（不显示计划外课程） -->
        <!-- 若到了退补选选课的时间，点击调整按钮跳转到退补选选课（显示计划外课程） -->
        <!-- <div v-if="flagtbx==false">
          <el-button
            type="primary"
            @click="returnsec"
            v-if="this.$route.params.id == 2"
            >退补选选课</el-button
          >
        </div> -->
        <!-- <el-button type="primary" @click="adjustclass" v-else>调整退补选选课</el-button> -->
      </div>
    </my-breadcrumb>
    <div v-if="flag == true && flagtbx == true">
      <my-blank msg="还不能在线选课哦！" picUrl="blank.png"></my-blank>
    </div>
    <div class="box">
      <!-- params是携带参数传值  name名称   而query则是path -->
      <!-- 每个id对应的值 1：第一次选课 2：第一次选完课之后详情展示 3：退补选页面，且展示计划外排课 4：调整退补选选课  5:调整第一次选课-->
      <!-- 选课 -->

      <div v-show="flag == false">
        <apply
          ref="children"
          v-if="$route.params.id == 1"
          :time="endTime"
        ></apply>
        <apply-detail
          :time="endTime"
          ref="children2"
          v-if="$route.params.id == 2"
        ></apply-detail>
      </div>
      <adjustClass
        ref="children"
        v-if="$route.params.id == 5"
        :time="endTime"
      ></adjustClass>
      <!-- 退补选 -->
      <div v-show="flagtbx == false">
        <apply-save
          ref="children"
          v-if="$route.params.id == 3"
          :time="endTime"
        ></apply-save>
      </div>
      <retyrn-adjust
        :time="endTime"
        ref="children"
        v-if="$route.params.id == 4"
      ></retyrn-adjust>
    </div>
  </div>
</template>

<script>
import apply from "./components/apply";
import applyDetail from "./components/applyDetail";
import applySave from "./components/applySave";
import retyrnAdjust from "./components/retyrnAdjust";
import adjustClass from "./components/adjustClass";
import myBreadcrumb from "@/components/myBreadcrumb";
import { clearTimeout } from "timers";
import blank from "@/components/blank";
export default {
  name: "onlineSelection",
  components: {
    apply,
    applyDetail,
    applySave,
    adjustClass: adjustClass,
    "retyrn-adjust": retyrnAdjust,
    "my-breadcrumb": myBreadcrumb,
    "my-blank": blank
  },
  data() {
    return {
      idLists: [],
      ids: null,
      kclxList: [],
      kclx: null,
      disabled: false,
      timer: 0,
      addnum: 0,
      jhwId: [],
      flag: false,
      flagtbx: false,
      endTime: null
    };
  },
  created() {
    if (this.$route.params.id == 1) this.requiredSelectd();
    this.kqgb();
    console.log(this.$route.params);
  },
  watch: {
    $route() {
      if (this.$route.params.id == 1) this.requiredSelectd();
    }
  },
  methods: {
    //判断在线选课时间是否开启
    kqgb() {
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=xsxksj")
        .then(res => {
          if (res.data.data.isOpen == 1) {
            //选课时间开启
            this.flag = false;
            this.endTime = res.data.data.endTime;
            // this.$router.push({
            //   path: "/teachTrain/onlineSelection/2"
            // });
          }
          if (res.data.data.isOpen == 0) {
            //若选课时间关闭则判断退补选时间是否开启
            this.flag = true;
            this.kqtbx();
          }
        });
    },
    //判断退补选时间是否开启
    kqtbx() {
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=tbxsj")
        .then(res => {
          if (res.data.data.isOpen == 1) {
            //若退补选时间开启
            this.flagtbx = false;
            this.endTime = res.data.data.endTime;
            this.$router.push({
              path: "/teachTrain/onlineSelection/3"
            });
          }
          if (res.data.data.isOpen == 0) {
            //若退补选时间开启
            this.flagtbx = true;
          }
        });
    },
    // 申请提交(提交分为3种情况。)
    applySubmit() {
      //1、第一次选课后提交，即id为1的时候。
      if (this.$route.params.id == 1) {
        //第一次提交选课 在子组件中定义的元素 即需要提交的班级id的值
        let list1 = this.$refs.children.idList1;
        let list2 = this.$refs.children.idList2;
        let url = "/api/cultivate/xk/save/";
        // url += this.$route.params.id == 1 ? "save" : "update";
        this.$http
          .post(url, {
            xwkIds: list1,
            xxkIds: list2,
            type: "first"
          })
          .then(res => {
            if (res.data.code == 202) {
              //当code 值为202的时候则需要进行轮询 此时会产生一个key值 取到这个key值 在轮询时使用
              window.sessionStorage.setItem("datacode", res.data.data);
              this.$http
                .get("/api/cultivate/xk/rollPolling?key=" + this.datacode)
                .then(res => {
                  if (res.data.code == 200) {
                    //若轮询时code值为200则选课成功，跳转至详情页
                    this.$message.success("选课成功");
                    clearInterval(this.timer);
                    this.$router.push({
                      path: "/teachTrain/onlineSelection/2"
                    });
                  } else if (res.data.code == 100001) {
                    //若code值为100001 则需要进行轮询，跳转到轮询的方法中
                    clearInterval(this.timer);
                    this.polling();
                  }
                });
            } else if (res.data.code == 200) {
              this.$router.push({
                path: "/teachTrain/onlineSelection/2"
              });
              this.$message.success(res.data.message);
            } else {
              this.$message.error(res.data.message);
            }
          });
      }
      //2、第一次选课后进行调整选课的提交，即id为5的时候。
      if (this.$route.params.id == 5) {
        //调整第一次选择的课后提交
        let list1 = this.$refs.children.idList1;
        let list2 = this.$refs.children.idList2;
        // let listall = this.$refs.children.checkall;
        let url = "/api/cultivate/xk/save/";
        this.$http
          .post(url, {
            xwkIds: list1,
            xxkIds: list2,
            // oldIds:listall,
            type: "second"
          })
          .then(res => {
            if (res.data.code == 202) {
              window.sessionStorage.setItem("datacode", res.data.data);
              this.$http
                .get("/api/cultivate/xk/rollPolling?key=" + this.datacode)
                .then(res => {
                  if (res.data.code == 200) {
                    this.$message.success("选课成功");
                    clearInterval(this.timer);
                    this.$router.push({
                      path: "/teachTrain/onlineSelection/2"
                    });
                  } else if (res.data.code == 100001) {
                    clearInterval(this.timer);
                    this.polling();
                  }
                });
            } else if (res.data.code == 200) {
              this.$router.push({
                path: "/teachTrain/onlineSelection/2"
              });
              this.$message.success(res.data.message);
            } else {
              this.$message.error(res.data.message);
            }
          });
      }
      //3、退补选选课的提交，即id为3的时候
      if (this.$route.params.id == 3) {
        this.jhwId = [];
        //提交退补选选课的内容
        let list1 = this.$refs.children.idList1;
        let list2 = this.$refs.children.idList2;
        let list3 = this.$refs.children.list3id;
        this.$refs.children.list3.map(v => {
          this.jhwId.push(v.id);
        });
        // console.log(list1, list2, list3, "所有选课的数据");
        let url = "/api/cultivate/xk/save/";
        this.$http
          .post(url, {
            xwkIds: list1,
            xxkIds: list2,
            jhwIds: this.jhwId,
            type: "other"
          })
          .then(res => {
            if (res.data.code == 202) {
              window.sessionStorage.setItem("datacode", res.data.data);
              this.$http
                .get("/api/cultivate/xk/rollPolling?key=" + this.datacode)
                .then(res => {
                  if (res.data.code == 200) {
                    this.$message.success("选课成功");
                    clearInterval(this.timer);
                    this.$router.push({
                      path: "/teachTrain/onlineSelection/4"
                    });
                  } else if (res.data.code == 100001) {
                    clearInterval(this.timer);
                    this.polling1();
                  } else {
                    this.$message.error(res.data.message);
                  }
                });
            } else if (res.data.code == 200) {
              this.$message.success("选课成功");
              this.$router.push({
                path: "/teachTrain/onlineSelection/4"
              });
            } else {
              this.$message.error(res.data.message);
            }
          });
      }
    },
    polling() {
      //设置一个定时器，每1s调用一次，当调用30次时停止定时器
      this.timer = setInterval(() => {
        this.$http
          .get("/api/cultivate/xk/rollPolling?key=" + this.datacode)
          .then(res => {
            if (res.data.code == 100001) {
              //当编码是100001时则需要调用该方法进行轮询  需要先清除定时器，否则方法会一直调用
              clearInterval(this.timer);
              this.polling();
            } else if (res.data.code == 200) {
              //如果在轮询时出现200则清除定时器，跳转至详情页面
              this.$message.success("选课成功");
              clearInterval(this.timer);
              this.$router.push({
                path: "/teachTrain/onlineSelection/2"
              });
            } else {
              //若为其他情况 如400 500 则清除定时器 直接报错
              clearInterval(this.timer);
              this.$message.error(res.data.message);
            }
            //当这个方法执行30次时清除掉定时器
            if (this.addnum == 29) {
              clearInterval(this.timer);
              this.$message.info("请刷新页面");
            }
          });
        this.addnum++;
      }, 1000);
    },
    polling1() {
      this.timer = setInterval(() => {
        this.$http
          .get("/api/cultivate/xk/rollPolling?key=" + this.datacode)
          .then(res => {
            if (res.data.code == 100001) {
              clearInterval(this.timer);
              this.polling();
            } else if (res.data.code == 200) {
              this.$message.success("选课成功");
              clearInterval(this.timer);
              this.$router.push({
                path: "/teachTrain/onlineSelection/4"
              });
            } else {
              clearInterval(this.timer);
              this.$message.error(res.data.message);
            }
            if (this.addnum == 29) {
              clearInterval(this.timer);
              this.$message.info("请刷新页面");
            }
          });
        this.addnum++;
      }, 1000);
    },
    //提交选课时要做一个轮询，若code=200则跳转到调整页面，若code值为其它则一直轮询
    // polling() {
    //   this.timer = setInterval(() => {
    //     this.$http.get("/api/cultivate/xk/rollPolling?key=" + this.datacode).then(res => {
    //         if (res.data.code == 200) {
    //           this.$message.success('选课成功');
    //           clearInterval(this.timer);
    //           this.$router.push({
    //             path: "/teachTrain/onlineSelection/2"
    //           });
    //         } else if (res.data.code == 100001) {
    //           this.polling();
    //           console.log(1);
    //         } else {
    //           this.$message.error(res.data.message);
    //           clearInterval(this.timer);
    //         }
    //         if (this.addnum == 30) {
    //           this.$message.info("请刷新页面");
    //           clearInterval(this.timer);
    //           console.log(this.addnum);
    //         }
    //       });
    //     this.addnum++;
    //   }, 1000);
    // },
    // polling1() {
    //   //退补选选课时需要做的轮询操作
    //   this.timer = setInterval(() => {
    //     this.$http
    //       .get("/api/cultivate/xk/rollPolling?key=" + this.datacode)
    //       .then(res => {
    //         if (res.data.code == 200) {
    //           this.$message.success('选课成功');
    //           clearInterval(this.timer);
    //           this.$router.push({
    //             path: "/teachTrain/onlineSelection/4"
    //           });
    //         } else if (res.data.code == 100001) {
    //           this.polling1();
    //           console.log(11);
    //         } else {
    //           this.$message.error(res.data.message);
    //           clearInterval(this.timer);
    //         }
    //         if (this.addnum == 30) {
    //           this.$message.info("请刷新页面");
    //           clearInterval(this.timer);
    //           console.log(this.addnum);
    //         }
    //       });
    //     this.addnum++;
    //   }, 1000);
    // },
    applyModify() {
      //调整时要做一个判断，当在第一次选课时间内则进行第一次选课的页面调整，在退补选时间内则进行退补选选课的调整
      //第一次选课后的详情页点击调整按钮进行调整
      if (this.$route.params.id == 2) {
        console.log("111");
        this.$router.push("/teachTrain/onlineSelection/5");
      }
      //退补选选课后的详情页点击调整按钮进行调整
      if (this.$route.params.id == 4) {
        this.$router.push("/teachTrain/onlineSelection/3");
      }
    },
    // 请求学生是否选过课
    requiredSelectd() {
      this.$http.get(`/api/cultivate/xk/init`).then(res => {
        let data = res.data.data;
        // 如果第一次已经选过课，则跳转到详情展示页面 对应的是页面是2
        if (data) {
          this.$router.push({
            path: "/teachTrain/onlineSelection/2"
          });
        }
      });
    },
    //点击退补选选课会跳转到二次选课，即退补选选课的页面。此时将展示计划外的课程，学生要根据它的分数展现出来
    returnsec() {
      this.$router.push("/teachTrain/onlineSelection/3");
    }
    // adjustclass() {
    //   this.$router.push("/teachTrain/onlineSelection/4");
    // }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    },
    datacode() {
      return sessionStorage.getItem("datacode");
    },
    // 是否可编辑
    writeable() {
      //点击提交后跳转到详情展示的页面
      if (this.$route.params.id == 2 || this.$route.params.id == 4) {
        return false;
      } else {
        return true;
      }
    }
    // // 是否可编辑
    // adjust() {
    //   //点击提交后跳转到详情展示的页面
    //   if (this.$route.params.id == 5) {
    //     return false;
    //   } else {
    //     return true;
    //   }
    // },
    //是否可以退补选
    // adjustable() {
    //   if (this.$route.params.id == 3) {
    //     return false;
    //   } else {
    //     return true;
    //   }
    // }
  }
};
</script>

<style lang="scss" scoped>
.my-plan {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
  }
}
</style>
