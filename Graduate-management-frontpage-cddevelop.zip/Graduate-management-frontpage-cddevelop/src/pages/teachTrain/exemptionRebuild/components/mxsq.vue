<template>
  <!-- 申请课程免修 -->
  <div class="table-box">
    <table border="1" cellspacing="0" cellpadding="10">
      <thead></thead>
      <tbody>
        <th colspan="6">浙江财经大学研究生免修申请表</th>
        <tr>
          <td>姓名</td>
          <td>{{ userInfo.xm }}</td>
          <td>学号</td>
          <td>{{ userInfo.xh }}</td>
          <td>学生类别</td>
          <td>{{ userInfo.xslbmc }}</td>
        </tr>
        <tr>
          <td>所属学院</td>
          <td>{{ userInfo.yxsh }}</td>
          <td>所属专业</td>
          <td>{{ userInfo.zy }}</td>
          <td>导师</td>
          <td>{{ userInfo.dsxm }}</td>
        </tr>
        <tr>
          <td class="moralHeight">&nbsp;&nbsp;免修课程</td>
          <td class="moralHeight">
            <el-select v-model="writeInfo.sqkc" placeholder="课程名称" style="width:100%;">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </td>
          <td class="moralHeight">&nbsp;&nbsp;学分</td>
          <td class="moralHeight">{{ userInfo.xf }}</td>
          <td class="moralHeight"></td>
          <td class="moralHeight"></td>
        </tr>
        <tr>
          <td colspan="6" style="background:none">
            <el-form>
              <el-form-item :required="true" label="申请理由：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 6, maxRows: 8}"
                  placeholder="请输入内容"
                  v-model="writeInfo.sqly"
                ></el-input>
              </el-form-item>
            </el-form>
          </td>
        </tr>
        <tr>
          <td style="background:none">附件：</td>
          <td colspan="5">
            <el-upload
              ref="upload"
              class="upload-demo"
              :headers="headers"
              action="/api/system/upload"
              :on-success="handleSuccess"
              :on-remove="handleRemove"
              multiple
              :limit="1"
            >
              <el-button size="small" type="primary" plain>
                点击上传
                <i class="el-icon-plus el-icon--right"></i>
              </el-button>
            </el-upload>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="tip">
      <div class="tip-left">
        <p>注：1. 申请英语免修，需附相关证明材料；申请专业课免修，需附原学习成绩单复印件，所学课程成绩自取得之日起四年内有效。</p>
        <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 申请免修的课程必须已列入经导师审核的研究生个人培养计划中。</p>
      </div>
      <div class="tip-right">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'mxsq',
  props: ['userInfo'],
  components: {},
  data () {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      tableData: [],
      value: '',
      writeInfo: {
        type: '0',
        fj: []
      },
      options: [
        {
          value: '1',
          label: '课程1'
        },
        {
          value: '2',
          label: '课程2'
        },
        {
          value: '3',
          label: '课程3'
        },
        {
          value: '4',
          label: '课程4'
        },
        {
          value: '5',
          label: '课程5'
        }
      ],
      // 保存当前选择的文件的列表
      dialogVisible: false
    }
  },
  created () {},
  mounted () {},
  computed: {},
  methods: {
    // 提交申请
    handleSubmit () {
      // console.log(this.writeInfo);
      this.dialogVisible = false
      if (!this.writeInfo.sqkc || !this.writeInfo.sqly) {
        this.$message.warning('请将必填项填写完整，再尝试提交')
        return false
      }
      this.$http.post('/api/cultivate/kcsq/start', this.writeInfo).then(res => {
        // console.log(res.data);
        if (res.data.code === 200) {
          this.$message.success('申请成功')
          // 清空附件
          this.$refs.upload.clearFiles()
          this.handleReset()
        }
      })
    },
    // 添加旁听课程
    addRow () {
      // console.log(222);
      let newValue = {
        kch: '',
        kcmc: '',
        xf: '',
        jxb: '',
        cj: '',
        kssj: '',
        skjs: ''
      }
      this.tableData.push(newValue)
    },
    // 删除旁听课程
    delRow (index) {
      this.tableData.splice(index, 1)
    },
    // 申请信息鼠标经过事件
    handleMouseEnter (column, cell) {
      // //console.log(row)
      if (column.label != '序号' && column.label != '操作') {
        cell.children[0].children[0].style.display = 'block'
        cell.children[0].children[1].style.display = 'none'
      }

      // this.tableData[num].editFlag = true;
    },
    // 申请信息鼠标经过移出事件
    handleMouseOut (column, cell) {
      // //console.log(column)
      if (column.label != '序号' && column.label != '操作') {
        cell.children[0].children[0].style.display = 'none'
        cell.children[0].children[1].style.display = 'block'
      }
    },
    // 删除文件的回调
    handleRemove () {
      // console.log("移除文件");
      this.writeInfo.fj.pop()
    },
    // 上传成功的回调
    handleSuccess (res) {
      this.writeInfo.fj.push(res.data)
      // console.log(res);
    },
    // 重置参数
    handleReset () {
      this.writeInfo.sqkc = ''
      this.writeInfo.sqly = ''
      this.fj = []
    }
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    // border-color: rgba(204, 204, 204, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }
    .moralHeight{
      padding:0;
      height: 40px;
    }
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
    td.grey {
      background-color: #f2f2f2;
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.tip {
  display: flex;
  .tip-left {
    flex: 3;
    margin-top: 8px;
    p {
      color: #f56c6c;
      font-size: 13px;
    }
  }
  .tip-right {
    flex: 1;
    margin-top:80px;
    text-align: right;
    line-height: 75px;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
.table-ptkc {
  .ptkc-head {
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    border-top: none;
    display: flex;
    padding: 10px;
    color: #333;
    .left {
      flex: 1;
      line-height: 32px;
    }
    .right {
      flex: 1;
      text-align: right;
    }
  }
}
</style>
