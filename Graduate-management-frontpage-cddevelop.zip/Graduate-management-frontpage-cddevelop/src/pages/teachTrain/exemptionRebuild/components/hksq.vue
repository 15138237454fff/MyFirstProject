<template>
  <!-- 申请课程缓考 -->
  <div class="table-box">
    <table border="1" cellspacing="0" cellpadding="10">
      <thead></thead>
      <tbody>
        <th colspan="6">浙江财经大学研究生缓考申请表</th>
        <tr>
          <td>姓名</td>
          <td>{{ userInfo.xm }}</td>
          <td>学号</td>
          <td>{{ userInfo.xh }}</td>
          <td>学生类别</td>
          <td>{{ userInfo.xslbmc }}</td>
        </tr>
        <tr>
          <td>所属学院</td>
          <td>{{ userInfo.yxsh }}</td>
          <td>所属专业</td>
          <td>{{ userInfo.zy }}</td>
          <td>导师</td>
          <td>{{ userInfo.dsxm }}</td>
        </tr>
        <tr>
          <td>缓考课程</td>
          <td>
            <el-select v-model="writeInfo.sqkc" placeholder="课程名称">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
          </td>
          <td>学分</td>
          <td>{{ userInfo.xf }}</td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td colspan="6" style="background:none">
            <el-form>
              <el-form-item :required="true" label="申请理由：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 6, maxRows: 8}"
                  placeholder="请输入内容"
                  v-model="writeInfo.sqly"
                ></el-input>
              </el-form-item>
            </el-form>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="tip-bottom">
      <div class="tip">
        <!-- <p>注： 学生须参加该课程全部教学环节。</p> -->
      </div>
      <div class="bottom">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'hksq',
  components: {},
  props: ['userInfo'],
  data () {
    return {
      options: [
        {
          value: '1',
          label: '课程1'
        },
        {
          value: '2',
          label: '课程2'
        },
        {
          value: '3',
          label: '课程3'
        },
        {
          value: '4',
          label: '课程4'
        },
        {
          value: '5',
          label: '课程5'
        }
      ],
      value: '',
      writeInfo: {
        type: '2',
        fj: []
      },
      dialogVisible: false
    }
  },
  created () {},
  mounted () {},
  computed: {},
  methods: {
    // 提交申请
    handleSubmit () {
      // console.log(this.writeInfo)
      this.dialogVisible = false
      if (!this.writeInfo.sqly || !this.writeInfo.sqkc) {
        this.$message.warning('请将必填项填写完整，再尝试提交')
        return false
      }
      this.$http.post('/api/cultivate/kcsq/start', this.writeInfo).then(res => {
        // console.log(res.data)
        if (res.data.code === 200) {
          this.$message.success('申请成功')
          this.handleReset()
        }
      })
    },
    // 重置参数
    handleReset () {
      this.writeInfo.sqkc = ''
      this.writeInfo.sqly = ''
      this.fj = []
    }
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    // border-color: rgba(204, 204, 204, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
    td.grey {
      background-color: #f2f2f2;
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.tip-bottom {
  display: flex;
  .tip {
    flex: 2;
    p {
      color: #f56c6c;
      font-size: 13px;
    }
  }
  .bottom {
    flex: 1;
    margin-top: 20px;
    text-align: right;
  }
}
</style>
