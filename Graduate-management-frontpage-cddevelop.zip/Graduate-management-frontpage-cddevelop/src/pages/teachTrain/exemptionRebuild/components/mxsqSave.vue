<template>
  <!-- 查看免修申请详情 -->
  <div class="table-box">
    <table border="1" cellspacing="0" cellpadding="10">
      <thead></thead>
      <tbody>
        <!-- <th colspan="6">浙江财经大学研究生免修申请表</th> -->
        <th colspan="6">
          <table-flag
            v-if="$route.params.id == 3 || $route.params.id == 4"
            :status="status"
            :time="time"
            :table-title="tableTitle"
          ></table-flag>
          <table-flag v-if="$route.matched[1].path == '/stuCourseAudit'" :table-title="tableTitle"></table-flag>
        </th>
        <tr>
          <td>姓名</td>
          <td>{{ userInfo.xm }}</td>
          <td>学号</td>
          <td>{{ userInfo.xh }}</td>
          <td>学生类别</td>
          <td>{{ userInfo.xslbmc }}</td>
        </tr>
        <tr>
          <td>所属学院</td>
          <td>{{ userInfo.yxsh }}</td>
          <td>所属专业</td>
          <td>{{ userInfo.zy }}</td>
          <td>导师</td>
          <td>{{ userInfo.dsxm }}</td>
        </tr>
        <tr>
          <td>免修课程</td>
          <td>
            <el-select
              v-model="writeInfo.sqkc"
              placeholder="课程名称"
              v-if="$route.matched[1].path !== '/stuCourseAudit' && status == 4"
            >
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              ></el-option>
            </el-select>
            <span v-else>{{writeInfo.sqkc}}</span>
          </td>
          <td>学分</td>
          <td>{{ userInfo.xf }}</td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td colspan="6" style="background:none">
            <el-form>
              <el-form-item :required="true" label="申请理由：">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 6, maxRows: 8}"
                  placeholder="请输入内容"
                  v-model="writeInfo.sqly"
                  v-if="$route.matched[1].path !== '/stuCourseAudit' && status == 4"
                ></el-input>
                <span v-else>{{writeInfo.sqly}}</span>
              </el-form-item>
            </el-form>
          </td>
        </tr>
        <tr v-if="$route.matched[1].path == '/stuCourseAudit' || status != 4">
          <td style="background:none">附件：</td>
          <td colspan="5">
            <ul class="fj">
              <li v-for="(item,index) of fj" :key="index">
                <a
                  :href="item.url"
                  target="_blank"
                  class="primary"
                  :download="item.fileName"
                >{{item.fileName}}</a>
              </li>
            </ul>
          </td>
        </tr>
        <tr v-else>
          <td style="background:none">附件：</td>
          <td colspan="5">
            <el-upload
              ref="upload"
              class="upload-demo"
              :headers="headers"
              action="/api/system/upload"
              :on-success="handleSuccess"
              multiple
              :limit="1"
              :file-list="fj"
            >
              <el-button size="small" type="primary" plain>
                点击上传
                <i class="el-icon-plus el-icon--right"></i>
              </el-button>
            </el-upload>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="table-ptkc">
      <div class="tip" v-show="$route.params.id == 4">
        <div class="tip-left">
          <p>注：1. 申请英语免修，需附相关证明材料；申请专业课免修，需附原学习成绩单复印件，所学课程成绩自取得之日起四年内有效。</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. 申请免修的课程必须已列入经导师审核的研究生个人培养计划中。</p>
        </div>
        <div class="tip-right">
          <el-button @click="handleReset">重置</el-button>
          <el-button type="primary" @click="handleUpdate">重新提交</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import tableFlag from "@/components/tableFlag";
export default {
  name: "mxsqSave",
  props: {
    userInfo: { default: {} }
  },
  components: {
    tableFlag
  },
  data() {
    return {
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      tableTitle: "浙江财经大学研究生免修申请表",
      time: "2019/05/18",
      status: "",
      input: "",
      options: [
        {
          value: "1",
          label: "课程1"
        },
        {
          value: "2",
          label: "课程2"
        },
        {
          value: "3",
          label: "课程3"
        },
        {
          value: "4",
          label: "课程4"
        },
        {
          value: "5",
          label: "课程5"
        }
      ],
      tableData: [],
      // userInfo: {}, //初始化数据
      writeInfo: {}, // 申请写入的数据,
      updateInfo: {}, // 修改提交的数据
      auditList: {}, // 审核流程图
      fj: [] // 保存选中文件的列表
    };
  },
  mounted() {},
  watch: {
    $route(to) {
      // 学生
      if (
        (to.path == "/teachTrain/exemptionRebuild/3" ||
          to.path == "/teachTrain/exemptionRebuild/4") &&
        to.query.sqlx == "0"
      ) {
        this.getData();
      }
      // 导师
      if ((to.query.check == 0 || to.query.check == 1) && to.query.mark == 2) {
        this.getData();
      }
    }
  },
  created() {
    // console.log(this.$route)
    if (
      (this.$route.path == "/teachTrain/exemptionRebuild/3" ||
        this.$route.path == "/teachTrain/exemptionRebuild/4") &&
      this.$route.query.sqlx == "0"
    ) {
      this.getData();
    }
    console.log(this.$route.path);
    if (
      (this.$route.query.check == 0 || this.$route.query.check == 1) &&
      this.$route.query.mark == 2 &&
      this.$route.path === "/stuCourseAudit"
    ) {
      this.getData();
    }
  },
  computed: {},
  methods: {
    // 查看详情
    getData() {
      this.$http
        .get("/api/cultivate/kcsq/infoByLcid", {
          params: {
            lcid: this.$route.query.lcid
          }
        })
        .then(res => {
          // console.log(res.data.data)
          let data = res.data.data;
          this.writeInfo = data.pyXskcsq;
          this.fj = data.pyXskcsq.fj;
          this.time = data.pyXskcsq.cjsj;
          this.status = data.pyXskcsq.zt;
          this.auditList = data.list;
          this.$store.state.auditList = this.auditList;
          this.$bus.$emit("stepList", this.auditList);
        });
    },
    // 修改提交
    handleUpdate() {
      this.writeInfo.firstfj = this.fj;
      this.$http
        .post("/api/cultivate/kcsq/update", this.writeInfo)
        .then(res => {
          // console.log(res.data)
          if (res.data.code === 200) {
            this.$message.success("修改成功");
            // 清空附件
            this.$refs.upload.clearFiles();
            this.getData();
            // 修改成功后后退
            this.$router.go(-1);
          }
        });
    },
    handleSuccess(res) {
      // console.log(res.data);
      if (res.data !== null) {
        this.fj.push(res.data);
      }
    },
    // 重置参数
    handleReset() {
      this.writeInfo.sqkc = "";
      this.writeInfo.sqly = "";
      this.fj = [];
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/styles/table.scss";
.table-box {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    // border-color: rgba(204, 204, 204, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }
    td {
      width: 100px;
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
    td.grey {
      background-color: #f2f2f2;
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.tip {
  display: flex;
  .tip-left {
    flex: 3;
    p {
      color: #f56c6c;
      font-size: 13px;
    }
  }
  .tip-right {
    flex: 1;
    text-align: right;
    line-height: 75px;
  }
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
.table-ptkc {
  .ptkc-head {
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);
    border-top: none;
    display: flex;
    padding: 10px;
    color: #333;
    .left {
      flex: 1;
      line-height: 32px;
    }
    .right {
      flex: 1;
      text-align: right;
    }
  }
}
</style>
