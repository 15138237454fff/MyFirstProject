<template>
  <div>
    <!-- 免修/重修/缓考  exemptionRebuild-->
    <div class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }">教学培养</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/teachTrain/exemptionRebuild/1'}">免修/重修/缓考</el-breadcrumb-item>
            <el-breadcrumb-item
              :to="{ path: '/teachTrain/exemptionRebuild/2'}"
              v-if="this.$route.params.id == 2 || this.$route.params.id == 3 || this.$route.params.id == 4"
            >申请记录</el-breadcrumb-item>
            <el-breadcrumb-item v-if="this.$route.params.id == 3">查看详情</el-breadcrumb-item>
            <el-breadcrumb-item v-if="this.$route.params.id == 4">修改</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <!-- <div slot="right">
          <div v-show="applyShow">
            <i class="el-icon-document"></i>

            <el-button type="text" @click="seeRecord">
              <el-badge class="item">
                <el-badge class="item">查看申请记录</el-badge>
              </el-badge>
            </el-button>
          </div>
          <div v-show="!applyShow">
            <i class="el-icon-d-arrow-left"></i>
            <el-button type="text" @click="handleBack">返回</el-button>
          </div>
        </div> -->
      </my-breadcrumb>
      <div class="box">
        <!-- <el-tabs v-model="activeTab" @tab-click="tabClick" v-show="this.$route.params.id == 1">
          <el-tab-pane label="课程免修申请" name="first">
            <mxsq :userInfo="userInfo1"></mxsq>
          </el-tab-pane>
          <el-tab-pane label="课程重修申请" name="second">
            <cxsq :userInfo="userInfo1"></cxsq>
          </el-tab-pane>
          <el-tab-pane label="课程缓考申请" name="third">
            <hksq :userInfo="userInfo1"></hksq>
          </el-tab-pane>
        </el-tabs>
        <mxsq-save
          v-show="$route.query.sqlx == '0'"
          :userInfo="userInfo1"
          :status="$route.query.sqzt"
        ></mxsq-save>
        <cxsq-save
          v-show="$route.query.sqlx == '1'"
          :userInfo="userInfo1"
          :status="$route.query.sqzt"
        ></cxsq-save>
        <hksq-save
          v-show="$route.query.sqlx == '2'"
          :userInfo="userInfo1"
          :status="$route.query.sqzt"
        ></hksq-save>
        <apply-record v-if="this.$route.params.id == 2" ref="childRecord"></apply-record>
        <apply-status-bottom
          v-show="this.$route.params.id == 3 || this.$route.params.id == 4"
          ref="applyStatus"
        ></apply-status-bottom> -->
        <unopen/>
      </div>
    </div>
  </div>
</template>

<script>
import mxsq from './components/mxsq'
import mxsqSave from './components/mxsqSave'
import cxsq from './components/cxsq'
import cxsqSave from './components/cxsqSave'
import hksq from './components/hksq'
import hksqSave from './components/hksqSave'
import applyRecord from './components/applyRecord'
import myBreadcrumb from '@/components/myBreadcrumb'
import applyStatusBottom from '@/components/applyStatusBottom'
import unopen from '@/components/unopen'
export default {
  name: 'exemptionRebuild',
  components: {
    mxsq,
    mxsqSave,
    cxsq,
    cxsqSave,
    hksq,
    hksqSave,
    applyRecord,
    applyStatusBottom,
    'my-breadcrumb': myBreadcrumb,
    unopen
  },
  data () {
    return {
      applyShow: true,
      activeTab: 'first',
      userInfo1: {},
      userInfo2: {},
      userInfo3: {}
    }
  },
  watch: {
    $route () {
      this.getId()
    }
  },
  created () {
    this.getId()
  },
  mounted () {
    this.getUserInfo()
  },
  methods: {
    // 查看申请记录
    seeRecord () {
      this.$router.push({
        path: '/teachTrain/exemptionRebuild/2'
      })
    },
    tabClick (t) {
      this.handleSwitch(t)
    },
    handleSwitch (t) {
      switch (t.name) {
        case 'first':
          // console.log(1);
          this.getData1()
          break
        case 'second':
          // console.log(2);
          this.getData2()
          break
        case 'third':
          // console.log(3);
          this.getData3()
          break
      }
    },
    // 获取基本信息
    getUserInfo () {
      this.$http.get('/api/cultivate/kcsq/init').then(res => {
        this.userInfo1 = res.data.data
      })
    },
    // 免修初始化数据
    getData1 () {},
    // 重修初始化数据
    getData2 () {},
    // 缓考初始化数据
    getData3 () {},
    // 新建申请(返回)
    handleBack () {
      this.applyShow = true
      this.sqlx = ''
      this.sqlx1 = ''
      this.$router.go(-1)
    },
    getId () {
      console.log('here getId')
      let id = this.$route.params.id
      // 1:申请表
      // 2:查看申请列表
      // 3:点击查看
      // 4:点击修改
      if (id == 1) {
        this.applyShow = true
      }
      if (id == 2) {
        this.applyShow = false
      }
      if (id == 3) {
        this.applyShow = false
      }
    }
  },
  computed: {
    xh () {
      return this.$store.getters.getXH
    }
  }
}
</script>

<style lang="scss" scoped>
.main {
  .el-icon-document,
  .el-icon-d-arrow-left {
    margin-right: 5px;
    color: #409eff;
  }
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    padding-top: 0;
    height: calc(100vh - 219px);
    overflow: auto;
    /deep/ .el-tabs__item {
      width: 33% !important;
      text-align: center;
    }
    /deep/ .el-tabs__nav {
      width: 100%;
      height: $student-tab-height;
      line-height: $student-tab-height;
    }
  }
}
</style>
