<template>
  <!-- 在线评教 onlineEvalution -->
  <div class="timetable">
    <!-- 在线评教 -->
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }"
            >教学培养</el-breadcrumb-item
          >
          <el-breadcrumb-item :to="{ path: '/teachTrain/onlineEvalution/1' }"
            >在线评教</el-breadcrumb-item
          >
          <el-breadcrumb-item
            :to="{ path: '/teachTrain/onlineEvalution/1' }"
            v-show="pjShow || detail"
            >评教详情</el-breadcrumb-item
          >
        </el-breadcrumb>
      </div>
      <!-- 前往评教和查看详情时的返回按钮 -->
      <div slot="right">
        <el-button
          type="primary"
          @click="handleReturn"
          v-show="pjShow || detail"
          >返回</el-button
        >
      </div>
    </my-breadcrumb>
    <div v-if="flag == true">
      <my-blank msg="还不可教学评价哦！" picUrl="blank.png"></my-blank>
    </div>
    <div class="box" v-if="flag == false">
      <div class="head">
        <div class="center">
          <span class="block"></span>
          <span class="header-title">{{xnxq.label}} 在线评教</span>
          <span class="block"></span>
        </div>
        <div
          slot="right"
          style="width:70px;height:40px;right:0;position:absolute;margin-right:120px;top: 210px;"
        >
          <el-button
            type="primary"
            @click="handleSubmit"
            :disabled="disabled"
            v-show="showList"
            >提交</el-button
          >
        </div>
      </div>
      <div v-show="showList">
        <el-table
          :data="tableData"
          border
          style="width: 100%;margin-top:16px"
          :header-cell-style="tableHeaderColor"
          :height="tableHeight"
          ref="box"
        >
          <el-table-column
            prop="gh"
            label="工号"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="xm"
            label="姓名"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="kcmc"
            label="所授课程"
            align="center"
            show-overflow-tooltip
          ></el-table-column>
          <el-table-column prop="pjdja" label="评价等级A" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.pjdja }}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="pjdjb"
            label="评价等级B"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="pjdjc"
            label="评价等级C"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="pjdjd"
            label="评价等级D"
            align="center"
          ></el-table-column>
          <el-table-column prop="pjrk" label="评教入口" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.pjrk }}</span>
              <el-button
                type="primary"
                size="small"
                @click="handleClick(scope.row, scope.$index)"
                v-if="!disabled"
                >前往评教</el-button
              >
              <el-button
                type="primary"
                size="small"
                @click="handleSee(scope.row)"
                v-else
                >前往查看</el-button
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div v-show="pjShow">
        <div class="pj-head">
          <div class="left">
            <span>教师：{{ head.js }} ({{head.gh}})</span>
            <span>所在学院：{{ head.szxy }}</span>
            <span>所授课程：{{ head.sskc }}</span>
          </div>
          <div class="right">
            <el-button type="primary" size="small" @click="handleSave"
              >保存</el-button
            >
          </div>
        </div>
        <el-table
          :data="pjData"
          border
          style="width: 100%"
          :header-cell-style="tableHeaderColor"
        >
          <el-table-column
            prop="pjxm"
            label="评价项目"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="pjnr"
            label="评价内容"
            align="center"
          ></el-table-column>
          <el-table-column prop="pjjg" label="评价结果" align="center">
            <template slot-scope="scope">
              <el-radio-group class="colorful3" v-model="scope.row.pjjg">
                <el-radio label="A">A</el-radio>
                <el-radio label="B">B</el-radio>
                <el-radio label="C">C</el-radio>
                <el-radio label="D">D</el-radio>
              </el-radio-group>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div v-show="detail">
        <div class="pj-head">
          <div class="left">
            <span>教师：{{ head.js }} ({{head.gh}})</span>
            <span>所在学院：{{ head.szxy }}</span>
            <span>所授课程：{{ head.sskc }}</span>
          </div>
        </div>
        <el-table
          :data="pjData"
          border
          style="width: 100%"
          :header-cell-style="tableHeaderColor"
        >
          <el-table-column
            prop="pjxm"
            label="评价项目"
            align="center"
          ></el-table-column>
          <el-table-column
            prop="pjnr"
            label="评价内容"
            align="center"
          ></el-table-column>
          <el-table-column prop="pjjg" label="评价结果" align="center">
            <template slot-scope="scope">
              <el-radio-group
                class="colorful3"
                v-model="scope.row.type"
                fill="#409EFF"
                :disabled="disabled"
              >
                <el-radio label="A">A</el-radio>
                <el-radio label="B">B</el-radio>
                <el-radio label="C">C</el-radio>
                <el-radio label="D">D</el-radio>
              </el-radio-group>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <!-- 分页 -->
    <div v-if="flag == false">
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="msgCount"
        v-show="showList"
      ></my-pagination>
    </div>
  </div>
</template>

<script>
import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
import blank from "@/components/blank";
export default {
  name: "onlineEvalution",
  data() {
    return {
      tableData: [],
      currentIndex: -1, //默认评教的记录从0开始
      pjData: [],
      disabled: false,
      detail: false,
      saveData: [],
      showList: true,
      pjShow: false,
      row: "",
      // 列表分页传参
      limitQuery: {
        pageNum: 1, // 当前页
        pageSize: 10 // 分页中每页显示条数
      },
      msgCount: 0,
      head: {
        js: "",
        szxy: "",
        sskc: "",
        gh:''
      },
      pingjiao: [], //声明一个新的数组，并将已选的数据放到这个数组中
      flag: true
    };
  },
  components: {
    "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb,
    "my-blank": blank
  },
  mounted() {
    this.kqgb();
    this.$store.commit('uplodexnxq')
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 90;
    },
    xnxq() {
      return this.$store.state.userxnxq;
    }
  },
  methods: {
    kqgb() {
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=jypjsj")
        .then(res => {
          if (res.data.data.isOpen == 1) {
            this.flag = false;
            this.getInit();
          } else {
            this.flag = true;
          }
        });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page;
      // 保存到pageList中
      this.limitQuery.pageNum = pageNum;
      this.limitQuery.pageSize = pageSize;
      this.msgCount = msgCount;
      // 重新请求列表数据
      this.getList();
    },
    // 初始化判断是否已经评教 若状态值为1则表示已评教学生可直接点击进入详情页面  为0则进入评教页
    getInit() {
      this.$http.get("/api/cultivate/pjwj/check").then(res => {
        // console.log(res.data);
        this.zt = res.data.data.zt; //获取评教的状态值
        // console.log(this.zt,'评教状态')
        if (res.data.data.count == 0) {
          this.disabled = false;
          this.getList();
        } else {
          this.disabled = true;
          this.getList();
        }
      });
    },
    // 加载需要评教的教师列表
    getList() {
      // 如果已评教请求已评教的教师列表
      if (this.disabled) {
        this.$http
          .get("/api/cultivate/pjwj/afterStuList", {
            params: this.limitQuery
          })
          .then(res => {
            // 取出结果中的教师列表
            let data = res.data.data.list;
            // 修改分页参数
            this.msgCount = res.data.data.total;
            data.forEach(item => {
              [
                item.pjdja,
                item.pjdjb,
                item.pjdjc,
                item.pjdjd
              ] = item.pjsl.split(",");
              item.pingjiao = [];
            });
            this.tableData = data;
          });
      } else {
        // 未评教请求未评教的教师列表
        this.$http
          .get("/api/cultivate/pjwj/stuList", { params: this.limitQuery })
          .then(res => {
            // 取出结果中的教师列表
            let data = res.data.data.list;
            // 修改分页参数
            this.msgCount = res.data.data.total;
            data.forEach(item => {
              [item.pjdja, item.pjdjb, item.pjdjc, item.pjdjd] = [0, 0, 0, 0];
              item.pingjiao = [];
            });

            this.tableData = data;
          });
      }
    },
    // 前往评教
    //在选中某一条评教内容时 因为每条数据选项中的id相同，因此要声明一个index来做历史记录，避免所选的内容发生重复   让id默认从0开始
    handleClick(row, index) {
      //若评教状态为0则证明试卷还未发布，若状态为1则可以进行评教
      if (this.zt == 1) {
        this.getPjnr();
        this.currentIndex = index;
        this.head.js = row.xm;
        this.head.gh = row.gh;
        this.head.szxy = row.dwmc;
        this.head.sskc = row.kcmc;
        this.showList = false;
        this.pjShow = true;
        row.pjdj = "";
        this.row = row;
      } else {
        this.$message.error("评教内容还未发布，暂不可评教");
        this.showList = true;
        this.pjShow = false;
      }
    },
    // 前往查看
    handleSee(row) {
      this.getPjnr(row.id);
      this.head.js = row.xm;
      this.head.gh = row.gh;
      this.head.szxy = row.dwmc;
      this.head.sskc = row.kcmc;
      this.detail = true;
      this.showList = false;
      this.pjShow = false;
    },
    handleReturn() {
      this.showList = true;
      this.pjShow = false;
      this.detail = false;
    },
    getPjnr(id) {
      // 如果未评教
      if (!this.disabled) {
        this.$http
          .get("/api/cultivate/pjwj/selectByWjid")
          .then(res => {
            this.pjData = res.data.data.nrList;
            //勾选保存后的评教项
            this.pjData.forEach(item => {
              let pjid = item.id;
              var pjobj = this.tableData[this.currentIndex].pingjiao.find(
                el => {
                  return el.id === pjid;
                }
              );
              if (pjobj === undefined) {
                this.$set(item, "pjjg", "");
                return;
              }
              this.$set(item, "pjjg", pjobj.type);
            });
            console.log(this.pjData);
          });
      } else {
        // 已评教
        this.$http("/api/cultivate/pjwj/afterInfo", {
          params: {
            id
          }
        }).then(res => {
          let data = res.data.data;
          this.pjData = data;
        });
      }
    },
    // 保存
    handleSave() {
      this.saveData = [];
      this.pjData.forEach(item => {
        let obj = {
          id: item.id,
          type: item.pjjg
        };
        this.saveData.push(obj);
        this.tableData[this.currentIndex].pingjiao.push(obj);
      });
      let aaa = [];
      let bbb = [];
      let ccc = [];
      let ddd = [];
      this.saveData.map(item => {
        if (item.type == "A") {
          aaa.push(item.type);
        }
        if (item.type == "B") {
          bbb.push(item.type);
        }
        if (item.type == "C") {
          ccc.push(item.type);
        }
        if (item.type == "D") {
          ddd.push(item.type);
        }
      });
      this.tableData.forEach(item => {
        if (item.gh == this.row.gh) {
          item.pjdja = aaa.length;
          item.pjdjb = bbb.length;
          item.pjdjc = ccc.length;
          item.pjdjd = ddd.length;
          item.pjdj = this.saveData; //将评教的选项赋值给 saveData
        }
      });
      this.showList = true;
      this.pjShow = false;
      this.detail = false;
    },
    // 提交
    handleSubmit() {
      console.log(123);
      let submitData = { list: [] };
      this.tableData.forEach(item => {
        let { gh, pjdj, pjdja, pjdjb, pjdjc, pjdjd, kch } = item;
        let obj = {
          gh: gh,
          pjsl: `${pjdja},${pjdjb},${pjdjc},${pjdjd}`,
          list: pjdj,
          kch: kch
        };
        submitData.list.push(obj);
      });
      if (
        !submitData.list.every(el => el.list && el.list.every(el => el.type))
      ) {
        this.$message.warning("请完成所有评教");
        return false;
      }
      this.$http.post("/api/cultivate/pjwj/save", submitData).then(res => {
        if (res.data.code === 200) {
          this.$message.success("提交成功");
          //评教完成后点击保存时设置3秒之后显示在线评教的页面
          this.showList = true;
          this.getInit();
          //提交后评教内容不显示出来
        } else {
          this.$message.error("提交失败");
        }
      });
    },
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.timetable {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
  }
}
.el-icon-document,
.el-icon-d-arrow-left {
  margin-right: 5px;
  color: #409eff;
}
.head {
  // display: flex;
  height: 50px;
  line-height: 50px;
  .center {
    text-align: center;
    // line-height: 63px;
    .header-title {
      font-size: 20px;
      font-weight: 500;
      color: $blue;
      margin-left: 5px;
      margin-right: 5px;
    }
    .block {
      font-size: 16px;
      width: 10px;
      height: 10px;
      background-color: $blue;
      display: inline-block;
    }
  }
}
.box {
  .table-search {
    display: flex;
    padding: 5px;
    background: #f2f2f2;
    border: 1px solid rgba(228, 228, 228, 1);

    .left {
      flex: 1;
    }
    .right {
      flex: 1;
      text-align: right;
      line-height: 36px;
    }
  }
}
.pj-head {
  font-size: 14px;
  display: flex;
  color: #606266;
  line-height: 44px;
  .left {
    flex: 5;
    span {
      margin-right: 30px;
    }
  }
  .right {
    flex: 1;
    text-align: right;
    .el-button {
      width: 70px;
      height: 40px;
      margin-right: 5px;
      margin-bottom: 10px;
    }
  }
}
.pages {
  margin: 0 auto;
  padding: 20px 0;
  text-align: center;
}
/deep/ .el-radio__input.is-disabled.is-checked .el-radio__inner {
  background-color: #409eff !important;
  border-color: #409eff !important;
  &::after {
    background-color: #fff !important;
  }
}
</style>
