<template>
  <!-- 个人成绩单 personalTranscript-->
  <div class="score-list">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalPlan/1' }"
            >教学培养</el-breadcrumb-item
          >
          <el-breadcrumb-item :to="{ path: '/teachTrain/personalTranscript/1' }"
            >个人成绩单</el-breadcrumb-item
          >
        </el-breadcrumb>
      </div>
      <div slot="right"><el-button @click="clickOutput">导出</el-button></div>
    </my-breadcrumb>
    <div v-loading="loading" element-loading-text="加载中">
      <div class="tip" v-if="showTip">
        <div style="margin-bottom:10px">完成评教后，可查看成绩单！</div>
        <div>
          请前往
          <el-link type="primary" @click="handleClick">在线评教>></el-link>
        </div>
      </div>
      <div v-if="!showTip" class="box">
        <div class="theTitle">
          <div class="titleLeft"></div>
          <div class="titleCenter">
            <span class="block"></span>
            <span class="header-title">个人成绩单</span>
            <span class="block"></span>
          </div>
          <div class="titleRight">
            <span>取得总学分:{{ totalCredit }} </span>
            <span style="margin-left:14px">
              学位课总学分:{{ degreeCredit }}</span
            >
          </div>
        </div>
        <table>
          <tr>
            <td>课程类别</td>
            <!-- <td>课程号</td> -->
            <td>课程名称</td>
            <td>学分</td>
            <td>学时</td>
            <td>开课学期</td>
            <td>授课教师/负责人</td>
            <td>考试形式</td>
            <td>成绩</td>
          </tr>
          <tr v-for="(item, index) in xwk" :key="index.total">
            <td :rowspan="xwk.length" v-if="index == 0">学位课</td>
            <!-- <td>{{ item.kch }}</td> -->
            <td>{{ item.kcmc }}</td>
            <td>{{ item.xf }}</td>
            <td>{{ item.zxs }}</td>
            <td>{{ item.kkxq }}</td>
            <td>{{ item.skjs }}</td>
            <td>{{ item.ksxsmc }}</td>
            <td>
              <span
                :class="item.sfjg == 0 ? 'badScore' : 'goodScore'"
                v-if="item.ksxs == '1'"
                >{{ Math.round(item.zzcj) }}</span
              >
              <span
                :class="item.zzcj == '0' ? 'badScore' : 'goodScore'"
                v-if="item.ksxs == '2'"
                ><span v-if="item.zzcj == '1'">通过</span
                ><span v-if="item.zzcj == '0'">不通过</span></span
              >
            </td>
          </tr>
          <tr v-for="(item, index) in xxk" :key="index.total">
            <td :rowspan="xxk.length" v-if="index == 0">选修课</td>
            <!-- <td>{{ item.kch }}</td> -->
            <td>{{ item.kcmc }}</td>
            <td>{{ item.xf }}</td>
            <td>{{ item.zxs }}</td>
            <td>{{ item.kkxq }}</td>
            <td>{{ item.skjs }}</td>
            <td>{{ item.ksxsmc }}</td>
            <td>
              <span
                :class="item.sfjg == 0 ? 'badScore' : 'goodScore'"
                v-if="item.ksxs == '1'"
                >{{ Math.round(item.zzcj) }}</span
              >
              <span
                :class="item.zzcj == '0' ? 'badScore' : 'goodScore'"
                v-if="item.ksxs == '2'"
                ><span v-if="item.zzcj == '1'">通过</span
                ><span v-if="item.zzcj == '0'">不通过</span></span
              >
            </td>
          </tr>
          <tr v-for="(item, index) in bxhj" :key="index.total">
            <td :rowspan="bxhj.length" v-if="index == 0">必修环节</td>
            <!-- <td>{{ item.kch }}</td> -->
            <td>{{ item.kcmc }}</td>
            <td>{{ item.xf }}</td>
            <td>{{ item.zxs }}</td>
            <td>{{ item.kkxq }}</td>
            <td>{{ item.skjs }}</td>
            <td>{{ item.ksxsmc }}</td>
            <td>
              <span
                :class="item.sfjg == 0 ? 'badScore' : 'goodScore'"
                v-if="item.ksxs == '1'"
                >{{ Math.round(item.zzcj) }}</span
              >
              <span
                :class="item.zzcj == '0' ? 'badScore' : 'goodScore'"
                v-if="item.ksxs == '2'"
                ><span v-if="item.zzcj == '1'">通过</span
                ><span v-if="item.zzcj == '0'">不通过</span></span
              >
            </td>
          </tr>
        </table>

        <!-- <el-table
          :data="tableData"
          border
          style="width: 100%;margin-top:16px;"
          :header-cell-style="tableHeaderColor"
          :height="tableHeight"
          ref="box"
        > -->
        <!-- <el-table-column prop="kch" label="课程类别" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.kch }}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="kch"
            label="课程号"
            align="center"
          ></el-table-column>
          <el-table-column label="开课学期" align="center"
            ><span>{{ this.xnxq.label }}</span></el-table-column
          >
        <!-- <el-table-column prop="zzcj" label="成绩" align="center">
            <template slot-scope="scope">
              <span
                :class="scope.row.sfjg == 0 ? 'badScore' : 'goodScore'"
                v-if="scope.row.ksxs == '1'"
                >{{ scope.row.zzcj }}</span
              >
              <span
                :class="scope.row.zzcj == '0' ? 'badScore' : 'goodScore'"
                v-if="scope.row.ksxs == '2'"
                ><span v-if="scope.row.zzcj == '1'">通过</span
                ><span v-if="scope.row.zzcj == '0'">不通过</span></span
              >
            </template>
          </el-table-column> -->
        <!-- </el-table> -->
        <!-- 分页 -->
        <!-- <my-pagination
          @paginate="handlePaginate"
          :pageSize="limitQuery.pageSize"
          :pageNum="limitQuery.pageNum"
          :msgCount="msgCount"
        ></my-pagination> -->
      </div>
    </div>
  </div>
</template>

<script>
// import myPagination from "@/components/myPagination";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "personalTranscript",
  data() {
    return {
      showTip: null,
      loading: false,
      // 列表分页传参
      // limitQuery: {
      //   pageNum: 1, // 当前页
      //   pageSize: 10, // 分页中每页显示条数
      //   search: "",
      //   kcmc: ""
      // },
      // msgCount: 0,
      totalCredit: null, //总学分
      degreeCredit: null, //学位课总学分
      xwk: [], //学位课
      xxk: [], //选修课
      bxhj: [] //必修环节
      // tableData: []
    };
  },
  components: {
    // "my-pagination": myPagination,
    "my-breadcrumb": myBreadcrumb
  },
  mounted() {
    this.kqgb();
    this.$store.commit("uplodexnxq");
    // console.log(this.$store.state.userxnxq)
  },
  methods: {
    // 点击导出
    clickOutput() {
      console.log("点击导出");
      window.location.href =
        "/api/cultivate/sac/export/" + this.$store.getters.getXH;
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    // handlePaginate(page) {
    //   // 解构出分页数据
    //   let { pageSize, pageNum, msgCount } = page;
    //   // 保存到pageList中
    //   this.limitQuery.pageNum = pageNum;
    //   this.limitQuery.pageSize = pageSize;
    //   this.msgCount = msgCount;
    //   // 重新请求列表数据
    //   this.getScoreList();
    // },
    kqgb() {
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain?key=jypjsj")
        .then(res => {
          if (res.data.data.isOpen == 1) {
            //若评教时间开启
            this.getInit();
          } else {
            // 若培养计划时间关闭给flag赋值
            this.showTip = false;
            this.getScoreList();
          }
        });
    },
    // 初始化判断是否已经评教
    getInit() {
      this.loading = true;
      this.$http
        .get("/api/cultivate/pycssz/checkOpenMain", {
          params: { key: "jypjsj" }
        })
        .then(res => {
          let data = res.data.data;
          if (
            data.isOpen === 0 ||
            new Date() < new Date(data.startTime) ||
            new Date() > new Date(data.endTime)
          ) {
            this.loading = false;
            this.showTip = false;
            this.getScoreList();
          } else {
            this.$http.get("/api/cultivate/pjwj/check").then(res => {
              this.loading = false;
              // 判断学生是否已经进行评教   若count大于0代表已评教  其它则是未评教
              if (res.data.data.count > 0) {
                this.showTip = false;
                this.getScoreList();
              } else {
                this.showTip = true;
              }
            });
          }
        });
    },
    // 点击在线评教
    handleClick() {
      this.$router.push({
        path: "/teachTrain/onlineEvalution/1"
      });
    },
    // 个人成绩单中的数据
    getScoreList() {
      this.$http.get("/api/cultivate/sac/personal").then(res => {
        console.log(res.data.data);
        this.loading = false;
        let data = res.data.data;
        // this.msgCount = data.total;
        // this.tableData = data;
        this.totalCredit = data.total;
        this.degreeCredit = data.degreeCoursesTotal;
        this.xwk = data.degreeCoursesList;
        this.xxk = data.electiveCoursesList;
        this.bxhj = data.unplannedCourseList;
      });
    },
    // 替换table中thead的颜色
    tableHeaderColor({ rowIndex }) {
      if (rowIndex === 0) {
        return "background-color: #F5F5F5;font-weight: 500;height:50px";
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters.getTableHeight - 88;
    },
    xnxq() {
      console.log(this.$store.state.userxnxq);
      return this.$store.state.userxnxq;
    }
  }
};
</script>

<style lang="scss" scoped>
.score-list {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
  }
  .tip {
    margin-top: 25%;
    margin-bottom: 25%;
    text-align: center;
    font-size: 16px;
  }
}
.theTitle {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  div {
    width: 20%;
  }
  .titleCenter {
    font-size: 20px;
    font-weight: 500;
    color: $blue;
    text-align: center;
    .block {
      font-size: 16px;
      width: 10px;
      height: 10px;
      background-color: $blue;
      display: inline-block;
      margin-left: 5px;
      margin-right: 5px;
    }
  }
  .titleRight {
    font-size: 14px;
    margin-top: 3px;
    min-width: 300px;
    text-align: right;
  }
}
tr:first-child {
  background: #f5f5f5;
}
td {
  border: 1px solid #ccc;
  text-align: center;
  padding: 10px 5px;
  box-sizing: border-box;
}
.badScore {
  color: #f00;
}
.goodScore {
  color: #333;
}
.el-button {
  background-color: #409eff;
  color: #fff;
  height: 34px;
  line-height: 10px;
}
</style>
