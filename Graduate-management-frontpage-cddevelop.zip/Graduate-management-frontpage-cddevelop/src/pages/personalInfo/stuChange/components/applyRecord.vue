<template>
  <!-- <div> -->
  <!-- 申请记录 applyRecord -->
  <div>
    <el-table
      :data="tableData"
      border
      :height="tableHeight"
      style="width: 100%;margin-top:16px;"
      :header-cell-style="tableHeaderColor"
      ref="box"
      v-loading="loading"
    >
      <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
      <el-table-column prop="ydlbmc" label="申请类型" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.ydlbmc }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="cjsj" label="申请时间" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.cjsj }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="zt" label="申请状态" align="center">
        <template slot-scope="scope">
          <el-tag :type="scope.row.zt | listStatusFilter">{{ scope.row.zt | ztFilter }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="cz" label="操作" width="120" align="center">
        <template slot-scope="scope">
          <el-button type="text" v-if="scope.row.zt == '4'" @click="changeClick(scope.row)">修改</el-button>
          <el-button type="text" v-else @click="seeClick(scope.row)">查看</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import myPagination from '@/components/myPagination'
export default {
  name: 'applyRecord',
  data () {
    return {
      pyXjydb: {},
      tableData: [],
      // 分页
      limitQuery: {
        pageNum: 1,
        pageSize: 10
      },
      msgCount: 0,
      loading:true
    }
  },
  created () {
    let val = sessionStorage.getItem("pageNum1")
    let from = sessionStorage.getItem("sqjl1")
    if(from){
      this.limitQuery.pageNum = Number(val)
    }
    this.loadTable()
  },
  components: {
    'my-pagination': myPagination
  },
  computed: {
    tableHeight () {
      return this.$store.getters.getTableHeight - 24
    }
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate (page) {
      // 解构出分页数据
      let { pageSize, pageNum, msgCount } = page
      // 保存到limitQuery中
      this.limitQuery.pageNum = pageNum
      this.limitQuery.pageSize = pageSize
      this.msgCount = msgCount
      // 重新请求列表数据
      this.loadTable()
    },

    loadTable () {
      this.$http
        .get('/api/frontpage/xjydsq/selectList', {
          params: this.limitQuery
        })
        .then(res => {
          this.loading = false
          // console.log(res.data.data)
          let data = res.data.data
          this.tableData = data.list
          this.msgCount = data.total
        })
    },
    // 替换table中thead的颜色
    tableHeaderColor ({ rowIndex }) {
      if (rowIndex === 0) {
        return 'background-color: #F5F5F5;font-weight: 500;height:50px'
      }
    },
    // 查看
    seeClick (row) {
      // console.log(row)
      // 子组件向父组件传值，子组件点击查看时将shzt传给父组件
      // 查询条件写在query中
      sessionStorage.setItem('pageNum1',this.limitQuery.pageNum)
      this.$router.push({
        path: '/personalInfo/stuChange/3',
        query: {
          sqlx: row.ydlbm,
          id: row.lcid
        }
      })
    },
    // 修改
    changeClick (row) {
      // console.log(row)
      // this.$emit('listen1',row)
      sessionStorage.setItem('pageNum1',this.limitQuery.pageNum)
      this.$router.push({
        path: '/personalInfo/stuChange/4',
        query: {
          sqlx: row.ydlbm,
          id: row.lcid
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
