<template>
  <div v-loading="loading"
      element-loading-text="拼命加载中"
      class="table-box-container">
    <!-- 延迟毕业申请 ycbysq -->
    <div
      class="table-box"
      v-if="!loading"
    >
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">
            <table-flag
              v-if="$route.params.id == 3 || $route.params.id == 4"
              :status="status1"
              :time="time"
              :table-title="tableTitle"
            ></table-flag>
            <table-flag
              v-if="$route.matched[1].path == '/stuInfoAudit/:id?'"
              :table-title="tableTitle"
            ></table-flag>
          </th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xh }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>培养层次</td>
            <td>{{ userInfo.pyccm }}</td>
          </tr>
          <tr>
            <td>学制</td>
            <td>{{ userInfo.xz }}</td>
            <td>入学年月</td>
            <td>{{ userInfo.rxny }}</td>
            <td>原定毕业时间</td>
            <td>{{ userInfo.ydbysj }}</td>
          </tr>
          <tr>
            <td>申请延长时间</td>
            <!-- <td colspan="5">{{ userInfo.sqycsj }}</td> -->
            <td colspan="5">
              <el-radio-group
                v-model="writeInfo.sqycsj"
                v-if="
                  $route.matched[1].path !== '/stuInfoAudit/:id?' &&
                    status1 == 4
                "
              >
                <el-radio :label="1">半年</el-radio>
                <el-radio :label="2">一年</el-radio>
                <el-radio :label="3">一年半</el-radio>
                <el-radio :label="4">两年</el-radio>
              </el-radio-group>
              <span v-else>{{ writeInfo.sqycsj | yearFilter }}</span>
            </td>
          </tr>
          <tr v-if="$route.params.id == 4">
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8 }"
                    placeholder="请输入内容"
                    v-model="writeInfo.ydsm"
                    v-if="
                      $route.matched[1].path !== '/stuInfoAudit/:id?' &&
                        status1 == 4
                    "
                  ></el-input>
                  <span v-else>{{ writeInfo.ydsm }}</span>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr v-if="$route.params.id != 4">
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8 }"
                    placeholder="请输入内容"
                    v-model="writeInfo.ydsm"
                    v-if="
                      $route.matched[1].path !== '/stuInfoAudit/:id?' &&
                        status1 == 4
                    "
                  ></el-input>
                  <span v-else>{{ writeInfo.ydsm }}</span>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr
            v-if="
              $route.matched[1].path == '/stuInfoAudit/:id?' || status1 != 4
            "
          >
            <td>证明材料：</td>
            <td colspan="5">
              <div v-if="!fj.includes(null)">
                <ul class="fj">
                  <li v-for="(item, index) of fj" :key="index">
                    <a
                      :href="item.url"
                      target="_blank"
                      class="primary"
                      :download="item.fileName"
                      >{{ item.fileName }}</a
                    >
                  </li>
                </ul>
              </div>
            </td>
          </tr>
          <tr v-else>
            <td style="background:none">证明材料：</td>
            <td colspan="5">
              <el-upload
                :beforeUpload="beforeAvatarUpload"
                ref="upload"
                class="upload-demo"
                :headers="headers"
                action="/api/system/upload"
                :on-success="handleSuccess"
                :on-remove="handleRemove"
                multiple
                :limit="5"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
              </el-upload>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="bottom" v-show="$route.params.id == 4 && status1 == 4">
        <el-button @click="handleReset">重置</el-button>
        <el-button type="primary" @click="handleUpdate">重新提交</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import tableFlag from "@/components/tableFlag";
export default {
  name: "ycbysqSave",
  props: [
    // 'userInfo',
    "status"
    // 'status1',
  ],
  components: {
    tableFlag
  },
  data() {
    return {
      tableTitle: "浙江财经大学研究生延迟毕业申请表",
      time: "2019/05/18",
      status1: "",
      input: "",
      fileList: [],
      userInfo: {}, // 初始化数据
      writeInfo: {}, // 申请写入的数据,
      updateInfo: {}, // 修改提交的数据
      auditList: {}, // 审核流程图
      fj: [],
      loading: true,
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      }
    };
  },
  watch: {
    $route(to) {
      // console.log("路由变化");
      // console.log(to.path);

      if (
        (to.path === "/personalInfo/stuChange/3" ||
          to.path === "/personalInfo/stuChange/4") &&
        to.query.sqlx === "06"
      ) {
        // //console.log(666)
        this.getData();
      }
      if ((to.query.check == 0 || to.query.check == 1) && to.query.mark == 3) {
        this.getData();
      }
    }
  },
  created() {
    this.status1 = this.status;
    if (
      (this.$route.path === "/personalInfo/stuChange/3" ||
        this.$route.path === "/personalInfo/stuChange/4") &&
      this.$route.query.sqlx === "06"
    ) {
      // //console.log('create-666')
      this.getData();
    }
    if (
      (this.$route.query.check == 0 || this.$route.query.check == 1) &&
      this.$route.query.mark == 3
    ) {
      this.getData();
    }
  },
  mounted() {
    // this.userInfo = {}
  },
  methods: {
    // 查看详情
    getData() {
      this.$http
        .get("/api/frontpage/xjydsq/ycbyInfoByLcid", {
          params: {
            lcid: this.$route.query.id
          }
        })
        .then(res => {
          console.log(res.data.data);
          // //console.log(res.data.data.pyXjydb.sqycsj)
          this.loading = false;
          let data = res.data.data;
          this.userInfo = data.xsXjydsqYcbyVo;
          this.writeInfo = data.pyXjydb;
          this.writeInfo.sqycsj = parseInt(data.pyXjydb.sqycsj); // 字符串转数字
          this.time = data.pyXjydb.cjsj;
          this.status1 = data.pyXjydb.zt;
          this.auditList = data.list;
          console.log(this.auditList);
          this.fj = data.pyXjydb.firstfj;
          this.$store.state.auditList = this.auditList;
          this.$bus.$emit("stepList", this.auditList);
        });
    },
    // 修改提交
    handleUpdate() {
      if (this.writeInfo.ydsm == " " || this.writeInfo.ydsm == null) {
        this.$message.warning("请填写申请理由");
        return false;
      }
      this.writeInfo.firstfj = this.fj;
      const subLoading = this.$loading({target:document.querySelector('.table-box')})
      this.$http
        .post("/api/frontpage/xjydsq/update", this.writeInfo)
        .then(res => {
          subLoading.close()
          // console.log(res.data);
          if (res.data.code === 200) {
            this.$message.success("修改成功");
            // 清空附件
            this.$refs.upload.clearFiles();
            this.getData();
            // 修改成功后后退
            this.$router.go(-1);
          }
        });
    },
    handleSuccess(res) {
      // console.log(res.data);
      if (res.data !== null) {
        this.fj.push(res.data);
      }
    },
    // 重置参数
    handleReset() {
      this.writeInfo.sqycsj = "";
      this.writeInfo.ydsm = "";
      this.fj = [];
    },
    //对上传文件的大小做出限制
    beforeAvatarUpload(file) {
      var testmsg = file.name.substring(file.name.lastIndexOf(".") + 1);
      const isLt2M = file.size / 1024 / 1024 < 5;
      if (!isLt2M) {
        this.$message.warning({
          message: "上传文件大小不能超过 5MB!"
        });
      }
      return isLt2M;
    },
    // 删除文件的回调
    handleRemove() {
      // console.log("移除文件");
      this.pyXjydb.firstfj.pop();
    }
  },
  filters: {
    yearFilter(val) {
      val = parseInt(val);
      if (!val) {
        return;
      }
      switch (val) {
        case 1:
          return "半年";
        case 2:
          return "一年";
        case 3:
          return "一年半";
        case 4:
          return "两年";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/styles/table.scss";
.table-box-container{
  width:100%;
  height:calc(100vh - 250px);
}
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;

      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.fj {
  display: flex;
  li:not(:first-child) {
    a:before {
      content: "、";
    }
  }
  a {
    color: #1890ff;
  }
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
