<template>
  <div>
    <!-- 肄业申请 yysq -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">浙江财经大学研究生肆业申请表</th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>年级</td>
            <td>{{ userInfo.sznj }}</td>
          </tr>
          <tr>
            <td>班级</td>
            <td>{{ userInfo.szbh }}</td>
            <td>出生日期</td>
            <td>{{ userInfo.csrq }}</td>
            <td>籍贯</td>
            <td>{{ userInfo.jgmc }}</td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="pyXjydb.ydsm"
                  ></el-input>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr>
            <td class="star">家长意见：</td>
            <td colspan="5">
              <el-upload
                ref="upload"
                class="upload-demo"
                action="/api/system/upload"
                :beforeUpload="beforeAvatarUpload"
                :on-success="handleSuccess"
                :on-remove="handleRemove"
                multiple
                :limit="5"
                :headers="headtoken"
                v-loading="uploadLoading"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
              </el-upload>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="bottom">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'yysq',
  props: ['userInfo'],
  data () {
    return {
      input: '',
      fileList: [],
      pyXjydb: {
        firstfj: [],
        ydlbm: '63' // 肄业
      },
      dialogVisible: false,
      headtoken:{userToken:this.$store.state.userLoginMsg.userToken},
      uploadLoading:false
    }
  },
  mounted () {
    // this.userInfo = {}
  },
  methods: {
    handleSubmit () {
      this.dialogVisible = false
      //申请理由的必填验证
      if (this.pyXjydb.ydsm == ' ' || this.pyXjydb.ydsm == null) {
        this.$message.warning('请填写申请理由')
        return false
      }
      //家长意见的必填验证
      if (this.pyXjydb.firstfj.length === 0) {
        this.$message.warning('请上传附件')
        return false
      }
      const subLoading = this.$loading({target:document.querySelector('.table-box')})
      this.$http.post('/api/frontpage/xjydsq/start', this.pyXjydb).then(res => {
        subLoading.close()
        if (res.data.code === 200) {
          this.$message.success('申请成功')
          // 清空附件
          this.$refs.upload.clearFiles()
          this.pyXjydb = {}
        }
      })
    },
    // 删除文件的回调
    handleRemove () {
      // console.log("移除文件");
      this.pyXjydb.firstfj.pop()
    },
    // 上传成功的回调
    handleSuccess(res,file,fileList) {
      this.uploadLoading = false
      if(res.code == 200){
        this.pyXjydb.firstfj.push(res.data);
      }else{
        fileList.pop()
        this.$message.error(res.message)
      }
    },
    beforeAvatarUpload(file) { 
        this.uploadLoading = true
			}
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;

      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
