<template>
  <div>
    <!-- 休学申请 xxsq -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">浙江财经大学研究生休（停）学申请表</th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>年级</td>
            <td>{{ userInfo.sznj }}</td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="pyXjydb.ydsm"
                  ></el-input>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr>
            <td class="required">家长意见：</td>
            <td colspan="5">
              <el-upload
                :beforeUpload="beforeAvatarUpload"
                ref="upload"
                class="upload-demo"
                action="/api/system/upload"
                :on-success="handleSuccessJZ"
                :on-remove="handleRemoveJZ"
                multiple
                :limit="5"
                :headers="headtoken"
                v-loading="uploadLoading"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
                <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
              </el-upload>
            </td>
          </tr>
          <tr>
            <td>医院证明：</td>
            <td colspan="5">
              <el-upload
                :beforeUpload="beforeAvatarUpload1"
                ref="uploadZM"
                class="upload-demo"
                action="/api/system/upload"
                :on-success="handleSuccessYY"
                :on-remove="handleRemoveYY"
                multiple
                :limit="5"
                :headers="headtoken"
                v-loading="uploadLoading1"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
                <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
              </el-upload>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="tip">
        <p>注：因病休学者必须上传医院证明，其他原因休学者无需上传医院证明。</p>
      </div>
      <div class="bottom">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'xxsq',
  props: ['userInfo'],
  data () {
    return {
      input: '',
      fileList: [],
      pyXjydb: {
        firstfj: [],
        secondfj: [],
        ydlbm: '11' // 休学(两个附件)
      },
      dialogVisible: false,
      headtoken:{userToken:this.$store.state.userLoginMsg.userToken},
      uploadLoading:false,
      uploadLoading1:false,
    }
  },
  mounted () {
    // this.userInfo = {}
  },
  methods: {
    //点击确定提交申请
    handleSubmit () {
      this.dialogVisible = false
      if (this.pyXjydb.ydsm == '' || this.pyXjydb.ydsm == null) {
        this.$message.warning('请输入申请理由')
        return false
      }
      if (this.pyXjydb.firstfj.length === 0) {
        this.$message.warning('请上传附件')
        return false
      }
      const subLoading = this.$loading({target:document.querySelector('.table-box')})
      this.$http.post('/api/frontpage/xjydsq/start', this.pyXjydb).then(res => {
        subLoading.close()
        // console.log(res.data);
        if (res.data.code === 200) {
          this.$message.success('申请成功')
          // 清空附件
          this.$refs.upload.clearFiles()
          // 清空附件
          this.$refs.uploadZM.clearFiles()
          this.pyXjydb = {}
        }
      })
    },
    // 删除文件的回调
    handleRemoveJZ () {
      // console.log("移除文件");
      this.pyXjydb.firstfj.pop()
    },
    // 上传成功的回调
    handleSuccessJZ (res,file,fileList) {
      this.uploadLoading = false 
      if(res.code == 200){
        this.pyXjydb.firstfj.push(res.data)
      }else{
        fileList.pop()
        this.$message.error(res.message)
      }
      // console.log(res);
    }, 
    // 删除文件的回调
    handleRemoveYY () {
      // console.log("移除文件");
      this.pyXjydb.secondfj.pop()
    },
    // 上传成功的回调
    handleSuccessYY(res,file,fileList) {
      this.uploadLoading1 = false 
      if(res.code == 200){
        this.pyXjydb.secondfj.push(res.data);
      }else{
        fileList.pop()
        this.$message.error(res.message)
      }
    },
    //对家长意见的上传文件的大小做出限制
    beforeAvatarUpload(file) { 
        this.uploadLoading = true 				
				var testmsg=file.name.substring(file.name.lastIndexOf('.')+1)	
				const isLt2M = file.size / 1024 / 1024 < 5
				if(!isLt2M) {
          this.uploadLoading = false 
					this.$message.warning({
						message: '上传文件大小不能超过 5MB!'
					});
				}
				return isLt2M
		},
    //对医院证明上传文件的大小做出限制
    beforeAvatarUpload1(file) {
        this.uploadLoading1 = true  				
				var testmsg=file.name.substring(file.name.lastIndexOf('.')+1)	
				const isLt2M = file.size / 1024 / 1024 < 5
				if(!isLt2M) {
          this.uploadLoading1 = false 
					this.$message.warning({
						message: '上传文件大小不能超过 5MB!'
					});
				}
				return isLt2M
		}
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;

      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.tip {
  p {
    color: #f56c6c;
    font-size: 13px;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
