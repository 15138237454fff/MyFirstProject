<template>
  <div>
    <!-- 转专业申请 zzysq -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">浙江财经大学研究生转专业申请表</th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>入学年月</td>
            <td>{{ userInfo.rxny }}</td>
            <td>学生类别</td>
            <td>{{ userInfo.xslbmc }}</td>
            <td>培养方式</td>
            <td>{{ userInfo.pyfsm }}</td>
          </tr>
          <tr>
            <td rowspan="2">现所学专业情况</td>
            <td style="background:#f2f2f2">原学院</td>
            <td style="background:none">{{ userInfo.yxsh }}</td>
            <td style="background:#f2f2f2">原专业</td>
            <td colspan="2" style="background:none">{{ userInfo.zy }}</td>
          </tr>
          <tr>
            <td>原导师</td>
            <td>{{ userInfo.dsxm }}</td>
            <td></td>
            <td colspan="2"></td>
          </tr>
          <tr>
            <td rowspan="2" style="line-height:80px;height:80px;padding:0 !important;"><span style="color:red;margin-left:8px;">*</span>&nbsp;拟转入专业情况</td>
            <td style="background:#f2f2f2;line-height:40px;height:40px;padding:0 !important;">&nbsp;&nbsp;新学院</td>
            <!-- <td>{{ userInfo.xxy }}</td>-->
            <td style="background:none;padding:0 !important;line-height:40px;height:40px;">
              <el-select
                v-model="pyXjydb.xyxsh"
                clearable
                placeholder="请选择学院"
                @clear="pyXjydb.xyxsh = ''"
              >
                <el-option
                  v-for="item in xyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
            <td style="background:#f2f2f2;line-height:40px;height:40px;padding:0 !important;">&nbsp;&nbsp;新专业</td>
            <td colspan="2" style="background:none;line-height:40px;height:40px;padding:0 !important;">
              <el-select
                v-model="pyXjydb.xzym"
                clearable
                placeholder="请选择专业"
                @clear="pyXjydb.xzym = ''"
              >
                <el-option
                  v-for="item in zyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td style="line-height:40px;height:40px;padding:0 !important;">&nbsp;&nbsp;新导师</td>
            <td style="line-height:40px;height:40px;padding:0 !important;">
              <el-select
                v-model="pyXjydb.xdsh"
                filterable
                clearable
                placeholder="请选择导师"
                @clear="pyXjydb.xdsh = ''"
              >
                <el-option
                  v-for="item in dsOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
            <td style="line-height:40px;height:40px;padding:0 !important;"></td>
            <td colspan="2" style="line-height:40px;height:40px;padding:0 !important;"></td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="pyXjydb.ydsm"
                  ></el-input>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr>
            <td>证明材料：</td>
            <td colspan="5">
              <el-upload
                ref="upload"
                class="upload-demo"
                action="/api/system/upload"
                :beforeUpload="beforeAvatarUpload"
                :on-success="handleSuccess"
                :on-remove="handleRemove"
                multiple
                :limit="5"
                :headers="headtoken"
                v-loading="uploadLoading"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
              </el-upload>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- <div class="tip">
        <el-checkbox v-model="checked" class="required">
          <p style="margin-top:8px;">
            声明：本人已全面了解学校
            <el-link type="primary">《研究生学籍管理办法》</el-link>等文件政策；知晓拟转入学位点课程及学位授予标准要求。
          </p>
        </el-checkbox>
      </div> -->
      <div class="bottom">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'zzysq',
  props: ['userInfo'],
  data () {
    return {
      input: '',
      fileList: [],
      // checked: false,
      pyXjydb: {
        firstfj: [],
        ydlbm: '23', // 转专业
        xyxsh: '',
        xzym: '',
        xdsh: ''
      },
      dialogVisible: false,
      // 学院可选列表
      xyOptions: [],
      // 专业可选列表
      zyOptions: [],
      // 导师可选列表
      dsOptions: [],
      headtoken:{userToken:this.$store.state.userLoginMsg.userToken},
      uploadLoading:false
    }
  },
  created () {
    this.requireXY()
    console.log(this.userInfo)
  },
  methods: {
    handleSubmit () {
      // console.log(this.pyXjydb);
      this.dialogVisible = false
      if (this.pyXjydb.ydsm == ' ' || this.pyXjydb.ydsm == null) {
        this.$message.warning('请填写申请理由')
        return false
      }
      if (
        !this.pyXjydb.ydsm ||
        !this.pyXjydb.xyxsh ||
        !this.pyXjydb.xzym ||
        !this.pyXjydb.xdsh ) {
        this.$message.warning('请将必填项填写完整，再尝试提交')
        return false
      }
      const subLoading = this.$loading({target:document.querySelector('.table-box')})
      this.$http.post('/api/frontpage/xjydsq/start', this.pyXjydb).then(res => {
        subLoading.close()
        // console.log(res.data);
        if (res.data.code === 200) {
          this.$message.success('申请成功')
          // 清空附件
          this.$refs.upload.clearFiles()
          this.pyXjydb = {}
        }
      })
    },
    // 删除文件的回调
    handleRemove () {
      // console.log("移除文件");
      this.pyXjydb.firstfj.pop()
    },
    // 上传成功的回调
    handleSuccess(res,file,fileList) {
      this.uploadLoading = false
      if(res.code == 200){
        this.pyXjydb.firstfj.push(res.data);
      }else{
        fileList.pop()
        this.$message.error(res.message)
      }
    },
    beforeAvatarUpload(file) { 
      this.uploadLoading = true
    },
    // 获取学院可选列表
    requireXY () {
      this.$http.get('/api/cultivate/pygrpyjhb/selectDwList').then(res => {
        // //console.log(res.data.data)
        let data = res.data.data
        if (!Array.isArray(data)) {
          this.$message.error('获取学院信息失败，请重试')
          return
        }
        this.xyOptions = []
        data.map(item => {
          let obj = {
            value: item.dwh,
            label: item.dwmc
          }
          this.xyOptions.push(obj)
        })
        // this.pyXjydb.xyxsh = this.xyOptions[0].value
      })
    },
    // 根据学院查询专业
    requireZY () {
      // console.log(val)
      if (this.pyXjydb.xyxsh) {
        this.$http
          .get('/api/cultivate/pygrpyjhb/selectZyByDwh', {
            params: {
              dwh: this.pyXjydb.xyxsh
            }
          })
          .then(res => {
            // console.log(res.data.data)
            let data = res.data.data
            if (!Array.isArray(data)) {
              this.$message.error('获取专业信息失败，请重试')
              return
            }
            this.zyOptions = []
            data.map(item => {
              let obj = {
                value: item.zyh,
                label: item.zymc
              }
              this.zyOptions.push(obj)
            })

            this.pyXjydb.xzym = this.zyOptions[0].value
          })
      }
    },
    // 请求导师列表 //this.userInfo.pyccm根据培养层次获取相关的信息
    requireDS () {
      this.$http
        .get('/api/frontpage/xjydsq/selectTeaByMajor', {
          params: { zyh: this.pyXjydb.xzym, pyccm: '2' }
        })
        .then(res => {
          let data = res.data.data
          if (!Array.isArray(data)) {
            this.$message.error('获取导师信息失败，请重试')
            return
          }
          this.dsOptions = []
          data.map(item => {
            let obj = {
              value: item.gh,
              label: item.dsxm
            }
            this.dsOptions.push(obj)
          })
          // this.pyXjydb.dsxm = this.dsOptions[0].value;
        })
    }
  },
  watch: {
    // 监听学院变化
    'pyXjydb.xyxsh': {
      handler (val) {
        console.log(val)
        this.pyXjydb.xzym = ''
        this.pyXjydb.xdsh = ''
        if (val) {
          this.requireZY()
        }
      }
    },
    // 监听专业变化
    'pyXjydb.xzym': {
      handler (val) {
        console.log(val)
        this.pyXjydb.xdsh = ''
        // 如果专业有值
        if (val) {
          // 请求导师列表
          this.requireDS()
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;
  margin-top: 10px;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;
      .el-select{
        outline: none;
        width: 100%;
        // padding: 0 4px 0 0;
      }
      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.tip {
  p {
    // color: #f56c6c;
    font-size: 13px;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
