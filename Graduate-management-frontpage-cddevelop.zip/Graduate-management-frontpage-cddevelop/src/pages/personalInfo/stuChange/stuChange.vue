<template>
  <div>
    <!-- 学籍异动申请 stuChange -->
    <div class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/personalInfo/baseInfo' }">个人信息管理</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/personalInfo/stuChange/1'}">学籍异动申请</el-breadcrumb-item>
            <el-breadcrumb-item
              :to="{ path: '/personalInfo/stuChange/2'}"
              v-if="this.$route.params.id == 2 || this.$route.params.id == 3 || this.$route.params.id == 4"
            >申请记录</el-breadcrumb-item>
            <el-breadcrumb-item v-if="this.$route.params.id == 3">查看详情</el-breadcrumb-item>
            <el-breadcrumb-item v-if="this.$route.params.id == 4">修改</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right">
          <!-- <div v-show="applyShow"> -->
          <div v-show="this.$route.params.id == 1">
            <i class="el-icon-document"></i>
            <el-button type="text" @click="seeRecord">
              <el-badge class="item">查看申请记录</el-badge>
            </el-button>
          </div>
          <div v-show="!applyShow">
            <i class="el-icon-d-arrow-left"></i>
            <el-button type="text" @click="handleBack">返回</el-button>
          </div>
        </div>
      </my-breadcrumb>
      <div class="box change">
        <el-tabs v-model="activeTab" @tab-click="tabClick" v-show="this.$route.params.id == 1">
          <el-tab-pane label="延迟毕业申请" name="first">
            <ycbysq :userInfo="userInfo1" v-if="activeTab === 'first'"></ycbysq>
          </el-tab-pane>
          <el-tab-pane label="复学申请" name="second">
            <fxsq :userInfo="userInfo2" v-if="activeTab === 'second'"></fxsq>
          </el-tab-pane>
          <el-tab-pane label="结业申请" name="third">
            <jysq :userInfo="userInfo3" v-if="activeTab === 'third'"></jysq>
          </el-tab-pane>
          <el-tab-pane label="休（停）学申请" name="four">
            <xxsq :userInfo="userInfo4" v-if="activeTab === 'four'"></xxsq>
          </el-tab-pane>
          <el-tab-pane label="肄业申请" name="five">
            <yysq :userInfo="userInfo5" v-if="activeTab === 'five'"></yysq>
          </el-tab-pane>
          <el-tab-pane label="转专业申请" name="six">
            <zzysq :userInfo="userInfo6" v-if="activeTab === 'six'"></zzysq>
          </el-tab-pane>
          <el-tab-pane label="退学申请" name="seven">
            <txsq :userInfo="userInfo7" v-if="activeTab === 'seven'"></txsq>
          </el-tab-pane>
        </el-tabs>
        <!-- <ycbysq-save v-show="sqlx == '06' || sqlx1 == '06'" :userInfo="userInfo1" :status="sqzt" :status1="sqzt1"></ycbysq-save> -->
        <ycbysq-save
          v-if="$route.query.sqlx == '06'"
          :userInfo="pyXjydb"
          :status="$route.query.sqzt"
        ></ycbysq-save>
        <fxsq-save
          v-if="$route.query.sqlx == '12'"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></fxsq-save>
        <jysq-save
          v-if="$route.query.sqlx == '62'"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></jysq-save>
        <xxsq-save
          v-if="$route.query.sqlx == '11'"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></xxsq-save>
        <yysq-save
          v-if="$route.query.sqlx == '63'"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></yysq-save>
        <zzysq-save
          v-if="$route.query.sqlx == '23'"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></zzysq-save>
        <txsq-save
          v-if="$route.query.sqlx == '31'"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></txsq-save>
        <apply-record
          v-if="this.$route.params.id == 2"
          @listen="listen"
          @listen1="listen1"
          ref="childRecord"
        ></apply-record>
        <apply-status-bottom
          v-if="this.$route.params.id == 3 || this.$route.params.id == 4"
          ref="applyStatus"
        ></apply-status-bottom>
      </div>
    </div>
  </div>
</template>

<script>
import ycbysq from "./components/ycbysq";
import ycbysqSave from "./components/ycbysqSave";
import fxsq from "./components/fxsq";
import fxsqSave from "./components/fxsqSave";
import jysq from "./components/jysq";
import jysqSave from "./components/jysqSave";
import xxsq from "./components/xxsq";
import xxsqSave from "./components/xxsqSave";
import yysq from "./components/yysq";
import yysqSave from "./components/yysqSave";
import zzysq from "./components/zzysq";
import zzysqSave from "./components/zzysqSave";
import txsq from "./components/txsq";
import txsqSave from "./components/txsqSave";
import applyRecord from "./components/applyRecord";
import myBreadcrumb from "@/components/myBreadcrumb";
import applyStatusBottom from "@/components/applyStatusBottom";
export default {
  name: "stuChange",
  components: {
    ycbysq,
    ycbysqSave,
    fxsq,
    fxsqSave,
    jysq,
    jysqSave,
    xxsq,
    xxsqSave,
    yysq,
    yysqSave,
    zzysq,
    zzysqSave,
    txsq,
    txsqSave,
    applyRecord,
    applyStatusBottom,
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      activeTab: "first",
      applyShow: true, // 申请显示
      seeShow: false, // 修改，查看详情
      tableShow: false, // 申请列表显示
      userInfo: {},
      userInfo1: {}, // 延迟毕业申请
      userInfo2: {}, // 复学申请
      userInfo3: {}, // 结业申请
      userInfo4: {}, // 休学申请
      userInfo5: {}, // 肆业申请
      userInfo6: {}, // 转专业申请
      userInfo7: {}, // 退学申请
      tableData: [], // 查看申请记录列表
      pyXjydb: {
        xh: ""
      },
      userList: {
        xm: "李文达",
        xh: "2131443",
        xb: "男",
        xy: "软件工程",
        zy: "计算机",
        nj: "2018级",
        yds: "克里斯"
      },
      sqlx: "", // 申请类型：查看时
      lxm: "",
      sqlx1: "", // 申请类型：修改时
      lxm1: "",
      sqzt: "", // 审核状态：查看时
      sqzt1: "" // 审核状态：修改时
    };
  },
  watch: {
    $route() {
      this.getId();
    }
  },
  created() {
    this.getId();
  },
  mounted() {
    this.getData();
  },
  methods: {
    // 初始化数据
    getData() {
      this.$http.get("/api/frontpage/xjydsq/ycbyInit").then(res => {
        this.userInfo1 = res.data.data;
      });
    },
    // 复学申请初始化
    getData2() {
      this.$http.get("/api/frontpage/xjydsq/fxsqInit").then(res => {
        this.userInfo2 = res.data.data;
      });
    },
    // 结业申请初始化
    getData3() {
      this.$http.get("/api/frontpage/xjydsq/jysqInit").then(res => {
        this.userInfo3 = res.data.data;
      });
    },
    // 休学申请初始化
    getData4() {
      this.$http.get("/api/frontpage/xjydsq/xxsqInit").then(res => {
        this.userInfo4 = res.data.data;
      });
    },
    // 肄业申请初始化
    getData5() {
      this.$http.get("/api/frontpage/xjydsq/yysqInit").then(res => {
        this.userInfo5 = res.data.data;
      });
    },
    // 转专业申请初始化
    getData6() {
      this.$http.get("/api/frontpage/xjydsq/zzysqInit").then(res => {
        this.userInfo6 = res.data.data;
      });
    },
    // 退学申请初始化
    getData7() {
      this.$http.get("/api/frontpage/xjydsq/txsqInit").then(res => {
        this.userInfo7 = res.data.data;
      });
    },
    // 父组件接收子组件传过来的shzt
    listen(data) {
      this.pyXjydb = data.pyXjydb;

      this.sqlx = data.sqlx;
      this.sqzt = data.sqzt;
    },
    listen1(data) {
      this.sqlx1 = data.sqlx;
      this.sqzt1 = data.sqzt;
    },
    // tab栏切换
    tabClick(t) {
      this.handleSwitch(t);
    },
    handleSwitch(t) {
      switch (t.name) {
        case "first":
          // console.log(1);
          this.getData();
          break;
        case "second":
          // console.log(2);
          this.getData2();
          break;
        case "third":
          // console.log(3);
          this.getData3();
          break;
        case "four":
          // console.log(4);
          this.getData4();
          break;
        case "five":
          // console.log(5);
          this.getData5();
          break;
        case "six":
          // console.log(6);
          this.getData6();
          break;
        case "seven":
          // console.log(7);
          this.getData7();
          break;
      }
    },
    // 查看申请记录
    seeRecord() {
      sessionStorage.setItem('sqjl1',false)
      sessionStorage.removeItem('pageNum1')
      // this.$refs.childRecord.loadTable();
      // this.applyShow = false
      this.$router.push({
        path: "/personalInfo/stuChange/2"
      });
    },
    // 新建申请(返回)
    handleBack() {
      sessionStorage.setItem('sqjl1',true)
      this.applyShow = true;
      // this.$router.push({
      //     path: '/personalInfo/stuChange/1'
      // })
      console.log(this)
      this.sqlx = "";
      this.sqlx1 = "";
      this.$router.go(-1);
    },
    getId() {
      let id = this.$route.params.id;
      // 1:申请表
      // 2:查看申请列表
      // 3:点击查看
      // 4:点击修改
      if (id == 1) {
        this.userInfo = {};
        this.applyShow = true;
        this.tableShow = false;
        this.seeShow = false;
      }
      if (id == 2) {
        this.applyShow = false;
        this.tableShow = true;
        this.seeShow = false;
      }
      if (id == 3) {
        this.userInfo = this.userList;
        this.applyShow = false;
        this.tableShow = false;
        this.seeShow = true;
        // this.$store.state.changeTutor = false
      }
      if (id == 4) {
        // console.log(4);
        this.userInfo = this.userList;
        this.applyShow = false;
        this.tableShow = false;
        this.seeShow = true;
      }
    }
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  .el-icon-document,
  .el-icon-d-arrow-left {
    margin-right: 5px;
    color: #409eff;
  }

  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    padding-top: 0;
    height: calc(100vh - 219px);
    overflow: auto;
    /deep/ {
      .el-tabs__nav {
        width: 100%;
        height: $student-tab-height;
        line-height: $student-tab-height;
      }
      .el-tabs__item {
        width: 14.3% !important;
        font-weight: normal !important;
        text-align: center;
      }
      .el-tabs__header {
        margin: 0 0 $top;
      }
      .el-textarea {
        width: 90%;
      }
    }
  }
}
</style>
