<template>
  <div>
    <!-- 家庭信息修改/保存 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">| 家庭信息</th>
          <tr>
            <td>家庭电话</td>
            <td>
              <el-input v-model="userInfo.studentJtxxes.jtdh" type="number" @blur="homephone"></el-input>
            </td>
            <td>邮政编码</td>
            <td>
              <el-input v-model="userInfo.studentJtxxes.jtyzbm" @blur="zipcode"></el-input>
            </td>
            <td>家庭地址</td>
            <td>
              <el-input v-model="userInfo.studentJtxxes.jtzz"></el-input>
            </td>
          </tr>
          <th colspan="6">| 家庭成员信息</th>
        </tbody>
      </table>
      <el-table :data="userInfo.studentJtxxes.xsJtcybs" border style="width: 100%" align="center">
        <el-table-column prop="cyxm" label="姓名" align="center">
          <template slot-scope="scope">
            <el-row>
              <el-col :span="4">
                <i class="el-icon-error" @click="delRow(scope.$index, scope.row)"></i>
              </el-col>
              <el-col :span="20">
                <el-input v-model="scope.row.cyxm"></el-input>
              </el-col>
            </el-row>
          </template>
        </el-table-column>
        <el-table-column prop="gxm" label="与本人关系" align="center">
          <template slot-scope="scope">
            <el-select v-model="scope.row.gxm" placeholder="请选择" align="center" style="width:100%;">
              <el-option
                v-for="(item,index) of userInfo.jtgxms"
                :key="index"
                :label="item.jtgxmc"
                :value="item.jtgxdm"
              ></el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="lxfs" label="联系方式" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.lxfs" @blur="contact"></el-input>
          </template>
        </el-table-column>
        <el-table-column prop="gzdw" label="工作单位" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.gzdw"></el-input>
          </template>
        </el-table-column>
        <el-table-column prop="zymc" label="职业" align="center">
          <template slot-scope="scope">
            <el-input v-model="scope.row.zy"></el-input>
          </template>
        </el-table-column>
      </el-table>
      <div class="append">
        <el-button type="primary" plain @click="addRow">
          添加家庭成员
          <i class="el-icon-plus el-icon--right"></i>
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "jtxxSave",
  props: ["userInfo"],
  data() {
    return {
      input: "",
      value: "",
      tableData: [],
      options: []
    };
  },
  mounted() {
    console.log(this.userInfo.jtgxms);
  },
  methods: {
    addRow() {
      // console.log(111);
      let newValue = {
        cyxm: "",
        gxm: "",
        lxfs: "",
        gzdw: "",
        zymc: ""
      };
      this.userInfo.studentJtxxes.xsJtcybs.push(newValue);
    },
    // 申请表信息动态减少行
    delRow(index) {
      this.userInfo.studentJtxxes.xsJtcybs.splice(index, 1);
    },
    //失去焦点事件，判断家庭电话的格式是否正确
    homephone(){
       var reg1=/^1[3456789]\d{9}$/;
       var reg2 =/^((0\d{2,3}-\d{7,8})|(1[3584]\d{9}))$/;
       if (!this.userInfo.studentJtxxes.jtdh) {
         this.$message.error('家庭电话不能为空！')
       }else if (!reg1.test(this.userInfo.studentJtxxes.jtdh) || !reg2.test(this.userInfo.studentJtxxes.jtdh)) {
         this.$message.error('家庭电话格式不正确！')
       }
    },
    zipcode(){
      var pattern = /[0-9][0-9]{5}/;
      if (!this.userInfo.studentJtxxes.jtdh) {
        // console.log('不对')
         this.$message.error('邮政编码不能为空！')
       }else if (!pattern.test(this.userInfo.studentJtxxes.jtdh)) {
         this.$message.error('邮政编码格式不正确！')
       }
    },
    contact(){
      var reg3=/^1[3456789]\d{9}$/;
       if (!this.lxfs) {
         this.$message.error('联系方式不能为空！')
       }else if (!reg3.test(this.lxfs)) {
         this.$message.error('联系方式格式不正确！')
       }
    }
  }
};
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: left;
      background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      text-align: center;
      height: 20px;
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }

  .append {
    margin-top: 20px;
  }
}
.el-table td div {
  overflow: visible;
  padding-right: 0;
  padding-left: 0;
}
.table-box /deep/ .el-table th > .cell {
  line-height: 40px;
}

.table-box /deep/ .el-select {
  width: 100%;
}

.table-box /deep/ .el-input__icon{
  margin-right: 10px;
}

.table-box /deep/ .el-icon-error {
  width: 20px;
  line-height: 40px;
  margin-right: 5px;
  cursor: pointer;

  &:before {
    font-size: 22px;
  }
}
</style>
