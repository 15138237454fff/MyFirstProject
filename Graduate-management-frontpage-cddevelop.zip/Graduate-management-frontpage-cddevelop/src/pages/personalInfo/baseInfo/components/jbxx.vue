<template>
  <div>
    <!-- 基本信息展示 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <!-- <th colspan="6">| 基本信息</th> -->
          <tr>
            <td colspan="6" style="text-align:left;color:#000;font-weight:500;">| 基本信息</td>
             <td rowspan="4">
              <img :src="userInfo.zp" alt class="avatar" />
            </td>
          </tr>
          <tr>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>姓名拼音</td>
            <td>{{ userInfo.xmpy }}</td>
            <!-- <td rowspan="3">
              <img :src="userInfo.zp" alt class="avatar" />
            </td> -->
          </tr>
          <tr>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
            <td>民族</td>
            <td>{{ userInfo.mzmc }}</td>
            <td>出生日期</td>
            <td>{{ userInfo.csrq }}</td>
          </tr>
          <tr>
            <td>婚姻状况</td>
            <td>{{ userInfo.hyzkmc }}</td>
            <td>政治面貌</td>
            <td>{{ userInfo.zzmmmc }}</td>
            <td>健康状况</td>
            <td>{{ userInfo.jkzkmc }}</td>
          </tr>
          <tr>
            <td>国籍</td>
            <td>{{ userInfo.gjmc }}</td>
            <td>籍贯</td>
            <td>{{ userInfo.jg }}</td>
            <td>出生地</td>
            <td colspan="2">{{ userInfo.csdm }}</td>
          </tr>
          <tr>
            <td>户口所在地</td>
            <td>{{ userInfo.hkszd }}</td>
            <td>证件类型</td>
            <td>{{ userInfo.sfzjlxmc }}</td>
            <td>证件号码</td>
            <td colspan="2">{{ userInfo.sfzh }}</td>
          </tr>
          <tr>
            <td>户口详细地址</td>
            <td colspan="6">{{ userInfo.hkxxdz }}</td>
          </tr>
          <tr>
            <td>移动电话</td>
            <td>{{ userInfo.yzbm }}</td>
            <td>固定电话</td>
            <td>{{ userInfo.dh }}</td>
            <td>电子信箱</td>
            <td colspan="2">{{ userInfo.dzxx }}</td>
          </tr>
          <tr>
            <td>邮政编码</td>
            <td>{{ userInfo.yzbm }}</td>
            <td>通信地址</td>
            <td colspan="4">{{ userInfo.txdz }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: 'jbxx',
  props: ['userInfo'],
  data () {
    return {}
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;
  table {
    width: 98%;
    // margin-top: 30px;
    margin:20px auto;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    table-layout: auto;
    th {
      text-align: left;
      background-color: rgba(242, 242, 242, 1);
    }
    td {
      width: 100px;
      text-align: center;
      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
</style>
