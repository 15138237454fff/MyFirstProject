<template>
  <div>
    <!-- 基本信息修改/保存 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="7">| 个人信息</th>
          <tr>
            <td>学号</td>
            <td>{{ userInfo.xsXsjcsjb.xh }}</td>
            <td>姓名</td>
            <td>{{ userInfo.xsXsjcsjb.xm }}</td>
            <td>姓名拼音</td>
            <td>{{ userInfo.xsXsjcsjb.xmpy }}</td>
            <td rowspan="3" style="padding:0;height:60px;line-height: 60px;">
              <el-upload
                ref="upload"
                class="avatar-uploader"
                :headers="headers"
                action="/api/system/upload"
                :on-success="handleSuccess"
                :show-file-list="false"
                style="padding:0;height:60px;line-height: 60px;"
              >
                <img v-if="userInfo.xsXsjcsjb.zp" :src="userInfo.xsXsjcsjb.zp" class="avatar" />
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </td>
          </tr>
          <tr>
            <td>性别</td>
            <td>{{ userInfo.xsXsjcsjb.xbm == 1? '男': userInfo.xsXsjcsjb.xbm == 2? '女' : ''}}</td>
            <td>民族</td>
            <td>
              <el-select v-model="userInfo.xsXsjcsjb.mzm" placeholder="请选择" style="width:100%;">
                <el-option
                  v-for="item in userInfo.mzdmbs"
                  :key="item.mzdm"
                  :label="item.mzmc"
                  :value="item.mzdm"
                ></el-option>
              </el-select>
            </td>
            <td>出生日期</td>
            <td>{{ userInfo.xsXsjcsjb.csrq }}</td>
          </tr>
          <tr>
            <td>婚姻状况</td>
            <td>
              <el-select v-model="userInfo.xsXsjcsjb.hyzkm" placeholder="请选择" style="width:100%;">
                <el-option
                  v-for="item in userInfo.hyzk"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
            <td>政治面貌</td>
            <td>
              <el-select v-model="userInfo.xsXsjcsjb.zzmmm" placeholder="请选择" style="width:100%;">
                <el-option
                  v-for="item in userInfo.zzmmdmbs"
                  :key="item.zzmmdm"
                  :label="item.zzmmmc"
                  :value="item.zzmmdm"
                ></el-option>
              </el-select>
            </td>
            <td>健康状况</td>
            <td>
              <el-select v-model="userInfo.xsXsjcsjb.jkzkm" placeholder="请选择" style="width:100%;">
                <el-option
                  v-for="item in userInfo.jkzk"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td>国籍</td>
            <td>{{ userInfo.xsXsjcsjb.gjmc }}</td>
            <td>籍贯</td>
            <td>{{ userInfo.xsXsjcsjb.jg }}</td>
            <td>出生地</td>
            <td colspan="7">{{ userInfo.xsXsjcsjb.csdm }}</td>
          </tr>
          <tr>
            <td>户口所在地</td>
            <td>
              <el-input v-model="userInfo.xsXsjcsjb.hkszd"></el-input>
            </td>
            <td>证件类型</td>
            <td>{{ userInfo.xsXsjcsjb.sfzjlxm }}</td>
            <td>证件号码</td>
            <td colspan="7">
              <el-input v-model="userInfo.xsXsjcsjb.sfzh"></el-input>
            </td>
          </tr>
          <tr>
            <td>邮政编码</td>
            <td>
              <el-input v-model="userInfo.xsXsjcsjb.yzbm"></el-input>
            </td>
            <td>电话号码</td>
            <td>
              <el-input v-model="userInfo.xsXsjcsjb.dh"></el-input>
            </td>
            <td>电子邮箱</td>
            <td colspan="7">
              <el-input v-model="userInfo.xsXsjcsjb.dzxx"></el-input>
            </td>
          </tr>
          <tr>
            <td>通信地址</td>
            <td colspan="3">
              <el-input v-model="userInfo.xsXsjcsjb.txdz"></el-input>
            </td>
            <td></td>
            <td colspan="2"></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: 'jbxxSave',
  props: ['userInfo'],
  data () {
    return {
      input: '',
      value: '',
      jbxxList: {},
      imageUrl: '',
      writeableList: {},
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
    }
  },
  mounted () {
    this.requireWriteable()
  },
  methods: {
    handleAvatarSuccess () {},
    beforeAvatarUpload () {},
    handleSuccess (res) {
      this.userInfo.xsXsjcsjb.zp = res.data.url
    },
    requireWriteable () {
      this.$http.get('/api/cultivate/pycssz').then(res => {
        let data = res.data.data
        if (!data) {
          this.$message.error(res.data.message)
          return
        }
        this.writeableList = data.main
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  box-sizing: border-box;
  table {
    width: 100%;
    border-collapse: collapse;
    table-layout: auto;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    th {
      text-align: left;
    }
    td {
      width: 100px;
      text-align: center;
      padding: 0;
      height: 40px;
      line-height: 40px;
      .avatar {
        width: 90px;
        height: 115px;
      }
      .el-icon-plus.avatar-uploader-icon {
        height: 125px;
        line-height: 125px;
      }
      .el-upload {
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
</style>
<style lang="scss">
// .el-input__inner {
//     height: 30px!important;
// }
// .el-input__icon {
//     line-height: 30px;
// }
.avatar-uploader .el-upload {
  // border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  bottom:26px;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 125px;
  line-height: 125px;
  text-align: center;
}
</style>
