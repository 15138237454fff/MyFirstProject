<template>
  <div>
    <!-- 家庭信息展示 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="7">| 其他信息</th>
          <tr>
            <td rowspan="2" style="white-space:pre-wrap;" class="jtbg">何时何地何原因受过何种奖励或处分</td>
          </tr>
          <tr>
            <td colspan="6" style="height:80px;">
              <!-- <el-input
                type="textarea"
                :autosize="{ minRows: 4, maxRows: 6}"
                placeholder="请输入内容"
                v-model="reson"
                style="height:100%"
              ></el-input> -->
            </td>
          </tr>
          <tr>
            <td rowspan="4" class="jtbg">学习和工作经历</td>
          </tr>
          <tr>
            <td colspan="2" class="jtbg">起止时间</td>
            <td colspan="2" class="jtbg">学习或工作单位</td>
            <td colspan="2" class="jtbg">职务</td>
          </tr>
          <tr>
            <td colspan="2">
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
          </tr>
          <tr>
            <td rowspan="4" class="jtbg">家庭主要成员</td>
          </tr>
          <tr>
            <td class="jtbg">姓名</td>
            <td class="jtbg">关系</td>
            <td colspan="2" class="jtbg">工作单位及职务</td>
            <td colspan="2" class="jtbg">联系方式</td>
          </tr>
          <tr>
            <td>{{ userInfo.studentJtxxes.xsJtcybs[0].cyxm }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td>{{ userInfo.studentJtxxes.xsJtcybs[0].gxm }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">{{ userInfo.studentJtxxes.xsJtcybs[0].gzdw }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">{{ userInfo.studentJtxxes.jtdh }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
          </tr>
          <tr>
            <td>{{ userInfo.studentJtxxes.xsJtcybs[1].cyxm }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td>{{ userInfo.studentJtxxes.xsJtcybs[1].gxm }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">{{ userInfo.studentJtxxes.xsJtcybs[1].gzdw }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
            <td colspan="2">{{ userInfo.studentJtxxes.jtdh }}
              <!-- <el-input v-model="reson1" placeholder="请输入内容"></el-input> -->
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: "jtxx",
  props: ["userInfo"],
  data() {
    return {
      reson: "",
      reson1: "",
      studentJtxxes: {
        xsJtcybs: []
      }
    };
  },
  methods: {
    jtgxm(gxm) {
      let tmpObj = this.userInfo.jtgxms.find(el => {
        return gxm === el.jtgxmc;
      });
      if (tmpObj) {
        return tmpObj.jtgxmc;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;
  table {
    width: 98%;
    margin: 20px auto;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);
    th {
      text-align: left;
      background-color: rgba(242, 242, 242, 1);
    }
    .jtbg {
      background-color: rgba(242, 242, 242, 1);
    }
    td {
      width: 100px;
      text-align: center;
      height: 20px;
      // padding: 0;
    }
  }
  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
</style>
