<template>
    <div>
        <!-- 学籍信息展示 -->
        <div class="table-box">
            <table border="1" cellspacing="0" cellpadding="10" style="margin-top:10px;">
                <thead></thead>
                <tbody>
                    <th colspan="6">| 学籍信息</th>
                    <tr>
                        <td>学生类别</td>
                        <td>{{ userInfo.xslbmc }}</td>
                        <td>学习方式</td>
                        <td>{{ userInfo.xslbmc }}</td>
                        <td>培养层次</td>
                        <td>{{ userInfo.pyccmc }}</td>
                    </tr>
                    <tr>
                        <td>入学年月</td>
                        <td>{{ userInfo.rxny }}</td>
                        <td>年级</td>
                        <td>{{ userInfo.sznj }}</td>
                        <td>学制</td>
                        <td>{{ userInfo.xz }}</td>
                    </tr>
                    <tr>
                        <td>所属学院</td>
                        <td>{{ userInfo.yxsh }}</td>
                        <td>所属专业</td>
                        <td>{{ userInfo.zy }}</td>
                        <td>研究方向</td>
                        <td>{{ userInfo.yjfx }}</td>
                    </tr>
                    <tr>
                        <td>班级</td>
                        <td>{{ userInfo.bjmc }}</td>
                        <td>导师</td>
                        <td>{{ userInfo.dsxm }}</td>
                        <td>当前状态</td>
                        <td>{{ userInfo.xsdqztmc }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
export default {
  name: 'xjxx',
  props: [
    'userInfo'
  ],
  data () {
    return {
      // userInfo: {}
    }
  },
  methods: {

  }
}
</script>

<style lang="scss" scoped>
.table-box {
    width: 100%;
    // height: 200px;
    // border: 1px solid rgba(228, 228, 228, 1);
    box-sizing: border-box;
    table {
        width:98%;
        margin: 0 auto;
        border-collapse: collapse;
        color: #333;
        font-size: 14px;
        border: none;
        border-color: rgba(228, 228, 228, 1);
        th {
            text-align: left;
            background-color: rgba(242, 242, 242, 1);
        }
        td {
            width: 100px;
            text-align: center;
            &:nth-child(odd){
                background: #f2f2f2;
            }
        }
    }
    .star::before {
        content: "*";
        color: #f56c6c;
        margin-right: 4px;
    }
}
</style>
