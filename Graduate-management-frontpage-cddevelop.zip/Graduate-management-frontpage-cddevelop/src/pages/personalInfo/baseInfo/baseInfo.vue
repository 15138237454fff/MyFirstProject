<template>
  <div>
    <!-- 个人基本信息 baseInfo -->
    <div class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/personalInfo/baseInfo' }"
              >个人信息管理</el-breadcrumb-item
            >
            <el-breadcrumb-item>个人基本信息</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right">
          <el-button @click="baseinfosave" class="modifyThe">修改</el-button>
        </div>
      </my-breadcrumb>
      <div class="box personal">
        <div class="personsafe" v-loading="loading">
          <table>
            <tr>
              <td
                class="listcss"
                colspan="6"
                style="text-align:left;font-weight:bold"
              >
                | 基本信息
              </td>
              <td rowspan="4" class="imgBox">
                <img
                  :src="resetForm.zp"
                  alt
                  style="width:100px;height:100px;display: inline;"
                />
              </td>
            </tr>
            <tr>
              <td class="listcss">学号</td>
              <td>{{ form.xh }}</td>
              <td class="listcss">姓名</td>
              <td>{{ form.xsxm }}</td>
              <td class="listcss">姓名拼音</td>
              <td>{{ resetForm.xmpy }}</td>
            </tr>
            <tr>
              <td class="listcss">性别</td>
              <td>{{ resetForm.xbm | xbm }}</td>
              <td class="listcss">民族</td>
              <td>{{ resetForm.mzmc }}</td>
              <td class="listcss">出生日期</td>
              <td>{{ resetForm.csrq }}</td>
            </tr>
            <tr>
              <td class="listcss">婚姻状况</td>
              <td>{{ resetForm.hyzkmc }}</td>
              <td class="listcss">政治面貌</td>
              <td>{{ resetForm.zzmmmc }}</td>
              <td class="listcss">健康状况</td>
              <td>{{ resetForm.jkzkmc }}</td>
            </tr>
            <tr>
              <td class="listcss">国籍</td>
              <td>{{ resetForm.gjmc }}</td>
              <td class="listcss">证件类型</td>
              <td>{{ resetForm.sfzjlxm }}</td>
              <td class="listcss">证件号码</td>
              <td colspan="2">{{ resetForm.sfzh }}</td>
            </tr>
            <tr>
              <td class="listcss">籍贯</td>
              <td>{{ resetForm.jgmc }}</td>
              <td class="listcss">出生地</td>
              <td>{{ resetForm.csdmc }}</td>
              <td class="listcss">户口所在地</td>
              <td colspan="2">{{ resetForm.hkszdmc }}</td>
            </tr>
            <tr>
              <td class="listcss">户口详细地址</td>
              <td colspan="6">{{ resetForm.hkxxdz }}</td>
            </tr>
            <tr>
              <td class="listcss">移动电话</td>
              <td>{{ resetForm.yddh }}</td>
              <td class="listcss">固定电话</td>
              <td>{{ resetForm.dh }}</td>
              <td class="listcss">电子邮箱</td>
              <td colspan="2">{{ resetForm.dzxx }}</td>
            </tr>
            <tr>
              <td class="listcss">邮政编码</td>
              <td>{{ resetForm.yzbm }}</td>
              <td class="listcss">通讯地址</td>
              <td colspan="4">{{ resetForm.txdz }}</td>
            </tr>
          </table>

          <table>
            <tr>
              <td
                class="listcss"
                colspan="8"
                style="text-align:left;font-weight:bold"
              >
                | 学籍信息
              </td>
            </tr>
            <tr>
              <td class="listcss">学生类别</td>
              <td>{{ form.xslbmc }}</td>
              <td class="listcss">学习方式</td>
              <td>{{ form.xxfsmc }}</td>
              <td class="listcss">培养层次</td>
              <td>{{ form.pyccmc }}</td>
            </tr>
            <tr>
              <td class="listcss">入学年月</td>
              <td>{{ form.rxny }}</td>
              <td class="listcss">年级</td>
              <td>{{ form.sznj }}</td>
              <td class="listcss">学制</td>
              <td>{{ form.xz }}</td>
            </tr>
            <tr>
              <td class="listcss">所属学院</td>
              <td>{{ form.ssyxmc }}</td>
              <td class="listcss">所属专业</td>
              <td>{{ form.zy }}</td>
              <td class="listcss">研究方向</td>
              <td>{{ form.yjfx }}</td>
            </tr>
            <tr>
              <td class="listcss">班级</td>
              <td>{{ form.bjmc }}</td>
              <td class="listcss">导师</td>
              <td>{{ form.dsxm }}</td>
              <td class="listcss">当前状态</td>
              <td>{{ form.xsdqztmc }}</td>
            </tr>
            <tr>
              <td class="listcss">是否跨学科</td>
              <td colspan="5">
                {{ form.sfkk == 0 ? "否" : form.sfkk == 1 ? "是" : "" }}
              </td>
            </tr>
          </table>

          <table>
            <tr>
              <td
                class="listcss"
                colspan="8"
                style="text-align:left;font-weight:bold"
              >
                | 其他信息
              </td>
            </tr>
            <tr>
              <td class="listcss">何时何地何原因受过何种奖励或处分</td>
              <td colspan="7">{{ resetForm.jcnr }}</td>
            </tr>
            <tr>
              <td class="listcss" :rowspan="resetForm.qtList.length + 1">
                学习和工作经历
              </td>
              <td class="listcss" colspan="2">起止时间</td>
              <td class="listcss" colspan="2">学习或工作单位</td>
              <td class="listcss" colspan="2">职务</td>
            </tr>
            <template v-for="(item, index) in resetForm.qtList">
              <tr>
                <td colspan="2" style="text-align: center;">
                  {{ item.kssj | kssj }} 至 {{ item.jssj | jssj }}
                </td>
                <td colspan="2">{{ item.gzdw }}</td>
                <td colspan="2">{{ item.zw }}</td>
              </tr>
            </template>
            <tr>
              <td class="listcss" :rowspan="resetForm.jtcy.length + 1">
                家庭主要成员
              </td>
              <td class="listcss">姓名</td>
              <td class="listcss">关系</td>
              <td class="listcss">工作单位</td>
              <td class="listcss">职务</td>
              <td class="listcss">联系方式</td>
            </tr>
            <template v-for="(item, index) in resetForm.jtcy">
              <tr>
                <td>{{ item.cyxm }}</td>
                <td>
                  <span v-if="resetForm.jtcy.length">{{
                    item.gxm | jtgxlist(jtgxlist)
                  }}</span>
                  <span v-else>未知</span>
                </td>
                <td>{{ item.gzdw }}</td>
                <td>
                  <span v-if="resetForm.jtcy.length">{{
                    item.zy | zylist(zylist)
                  }}</span>
                  <span v-else>未知</span>
                </td>
                <td colspan="2">{{ item.lxfs }}</td>
              </tr>
            </template>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "baseInfo",
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      form: {},
      resetForm: {
        qtList: [],
        jtcy: []
      },
      jtgxlist: [],
      zylist: [],
      nativeList: [],
      hkszd: "",
      loading: true
    };
  },
  filters: {
    xbm(val) {
      switch (val) {
        case "1":
          return "男";
          break;
        case "2":
          return "女";
          break;
        default:
          break;
      }
    },
    kssj(val) {
      if (val == "" || val == null) {
        return;
      }
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jssj(val) {
      if (val == "" || val == null) {
        return;
      }
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jtgxlist(val, index) {
      const valindex = index.find((el, index) => el.value === val);
      if (valindex) {
        return valindex.label;
      } else {
        return "";
      }
    },
    zylist(val, index) {
      const valindex = index.find((el, index) => el.value === val);
      if (valindex) {
        return valindex.label;
      } else {
        return "";
      }
    }
  },
  methods: {
    takeList() {
      var hk = "";
      this.$http.get("/api/cultivate/stu/xjsj/" + this.xh).then(res => {
        //获取学生的学籍信息
        if (!res.data.data) {
          this.$message.error({
            message: "数据为空"
          });
        } else {
          this.form = res.data.data;
          console.log(this.form);
        }
      });
      this.$http.get("/api/cultivate/stu/jbxx/" + this.xh).then(res => {
        //获取学生的基本信息
        this.loading = false;
        if (!res.data.data) {
          this.$message.error({
            message: "数据为空"
          });
        } else {
          this.resetForm = res.data.data;
          if (this.resetForm.qtList.length == 0) {
            this.resetForm.qtList = [{ kssj: "", jssj: "", gzdw: "", zw: "" }];
          }
          if (this.resetForm.jtcy.length == 0) {
            this.resetForm.jtcy = [
              { cyxm: "", gxm: "", gzdw: "", zy: "", lxfs: "" }
            ];
          }
          console.log(this.resetForm);
          this.$http
            .get("/api/system/dict/select/origoLevelThree")
            .then(res => {
              this.nativeList = res.data.data;
              // hk = this.resetForm.hkszd.length == 1 ? this.resetForm.hkszd.toString() : this.resetForm.hkszd[this.resetForm.hkszd.length - 1];
              // // console.log(hk,'户口')
              // this.nativeList.map(v => {
              //   if (v.value === hk) {
              //     this.hkszd = v.label;
              //   } else {
              //     if (v.children) {
              //       v.children.map(vv => {
              //         if (vv.value === hk) {
              //            this.hkszd = `${v.label}/${vv.label}`;
              //         } else {
              //           if (vv.children) {
              //             vv.children.map(f => {
              //               if (f.value === hk) {
              //                  this.hkszd = `${v.label}/${vv.label}/${f.label}`;
              //               }
              //             });
              //           }
              //         }
              //       });
              //     }
              //   }
              // });
            });
          this.$http.get("/api/system/dict/select/all").then(res => {
            // 关系
            this.jtgxlist = res.data.data.jtgx;
            //职业码
            this.zylist = res.data.data.zw;
            // 婚姻状况
            if (this.resetForm.hyzkmc != null) {
              this.resetForm.hyzkm = res.data.data.hyzk.find(
                (el, index) => el.value == this.resetForm.hyzkm
              ).label;
            }
            // 政治面貌
            if (this.resetForm.zzmmmc != null) {
              this.resetForm.zzmmm = res.data.data.zzmm.find(
                (el, index) => el.value == this.resetForm.zzmmm
              ).label;
            }
            // 民族
            if (this.resetForm.mzmc != null) {
              this.resetForm.mzm = res.data.data.mz.find(
                (el, index) => el.value == this.resetForm.mzm
              ).label;
            }
            // 健康状况
            if (this.resetForm.jkzkm != null) {
              this.resetForm.jkzkm = res.data.data.jkzk.find(
                (el, index) => el.value == this.resetForm.jkzkm
              ).label;
            }
            // 证件类型
            if (this.resetForm.sfzjlxmc != null) {
              this.resetForm.sfzjlxm = res.data.data.zjlx.find(
                (el, index) => el.value == this.resetForm.sfzjlxm
              ).label;
            }
          });
        }
      });
    },
    baseinfosave() {
      this.$router.push("/personalInfo/baseInfoModify");
    }
  },
  created() {},
  mounted() {
    this.takeList();
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>

<style scoped lang="scss">
.modifyThe {
  background-color: #409eff;
  color: #fff;
  width: 70px;
  height: 34px;
  font-size: 14px;
  padding: 10px;
}
.main {
  box-sizing: border-box;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 0 $top $top;
    height: calc(100vh - 219px);
    overflow: auto;
    width: 100%;
    box-sizing: border-box;
    table {
      width: 98%;
      margin: 20px auto;
      border-collapse: collapse;
      color: #333;
      font-size: 14px;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      table-layout: auto;
      th {
        text-align: left;
        background-color: rgba(242, 242, 242, 1);
      }
      td {
        height: 40px;
        line-height: 40px;
        border: 1px solid #e0e0e0;
        width: 100px;
        text-align: center;
        .avatar {
          width: 100px;
          height: 125px;
        }
      }
      .imgBox {
        text-align: center;
      }
      .listcss {
        background: #f2f2f2;
        width: 150px;
        text-align: center;
      }
    }
  }
}
</style>
