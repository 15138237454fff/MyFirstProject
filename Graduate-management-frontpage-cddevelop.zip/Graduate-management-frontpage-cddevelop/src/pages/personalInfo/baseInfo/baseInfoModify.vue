<template>
  <div>
    <!-- 个人基本信息 baseInfo -->
    <div class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/personalInfo/baseInfo' }"
              >个人信息管理</el-breadcrumb-item
            >
            <el-breadcrumb-item>个人基本信息</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right">
          <el-button @click="baseinfosave" class="modifyThe">保存</el-button>
        </div>
      </my-breadcrumb>
      <div class="box personal">
        <div class="personsafe" v-loading="loading">
          <table>
            <tr>
              <td
                class="listcss"
                colspan="6"
                style="text-align:left;font-weight:bold"
              >
                | 基本信息
              </td>
              <td rowspan="4" class="imgBox">
                <img
                  :src="resetForm.zp"
                  alt
                  style="width:100px;height:100px;display: inline;"
                />
              </td>
            </tr>
            <tr>
              <td class="listcss">学号</td>
              <td>{{ form.xh }}</td>
              <td class="listcss">姓名</td>
              <td>{{ form.xsxm }}</td>
              <td class="listcss">姓名拼音</td>
              <td>{{ resetForm.xmpy }}</td>
            </tr>
            <tr>
              <td class="listcss">性别</td>
              <td>{{ resetForm.xbm | xbm }}</td>
              <td class="listcss">民族</td>
              <td>{{ resetForm.mzmc }}</td>
              <td class="listcss">出生日期</td>
              <td>{{ resetForm.csrq }}</td>
            </tr>
            <tr>
              <td class="listcss"><span class="required"></span>婚姻状况</td>
              <td v-if="changezt.marray === 1">
                <el-select
                  v-model="resetForm.hyzkm"
                  placeholder="请选择"
                  align="center"
                  style="width:100%;text-align: center;"
                >
                  <el-option
                    v-for="(item, index) in hyzk"
                    :key="index"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td v-else>{{ resetForm.hyzkmc }}</td>
              <td class="listcss">政治面貌</td>
              <td>{{ resetForm.zzmmmc }}</td>
              <td class="listcss"><span class="required"></span>健康状况</td>
              <td v-if="changezt.jkzk === 1">
                <el-select
                  v-model="resetForm.jkzkm"
                  placeholder="请选择"
                  align="center"
                  style="width:100%;text-align: center;"
                >
                  <el-option
                    v-for="item in dropDown.jkzk"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  ></el-option>
                </el-select>
              </td>
              <td v-else>{{ resetForm.jkzkmc }}</td>
            </tr>
            <tr>
              <td class="listcss">国籍</td>
              <td>{{ resetForm.gjmc }}</td>
              <td class="listcss">证件类型</td>
              <td>{{ resetForm.sfzjlxmc }}</td>
              <td class="listcss">证件号码</td>
              <td colspan="2">{{ resetForm.sfzh }}</td>
            </tr>
            <tr>
              <td class="listcss">籍贯</td>
              <td>{{ resetForm.jgmc }}</td>
              <td class="listcss">出生地</td>
              <td>{{ resetForm.csdmc }}</td>
              <td class="listcss"><span class="required"></span>户口所在地</td>
              <td colspan="2" v-if="changezt.hkszd === 1">
                <el-cascader
                  :options="nativeList"
                  clearable
                  v-model="hkszd"
                  style="width:100%"
                  filterable
                ></el-cascader>
              </td>
              <td colspan="2" v-else>{{ resetForm.hkszdmc }}</td>
            </tr>
            <tr>
              <td class="listcss">
                <span class="required"></span>户口详细地址
              </td>
              <td colspan="6" v-if="changezt.xxdz === 1">
                <el-input v-model="resetForm.hkxxdz"></el-input>
              </td>
              <td colspan="6" v-else>{{ resetForm.hkxxdz }}</td>
            </tr>
            <tr>
              <td class="listcss"><span class="required"></span>移动电话</td>
              <td v-if="changezt.yddh === 1">
                <el-input v-model="resetForm.yddh"></el-input>
              </td>
              <td v-else>{{ resetForm.yddh }}</td>
              <td class="listcss">固定电话</td>
              <td v-if="changezt.gddh === 1">
                <el-input v-model="resetForm.dh"></el-input>
              </td>
              <td v-else>{{ resetForm.dh }}</td>
              <td class="listcss"><span class="required"></span>电子邮箱</td>
              <td colspan="2" v-if="changezt.email === 1">
                <el-input v-model="resetForm.dzxx"></el-input>
              </td>
              <td colspan="2" v-else>{{ resetForm.dzxx }}</td>
            </tr>
            <tr>
              <td class="listcss"><span class="required"></span>邮政编码</td>
              <td v-if="changezt.mycode === 1">
                <el-input v-model="resetForm.yzbm" else></el-input>
              </td>
              <td v-else>{{ resetForm.yzbm }}</td>
              <td class="listcss">通讯地址</td>
              <td colspan="4" v-if="changezt.mailingAddress === 1">
                <el-input v-model="resetForm.txdz"></el-input>
              </td>
              <td colspan="4" v-else>{{ resetForm.txdz }}</td>
            </tr>
          </table>

          <table>
            <tr>
              <td
                class="listcss"
                colspan="8"
                style="text-align:left;font-weight:bold"
              >
                | 学籍信息
              </td>
            </tr>
            <tr>
              <td class="listcss">学生类别</td>
              <td>{{ form.xslbmc }}</td>
              <td class="listcss">学习方式</td>
              <td>{{ form.xxfsmc }}</td>
              <td class="listcss">培养层次</td>
              <td colspan="4">{{ form.pyccmc }}</td>
            </tr>
            <tr>
              <td class="listcss">入学年月</td>
              <td>{{ form.rxny }}</td>
              <td class="listcss">年级</td>
              <td>{{ form.sznj }}</td>
              <td class="listcss">学制</td>
              <td colspan="4">{{ form.xz }}</td>
            </tr>
            <tr>
              <td class="listcss">所属学院</td>
              <td>{{ form.ssyxmc }}</td>
              <td class="listcss">所属专业</td>
              <td>{{ form.zy }}</td>
              <td class="listcss">研究方向</td>
              <td colspan="4">{{ form.yjfx }}</td>
            </tr>
            <tr>
              <td class="listcss">班级</td>
              <td>{{ form.bjmc }}</td>
              <td class="listcss">导师</td>
              <td>{{ form.dsxm }}</td>
              <td class="listcss">当前状态</td>
              <td>{{ form.xsdqztmc }}</td>
            </tr>
            <tr>
              <td class="listcss" :class="{ required: changezt.sfkxk === 1 }">
                是否跨学科
              </td>
              <td colspan="5">
                <el-radio-group v-model="form.sfkk" v-if="changezt.sfkxk === 1">
                  <el-radio label="1">是</el-radio>
                  <el-radio label="0">否</el-radio>
                </el-radio-group>
                <span v-else>{{
                  form.sfkk == 0 ? "否" : form.sfkk == 1 ? "是" : ""
                }}</span>
              </td>
            </tr>
          </table>

          <table>
            <tr>
              <td
                class="listcss"
                colspan="9"
                style="text-align:left;font-weight:bold"
              >
                | 其他信息
              </td>
            </tr>
            <tr>
              <td class="listcss">
                何时何地何原因
                <br />受过何种奖励或处分
              </td>
              <td colspan="8" v-if="changezt.jlcf === 1">
                <el-input
                  type="textarea"
                  :autosize="{ minRows: 2, maxRows: 4 }"
                  placeholder="请输入内容"
                  v-model="resetForm.jcnr"
                ></el-input>
              </td>
              <td colspan="8" v-else>{{ resetForm.jcnr }}</td>
            </tr>
            <tr>
              <td class="listcss" :rowspan="resetForm.qtList.length + 1">
                学习和工作经历
              </td>
              <td class="listcss" colspan="2">起止时间</td>
              <td class="listcss" colspan="3">学习或工作单位</td>
              <td class="listcss" colspan="2">职务</td>
              <td class="listcss"></td>
            </tr>
            <template v-if="changezt.xxgzjl == 1">
              <tr v-for="(item, index) in resetForm.qtList" :key="index">
                <td colspan="2">
                  <div class="block">
                    <span class="demonstration"></span>
                    <el-date-picker
                      v-model="item.sj"
                      type="daterange"
                      placeholder="选择日期"
                      :picker-options="pickerOptionsStart"
                      @change="startTimeStatus($event, index)"
                    ></el-date-picker>
                  </div>
                </td>
                <td colspan="3">
                  <el-input v-model="item.gzdw"></el-input>
                </td>
                <td colspan="2">
                  <el-input v-model="item.zw"></el-input>
                </td>
                <td colspan="2">
                  <i
                    class="el-icon-circle-plus"
                    style="color:#409eff"
                    @click="studyadd(item, index)"
                    v-if="index == resetForm.qtList.length - 1"
                  ></i>
                  <i
                    class="el-icon-remove"
                    style="color:#f56c6c"
                    v-else
                    @click="studydelet(item, index)"
                  ></i>
                </td>
              </tr>
            </template>
            <template v-else>
              <tr v-for="(item, index) in resetForm.qtList" :key="index">
                <td colspan="2">
                  {{ item.kssj | kssj }} 至 {{ item.jssj | jssj }}
                </td>
                <td colspan="2">{{ item.gzdw }}</td>
                <td colspan="2">{{ item.zw }}</td>
              </tr>
            </template>
            <tr>
              <td class="listcss" :rowspan="resetForm.jtcy.length + 1">
                家庭主要成员
              </td>
              <td class="listcss">姓名</td>
              <td class="listcss">关系</td>
              <td class="listcss" colspan="3">工作单位</td>
              <td class="listcss">职务</td>
              <td class="listcss">联系方式</td>
              <td class="listcss"></td>
            </tr>
            <template
              v-for="(item, index) in resetForm.jtcy"
              v-if="changezt.infor === 1"
            >
              <tr>
                <td>
                  <el-input v-model="item.cyxm"></el-input>
                </td>
                <td>
                  <el-select v-model="item.gxm" placeholder="请选择">
                    <el-option
                      v-for="(item, index) in jtgxlist"
                      :value="item.value"
                      :label="item.label"
                      :key="index"
                    />
                  </el-select>
                </td>
                <td colspan="3">
                  <el-input v-model="item.gzdw"></el-input>
                </td>
                <td>
                  <el-select v-model="item.zy" placeholder="请选择">
                    <el-option
                      v-for="(item, index) in zw"
                      :value="item.value"
                      :label="item.label"
                      :key="index"
                    />
                  </el-select>
                </td>
                <td>
                  <el-input v-model="item.lxfs"></el-input>
                </td>
                <td>
                  <i
                    class="el-icon-circle-plus"
                    style="color:#409eff"
                    @click="homeadd(item, index)"
                    v-if="index === resetForm.jtcy.length - 1"
                  ></i>
                  <i
                    class="el-icon-remove"
                    style="color:#f56c6c"
                    v-if="index != resetForm.jtcy.length - 1"
                    @click="homedelet(item, index)"
                  ></i>
                </td>
              </tr>
            </template>
            <template v-for="(item, index) in resetForm.jtcy" v-else>
              <tr :key="index">
                <td>{{ item.cyxm }}</td>
                <!-- 过滤器的高级用法，可以指定参数，来告诉过滤器按照参数进行数据的过滤 -->
                <td>
                  <span v-if="resetForm.jtcy.length">{{
                    item.gxm | jtgxlist(jtgxlist)
                  }}</span>
                  <span v-else>未知</span>
                </td>
                <td colspan="2">{{ item.gzdw }}</td>
                <td>
                  <span v-if="resetForm.jtcy.length">{{
                    item.zy | zylist(zylist)
                  }}</span>
                  <span v-else>未知</span>
                </td>
                <td colspan="2">{{ item.lxfs }}</td>
              </tr>
            </template>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "baseInfoModify",
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      form: {
        jttx: {},
        xxgzjl: []
      },
      resetForm: {
        qtList: [],
        jtcy: [],
        hkszd: []
      },
      jtgxlist: [],
      jzgzt: [],
      nativeList: [],
      zw: [],
      zylist: [],
      dropDown: [],
      gzjlsj: "",
      changezt: {},
      hyzk: [],
      hkszd: [],
      loading: true,
      //开始时间设置
      pickerOptionsStart: {
        disabledDate: time => {
          let endDateVal = this.resetForm.qtList.jssj;
          if (endDateVal) {
            return time.getTime() > new Date(endDateVal).getTime();
          }
        }
      },
      //结束时间设置
      pickerOptionsEnd: {
        disabledDate: time => {
          let beginDateVal = this.resetForm.qtList.kssj;
          if (beginDateVal) {
            return (
              time.getTime() <
              new Date(beginDateVal).getTime() - 1 * 24 * 60 * 60 * 1000
            );
          }
        }
      },
      //将所有的家庭成员信息放在一个变量中
      cyxx: {
        cyxm: "",
        gxm: "",
        gzdw: "",
        zy: "",
        lxfs: ""
      },
      //将所有更改的工作经历的信息放在一个变量中
      jlxx: {
        kssj: "",
        jssj: "",
        sj: "",
        gxm: "",
        zw: ""
      }
    };
  },
  filters: {
    xbm(val) {
      switch (val) {
        case "1":
          return "男";
          break;
        case "2":
          return "女";
          break;
        default:
          break;
      }
    },
    kssj(val) {
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jssj(val) {
      var date = new Date(val);
      return (
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      );
    },
    jtgxlist(val, index) {
      //过滤家庭关系中的每一项，若存在则返回它的label值，若不存在则返回空值
      const valindex = index.find((el, index) => el.value === val);
      if (valindex) {
        return valindex.label;
      } else {
        return "";
      }
    },
    zylist(val, index) {
      //过滤职务码的每一项，若存在则返回它的label值，若不存在则返回空值
      const valindex = index.find((el, index) => el.value === val);
      if (valindex) {
        return valindex.label;
      } else {
        return "";
      }
    }
  },
  methods: {
    // 时间开始选择器
    startTimeStatus(val, ine) {
      if (val != null) {
        this.resetForm.qtList[ine].kssj = val[0];
        this.resetForm.qtList[ine].jssj = val[1];
      } else {
        this.resetForm.qtList[ine].kssj = "";
        this.resetForm.qtList[ine].jssj = "";
      }

      console.log(this.resetForm.qtList[ine], ine, val, "00000000000");
    },
    // 时间结束选择器
    endTimeStatus(val, ine) {
      if (val != null) {
        this.resetForm.qtList[ine].kssj = val[0];
        this.resetForm.qtList[ine].jssj = val[1];
      } else {
        this.resetForm.qtList[ine].kssj = "";
        this.resetForm.qtList[ine].jssj = "";
      }
      // this.resetForm.qtList.jssj = value;
    },
    //ES6为Array增加了find()，findIndex函数。他们都是查找一个回调函数 查找函数有三个参数 value：每一次迭代查找的数组元素 index：每一次迭代查找的数组元素索引  arr:被查找的数组
    //find()函数用来查找目标元素，找到就返回该元素，找不到返回undefined。  findIndex()函数也是查找目标元素，找到就返回元素的位置，找不到就返回-1。
    // 增加学习和工作经历
    studyadd(val, index) {
      const obj = {
        kssj: "",
        jssj: "",
        gzdw: "",
        zw: "",
        xh: this.xh
      };
      this.resetForm.qtList.push(obj);
    },
    // 删除学习和工作经历
    studydelet(val, index) {
      this.resetForm.qtList.splice(
        this.resetForm.qtList.findIndex(item => item === val),
        1
      );
    },
    //增加家庭主要成员
    homeadd(val, index) {
      const obb = {
        cyxm: "",
        gxm: "",
        lxfs: "",
        gzdw: "",
        zy: ""
      };
      this.resetForm.jtcy.push(obb);
    },
    //删除家庭主要成员
    homedelet(val, index) {
      // console.log(val,index,'看删除的');
      this.resetForm.jtcy.splice(
        this.resetForm.jtcy.findIndex(item => item === val),
        1
      );
    },
    takeList() {
      this.$http.get("/api/system/dict/select/origoLevelThree").then(res => {
        this.nativeList = res.data.data;
        // console.log(this.nativeList,'所有户籍')
      });
      this.$http.get("/api/cultivate/stu/xjsj/" + this.xh).then(res => {
        if (!res.data.data) {
          this.$message.warning({
            message: "数据为空"
          });
        } else {
          this.form = res.data.data;
        }
      });
      this.$http.get("/api/cultivate/stu/jbxx/" + this.xh)
        .then(res => {
          this.loading = false;
          if (!res.data.data) {
            this.$message.warning({
              message: "数据为空"
            });
          } else {
            let data = res.data.data;
            data.qtList.forEach(el => {
              el.sj = [el.kssj, el.jssj];
            });
            if (data.qtList.length === 0) {
              var obj = {
                kssj: "",
                jssj: "",
                gzdw: "",
                zw: "",
                xh: this.xh
              };
              data.qtList.push(obj);
            }
            if (data.jtcy.length === 0) {
              var obj = {
                cyxm: "",
                gxm: "",
                lxfs: "",
                gzdw: "",
                zy: ""
              };
              data.jtcy.push(obj);
            }
            this.resetForm = data;
            this.resetForm.hkszd = this.resetForm.hkszd == null ? '' : null
            this.resetForm.hkszd = this.resetForm.hkszd.split(",");
            let hkszd = [];
            var hk =
              this.resetForm.hkszd.length == 1
                ? this.resetForm.hkszd.toString()
                : this.resetForm.hkszd[
                    this.resetForm.hkszd.length - 1
                  ].toString();
            this.nativeList.map(v => {
              v.children.map(el => {
                el.children.map(element => {
                  if (element.value === hk) {
                    this.hkszd = [v.value, el.value, element.value];
                  }
                });
              });
            });
            this.$http.get("/api/system/dict/select/all").then(res => {
              this.dropDown = res.data.data;
              this.jtgxlist = res.data.data.jtgx;
              // 关系
              this.zw = res.data.data.zw;
              //职业码
              this.zylist = res.data.data.zw;
              this.jzgzt = res.data.data.xszt;
              this.hyzk = res.data.data.hyzk;
              console.log('============',this.hyzk)
              // 政治面貌
              this.resetForm.zzmmm = res.data.data.zzmm.find(
                (el, index) => el.value === this.resetForm.zzmmm
              ).label;
              this.resetForm.sfzjlxm = res.data.data.zjlx.find(
                (el, index) => el.value === this.resetForm.sfzjlxm
              ).label;
              console.log(this.resetForm.qtList);
            });
          }
        })
        .catch(err => {
          this.loading = false;
          this.$message.error(err.data.message);
        });
    },
    baseinfosave() {
      if (this.resetForm.hyzkm == "" || this.resetForm.hyzkm == null) {
        this.$message.warning("请选择婚姻状况！");
        return false;
      }
      if (this.resetForm.jkzkm == "" || this.resetForm.jkzkm == null) {
        this.$message.warning("请选择健康状况！");
        return false;
      }
      if (this.hkszd == "" || this.hkszd == null) {
        this.$message.warning("请选择户口所在地！");
        return false;
      }
      if (this.resetForm.hkxxdz == "" || this.resetForm.hkxxdz == null) {
        this.$message.warning("请输入户口详细地址！");
        return false;
      }
      //保存前先验证必填项，若格式不正确则无法保存成功。需重新填写
      // var homereg = /^((0\d{2,3}-\d{7,8})|(1[3584]\d{9}))$/;//移动电话的正则表达式,家庭电话的正确格式
      var gdreg1 = /^1[3456789]\d{9}$/; //固定电话格式的第一种情况
      var gdreg2 = /^((0\d{2,3}-\d{7,8})|(1[3456789]\d{9}))$/; //固定电话格式的第二种情况
      var pattern = /[0-9][0-9]{5}/; //邮政编码的正则表达式
      var eamilreg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/; //电子信箱的邮政编码
      if (this.changezt.yddh === 1) {
        if (this.resetForm.yddh == "") {
          this.$message.warning("移动电话不能为空！");
          return false;
        } else if (!gdreg1.test(this.resetForm.yddh)) {
          this.$message.warning("移动电话格式不正确！");
          return false;
        }
      }
      if (this.changezt.email === 1) {
        if (this.resetForm.dzxx == "") {
          this.$message.warning("电子邮箱不能为空！");
          return false;
        } else if (!eamilreg.test(this.resetForm.dzxx)) {
          this.$message.warning("电子邮箱格式不正确！");
          return false;
        }
      }
      if (this.changezt.mycode === 1) {
        if (this.resetForm.yzbm == "") {
          this.$message.warning("邮政编码不能为空！");
          return false;
        } else if (!pattern.test(this.resetForm.yzbm)) {
          this.$message.warning("邮政编码格式不正确！");
          c;
        }
      }
      if (this.changezt.sfkxk === 1) {
        if (this.form.sfkk === undefined) {
          this.$message.warning("是否跨科不能为空！")
          return
        }
      }
      //循环家庭信息中的每一项，再复制给家庭成员的变量中，方便判断。
      this.resetForm.qtList.forEach(el => {
        this.jlxx.kssj = el.kssj;
        this.jlxx.jssj = el.jssj;
        this.jlxx.sj = el.sj;
        this.jlxx.gxm = el.gzdw;
        this.jlxx.zw = el.zw;
      });
      //先判断状态值是否可修改，如果可以修改则去验证，不可修改则不验证  根据变量的赋值去做判断  循环要写在外面 否则判断只在循环中生效
      if (this.changezt.xxgzjl === 1) {
        if (this.jlxx.kssj == undefined || this.jlxx.jssj == undefined) {
          this.$message.warning("请选择时间");
          return;
        }
        if (this.jlxx.gxm == "" && this.jlxx.zw == "") {
          this.$message.warning("请添加关系名和职务");
          return;
        }
        if (this.jlxx.gxm == "" && this.jlxx.zw !== "") {
          this.$message.warning("请添加关系名");
          return false;
        }
        if (this.jlxx.gxm !== "" && this.jlxx.zw == "") {
          this.$message.warning("请添加职务");
          return false;
        }
      }
      this.resetForm.jtcy.forEach(el => {
        this.cyxx.cyxm = el.cyxm;
        this.cyxx.gxm = el.gxm;
        this.cyxx.gzdw = el.gzdw;
        this.cyxx.zy = el.zy;
        this.cyxx.lxfs = el.lxfs;
      });
      //先判断状态值是否可修改，如果可以修改则去验证，不可修改则不验证  根据变量的赋值去做判断  循环要写在外面 否则判断只在循环中生效
      if (this.changezt.infor === 1) {
        if (this.cyxx.cyxm == "") {
          this.$message.warning("请添加家庭成员姓名");
          return false;
        }
        if (this.cyxx.gxm == "") {
          this.$message.warning("请添加家庭成员关系");
          return false;
        }
        if (this.cyxx.gzdw == "") {
          this.$message.warning("请添加家庭成员工作单位");
          return false;
        }
        if (this.cyxx.zy == "") {
          this.$message.warning("请添加家庭成员职务");
          return false;
        }
        if (this.cyxx.lxfs == "") {
          this.$message.warning("请添加家庭成员联系方式");
          return false;
        }
      }
      if (this.form.xsdqztm) {
        //过滤学生的当前状态
        this.resetForm.xsdqztmc = this.jzgzt.find(
          //（el,index)在每一行拿到对应的index值     箭头函数的用法当只有一个参数时，圆括号是可选的：(单一参数) => {函数声明}  单一参数 => {函数声明}  没有参数的函数应该写成一对圆括号
          (el, index) => el.value === this.form.xsdqztm
        ).label;
      }
      const formSubmit = {
        //点击保存时将需要传递给后台的数据保存在一个大的对象中
        studentBasicDTO: {
          // 固定电话
          dh: this.resetForm.dh,
          // 电子信箱
          dzxx: this.resetForm.dzxx,
          // 户口所在地   toString把数字转化为字符串
          hkszd: this.hkszd[this.hkszd.length - 1].toString(),
          // 户口详细地址
          hkxxdz: this.resetForm.hkxxdz,
          // 婚姻状况码
          hyzkm: this.resetForm.hyzkm,
          // 奖惩内容
          jcnr: this.resetForm.jcnr,
          // 健康状况码
          jkzkm: this.resetForm.jkzkm,
          // hkszdmc: hkszd,//户口所在地的具体名称
          sfkk: this.form.sfkk,
          // 通信地址
          txdz: this.resetForm.txdz,
          // 学号
          xh: this.form.xh,
          // 学生当前状态码
          xsdqztm: this.form.xsdqztm,
          // 学籍表中的学生当前状态名称
          xsdqztmc: this.resetForm.xsdqztmc,
          // 移动电话
          yddh: this.resetForm.yddh,
          // 邮政编码
          yzbm: this.resetForm.yzbm
        },
        jtcy: this.resetForm.jtcy,
        qtList: this.resetForm.qtList,
        type: 2
      };
      // formSubmit即为需要传递给后台的数据
      this.$http.put("/api/cultivate/stu", formSubmit).then(res => {
        this.$message({
          message: res.data.message,
          type: res.data.code == 200 ? "success" : "warning" //用三目运算符去做判断，正确时提示保存成功，错误时提示错误的消息
        });
        if (res.data.code == 200) {
          this.$router.push("/personalInfo/baseInfo"); //当保存成功时跳转至详情展示的页面
        } else {
        }
      });
    },
    // 加载数据字典
    loadDict() {
      this.$http.get("/api/system/dict/select/all").then(res => {
        this.dict = res.data.data;
      });
    }
  },
  created() {
    //根据后台返回的参数判断是否为可修改字段，0为只读状态，1为可修改状态
    this.$http.get("/api/cultivate/pycssz").then(res => {
      this.changezt = res.data.data.main;
      console.log(this.changezt, "个人基本信息状态值");
    });
  },
  mounted() {
    this.takeList();
    this.loadDict();
  },
  computed: {
    xh() {
      return this.$store.getters.getXH;
    }
  }
};
</script>

<style scoped lang="scss">
.modifyThe {
  background-color: #409eff;
  color: #fff;
  width: 70px;
  height: 34px;
  font-size: 14px;
  padding: 10px;
}
.main {
  box-sizing: border-box;
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: 0 $top $top;
    height: calc(100vh - 219px);
    overflow: auto;
    width: 100%;
    box-sizing: border-box;
    table {
      width: 98%;
      // margin-top: 30px;
      margin: 20px auto;
      border-collapse: collapse;
      color: #333;
      font-size: 14px;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      table-layout: auto;
      th {
        text-align: left;
        background-color: rgba(242, 242, 242, 1);
      }
      td {
        height: 40px;
        // line-height: 40px;
        border: 1px solid #e0e0e0;
        min-width: 100px;
        text-align: left;
        .avatar {
          width: 100px;
          height: 125px;
        }
        img {
          width: 25px;
          height: 25px;
          // position: relative;
          // top: 8px;
        }
        .el-icon-circle-plus,
        .el-icon-remove {
          font-size: 20px;
        }
        //   &:nth-child(odd) {
        //     background: #f2f2f2;
        //   }
      }
      .imgBox {
        text-align: center;
      }
      .listcss {
        background: #f2f2f2;
        width: 150px;
        text-align: center;
      }
    }
    /deep/.el-input .el-input__inner {
      padding: 0 4px;
    }
  }
}
</style>
