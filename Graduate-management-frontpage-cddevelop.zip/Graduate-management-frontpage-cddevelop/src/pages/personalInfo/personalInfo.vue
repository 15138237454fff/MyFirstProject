<template>
    <div>
        <!-- 个人基本信息 personalInfo -->
        <main>
            <section class="left box">
                <h4 class="title">个人基本信息</h4>
                <el-divider></el-divider>
                <div class="center">
                    <div>
                        <img src="../../assets/images/avator.png" alt="">
                        <h4>学生姓名</h4>
                        <span>学号：1234567</span>
                    </div>
                </div>
                <el-divider></el-divider>
                <div class="bottom">
                    <table border="1" cellspacing="0" cellpadding="10">
                        <tr>
                            <td>姓名</td>
                            <td>111</td>
                            <td>性别</td>
                            <td>111</td>
                        </tr>
                        <tr>
                            <td>出生日期</td>
                            <td>111</td>
                            <td>电话号码</td>
                            <td>111</td>
                        </tr>
                        <tr>
                            <td>所属学院</td>
                            <td>111</td>
                            <td>所属专业</td>
                            <td>111</td>
                        </tr>
                        <tr>
                            <td>年级</td>
                            <td>111</td>
                            <td>班级</td>
                            <td>111</td>
                        </tr>
                        <tr>
                            <td>培养层次</td>
                            <td>111</td>
                            <td>导师</td>
                            <td>111</td>
                        </tr>
                        <tr>
                            <td>学生类别</td>
                            <td>111</td>
                            <td>当前状态</td>
                            <td>111</td>
                        </tr>
                    </table>
                </div>
            </section>
            <section class="right">
                <div class="list box" @click="toDetail('个人信息管理')">
                    <div class="flex-left">
                        <img src="../../assets/images/email.png" alt="">
                    </div>
                    <h4 class="flex-center">个人基本信息</h4>
                    <div class="flex-right">
                        <el-divider direction="vertical"></el-divider>
                        <el-button type="text">点击进入</el-button>
                    </div>
                </div>
                <div class="list box" @click="toDetail('学籍异动申请')">
                    <div class="flex-left">
                        <img src="../../assets/images/email.png" alt="">
                    </div>
                    <h4 class="flex-center">学籍异动申请</h4>
                    <div class="flex-right">
                        <el-divider direction="vertical"></el-divider>
                        <el-button type="text">点击进入</el-button>
                    </div>
                </div>
                <div class="list box" @click="toDetail('硕博连读申请')">
                    <div class="flex-left">
                        <img src="../../assets/images/email.png" alt="">
                    </div>
                    <h4 class="flex-center">硕博连读申请</h4>
                    <div class="flex-right">
                        <el-divider direction="vertical"></el-divider>
                        <el-button type="text">点击进入</el-button>
                    </div>
                </div>
                <div class="list box" @click="toDetail('更换导师申请')">
                    <div class="flex-left">
                        <img src="../../assets/images/email.png" alt="">
                    </div>
                    <h4 class="flex-center">更换导师申请</h4>
                    <div class="flex-right">
                        <el-divider direction="vertical"></el-divider>
                        <el-button type="text">点击进入</el-button>
                    </div>
                </div>
                <div class="list box" @click="toDetail('研究生证补办')">
                    <div class="flex-left">
                        <img src="../../assets/images/email.png" alt="">
                    </div>
                    <h4 class="flex-center">研究生证补办</h4>
                    <div class="flex-right">
                        <el-divider direction="vertical"></el-divider>
                        <el-button type="text">点击进入</el-button>
                    </div>
                </div>
                <!-- <div class="list box" @click="toDetail('网上自助注册')">
                    <div class="flex-left">
                        <img src="../../assets/images/email.png" alt="">
                    </div>
                    <h4 class="flex-center">网上自助注册</h4>
                    <div class="flex-right">
                        <el-divider direction="vertical"></el-divider>
                        <el-button type="text">点击进入</el-button>
                    </div>
                </div> -->
            </section>
        </main>
    </div>
</template>

<script>
export default {
  name: 'personalInfo',
  data () {
    return {

    }
  },
  methods: {
    // 点击进入
    toDetail (t) {
      switch (t) {
        case '个人信息管理':
          this.$router.push({
            name: 'baseInfo'
          })
          break
        case '学籍异动申请':
          this.$router.push({
            path: 'personalInfo/stuChange/1'
          })
          break
        case '硕博连读申请':
          this.$router.push({
            path: 'personalInfo/suoboApply/1'
          })
          break
        case '更换导师申请':
          this.$router.push({
            path: 'personalInfo/changeTutor/1'
          })
          break
        case '研究生证补办':
          this.$router.push({
            path: 'personalInfo/cardReapply/1'
          })
          break
                // case '网上自助注册':
                //     this.$router.push({
                //         name: 'onlineRegister'
                //     })
                // break;
      }
    }
  }
}
</script>

<style lang="scss" scoped>
    main {
        display: flex;
        margin-top: 30px;
        margin-bottom: 30px;
        // box-sizing: border-box;
        .box {
            box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
            // margin: 20px;
        }
        .left {
            flex: 1;
            // height: 300px;
            margin: 10px 30px;
            .title {
                margin: 20px;
                height: 41px;
                line-height: 41px;
                box-sizing: border-box;
            }
            .el-divider--horizontal {
                margin: 15px 0;
            }
            .center {
                height: 206px;
                box-sizing: border-box;
                div {
                    transform: translateY(33%);
                }
                h4 {
                    margin: 10px;
                }
                text-align: center;
                span {
                    color: #666;
                }
            }
            .bottom {
                padding: 10px;
                padding-bottom: 25px;
                padding-left: 20px;
                padding-right: 20px;
                color: #333;
                ul {
                    list-style: none;
                    color: #666;
                    li {
                        margin: 10px 0;
                    }
                }
                table {
                    width: 100%;
                    margin: auto;
                    border: none;
                    border-collapse: collapse;
                    td {
                        width: 50px;
                        font-size: 14px;
                    }
                }
            }
        }
        .right {
            flex: 1.6;
            margin: 10px 30px 10px 0;
            .list {
                height: 100px;
                margin-bottom: 34px;
                display: flex;
                cursor: pointer;
                &:last-child {
                    margin-bottom: 0;
                }
                .flex-left {
                    // flex: 1;
                    img {
                        width: 50px;
                        height: 48px;
                        margin: 26px 20px;
                        // flex:1;
                    }
                }
                .flex-center {
                    line-height: 50px;
                    flex: 5;
                }
                .flex-right {
                    font-size: 14px;
                    line-height: 100px;
                    flex: 1.5;
                    .el-button {
                        padding: 0;
                    }
                    .el-divider--vertical {
                        margin: 30px;
                    }
                }
            }
        }
    }
</style>
