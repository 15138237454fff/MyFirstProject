<template>
  <div>
    <!-- 硕博连读申请 suoboApply -->
    <div class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/personalInfo/baseInfo' }">个人信息管理</el-breadcrumb-item>
            <el-breadcrumb-item :to="{ path: '/personalInfo/suoboApply/1' }">硕博连读申请</el-breadcrumb-item>
            <el-breadcrumb-item
              :to="{ path: '/personalInfo/suoboApply/2'}"
              v-if="this.$route.params.id == 2 || this.$route.params.id == 3 || this.$route.params.id == 4"
            >申请记录</el-breadcrumb-item>
            <el-breadcrumb-item v-if="this.$route.params.id == 3">查看详情</el-breadcrumb-item>
            <el-breadcrumb-item v-if="this.$route.params.id == 4">修改</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right">
          <div v-show="applyShow">
            <i class="el-icon-document"></i>
            <el-button type="text" @click="seeRecord">
              <el-badge class="item">查看申请记录</el-badge>
            </el-button>
          </div>
          <div v-show="!applyShow">
            <i class="el-icon-d-arrow-left"></i>
            <el-button type="text" @click="handleBack">返回</el-button>
          </div>
        </div>
      </my-breadcrumb>
      <div class="box">
        <apply v-if="$route.params.id == 1" :userInfo="userInfo" :status="$route.query.sqzt"></apply>
        <apply-save
          v-else-if="$route.params.id == 3 || $route.params.id == 4"
          :userInfo="userInfo"
          :status="$route.query.sqzt"
        ></apply-save>
        <apply-record v-else-if="$route.params.id == 2" @listen="listen" @listen1="listen1"></apply-record>
        <apply-status-bottom v-show="this.$route.params.id == 3 || this.$route.params.id == 4"></apply-status-bottom>
      </div>
    </div>
  </div>
</template>

<script>
import apply from './components/apply'
import applySave from './components/applySave'
import applyRecord from './components/applyRecord'
import applyStatusBottom from '../../../components/applyStatusBottom'
import myBreadcrumb from '@/components/myBreadcrumb'
export default {
  name: 'suoboApply',
  components: {
    apply,
    applySave,
    applyRecord,
    applyStatusBottom,
    'my-breadcrumb': myBreadcrumb
  },
  data () {
    return {
      applyShow: true, // 申请显示
      seeShow: false, // 修改，查看详情
      tableShow: false, // 申请列表显示
      userInfo: {},
      shzt: '', // 审核状态：查看时
      shzt1: '' // 审核状态：修改时
    }
  },
  watch: {
    $route () {
      // console.log(this.$route.params.id);
      this.getId()
    }
  },
  created () {
    this.getId()
  },
  mounted () {
    if (this.$route.params.id == 1) this.getData()
  },
  methods: {
    // 初始化数据
    getData () {
      this.$http.get('/api/frontpage/sbldsq/sbldsqInit').then(res => {
        this.userInfo = res.data.data
      })
    },
    // 父组件接收子组件传过来的shzt
    listen (data) {
      // console.log("data:", data);
      this.shzt = data
    },
    listen1 (data) {
      this.shzt1 = data
    },
    // 查看申请记录
    seeRecord () {
      sessionStorage.setItem('sqjl4',false)
      sessionStorage.removeItem('pageNum4')
      this.applyShow = false
      this.$router.push({
        path: '/personalInfo/suoboApply/2'
      })
    },
    // 新建申请(返回)
    handleBack () {
      sessionStorage.setItem('sqjl4',true)
      this.applyShow = true
      this.$router.go(-1)
    },
    getId () {
      let id = this.$route.params.id
      // 1:申请表
      // 2:查看申请列表
      // 3:点击查看
      // 4:点击修改
      if (id == 1) {
        this.applyShow = true
        this.tableShow = false
        this.seeShow = false
      }
      if (id == 2) {
        this.applyShow = false
        this.tableShow = true
        this.seeShow = false
      }
      if (id == 3) {
        this.applyShow = false
        this.tableShow = false
        this.seeShow = true
      }
      if (id == 4) {
        this.applyShow = false
        this.tableShow = false
        this.seeShow = true
      }
    }
  },
  computed: {
    xh () {
      return this.$store.getters.getXH
    }
  }
}
</script>

<style lang="scss" scoped>
.main {
  .el-icon-document,
  .el-icon-d-arrow-left {
    margin-right: 5px;
    color: #409eff;
  }
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
  }
  /deep/ .el-textarea {
    width: 90%;
  }
}
</style>
