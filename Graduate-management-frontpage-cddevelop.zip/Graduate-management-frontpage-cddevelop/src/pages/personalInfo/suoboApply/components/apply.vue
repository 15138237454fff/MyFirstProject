<template>
  <div>
    <!-- 基本信息 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">浙江财经大学研究生硕博连读申请表</th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>政治面貌</td>
            <td>{{ userInfo.zzmmmc }}</td>
            <td>联系电话</td>
            <td>{{ userInfo.dh }}</td>
            <td>入学年月</td>
            <td>{{ userInfo.rxny }}</td>
          </tr>
          <tr>
            <td>硕士所在学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>硕士专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>硕士生导师</td>
            <td>{{ userInfo.dsxm }}</td>
          </tr>
          <tr>
            <td class="moralHeight">
              <span style="color:red;margin-left:8px;">*</span>&nbsp;硕博连读学院
            </td>
            <td class="moralHeight">
              <!-- <el-input v-model="pySbld.sbldxy"></el-input> -->
              <el-select
                v-model="pySbld.sbldxy"
                clearable
                placeholder="请选择学院"
                @clear="pySbld.sbldxy = ''"
                style="width:230px"
              >
                <el-option
                  v-for="item in xyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>

            <td class="moralHeight">
              <span style="color:red;margin-left:8px;">*</span>&nbsp;硕博连读专业
            </td>
            <td class="moralHeight">
              <!-- <el-input v-model="pySbld.sbldzy"></el-input> -->
              <el-select
                v-model="pySbld.sbldzy"
                clearable
                placeholder="请选择专业"
                @clear="pySbld.sbldzy = ''"
                style="width:230px"
              >
                <el-option
                  v-for="item in zyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>

            <td class="moralHeight">
              <span style="color:red;margin-left:8px;">*</span>&nbsp;博士生导师
            </td>
            <td class="moralHeight">
              <!-- <el-input v-model="pySbld.bosds"></el-input> -->
              <el-select
                v-model="pySbld.bosds"
                filterable
                clearable
                placeholder="请选择导师"
                @clear="pySbld.bosds = ''"
                style="width:230px"
              >
                <el-option
                  v-for="item in dsOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </td>
          </tr>
          <tr>
            <td class="moralHeight">
              <span style="color:red;margin-left:8px;">*</span>&nbsp;入学前学历<br/>
              &nbsp;&nbsp;(何时何校何专业毕业及学位<br/>&nbsp;&nbsp;授予情况)
            </td>
            <td colspan="5" class="moralHeight">
              <el-input v-model="pySbld.rxqxl" style="padding:0;"></el-input>
            </td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="重点介绍自己本科学习及科研情况，以及对所申请学科专业的认知和本人今后的打算。"
                    v-model="pySbld.sqly"
                  ></el-input>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr>
            <td style="background:none">上传证明材料：</td>
            <td colspan="5">
              <el-upload
                ref="upload"
                class="upload-demo"
                :headers="headers"
                action="/api/system/upload"
                :on-success="handleSuccess"
                :on-remove="handleRemove"
                multiple
                :limit="1"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
              </el-upload>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="bottom">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "apply",
  props: ["userInfo"],
  data() {
    return {
      input: "",
      pySbld: {
        fj: [],
        sqly: "",
        rxqxl: "",
        bosds: "",
        sbldzy: "",
        sbldxy: ""
      },
      dialogVisible: false,
      // 学院可选列表
      xyOptions: [],
      // 专业可选列表
      zyOptions: [],
      // 导师可选列表
      dsOptions: [],
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
    };
  },
  created() {
    this.requireXY();
  },
  methods: {
    // 获取学院可选列表
    requireXY() {
      this.$http.get("/api/cultivate/pygrpyjhb/selectDwList").then(res => {
        // //console.log(res.data.data)
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取学院信息失败，请重试");
          return;
        }
        this.xyOptions = [];
        data.map(item => {
          let obj = {
            value: item.dwh,
            label: item.dwmc
          };
          this.xyOptions.push(obj);
        });
        // this.pySbld.sbldxy = this.xyOptions[0] && this.xyOptions[0].value
      });
    },
    // 根据学院查询专业
    requireZY() {
      // console.log(val)
      if (this.pySbld.sbldxy) {
        this.$http
          .get("/api/cultivate/class/getMajorByCollege", {
            params: {
              dwh: this.pySbld.sbldxy
            }
          })
          .then(res => {
            // console.log(res.data.data)
            let data = res.data.data;
            if (!Array.isArray(data)) {
              this.$message.error("获取专业信息失败，请重试");
              return;
            }
            this.zyOptions = [];
            data.map(item => {
              let obj = {
                value: item.zyh,
                label: item.zymc
              };
              this.zyOptions.push(obj);
            });

            // this.pySbld.sbldzy = this.zyOptions[0] && this.zyOptions[0].value
          });
      }
    },
    // 请求导师列表
    requireDS() {
      this.$http
        .get("/api/frontpage/xjydsq/selectTeaByMajor", {
          params: { zyh: this.pySbld.sbldzy, pyccm: "2" }
        })
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("获取导师信息失败，请重试");
            return;
          }
          this.dsOptions = [];
          data.map(item => {
            let obj = {
              value: item.gh,
              label: item.dsxm
            };
            this.dsOptions.push(obj);
          });
          // this.pySbld.bosds = this.dsOptions[0] && this.dsOptions[0].value;
        });
    },
    // 提交申请
    handleSubmit() {
      // console.log(this.pySbld);
      this.dialogVisible = false;
      if (this.pySbld.sbldxy == ' ' || this.pySbld.sbldxy == null) {
        this.$message.warning("请选择学院");
        return false;
      }
      if (this.pySbld.sbldzy == ' ' || this.pySbld.sbldzy == null) {
        this.$message.warning("请选择专业");
        return false;
      }
      if (this.pySbld.bosds == ' ' || this.pySbld.bosds == null) {
        this.$message.warning("请选择导师");
        return false;
      }
      if (this.pySbld.rxqxl == ' ' || this.pySbld.rxqxl == null) {
        this.$message.warning("请输入入学前简历");
        return false;
      }
      if (this.pySbld.sqly == ' ' || this.pySbld.sqly == null) {
        this.$message.warning("请输入申请理由");
        return false;
      }
      this.$http.post("/api/frontpage/sbldsq/start", this.pySbld).then(res => {
        // console.log(res.data);
        if (res.data.code === 200) {
          this.$message.success("申请成功");
          // 清空附件
          this.$refs.upload.clearFiles();
          this.pySbld = { fj: [] };
        }
      });
    },
    // 删除文件的回调
    handleRemove() {
      // console.log("移除文件");
      this.pySbld.fj.pop();
    },
    // 上传成功的回调
    handleSuccess(res,file,fileList) {
       if(res.code == 200){
          this.pySbld.fj.push(res.data);
        }else{
          fileList.pop()
          this.$message.error(res.message)
        }
      
      // console.log(res);
    }
  },
  watch: {
    // 监听学院变化
    "pySbld.sbldxy": {
      handler(val) {
        console.log(val);
        this.pySbld.sbldzy = "";
        this.pySbld.bosds = "";
        if (val) {
          this.requireZY();
        }
      }
    },
    // 监听专业变化
    "pySbld.sbldzy": {
      handler(val) {
        console.log(val);
        this.pySbld.bosds = "";
        // 如果专业有值
        if (val) {
          // 请求导师列表
          this.requireDS();
        }
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }
    .moralHeight {
      padding: 0;
      height: 40px;
    }
    td {
      width: 100px;
      // text-align: center;

      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
