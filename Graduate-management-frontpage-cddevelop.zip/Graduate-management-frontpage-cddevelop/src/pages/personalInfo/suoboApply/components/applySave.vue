<template>
  <div>
    <!-- 基本信息 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">
            <table-flag
              v-if="$route.params.id == 3 || $route.params.id == 4"
              :status="localStatus"
              :time="time"
              :table-title="tableTitle"
            ></table-flag>
            <table-flag
              v-if="$route.matched[1].path == '/stuInfoAudit/:id?'"
              :table-title="tableTitle"
            ></table-flag>
          </th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>政治面貌</td>
            <td>{{ userInfo.zzmmmc }}</td>
            <td>联系电话</td>
            <td>{{ userInfo.dh }}</td>
            <td>入学年月</td>
            <td>{{ userInfo.rxny }}</td>
          </tr>
          <tr>
            <td>硕士所在学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>硕士专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>硕士生导师</td>
            <td>{{ userInfo.dsxm }}</td>
          </tr>
          <tr>
            <td class="moralHeight">
              <span v-if="localStatus == 4" style="color:red;margin-left:8px;">*</span>&nbsp;硕博连读学院
            </td>
            <td class="moralHeight">
              <span v-if="$route.matched[1].path === '/stuInfoAudit/:id?'">{{writeInfo.sbldxy}}</span>
              <el-select
                v-model="writeInfo.sbldxy"
                clearable
                placeholder="请选择学院"
                @clear="writeInfo.sbldxy = ''"
                v-else-if="localStatus == 4"
                @change="xyChange"
                style="width:230px"
              >
                <el-option
                  v-for="item in xyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
              <span v-else>{{xyShow}}</span>
            </td>

            <td class="moralHeight">
              <span v-if="localStatus == 4" style="color:red;margin-left:8px;">*</span>&nbsp;硕博连读专业
            </td>
            <td class="moralHeight">
              <!-- <el-input v-model="writeInfo.sbldzy"></el-input> -->
              <span v-if="$route.matched[1].path === '/stuInfoAudit/:id?'">{{writeInfo.sbldzy}}</span>
              <el-select
                v-else-if="localStatus == 4"
                v-model="writeInfo.sbldzy"
                clearable
                placeholder="请选择专业"
                @clear="writeInfo.sbldzy = ''"
                @change="zyChange"
                style="width:230px"
              >
                <el-option
                  v-for="item in zyOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
              <span v-else>{{zyShow}}</span>
            </td>

            <td class="moralHeight">
              <span v-if="localStatus == 4" style="color:red;margin-left:8px;">*</span>&nbsp;博士生导师
            </td>
            <td class="moralHeight">
              <!-- <el-input v-model="writeInfo.bosds"></el-input> -->
              <span v-if="$route.matched[1].path === '/stuInfoAudit/:id?'">{{writeInfo.bosds}}</span>
              <el-select
                v-else-if="localStatus == 4"
                v-model="writeInfo.bosds"
                filterable
                clearable
                placeholder="请选择导师"
                @clear="writeInfo.bosds = ''"
                style="width:230px"
              >
                <el-option
                  v-for="item in dsOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
              <span v-else>{{dsShow}}</span>
            </td>
          </tr>
          <tr>
            <td class="moralHeight">
              <span v-if="$route.matched[1].path !== '/stuInfoAudit/:id?'  && localStatus == 4" style="color:red;margin-left:8px;">*</span>&nbsp;入学前学历(何时何校何专业毕业及学位授予情况)
            </td>
            <td colspan="5" class="moralHeight">
              <el-input
                v-model="writeInfo.rxqxl"
                v-if="$route.matched[1].path !== '/stuInfoAudit/:id?'  && localStatus == 4"
              ></el-input>
              <span v-else>{{writeInfo.rxqxl}}</span>
            </td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item v-if="$route.matched[1].path !== '/stuInfoAudit/:id?'  && localStatus == 4" :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="writeInfo.sqly"
                  ></el-input>
                </el-form-item>
                <el-form-item  label="申请理由：" v-else>
                  <span >{{writeInfo.sqly}}</span>
                </el-form-item>
              </el-form>
            </td>
          </tr>
          <tr v-if="$route.matched[1].path == '/stuInfoAudit/:id?' || localStatus != 4">
            <td style="background:none">证明材料：</td>
            <td colspan="5">
              <ul class="fj">
                <li v-for="(item,index) of fj" :key="index">
                  <a
                    :href="item.url"
                    target="_blank"
                    class="primary"
                    :download="item.fileName"
                  >{{item.fileName}}</a>
                </li>
              </ul>
            </td>
          </tr>
          <tr v-else>
            <td style="background:none">上传证明材料：</td>
            <td colspan="5">
              <el-upload
                ref="upload"
                class="upload-demo"
                :headers="headers"
                action="/api/system/upload"
                :on-success="handleSuccess"
                multiple
                :limit="1"
              >
                <el-button size="small" type="primary" plain>
                  点击上传
                  <i class="el-icon-plus el-icon--right"></i>
                </el-button>
              </el-upload>
            </td>
          </tr>
        </tbody>
      </table>
      <div
        class="bottom"
        v-show="$route.params.id == 4 && $route.matched[1].path !== '/stuInfoAudit/:id?'"
      >
        <el-button @click="handleReset">重置</el-button>
        <el-button type="primary" @click="handleUpdate">重新提交</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import tableFlag from "@/components/tableFlag";
export default {
  name: "applySave",
  props: {
    status: {
      default: ""
    }
  },
  components: {
    tableFlag
  },
  data() {
    return {
      tableTitle: "浙江财经大学研究生硕博连读申请表",
      input: "",
      isSee: false,
      isChange: false,
      isIng: true,
      isBack: false,
      time: "2019/05/18",
      // 本地化父组件传递的值
      localStatus: "",
      userInfo: {}, // 初始化数据
      writeInfo: {}, // 申请写入的数据
      updateInfo: {}, // 修改提交的数据
      auditList: {}, // 审核流程图
      // 学院可选列表
      xyOptions: [],
      // 专业可选列表
      zyOptions: [],
      // 导师可选列表
      dsOptions: [],
      fj: [],
      headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
    };
  },
  watch: {
    // 1申请，2列表，3查看，4修改
    $route(to) {
      if (
        to.path == "/personalInfo/suoboApply/3" ||
        to.path == "/personalInfo/suoboApply/4"
      ) {
        this.getData1();
      } else if (
        (to.query.check == 0 || to.query.check == 1) &&
        to.query.mark == 4
      ) {
        this.getData();
      }
    },
    // 监听学院变化
    "writeInfo.sbldxy": {
      handler(val) {
        // console.log(val);
        if (this.$route.matched[1].path !== "/stuInfoAudit/:id?") {
          if (val) {
            this.requireZY();
          }
        }
      }
    },
    // 监听专业变化
    "writeInfo.sbldzy": {
      handler(val) {
        // console.log(val);
        if (this.$route.matched[1].path !== "/stuInfoAudit/:id?") {
          // 如果专业有值
          if (val) {
            // 请求导师列表
            this.requireDS();
          }
        }
      }
    }
  },
  mounted() {
    // 本地化父组件传递的值
    this.localStatus = this.status;
  },
  created() {
    if (this.$route.matched[1].path !== "/stuInfoAudit/:id?") {
      this.requireXY();
    }
    if (
      this.$route.path === "/personalInfo/suoboApply/3" ||
      this.$route.path === "/personalInfo/suoboApply/4"
    ) {
      this.getData1();
    } else if (
      (this.$route.query.check == 0 || this.$route.query.check == 1) &&
      this.$route.query.mark == 4
    ) {
      this.getData();
    }
  },
  computed: {
    xyShow() {
      let tmp = this.xyOptions.find(el => this.writeInfo.sbldxy === el.value);
      if (tmp) {
        return tmp.label;
      }
    },
    zyShow() {
      let tmp = this.zyOptions.find(el => this.writeInfo.sbldzy === el.value);
      if (tmp) {
        return tmp.label;
      }
    },
    dsShow() {
      console.log(this.writeInfo.bosds);
      console.log(this.dsOptions);
      let tmp = this.dsOptions.find(el => this.writeInfo.bosds === el.value);
      if (tmp) {
        return tmp.label;
      }
    }
  },
  methods: {
    xyChange() {//当学院的值发生改变时做相应的变化
      this.writeInfo.sbldzy = "";
      this.writeInfo.bosds = "";
      this.zyOptions = [];
      this.dsOptions = [];
    },
    zyChange() {//当专业值发生改变时做出相应的变化
      this.writeInfo.bosds = "";
      this.dsOptions = [];
    },

    // 获取学院可选列表
    requireXY() {
      this.$http.get("/api/cultivate/pygrpyjhb/selectDwList").then(res => {
      //  console.log(res.data.data,8)
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取学院信息失败，请重试");
          return;
        }
        this.xyOptions = [];

        data.map(item => {
          let obj = {
            value: item.dwh,
            label: item.dwmc
          };
          this.xyOptions.push(obj);
        });
      });
    },
    // 根据学院查询专业 //新修改的接口/cultivate/class/getMajorByCollege?dwh=   zyh  zymc
    requireZY() {
      // console.log(val)
      if (this.writeInfo.sbldxy) {
        this.$http
          .get("/api/cultivate/class/getMajorByCollege", {
            params: {
              dwh: this.writeInfo.sbldxy
            }
          })
          .then(res => {
            // console.log(res.data.data)
            let data = res.data.data;
            if (!Array.isArray(data)) {
              this.$message.error("获取专业信息失败，请重试");
              return;
            }
            this.zyOptions = [];
            console.log("清空导师列表");
            data.map(item => {
              let obj = {
                value: item.zyh,
                label: item.zymc
              };
              this.zyOptions.push(obj);
            });
          });
      }
    },
    // 请求导师列表
    requireDS() {
      console.log("请求导师");
      this.$http
        .get("/api/frontpage/xjydsq/selectTeaByMajor", {
          params: { zyh: this.writeInfo.sbldzy, pyccm: "2" }
        })
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            this.$message.error("获取导师信息失败，请重试");
            return;
          }
          this.dsOptions = [];
          data.map(item => {
            let obj = {
              value: item.gh,
              label: item.dsxm
            };
            console.log("获取导师列表");
            this.dsOptions.push(obj);
          });
        });
    },
    // 查看详情 老师端
    getData() {
      this.$http
        .get("/api/frontpage/sbldsq/infoByLcid", {
          params: {
            lcid: this.$route.query.id
          }
        })
        .then(res => {
          let data = res.data.data.xsSbldsqInfoBaseVo;
          this.userInfo = data.xsSbldsqVo;
          this.writeInfo = data.pySbld;
          this.time = data.pySbld.cjsj;
          this.localStatus = data.pySbld.zt;
          this.auditList = res.data.data.list;
          this.fj = data.pySbld.fj;
          this.$store.state.auditList = this.auditList;
          this.$bus.$emit("stepList", this.auditList);
        });
    },
    // 学生端
    getData1() {
      this.$http
        .get("/api/frontpage/sbldsq/infoById", {
          params: {
            id: this.$route.query.id
          }
        })
        .then(res => {
          let data = res.data.data;
          this.userInfo = data.xsSbldsqVo;
          this.writeInfo = data.pySbld;
          this.time = data.pySbld.cjsj;
          this.localStatus = data.pySbld.zt;
          this.fj = data.pySbld.fj;
        });
    },
    // 修改提交
    handleUpdate() {
      this.writeInfo.firstfj = this.fj;
      if (this.writeInfo.sbldxy == ' ' || this.writeInfo.sbldxy == null) {
        this.$message.warning("请选择学院");
        return false;
      }
      if (this.writeInfo.sbldzy == ' ' || this.writeInfo.sbldzy == null) {
        this.$message.warning("请选择专业");
        return false;
      }
      if (this.writeInfo.bosds == ' ' || this.writeInfo.bosds == null) {
        this.$message.warning("请选择导师");
        return false;
      }
      if (this.pySbld.rxqxl == ' ' || this.pySbld.rxqxl == null) {
        this.$message.warning("请输入入学前简历");
        return false;
      }
      if (this.pySbld.sqly == ' ' || this.pySbld.sqly == null) {
        this.$message.warning("请输入申请理由");
        return false;
      }
      // console.log(this.updateInfo);
      this.$http
        .post("/api/frontpage/sbldsq/update", this.writeInfo)
        .then(res => {
          // console.log(res.data);
          if (res.data.code === 200) {
            this.$message.success("修改成功");
            // 清空附件
            this.$refs.upload.clearFiles();
            this.getData();
            // 修改成功后后退
            this.$router.go(-1);
          }
        });
    },
    handleSuccess(res) {
      if (res.data !== null) {
        this.fj.push(res.data);
      }
    },
    // 重置参数
    handleReset() {
      this.writeInfo.sbldxy = "";
      this.writeInfo.sbldzy = "";
      this.writeInfo.bosds = "";
      this.writeInfo.rxqxl = "";
      this.writeInfo.sqly = "";
      this.fj = [];
      // console.log(this.writeInfo);
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/styles/table.scss";
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;

      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.fj {
  display: flex;
  li:not(:first-child) {
    a:before {
      content: "、";
    }
  }
  a {
    color: #1890ff;
  }
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
