<template>
  <div>
    <!-- 查看更换导师申请状态 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">
            <table-flag
              v-if="$route.params.id == 3 || $route.params.id == 4"
              :status="status1"
              :time="time"
              :table-title="tableTitle"
            ></table-flag>
            <table-flag
              v-if="$route.matched[1].path == '/stuInfoAudit/:id?'"
              :table-title="tableTitle"
            ></table-flag>
          </th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>年级</td>
            <td>{{ userInfo.sznj }}</td>
          </tr>
          <tr>
            <td>原导师</td>
            <td>{{ userInfo.dsxm }}</td>
            <td>新导师</td>
            <td colspan="3">
              <el-select
                v-model="writeInfo.xds"
                filterable
                remote
                placeholder="请输入教职工姓名查询"
                :remote-method="queryTutorByName"
                :loading="loading"
                style="width:100%"
                @change="teacherSelectChange"
                v-if="$route.matched[1].path === '/stuInfoAudit/:id?' && this.status1 == 4"
              >
                <el-option
                  v-for="(item,index) in dsOptions"
                  :key="index"
                  :value="item.gh"
                  :label="item.info"
                ></el-option>
              </el-select>
              <span v-else>{{writeInfo.xds}}</span>
            </td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item v-if="$route.matched[1].path !== '/stuInfoAudit/:id?' && this.status1 == 4" :required="true" label="申请理由：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="writeInfo.sqly"
                    v-if="$route.matched[1].path !== '/stuInfoAudit/:id?' && this.status1 == 4"
                  ></el-input>
                </el-form-item>
                <el-form-item label="申请理由：" v-else>
                  <span>{{writeInfo.sqly}}</span>
                </el-form-item>
              </el-form>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="bottom" v-if="status1 == 4">
        <el-button @click="handleReset">重置</el-button>
        <el-button type="primary" @click="handleUpdate">重新提交</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import tableFlag from "@/components/tableFlag";
export default {
  name: "apply",
  props: ["status"],
  components: {
    tableFlag
  },
  data() {
    return {
      tableTitle: "浙江财经大学研究生更换导师申请表",
      input: "",
      isSee: false,
      isChange: false,
      isIng: true,
      isBack: false,
      time: "2019/05/18",
      status1: "",
      userInfo: {}, // 初始化数据
      writeInfo: {}, // 申请写入的数据
      updateInfo: {}, // 修改提交的数据
      auditList: {}, // 审核流程图
      loading: false,
      dsOptions: []
    };
  },
  watch: {
    // 1申请，2列表，3查看，4修改
    // 待审核check：0，已审核：1
    $route(to) {
      if (
        to.path == "/personalInfo/changeTutor/3" ||
        to.path == "/personalInfo/changeTutor/4"
      ) {
        this.getData();
      }
      if (
        (to.path == "/stuInfoAudit" || to.query.check == 1) &&
        to.query.mark == 2
      ) {
        this.getData();
      }
    }
  },
  created() {
    this.queryTutorByName();
    // 将父组件传递的status本地化
    this.status1 = this.status;
    if (
      this.$route.path == "/personalInfo/changeTutor/3" ||
      this.$route.path == "/personalInfo/changeTutor/4"
    ) {
      this.getData();
    }
    if (
      (this.$route.path == "/stuInfoAudit" || this.$route.query.check == 1) &&
      this.$route.query.mark == 2
    ) {
      this.getData();
    }
  },
  mounted() {
    // //console.log(this.$route.params.id)
  },
  methods: {
    // 查看详情
    getData() {
      this.$http
        .get("/api/frontpage/ghds/infoByLcid", {
          params: {
            lcid: this.$route.query.id
          }
        })
        .then(res => {
          // console.log(res.data.data)
          let data = res.data.data;
          this.userInfo = data.xsGhdssqVo;
          this.writeInfo = data.pyGhds;
          this.time = data.pyGhds.cjsj;
          this.status1 = data.pyGhds.zt;
          this.auditList = data.list;
          this.$store.state.auditList = this.auditList;
          this.$bus.$emit("stepList", this.auditList);
          // if (
          //   this.$route.matched[1].path !== "/stuInfoAudit/:id?" &&
          //   this.status1 === 4
          // )
          //  {
          //   this.queryTutorByNameRemote(this.writeInfo.xds);
          // }
        });
    },
    // 修改提交
    handleUpdate() {
      if (this.pyGhds.xds == ' ' || this.pyGhds.xds == null) {
        this.$message.warning('请选择新导师')
        return false
      }
      if (this.pyGhds.sqly == ' ' || this.pyGhds.sqly == null) {
        this.$message.warning('请输入申请理由')
        return false
      }
      this.$http
        .post("/api/frontpage/ghds/update", this.writeInfo)
        .then(res => {
          // console.log(res.data)
          if (res.data.code === 200) {
            this.$message.success("修改成功");
            this.getData();
            // 修改成功后后退
            this.$router.go(-1);
          }
        });
    },
    // 重置参数
    handleReset() {
      this.writeInfo.sqly = "";
      this.writeInfo.xds = "";
    },
    queryTutorByName(val) {
      // console.log(val);
      if (val === "") {
        return;
      }
      this.loading = true;
      // setTimeout(() => {
      //   this.queryTutorByNameRemote(val);
      // }, 200);
      // this.dsOptions = [];
    },
    // queryTutorByNameRemote(val) {
    //   this.$http
    //     .get("/api/frontpage/ghds/selectTeaList", { params: { xm: val } })
    //     .then(res => {
    //       this.loading = false;
    //       let data = res.data.data;
    //       console.log(data);
    //       if (!Array.isArray(data)) {
    //         this.$message.error("获取导师信息失败，请重试");
    //         return;
    //       }
    //       this.dsOptions = data;
    //     });
    // },
    teacherSelectChange(val) {
      // this.dsOptions = [];
    },
  }
};
</script>

<style lang="scss" scoped>
@import "@/styles/table.scss";
</style>
