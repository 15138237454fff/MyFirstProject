<template>
  <div>
    <!-- 申请研究生证补办 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">
            浙江财经大学研究生证补办申请表
            <!-- <span v-show="time">{{ `(${time})` }}</span> -->
          </th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>培养层次</td>
            <td>{{ userInfo.pyccm }}</td>
          </tr>
          <tr>
            <td>出生年月</td>
            <td>{{ userInfo.csrq }}</td>
            <td>入学年月</td>
            <td>{{ userInfo.rxny }}</td>
            <td>学制</td>
            <td>{{ userInfo.xz }}</td>
          </tr>
          <tr>
            <td rowspan="2" style="padding:0;height:80px;"><span style="color:red;margin-left:8px;">*</span>&nbsp;假期火车票减价优待证</td>
            <td style="background:#f2f2f2;padding:0;height:40px;">&nbsp;&nbsp;家庭所在地</td>
            <td colspan="4" style="background:none;padding:0;height:40px;">
              <el-input v-model="pyYjszbb.jtszd"></el-input>
            </td>
          </tr>
          <tr>
            <td style="padding:0;height:40px;">&nbsp;&nbsp;乘车区间</td>
            <td colspan="4" class="travel-range" style="padding:0;height:40px;text-align: center;">
              杭州站 至
              <el-input v-model="pyYjszbb.ccqj"></el-input>站
            </td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="补办原因：">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="pyYjszbb.bbsm"
                  ></el-input>
                </el-form-item>
              </el-form>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="tip" style="margin-top:10px;">
        <p>注：1.研究生证补办时间：教学周第一周至第16周。</p>
        <p>2.补办研究生证工本费10元/本。每张优惠卡成本费7元。</p>
        <p>3.领取证件需另带一寸近照一张。</p>
      </div>
      <div class="bottom">
        <el-button type="primary" @click="dialogVisible = true">提交申请</el-button>
      </div>
    </div>
    <el-dialog title="确认提交" :visible.sync="dialogVisible" width="380px" top="31vh">
      <p>是否确认提交？</p>
      <p>提交后请在申请记录中查看审核状态</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleSubmit">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'apply',
  props: ['userInfo'],
  data () {
    return {
      input: '',
      pyYjszbb: {},
      dialogVisible: false
    }
  },
  mounted () {
    // //console.log(this.$route.params.id)
  },
  methods: {
    // 提交申请
    handleSubmit () {
      // console.log(this.pyYjszbb)
      this.dialogVisible = false
      if (this.pyYjszbb.jtszd == ' '|| this.pyYjszbb.jtszd == null) {
        this.$message.warning('请填写家庭所在地')
        return false
      }
      if (this.pyYjszbb.ccqj == ' ' || this.pyYjszbb.ccqj == null) {
        this.$message.warning('请输入乘车区间')
        return false
      }
      if (this.pyYjszbb.bbsm == ' ' || this.pyYjszbb.bbsm == null) {
        this.$message.warning('请填写补办原因')
        return false
      }
      const loading = this.$loading({
          lock: true,
          text: 'Loading',
          // spinner: 'el-icon-loading',
          background: 'rgba(255, 255, 255, 1)',
          target:document.querySelector('.table-box')
        });
      this.$http
        .post('/api/frontpage/yjszbbsq/start', this.pyYjszbb)
        .then(res => {
          loading.close()
          // console.log(res.data)
          if (res.data.code === 200) {
            this.$message.success('申请成功')
            this.pyYjszbb = {}
          }
        }).catch(err=>{
          loading.close()
          this.$message.error(err.data.message)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;
    .el-input{
      padding: 0;
      height: 40px;
    }
      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
      .el-textarea {
        width: 90%;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
  .travel-range {
    .el-input {
      width: 30%;
      margin-left: 10px;
      margin-right: 10px;
    }
  }
}
.tip {
  p {
    color: #f56c6c;
    font-size: 13px;
    margin-left:26px;
  }
  p:nth-of-type(1){
    margin-left:0;
  }
}
/deep/ .el-dialog__body {
  border-bottom: 1px solid #ddd;
  text-align: center;
  p {
    line-height: 32px;
  }
}
/deep/ .el-dialog__title {
  font-size: 14px;
  color: #333;
  font-weight: 600;
}
/deep/ .el-dialog__header {
  border-bottom: 1px solid #ddd;
}
/deep/ .el-dialog__footer {
  text-align: center;
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
