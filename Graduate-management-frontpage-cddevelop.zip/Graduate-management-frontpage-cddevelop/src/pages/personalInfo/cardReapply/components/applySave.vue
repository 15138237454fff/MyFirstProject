<template>
  <div>
    <!-- 研究生证补办查看申请状态 -->
    <div class="table-box">
      <table border="1" cellspacing="0" cellpadding="10">
        <thead></thead>
        <tbody>
          <th colspan="6">
            <table-flag
              v-if="$route.params.id == 3 || $route.params.id == 4"
              :status="zt"
              :time="time"
              :table-title="tableTitle"
            ></table-flag>
          </th>
          <tr>
            <td>姓名</td>
            <td>{{ userInfo.xm }}</td>
            <td>学号</td>
            <td>{{ userInfo.xh }}</td>
            <td>性别</td>
            <td>{{ userInfo.xbm }}</td>
          </tr>
          <tr>
            <td>学院</td>
            <td>{{ userInfo.yxsh }}</td>
            <td>专业</td>
            <td>{{ userInfo.zy }}</td>
            <td>培养层次</td>
            <td>{{ userInfo.pyccm }}</td>
          </tr>
          <tr>
            <td>出生年月</td>
            <td>{{ userInfo.csrq }}</td>
            <td>入学年月</td>
            <td>{{ userInfo.rxny }}</td>
            <td>学制</td>
            <td>{{ userInfo.xz }}</td>
          </tr>
          <tr>
            <td rowspan="2" style="padding:0 10px;height:80px;">假期火车票减价优待证</td>
            <td style="background:#f2f2f2;padding:0 10px;height:40px;">家庭所在地</td>
            <td colspan="4" style="background:none;padding:0 10px;height:40px;">
              <el-input v-model="writeInfo.jtszd" v-if="zt == 4"></el-input>
              <span v-else>{{writeInfo.jtszd}}</span>
            </td>
          </tr>
          <tr>
            <td style="padding:0 10px;height:40px;">乘车区间</td>
            <td colspan="4" class="travel-range" style="padding:0 10px;height:40px;text-align: center;">
              杭州站 至
              <el-input v-model="writeInfo.ccqj" v-if="zt === 4"></el-input>
              <span v-else>{{writeInfo.ccqj}}</span> 站
            </td>
          </tr>
          <tr>
            <td colspan="6" style="background:none">
              <el-form>
                <el-form-item :required="true" label="补办原因：" v-if="zt == 4">
                  <el-input
                    type="textarea"
                    :autosize="{ minRows: 6, maxRows: 8}"
                    placeholder="请输入内容"
                    v-model="writeInfo.bbsm"
                  ></el-input>
                </el-form-item>
                 <el-form-item label="补办原因：" v-if="zt != 4">
                  <span >{{writeInfo.bbsm}}</span>
                </el-form-item>
              </el-form>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="tip">
        <p>注:1.研究生证补办时间：教学周第一周至第16周。</p>
        <p>2.补办研究生证工本费10元/本。每张优惠卡成本费7元。</p>
        <p>3.领取证件需另带一寸近照一张。</p>
      </div>
      <div class="bottom" v-if="zt == 4">
        <el-button @click="handleReset">重置</el-button>
        <el-button type="primary" @click="handleUpdate">重新提交</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import tableFlag from "@/components/tableFlag";
export default {
  name: "applySave",
  props: ["status"],
  components: {
    tableFlag
  },
  data() {
    return {
      tableTitle: "浙江财经大学研究生证补办申请表",
      time: "2019/05/18",
      input: "",
      isSee: false,
      isChange: false,
      isIng: true,
      isBack: false,
      userInfo: {}, // 初始化数据
      writeInfo: {}, // 申请写入的数据
      updateInfo: {}, // 修改提交的数据
      auditList: {} ,// 审核流程图
      zt:''
    };
  },
  watch: {
    // 1申请，2列表，3查看，4修改
    $route(to) {
      if (
        to.path == "/personalInfo/cardReapply/3" ||
        to.path == "/personalInfo/cardReapply/4"
      ) {
        this.getData();
      }
    }
  },
  created() {
    console.log(this.zt);
    if (
      this.$route.path == "/personalInfo/cardReapply/3" ||
      this.$route.path == "/personalInfo/cardReapply/4"
    ) {
      this.getData();
    }
  },
  mounted() {
    if(this.zt == ''){
      this.zt = this.status
    }
    // //console.log(this.$route.params.id)
  },
  methods: {
    // 查看详情
    getData() {
      this.$http
        .get("/api/frontpage/yjszbbsq/infoByLcid", {
          params: {
            lcid: this.$route.query.id
          }
        })
        .then(res => {
          // console.log(res.data.data)
          let data = res.data.data;
          this.userInfo = data.xsYjsbbsqVo;
          this.writeInfo = data.pyYjszbb;
          this.time = data.pyYjszbb.cjsj;
          this.auditList = data.list;
          this.$store.state.auditList = this.auditList;
          this.$bus.$emit("stepList", this.auditList);
          this.zt = data.pyYjszbb.zt
        });
    },
    // 修改提交
    handleUpdate() {
      if (this.pyYjszbb.jtszd == ' '|| this.pyYjszbb.jtszd == null) {
        this.$message.warning('请填写家庭所在地')
        return false
      }
      if (this.pyYjszbb.ccqj == ' ' || this.pyYjszbb.ccqj == null) {
        this.$message.warning('请输入乘车区间')
        return false
      }
      if (this.pyYjszbb.bbsm == ' ' || this.pyYjszbb.bbsm == null) {
        this.$message.warning('请填写补办原因')
        return false
      }
      this.$http
        .post("/api/frontpage/yjszbbsq/update", this.writeInfo)
        .then(res => {
          // console.log(res.data)
          if (res.data.code === 200) {
            this.$message.success("修改成功");
            this.getData();
            // 修改成功后后退
            this.$router.go(-1);
          }
        });
    },
    // 重置参数
    handleReset() {
      this.writeInfo.jtszd = "";
      this.writeInfo.bbsm = "";
      this.writeInfo.ccqj = "";
    }
  }
};
</script>

<style lang="scss" scoped>
@import "@/styles/table.scss";
.table-box {
  width: 100%;
  // height: 200px;
  // border: 1px solid rgba(228, 228, 228, 1);
  box-sizing: border-box;

  table {
    width: 100%;
    border-collapse: collapse;
    color: #333;
    font-size: 14px;
    border: none;
    border-color: rgba(228, 228, 228, 1);

    th {
      text-align: center;
      font-size: 20px;
      // background-color: rgba(242, 242, 242, 1);
    }

    td {
      width: 100px;
      // text-align: center;
      .el-input{
        padding: 0;
        height: 40px;
      }
      .avatar {
        width: 100px;
        height: 125px;
      }
      &:nth-child(odd) {
        background: #f2f2f2;
      }
    }
  }

  .star::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
  .travel-range {
    .el-input {
      width: 30%;
      margin-left: 10px;
      margin-right: 10px;
    }
  }
}
.tip {
  p {
    color: #f56c6c;
    font-size: 13px;
    margin-left:26px;
  }
  p:nth-of-type(1){
    margin-left:0;
  }
}
.bottom {
  margin-top: 20px;
  text-align: right;
}
</style>
