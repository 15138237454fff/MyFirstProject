<template>
    <div class="employService-box">
        <!-- 离职就业服务 employService -->
        <unopen/>
    </div>
</template>

<script>
import unopen from '@/components/unopen'
export default {
  name: 'employService',
  components:{unopen}
}
</script>

<style lang="scss" scoped>
  .employService-box{
    width: 100%;
    height: 100%;
  }
</style>
