<template>
    <div class="routine-box">
        <!-- 日常工作 routine -->
        <unopen/>
    </div>
</template>

<script>
import unopen from '@/components/unopen'
export default {
  name: 'routine',
  components:{unopen}
}
</script>

<style lang="scss" scoped>
  .routine-box{
    width:100%;
    height:100%;
    background: #fff;
  }
</style>
