<template>
  <div class="uploadTable" v-if="!loading">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item
            :to="{ path: '/academicDegree/academicDegreeApply' }"
            >学位申请</el-breadcrumb-item
          >
          <el-breadcrumb-item>学位论文终稿</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button type="primary" @click="handleSubmit" v-if="writeable"
          >提交</el-button
        >
      </div>
    </my-breadcrumb>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              table-title="浙江财经大学研究生学位论文终稿"
              :status="userStatus == 1 ? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6"><span>|</span> 论文关键信息</th>
          <tr>
            <td :class="writeable ? 'required' : ''">论文中文题目</td>
            <td colspan="5">
              <el-input v-model="paperForm.lwzwtm" v-if="writeable"></el-input>
              <span v-else>{{ paperForm.lwzwtm }}</span>
            </td>
          </tr>
          <tr>
            <td :class="writeable ? 'required' : ''">论文英文题目</td>
            <td colspan="5">
              <el-input v-model="paperForm.lwywtm" v-if="writeable"></el-input>
              <span v-else>{{ paperForm.lwywtm }}</span>
            </td>
          </tr>
          <tr>
            <td :class="writeable ? 'required' : ''">论文字数</td>
            <td>
              <el-input
                v-model="paperForm.lwzs"
                v-if="writeable"
                type="number"
                min="0"
              >
                <i slot="suffix" class="danwei">万</i>
              </el-input>
              <span v-else>{{ paperForm.lwzs }}万</span>
            </td>
            <td :class="writeable ? 'required' : ''">论文类型</td>
            <td>
              <el-input v-model="paperForm.lwlx" v-if="writeable"></el-input>
              <span v-else>{{ paperForm.lwlx }}</span>
            </td>
            <td :class="writeable ? 'required' : ''">选题来源</td>
            <td>
              <el-select
                v-model="paperForm.xtly"
                placeholder="请选择"
                v-if="writeable"
                style="width:100%"
              >
                <el-option
                  v-for="(item, index) in originOption"
                  :key="index"
                  :label="item.name"
                  :value="item.name"
                ></el-option>
              </el-select>
              <span v-else>{{ paperForm.xtly }}</span>
            </td>
          </tr>
          <!-- <tr>
            <td :class=" writeable ? 'required' : '' ">论文起始日期</td>
            <td>
              <el-date-picker
                v-if="writeable"
                v-model="paperForm.lwkssj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%"
                :picker-options="startDatePicker"
              ></el-date-picker>
              <span v-else>{{paperForm.lwkssj|toYMD}}</span>
            </td>
            <td :class=" writeable ? 'required' : '' ">论文终止日期</td>
            <td>
              <el-date-picker
                v-if="writeable"
                v-model="paperForm.lwzzsj"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%"
                :picker-options="endDatePicker"
              ></el-date-picker>
              <span v-else>{{paperForm.lwzzsj|toYMD}}</span>
            </td>
            <td></td>
            <td></td>
          </tr> -->
          <tr>
            <td :class="writeable ? 'required' : ''">论文关键词</td>
            <td colspan="5" style="background:#fff">
              <el-input
                v-model="lwgjz"
                v-if="writeable"
                placeholder="请输入关键词3-5个，以“，”间隔"
                class="keywords"
              ></el-input>
              <i
                class="el-icon-circle-plus"
                style="color:#409eff"
                @click="lwadd()"
                v-if="paperForm.lwgjz.length != -1 && writeable"
              ></i>
              <div v-if="writeable" style="display:inline-block;">
                <div
                  class="delkeybords"
                  v-for="(lwzList, index) in paperForm.lwgjz"
                  :key="index"
                >
                  {{ lwzList
                  }}<i
                    class="el-icon-remove"
                    style="color:#f56c6c"
                    @click="lwdelet(lwzList, index)"
                  ></i>
                </div>
              </div>
              <span v-if="!writeable" class="disable">{{
                paperForm.lwgjz
              }}</span>
            </td>
          </tr>
          <!-- <tr>
            <td>中文摘要</td>
            <td colspan="5">
              <el-input
                v-model="paperForm.zwzy"
                v-if="writeable"
                type="textarea"
                :rows="2"
              ></el-input>
              <span v-else>{{ paperForm.zwzy }}</span>
            </td>
          </tr>
          <tr>
            <td>英文摘要</td>
            <td colspan="5">
              <el-input
                v-model="paperForm.ywzy"
                v-if="writeable"
                type="textarea"
                :rows="2"
              ></el-input>
              <span v-else>{{ paperForm.ywzy }}</span>
            </td>
          </tr> -->
          <tr>
            <td :class="writeable ? 'required' : ''">论文研究方向</td>
            <td colspan="5">
              <el-input
                v-model="paperForm.lwyjfx"
                v-if="writeable"
                :rows="2"
              ></el-input>
              <span v-else>{{ paperForm.lwyjfx }}</span>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6"><span>|</span> 论文附件上传</th>
          <tr>
            <td colspan="6" class="uploadArea" v-if="uploadShow">
              <!-- <el-upload
                ref="upload"
                action="/api/degree/duc/upload"
                multiple
                :file-list="fileList"
                :show-file-list="true"
                :on-success="receiveFJ"
                :on-remove="removeFJ"
                accept=".pdf, .doc, .docx"
              >
                <el-button style="width:117px" icon="el-icon-upload2">上传文件</el-button>
              </el-upload>
              <div>
                <div>只能上传后缀为.docx或.pdf的文件！</div>
              </div> -->
              <el-upload
                action="/api/degree/duc/upload"
                :data="uploadData"
                :limit="1"
                :before-upload="handlebefore"
                :on-success="handleSuccess"
                ref="uploadcsv"
                accept=".pdf, .doc, .docx"
                :headers="headtoken"
              >
                <el-button style="width:350px" icon="el-icon-upload"
                  >点击上传</el-button
                >
              </el-upload>
              <div>
                <li v-for="(item, index) in fileList" :key="index">
                  <i class="el-icon-document"></i
                  ><a
                    style="margin-right:20px;margin-left:10px"
                    :href="paperForm.fj.url"
                    target="_blank"
                    :download="item.fileName"
                    >{{ item.fileName }}</a
                  >
                  <i
                    class="el-icon-close"
                    @click="cancelupload(index, item.url)"
                  ></i>
                </li>
                <li
                  style="margin-left:20px;margin-top:20px;"
                  class="el-upload__tip"
                >
                  只能上传后缀为.docx或.pdf的文件！
                </li>
              </div>
            </td>
            <td colspan="6" class="paperShow" v-if="!uploadShow">
              <a
                :href="paperForm.fj.url"
                target="_blank"
                class="primary"
                :download="paperForm.fj.fileName"
                >{{ paperForm.fj.fileName }}</a
              >
            </td>
          </tr>
        </tbody>
      </table>
      <apply-status-bottom></apply-status-bottom>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
import applyStatusBottom from "@/components/applyStatusBottom";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "uploadTable",
  props: {
    id: 0
  },
  components: {
    tableFlag,
    applyStatusBottom,
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      // 是否可以写入
      writeable: true,
      // 是否已经上传过论文
      // hasUpload:false,
      // 待提交的表单数据
      lwgjz: "", // 论文关键字
      paperForm: {
        fj: { url: "", fileName: "" },
        // 论文关键字
        lwgjz: [],
        // 论文类型
        lwlx: "",
        // 论文字数
        lwzs: "",
        // 论文英文题目
        lwywtm: "",
        // 选题来源
        xtly: "",
        // 论文中文题目
        lwzwtm: "",
        // 论文开始时间
        // lwkssj: "",
        // // 论文终止时间
        // lwzzsj: "",
        // // 英文摘要
        // ywzy: "",
        // // 中文摘要
        // zwzy: "",
        lwyjfx: "" // 论文研究方向
      },
      // 审核状态
      status: null,
      // 流程id
      lcid: "",
      // 选题来源可选项
      originOption: [],
      // 必填的基本类型字段
      requiredKeys: [
        "lwzwtm",
        "lwzs",
        "lwlx",
        "xtly",
        "lwkssj",
        "lwzzsj",
        "lwzwywtm",
        "lwyjfx"
      ],
      //上传框参数
      uploadShow: true,
      fileList: [],
      uploadData: {
        file: ""
      },
      headtoken: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      startDatePicker: this.beginDate(),
      endDatePicker: this.processDate(),
      loading: true
    };
  },
  created() {
    // 当前登录为学生
    if (this.userStatus == 1) {
      // 请求提交论文的历史记录
      this.uploadHistoryByXH();
      // 获取论文选题的可选列表
      this.requireSelectTitle();
    }
  },
  methods: {
    // 提交学位申请信息
    handleSubmit() {
      this.$store.commit("updateDialog", {
        msgTwo: " ",
        visible: true,
        successCallback: this.submit
      });
    },
    // 提交数据
    submit() {
      // 关闭对话框
      this.$store.commit("updateDialog", { visible: false });
      // 保存表单验证结果，默认为正确
      let test = true;
      // 如果没有上传附件,验证失败
      if (this.lwgjz.length > 20) {
        this.$message.warning("论文关键字不可超过20字");
        return;
      }
      let regArr = /^[\u4e00-\u9fa5_a-zA-Z0-9]+$/;
      if (regArr.test(this.lwgjz)) {
        this.$message.warning("论文关键字不可包含特殊字符和空格");
        return;
      }
      if (this.paperForm.lwgjz.length < 3 || this.paperForm.lwgjz.length > 5) {
        this.$message.warning("论文关键字大于3个小于5个");
        return;
      }
      if (Object.values(this.paperForm.fj).includes("")) {
        this.$message.warning("将信息填写完整后再尝试提交");
        test = false;
        return;
      }
      // this.requiredKeys.forEach(key => {
      //   // 如果必填项为空,验证失败
      //   if (this.paperForm[key] === "") {
      //     this.$message.warning("将信息填写完整后再尝试提交");
      //     console.log(123)
      //     console.log(key);
      //     test = false;
      //   }
      // });
      Object.keys(this.paperForm).forEach(key => {
        console.log(key, "每一项数据");
        // 如果必填项为空,验证失败
        if (this.paperForm[key] === "") {
          this.$message.warning("将信息填写完整后再提交");
          console.log(key, "未提交");
          test = false;
          return;
        }
        if (key === "lwzs" && this.paperForm.lwzs <= 0) {
          this.$message.warning("论文字数应为正数");
          test = false;
          return;
        }
        // 如果没有上传附件,验证失败
        if (key === "fj" && Object.values(this.paperForm.fj).includes("")) {
          this.$message.warning("将信息填写完整后再提交");
          test = false;
        }
      });
      // 如果验证成功，提交表单数据
      if (test) {
        const loading = this.$loading({
          lock: true,
          text: "Loading",
          // spinner: 'el-icon-loading',
          background: "rgba(255, 255, 255, 1)",
          target: document.querySelector(".box")
        });
        if (this.status != 2) {
          var arr = "";
          arr = this.paperForm.lwgjz.toString();
          this.paperForm.lwgjz = arr;
          this.paperForm.lwgjz.toString();
          console.log(this.paperForm, "第yi次提交数据");
          this.$http.post("/api/degree/pfc/apply", this.paperForm).then(res => {
            loading.close();
            if (res.data.code === 200) {
              this.$message.success("申请成功");
              this.resetForm();
              this.uploadHistoryByXH();
            } else {
              this.$message.error(res.data.message);
            }
          });
        } else {
          var brr = "";
          brr = this.paperForm.lwgjz.toString();
          this.paperForm.lwgjz = brr;
          this.paperForm.lwgjz.toString();
          console.log(this.paperForm, "第er次提交数据");
          this.$http
            .put(`/api/degree/pfc/${this.xh}`, this.paperForm)
            .then(res => {
              loading.close();
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.uploadHistoryByXH();
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
    },
    // // 文件上传接收附件
    // receiveFJ(res) {
    //   this.paperForm.fj = res.data;
    //   this.fileList = [{name:this.paperForm.fj.fileName,url:this.paperForm.fj.url}]
    //   console.log(this.paperForm.fj)
    // },
    // // 文件移除时清空附件
    // removeFJ() {
    //   this.paperForm.fj = { url: "", fileName: "" };
    // },

    //上传
    cancelupload(index, url) {
      this.fileList.splice(
        this.fileList.findIndex(item => item.url === url),
        1
      );
    },
    handlebefore(file) {
      console.log(file, "111111");
      console.log(
        file.name.lastIndexOf("."),
        file.name.substr(file.name.lastIndexOf("."))
      );
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      var fileobj = file.data;
      this.fileList.splice(0, 1, fileobj);
      console.log(file, fileobj, "111111");
      this.paperForm.fj = fileobj;
      if (file.code == 400) {
        this.$message({
          message: "上传失败，请重新上传",
          type: "error"
        });
        this.$refs.uploadcsv.clearFiles();
      } else {
        this.$message({
          message: "上传成功",
          type: "success"
        });
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles();
        }, 500);
      }
    },

    // 通过学号查询学位论文上传申请提交信息
    uploadHistoryByXH() {
      this.$http.get(`/api/degree/pfc/${this.xh}`).then(res => {
        this.loading = false;
        console.log(res);
        let data = res.data.data;
        // 如果学生没有上传过论文
        if (data === null) {
          return;
        }
        // 如果上传过论文，将论文信息保存，并保存状态和流程id
        Object.keys(this.paperForm).forEach(key => {
          this.paperForm[key] = data[key];
        });
        this.lcid = data.lcid;
        this.status = data.zt;
        // 根据流程id获取审核记录
        this.detailStatus();
        this.uploadShow = true;
        this.fileList = [
          { fileName: this.paperForm.fj.fileName, url: this.paperForm.fj.url }
        ];
        this.uploadData.file = this.paperForm.fj.fileName;
      });
    },
    // 请求论文选题来源
    requireSelectTitle() {
      this.$http.get(`/api/academic/apc/serve/XS-35445`).then(res => {
        console.log(res);
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取可选的选题来源失败，请重试");
          return;
        }
        this.originOption = data;
      });
    },
    // 重置表单的方法
    resetForm() {
      this.paperForm = {
        fj: { url: "", fileName: "" },
        // 论文关键字
        lwgjz: [],
        // 论文类型
        lwlx: "",
        // 论文字数
        lwzs: "",
        // 论文英文题目
        lwywtm: "",
        // 选题来源
        xtly: "",
        // 论文中文题目
        lwzwtm: "",
        // // 论文开始时间
        // lwkssj: "",
        // // 论文终止时间
        // lwzzsj: "",
        // // 英文摘要
        // ywzy: "",
        // // 中文摘要
        // zwzy: "",
        lwyjfx: "" // 论文研究方向
      };
      // 清空附件
      this.$refs.uploadcsv.clearFiles();
    },
    /// /获取审核的历史记录，并将审核的流程数据通过bus进行传值
    detailStatus() {
      this.$http.get("/api/degree/pfc/history/" + this.lcid).then(res => {
        // console.log("aaaa");
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取审核具体流程数据失败，请刷新重试");
          return;
        }
        // 将审核具体流程数据发送给applyStatus
        this.$bus.$emit("stepList", data);
      });
    },
    beginDate() {
      const self = this;
      return {
        disabledDate(time) {
          if (self.paperForm.lwzzsj) {
            //如果结束时间不为空，则小于结束时间
            return new Date(self.paperForm.lwzzsj).getTime() < time.getTime();
          } else {
            // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
          }
        }
      };
    },
    processDate() {
      // const self = this;
      // return {
      //   disabledDate(time) {
      //     if (self.paperForm.lwkssj) {
      //       //如果开始时间不为空，则结束时间大于开始时间
      //       return new Date(self.paperForm.lwkssj).getTime() > time.getTime();
      //     } else {
      //       // return time.getTime() > Date.now()//开始时间不选时，结束时间最大值小于等于当天
      //     }
      //   }
      // };
    },
    lwadd() {
      this.paperForm.lwgjz.push(this.lwgjz);
    },
    // 删除学习和工作经历
    lwdelet(val, index) {
      console.log(val, index, "删除数据");
      this.paperForm.lwgjz.splice(val, 1);
    }
  },
  watch: {
    $route() {
      this.detailStatus();
    },
    status(val) {
      console.log(val);
      if (val == 1 || val == 3) this.writeable = false;
      else this.writeable = true;
      if (val == 1 || val == 3) {
        this.uploadShow = false;
      }
    }
  },
  computed: {
    // 获取学生学号
    xh() {
      return this.$store.getters.getXH;
    },
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>
<style lang="scss" scoped>
.uploadTable {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          // text-align: center;
          background: #fafafa;
        }
        .keywords {
          width: 25%;
          float: left;
        }
        .el-icon-circle-plus {
          width: 15px;
          height: 15px;
          margin-top: 15px;
          margin-left: 5px;
        }
        .el-icon-remove {
          width: 15px;
          height: 15px;
          margin-top: 10px;
          margin-left: 5px;
        }
        .delkeybords {
          display: inline-block;
          border: 1px solid #999;
          background-color: #f5f5f5;
          height: 30px;
          line-height: 10px;
          padding: 2px 10px;
          margin-top: 2px;
          margin-left: 10px;
          border-radius: 6px;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        .danwei {
          line-height: 40px;
          margin-right: 5px;
          color: #ccc;
        }
        &.uploadArea {
          height: 280px;
          background: #fff;
          box-sizing: border-box;
          & > div {
            margin-top: 20px;
            text-align: center;
            color: #00000072;
          }
        }
        &.paperShow {
          height: 85px;
          background: #fff;
        }
      }
    }
  }
}
</style>
