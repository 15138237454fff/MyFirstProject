<template>
  <!-- <div v-if="degreeShow === null || hasQualification === null"></div>
  <div v-else-if="!degreeShow">
    <my-blank msg="模块还未开启哦~" picUrl="blank.png"></my-blank>
  </div> -->
  <div
    class="academicDegreePaperFinalBox"
    v-loading="loading"
    element-loading-text="拼命加载中"
    element-loading-background="rgb(245, 246, 247)"
  >
    <div v-if="tableShow">
      <div v-if="!hasQualification">
        <my-blank
          msg="通过毕业答辩才可上传论文终稿哦~"
          picUrl="blank.png"
        ></my-blank>
      </div>
      <div v-else-if="isPublish && !isFinish">
        <my-blank
          msg="请先完成满意度调查问卷，才可上传论文终稿哦！"
          picUrl="blank.png"
        ></my-blank>
      </div>
      <!-- 学位论文定稿 academicDegreePaperFinal -->
      <div v-else class="main">
        <final-table></final-table>
      </div>
    </div>
  </div>
</template>

<script>
import blank from "@/components/blank";
import finalTable from "./components/finalTable";
export default {
  name: "academicDegreePaperFinal",
  components: {
    "my-blank": blank,
    "final-table": finalTable
  },
  data() {
    return {
      // 是否有资格
      hasQualification: window.sessionStorage.getItem("degreeQualification"),
      // 问卷是否发布，是否完成
      isPublish: window.sessionStorage.getItem("paperPublish"),
      isFinish: window.sessionStorage.getItem("paperFinish"),
      loading: true,
      tableShow: false
    };
  },
  created() {
    // 查询学位时间信息
    this.$store.dispatch("requireDegreeTime");
    // 查询是否有资格上传学位论文
    this.qualification();
    this.requirePublishStatus();
    this.requireFinishStatus();
  },
  computed: {
    // 返回学位显示状态
    degreeShow() {
      return this.$store.getters.getDegreeIng;
    }
  },
  methods: {
    // 查询是否有资格上传学位论文的方法
    qualification() {
      this.$http.get("/api/degree/pfc/qualification").then(res => {
        // console.log(res);
        this.tableShow = true;
        this.loading = false;
        let data = res.data;
        // 如果返回数据为状态码不为200
        if (data.code !== 200) {
          // 没有资格
          this.hasQualification = false;
          window.sessionStorage.setItem("degreeQualification", false);
        } else {
          // 有资格
          this.hasQualification = true;
          window.sessionStorage.setItem("degreeQualification", true);
        }
      });
    },
    requirePublishStatus() {
      this.$http.get("/api/degree/question/serve/status").then(res => {
        let data = res.data.data;
        this.isPublish = data;
        window.sessionStorage.setItem("paperPublish", data);
      });
    },
    requireFinishStatus() {
      this.$http.get("/api/degree/question/serve/isSubmit").then(res => {
        let data = res.data.data;
        this.isFinish = data;
        window.sessionStorage.setItem("paperFinish", data);
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.academicDegreePaperFinalBox {
  width: 100%;
  min-height: calc(100vh - 140px);
}
</style>
