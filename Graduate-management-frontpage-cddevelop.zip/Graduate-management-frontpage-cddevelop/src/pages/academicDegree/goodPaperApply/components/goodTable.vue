<template>
  <div class="goodTable">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>优秀论文申请</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button type="primary" @click="handleSubmit" v-if="writeable">提交</el-button>
      </div>
    </my-breadcrumb>
    <div class="box">
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              table-title="浙江财经大学研究生优秀论文申请"
              :status="userStatus == 1 ? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6">
            <span>|</span> 基本信息
          </th>
          <tr>
            <td>学号</td>
            <td>{{author.xh}}</td>
            <td>姓名</td>
            <td>{{author.xsxm}}</td>
            <td>所属学院</td>
            <td>{{author.ssyxmc}}</td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">论文中文题目</td>
            <td colspan="5">
              <el-input v-model="goodForm.lwzwtm" :disabled="!writeable"></el-input>
            </td>
          </tr>
          <tr>
            <td>论文英文题目</td>
            <td colspan="5">
              <el-input v-model="goodForm.lwywtm" :disabled="!writeable"></el-input>
            </td>
          </tr>
          <tr>
            <td :class=" writeable ? 'required' : '' ">论文答辩日期</td>
            <td>
              <el-date-picker
                :disabled="!writeable"
                v-model="goodForm.lwdbrq"
                type="date"
                placeholder="请选择"
                prefix-icon="el-icon-date"
                style="width:100%;"
              ></el-date-picker>
            </td>
            <td>论文涉及的研究方向</td>
            <td>
              <el-input v-model="goodForm.lwsjyjfx" :disabled="!writeable"></el-input>
            </td>
            <td>论文公开时间</td>
            <td>
              <el-select
                v-model="goodForm.lwgksj"
                placeholder="请选择"
                :disabled="!writeable"
                style="width:100%;"
              >
                <el-option v-for="item in openTimeOptions" :key="item" :label="item" :value="item"></el-option>
              </el-select>
            </td>
          </tr>

          <tr>
            <td>一级学科（专业）名称</td>
            <td>
              <el-input v-model="goodForm.yjxk" :disabled="!writeable"></el-input>
            </td>
            <td>二级学科名称</td>
            <td>
              <el-input v-model="goodForm.ejxk" :disabled="!writeable"></el-input>
            </td>
            <td>
              指导教师姓名
              <br />(如导师组按序填入）
            </td>
            <td>
              <el-input v-model="goodForm.dsxm" :disabled="!writeable"></el-input>
            </td>
          </tr>
          <tr>
            <td>指导教师研究方向</td>
            <td colspan="5">
              <el-input v-model="goodForm.dsyjfx" :disabled="!writeable"></el-input>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <span>|</span> 论文评审情况
          </th>
          <tr>
            <td>同意答辩人数</td>
            <td>
              <el-input v-model="goodForm.tydbrs" :disabled="!writeable" type="number" min="0"></el-input>
            </td>
            <td>同意修改后答辩人数</td>
            <td>
              <el-input v-model="goodForm.tyxghdbrs" :disabled="!writeable" type="number" min="0"></el-input>
            </td>
            <td>推荐校优人数</td>
            <td>
              <el-input v-model="goodForm.tjxyrs" :disabled="!writeable" type="number" min="0"></el-input>
            </td>
          </tr>
          <tr>
            <td>推荐省优人数</td>
            <td>
              <el-input v-model="goodForm.tjsyrs" :disabled="!writeable" type="number" min="0"></el-input>
            </td>
            <td>答辩委员会是否推优</td>
            <td>
              <el-radio-group v-model="goodForm.dbwyhsfty" size="small" :disabled="!writeable">
                <el-radio-button :label="1">是</el-radio-button>
                <el-radio-button :label="0">否</el-radio-button>
              </el-radio-group>
            </td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <td>备注</td>
            <td colspan="5">
              <el-input v-model="goodForm.bz" placeholder="请在备注栏注明攻读学位类别！" :disabled="!writeable"></el-input>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6" class="connect-academic">
            <div>
              <span>|</span> 作者攻博期间及获博士学位后一年内获得与博士学位论文密切相关的代表性成果
            </div>
            <el-button type="primary" @click="connectDialogVisible = true" v-if="writeable">关联成果</el-button>
          </th>
          <tr>
            <td colspan="6">
              <el-table :header-cell-style="$tableHeaderColor" border :data="goodForm.cgxx">
                <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
                <el-table-column prop="resultsName" label="成果名称" align="center"></el-table-column>
                <el-table-column prop="resultsType" label="成果类型" align="center">
                  <template slot-scope="scope">
                    <span>{{scope.row.resultsType|resultsType}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="applyDate" label="时间" align="center">
                  <template slot-scope="scope">
                    <span>{{scope.row.applyDate|toDate}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="attachment" label="相关附件" align="center">
                  <template slot-scope="scope">
                    <a
                      target="_blank"
                      :href="scope.row.attachment.url"
                      :download="scope.row.attachment.fileName"
                      class="primary"
                    >{{scope.row.attachment.fileName}}</a>
                  </template>
                </el-table-column>
                <el-table-column label="操作" width="120" align="center" v-if="writeable">
                  <template slot-scope="scope">
                    <el-button type="text" @click="removeRow(scope.$index)" class="danger">删除</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <div>
              <span>|</span> 论文创新点
            </div>
          </th>
          <tr>
            <td colspan="6">
              <el-input
                type="textarea"
                placeholder="论文主要创新点"
                :row="2"
                v-model="goodForm.lwcxd"
                :disabled="!writeable"
              ></el-input>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6">
            <div>
              <span>|</span> 相关附件
            </div>
          </th>
          <tr>
            <td :class=" writeable ? 'required' : '' ">论文</td>
            <td v-if="writeable">
              <el-upload
                ref="uploadLW"
                action="/api/degree/duc/upload"
                :headers="headers"
                multiple
                :limit="1"
                :on-success="receiveLW"
                :on-remove="removeLW"
                accept=".pdf, .doc, .docx"
              >
                <el-button style="width:117px" icon="el-icon-upload2">上传文件</el-button>
              </el-upload>
            </td>
            <td v-else>
              <a
                :href="goodForm.lw.url"
                target="_blank"
                class="primary"
                :download="goodForm.lw.fileName"
              >{{goodForm.lw.fileName}}</a>
            </td>
            <td :class=" writeable ? 'required' : '' ">评阅表</td>
            <td v-if="writeable">
              <el-upload
                ref="uploadPYB"
                :headers="headers"
                action="/api/degree/duc/upload"
                multiple
                :limit="1"
                :on-success="receivePYB"
                :on-remove="removePYB"
              >
                <el-button style="width:117px" icon="el-icon-upload2">上传文件</el-button>
              </el-upload>
            </td>
            <td v-else>
              <a
                :href="goodForm.pyb.url"
                target="_blank"
                class="primary"
                :download="goodForm.pyb.fileName"
              >{{goodForm.pyb.fileName}}</a>
            </td>
            <td :class=" writeable ? 'required' : '' ">答辩记录表</td>
            <td v-if="writeable">
              <el-upload
                ref="uploadDB"
                :headers="headers"
                action="/api/degree/duc/upload"
                multiple
                :limit="1"
                :on-success="receiveDB"
                :on-remove="removeDB"
              >
                <el-button style="width:117px" icon="el-icon-upload2">上传文件</el-button>
              </el-upload>
            </td>
            <td v-else>
              <a
                :href="goodForm.dbjlb.url"
                target="_blank"
                class="primary"
                :download="goodForm.dbjlb.fileName"
              >{{goodForm.dbjlb.fileName}}</a>
            </td>
          </tr>
        </tbody>
      </table>
      <apply-status-bottom></apply-status-bottom>
    </div>
    <el-dialog title="关联成果" :visible.sync="connectDialogVisible" width="720px">
      <el-table
        :header-cell-style="$tableHeaderColor"
        border
        :data="connetAchieve"
        height="600px"
        @selection-change="handleSelectionChange"
        ref="multipleTable"
      >
        <el-table-column type="selection" width="50" align="center"></el-table-column>
        <el-table-column prop="resultsName" label="成果名称" align="center"></el-table-column>
        <el-table-column prop="resultsType" label="成果类型" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.resultsType|resultsType}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="applyDate" label="时间" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.applyDate|toDate}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="attachment" label="相关附件" align="center" width="120">
          <template slot-scope="scope">
            <a
              target="_blank"
              :href="scope.row.attachment.url"
              class="primary"
              :download="scope.row.attachment.fileName"
            >{{scope.row.attachment.fileName}}</a>
          </template>
        </el-table-column>
      </el-table>
      <div class="confirmBTN">
        <el-button @click="achieveCancel">取消</el-button>
        <el-button type="primary" @click="achieveConfirm">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import tableFlag from '@/components/tableFlag_2'
import applyStatusBottom from '@/components/applyStatusBottom'
import myBreadcrumb from '@/components/myBreadcrumb'
export default {
  name: 'goodTable',
  components: {
    'table-flag': tableFlag,
    'apply-status-bottom': applyStatusBottom,
    'my-breadcrumb': myBreadcrumb
  },
  data () {
    return {
       headers: {
        userToken: this.$store.state.userLoginMsg.userToken
      },
      // 关联成果模态框显示状态
      connectDialogVisible: false,
      // 表单是否可写
      writeable: false,
      // 关联的学术成果列表
      connetAchieve: [],
      // 选择的历史记录
      historySelect: [],
      // 优秀论文提交表单
      goodForm: {
        // 备注
        bz: '',
        // 成果信息
        cgxx: [],
        // 答辩记录表
        dbjlb: {
          url: '',
          fileName: ''
        },
        // 答辩委员会是否推优
        dbwyhsfty: 1,
        // 导师研究方向
        dsyjfx: '',
        // 二级学科
        ejxk: '',
        // 论文
        lw: {
          url: '',
          fileName: ''
        },
        // 论文创新点
        lwcxd: '',
        // 论文答辩日期
        lwdbrq: '',
        // 论文公开时间
        lwgksj: '立即公开',
        // 论文涉及研究方向
        lwsjyjfx: '',
        // 论文英文题目
        lwywtm: '',
        // 论文中文题目
        lwzwtm: '',
        // 评阅表
        pyb: {
          url: '',
          fileName: ''
        },
        // 推荐省优人数
        tjsyrs: '',
        // 推荐校优人数
        tjxyrs: '',
        // 同意答辩人数
        tydbrs: '',
        // 同意修改后答辩人数
        tyxghdbrs: '',
        // 一级学科
        yjxk: '',
        // 导师姓名
        dsxm: ''
      },
      // 审核状态
      status: null,
      // 流程id
      lcid: '',
      // 作者信息
      author: {
        ssyxmc: '', // 学院名称
        xh: '', // 学号
        xsxm: '' // 学生姓名
      },

      // 可选的公开时间
      openTimeOptions: ['立即公开', '一年', '两年', '三年']
    }
  },
  created () {
    // 获取历史申请记录
    this.requireHistoryApply()
    // 获取学生关联的学术成果列表
    this.requireConnectAchieve()
    // 请求申请的学生信息
    this.requireAuthor()
  },
  watch: {
    $route () {
      // 如果流程Id不为空则发送请求
      if (this.lcid) {
        this.detailStatus()
      }
    },
    status (val) {
      console.log(val)
      if (val == 1 || val == 3) this.writeable = false
      else this.writeable = true
    }
  },
  computed: {
    // 获取用户的身份状态
    userStatus () {
      return this.$store.getters.getStatus
    },
    // 返回学生学号
    xh () {
      return this.$store.getters.getXH
    }
  },
  methods: {
    // 提交学位申请信息
    handleSubmit () {
      this.$store.commit('updateDialog', {
        msgTwo: ' ',
        visible: true,
        successCallback: this.submit
      })
    },
    // 提交数据
    submit () {
      console.log(1)
      // 关闭对话框
      this.$store.commit('updateDialog', { visible: false })
      // 附件的字段名称列表
      let fjList = ['lw', 'pyb', 'dbjlb']
      // 保存是否通过表单验证
      let test = true
      // 验证基本类型必填项
      if (this.goodForm.lwzwtm === '' || this.goodForm.lwdbrq === '') {
        this.$message.warning('请填写完整后再尝试提交')
        test = false
        return
      }
      // 遍历附件
      fjList.forEach(key => {
        // 如果附件为空，验证不通过
        if (Object.values(this.goodForm[key]).includes('')) {
          test = false
        }
      })
      // 如果验证通过
      if (test) {
        // 如果不是退回，是提交申请
        if (this.status != 2) {
          // 提交申请
          this.$http
            .post('/api/degree/dpcr/apply', this.goodForm)
            .then(res => {
              if (res.data.code === 200) {
                this.$message.success('申请成功')
                // 再次请求申请状态
                this.requireHistoryApply()
              } else {
                this.$message.error(res.data.message)
              }
            })
        }
        // 如果是退回
        else {
          // 提交申请
          this.$http
            .put(`/api/degree/dpcr/${this.xh}`, this.goodForm)
            .then(res => {
              if (res.data.code === 200) {
                this.$message.success('申请成功')
                // 再次请求申请状态
                this.requireHistoryApply()
              } else {
                this.$message.error(res.data.message)
              }
            })
        }
      }
      // 验证不通过
      else {
        this.$message.warning('请填写完整后再尝试提交')
      }
    },
    // 请求历史学位申请记录
    requireHistoryApply () {
      this.$http.get(`/api/degree/dpcr/${this.xh}`).then(res => {
        let data = res.data.data
        // 如果为null，即没有申请记录
        if (data === null) {
          this.writeable = true
        }
        // 已经申请学位
        else {
          this.writeable = false
          // 更新表单中的信息
          Object.keys(this.goodForm).forEach(key => {
            this.goodForm[key] = data[key]
          })
          // 保存审核状态
          this.status = data.zt
          this.lcid = data.lcid
          this.detailStatus()
        }
      })
    },
    // 获取学生关联的学术成果
    requireConnectAchieve () {
      this.$http.get('/api/academic/aac/relevancy').then(res => {
        let data = res.data.data
        if (!Array.isArray(data)) {
          this.$message.error('获取学生关联的学术成果失败，请重试')
          return
        }
        this.connetAchieve = data
        console.log(this.connetAchieve)
      })
    },
    // 取消选中
    achieveCancel () {
      // 放弃本次选择
      // 清空所有选择
      this.$refs.multipleTable.clearSelection()
      // 根据之前选择的列表勾选对应的成果
      this.goodForm.cgxx.forEach(el => {
        this.$refs.multipleTable.toggleRowSelection(el)
      })
      // 隐藏模态框
      this.connectDialogVisible = false
    },
    // 确认选中
    achieveConfirm () {
      // 将选择的成果添加到选中的成果列表中去
      this.goodForm.cgxx = this.historySelect
      // 隐藏模态框
      this.connectDialogVisible = false
    },
    // 多选改变时触发的事件
    handleSelectionChange (val) {
      // 保存当前的选择记录
      this.historySelect = val
    },
    // 在选中的成果中移除一行
    removeRow (index) {
      let tmp = this.goodForm.cgxx.splice(index, 1)[0]
      this.$refs.multipleTable.toggleRowSelection(tmp)
    },
    /// /获取审核的历史记录，并将审核的流程数据通过bus进行传值
    detailStatus () {
      this.$http.get('/api/degree/dpcr/history/' + this.lcid).then(res => {
        // console.log("aaaa");
        let data = res.data.data
        if (!Array.isArray(data)) {
          this.$message.error('获取审核具体流程数据失败，请刷新重试')
          return
        }
        // 将审核具体流程数据发送给applyStatus
        this.$bus.$emit('stepList', data)
      })
    },
    // 获取作者信息
    requireAuthor () {
      // 请求学生个人信息
      this.$http.get('/api/academic/aac/basic/info').then(res => {
        let data = res.data.data
        // 非空验证
        if (!data) {
          this.$message.error('获取学生信息失败，请重试')
          return
        }
        // 保存学生信息
        this.author = data
      })
    },
    // 文件上传触发的方法
    receiveLW (res) {
      this.goodForm.lw = res.data
    },
    receivePYB (res) {
      this.goodForm.pyb = res.data
    },
    receiveDB (res) {
      this.goodForm.dbjlb = res.data
    },
    // 文件移除触发的方法
    removeLW () {
      this.goodForm.lw = { url: '', fileName: '' }
    },
    removePYB () {
      this.goodForm.pyb = { url: '', fileName: '' }
    },
    removeDB () {
      this.goodForm.dbjlb = { url: '', fileName: '' }
    }
  }
}
</script>
<style lang="scss" scoped>
.goodTable {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    height: calc(100vh - 236px);
    padding: $top;
    overflow: auto;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        &.uploadArea {
          height: 280px;
          background: #fff;
          box-sizing: border-box;
          & > div {
            margin-top: 20px;
            text-align: center;
            color: #00000072;
          }
        }
        &.paperShow {
          height: 85px;
          background: #fff;
        }
      }
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    line-height: 22px;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ebebeb;
  }
  /deep/ .el-dialog__body {
    padding-top: 10px;
    padding-bottom: 10px;
  }
  .confirmBTN {
    margin-top: 10px;
    text-align: center;
  }
}
</style>
