<template>
  <div v-if="degreeShow === null || hasQualification === null"></div>
  <div v-else-if="!degreeShow">
    <my-blank msg="模块还未开启哦~" picUrl="blank.png"></my-blank>
  </div>
  <div v-else-if="!hasQualification">
    <my-blank msg="答辩结果通过后可申请优秀论文哦~" picUrl="blank.png"></my-blank>
  </div>
  <!-- 优秀论文申请 goodPaperApply -->
  <div v-else class="main">
    <good-table></good-table>
  </div>
</template>

<script>
import blank from '@/components/blank'
import goodTable from './components/goodTable'
export default {
  name: 'goodPaperApply',
  components: {
    'my-blank': blank,
    'good-table': goodTable
  },
  data () {
    return {
      // 是否有资格
      hasQualification: null
    }
  },
  created () {
    // 查询学位时间信息
    this.$store.dispatch('requireDegreeTime')
    // 查询有资格申请优秀论文
    this.qualification()
  },
  computed: {
    // 返回学位显示状态
    degreeShow () {
      return this.$store.getters.getDegreeIng
    }
  },
  methods: {
    // 查询是否有资格申请优秀论文的方法
    qualification () {
      this.$http.get('/api/degree/dpcr/qualification').then(res => {
        // console.log(res);
        let data = res.data
        // 如果返回数据为状态码不为200
        if (data.code !== 200) {
          // 没有资格
          this.hasQualification = false
        } else {
          // 有资格
          this.hasQualification = true
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
