<template>
  <div>
    <!-- 学位资格申请 academicDegreeApply -->
    <div v-if="degreeShow === null"></div>
    <div v-else-if="degreeShow" class="main">
      <my-breadcrumb>
        <div slot="left">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <!-- <el-breadcrumb-item :to="{ path: '/academicDegree/academicDegreeApply' }">学位申请</el-breadcrumb-item> -->
            <el-breadcrumb-item>学位资格申请</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
        <div slot="right">
          <el-button
            type="primary"
            @click="handleSubmit"
            v-if="writeable"
            :disabled="studentInfo.hdzxf<minZxf || studentInfo.hdzxf<minXwkZxf"
          >提交</el-button>
        </div>
      </my-breadcrumb>
      <div class="box">
        <table border="1" cellspacing="0" cellpadding="0">
          <thead>
            <th colspan="6">
              <table-flag
                table-title="浙江财经大学研究生学位资格申请"
                :status="!writeable ? `${status}` : null"
                :time="degreeTime|toYMD"
              ></table-flag>
            </th>
          </thead>
          <tbody>
            <th colspan="6">
              <span>|</span> 学生基本信息
            </th>
            <tr>
              <td>学号</td>
              <td>{{studentInfo.xh}}</td>
              <td>姓名</td>
              <td>{{studentInfo.xm}}</td>
              <td>性别</td>
              <td>{{studentInfo.xbm === "1" ? "男" : "女"}}</td>
            </tr>
            <tr>
              <td>出生年月</td>
              <td>{{studentInfo.csrq}}</td>
              <td>身份证号</td>
              <td>{{studentInfo.sfzh}}</td>
              <td>学生类别</td>
              <td>{{studentInfo.xslbmc}}</td>
            </tr>
            <tr>
              <td>所属学院</td>
              <td>{{studentInfo.yxsmc}}</td>
              <td>所属专业</td>
              <td>{{studentInfo.zy}}</td>
              <td>导师</td>
              <td>{{studentInfo.dsxm }}</td>
            </tr>
            <tr>
              <td>取得总学分</td>
              <td>
                <span :class="studentInfo.hdzxf>=minZxf?'primary':'danger'">{{studentInfo.hdzxf}}</span>
                (>{{minZxf}})
              </td>
              <td>学位课总学分</td>
              <td>
                <span
                  :class="studentInfo.hdzxf>=minXwkZxf?'primary':'danger'"
                >{{studentInfo.xwkzxf}}</span>
                (>{{minXwkZxf}})
              </td>
              <td>学位课平均分</td>
              <td>{{studentInfo.xwkzpjf }}</td>
            </tr>
            <tr>
              <td>最后学历</td>
              <td>{{studentInfo.zhxlmc}}</td>
              <td>已获学位</td>
              <td>{{studentInfo.qxwmc}}</td>
              <td>已获学位一级学科</td>
              <td>{{studentInfo.qxwxk }}</td>
            </tr>
            <tr>
              <td>已获学位证书号</td>
              <td>{{studentInfo.qxwzsh}}</td>
              <td>学位授予日期</td>
              <td>{{studentInfo.xwsyrq}}</td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
          <tbody>
            <th colspan="6">
              <span>|</span> 就业信息
            </th>
            <tr>
              <td>单位名称</td>
              <td>
                <el-input v-model="degreeForm.jydw" v-if="writeable"></el-input>
                <span v-else>{{degreeForm.jydw}}</span>
              </td>
              <td>单位性质</td>
              <td>
                <el-input v-model="degreeForm.dwxz" v-if="writeable"></el-input>
                <span v-else>{{degreeForm.jydw}}</span>
              </td>
              <td>单位所在地</td>
              <td>
                <el-input v-model="degreeForm.dwszd" v-if="writeable"></el-input>
                <span v-else>{{degreeForm.dwszd}}</span>
              </td>
            </tr>
          </tbody>
          <tbody>
            <th colspan="6" class="connect-academic">
              <div>
                <span>|</span> 取得代表性成果
              </div>
              <el-button type="primary" @click="connectDialogVisible = true" v-if="writeable">关联成果</el-button>
            </th>
          </tbody>
        </table>
        <el-table :header-cell-style="$tableHeaderColor" border :data="degreeForm.dbxcg">
          <el-table-column label="序号" type="index" width="50" align="center"></el-table-column>
          <el-table-column prop="resultsName" label="成果名称" align="center"></el-table-column>
          <el-table-column prop="resultsType" label="成果类型" align="center">
            <template slot-scope="scope">
              <span>{{scope.row.resultsType|resultsType}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="applyDate" label="时间" align="center">
            <template slot-scope="scope">
              <span>{{scope.row.applyDate|toDate}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="attachment" label="相关附件" align="center">
            <template slot-scope="scope">
              <a
                target="_blank"
                :href="scope.row.attachment.url"
                class="primary"
                :download="scope.row.attachment.fileName"
              >{{scope.row.attachment.fileName}}</a>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="120" align="center" v-if="writeable">
            <template slot-scope="scope">
              <el-button type="text" @click="removeRow(scope.$index)" class="danger">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <apply-status-bottom></apply-status-bottom>
      </div>
      <el-dialog title="关联成果" :visible.sync="connectDialogVisible" width="720px">
        <el-table
          :header-cell-style="$tableHeaderColor"
          border
          :data="connetAchieve"
          height="600px"
          @selection-change="handleSelectionChange"
          ref="multipleTable"
        >
          <el-table-column type="selection" width="50" align="center"></el-table-column>
          <el-table-column prop="resultsName" label="成果名称" align="center"></el-table-column>
          <el-table-column prop="resultsType" label="成果类型" align="center">
            <template slot-scope="scope">
              <span>{{scope.row.resultsType|resultsType}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="applyDate" label="时间" align="center">
            <template slot-scope="scope">
              <span>{{scope.row.applyDate|toDate}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="attachment" label="相关附件" align="center" width="120">
            <template slot-scope="scope">
              <a
                target="_blank"
                :href="scope.row.attachment.url"
                class="primary"
                :download="scope.row.attachment.fileName"
              >{{scope.row.attachment.fileName}}</a>
            </template>
          </el-table-column>
        </el-table>
        <div class="confirmBTN">
          <el-button @click="achieveCancel">取消</el-button>
          <el-button type="primary" @click="achieveConfirm">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div v-else>
      <my-blank msg="模块还未开启哦~" picUrl="blank.png"></my-blank>
    </div>
  </div>
</template>

<script>
import blank from "@/components/blank";
import tableFlag from "@/components/tableFlag_2";
import applyStatusBottom from "@/components/applyStatusBottom";
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "academicDegreeApply",
  components: {
    "my-blank": blank,
    "table-flag": tableFlag,
    "apply-status-bottom": applyStatusBottom,
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      // 关联成果模态框显示状态
      connectDialogVisible: false,
      // 表单是否可写
      writeable: false,
      // 关联的学术成果列表
      connetAchieve: [],
      // 选择的历史记录
      historySelect: [],
      // 学位表单
      degreeForm: {
        // 代表性成果数组
        dbxcg: [
          // {
          //   //创建时间
          //   applyDate: "",
          //   //文件
          //   attachment: { fileName: "", url: "" },
          //   id: "",
          //   //成果名称
          //   resultsName: "",
          //   //成果类型
          //   resultsType: 0
          // }
        ],
        // 单位所在地
        dwszd: "",
        // 单位性质
        dwxz: "",
        // 就业单位
        jydw: ""
      },
      // 学生基本信息
      studentInfo: {},
      // 审核状态
      status: null,
      // 流程id
      lcid: "",
      // 写死变量
      // 最小总学分
      minZxf: 20,
      // 最小学位课总学分
      minXwkZxf: 10
    };
  },
  created() {
    // 查询学位时间信息
    this.$store.dispatch("requireDegreeTime");
    // 获取历史申请记录
    this.requireHistoryApply();
    // 获取学生基本信息
    this.requireStudentInfo();
    // 获取学生关联的学术成果列表
    this.requireConnectAchieve();
  },
  watch: {
    $route() {
      // 如果流程Id不为空则发送请求
      if (this.lcid) {
        this.detailStatus();
      }
    }
  },
  computed: {
    // 返回学位时间信息对象
    degreeTime() {
      return this.$store.getters.getDegreeEndTime;
    },
    // 返回学位显示状态
    degreeShow() {
      return this.$store.getters.getDegreeIng;
    },
    // 返回学生学号
    xh() {
      return this.$store.getters.getXH;
    }
  },
  methods: {
    // 提交学位申请信息
    handleSubmit() {
      this.$store.commit("updateDialog", {
        msgTwo: " ",
        visible: true,
        successCallback: this.submit
      });
    },
    // 提交数据
    submit() {
      // 关闭对话框
      this.$store.commit("updateDialog", { visible: false });

      this.$http.post("/api/degree/degree", this.degreeForm).then(res => {
        if (res.data.code === 200) {
          this.$message.success("申请成功");
          // 再次请求申请状态
          this.requireHistoryApply();
        } else {
          this.$message.error(res.data.message);
        }
      });
    },
    // 请求历史学位申请记录
    requireHistoryApply() {
      this.$http.get(`/api/degree/degree/${this.xh}`).then(res => {
        let data = res.data.data;
        // 如果为null，即没有申请记录
        if (data === null) {
          this.writeable = true;
        }
        // 已经申请学位
        else {
          this.writeable = false;
          // 更新表单中的信息
          Object.keys(this.degreeForm).forEach(key => {
            this.degreeForm[key] = data[key];
          });
          // 保存审核状态
          this.status = data.zt;
          this.lcid = data.lcid;
          this.detailStatus();
        }
      });
    },
    // 获取申请学生基本信息
    requireStudentInfo() {
      this.$http
        .get(`/api/degree/degree/student/basic/${this.xh}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            this.$message.error("获取学生基本信息失败，请重试");
            return;
          }
          this.studentInfo = Object.assign({}, this.studentInfo, data);
        });
    },
    // 获取学生关联的学术成果
    requireConnectAchieve() {
      this.$http.get("/api/academic/aac/relevancy").then(res => {
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取学生关联的学术成果失败，请重试");
          return;
        }
        this.connetAchieve = data;
        console.log(this.connetAchieve);
      });
    },
    // 取消选中
    achieveCancel() {
      // 放弃本次选择
      // 清空所有选择
      this.$refs.multipleTable.clearSelection();
      // 根据之前选择的列表勾选对应的成果
      this.degreeForm.dbxcg.forEach(el => {
        this.$refs.multipleTable.toggleRowSelection(el);
      });
      // 隐藏模态框
      this.connectDialogVisible = false;
    },
    // 确认选中
    achieveConfirm() {
      // 将选择的成果添加到选中的成果列表中去
      this.degreeForm.dbxcg = this.historySelect;
      // 隐藏模态框
      this.connectDialogVisible = false;
    },
    // 多选改变时触发的事件
    handleSelectionChange(val) {
      // 保存当前的选择记录
      this.historySelect = val;
    },
    // 在选中的成果中移除一行
    removeRow(index) {
      let tmp = this.degreeForm.dbxcg.splice(index, 1)[0];
      this.$refs.multipleTable.toggleRowSelection(tmp);
    },
    /// /获取审核的历史记录，并将审核的流程数据通过bus进行传值
    detailStatus() {
      this.$http.get("/api/degree/degree/history/" + this.lcid).then(res => {
        // console.log("aaaa");
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取审核具体流程数据失败，请刷新重试");
          return;
        }
        // 将审核具体流程数据发送给applyStatus
        this.$bus.$emit("stepList", data);
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.main {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    padding: $top;
    height: calc(100vh - 236px);
    overflow: auto;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          text-align: center;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }

        .add {
          font-size: 24px;
          color: #1e6fd9;
          border-radius: 50%;
          padding-left: 20px;
          background: #fff;
          outline: none;
          border: none;
        }
        /deep/ .el-textarea__inner {
          font-size: 14px;
          color: #333;
        }
      }
    }
  }
  /deep/ .el-dialog__title {
    font-size: 14px;
    line-height: 22px;
  }
  /deep/ .el-dialog__header {
    border-bottom: 1px solid #ebebeb;
  }
  /deep/ .el-dialog__body {
    padding-top: 10px;
    padding-bottom: 10px;
  }
  .confirmBTN {
    margin-top: 10px;
    text-align: center;
  }
}
</style>
