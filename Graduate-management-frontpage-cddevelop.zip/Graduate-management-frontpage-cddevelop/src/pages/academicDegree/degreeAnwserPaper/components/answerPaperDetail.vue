<template>
  <div class="answerPaper">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>学位论文</el-breadcrumb-item>
          <el-breadcrumb-item>教育满意度调查</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right"></div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loadingContent"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255, 255, 255, 1)"
    >
      <div class="my-header">
        浙江财经大学研究生教育满意度调查
      </div>
      <div class="paper-content">
        <div class="peper-item" v-for="(item, index) of tableData" :key="index">
          <div class="item-title">
            {{ index + 1 }}. {{ item.tmmc }} ({{ item.tmlx | typeFilter }})
          </div>
          <div class="item-content">
            <template v-if="item.tmlx === 1">
              <span
                v-for="(obj, ind) of item.xxnr"
                :key="ind"
                :class="{ isAnswer: obj.option === item.result }"
              >
                {{ obj.option }}.&nbsp;{{ obj.content }}
              </span>
            </template>
            <template v-if="item.tmlx === 2 && item.result !== null">
              <span
                v-for="(obj, ind) of item.xxnr"
                :key="ind"
                :class="{ isAnswer: item.result.includes(obj.option) }"
              >
                {{ obj.option }}.&nbsp;{{ obj.content }}
              </span>
            </template>
            <template v-if="item.tmlx === 3">
              <div style="padding-bottom:5px;border-bottom:1px solid #ccc">
                <span>{{ item.result === "" ? "无" : item.result }}</span>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "answerPaper",
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      loadingContent: false,
      tableData: []
    };
  },
  filters: {
    typeFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "单选题";
        case 2:
          return "多选题";
        case 3:
          return "问答题";
      }
    }
  },
  mounted() {
    this.loadTable();
  },
  methods: {
    loadTable() {
      this.loadingContent = true;
      // 发送请求列表数据的请求
      this.$http
        .get("/api/degree/question/serve/list")
        .then(res => {
          // 取消列表加载状态
          this.loadingContent = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loadingContent = false;
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.answerPaper {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    height: calc(100vh - 236px);
    padding: $top;
    overflow: auto;
    .my-header {
      font-size: 18px;
      text-align: center;
      line-height: 40px;
      padding-bottom: 10px;
      font-weight: bold;
      border-bottom: 1px solid #eee;
    }
    .required:before {
      margin-right: 0;
    }
    .paper-content {
      padding: 30px 40px;
      .peper-item {
        padding: 20px 0;
        &:not(:last-child) {
          border-bottom: 1px solid #eee;
        }
        .item-title {
          font-weight: bold;
          margin-bottom: 20px;
        }
        .item-content {
          & > span {
            margin-right: 50px;
          }
          .isAnswer {
            color: $blue;
            &:after {
              content: "(✔)";
            }
          }
        }
      }
    }
  }
}
</style>
