<template>
  <div
    class="answerPaper"
    v-loading="loading"
    element-loading-text="提交中"
    element-loading-background="rgba(255, 255, 255, 1)"
  >
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>学位论文</el-breadcrumb-item>
          <el-breadcrumb-item>教育满意度调查</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button type="primary" @click="clickSubmit">提交</el-button>
      </div>
    </my-breadcrumb>
    <div
      class="box"
      v-loading="loadingContent"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255, 255, 255, 1)"
    >
      <div class="my-header">
        浙江财经大学研究生教育满意度调查
      </div>
      <div class="paper-content">
        <div class="peper-item" v-for="(item, index) of tableData" :key="index">
          <div class="item-title" :class="{ required: item.sfbt === 1 }">
            {{ index + 1 }}. {{ item.tmmc }} ({{ item.tmlx | typeFilter }})
          </div>
          <div class="item-content">
            <template v-if="item.tmlx === 1">
              <el-radio-group v-model="item.result">
                <el-radio
                  :label="obj.option"
                  v-for="(obj, ind) of item.xxnr"
                  :key="ind"
                  >{{ obj.option }}.&nbsp;{{ obj.content }}</el-radio
                >
              </el-radio-group>
            </template>
            <template v-if="item.tmlx === 2">
              <el-checkbox-group v-model="item.result">
                <el-checkbox
                  :label="obj.option"
                  v-for="(obj, ind) of item.xxnr"
                  :key="ind"
                  >{{ obj.option }}.&nbsp;{{ obj.content }}</el-checkbox
                >
              </el-checkbox-group>
            </template>
            <template v-if="item.tmlx === 3">
              <el-input v-model="item.result" placeholder="请输入"></el-input>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import myBreadcrumb from "@/components/myBreadcrumb";
export default {
  name: "answerPaper",
  components: {
    "my-breadcrumb": myBreadcrumb
  },
  data() {
    return {
      loading: false,
      loadingContent: false,
      tableData: []
    };
  },
  filters: {
    typeFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "单选题";
        case 2:
          return "多选题";
        case 3:
          return "问答题";
      }
    }
  },
  mounted() {
    this.loadTable();
  },
  methods: {
    loadTable() {
      this.loadingContent = true;
      // 发送请求列表数据的请求
      this.$http
        .get("/api/degree/question/serve/list")
        .then(res => {
          // 取消列表加载状态
          this.loadingContent = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存列表数据
          this.tableData = data.map(el => {
            let result;
            if (el.tmlx === 2) {
              result = [];
            } else {
              result = "";
            }
            return { ...el, result };
          });
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loadingContent = false;
        });
    },
    testForm() {
      let test = true;
      this.tableData.forEach(el => {
        if (!test) return;
        if (el.sfbt === 1 && el.tmlx !== 2) {
          test = el.result !== "";
        } else if (el.sfbt === 1 && el.tmlx === 2) {
          test = el.result.length !== 0;
        }
      });
      return test;
    },
    // 提交学位申请信息
    clickSubmit() {
      console.log(this.tableData);
      if (!this.testForm()) {
        this.$message.error("请将问卷填写完整后再尝试提交");
        return;
      }
      this.$store.commit("updateDialog", {
        msgTwo: " ",
        visible: true,
        successCallback: this.handleSubmit
      });
    },
    // 提交数据
    handleSubmit() {
      // 关闭对话框
      this.$store.commit("updateDialog", { visible: false });
      // 保存表单验证结果，默认为正确
      let tmpArr = this.tableData.map(el => {
        let tmpObj = { ...el };
        if (tmpObj.tmlx === 2) {
          tmpObj.result = tmpObj.result.join(",");
        }
        return { id: tmpObj.id, result: tmpObj.result };
      });
      this.loading = true;
      this.$http.post("/api/degree/question/submit", tmpArr).then(res => {
        this.loading = false;
        if (res.data.code === 200) {
          this.$message.success("提交成功");
          this.$emit("submitSuccess");
        } else {
          this.$message.error(res.data.message);
        }
      });
    }
  },
  computed: {
    // 获取学生学号
    xh() {
      return this.$store.getters.getXH;
    },
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>
<style lang="scss" scoped>
.answerPaper {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    height: calc(100vh - 236px);
    padding: $top;
    overflow: auto;
    .my-header {
      font-size: 18px;
      text-align: center;
      line-height: 40px;
      padding-bottom: 10px;
      font-weight: bold;
      border-bottom: 1px solid #eee;
    }
    .required:before {
      margin-right: 0;
    }
    .paper-content {
      padding: 30px 40px;
      .peper-item {
        padding: 20px 0;
        &:not(:last-child) {
          border-bottom: 1px solid #eee;
        }
        .item-title {
          font-weight: bold;
          margin-bottom: 20px;
        }
      }
    }
  }
}
</style>
