<template>
  <div class="uploadTable">
    <my-breadcrumb>
      <div slot="left">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item
            :to="{ path: '/academicDegree/academicDegreeApply' }"
            >学位申请</el-breadcrumb-item
          >
          <el-breadcrumb-item>学位论文上传</el-breadcrumb-item>
          <el-breadcrumb-item v-show="detile">论文评阅书</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div slot="right">
        <el-button type="primary" @click="handleSubmit" v-if="writeable"
          >提交</el-button
        >
        <el-button type="primary" @click="handleReturn" v-show="detile"
          >返回</el-button
        >
      </div>
    </my-breadcrumb>
    <div
      class="box"
      v-show="!detile"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-background="rgba(255, 255, 255, 1)"
    >
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <th colspan="6">
            <table-flag
              table-title="浙江财经大学研究生论文上传"
              :status="userStatus == 1 ? `${status}` : null"
            ></table-flag>
          </th>
        </thead>
        <tbody>
          <th colspan="6"><span>|</span> 论文关键信息</th>
          <tr>
            <td :class="writeable ? 'required' : ''">论文中文题目</td>
            <td colspan="5">
              <el-input v-model="paperForm.xwlwtm" v-if="writeable"></el-input>
              <span v-if="!writeable" class="disable">{{
                paperForm.xwlwtm
              }}</span>
            </td>
          </tr>
          <tr>
            <td :class="writeable ? 'required' : ''">论文英文题目</td>
            <td colspan="5">
              <el-input
                v-model="paperForm.xwlwywtm"
                v-if="writeable"
              ></el-input>
              <span v-if="!writeable" class="disable">{{
                paperForm.xwlwywtm
              }}</span>
            </td>
          </tr>
          <tr>
            <td :class="writeable ? 'required' : ''">论文字数</td>
            <td>
              <el-input v-model="paperForm.lwzs" v-if="writeable" type="number">
                <i slot="suffix" class="danwei">万</i>
              </el-input>
              <span v-if="!writeable" class="disable"
                >{{ paperForm.lwzs }}万</span
              >
            </td>
            <td :class="writeable ? 'required' : ''">论文类型</td>
            <td>
              <el-input v-model="paperForm.lwlx" v-if="writeable"></el-input>
              <span v-if="!writeable" class="disable">{{
                paperForm.lwlx
              }}</span>
            </td>
            <td :class="writeable ? 'required' : ''">选题来源</td>
            <td>
              <el-select
                v-model="paperForm.xtly"
                v-if="writeable"
                style="width:100%;"
              >
                <el-option
                  v-for="(item, index) in originOption"
                  :key="index"
                  :label="item.name"
                  :value="item.name"
                ></el-option>
              </el-select>
              <span v-if="!writeable" class="disable">{{
                paperForm.xtly | xtlyFilter(originOption)
              }}</span>
            </td>
          </tr>
          <tr>
            <td :class="writeable ? 'required' : ''">论文关键词</td>
            <td colspan="5" style="background:#fff;">
              <el-input
                v-model="lwgjz"
                v-if="writeable"
                placeholder="请输入关键词3-5个，以“，”间隔"
                class="keywords"
              ></el-input>
              <i
                class="el-icon-circle-plus"
                style="color:#409eff"
                @click="lwadd"
                v-if="paperForm.lwgjz.length != -1 && writeable"
              ></i>
              <div v-if="writeable" style="display:inline-block;">
                <div
                  class="delkeybords"
                  v-for="(lwzList, index) in paperForm.lwgjz"
                  :key="index"
                >
                  {{ lwzList
                  }}<i
                    class="el-icon-remove"
                    style="color:#f56c6c"
                    @click="lwdelet(lwzList, index)"
                  ></i>
                </div>
              </div>
              <span v-if="!writeable" class="disable">{{
                paperForm.lwgjz.join(", ")
              }}</span>
            </td>
          </tr>
          <tr>
            <td :class="writeable ? 'required' : ''">论文研究方向</td>
            <td colspan="5">
              <el-input v-model="paperForm.lwyjfx" v-if="writeable"></el-input>
              <span v-if="!writeable" class="disable">{{
                paperForm.lwyjfx
              }}</span>
            </td>
          </tr>
        </tbody>
        <tbody>
          <th colspan="6"><span>|</span> 论文附件上传</th>
          <tr>
            <td colspan="6" class="uploadArea" v-if="uploadShow">
              <!-- <el-upload
                ref="upload"
                action="/api/degree/duc/upload"
                multiple
                :file-list="fileList"
                :show-file-list="true"
                :on-success="receiveFJ"
                :on-remove="removeFJ"
                accept=".pdf, .doc, .docx"
              >
                <el-button style="width:117px" icon="el-icon-upload2"
                  >上传文件</el-button
                >
              </el-upload> -->
              <el-upload
                action="/api/degree/duc/upload"
                :data="uploadData"
                :limit="1"
                :before-upload="handlebefore"
                :on-success="handleSuccess"
                ref="uploadcsv"
                accept=".pdf, .doc, .docx"
                :headers="headtoken"
              >
                <el-button style="width:350px" icon="el-icon-upload"
                  >点击上传</el-button
                >
              </el-upload>
              <div>
                <li v-for="(item, index) in fileList" :key="index">
                  <i class="el-icon-document"></i
                  ><a
                    style="margin-right:20px;margin-left:10px"
                    :href="item.url"
                    target="_blank"
                    :download="item.fileName"
                    >{{ item.fileName }}</a
                  >
                  <i
                    class="el-icon-close"
                    @click="cancelupload(index, item.url)"
                  ></i>
                </li>
                <li
                  style="margin-left:20px;margin-top:20px;"
                  class="el-upload__tip"
                >
                  只能上传后缀为.docx或.pdf的文件！
                </li>
              </div>
            </td>
            <td colspan="6" class="paperShow" v-if="!uploadShow">
              <a
                :href="paperForm.fj.url"
                target="_blank"
                class="primary"
                :download="paperForm.fj.fileName"
                >{{ paperForm.fj.fileName }}</a
              >
            </td>
          </tr>
        </tbody>
        <tbody v-if="status == 1 || status == 2 || status == 3">
          <th colspan="6" class="connect-academic">
            <div><span>|</span> 论文检测结果</div>
          </th>
          <tr>
            <td>重复率</td>
            <td colspan="2" v-if="cfl == null">
              <span style="color:#ccc">暂未检测</span>
            </td>
            <td colspan="2" :class="cfl <= 15 ? 'primary' : 'danger'" v-else>
              <span>{{ cfl }}%</span>
            </td>
            <td>送审结果</td>
            <!-- <td colspan="2" v-if="ssjg == 0">
              <span style="color:#ccc">暂未送审</span>
            </td> -->
            <td colspan="2">
              <span
                style="float:left"
                v-for="(scores, index) in scoreArr"
                :key="index"
                ><i :class="scores >= 70 ? 'primary' : 'danger'">{{ scores }}</i
                ><i v-if="index < scoreArr.length - 1">,</i></span
              >
              <button
                class="results"
                @click="seeResults"
                :class="{ disResults: type == 0 }"
              >
                论文评阅书
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <apply-status-bottom></apply-status-bottom>
    </div>
    <div class="box" v-show="detile">
      <upload-detile></upload-detile>
    </div>
  </div>
</template>
<script>
import tableFlag from "@/components/tableFlag_2";
import applyStatusBottom from "@/components/applyStatusBottom";
import myBreadcrumb from "@/components/myBreadcrumb";
import uploadDetile from "../components/uploadDetile";

export default {
  name: "uploadTable",
  props: {
    id: 0
  },
  components: {
    tableFlag,
    applyStatusBottom,
    uploadDetile,
    "my-breadcrumb": myBreadcrumb
  },
  filters: {
    ssjgFilter(ssjg) {
      // console.log(typeof ssjg);
      switch (ssjg) {
        case 0:
          return "不通过";
        case 1:
          return "通过";
        case 2:
          return "待审核";
      }
    },
    xtlyFilter(val, option) {
      let filts;
      console.log(val, option);
      option.find(itm => {
        if (itm.name == val) {
          filts = itm.name;
        }
      });
      return filts;
    }
  },
  data() {
    return {
      index: 0,
      loading: false,
      // 是否可以写入
      writeable: true,
      // 是否已经上传过论文
      isshow: false,
      // hasUpload:false,
      // 待提交的表单数据
      // 论文关键字
      lwgjz: "",
      paperForm: {
        fj: { url: "", fileName: "" },
        lwgjz: [],
        // 论文类型
        lwlx: "",
        // 论文字数
        lwzs: "",
        // 选题来源
        xtly: "",
        // 学位论文题目
        xwlwtm: "",
        xwlwywtm: "", // 论文英文题目
        lwyjfx: "" // 论文研究方向
      },
      // 审核状态
      status: null,
      // 流程id
      lcid: "",
      // 重复率
      cfl: "",
      // 送审结果
      ssjg: "",
      //成绩
      score: "",
      scoreArr: [],
      //是否可查看送审成绩详情
      type: "",
      // 选题来源可选项
      originOption: [],
      detile: false,
      uploadShow: true,
      fileList: [],
      //上传
      uploadData: {
        file: ""
      },
      headtoken: {
        userToken: this.$store.state.userLoginMsg.userToken
      }
    };
  },
  created() {
    // 当前登录为学生
    if (this.userStatus == 1) {
      // 请求提交论文的历史记录
      this.uploadHistoryByXH();
      // 获取论文选题的可选列表
      this.requireSelectTitle();
    }
  },
  methods: {
    // 提交学位申请信息
    handleSubmit() {
      this.$store.commit("updateDialog", {
        msgTwo: " ",
        visible: true,
        successCallback: this.submit
      });
    },
    // 提交数据
    submit() {
      // 关闭对话框
      this.$store.commit("updateDialog", { visible: false });
      // 保存表单验证结果，默认为正确
      let test = true;
      if (this.lwgjz.length > 20) {
        this.$message.warning("论文关键字不可超过20字");
        return;
      }
      let regArr = /^[\u4e00-\u9fa5_a-zA-Z0-9]+$/;
      if (regArr.test(this.lwgjz)) {
        this.$message.warning("论文关键字不可包含特殊字符和空格");
        return;
      }
      if (this.paperForm.lwgjz.length < 3 || this.paperForm.lwgjz.length > 5) {
        this.$message.warning("论文关键字大于3个小于5个");
        return;
      }
      Object.keys(this.paperForm).forEach(key => {
        console.log(key, "每一项数据");
        // 如果必填项为空,验证失败
        if (this.paperForm[key] === "") {
          this.$message.warning("将信息填写完整后再提交");
          // console.log(key)
          test = false;
          return;
        }
        if (key === "lwzs" && this.paperForm.lwzs <= 0) {
          this.$message.warning("论文字数应为正数");
          test = false;
          return;
        }
        // 如果没有上传附件,验证失败
        if (key === "fj" && Object.values(this.paperForm.fj).includes("")) {
          this.$message.warning("将信息填写完整后再提交");
          test = false;
        }
      });
      // 如果验证成功，提交表单数据
      if (test) {
        this.loading = true;
        if (this.status != 2) {
          var arr = "";
          arr = this.paperForm.lwgjz.toString();
          this.paperForm.lwgjz = arr;
          this.paperForm.lwgjz.toString();
          console.log(this.paperForm, "上传论文");
          this.$http.post("/api/degree/duc/apply", this.paperForm).then(res => {
            this.loading = false;
            if (res.data.code === 200) {
              this.$message.success("申请提交成功");
              this.resetForm();
              this.uploadHistoryByXH();
            } else {
              this.$message.error(res.data.message);
            }
          });
        } else {
          var brr = "";
          brr = this.paperForm.lwgjz.toString();
          this.paperForm.lwgjz = brr;
          console.log(this.paperForm, "二次上传");
          this.$http
            .put(`/api/degree/duc/${this.xh}`, this.paperForm)
            .then(res => {
              this.loading = false;
              if (res.data.code === 200) {
                this.$message.success("申请成功");
                this.uploadHistoryByXH();
              } else {
                this.$message.error(res.data.message);
              }
            });
        }
      }
    },
    //上传方法
    //上传
    cancelupload(index, url) {
      this.fileList.splice(
        this.fileList.findIndex(item => item.url === url),
        1
      );
    },
    handlebefore(file) {
      this.uploadData.file = file.name;
    },
    // csv文件上传成功
    handleSuccess(file, fileList) {
      var fileobj = file.data;
      this.fileList.splice(0, 1, fileobj);
      this.paperForm.fj = fileobj;
      console.log(this.fileList, "1111111111111");
      if (file.code == 400) {
        this.$message({
          message: "上传失败，请重新上传",
          type: "error"
        });
        this.$refs.uploadcsv.clearFiles();
      } else {
        this.$message({
          message: "上传成功",
          type: "success"
        });
        setTimeout(() => {
          this.$refs.uploadcsv.clearFiles();
        }, 500);
      }
    },
    // 文件上传接收附件
    // receiveFJ(res) {
    //   this.paperForm.fj = res.data;
    //   this.fileList = [
    //     { name: this.paperForm.fj.fileName, url: this.paperForm.fj.url }
    //   ];
    //   console.log(this.paperForm.fj);
    // },
    // // 文件移除时清空附件
    // removeFJ() {
    //   this.paperForm.fj = { url: "", fileName: "" };
    // },
    // 通过学号查询学位论文上传申请提交信息
    uploadHistoryByXH() {
      this.$http.get(`/api/degree/duc/${this.xh}`).then(res => {
        let data = res.data.data;
        console.log(data, "查询学位论文上传申请提交信息");
        // 如果学生没有上传过论文
        if (data === null) {
          return;
        } else if (data.fj == null) {
          this.isshow = true;
        }
        // 如果上传过论文，将论文信息保存，并保存状态和流程id
        Object.keys(this.paperForm).forEach(key => {
          this.paperForm[key] = data[key];
        });
        this.paperForm.lwgjz = this.paperForm.lwgjz
          .split(",")
          .filter(el => el !== "");
        this.lcid = data.lcid;
        this.status = data.zt;
        this.cfl = data.cfl;
        this.ssjg = data.ssjg;
        this.score = data.score;
        this.scoreArr = data.score.split(",");
        this.type = data.type;
        this.detailStatus();
        this.uploadShow = true;
        this.fileList = [
          { fileName: this.paperForm.fj.fileName, url: this.paperForm.fj.url }
        ];
      });
    },
    // 请求论文选题来源
    requireSelectTitle() {
      this.$http.get(`/api/academic/apc/serve/XS-35445`).then(res => {
        let data = res.data.data;
        this.originOption = data;
        // console.log(this.originOption,'论文的选题来源')
        if (!Array.isArray(data)) {
          this.$message.error("获取可选的选题来源失败，请重试");
          return;
        }
      });
    },
    // 重置表单的方法
    resetForm() {
      this.paperForm = {
        fj: { url: "", fileName: "" },
        // 论文关键字
        lwgjz: [],
        // 论文类型
        lwlx: "",
        // 论文字数
        lwzs: "",
        // 选题来源
        xtly: "",
        // 学位论文题目
        xwlwtm: "",
        lwyjfx: "", // 论文研究方向
        xwlwywtm: "" //学位论文英文题目
      };
      // 清空附件
      this.$refs.uploadcsv.clearFiles();
    },
    /// /获取审核的历史记录，并将审核的流程数据通过bus进行传值
    detailStatus() {
      this.$http.get("/api/degree/duc/history/" + this.lcid).then(res => {
        // console.log("aaaa");
        let data = res.data.data;
        if (!Array.isArray(data)) {
          this.$message.error("获取审核具体流程数据失败，请刷新重试");
          return;
        }
        // 将审核具体流程数据发送给applyStatus
        this.$bus.$emit("stepList", data);
      });
    },
    // 查看送审成绩
    seeResults() {
      console.log("查看成绩详情");
      console.log(this.type, "当前类型");
      if (this.type == 0) {
        return;
      }
      this.detile = !this.detile;
    },
    // 查看详情的返回按钮
    handleReturn() {
      this.detile = !this.detile;
    },
    lwadd() {
      if (this.paperForm.lwgjz.length > 4) {
        this.$message.error("最多添加五个关键字");
        this.lwgjz = "";
        return;
      }
      if (this.lwgjz === "") {
        this.$message.error("关键字不能为空");
        return;
      }
      if (this.lwgjz.length > 20) {
        this.$message.error("关键字不能超过20位");
        this.lwgjz = "";
        return;
      }
      this.paperForm.lwgjz.push(this.lwgjz);
      this.lwgjz = "";
    },
    // 删除学习和工作经历
    lwdelet(val, index) {
      console.log(val, index, "删除数据");
      this.paperForm.lwgjz.splice(index, 1);
    }
  },
  watch: {
    $route() {
      this.detailStatus();
    },
    status(val) {
      // console.log(val)
      if (val == 1 || val == 3) this.writeable = false;
      else this.writeable = true;
      if (val == 1 || val == 3) {
        this.uploadShow = false;
      }
    }
  },
  computed: {
    // 获取学生学号
    xh() {
      return this.$store.getters.getXH;
    },
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>
<style lang="scss" scoped>
.uploadTable {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    height: calc(100vh - 236px);
    padding: $top;
    overflow: auto;
    table {
      width: 100%;
      border-collapse: collapse;
      color: #333;
      border: none;
      border-color: rgba(228, 228, 228, 1);
      thead > th {
        text-align: center;
        font-size: 20px;
        padding: 10px;
        line-height: 40px;
        overflow: hidden;
      }
      tbody > th {
        text-align: left;
        font-weight: 700;
        padding: 11px 2px 11px 10px;
        background: #e4e4e4;
        span {
          color: #1890ff;
        }
        &.connect-academic {
          position: relative;
          .el-button {
            position: absolute;
            right: 10px;
            top: 0;
          }
        }
      }
      td {
        width: 200px;
        height: 40px;
        .disable {
          // display: inline-block;
          // cursor: not-allowed;
          // width:100%;
          // text-align: left;
          // color: #C0C4CC
        }
        .keywords {
          width: 25%;
          float: left;
        }
        .el-icon-circle-plus {
          font-size: 30px;
          line-height: 40px;
          margin-left: 5px;
        }
        .el-icon-remove {
          width: 15px;
          height: 15px;
          margin-top: 10px;
          margin-left: 5px;
        }
        .delkeybords {
          display: inline-block;
          border: 1px solid #999;
          background-color: #f5f5f5;
          height: 30px;
          line-height: 10px;
          padding: 2px 10px;
          margin-top: 2px;
          margin-left: 10px;
          border-radius: 6px;
        }
        .results {
          float: right;
          border-radius: 5%;
          border: 0;
          background-color: #429dff;
          color: #fff;
          padding: 3px;
          cursor: pointer;
        }
        .disResults {
          background-color: #ccc;
          cursor: not-allowed;
        }
        &:nth-child(odd) {
          background: #f2f2f2;
          padding-left: 10px;
        }
        &:nth-child(even) {
          // text-align: center;
          background: #fafafa;
        }
        .range /deep/ .el-input {
          width: 25%;
        }
        &.uploadArea {
          height: 280px;
          background: #fff;
          box-sizing: border-box;
          & > div {
            margin-top: 20px;
            text-align: center;
            color: #00000072;
          }
        }
        &.paperShow {
          height: 85px;
          background: #fff;
        }
        .danwei {
          line-height: 40px;
          margin-right: 5px;
          color: #ccc;
        }
      }
    }
  }
}
</style>
