<template>
  <div class="uploadDetile">
    <div class="box">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane
          v-for="(tabs, index) in tableData"
          :key="index"
          :label="tabs.tabLabel"
          :name="index | toStr"
        >
          <div class="boxsafe">
            <table border="1" cellspacing="0" cellpadding="0">
              <th colspan="4">论文信息</th>
              <tr>
                <td>论文中文题目</td>
                <td colspan="3">{{ tabs.xwlwtm }}</td>
              </tr>
              <tr>
                <td>论文英文题目</td>
                <td  colspan="3">{{ tabs.xwlwywtm }}</td>
              </tr>
              <tr>
                <td>论文字数</td>
                <td>{{ tabs.lwzs }}</td>
                <td>论文类型</td>
                <td>{{ tabs.lwlx }}</td>
              </tr>
              <tr>
                <td>选题来源</td>
                <td>{{ tabs.xtly }}</td>
                <td>论文关键词</td>
                <td>{{ tabs.lwgjz }}</td>
              </tr>
              <tr>
                <td>论文研究方向</td>
                <td>{{ tabs.lwyjfx }}</td>
                <td>论文附件</td>
                <td>
                  <a
                    :href="tabs.fj.url"
                    target="_blank"
                    :download="tabs.fj.fileName"
                    >{{ tabs.fj.fileName }}</a
                  >
                </td>
              </tr>
            </table>
          </div>
          <div class="boxmsg" v-if="tabs.pszbVOList.length">
            <th colspan="4">评审信息</th>
            <table border="1" cellspacing="0" cellpadding="0">
              <th colspan="4">
                <span style="float:left">|论文评分</span>
                <span
                  style="float:right"
                  :class="tabs.zf >= 70 ? 'primary' : 'danger'"
                  >总分:{{ tabs.zf }}</span
                >
              </th>
              <tr class="boxmsgtr1">
                <td>一级指标</td>
                <td>二级指标和评价要点</td>
                <td>项目满分</td>
                <td>评分</td>
              </tr>
              <tr v-for="(item,index) in tabs.pszbVOList" :key="index">
                <td>{{item.nr}}</td>
                <td>{{ item.zb }}</td>
                <td>{{ item.fs }}</td>
                <td>{{ item.pf }}</td>
              </tr>
              <!-- <tr>
                <td>选题与综述</td>
                <td>{{ tabs.pszbVOList[0].zb }}</td>
                <td>{{ tabs.pszbVOList[0].fs }}</td>
                <td>{{ tabs.pszbVOList[0].pf }}</td>
              </tr>
              <tr>
                <td>内容与结构</td>
                <td>{{ tabs.pszbVOList[1].zb }}</td>
                <td>{{ tabs.pszbVOList[1].fs }}</td>
                <td>{{ tabs.pszbVOList[1].pf }}</td>
              </tr>
              <tr v-if="tabs.pszbVOList.length > 2">
                <td>创新性</td>
                <td>{{ tabs.pszbVOList[2].zb }}</td>
                <td>{{ tabs.pszbVOList[2].fs }}</td>
                <td>{{ tabs.pszbVOList[2].pf }}</td>
              </tr>
              <tr v-if="tabs.pszbVOList.length > 3">
                <td>格式规范</td>
                <td>{{ tabs.pszbVOList[0].zb }}</td>
                <td>{{ tabs.pszbVOList[0].fs }}</td>
                <td>{{ tabs.pszbVOList[0].pf }}</td>
              </tr>
              <tr v-if="tabs.pszbVOList.length > 4">
                <td>一级指标</td>
                <td>{{ tabs.pszbVOList[0].zb }}</td>
                <td>{{ tabs.pszbVOList[0].fs }}</td>
                <td>{{ tabs.pszbVOList[0].pf }}</td>
              </tr>
              <tr v-if="tabs.pszbVOList.length > 5">
                <td>二级指标</td>
                <td>{{ tabs.pszbVOList[0].zb }}</td>
                <td>{{ tabs.pszbVOList[0].fs }}</td>
                <td>{{ tabs.pszbVOList[0].pf }}</td>
              </tr> -->
              <th colspan="4">评审意见</th>
              <tr>
                <td colspan="4">{{ tabs.psyj }}</td>
              </tr>
            </table>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
export default {
  name: "uploadDetile",
  data() {
    return {
      activeName: "0",
      tabsData: {
        xwlwtm: "", //名称
        xwlwywtm: "", //学位论文英文题目
        xtly: "", //来源
        lwgjz: "", //关键字
        lwlx: "", //论文类型
        lwzs: "", //论文字数（万）
        lwyjfx: "", //论文研究方向
        fj: {
          fileName: "",
          url: ""
        },
        pszbVOList: [], //指标数据
        psyj: "" //评审意见
      },
      tableData: []
    };
  },
  created() {
    this.getData();
  },
  filters: {
    toStr(val) {
      return val.toString();
    }
  },
  methods: {
    handleClick(tab, event) {
      // console.log(tab, event);
    },
    getData() {
      this.$http
        .get("/api/degree/duc/selectCheckInfo", {
          params: { xh: this.xh, lx: "1" }
        })
        .then(res => {
          if (res.data.code == 200) {
            // this.tableData=[{zf:'50',fj:{},xwlwtm:'111111'},{zf:'90',fj:{}}]
            this.tableData = res.data.data;
            this.tableData.forEach((val, index) => {
              val.tabLabel = `送审结果${index + 1} (${val.zf}分)`;
            });
          }
        });
    }
  },
  computed: {
    // 获取学生学号
    xh() {
      return this.$store.getters.getXH;
    },
    // 获取用户的身份状态
    userStatus() {
      return this.$store.getters.getStatus;
    }
  }
};
</script>
<style lang="scss" scoped>
.uploadDetile {
  .box {
    border: 1px solid rgba(228, 228, 228, 1);
    background-color: #fff;
    height: calc(100vh - 236px);
    padding: $top;
    overflow: auto;
    .boxsafe {
      border: 1px solid rgba(228, 228, 228, 1);
      background-color: #fff;
      padding: 10px;
      th {
        text-align: left;
        font-size: 14px;
        height: 20px;
        padding: 0 10px 10px 10px;
      }
      table {
        width: 95%;
        margin: 0 auto;
        border-collapse: collapse;
        color: #333;
        border: none;
        border-color: rgba(228, 228, 228, 1);
        th {
          font-size: 14px;
          height: 20px;
          padding: 10px;
          background: #f2f2f2;
        }
        td {
          width: 200px;
          height: 40px;
          &:nth-child(odd) {
            background: #f2f2f2;
            padding-left: 10px;
          }
          &:nth-child(even) {
            text-align: center;
            background: #fafafa;
          }
          .range /deep/ .el-input {
            width: 25%;
          }
          &.uploadArea {
            height: 280px;
            background: #fff;
            box-sizing: border-box;
            & > div {
              margin-top: 20px;
              text-align: center;
              color: #00000072;
            }
          }
        }
      }
    }
    .boxmsg {
      border: 1px solid rgba(228, 228, 228, 1);
      background-color: #fff;
      padding: 10px;
      margin-top: 20px;
      th {
        text-align: left;
        font-size: 14px;
        height: 20px;
        padding: 0 10px 10px 10px;
      }
      table {
        width: 95%;
        margin: 0 auto;
        border-collapse: collapse;
        color: #333;
        border: none;
        border-color: rgba(228, 228, 228, 1);
        th {
          font-size: 14px;
          height: 20px;
          padding: 10px;
          background: #f2f2f2;
        }
        .boxmsgtr1 {
          background: #f2f2f2;
        }
        td {
          width: 200px;
          height: 40px;
        }
      }
    }
  }
}
</style>
