<template>
  <div
    v-loading="loading"
    element-loading-text="拼命加载中"
    element-loading-background="rgba(255, 255, 255, 1)"
    class="academicDegreePaperUploadBox"
  >
    <!--<div v-if="!degreeShow || !hasQualification">
      <my-blank msg="未通过预答辩，不能上传学位论文！" picUrl="blank.png"></my-blank>
    </div>-->
    <!--<div v-else-if="!degreeShow">
    <my-blank msg="未通过预答辩，不能上传学位论文！" picUrl="blank.png"></my-blank>
  </div>-->
    <!-- <div v-else-if="!hasQualification">
    <my-blank msg="请先完成学位资格申请，才可以上传论文哦~" picUrl="blank.png"></my-blank>
  </div> -->
    <!-- 学位论文上传 academicDegreePaperUpload -->
    <div class="main" v-show="hasQualification">
      <upload-table></upload-table>
    </div>
    <div v-show="loadTable" class="my-blank-box">
      <my-blank
        msg="未通过预答辩，不能上传学位论文！"
        picUrl="blank.png"
      ></my-blank>
    </div>
  </div>
</template>

<script>
import blank from "@/components/blank";
import uploadTable from "./components/uploadTable";
export default {
  name: "academicDegreePaperUpload",
  components: {
    "my-blank": blank,
    "upload-table": uploadTable
  },
  data() {
    return {
      // 是否有资格
      loading: false,
      loadTable: false,
      hasQualification: false
    };
  },
  created() {
    // 查询学位时间信息
    this.$store.dispatch("requireDegreeTime");
    this.qualification();
  },
  computed: {
    // 返回学位显示状态
    degreeShow() {
      return this.$store.getters.getDegreeIng;
    }
  },
  methods: {
    // 查询是否有资格上传学位论文的方法
    qualification() {
      // this.loading = this.$loading({
      //     lock: true,
      //     text: 'Loading',
      //     spinner: 'el-icon-loading',
      //     background: 'rgba(255, 255, 255, 1)',
      //     fullscreen:true
      // });
      this.loading = true;
      this.$http.get("/api/degree/duc/qualification").then(res => {
        let data = res.data;
        // 如果返回数据为状态码不为200
        if (data.code == 200) {
          // 没有资格
          this.hasQualification = true;
        } else {
          // 有资格
          this.loadTable = true;
        }
        setTimeout(() => {
          this.loading = false;
        }, 2000);
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.academicDegreePaperUploadBox {
  width: 100%;
  min-height: calc(100vh - 140px);
}
</style>
