import { request } from "http";

export function getData(type,query){
    return request({
        url: '/api/xjydsq/'+type,
        method: 'get',
        params: query
    }
}