const isBuild = false
const myDate = new Date()
var logTime = myDate.toLocaleString()
var currentlevel = 3
// 获取日期与时间
const Log = (Vue) => {
  Vue.prototype.$log = new Vue({
    methods: {
      // 强烈日志...DEBUG
      DEBUG(...params) {
        if (!isBuild && currentlevel <= 1) {
          console.log(`${logTime}DEBUG`, ...params, 'DEBUG')
        }
      },
      // 信息
      INFO(...params) {
        if (!isBuild && currentlevel <= 2) {
          console.info(`${logTime}INFO`, ...params, 'INFO')
        }
      },
      // 警告
      WARN(...params) {
        if (!isBuild && currentlevel <= 3) {
          console.warn(`${logTime}⚠WARN`, ...params, 'WARN⚠')
        }
      },
      // 信息
      ERROR(...params) {
        if (!isBuild && currentlevel <= 4) {
          console.error(`${logTime}❌ERROR`, ...params, 'ERROR❌')
        }
      },
      // 致命
      FATAL(...params) {
        if (!isBuild && currentlevel <= 5) {
          console.error(`${logTime}❌FATAL`, ...params, 'FATAL❌')
        }
      },
      currentmethod(params) {
        currentlevel = params
      }
    }
  })
}
export default Log