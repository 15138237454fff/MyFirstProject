import Vue from 'vue'
import VueRouter from 'vue-router'
import login from '../pages/login/index'
import Main from '../pages'
import store from '../store'
import Register from '../pages/register/register'
import noFound from '../components/404'
import noPerm from '../components/403'
import forgotPassword from '../components/forgotPassword'

// 通知公告查看更多页面
import noticeList from '../pages/notice/noticeList.vue'
import noticeDetail from '../pages/notice/noticeDetail.vue'
// 个人信息管理
import personalInfo from '../pages/personalInfo/personalInfo'
// 学生的个人基本信息
import baseInfo from '../pages/personalInfo/baseInfo/baseInfo'
import baseInfoModify from '../pages/personalInfo/baseInfo/baseInfoModify'
import stuChange from '../pages/personalInfo/stuChange/stuChange'
// 硕博连读申请
import suoboApply from '../pages/personalInfo/suoboApply/suoboApply'
// 更换导师申请
import changeTutor from '../pages/personalInfo/changeTutor/changeTutor'
// 研究生证补办
import cardReapply from '../pages/personalInfo/cardReapply/cardReapply'
// 日常工作
import routine from '../pages/routine/routine'
// 教学培养
import teachTrain from '../pages/teachTrain/teachTrain'
// 培养模块 1、制定个人培养计划 2、在线选课 3、免修 重修 缓考 4、在线评教 5、个人课表 6、个人成绩单 7、四六级报名
import personalPlan from '../pages/teachTrain/personalPlan/personalPlan'
import onlineSelection from '../pages/teachTrain/onlineSelection/onlineSelection'
import exemptionRebuild from '../pages/teachTrain/exemptionRebuild/exemptionRebuild'
import onlineEvalution from '../pages/teachTrain/onlineEvalution/onlineEvalution'
import personalTimetable from '../pages/teachTrain/personalTimetable/personalTimetable'
import personalTranscript from '../pages/teachTrain/personalTranscript/personalTranscript'
import applyCET from '../pages/teachTrain/applyCET/applyCET'
// 国际化培养
import interTrain from '../pages/interTrain/interTrain'
// 教育建设项目

// 学术成果
import achieveInput from '../pages/academicAchieve/achieveInput/achieveInput'
import achieveQuery from '../pages/academicAchieve/achieveQuery/achieveQuery'
// 学位论文
// import academicDegreeApply from '../pages/academicDegree/academicDegreeApply/academicDegreeApply'
import academicDegreePaperFinal from '../pages/academicDegree/academicDegreePaperFinal/academicDegreePaperFinal'
import academicDegreePaperUpload from '../pages/academicDegree/academicDegreePaperUpload/academicDegreePaperUpload'
// import goodPaperApply from '../pages/academicDegree/goodPaperApply/goodPaperApply'
// 离校就业服务
import employService from '../pages/employService/employService'

// 导师
// 主页
import teacher from '../teacher'
import teacherHome from '../teacher/home'
import teacherNoticeList from '../teacher/notice/noticeList.vue'
import teacherNoticeDetail from '../teacher/notice/noticeDetail.vue'
import waitThing from '../teacher/waitThing/waitThing.vue'
// 学生信息管理
import stuInfoView from '../teacher/stuInfoManage/stuInfoView/stuInfoView'
import stuInfoAudit from '../teacher/stuInfoManage/stuInfoAudit/stuInfoAudit'
// 教学培养管理
import trainPlanAudit from '../teacher/teaTrainManage/trainPlanAudit/trainPlanAudit'
import stuCourseAudit from '../teacher/teaTrainManage/stuCourseAudit/stuCourseAudit'
import trainPlanQuery from '../teacher/teaTrainManage/trainPlanQuery/trainPlanQuery'
import courseManage from '../teacher/teaTrainManage/courseManage/courseManage'
import stuScoreManage from '../teacher/teaTrainManage/stuScoreManage/stuScoreManage'
// 学术成果管理
// 学术成果审核
import academicAchieveAduit from '../teacher/academicAchieveManage/academicAchieveAduit/academicAchieveAduit.vue'
// 学术成果审核——详情
import academicAchieveDetail from '../teacher/academicAchieveManage/academicAchieveAduit/academicAchieveDetail.vue'
// 学术成果查看
import academicAchieveSee from '../teacher/academicAchieveManage/academicAchieveSee/academicAchieveSee.vue'

// 学位论文管理
// import academicDegreeAduit from '../teacher/academicDegreeMangage/academicDegreeAduit/academicDegreeAduit'
import academicDegreePaperAduit from '../teacher/academicDegreeMangage/academicDegreePaperAduit/academicDegreePaperAduit'
import paperFinalAduit from '../teacher/academicDegreeMangage/paperFinalAduit/paperFinalAduit'
// import goodPaperAduit from '../teacher/academicDegreeMangage/goodPaperAduit/goodPaperAduit'

Vue.use(VueRouter)

const routes = [{
  path: '/login',
  name: 'login',
  component: login,
  meta: {
    title: '登录页'
  }
},
{
  path: '/register',
  component: Register,
  meta: {
    title: '注册页'
  }
},
{
  path: '/403',
  component: noPerm
},
{
  path: '/forgotPassword',
  name: 'forgotPassword',
  component: forgotPassword,
  meta: {
    title: '忘记密码'
    // perm: true //设置权限(测试)
  }
},
{
  path: '/',
  name: 'index',
  component: Main,
  meta: {
    title: '首页'
    // perm: true //设置权限(测试)
  },
  children: [
    // 个人信息管理
    {
      path: '/personalInfo',
      name: 'personalInfo',
      component: personalInfo,
      meta: {
        title: '个人信息管理'
      }
    },
    {
      path: '/personalInfo/baseInfo',
      name: 'baseInfo',
      component: baseInfo,
      meta: {
        title: '个人基本信息'
      }
    },
    {
      path: '/personalInfo/baseInfoModify',
      name: 'baseInfoModify',
      component: baseInfoModify,
      // redirect: '/personalInfo/baseInfoModify',
      meta: {
        title: '个人基本信息'
      }
    },
    {
      path: '/personalInfo/stuChange/:id?',
      name: 'stuChange',
      component: stuChange,
      meta: {
        title: '学籍异动申请'
      }
    },
    {
      path: '/personalInfo/suoboApply/:id?',
      name: 'suoboApply',
      component: suoboApply,
      // redirect: '/personalInfo/suoboApply/apply',
      meta: {
        title: '硕博连读申请'
      }
    },
    {
      path: '/personalInfo/changeTutor/:id?',
      name: 'changeTutor',
      component: changeTutor,
      // redirect: '/personalInfo/changeTutor/apply',
      meta: {
        title: '更换导师申请'
      }
    },
    {
      path: '/personalInfo/cardReapply/:id?',
      name: 'cardReapply',
      component: cardReapply,
      meta: {
        title: '研究生证补办'
      }
    },
    {
      path: '/routine',
      name: 'routine',
      component: routine
    },
    {
      path: '/teachTrain',
      name: 'teachTrain',
      component: teachTrain,
      meta: {
        title: '教学培养'
      }
    },
    {
      path: '/teachTrain/personalPlan/:id?',
      name: 'personalPlan',
      component: personalPlan,
      meta: {
        title: '个人培养计划'
      }
    },
    {
      path: '/teachTrain/onlineSelection/:id?',
      name: 'onlineSelection',
      component: onlineSelection,
      meta: {
        title: '在线选课'
      }
    },
    {
      path: '/teachTrain/exemptionRebuild/:id?',
      name: 'exemptionRebuild',
      component: exemptionRebuild,
      meta: {
        title: '免修/重修/缓考'
      }
    },
    {
      path: '/teachTrain/onlineEvalution/:id?',
      name: 'onlineEvalution',
      component: onlineEvalution,
      meta: {
        title: '在线评教'
      }
    },
    {
      path: '/teachTrain/personalTimetable/:id?',
      name: 'personalTimetable',
      component: personalTimetable,
      meta: {
        title: '个人课表'
      }
    },
    {
      path: '/teachTrain/personalTranscript/:id?',
      name: 'personalTranscript',
      component: personalTranscript,
      meta: {
        title: '个人成绩单'
      }
    },
    {
      path: '/teachTrain/applyCET/:id?',
      name: 'applyCET',
      component: applyCET,
      meta: {
        title: '英语四六级报名'
      }
    },
    {
      path: '/interTrain',
      name: 'interTrain',
      component: interTrain
    },
    // 教育建设项目
    {
      path: '/jiansheProject/projectReport',
      name: 'projectReport',
      component: () =>
        import('../pages/jiansheProject/projectReport/projectReport.vue'),
      meta: {
        title: "项目申报"
      }
    },
    {
      path: '/jiansheProject/projectReportDetail/:type/:id',
      name: 'projectReportDetail',
      component: () =>
        import('../pages/jiansheProject/projectReport/projectReportDetail.vue'),
      meta: {
        title: "项目申报"
      },
      props: true
    },
    {
      path: '/jiansheProject/myProject',
      name: 'myProject',
      component: () =>
        import('../pages/jiansheProject/myProject/myProject.vue'),
      meta: {
        title: "我的项目"
      }
    },
    {
      path: '/jiansheProject/myProjectModify/:type/:id/:projectStatus',
      name: 'myProjectModify',
      component: () =>
        import('../pages/jiansheProject/myProject/myProjectModify.vue'),
      meta: {
        title: "我的项目"
      },
      props: true
    },
    {
      path: '/jiansheProject/myProjectDetail/:type/:id/:projectStatus',
      name: 'myProjectDetail',
      component: () =>
        import('../pages/jiansheProject/myProject/myProjectDetail.vue'),
      meta: {
        title: "我的项目"
      },
      props: true
    },
    {
      path: '/jiansheProject/conclusionApply',
      name: 'conclusionApply',
      component: () =>
        import('../pages/jiansheProject/conclusionApply/conclusionApply.vue'),
      meta: {
        title: "结题申请"
      }
    },
    {
      path: '/jiansheProject/conclusionApplyAdd/:type/:id/:lcid',
      name: 'conclusionApplyAdd',
      component: () =>
        import('../pages/jiansheProject/conclusionApply/conclusionApplyAdd.vue'),
      meta: {
        title: "结题申请"
      },
      props: true
    },
    {
      path: '/jiansheProject/conclusionApplyDetail/:type/:id/:projectStatus/:jtId',
      name: 'conclusionApplyDetail',
      component: () =>
        import('../pages/jiansheProject/conclusionApply/conclusionApplyDetail.vue'),
      meta: {
        title: "结题申请"
      },
      props: true
    },
    {
      path: '/jiansheProject/conclusionApplyModify/:type/:id/:projectStatus/:jtId',
      name: 'conclusionApplyModify',
      component: () =>
        import('../pages/jiansheProject/conclusionApply/conclusionApplyModify.vue'),
      meta: {
        title: "结题申请"
      },
      props: true
    },
    {
      path: '/jiansheProject/conclusionProjectDetail/:type/:id',
      name: 'conclusionProjectDetail',
      component: () =>
        import('../pages/jiansheProject/conclusionApply/conclusionProjectDetail.vue'),
      meta: {
        title: "结题申请"
      },
      props: true
    },
    // 学术成果录入 id: 1=申请页 2=列表页 3=详情页--查看 4=详情页--修改
    {
      path: '/academicAchieve/achieveInput/:id/:executionId?',
      name: 'achieveInput',
      component: achieveInput,
      props: true
    },
    // 个人成果查询
    {
      path: '/academicAchieve/achieveQuery/:id/:executionId?',
      name: 'achieveQuery',
      component: achieveQuery,
      props: true
    },

    // // 学位资格申请
    // {
    //   path: '/academicDegree/academicDegreeApply',
    //   name: 'academicDegreeApply',
    //   component: academicDegreeApply
    // },
    // 学位论文上传
    {
      path: '/academicDegree/academicDegreePaperUpload',
      name: 'academicDegreePaperUpload',
      component: academicDegreePaperUpload
    },
    // 满意度问卷
    {
      path: '/academicDegree/degreeAnwserPaper',
      name: 'degreeAnwserPaper',
      component: () => import("@/pages/academicDegree/degreeAnwserPaper/degreeAnwserPaper.vue")
    },
    // 学位论文定稿
    {
      path: '/academicDegree/academicDegreePaperFinal',
      name: 'academicDegreePaperFinal',
      component: academicDegreePaperFinal
    },
    // // 优秀论文申请
    // {
    //   path: '/academicDegree/goodPaperApply',
    //   name: 'goodPaperApply',
    //   component: goodPaperApply
    // },

    {
      path: '/employService',
      name: 'employService',
      meta: {
        perm: true // 设置权限(测试)
      },
      component: employService
    },
    // 通知公告列表页面
    {
      path: '/noticeList',
      name: 'noticeList',
      component: noticeList
    },
    // 通知公告详细页面
    {
      path: '/noticeDetail/:id',
      name: 'noticeDetail',
      component: noticeDetail,
      props: true
    }
  ]
},
{
  path: '/teacher',
  name: 'teacher',
  component: teacher,
  meta: {
    title: '主页'
  },
  children: [{
    path: '/teacherHome',
    name: 'teacherHome',
    component: teacherHome,
    meta: {
      title: '首页'
    }
  },
  {
    path: '/teacherNoticeList',
    name: 'teacherNoticeList',
    component: teacherNoticeList
  },
  {
    path: '/teacherNoticeDetail/:id',
    name: 'teacherNoticeDetail',
    component: teacherNoticeDetail,
    props: true
  },
  {
    path: '/waitThing',
    name: 'waitThing',
    component: waitThing
  },
  {
    path: '/stuInfoView/:id?/:zt?',
    name: 'stuInfoView',
    component: stuInfoView,
    meta: {
      title: '学生信息查看'
    }
  },
  {
    path: '/stuInfoAudit/:id?',
    name: 'stuInfoAudit',
    component: stuInfoAudit,
    meta: {
      title: '学生信息审核'
    }
  },
  {
    path: '/trainPlanAudit/:id?',
    name: 'trainPlanAudit',
    component: trainPlanAudit,
    meta: {
      title: '培养计划审核'
    }
  },
  {
    path: '/stuCourseAudit',
    name: 'stuCourseAudit',
    component: stuCourseAudit,
    meta: {
      title: '学生课程审核'
    }
  },
  {
    path: '/trainPlanQuery/:id?',
    name: 'trainPlanQuery',
    component: trainPlanQuery,
    meta: {
      title: '培养计划查询'
    }
  },
  {
    path: '/courseManage/:id?',
    name: 'courseManage',
    component: courseManage,
    meta: {
      title: '课程教学管理'
    }
  },
  {
    path: '/stuScoreManage',
    name: 'stuScoreManage',
    component: stuScoreManage,
    meta: {
      title: '学生成绩管理'
    }
  },
  // 教育建设项目
  {
    path: '/projectReportByTeacher',
    name: 'projectReportByTeacher',
    component: () =>
      import('../teacher/jiansheProject/projectReport/projectReportByTeacher.vue'),
    meta: {
      title: "项目申报"
    }
  },
  {
    path: '/projectReportDetailByTeacher/:type/:id',
    name: 'projectReportDetailByTeacher',
    component: () =>
      import('../teacher/jiansheProject/projectReport/projectReportDetailByTeacher.vue'),
    meta: {
      title: "项目申报",
      alias: "/projectReportByTeacher"
    },
    props: true
  },
  {
    path: '/myProjectByTeacher',
    name: 'myProjectByTeacher',
    component: () =>
      import('../teacher/jiansheProject/myProject/myProjectByTeacher.vue'),
    meta: {
      title: "我的项目"
    }
  },
  {
    path: '/myProjectModifyByTeacher/:type/:id/:projectStatus',
    name: 'myProjectModifyByTeacher',
    component: () =>
      import('../teacher/jiansheProject/myProject/myProjectModifyByTeacher.vue'),
    meta: {
      title: "我的项目",
      alias: "/myProjectByTeacher"
    },
    props: true
  },
  {
    path: '/myProjectDetailByTeacher/:type/:id/:projectStatus',
    name: 'myProjectDetailByTeacher',
    component: () =>
      import('../teacher/jiansheProject/myProject/myProjectDetailByTeacher.vue'),
    meta: {
      title: "我的项目",
      alias: "/myProjectByTeacher"
    },
    props: true
  },
  {
    path: '/conclusionApplyByTeacher',
    name: 'conclusionApplyByTeacher',
    component: () =>
      import('../teacher/jiansheProject/conclusionApply/conclusionApplyByTeacher.vue'),
    meta: {
      title: "结题申请"
    }
  },
  {
    path: '/conclusionApplyAddByTeacher/:type/:id/:lcid',
    name: 'conclusionApplyAddByTeacher',
    component: () =>
      import('../teacher/jiansheProject/conclusionApply/conclusionApplyAddByTeacher.vue'),
    meta: {
      title: "结题申请",
      alias: "/conclusionApplyByTeacher"
    },
    props: true
  },
  {
    path: '/conclusionApplyDetailByTeacher/:type/:id/:projectStatus/:jtId',
    name: 'conclusionApplyDetailByTeacher',
    component: () =>
      import('../teacher/jiansheProject/conclusionApply/conclusionApplyDetailByTeacher.vue'),
    meta: {
      title: "结题申请",
      alias: "/conclusionApplyByTeacher"
    },
    props: true
  },
  {
    path: '/conclusionApplyModifyByTeacher/:type/:id/:projectStatus/:jtId',
    name: 'conclusionApplyModifyByTeacher',
    component: () =>
      import('../teacher/jiansheProject/conclusionApply/conclusionApplyModifyByTeacher.vue'),
    meta: {
      title: "结题申请",
      alias: "/conclusionApplyByTeacher"
    },
    props: true
  },
  {
    path: '/conclusionProjectDetailByTeacher/:type/:id',
    name: 'conclusionProjectDetailByTeacher',
    component: () =>
      import('../teacher/jiansheProject/conclusionApply/conclusionProjectDetailByTeacher.vue'),
    meta: {
      title: "结题申请",
      alias: "/conclusionApplyByTeacher"
    },
    props: true
  },
  {
    path: '/projectAduit',
    name: 'projectAduit',
    component: () =>
      import('../teacher/jiansheProject/projectAduit/projectAduit.vue'),
    meta: {
      title: "项目申报审核"
    }
  },
  {
    path: '/projectAduitAdd/:type/:id/:taskId',
    name: 'projectAduitAdd',
    component: () =>
      import('../teacher/jiansheProject/projectAduit/projectAduitAdd.vue'),
    meta: {
      title: "项目申报审核",
      alias: "/projectAduit"
    },
    props: true
  },
  {
    path: '/projectAduitDetail/:type/:id',
    name: 'projectAduitDetail',
    component: () =>
      import('../teacher/jiansheProject/projectAduit/projectAduitDetail.vue'),
    meta: {
      title: "项目申报审核",
      alias: "/projectAduit"
    },
    props: true
  },
  {
    path: '/conclusionAduit',
    name: 'conclusionAduit',
    component: () =>
      import('../teacher/jiansheProject/conclusionAduit/conclusionAduit.vue'),
    meta: {
      title: "项目结题审核"
    }
  },
  {
    path: '/conclusionAduitProjectDetailByTeacher/:type/:id',
    name: 'conclusionAduitProjectDetailByTeacher',
    component: () =>
      import('../teacher/jiansheProject/conclusionAduit/conclusionAduitProjectDetailByTeacher.vue'),
    meta: {
      title: "项目结题审核",
      alias: "/conclusionAduit"
    },
    props: true
  },
  {
    path: '/conclusionAduitAdd/:type/:id/:taskId/:jtId',
    name: 'conclusionAduitAdd',
    component: () =>
      import('../teacher/jiansheProject/conclusionAduit/conclusionAduitAdd.vue'),
    meta: {
      title: "项目结题审核",
      alias: "/conclusionAduit"
    },
    props: true
  },
  {
    path: '/conclusionAduitDetail/:type/:id/:jtId',
    name: 'conclusionAduitDetail',
    component: () =>
      import('../teacher/jiansheProject/conclusionAduit/conclusionAduitDetail.vue'),
    meta: {
      title: "项目结题审核",
      alias: "/conclusionAduit"
    },
    props: true
  },
  // 学术成果审核主页
  {
    path: '/academicAchieveAduit',
    name: 'academicAchieveAduit',
    component: academicAchieveAduit,
    meta: {
      title: '学术成果审核'
    }
  },
  // 学术成果审核详情页
  {
    path: '/academicAchieveDetail/:id/:executionId/:check',
    name: 'academicAchieveDetail',
    component: academicAchieveDetail,
    meta: {
      title: '学术成果审核',
      // 折叠导航栏侧边栏的是否激活判断依据
      alias: '/academicAchieveAduit'
    },
    props: true
  },
  {
    path: '/academicAchieveSee/:id/:executionId?',
    name: 'academicAchieveSee',
    component: academicAchieveSee,
    meta: {
      title: '学术成果查询',
      // 折叠导航栏侧边栏的是否激活判断依据
      alias: '/academicAchieveSee/2'
    },
    props: true
  },

  // 学位申请审核
  // {
  //   path: '/academicDegreeAduit/:id/:executionId?',
  //   name: 'academicDegreeAduit',
  //   component: academicDegreeAduit,
  //   meta: {
  //     title: '学位申请审核',
  //     // 折叠导航栏侧边栏的是否激活判断依据
  //     alias: '/academicDegreeAduit/2'
  //   },
  //   props: true
  // },
  // 学位论文审核
  {
    path: '/academicDegreePaperAduit/:id/:executionId?',
    name: 'academicDegreePaperAduit',
    component: academicDegreePaperAduit,
    meta: {
      title: '学位论文审核',
      // 折叠导航栏侧边栏的是否激活判断依据
      alias: '/academicDegreePaperAduit/2'
    },
    props: true
  },
  // 论文终稿审核
  {
    path: '/paperFinalAduit/:id/:executionId?',
    name: 'paperFinalAduit',
    component: paperFinalAduit,
    meta: {
      title: '论文终稿审核',
      // 折叠导航栏侧边栏的是否激活判断依据
      alias: '/paperFinalAduit/2'
    },
    props: true
  },
  // 优秀论文审核
  // {
  //   path: '/goodPaperAduit/:id/:executionId?',
  //   name: 'goodPaperAduit',
  //   component: goodPaperAduit,
  //   meta: {
  //     title: '优秀论文评审',
  //     // 折叠导航栏侧边栏的是否激活判断依据
  //     alias: '/goodPaperAduit/2'
  //   },
  //   props: true
  // },

  // 匹配不存在的路径页面
  {
    path: '*',
    component: noFound
    // 重定向
    // redirect: '/'
    // redirect: {
    //     path: '/'
    // }
    // 动态设置重定向的目标,to目标路由对象，就是访问的路径的路由信息
    // redirect:(to)=>{
    //     // if(to.path == '/123'){
    //     //     return '/'
    //     // }else if(to.path == '456'){
    //     //     return { path: '/first' }
    //     // }else {
    //     //     return { name: 'index' }
    //     // }
    //     return '/'
    // }
  }
  ]
}
]

const router = new VueRouter({
  routes,
  mode: 'hash',
  // linkActiveClass: 'is-active',//当前激活的路由的class名字
  scrollBehavior(to, from, savePotion) {
    if (savePotion) {
      return savePotion
    } else {
      return {
        x: 0,
        y: 0
      }
    }
  }
})

// meta里可以定义一些自己想要的数据
// 测试权限
// 进入导航之前的钩子
// 写上next()路由才会跳转
// 可以拦截登录，如果meta里配置了需要登录，则重定向到'/login'页面
router.beforeEach((to, from, next) => {
  if (to.path === '/' && !store.getters.getXH) {
    // next('/403')
    next('/login')
  } else {
    next()
  }
})

export default router
