// const path = require('path')
module.exports = {
  configureWebpack: config => {
    if (process.env.NODE_ENV === 'production') {
      config.optimization.minimizer[0].options.terserOptions.compress.drop_console = true
    }
  },
  runtimeCompiler: true,
  devServer: {
    proxy: {
      '/mock': {
        target: 'https://easy-mock.com/mock/5ccfef59996c4b37a1b98533/example',
        // ws: true,
        changeOrigin: true,
        pathRewrite: { // 重写路径
          '^/mock': ''
        }
      },
      '/api': {
        target: 'http://192.168.31.57:6677', // 测试
        // target: 'http://192.168.31.135:6677', // jss
        // target: 'http://192.168.31.75:6677', // yx
        // target: 'http://192.168.31.116:6677', // byl
        // target: 'http://192.168.31.118:6677',
        // target: 'http://192.168.31.181:6677',// hry
        // ws: true,
        changeOrigin: true,
        pathRewrite: { // 重写路径
          '^/api': ''
        }
      }
    }
  },
  pluginOptions: {
    'style-resources-loader': {
      patterns: [
        // '/Users/dream/Desktop/Graduate-management-frontpage/src/styles/abstracts/*.scss'
        // main.js里全局引入css配置
        // path.resolve(__dirname, './src/styles/*.scss')
      ],
      preProcessor: 'scss'
    }
  },
  css: {
    // 向所有 Sass 样式传入共享的全局变量：
    loaderOptions: {
      // 给 sass-loader 传递选项
      sass: {
        // @/ 是 src/ 的别名
        // 所以这里假设你有 `src/variables.scss` 这个文件
        data: `@import "~@/styles/variables.scss";`
      }
    }
  }
}
