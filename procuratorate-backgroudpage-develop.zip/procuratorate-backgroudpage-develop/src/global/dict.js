// var dict = {
//   sexCode: [{ label: '男', value: '1' }, { label: '女', value: '2' }]
// };
// export default {
//   dict
// };
