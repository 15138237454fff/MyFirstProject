const isBuild = false
const myDate = new Date()
var logTime = myDate.toLocaleString()
var currentlevel = 0
// 获取日期与时间
const Log = (Vue) => {
  Vue.prototype.$log = new Vue({
    methods: {
      // 强烈日志...DEBUG
      DEBUG(...params) {
        if (!isBuild && currentlevel <= 1) {
          this.$log.INFO(`${logTime} DEBUG \n`, ...params, '\nEND ')
        }
      },
      // 信息
      INFO(...params) {
        if (!isBuild && currentlevel <= 2) {
          console.info(`${logTime} INFO \n`, ...params, '\nEND ')
        }
      },
      // 警告
      WARN(...params) {
        if (!isBuild && currentlevel <= 3) {
          console.warn(`${logTime} ⚠WARN \n`, ...params, '\nEND ')
        }
      },
      // 信息
      ERROR(...params) {
        if (!isBuild && currentlevel <= 4) {
          console.error(`${logTime} ❌ERROR \n`, ...params, '\nEND ')
        }
      },
      // 致命
      FATAL(...params) {
        if (!isBuild && currentlevel <= 5) {
          console.error(`${logTime} ❌FATAL \n`, ...params, '\nEND ')
        }
      },
      currentmethod(params) {
        currentlevel = params
      }
    }
  })
}
export default Log
