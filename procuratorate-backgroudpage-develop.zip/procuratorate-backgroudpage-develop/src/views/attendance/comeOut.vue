<template>
  <div class="comeOut">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入姓名/培训项目"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-date-picker
          :editable="false"
          type="daterange"
          separator=" 至 "
          v-model="limitQuery.timePick"
          @on-change="initLoadTable"
          placeholder="请选择时间段"
          size="large"
        ></i-date-picker>
      </div>
      <div slot="right">
        <i-button size="large" @click="clickOutput" type="primary"
          >导出</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="status">
          <span>{{ row.status ? "离开" : "进入" }}</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Input, Button, DatePicker } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "comeOut",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-date-picker": DatePicker,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { title: "姓名", align: "center", key: "name", tooltip: true },
        { title: "所属部门", align: "center", key: "deptName", tooltip: true },
        {
          title: "关联培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "进入/离开", align: "center", slot: "status" },
        {
          title: "时间",
          align: "center",
          key: "actionTime",
          width: 200
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 时间段
        timePick: []
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 对分页数据做处理
      let {
        query,
        pageSize,
        pageNum,
        // 时间段
        timePick
      } = this.limitQuery;
      let tmpObj = {
        query,
        pageSize,
        pageNum,
        startTime: timePick[0] ? timePick[0] : "",
        // 查询时间从00：00：00 分改为 23：59：59
        endTime: timePick[1] ? this.$endTime(timePick[1]) : ""
      };
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/attence/passOutInfo/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    clickOutput() {
      this.$log.INFO("正在导出");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.comeOut {
}
</style>
<style lang="scss">
.myContentHead {
  .header .left {
    flex: 3;
  }
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
