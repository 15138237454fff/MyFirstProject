<template>
  <div class="leaveAduit">
    <i-tabs v-model="activeTab">
      <i-tab-pane name="wait" label="待审核"></i-tab-pane>
      <i-tab-pane name="aduited" label="已审核"></i-tab-pane>
    </i-tabs>
    <template v-if="activeTab === 'wait'">
      <leave-aduit-wait></leave-aduit-wait>
    </template>
    <template v-else>
      <leave-aduited></leave-aduited>
    </template>
  </div>
</template>
<script>
import { Tabs, TabPane } from "view-design";
import leaveAduited from "@/components/leaveAduitTab/leaveAduited";
import leaveAduitWait from "@/components/leaveAduitTab/leaveAduitWait";
export default {
  name: "leaveAduit",
  components: {
    "i-tabs": Tabs,
    "i-tab-pane": TabPane,
    "leave-aduit-wait": leaveAduitWait,
    "leave-aduited": leaveAduited
  },
  data() {
    return {
      activeTab: "wait"
    };
  }
};
</script>
<style lang="scss" scoped>
.leaveAduit {
  /deep/ .ivu-tabs-bar {
    margin-bottom: $top;
  }
}
</style>
