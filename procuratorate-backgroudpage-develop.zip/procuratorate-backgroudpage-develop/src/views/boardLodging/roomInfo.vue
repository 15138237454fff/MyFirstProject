<template>
  <div class="roomInfo">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入房间号"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-select
          size="large"
          v-model="limitQuery.status"
          @on-change="initLoadTable"
        >
          <i-option
            v-for="(item, index) of moreRoomTypeOptions"
            :key="index"
            :value="item.value"
            >{{ item.label }}</i-option
          >
        </i-select>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('room:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('room:delete')"
          >删除</i-button
        >
        <i-button size="large" @click="clickOutput" type="primary" ghost
          >导出</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="status" slot-scope="{ row }">
          <i-switch
            v-model="row.status"
            size="large"
            @on-change="handleSwitch(row.id, row.status)"
            :false-value="0"
            :true-value="1"
            v-if="$btnAuthorityTest('room:status')"
          >
            <span slot="open">正常</span>
            <span slot="close">锁定</span>
          </i-switch>
        </template>
        <template slot-scope="{ row }" slot="roomType">
          <span>{{ roomTypeFilter(row.roomType) }}</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            @click="clickModify(row)"
            class="modify"
            v-if="row.inUse === 0 && $btnAuthorityTest('room:add')"
            >修改</span
          >
          <span v-else-if="$btnAuthorityTest('room:add')" class="disable"
            >修改</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template>
          <i-form
            :model="formData"
            :label-width="100"
            ref="formValidate"
            :rules="ruleValidate"
          >
            <i-form-item label="房间号：" required prop="roomNum">
              <span v-if="modalOption.disabled">{{ formData.roomNum }}</span>
              <i-input
                v-model="formData.roomNum"
                placeholder="请输入"
                size="large"
                v-else
              ></i-input>
            </i-form-item>
            <i-form-item label="房间类型：" required prop="roomType">
              <i-select size="large" v-model="formData.roomType">
                <i-option
                  v-for="(item, index) of roomTypeOptions"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </i-form-item>
            <i-form-item label="入住对象：" required prop="inObject">
              <i-select
                size="large"
                :value="formData.inObject"
                multiple
                @on-change="inObjectChange"
              >
                <i-option
                  v-for="(item, index) of dutySelectOptions"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </i-form-item>
            <i-form-item label="门禁：" prop="doorControl">
              <i-select size="large" v-model="formData.doorControl">
                <i-option
                  v-for="(item, index) of doorControlOptions"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </i-form-item>
          </i-form>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" @click="modalOption.modalVisiabal = false"
          >取消</i-button
        >
        <i-button size="large" type="primary" @click="clickOk">{{
          modalOption.key === "supply" ? "确定" : "保存"
        }}</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Form,
  FormItem,
  Switch
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "roomInfo",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-switch": Switch,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "房间号",
          align: "center",
          key: "roomNum",
          tooltip: true
        },
        { title: "房间类型", align: "center", slot: "roomType", width: 120 },
        { title: "入住对象", align: "center", key: "inObject", tooltip: true },
        { title: "门禁", align: "center", key: "doorControl", tooltip: true },
        { title: "状态", align: "center", slot: "status", width: 120 },
        { title: "操作", align: "center", width: 80, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 房间类型
        status: -1
      },
      // 待提交的表单数据
      formData: {
        // 门禁信息
        doorControl: "",
        // 入住对象，和职务相对应
        inObject: [],
        // 房间号
        roomNum: "",
        // 房间类型 1:一人间 2：二人间 4:四人间
        roomType: ""
      },
      // 表单校验规则
      ruleValidate: {
        roomNum: [
          {
            required: true,
            message: "房间号不能为空"
          },
          {
            max: 8,
            message: "房间号长度不能超过8位"
          }
        ],
        roomType: [
          {
            required: true,
            message: "房间类型不能为空"
          }
        ],
        inObject: [
          {
            type: Array,
            required: true,
            message: "入住对象不能为空"
          }
        ]
        // doorControl: [
        //   {
        //     required: true,
        //     message: "门禁不能为空"
        //   }
        // ]
      },
      // 房间类型可选列表
      roomTypeOptions: [
        { label: "单人间", value: 1 },
        { label: "双人间", value: 2 },
        { label: "四人间", value: 4 }
      ],
      // 当前操作的Id
      id: "",
      // 职务参数的id
      dutyId: "XP-003",
      // 职务待选列表
      dutySelectOptions: [],
      doorControlOptions: [
        // { label: "刷卡入住", value: 1 }
      ],
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-room-info",
        disabled: false
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求职务下拉列表
    this.requireDutyList();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = Object.assign({}, this.limitQuery);
      if (tmpObj.status === -1) {
        tmpObj.status = "";
      }
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/room/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 根据房间的使用和申请情况设置禁止选中状态
          data.list.forEach(el => {
            el._disabled = el.inUse === 1 || el.modifiableState === 1;
          });
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 添加
    clickAdd() {
      this.modalOption.title = "添加";
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
    },
    // 点击修改的处理函数
    clickModify(obj) {
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      this.modalOption.disabled = obj._disabled;
      // 保存当前修改的记录id
      this.id = obj.id;
      // 数据回显
      this.dataCallBack(obj);
    },
    // 数据回显
    dataCallBack(obj) {
      Object.keys(this.formData).forEach(key => {
        this.formData[key] = obj[key];
      });
      this.formData.inObject = obj.inObject.split(",");
    },
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 待提交的id列表
      let ids = [];
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.id);
      this.$axios
        .delete("/api/room", { data: ids })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    // 对话框确认的处理方法
    clickOk() {
      // 获取表单验证结果
      let sign = this.testForm();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      // 根据key值调用不同的方法
      if (this.modalOption.key === "add") {
        this.saveAdd();
      }
      if (this.modalOption.key === "modify") {
        this.saveModify();
      }
    },
    // 保存添加的信息
    saveAdd() {
      let tmpObj = Object.assign({}, this.formData);
      tmpObj.inObject = tmpObj.inObject.join(",");
      this.$axios
        .post("/api/room", tmpObj)
        .then(res => {
          this.$Message.success("添加成功");
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 保存修改的信息
    saveModify() {
      let tmpObj = Object.assign({}, this.formData);
      tmpObj.inObject = tmpObj.inObject.join(",");
      this.$axios
        .put(`/api/room/${this.id}`, tmpObj)
        .then(res => {
          this.$Message.success("修改成功");
          // 重新渲染列表
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求可选的职务列表数据
    requireDutyList() {
      this.$axios
        .get(`/api/param/select/${this.dutyId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("职务下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.dutySelectOptions = data.map(el => {
            return { label: el.title, value: el.title };
          });
          this.dutySelectOptions.unshift({ label: "不限", value: "不限" });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 清空表单数据
    clearFormData() {
      this.$refs.formValidate.resetFields();
      this.formData = {
        // 门禁信息
        doorControl: "",
        // 入住对象，和职务相对应
        inObject: [],
        // 房间号
        roomNum: "",
        // 房间类型 1:一人间 2：二人间 4:四人间
        roomType: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // switch 改变事件
    handleSwitch(id, state) {
      this.$axios.put(`/api/room/status/${id}/${state}`).catch(error => {
        this.loadTable();
        console.error(error.message);
      });
    },
    inObjectChange(arr) {
      if (arr.includes("不限")) {
        this.formData.inObject = ["不限"];
      } else {
        this.formData.inObject = arr;
      }
    },
    // 导出的方法
    clickOutput() {
      this.$log.INFO("正在导出");
    },
    roomTypeFilter(val) {
      if (typeof val !== "number") {
        console.error("过滤的房间类型参数格式错误");
        return "";
      }
      let result = this.roomTypeOptions.find(el => val === el.value);
      if (!result || !result.label) {
        return "";
      }
      return result.label;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    moreRoomTypeOptions() {
      return [{ label: "全部房间类型", value: -1 }].concat(
        this.roomTypeOptions
      );
    }
  }
};
</script>
<style lang="scss" scoped>
.roomInfo {
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .disable {
    color: $grey;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-room-info {
  .ivu-modal {
    width: 360px !important;
  }
  .modal-content {
    // .ivu-form-item:last-child {
    //   margin-bottom: 0;
    // }
    .ivu-select {
      width: 200px !important;
    }
  }
}
</style>
