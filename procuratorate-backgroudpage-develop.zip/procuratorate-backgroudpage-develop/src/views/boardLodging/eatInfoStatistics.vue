<template>
  <div class="eatInfoStatistics">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-date-picker
          :editable="false"
          type="daterange"
          separator=" 至 "
          :value="[limitQuery.startTime, limitQuery.endTime]"
          @on-change="handleDatePickChange"
          placeholder="请选择时间段"
          size="large"
        ></i-date-picker>
      </div>
      <div slot="right">
        <i-button size="large" @click="clickOutput" type="primary" ghost
          >导出</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="time">
          <i-tooltip
            :content="`${row.startTime} 至 ${row.endTime}`"
            :transfer="true"
            max-width="300px"
            >{{ row.startTime }} 至 {{ row.endTime }}</i-tooltip
          >
        </template>
        <template slot-scope="{ row }" slot="roomType">
          <span>{{ row.roomType }}</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span class="disable" v-if="row._disabled">修改</span>
          <span @click="clickModify(row)" class="modify" v-else>修改</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Button, DatePicker, Tooltip } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "eatInfoStatistics",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-date-picker": DatePicker,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        { title: "就餐日期", align: "center", slot: "time" },
        { title: "早餐人数", align: "center", key: "deptName", tooltip: true },
        { title: "中餐人数", align: "center", key: "duty", tooltip: true },
        {
          title: "晚餐人数",
          align: "center",
          key: "roomNum",
          tooltip: true
        }
      ],

      // 分页查询的参数
      limitQuery: {
        pageSize: 15,
        pageNum: 1,
        startTime: "",
        endTime: ""
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-room-info"
      }
    };
  },
  mounted() {
    // 请求列表数据
    // this.loadTable();
    this.$Message.error("接口未对接");
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/liqc/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 导出的方法
    clickOutput() {
      this.$log.INFO("正在导出");
    },
    // 事件选择器变化
    handleDatePickChange(val) {
      [this.limitQuery.startTime, this.limitQuery.endTime] = val;
      // 重新请求列表
      this.initLoadTable();
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.eatInfoStatistics {
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .disable {
    color: $grey;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-room-info {
  .ivu-modal {
    width: 360px !important;
  }
  .modal-content {
    // .ivu-form-item:last-child {
    //   margin-bottom: 0;
    // }
    .ivu-select {
      width: 200px !important;
    }
  }
}
</style>
