<template>
  <div class="roomDistribution">
    <div class="my-header">
      <div class="header-left">
        <div>
          <span>请选择培训项目：</span>
          <i-select
            size="large"
            v-model="projectId"
            @on-change="handleProjectSelectChange"
          >
            <i-option
              v-for="(item, index) of projectOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
        </div>
        <div>
          <span>起止日期：</span>
          <i-date-picker
            :editable="false"
            type="daterange"
            separator=" 至 "
            :value="[limitQuery.startTime, limitQuery.endTime]"
            @on-change="handleDatePickChange"
            placeholder="请选择时间段"
            size="large"
            :options="dateOption"
          ></i-date-picker>
        </div>
        <div>
          <span>待分配人数：</span>
          <span>{{ waitToDistributionCount }}</span>
        </div>
      </div>
      <div class="header-right">
        <!-- <i-button size="large" @click="initLoadTable" type="primary"
          >查找可用房间</i-button
        > -->
      </div>
    </div>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="roomType">
          <span>{{ row.roomType | roomTypeFilter }}</span>
        </template>
        <template slot-scope="{ row, index }" slot="roster">
          <span class="modify" @click="clickRoster(index)">入住名单</span>
        </template>
        <template slot-scope="{ row, index }" slot="distribute">
          <span
            :class="projectId !== '' ? 'modify' : 'disable'"
            @click="clickDistribute(index)"
            >入住分配</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="modalOption.key === 'roster'">
          <div class="modal-head">
            <div>
              <span>房间号：</span>
              <span>{{ modalParams.roomNum }}</span>
            </div>
            <div>
              <span>房间类型：</span>
              <span>{{ modalParams.roomType | roomTypeFilter }}</span>
            </div>
            <div>
              <span>入住对象：</span>
              <span>{{ modalParams.inObject }}</span>
            </div>
          </div>
          <i-table
            :height="300"
            :data="rosterTableData"
            :columns="rosterColOption"
            :border="true"
            :loading="loading"
          >
            <template slot-scope="{ row }" slot="time">
              <i-tooltip
                :content="`${row.startTime} 至 ${row.endTime}`"
                :transfer="true"
                max-width="300px"
                >{{ row.startTime }} 至 {{ row.endTime }}</i-tooltip
              >
            </template>
            <template slot-scope="{ row, index }" slot="action">
              <div
                class="reduce"
                @click="reduceRow(index)"
                v-if="row.actionable === 1"
              >
                -
              </div>
              <div class="unReduce" v-else>-</div>
            </template>
          </i-table>
        </template>
        <template v-if="modalOption.key === 'distribute'">
          <div class="modal-head">
            <div>
              <span>房间号：</span>
              <span>{{ modalParams.roomNum }}</span>
            </div>
            <div>
              <span>房间类型：</span>
              <span>{{ modalParams.roomType | roomTypeFilter }}</span>
            </div>
            <div>
              <span>入住对象：</span>
              <span>{{ modalParams.inObject }}</span>
            </div>
            <div>
              <span>可分配床位数：</span>
              <span class="green">{{
                modalParams.distributable -
                  this.distributeTableData.filter(el => el.selected).length
              }}</span>
            </div>
          </div>
          <i-table
            :height="300"
            :data="distributeTableData"
            :columns="distributeColOption"
            :border="true"
            :loading="loading"
          >
            <template slot-scope="{ row, index }" slot="mySelection">
              <i-checkbox
                @on-change="handleDistributeSelectChange($event, index)"
                v-model="distributeTableData[index].selected"
                :disabled="row.disabled"
              ></i-checkbox>
            </template>
            <template slot-scope="{ row }" slot="roomType">
              <span>{{ row.roomType | roomTypeFilter }}</span>
            </template>
            <template slot-scope="{ row, index }" slot="roster">
              <span class="modify" @click="clickRoster(index)">入住名单</span>
            </template>
            <template slot-scope="{ row, index }" slot="distribute">
              <span
                :class="projectId !== '' ? 'modify' : 'disable'"
                @click="clickDistribute(index)"
                >入住分配</span
              >
            </template>
          </i-table>
          <div class="red">注：男女不可混住！</div>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" @click="modalOption.modalVisiabal = false"
          >取消</i-button
        >
        <i-button size="large" type="primary" @click="clickOk">{{
          modalOption.key === "distribute" ? "确定" : "保存"
        }}</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Button,
  Select,
  Option,
  DatePicker,
  Checkbox,
  Tooltip
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
export default {
  name: "roomDistribution",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-date-picker": DatePicker,
    "i-checkbox": Checkbox,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination,
    "my-modal": myModal
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      rosterTableData: [],
      distributeTableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        { title: "房间号", align: "center", key: "roomNum", tooltip: true },
        { title: "房间类型", align: "center", slot: "roomType", width: 120 },
        { title: "入住对象", align: "center", key: "inObject", tooltip: true },
        {
          title: "可分配床位数",
          align: "center",
          key: "distributable",
          width: 120
        },
        { title: "入住名单", align: "center", width: 120, slot: "roster" },
        { title: "入住分配", align: "center", width: 120, slot: "distribute" }
      ],
      rosterColOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          width: 80,
          tooltip: true
        },
        {
          title: "性别",
          align: "center",
          width: 80,
          render: (h, params) => {
            let row = params.row;
            return h("span", row.sex === 1 ? "男" : "女");
          }
        },
        { title: "所属部门", align: "center", key: "deptName", tooltip: true },
        { title: "职务", align: "center", key: "duty", tooltip: true },
        { title: "入住时间", align: "center", slot: "time" },
        { title: "操作", align: "center", slot: "action", width: 80 }
      ],
      distributeColOption: [
        {
          title: " ",
          align: "center",
          slot: "mySelection",
          width: 60
        },
        { title: "姓名", align: "center", key: "name", tooltip: true },
        {
          title: "性别",
          align: "center",
          render: (h, params) => {
            let row = params.row;
            return h("span", row.sex === 1 ? "男" : "女");
          },
          width: 80
        },
        { title: "所属部门", align: "center", key: "deptName", tooltip: true },
        { title: "职务", align: "center", key: "duty", tooltip: true }
      ],
      // 日期选择器的禁止选择日期范围
      dateOption: {
        disabledDate(date) {
          if (!date) {
            return false;
          }
          return date.valueOf() < Date.now() - 86400000;
        }
      },
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        startTime: "",
        endTime: ""
      },
      // 当前选中的项目Id
      projectId: "",
      // 待分配人数
      waitToDistributionCount: 0,
      // 培训项目可选列表
      projectOptions: [],
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-room-distribution"
      },
      // 被删除的用户列表
      deleteUserList: [],
      // 对话框展示的参数
      modalParams: {
        // 房间号
        roomNum: "",
        // 房间类型
        roomType: "",
        // 入住对象
        inObject: "",
        // 剩余床位数
        distributable: "",
        // 房间Id
        roomId: "",
        // 限制性别
        limitSex: ""
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求培训项目下拉框可选项
    this.requireProjectOptions();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/rldc/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击名单
    clickRoster(index) {
      this.modalOption.title = "入住名单";
      this.modalOption.key = "roster";
      this.modalOption.modalVisiabal = true;
      let { roomNum, roomType, inObject, id } = this.tableData[index];
      this.modalParams.roomNum = roomNum;
      this.modalParams.roomType = roomType;
      this.modalParams.inObject = inObject;
      this.modalParams.roomId = id;
      this.requireRoomRoster();
    },
    // 保存名单修改
    saveRoster() {
      console.log("保存名单");
      let formData = {
        roomId: this.modalParams.roomId,
        ids: this.deleteUserList.map(el => el.id)
      };
      this.$axios
        .delete(`/api/rldc`, { data: formData })
        .then(res => {
          this.$Message.success("保存成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击入住分配
    clickDistribute(index) {
      if (this.projectId === "") {
        this.$Message.error("请选择具体项目后再进行入住分配");
        return;
      }
      if (this.limitQuery.startTime === this.limitQuery.endTime) {
        this.$Message.error("入住时间不能小于一天");
        return;
      }
      this.modalOption.title = "入住分配";
      this.modalOption.key = "distribute";
      this.modalOption.modalVisiabal = true;
      let currentObj = this.tableData[index];
      let { roomNum, roomType, inObject, distributable, id, sex } = currentObj;
      this.modalParams.roomNum = roomNum;
      this.modalParams.roomType = roomType;
      this.modalParams.inObject = inObject;
      this.modalParams.distributable = distributable;
      this.modalParams.limitSex = sex;
      this.modalParams.roomId = id;
      this.requireRoomDistribute();
    },
    // 保存分配修改
    saveDistribute() {
      let formData = {
        userIds: this.distributeTableData
          .filter(el => el.selected)
          .map(el => el.userId),
        startTime: this.limitQuery.startTime,
        endTime: this.limitQuery.endTime,
        projectId: this.projectId,
        roomId: this.modalParams.roomId
      };
      this.$axios
        .post("/api/rldc/distribution", formData)
        .then(res => {
          this.$Message.success("分配成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求培训项目可选列表
    requireProjectOptions() {
      this.$axios
        .get(`/api/rldc/select`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("培训项目下拉框数据获取失败");
            return false;
          }
          this.projectOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求入住名单
    requireRoomRoster() {
      this.$axios
        .get(`/api/rldc/checkIn/${this.modalParams.roomId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("入住名单数据获取失败");
            return false;
          }
          this.rosterTableData = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求入住分配
    requireRoomDistribute() {
      this.$axios
        .get(
          `/api/rldc/distribution/${this.projectId}/${this.modalParams.roomId}`
        )
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("入住名单数据获取失败");
            return false;
          }
          if (!this.$isEmpty(this.modalParams.limitSex)) {
            data.forEach(
              el => (el.disabled = el.sex !== this.modalParams.limitSex)
            );
          } else {
            data.forEach(el => {
              el.disabled = false;
            });
          }
          data.forEach(el => {
            el.selected = false;
          });
          this.distributeTableData = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 删除一条未入住的用户信息
    reduceRow(index) {
      // 将该用户从名单列表中删除，放入待删除的列表中
      let deleteUser = this.rosterTableData.splice(index, 1)[0];
      this.deleteUserList.push(deleteUser);
    },
    // 入住分配勾选改变
    handleDistributeSelectChange(bool, index) {
      let limit = this.modalParams.distributable;
      let noSelectedList = this.distributeTableData.filter(el => !el.selected);
      let selectedList = this.distributeTableData.filter(el => el.selected);
      if (selectedList.length >= limit) {
        noSelectedList.forEach(el => {
          el.disabled = true;
        });
      } else if (selectedList.length !== 0) {
        let sex = selectedList[0].sex;
        noSelectedList.forEach(el => {
          el.disabled = el.sex !== sex;
        });
      } else {
        noSelectedList.forEach(el => {
          if (!this.$isEmpty(this.modalParams.limitSex)) {
            el.disabled = el.sex !== this.modalParams.limitSex;
          } else {
            el.disabled = false;
          }
        });
      }
      if (bool) {
        let sex = this.distributeTableData[index].sex;
        this.distributeTableData.forEach(el => {
          if (el.sex !== sex) {
            el.disabled = true;
          }
        });
      }
    },
    // 对话框确认的处理方法
    clickOk() {
      if (this.modalOption.key === "roster") {
        this.saveRoster();
      } else {
        this.saveDistribute();
      }
    },

    // 培训项目下拉框改变事件
    handleProjectSelectChange(val) {
      // 获取当前选中的对象
      let selectObj = this.projectOptions.find(el => el.value === val);
      this.limitQuery.startTime = selectObj.startTime;
      this.limitQuery.endTime = selectObj.endTime;
      this.waitToDistributionCount = selectObj.undistributed;
      // 重新请求列表
      this.initLoadTable();
    },
    // 事件选择器变化
    handleDatePickChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = arr[0];
      this.limitQuery.endTime = arr[1];
      // 重新请求列表
      this.initLoadTable();
    },
    // 清空表单数据
    clearFormData() {
      this.deleteUserList = [];
      this.modalParams = {
        // 房间号
        roomNum: "",
        // 房间类型
        roomType: "",
        // 入住对象
        inObject: "",
        // 剩余床位数
        distributable: "",
        // 房间Id
        roomId: "",
        // 限制性别
        limitSex: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearFormData();
      }
    }
  },
  filters: {
    roomTypeFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "一人间";
        case 2:
          return "二人间";
        case 4:
          return "四人间";
        default:
          return "";
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 28;
    }
  }
};
</script>
<style lang="scss" scoped>
.roomDistribution {
  .my-header {
    height: 34px;
    margin-bottom: 10px;
    display: flex;
    padding: 14px;
    justify-content: space-between;
    box-sizing: content-box;
    @extend .header-bg;
    .header-left {
      display: flex;
      align-items: center;
      & > div {
        margin-right: 40px;
      }
    }
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .disable {
    cursor: pointer;
    text-decoration: underline;
    color: $grey;
  }
}
</style>
<style lang="scss">
// 模态框内容的样式设置
.modal-room-distribution {
  .ivu-modal {
    width: 750px !important;
  }
  .modal-content {
    .modal-head {
      display: flex;
      margin-bottom: $top;
      & > div {
        margin-right: 30px;
      }
    }
    .ivu-select {
      width: 200px !important;
    }
    .green {
      color: $theme;
    }
    .red {
      color: $error;
      margin-top: 10px;
    }
    .ivu-checkbox-wrapper {
      margin-right: 0;
    }
    .unReduce,
    .reduce {
      cursor: pointer;
      background: $error;
      margin: 0 auto;
      width: 24px;
      height: 24px;
      text-align: center;
      color: $white;
      border-radius: 50%;
      line-height: 20px;
      font-size: 30px;
    }
    .unReduce {
      background: $grey;
    }
  }
}
</style>
