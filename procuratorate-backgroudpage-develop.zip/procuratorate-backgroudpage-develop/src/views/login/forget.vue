<template>
  <div class="forget">
    <div class="forget-header">
      <div class="logo">
        <img :src="imgUrl" />
      </div>
      <div class="title">
        <span>综合教育培训管理系统</span>
      </div>
      <div></div>
    </div>
    <div class="forget-content">
      <div class="box">
        <div class="header">
          <div>
            <img :src="lockUrl" />
          </div>
          <span>找回密码</span>
        </div>
        <div class="content">
          <i-steps :current="current">
            <i-step title="安全认证"></i-step>
            <i-step title="重置密码"></i-step>
            <i-step title="完成"></i-step>
          </i-steps>
          <template v-if="current === 0">
            <div class="form-area">
              <i-form
                :model="formData1"
                :label-width="140"
                ref="formValidate1"
                :rules="ruleValidate1"
              >
                <i-form-item label="请输入用户名：" required prop="userName">
                  <i-input
                    v-model="formData1.userName"
                    placeholder="请输入"
                    size="large"
                  ></i-input>
                </i-form-item>
                <i-form-item label="请输入验证码：" required prop="captcha">
                  <div class="captcha">
                    <i-input
                      placeholder="请输入"
                      size="large"
                      v-model="formData1.captcha"
                    ></i-input>
                    <i-button
                      size="large"
                      ghost
                      type="primary"
                      @click="clickRequireCaptcha"
                      :loading="loadingTime !== 0"
                    >
                      <span v-if="loadingTime === 0">获取验证码</span>
                      <span v-else>{{ loadingTime }}s后重新获取</span>
                    </i-button>
                  </div>
                  <div class="tip">
                    <span>验证码将以邮箱的形式发送至您的邮箱，</span>
                    <br />
                    <span>如在几分钟内未收到邮箱，请点击重新发送</span>
                  </div>
                </i-form-item>
              </i-form>
            </div>
            <div class="btn-area">
              <i-button size="large" @click="clickPreviou">返回登录</i-button>
              <i-button type="primary" size="large" @click="clickNext"
                >下一步</i-button
              >
            </div>
          </template>
          <template v-else-if="current === 1">
            <div class="form-area">
              <i-form
                :model="formData2"
                :label-width="140"
                ref="formValidate2"
                :rules="ruleValidate2"
              >
                <i-form-item label="请输入新密码：" required prop="passWord">
                  <i-input
                    v-model="formData2.passWord"
                    placeholder="请输入"
                    size="large"
                    type="password"
                    password
                  ></i-input>
                </i-form-item>
                <i-form-item label="请确认密码：" required prop="copyPassWord">
                  <i-input
                    placeholder="请输入"
                    size="large"
                    v-model="formData2.copyPassWord"
                    type="password"
                    password
                  ></i-input>
                </i-form-item>
              </i-form>
            </div>
            <div class="btn-area">
              <i-button size="large" @click="clickPreviou">上一步</i-button>
              <i-button type="primary" size="large" @click="clickNext"
                >下一步</i-button
              >
            </div>
          </template>
          <template v-else-if="current === 2">
            <div class="finish">
              <div>
                <i-icon
                  type="md-checkmark-circle"
                  size="40"
                  color="#188f96"
                ></i-icon>
                <span class="success">修改密码成功</span>
              </div>
              <i-button size="large" @click="clickPreviou" type="primary" ghost
                >返回登录</i-button
              >
            </div>
            <div></div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { Icon, Steps, Step, Button, Form, FormItem, Input } from "view-design";
export default {
  name: "forget",
  components: {
    "i-icon": Icon,
    "i-steps": Steps,
    "i-step": Step,
    "i-button": Button,
    "i-input": Input,
    "i-form": Form,
    "i-form-item": FormItem
  },
  data() {
    return {
      imgUrl: require("../../assets/images/logo2.png"),
      lockUrl: require("../../assets/images/lock.png"),
      current: 0,
      formData1: {
        // 用户名
        userName: "",
        // 验证码
        captcha: ""
      },
      formData2: {
        // 密码
        passWord: "",
        // 重复密码
        copyPassWord: ""
      },
      passwordReg: /^(?!^(\d+|[a-zA-Z]+|[~!@#$%^&*?]+)$)^[\w~!.@#$%^&*?]{8,16}$/,
      // 表单校验规则
      ruleValidate1: {
        userName: [
          {
            required: true,
            message: "请输入用户名"
          }
        ],
        captcha: [
          {
            required: true,
            message: "请输入验证码"
          }
        ]
      },
      ruleValidate2: {
        passWord: [
          {
            validator: (rule, value, callback) => {
              if (value === "") {
                callback(new Error("请输入密码"));
              } else if (!this.passwordReg.test(value)) {
                callback(new Error("8-16位,包含数字、字母、特殊字符中的2种"));
              } else {
                if (this.formData2.copyPassWord !== "") {
                  // 对第二个密码框单独验证
                  this.$refs.formValidate2.validateField("copyPassWord");
                }
                callback();
              }
            }
          }
        ],
        copyPassWord: [
          {
            validator: (rule, value, callback) => {
              if (value === "") {
                callback(new Error("请再次输入密码"));
              } else if (value !== this.formData2.passWord) {
                callback(new Error("两次密码输入不一致"));
              } else {
                callback();
              }
            }
          }
        ]
      },
      // 可以再次发送验证码的时间
      loadingTime: 0,
      timer: null
    };
  },
  methods: {
    // 点击请求验证码
    clickRequireCaptcha() {
      this.$refs.formValidate1.validateField("userName", valid => {
        if (valid === "") {
          this.handleRequireCaptcha();
        }
      });
    },
    // 请求验证码
    handleRequireCaptcha() {
      this.$axios
        .post(`/api/login/sendSms?userName=${this.formData1.userName}`)
        .then(res => {
          this.$Message.success("发送成功");
          this.loadingTime = 60;
          this.readSecond();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 定时器读秒
    readSecond() {
      // 如果之前存在一个定时器
      if (this.timer) {
        // 清空
        clearInterval(this.timer);
      }
      this.timer = setInterval(() => {
        this.loadingTime--;
        this.$log.INFO(this.loadingTime + "后可以重新发送");
        if (this.loadingTime === 0) {
          clearInterval(this.timer);
        }
      }, 1000);
    },
    // 点击上一步
    clickPreviou() {
      // 在安全认证页
      if (this.current === 0 || this.current === 2) {
        this.$router.push("/login");
      }
      if (this.current === 1) {
        this.current--;
      }
    },
    // 点击下一步
    clickNext() {
      if (this.current === 0) {
        this.$refs.formValidate1.validate(valid => {
          if (valid) {
            this.handleCheckCaptcha();
          } else {
            this.$Message.error("请填写正确后再尝试保存！");
          }
        });
      }
      if (this.current === 1) {
        this.$refs.formValidate2.validate(valid => {
          if (valid) {
            this.handleResetPassword();
          } else {
            this.$Message.error("请填写正确后再尝试保存！");
          }
        });
      }
    },
    // 校验验证码
    handleCheckCaptcha() {
      // /login/check/captcha
      this.$axios
        .post(
          `/api/login/check/captcha?userName=${this.formData1.userName}&captcha=${this.formData1.captcha}`
        )
        .then(res => {
          this.current++;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 重置密码
    handleResetPassword() {
      this.$axios
        .post(
          `/api/login/update/passWord?passWord=${encodeURIComponent(
            this.formData2.passWord
          )}&userName=${this.formData1.userName}`
        )
        .then(res => {
          this.current++;
          this.$Message.success("重置密码成功");
          // 清空表单
          this.$refs.formValidate2.resetFields();
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  watch: {
    current(newVal) {
      if (newVal === 0) {
        this.$nextTick(() => {
          this.$refs.formValidate1.resetFields();
        });
      }
      if (newVal === 1) {
        this.$nextTick(() => {
          this.$refs.formValidate2.resetFields();
        });
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.forget {
  .forget-header {
    width: 100%;
    height: $header-height;
    background: $theme;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 40px;
    & > div {
      flex: 1;
    }
    .logo {
      height: $header-height;
      img {
        height: 100%;
      }
    }
    .title {
      font-family: "Arial Negreta", "Arial Normal", "Arial";
      font-weight: 700;
      font-size: 24px;
      color: #fff;
      text-align: center;
      line-height: $header-height;
    }
  }
  .forget-content {
    width: 100%;
    height: calc(100vh - 80px);
    background: #f2f2f2;
    display: flex;
    justify-content: center;
    align-items: center;
    .box {
      width: 60%;
      height: 80%;
      min-width: 1000px;
      display: flex;
      flex-direction: column;
      background: #fff;
      .header {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 120px;
        border-bottom: 1px solid $border-color;
        & > div {
          height: 100px;
        }
        img {
          height: 100%;
        }
        span {
          font-weight: 900;
          @extend .table-font;
          color: #333;
        }
      }
      .content {
        padding: 30px 20px;
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: center;
        .ivu-steps {
          display: flex;
          justify-content: center;
          .ivu-steps-item:last-child {
            width: auto !important;
          }
        }
        .form-area {
          width: 50%;
          max-width: 450px;
          height: 200px;
          .ivu-input-wrapper {
            width: 100% !important;
          }
          .captcha {
            display: flex;
            // width: 70% !important;
            .ivu-input-wrapper {
              width: 55% !important;
              margin-right: 10px;
            }
            .ivu-btn {
              width: 45%;
            }
          }
          .tip {
            font-size: 12px;
            line-height: 24px;
            color: $bz-color;
          }
        }
        .btn-area {
          display: flex;
          justify-content: center;
          .ivu-btn:not(:last-child) {
            margin-right: 10px;
          }
        }
        .finish {
          width: 150px;
          height: 200px;
          text-align: center;
          & > div:first-child {
            margin-bottom: 10px;
          }
          .success {
            margin-left: 10px;
            font-weight: 900;
          }
        }
      }
    }
  }
}
</style>
