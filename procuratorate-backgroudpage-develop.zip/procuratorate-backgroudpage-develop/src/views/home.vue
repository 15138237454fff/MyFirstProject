<template>
  <div class="home">
    <div class="left-area">
      <div class="left-col">
        <i-card>
          <p slot="title" class="card-head">
            <span> <img :src="courseIconUrl" /> 未发布的培训课程 </span>
            <router-link :to="seeMorePath">查看更多</router-link>
          </p>
          <ul>
            <li
              class="msg-item"
              v-for="(item, index) of unreleasedCourse"
              :key="index"
            >
              <span class="text-ellipsis">{{ item.name }}</span>
              <span class="time text-ellipsis">{{
                item.time | toDateTime
              }}</span>
            </li>
          </ul>
        </i-card>
        <i-card>
          <p slot="title" class="card-head">
            <span> <img :src="projectIconUrl" /> 未安排的培训项目 </span>
            <router-link :to="seeMorePath">查看更多</router-link>
          </p>
          <ul>
            <li
              class="msg-item"
              v-for="(item, index) of unreleasedCourse"
              :key="index"
            >
              <span class="text-ellipsis">{{ item.name }}</span>
              <span class="time text-ellipsis">{{
                item.time | toDateTime
              }}</span>
            </li>
          </ul>
        </i-card>
        <i-card>
          <p slot="title" class="card-head">
            <span> <img :src="waitIconUrl" /> 待审核的培训课程 </span>
            <router-link :to="seeMorePath">查看更多</router-link>
          </p>
          <ul>
            <li
              class="msg-item"
              v-for="(item, index) of unreleasedCourse"
              :key="index"
            >
              <span class="text-ellipsis">{{ item.name }}</span>
              <span class="time text-ellipsis">{{
                item.time | toDateTime
              }}</span>
            </li>
          </ul>
        </i-card>
      </div>
      <div class="right-col">
        <i-card>
          <p slot="title" class="card-head">
            <span> <img :src="projectIconUrl" /> 未报名的培训项目 </span>
            <router-link :to="seeMorePath">查看更多</router-link>
          </p>
        </i-card>
        <i-card>
          <p slot="title" class="card-head">
            <span> <img :src="leaveIconUrl" /> 待审核的请假申请 </span>
            <router-link :to="seeMorePath">查看更多</router-link>
          </p>
        </i-card>
        <i-card>
          <p slot="title" class="card-head">
            <span> <img :src="sourceIconUrl" /> 待审核的教学资源 </span>
            <router-link :to="seeMorePath">查看更多</router-link>
          </p>
        </i-card>
      </div>
    </div>
    <div class="right-area">
      <i-card>
        <p slot="title" class="card-head">
          <span> <img :src="noticeIconUrl" /> 通知公告 </span>
          <router-link :to="seeMoreNotice">查看更多</router-link>
        </p>
        <ul class="msg-list">
          <li
            class="msg-item"
            v-for="(item, index) of noticeList"
            :key="index"
            :class="{ setTop: item.stick }"
            @click="goToNociceDetail(item.id)"
          >
            <span class="text-ellipsis">{{ item.title }}</span>
            <span class="time text-ellipsis">{{
              $tagTime(item.publishTime, "yyyy-MM-dd HH:mm")
            }}</span>
          </li>
        </ul>
      </i-card>
    </div>
  </div>
</template>
<script>
import { Card } from "view-design";
export default {
  name: "home",
  components: {
    "i-card": Card
  },
  data() {
    return {
      waitIconUrl: require("../assets/icons/home/wait.png"),
      sourceIconUrl: require("../assets/icons/home/source.png"),
      projectIconUrl: require("../assets/icons/home/project.png"),
      noticeIconUrl: require("../assets/icons/home/notice.png"),
      leaveIconUrl: require("../assets/icons/home/leave.png"),
      courseIconUrl: require("../assets/icons/home/course.png"),
      seeMorePath: "/home",
      seeMoreNotice: "/homeNotice",
      unreleasedCourse: [
        { name: "测试课程测试课程测试课程测试课程", time: 1567566713746 },
        { name: "测试课程", time: 1567566713746 },
        { name: "测试课程", time: 1567566713746 },
        { name: "测试课程", time: 1567566713746 }
      ],
      noticeList: []
    };
  },
  mounted() {
    // 获取通知公告列表
    this.requireNoticeList();
  },
  methods: {
    // 请求通知公告列表
    requireNoticeList() {
      this.$axios
        .post(`/api/notice/home`, { pageNum: 1, pageSize: 10, query: "" })
        .then(res => {
          let data = res.data.data;
          if (!data || !Array.isArray(data.list)) {
            console.error("通知公告列表获取失败");
            return false;
          }
          this.noticeList = data.list;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 前往查看通知详情
    goToNociceDetail(id) {
      this.$router.push(`/homeNoticeDetail/${id}`);
    }
  }
};
</script>
<style lang="scss" scoped>
.home {
  width: 100%;
  height: 100%;
  display: flex;
  .left-area {
    width: 60%;
    display: flex;
    .left-col,
    .right-col {
      width: 50%;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding-right: $left-padding;
      .ivu-card {
        flex: 1;
        padding-bottom: $top;
        overflow: hidden;
      }
      .card-head {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        height: 100%;
        @extend .table-font;
        img {
          width: 24px;
          vertical-align: bottom;
        }
        a {
          color: $theme;
          line-height: 24px;
          font-size: 14px;
        }
      }
      .msg-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 12px;
        cursor: pointer;
        span:first-child {
          flex: 2;
          padding-right: $left;
        }
        .time {
          flex: 1;
          color: $bz-color;
          text-align: right;
        }
      }
    }
    .ivu-card:not(:first-child) {
      margin-top: $top;
    }
    /deep/ .ivu-card-head {
      padding: $left;
    }
    /deep/ .ivu-card-body {
      padding: $left;
      padding-top: 10px;
    }
  }
  .right-area {
    width: 40%;
    overflow: hidden;
    .ivu-card {
      height: 100%;
    }
    /deep/ .ivu-card-body {
      height: calc(100% - 51px);
      overflow: hidden;
    }
    .card-head {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      height: 100%;
      img {
        width: 24px;
        vertical-align: bottom;
      }
      span {
        @extend .table-font;
      }
      a {
        color: $theme;
        line-height: 24px;
        font-size: 14px;
      }
    }
    .msg-list {
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      height: 100%;
    }
    .msg-item {
      display: flex;
      justify-content: space-between;
      line-height: 46px;
      height: 46px;
      cursor: pointer;
      span:first-child {
        flex: 2;
        padding-right: $left;
        padding-left: 16px;
      }
      .time {
        flex: 1;
        color: $bz-color;
        text-align: right;
      }
      &.setTop {
        background: url("../assets/images/top.png") #fffaeb no-repeat 0px 0px;
        background-size: 30px;
      }
    }
  }
}
</style>
