<template>
  <div class="toolReceive">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训课程/申请人"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="detailsVOS">
          <i-tooltip
            :max-width="450"
            :content="row.detailsVOS | detailsVOSFilter"
            >{{ row.detailsVOS | detailsVOSFilter }}
          </i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="trainingTime">
          <i-tooltip
            :max-width="450"
            :content="
              `${row.trainingTimeStart ? row.trainingTimeStart + ' 至' : ''}  ${
                row.traininTimeEnd ? row.traininTimeEnd : ''
              }`
            "
            >{{ row.trainingTimeStart ? row.trainingTimeStart + " 至" : "" }}
            {{ row.traininTimeEnd }}
          </i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="receiveName">
          <span>{{ row.receiveName }}</span>
        </template>
        <template slot-scope="{ row }" slot="receiveTime">
          <span v-if="row.status === 3004">未领取</span>
          <i-tooltip :content="row.receiveTime" v-else>{{
            row.receiveTime
          }}</i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            @click="clickModify(row.projectClassapplyId)"
            class="receive"
            v-if="row.status === 3001 && $btnAuthorityTest('tool:receive')"
            >领取</span
          >
          <span class="disable" v-else-if="$btnAuthorityTest('tool:receive')"
            >领取</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <i-table
          :data="modalOption.toolDetail"
          :columns="modalColOption"
          :border="true"
        >
          <template slot-scope="{ row }" slot="receiveList">
            <i-tooltip
              :transfer="true"
              :content="`${row.useNumber} ${row.toolUnit}    ${row.toolName}`"
              >{{
                `${row.useNumber} ${row.toolUnit}    ${row.toolName}`
              }}</i-tooltip
            >
          </template>
          <template slot-scope="{ row }" slot="actualCount">
            <template v-if="row.toolStock">
              <span v-if="row.useNumber <= row.toolStock"
                >{{ row.toolStock }}个</span
              >
              <span v-else class="red"> {{ row.toolStock }}个(不足) </span>
            </template>
          </template>
        </i-table>
        <div class="row">
          <div class="required">领取人：</div>
          <div>
            <i-input
              size="large"
              v-model="formData.receiveName"
              placeholder="请输入"
            ></i-input>
          </div>
        </div>
        <div class="row" v-if="!isEnough">
          <span class="red">剩余数量不足，请选择领取实际数量或稍后领取？</span>
        </div>
      </div>
      <p slot="footer">
        <template v-if="isEnough">
          <i-button size="large" @click="clickCancel">取消</i-button>
          <i-button size="large" type="primary" @click="clickReceive"
            >领取</i-button
          >
        </template>
        <template v-else>
          <i-button size="large" @click="clickReceive">领取实际数量</i-button>
          <i-button size="large" type="primary" @click="clickCancel"
            >稍后领取</i-button
          >
        </template>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Table, Input, Button, Tooltip } from "view-design";
import myModal from "@/components/common/myModal";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "toolReceive",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "培训课程", align: "center", key: "className", tooltip: true },
        { title: "申请明细", align: "center", slot: "detailsVOS" },
        { title: "申请人", align: "center", key: "applyUser", tooltip: true },
        { title: "使用时间", align: "center", slot: "trainingTime" },
        { title: "使用场地", align: "center", key: "siteName" },
        { title: "领取人", align: "center", slot: "receiveName" },
        { title: "领取时间", align: "center", slot: "receiveTime", width: 200 },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      modalColOption: [
        {
          title: "领取清单",
          align: "left",
          slot: "receiveList",
          tooltip: true
        },
        { title: "实际数量", align: "left", slot: "actualCount", tooltip: true }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {
        // 项目安排后的课程id
        projectClassapplyId: "",
        // 领取人
        receiveName: ""
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-tool-receive",
        toolDetail: []
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/tools/listReceive", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击修改按钮
    clickModify(id) {
      // 保存当前修改的申请id
      this.formData.projectClassapplyId = id;
      this.modalOption.title = "领取教学用具";
      this.requireReceiveDetail();
    },
    // 获取领取的详情信息
    requireReceiveDetail() {
      this.$axios
        .get(`/api/tools/receiveInfo/${this.formData.projectClassapplyId}`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("领取详情数据获取失败");
            return;
          }
          this.modalOption.toolDetail = data;
          this.modalOption.modalVisiabal = true;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击领取按钮
    clickReceive(index) {
      if (this.formData.receiveName === "") {
        this.$Message.error("领取人不能为空");
        return;
      }
      this.$axios
        .put("/api/tools/receive", this.formData)
        .then(res => {
          this.modalOption.modalVisiabal = false;
          this.$Message.success("领取成功");
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickCancel() {
      this.modalOption.modalVisiabal = false;
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 项目安排后的课程id
        projectClassapplyId: "",
        // 领取人
        receiveName: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 重置表单
        this.clearFormData();
      }
    }
  },
  filters: {
    detailsVOSFilter(list) {
      if (!Array.isArray(list)) {
        console.error("用具详情列表格式不正确");
        return "";
      }
      let tmpArr = list.map(el => {
        return `${el.useNumber} ${el.toolUnit}    ${el.toolName}`;
      });
      return tmpArr.join("\n");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    // 领取教学用具是否充足
    isEnough() {
      let sign = true;
      this.modalOption.toolDetail.forEach(el => {
        if (el.useNumber > el.toolStock) {
          sign = false;
        }
      });
      return sign;
    }
  }
};
</script>
<style lang="scss" scoped>
.toolReceive {
  .disable {
    color: $grey;
  }
  .receive {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
<style lang="scss">
.modal-tool-receive {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 360px !important;
  }
  .modal-content {
    .row {
      display: flex;
      margin-top: 20px;
      & > div {
        &:first-child {
          width: 100px;
          text-align: right;
          line-height: 34px;
          padding-right: 10px;
        }
      }
    }
  }
  .red {
    color: $error;
  }
}
</style>
