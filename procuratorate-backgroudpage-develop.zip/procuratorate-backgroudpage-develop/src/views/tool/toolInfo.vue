<template>
  <div class="toolInfo">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-select
          size="large"
          v-model="limitQuery.toolCategoryId"
          @on-change="initLoadTable"
        >
          <i-option
            v-for="(item, index) of moreToolCategoryOptions"
            :key="index"
            :value="item.value"
            >{{ item.label }}</i-option
          >
        </i-select>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('tool:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('tool:delete')"
          >删除</i-button
        >
        <i-button size="large" @click="handleDown" type="primary" ghost
          >下载模板</i-button
        >
        <i-dropdown trigger="click" @on-click="handleDropdownItemClick">
          <i-button size="large" type="primary" ghost>
            批量操作
            <i-icon type="ios-arrow-down"></i-icon>
          </i-button>
          <i-dropdown-menu slot="list">
            <i-dropdown-item name="input">导入</i-dropdown-item>
            <i-dropdown-item name="output">导出</i-dropdown-item>
          </i-dropdown-menu>
        </i-dropdown>
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="isNeedReturn">
          <span>{{ row.isNeedReturn | isNeedReturnFilter }}</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            @click="clickSupply(row.toolName, row.toolId)"
            class="supply"
            v-if="$btnAuthorityTest('tool:addStock')"
            >补充数量</span
          >
          <span v-if="row.isGray">&nbsp;|&nbsp;</span>
          <span
            @click="clickModify(row.toolId)"
            class="modify"
            v-if="row.isGray && $btnAuthorityTest('tool:update')"
            >修改</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="modalOption.key === 'supply'">
          <i-form
            :model="formDataSupply"
            :label-width="140"
            ref="formValidateSupply"
            :rules="ruleValidateSupply"
          >
            <i-form-item label="教学用具：">
              <span>{{ toolName }}</span>
            </i-form-item>
            <i-form-item
              label="请输入补充数量："
              required
              prop="addNum"
              :label-width="140"
            >
              <i-input
                v-model="formDataSupply.addNum"
                placeholder="请输入"
                size="large"
                number
              ></i-input>
            </i-form-item>
          </i-form>
        </template>
        <template v-else>
          <i-form
            :model="formData"
            :label-width="100"
            ref="formValidate"
            :rules="ruleValidate"
          >
            <i-form-item label="名   称：" required prop="toolName">
              <i-input
                v-model="formData.toolName"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
            <i-form-item label="类   型：" required prop="toolCategoryId">
              <i-select
                v-model="formData.toolCategoryId"
                size="large"
                placeholder="请选择"
              >
                <i-option
                  v-for="(item, index) of toolCategoryOptions"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </i-form-item>
            <i-form-item label="单   位：" required prop="toolUnit">
              <i-input
                v-model="formData.toolUnit"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
            <i-form-item
              label="是否需要归还："
              required
              prop="isNeedReturn"
              :label-width="120"
            >
              <i-radio-group v-model="formData.isNeedReturn">
                <i-radio :label="1001">是</i-radio>
                <i-radio :label="1002">否</i-radio>
              </i-radio-group>
            </i-form-item>
            <i-form-item label="总数量：" required prop="toolTotal">
              <i-input
                v-model="formData.toolTotal"
                placeholder="请输入"
                size="large"
                number
              ></i-input>
            </i-form-item>
          </i-form>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" @click="modalOption.modalVisiabal = false"
          >取消</i-button
        >
        <i-button size="large" type="primary" @click="clickOk">{{
          modalOption.key === "supply" ? "确定" : "保存"
        }}</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Icon,
  RadioGroup,
  Radio,
  Form,
  FormItem,
  Dropdown,
  DropdownMenu,
  DropdownItem
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "toolInfo",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-icon": Icon,
    "i-radio-group": RadioGroup,
    "i-radio": Radio,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-dropdown": Dropdown,
    "i-dropdown-menu": DropdownMenu,
    "i-dropdown-item": DropdownItem,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "名称",
          align: "center",
          key: "toolName",
          tooltip: true
        },
        {
          title: "类型",
          align: "center",
          key: "toolCategoryId",
          tooltip: true
        },
        { title: "单位", align: "center", key: "toolUnit", width: 120 },
        {
          title: "是否需要归还",
          align: "center",
          slot: "isNeedReturn",
          width: 150
        },
        {
          title: "总数量",
          align: "center",
          key: "toolTotal",
          tooltip: true,
          width: 150
        },
        {
          title: "剩余数量",
          align: "center",
          key: "toolStock",
          tooltip: true,
          width: 150
        },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],

      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 教学用具类型
        toolCategoryId: -1
      },
      // 待提交的表单数据
      formData: {
        // 是否需要归还 1001-需要归还 1002-不需要归还
        isNeedReturn: "",
        // 教学用具种类ID
        toolCategoryId: "",
        // 教学用具名称
        toolName: "",
        // 教学用具总数量
        toolTotal: "",
        // 教学用具单位
        toolUnit: ""
      },
      formDataSupply: {
        // 补充数量
        addNum: "",
        // 教学用具id
        toolId: ""
      },
      // 表单校验规则
      ruleValidate: {
        toolName: [
          {
            required: true,
            message: "名称不能为空"
          },
          {
            max: 20,
            message: "名称长度不能超过20位"
          }
        ],
        toolCategoryId: [
          {
            required: true,
            message: "类型不能为空"
          }
        ],
        toolUnit: [
          {
            required: true,
            message: "单位不能为空"
          },
          {
            max: 2,
            message: "单位不能超过2位"
          }
        ],
        isNeedReturn: [
          {
            required: true,
            message: "是否需要归还不能为空"
          }
        ],
        toolTotal: [
          {
            required: true,
            message: "总数量不能为空"
          },
          {
            type: "number",
            max: 99999,
            message: "总数量不能超过99999"
          }
        ]
      },
      ruleValidateSupply: {
        addNum: [
          {
            required: true,
            message: "补充数量不能为空"
          },
          {
            type: "number",
            max: 9999,
            message: "补充数量应小于9999"
          }
        ]
      },
      // 教学用具类型参数的id
      paramsId: "XP-004",
      // 教学用具可选列表
      toolCategoryOptions: [],
      // 当前操作的Id
      id: "",
      // 当前要补充的用具名称
      toolName: "",
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-tool-info"
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求教学用具类型列表
    this.requireToolCategoryOptions();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = { ...this.limitQuery };
      if (tmpObj.toolCategoryId === -1) {
        tmpObj.toolCategoryId = "";
      }
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/tools/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 添加
    clickAdd() {
      this.modalOption.title = "添加";
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
    },
    // 点击修改的处理函数
    clickModify(id) {
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      // 保存当前修改的记录id
      this.id = id;
      // 数据回显
      this.dataCallBack();
    },
    // 点击补充数量
    clickSupply(name, id) {
      this.modalOption.title = "补充数量";
      this.modalOption.key = "supply";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-tool-info-supply";
      // 保存当前补充数量的用具名称和id
      this.toolName = name;
      this.formDataSupply.toolId = id;
    },
    // 请求用具的可选列表的方法
    requireToolCategoryOptions() {
      this.$axios
        .get(`/api/param/select/${this.paramsId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("教学用具类型下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.toolCategoryOptions = data.map(el => {
            return { value: el.title, label: el.title };
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 数据回显
    dataCallBack() {
      this.$axios
        .get("/api/tools/getById", {
          params: { toolId: this.id }
        })
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.formData.toolCategoryId = data.toolCategoryName;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      // 待提交的id列表
      let ids = [];
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.toolId);
      this.$axios
        .delete("/api/tools/delete", { data: ids })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    testFormSupply() {
      let sign = true;
      this.$refs.formValidateSupply.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    // 对话框确认的处理方法
    clickOk() {
      // 如果当前对话框为补充数量
      if (this.modalOption.key === "supply") {
        // 表单数据通过验证
        if (this.testFormSupply()) {
          this.saveSupply();
        }
        return;
      }
      // 获取表单验证结果
      let sign = this.testForm();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      // 根据key值调用不同的方法
      if (this.modalOption.key === "add") {
        this.saveAdd();
      }
      if (this.modalOption.key === "modify") {
        this.saveModify();
      }
    },
    // 保存添加的信息
    saveAdd() {
      this.$axios
        .post("/api/tools/insert", this.formData)
        .then(res => {
          this.$Message.success("添加成功");
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 保存修改的信息
    saveModify() {
      this.$axios
        .put(
          `/api/tools/update`,
          Object.assign({}, this.formData, { toolId: this.id })
        )
        .then(res => {
          this.$Message.success("修改成功");
          // 重新渲染列表
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    saveSupply() {
      this.$log.INFO("保存补充数量数据");
      this.$axios
        .put(`/api/tools/addStock`, this.formDataSupply)
        .then(res => {
          this.$Message.success("补充成功");
          // 重新渲染列表
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 清空表单数据
    clearFormData() {
      this.$refs.formValidate.resetFields();
      this.formData = {
        // 是否需要归还 1001-需要归还 1002-不需要归还
        isNeedReturn: "",
        // 教学用具种类ID
        toolCategoryId: "",
        // 教学用具名称
        toolName: "",
        // 教学用具总数量
        toolTotal: "",
        // 教学用具单位
        toolUnit: ""
      };
    },
    // 清空表单数据-补充数量
    clearFormDataSupply() {
      this.$refs.formValidateSupply.resetFields();
      this.formDataSupply = {
        // 补充数量
        addNum: "",
        // 教学用具id
        toolId: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        if (this.modalOption.key === "supply") {
          this.clearFormDataSupply();
        } else {
          this.clearFormData();
        }
      }
    },
    // 下载模板
    handleDown() {
      this.$log.INFO("正在下载模板");
    },
    // 导入的方法
    handleInput() {
      this.$log.INFO("正在导入");
    },
    // 导出的方法
    handleOutput() {
      this.$log.INFO("正在导出");
    },
    // 处理下拉项点击事件的方法
    handleDropdownItemClick(name) {
      if (name === "input") {
        // 调用导入
        this.handleInput();
      } else {
        // 调用导出
        this.handleOutput();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    moreToolCategoryOptions() {
      return [{ value: -1, label: "全部类型" }].concat(
        this.toolCategoryOptions
      );
    }
  },
  filters: {
    isNeedReturnFilter(val) {
      if (typeof val !== "number") {
        console.error("过滤的是否需要归还参数格式错误");
        return "";
      }
      switch (val) {
        case 1001:
          return "是";
        case 1002:
          return "否";
        default:
          return "";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.toolInfo {
  .ivu-dropdown-menu {
    min-width: 90px;
  }
  .ivu-dropdown-item {
    color: $theme;
    text-align: center;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .disable {
    color: $grey;
  }
  .supply {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-tool-info {
  .ivu-modal {
    width: 360px !important;
  }
  .modal-content {
    .ivu-select {
      width: 200px !important;
    }
  }
}
.modal-tool-info-supply {
  .ivu-modal {
    width: 360px !important;
  }
  .ivu-form-item:first-child {
    margin-bottom: $top;
  }
  .ivu-input-wrapper {
    width: auto !important;
  }
  .ivu-select {
    width: auto !important;
  }
}
</style>
