<template>
  <div class="toolReturn">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训课程/领取人"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-date-picker
          type="daterange"
          separator=" 至 "
          placeholder="请输入查询时间段"
          :value="[limitQuery.startTime, limitQuery.endTime]"
          @on-change="handleListTimeChange"
          size="large"
          :editable="false"
        ></i-date-picker>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="detailsVOS">
          <i-tooltip
            :max-width="450"
            :content="row.detailsVOS | detailsVOSFilter"
            >{{ row.detailsVOS | detailsVOSFilter }}
          </i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="trainingTime">
          <i-tooltip
            :max-width="450"
            :content="
              `${row.trainingTimeStart ? row.trainingTimeStart + ' 至' : ''}  ${
                row.traininTimeEnd ? row.traininTimeEnd : ''
              }`
            "
            >{{ row.trainingTimeStart ? row.trainingTimeStart + "至" : "" }}
            {{ row.traininTimeEnd }}
          </i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="returnName">
          <span>{{ row.returnName }}</span>
        </template>
        <template slot-scope="{ row }" slot="returnTime">
          <i-tooltip
            :content="row.returnTime"
            :transfer="true"
            max-width="300px"
            >{{ row.returnTime }}</i-tooltip
          >
        </template>
        <template slot-scope="{ row, index }" slot="action">
          <span
            @click="clickReturn(index)"
            class="return"
            v-if="row.status === 3002 && $btnAuthorityTest('tool:return')"
            >归还</span
          >
          <span class="look" v-if="row.status === 3003" @click="clickSee(index)"
            >查看</span
          >
        </template>
      </i-table>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <template v-if="modalOption.key === 'return'">
        <div class="modal-content">
          <i-form :model="formData" :label-width="100" ref="formValidate">
            <i-form-item label="归还人：">
              <i-input
                v-model="formData.returnName"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
          </i-form>
          <i-table :data="detailsVOS" :columns="modalColOption" :border="true">
            <template slot-scope="{ row }" slot="detailsVOS">
              <span>{{
                `${row.useNumber} ${row.toolUnit}    ${row.toolName}`
              }}</span>
            </template>
            <template slot-scope="{ row, index }" slot="returnNum">
              <input-number
                v-model="formData.returnDetailDTOs[index].returnNumber"
                placeholder="请输入"
                size="large"
                :min="0"
                :max="row.useNumber"
              ></input-number>
            </template>
          </i-table>
        </div>
        <p slot="footer">
          <i-button size="large" @click="modalOption.modalVisiabal = false"
            >取消</i-button
          >
          <i-button size="large" type="primary" @click="clickOk">确认</i-button>
        </p>
      </template>
      <template v-else>
        <i-form :model="formData" :label-width="100" ref="formValidate">
          <i-form-item label="归还人：">
            {{ formData.returnName }}
          </i-form-item>
          <i-form-item label="归还时间：">
            {{ formData.returnTime }}
          </i-form-item>
        </i-form>
        <i-table :data="detailsVOS" :columns="modalColOption" :border="true">
          <template slot-scope="{ row }" slot="detailsVOS">
            <span>{{
              `${row.useNumber} ${row.toolUnit}    ${row.toolName}`
            }}</span>
          </template>
          <template slot-scope="{ row }" slot="returnNum">
            {{ row.returnNumber }}
          </template>
        </i-table>
      </template>
    </my-modal>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  DatePicker,
  Tooltip,
  Form,
  InputNumber,
  FormItem
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "toolReturn",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "i-date-picker": DatePicker,
    "i-form": Form,
    "input-number": InputNumber,
    "i-form-item": FormItem,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "培训课程", align: "center", key: "className", tooltip: true },
        { title: "领取明细", align: "center", slot: "detailsVOS" },
        { title: "领取人", align: "center", key: "receiveName", tooltip: true },
        { title: "使用时间", align: "center", slot: "trainingTime" },
        { title: "使用场地", align: "center", key: "siteName" },
        { title: "归还人", align: "center", slot: "returnName" },
        { title: "归还时间", align: "center", slot: "returnTime", width: 200 },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        startTime: "",
        endTime: ""
      },
      // 待提交的表单数据
      formData: {
        // 项目安排后的课程id
        projectClassapplyId: "",
        returnDetailDTOs: [],
        // 归还人
        returnName: ""
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-tool-return"
      },
      // 对话框内表格配置项
      modalColOption: [
        { title: "领取明细", align: "center", slot: "detailsVOS" },
        { title: "归还数量", align: "center", slot: "returnNum" }
      ],
      // 对话框中要显示的用具详细信息列表
      detailsVOS: [],
      // 日期选择器的禁止选择日期范围
      dateOption: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        }
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 查询时间从00：00：00 分改为 23：59：59
      this.limitQuery.endTime = this.$endTime(this.limitQuery.endTime);
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/tools/listReturn", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 处理接收人改变的方法
    handleReceiveNameChange(event) {
      this.formData.receiveName = event.target.value;
    },
    // 列表查询时的时间段改变的方法
    handleListTimeChange(arr) {
      // 从结果数组中取出开始和结束时间
      this.limitQuery.startTime = new Date(arr[0] + " " + "00:00:00");
      this.limitQuery.endTime = new Date(arr[1]);
      this.loadTable();
    },
    // 点击归还按钮
    clickReturn(index) {
      this.$log.INFO("归还");
      let obj = this.tableData[index];
      // 保存当前修改的申请id
      this.formData.projectClassapplyId = obj.projectClassapplyId;
      this.detailsVOS = obj.detailsVOS;
      this.formData.returnDetailDTOs = obj.detailsVOS.map(el => {
        return { toolId: el.toolId, returnNumber: 0 };
      });
      this.modalOption.title = "归还";
      this.modalOption.key = "return";
      this.modalOption.modalVisiabal = true;
    },
    // 点击查看按钮
    clickSee(index) {
      this.$log.INFO("查看");
      let obj = this.tableData[index];
      this.formData.projectClassapplyId = obj.projectClassapplyId; // 保存当前修改的申请id
      this.formData.returnName = obj.returnName;
      this.formData.returnTime = obj.returnTime;
      this.detailsVOS = obj.detailsVOS;
      this.modalOption.title = "查看";
      this.modalOption.key = "see";
      this.modalOption.modalVisiabal = true;
    },
    // 对话框确认的处理方法
    clickOk() {
      if (this.modalOption.key === "return") {
        if (this.$isEmpty(this.formData.returnName)) {
          this.$Message.error("请输入归还人");
          return;
        }
        for (
          let index = 0;
          index < this.formData.returnDetailDTOs.length;
          index++
        ) {
          const element = this.formData.returnDetailDTOs[index];
          if (this.$isEmpty(element.returnNumber)) {
            this.$Message.error("请输入正确的归还数量");
            return;
          }
        }
        this.saveReturn();
      }
    },
    // 保存归还信息
    saveReturn() {
      this.$log.INFO("归还");
      this.$axios
        .put("/api/tools/return", this.formData)
        .then(res => {
          this.$Message.success("归还成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      // 在隐藏时清空表单
      if (!bool) {
        // 清空表单
        this.$refs.formValidate.resetFields();
        this.clearFormData();
      }
    },
    // 清空表单数据
    clearFormData() {
      this.detailsVOS = [];
      this.formData = {
        // 项目安排后的课程id
        projectClassapplyId: "",
        returnDetailDTOs: [],
        // 归还人
        returnName: ""
      };
    }
  },
  filters: {
    detailsVOSFilter(list) {
      if (!Array.isArray(list)) {
        console.error("用具详情列表格式不正确");
        return "";
      }
      let tmpArr = list.map(el => {
        return `${el.useNumber} ${el.toolUnit}    ${el.toolName}`;
      });
      return tmpArr.join("\n");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.toolReturn {
  .return {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
    opacity: 0.8;
  }
  .look {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
.modal-tool-return {
  .ivu-modal {
    width: 360px !important;
  }
  .ivu-table-cell {
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
  .ivu-form-item:not(.ivu-form-item-required) {
    margin-bottom: 20px;
  }
}
</style>
