<template>
  <div class="vehicleArrangement">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训项目/课程"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="sex">
          <span>{{ row.sex | sexFilter }}</span>
        </template>
        <template slot-scope="{ row }" slot="classTime">
          <i-tooltip
            :content="
              `${$tagTime(row.trainingTimeStart, 'yyyy-MM-dd HH:mm')} ~
                ${$tagTime(row.trainingTimeEnd, 'HH:mm')}`
            "
            :transfer="true"
          >
            {{ $tagTime(row.trainingTimeStart, "yyyy-MM-dd HH:mm") }} ~
            {{ $tagTime(row.trainingTimeEnd, "HH:mm") }}
          </i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            class="modify"
            v-if="row.status === 1 && $btnAuthorityTest('arrange:use')"
            @click="arrangeVehicle(row)"
            >安排车辆</span
          >
          <span
            class="modify"
            v-if="row.status === 2 && $btnAuthorityTest('arrange:adjust')"
            @click="adjustVehicle(row)"
            >调整安排</span
          >
          <span class="modify" v-if="row.status === 3" @click="viewVehicle(row)"
            >查看车辆</span
          >
          <span class="red" v-if="row.status === 4">未安排车辆</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <i-row>
          <i-col span="12">
            <span>培训项目：{{ project.projectName }}</span>
          </i-col>
          <i-col span="12">
            <span>培训课程：{{ project.className }}</span>
          </i-col>
        </i-row>
        <div
          v-if="modalOption.key === 'arrange' || modalOption.key === 'adjust'"
        >
          <i-row class="time">
            <i-col span="12">
              <span
                >课程时间：{{ project.trainingTimeStart }}~{{
                  project.trainingTimeEnd
                }}</span
              >
            </i-col>
            <i-col span="12">
              <span
                >用车时间：<date-picker
                  type="datetime"
                  style="width: 200px"
                  v-model="project.startTime"
                  format="yyyy-MM-dd HH:mm"
                  size="large"
                  :options="dateOption"
                ></date-picker
              ></span>
            </i-col>
          </i-row>
          <i-row style="padding-top:20px;padding-bottom:10px">
            <i-col span="12">
              <span
                >用车人数：{{ project.carUseMember }}人（已选座位数：{{
                  selectedHistoryList.reduce((prev, el) => {
                    return el.vehicleSeating + prev;
                  }, 0)
                }}）</span
              >
            </i-col>
            <i-col span="12">
              <span>目的地：{{ project.destination }}</span>
            </i-col>
          </i-row>
        </div>
        <div v-else>
          <i-row style="padding-top:20px">
            <i-col span="12">
              <span>用车人数：{{ project.carUseMember }}人</span>
            </i-col>
            <i-col span="12">
              <span>用车时间：{{ project.startTime }}</span>
            </i-col>
          </i-row>
          <i-row style="padding-top:20px;padding-bottom:10px">
            <i-col span="12">
              <span>目的地：{{ project.destination }}</span>
            </i-col>
          </i-row>
        </div>
        <i-table
          :height="400"
          :data="vehicleList"
          :columns="
            modalOption.key === 'view' ? vehicleViewOption : vehicleOption
          "
          :border="true"
          @on-selection-change="handleSelectChange"
          ref="selection"
        >
        </i-table>
      </div>
      <p
        slot="footer"
        v-if="modalOption.key === 'arrange' || modalOption.key === 'adjust'"
      >
        <i-button size="large" @click="modalOption.modalVisiabal = false"
          >取消</i-button
        >
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Row,
  Col,
  DatePicker,
  Tooltip
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "vehicleArrangement",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-row": Row,
    "i-col": Col,
    "i-tooltip": Tooltip,
    "date-picker": DatePicker,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 车辆表格列
      vehicleOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "车辆名称",
          align: "center",
          key: "vehicleName",
          tooltip: true
        },
        { title: "品牌", align: "center", key: "vehicleBrand", tooltip: true },
        { title: "型号", align: "center", key: "vehicleModel", tooltip: true },
        {
          title: "座位数",
          align: "center",
          key: "vehicleSeating",
          tooltip: true
        }
      ],
      // 车辆表格列
      vehicleViewOption: [
        {
          title: "车辆名称",
          align: "center",
          key: "vehicleName",
          tooltip: true
        },
        { title: "品牌", align: "center", key: "vehicleBrand", tooltip: true },
        { title: "型号", align: "center", key: "vehicleModel", tooltip: true },
        {
          title: "座位数",
          align: "center",
          key: "vehicleSeating",
          tooltip: true
        }
      ],
      // 车辆信息
      vehicleList: [],
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "index", width: 80, align: "center", title: "序号" },
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "培训课程", align: "center", key: "className", tooltip: true },
        {
          title: "课程时间",
          align: "center",
          slot: "classTime",
          tooltip: true,
          width: 200
        },
        {
          title: "用车人数",
          align: "center",
          key: "carUseMember",
          tooltip: true,
          width: 120
        },
        { title: "用车时间", align: "center", key: "startTime", tooltip: true },
        { title: "目的地", align: "center", key: "destination", tooltip: true },
        { title: "申请人", align: "center", key: "applicant", tooltip: true },
        { title: "安排车辆", align: "center", width: 120, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {},
      // 车辆型号可选列表
      vehicleModelOptions: [],
      // 当前操作的Id
      id: "",
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 项目信息
      project: {},
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-vehicle-info"
      },
      // 日期选择器的禁止选择日期范围
      dateOption: {
        disabledDate(date) {
          if (!date) {
            return false;
          }
          return date.valueOf() < Date.now() - 86400000;
        }
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 查看车辆
    viewVehicle(row) {
      this.project = JSON.parse(JSON.stringify(row));
      // 查询车辆信息
      this.queryArrangementInfo();
      this.modalOption.modalVisiabal = true;
      this.modalOption.key = "view";
      this.modalOption.title = "查看车辆";
    },
    // 调整安排
    adjustVehicle(row) {
      // 查询可安排车辆信息
      this.queryNoUseArrangementInfo();
      this.project = JSON.parse(JSON.stringify(row));
      this.modalOption.modalVisiabal = true;
      this.modalOption.key = "adjust";
      this.modalOption.title = "调整安排";
    },
    // 确认事件
    clickOk() {
      if (this.selectedHistoryList.length < 1) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      if (
        new Date(this.project.trainingTimeStart + ":00") <
        this.project.startTime
      ) {
        this.$Message.error("用车时间不能晚于课程开始时间");
        return;
      }
      if (this.modalOption.key === "arrange") {
        // 安排车辆
        this.arrangement();
      } else if (this.modalOption.key === "adjust") {
        this.modificationArrangement();
      }
    },
    // 调整安排
    modificationArrangement() {
      if (this.project.startTime > this.project.trainingTimeStart) {
        this.$Message.error("用车晚于课程开始时间无法安排车辆！");
        return;
      }
      this.$axios
        .put("/api/arrange", {
          projectId: this.project.projectId,
          classId: this.project.classId,
          startTime: this.project.startTime,
          ids: this.selectedHistoryList.map(item => {
            return item.id;
          })
        })
        .then(res => {
          this.initLoadTable();
          this.$Message.success("调整成功！");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 提交安排车辆信息数据
    arrangement() {
      if (this.project.startTime > this.project.trainingTimeStart) {
        this.$Message.error("用车晚于课程开始时间无法安排车辆！");
        return;
      }
      this.$axios
        .post("/api/arrange", {
          projectId: this.project.projectId,
          classId: this.project.classId,
          startTime: this.project.startTime,
          ids: this.selectedHistoryList.map(item => {
            return item.id;
          })
        })
        .then(res => {
          this.initLoadTable();
          this.$Message.success("安排成功！");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 安排车辆
    arrangeVehicle(row) {
      // 查询可安排车辆信息
      this.queryNoUseArrangementInfo();
      this.project = JSON.parse(JSON.stringify(row));
      this.project.startTime = new Date(row.trainingTimeStart);
      this.modalOption.modalVisiabal = true;
      this.modalOption.key = "arrange";
      this.modalOption.title = "安排车辆";
    },
    // 查询可安排车辆信息
    queryNoUseArrangementInfo() {
      this.$axios
        .get("/api/arrange")
        .then(res => {
          this.vehicleList = res.data.data;
          if (this.modalOption.key === "adjust") {
            this.queryArrangementInfo();
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查询项目安排车辆信息
    queryArrangementInfo() {
      this.$axios
        .get(`/api/arrange/${this.project.projectId}/${this.project.classId}`)
        .then(res => {
          var list = res.data.data;
          if (this.modalOption.key === "adjust") {
            this.selectedHistoryList = [];
            list.forEach((element, index) => {
              element._checked = true;
              this.vehicleList.unshift(element);
              this.selectedHistoryList.push(element);
            });
          } else {
            this.vehicleList = list;
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/arrange/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      this.selectedHistoryList = [];
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.vehicleArrangement {
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .disable {
    color: $grey;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
  .red {
    color: $error;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-vehicle-info {
  .ivu-modal {
    width: 700px !important;
  }
  .modal-content {
    .time {
      padding-top: 20px;
      display: flex;
      align-items: center;
    }
    // .ivu-form-item:last-child {
    //   margin-bottom: 0;
    // }
    .ivu-select {
      width: 200px !important;
    }
  }
}
</style>
