<template>
  <div class="vehicleReturn">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入车辆名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="sex">
          <span>{{ row.sex | sexFilter }}</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            class="modify"
            v-if="row.isReturned === 0 && $btnAuthorityTest('vrrc:return')"
            @click="returnRegistration(row.id)"
            >返回登记</span
          >
          <span
            class="disable"
            v-if="row.isReturned === 1 && $btnAuthorityTest('vrrc:return')"
            >返回登记</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Input, Button } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "vehicleReturn",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "index", width: 80, align: "center", title: "序号" },
        {
          title: "车辆名称",
          align: "center",
          key: "vehicleName",
          tooltip: true
        },
        { title: "品牌", align: "center", key: "vehicleBrand", tooltip: true },
        { title: "型号", align: "center", key: "vehicleModel", tooltip: true },
        { title: "申请人", align: "center", key: "applicant", tooltip: true },
        {
          title: "用车时间",
          align: "center",
          key: "startTime",
          tooltip: true,
          width: 200
        },
        {
          title: "返回时间",
          align: "center",
          key: "endTime",
          tooltip: true,
          width: 200
        },
        { title: "操作", align: "center", width: 100, slot: "action" }
      ],
      // 表单校验规则
      ruleValidate: {},
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {},
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-vehicle-info"
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 返回登记
    returnRegistration(id) {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "车辆返回登记",
        msg: "确认返回车辆？",
        modalVisiabal: true,
        handleOk: () => {
          this.submitReturnRegistration(id);
        }
      });
    },
    // 提交登记信息
    submitReturnRegistration(id) {
      this.$axios
        .put(`/api/vrrc/${id}`)
        .then(res => {
          this.initLoadTable();
          this.$Message.info("登记成功！");
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/vrrc/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.vehicleReturn {
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .disable {
    color: $grey;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-vehicle-info {
  .ivu-modal {
    width: 700px !important;
  }
  .modal-content {
    .time {
      padding-top: 20px;
      display: flex;
      align-items: center;
    }
    // .ivu-form-item:last-child {
    //   margin-bottom: 0;
    // }
    .ivu-select {
      width: 200px !important;
    }
  }
}
</style>
