<template>
  <div class="carInfo">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入车辆名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('vehicle:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('vehicle:delete')"
          >删除</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="sex">
          <span>{{ row.sex | sexFilter }}</span>
        </template>
        <template slot-scope="{ row }" slot="status">
          <i-switch
            v-model="row.status"
            size="large"
            @on-change="handleSwitch(row.id, row.status)"
            :false-value="0"
            :true-value="1"
            v-if="$btnAuthorityTest('vehicle:status')"
          >
            <span slot="open">正常</span>
            <span slot="close">锁定</span>
          </i-switch>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            class="disable"
            v-if="row._disabled && $btnAuthorityTest('vehicle:update')"
            >修改</span
          >
          <span
            @click="clickModify(row)"
            class="modify"
            v-else-if="$btnAuthorityTest('vehicle:update')"
            >修改</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <i-form
          :model="formData"
          :label-width="100"
          ref="formValidate"
          :rules="ruleValidate"
        >
          <i-form-item label="车辆名称：" required prop="vehicleName">
            <i-input
              v-model="formData.vehicleName"
              placeholder="请输入"
              size="large"
            ></i-input>
          </i-form-item>
          <i-form-item label="品   牌：" required prop="vehicleBrand">
            <i-input
              v-model="formData.vehicleBrand"
              placeholder="请输入"
              size="large"
            ></i-input>
          </i-form-item>
          <i-form-item label="型   号：" required prop="vehicleModel">
            <i-select
              v-model="formData.vehicleModel"
              size="large"
              placeholder="请选择"
            >
              <i-option
                v-for="(item, index) of vehicleModelOptions"
                :key="index"
                :value="item.value"
                >{{ item.label }}</i-option
              >
            </i-select>
          </i-form-item>
          <i-form-item label="座位数：" required prop="vehicleSeating">
            <!-- <i-input
              v-model="formData.vehicleSeating"
              placeholder="请输入"
              size="large"
              number
            ></i-input> -->
            <i-input-number
              v-model="formData.vehicleSeating"
              placeholder="请输入"
              :min="1"
              size="large"
            ></i-input-number>
          </i-form-item>
          <i-form-item label="司   机：" required prop="motorman">
            <i-input
              v-model="formData.motorman"
              placeholder="请输入"
              size="large"
            ></i-input>
          </i-form-item>
          <i-form-item label="联系方式：" required prop="contact">
            <i-input
              v-model="formData.contact"
              placeholder="请输入"
              size="large"
            ></i-input>
          </i-form-item>
        </i-form>
      </div>
      <p slot="footer">
        <i-button size="large" @click="modalOption.modalVisiabal = false"
          >取消</i-button
        >
        <i-button size="large" type="primary" @click="clickOk">保存</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Switch,
  Form,
  FormItem,
  InputNumber
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "carInfo",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-switch": Switch,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-input-number": InputNumber,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "车辆名称",
          align: "center",
          key: "vehicleName",
          tooltip: true
        },
        { title: "品牌", align: "center", key: "vehicleBrand", tooltip: true },
        { title: "型号", align: "center", key: "vehicleModel", tooltip: true },
        {
          title: "座位数",
          align: "center",
          key: "vehicleSeating",
          tooltip: true,
          width: 120
        },
        { title: "司机", align: "center", key: "motorman", tooltip: true },
        {
          title: "联系方式",
          align: "center",
          key: "contact",
          tooltip: true,
          width: 150
        },
        { title: "状态", align: "center", width: 120, slot: "status" },
        { title: "操作", align: "center", width: 80, slot: "action" }
      ],
      // 表单校验规则
      ruleValidate: {
        vehicleName: [
          {
            required: true,
            message: "车辆名称不能为空"
          },
          {
            max: 20,
            message: "车辆名称长度不能超过20位"
          }
        ],
        vehicleBrand: [
          {
            required: true,
            message: "车辆品牌不能为空"
          },
          {
            max: 20,
            message: "车辆品牌长度不能超过20位"
          }
        ],
        vehicleModel: [
          {
            required: true,
            message: "车辆类型不能为空"
          }
        ],
        vehicleSeating: [
          {
            required: true,
            message: "车辆座位数不能为空"
          },
          {
            type: "number",
            max: 99,
            message: "车辆座位数不能超过99"
          }
        ],
        motorman: [
          {
            required: true,
            message: "车辆司机不能为空"
          },
          {
            max: 8,
            message: "车辆司机长度不能超过8位"
          }
        ],
        contact: [
          {
            required: true,
            message: "联系方式不能为空"
          },
          {
            pattern: /^\d{1,11}$/,
            message: "请输入长度不超过11位的数字"
          }
        ]
      },
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {
        // 联系方式
        contact: "",
        // 司机
        motorman: "",
        // 车辆品牌
        vehicleBrand: "",
        // 车辆型号
        vehicleModel: "",
        // 车辆名称
        vehicleName: "",
        // 座位数
        vehicleSeating: 1
      },
      // 车辆型号可选列表
      vehicleModelOptions: [],
      // 当前操作的Id
      id: "",
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-car-info"
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/vehicle/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 根据车辆的使用和申请情况设置禁止选中状态
          data.list.forEach(el => {
            el._disabled = el.inUse === 1 || el.modifiableState === 1;
          });
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 添加
    clickAdd() {
      this.modalOption.title = "添加";
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
      // 请求车辆类型可选列表
      this.requireVehicleModelOptions();
    },
    // 点击修改的处理函数
    clickModify(obj) {
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      // 保存当前修改的记录id
      this.id = obj.id;
      // 数据回显
      this.dataCallBack(obj);
      // 请求车辆类型列表
      this.requireVehicleModelOptions();
    },
    // 请求车辆类型的可选列表的方法
    requireVehicleModelOptions() {
      this.$axios
        .get("/api/vehicle/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("车辆类型列表获取失败");
            return false;
          }
          this.vehicleModelOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 数据回显
    dataCallBack(obj) {
      Object.keys(this.formData).forEach(key => {
        this.formData[key] = obj[key];
      });
    },
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 待提交的id列表
      let ids = [];
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.id);
      this.$axios
        .delete("/api/vehicle", { data: ids })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    // 对话框确认的处理方法
    clickOk() {
      // 获取表单验证结果
      let sign = this.testForm();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      // 根据key值调用不同的方法
      if (this.modalOption.key === "add") {
        this.saveAdd();
      }
      if (this.modalOption.key === "modify") {
        this.saveModify();
      }
    },
    // 保存添加的信息
    saveAdd() {
      this.$axios
        .post("/api/vehicle", this.formData)
        .then(res => {
          this.$Message.success("添加成功");
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 保存修改的信息
    saveModify() {
      this.$axios
        .put(`/api/vehicle/${this.id}`, this.formData)
        .then(res => {
          this.$Message.success("修改成功");
          // 重新渲染列表
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },

    // 开关切换的处理函数
    handleSwitch(id, bool) {
      this.$axios.put(`/api/vehicle/status/${id}/${bool}`).catch(error => {
        this.loadTable();
        console.error(error.message);
      });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 清空表单数据
    clearFormData() {
      this.$refs.formValidate.resetFields();
      this.formData = {
        // 联系方式
        contact: "",
        // 司机
        motorman: "",
        // 车辆品牌
        vehicleBrand: "",
        // 车辆型号
        vehicleModel: "",
        // 车辆名称
        vehicleName: "",
        // 座位数
        vehicleSeating: 1
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.carInfo {
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .disable {
    color: $grey;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-car-info {
  .ivu-modal {
    width: 360px !important;
  }
  .modal-content {
    // .ivu-form-item:last-child {
    //   margin-bottom: 0;
    // }
    .ivu-select {
      width: 200px !important;
    }
  }
}
</style>
