<template>
  <div class="index">
    <my-header></my-header>
    <my-tag></my-tag>
    <my-side-bar></my-side-bar>
    <div class="main-area">
      <div class="content-area">
        <router-view></router-view>
      </div>
    </div>
    <!-- <my-pagination></my-pagination> -->
  </div>
</template>

<script>
import myHeader from "@/components/common/myHeader.vue";
import mySideBar from "@/components/common/mySideBar.vue";
import myTag from "@/components/common/myTag.vue";
export default {
  name: "index",
  data() {
    return {
      content: ""
    };
  },
  mounted() {
    // 页面挂载后获取表格高度
    this.$store.commit("skb/updateTableHeight");
    // 窗口大小改变后获取表格高度
    window.onresize = () => {
      return (() => {
        this.$store.commit("skb/updateTableHeight");
      })();
    };
  },
  components: {
    "my-side-bar": mySideBar,
    "my-tag": myTag,
    "my-header": myHeader
  }
};
</script>
<style lang="scss" scoped>
.index {
  .main-area {
    padding-left: $sidebar-width;
    width: 100%;
    height: calc(100vh - 120px);
    .content-area {
      height: 100%;
      padding: $top;
    }
  }
}
</style>
