<template>
  <div class="noticeDetail">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "noticeDetail"
};
</script>
<style lang="scss" scoped>
.noticeDetail {
  height: calc(100vh - 130px);
  overflow: auto;
}
</style>
