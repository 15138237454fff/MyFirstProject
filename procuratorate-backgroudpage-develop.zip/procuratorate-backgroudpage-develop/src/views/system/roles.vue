<template>
  <div class="roles">
    <my-content-head>
      <div slot="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入角色名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="handleAdd"
          type="primary"
          v-if="$btnAuthorityTest('role:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('role:delete')"
          >删除</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="users">
          <i-tooltip
            :content="row.users | userListToString"
            v-if="Array.isArray(row.users) && row.users.length !== 0"
            placement="top"
            :transfer="true"
            max-width="300px"
          >
            <span>{{ row.users | userListToString }}</span>
          </i-tooltip>
        </template>
        <template slot-scope="{ row, index }" slot="action">
          <span @click="handleSee(index)" class="toSee">查看</span>
          <span v-if="$btnAuthorityTest('role:update')">&nbsp;|&nbsp;</span>
          <span
            @click="handleModify(index)"
            class="modify"
            v-if="$btnAuthorityTest('role:update')"
            >修改</span
          >
          <span v-if="$btnAuthorityTest('role:relevance')">&nbsp;|&nbsp;</span>
          <span
            @click="handleConnect(index)"
            class="connect"
            v-if="$btnAuthorityTest('role:relevance')"
            >关联用户</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p class="role-name">角色名称：{{ formData.roleName }}</p>
        <i-transfer
          :data="transferOptions.userList"
          :target-keys="transferOptions.connectList"
          :list-style="transferOptions.listStyle"
          :operations="['到左边', '到右边']"
          :titles="transferOptions.titles"
          filterable
          @on-change="handleConnectChange"
        ></i-transfer>
      </div>
      <p slot="footer">
        <i-button size="large" @click="handleCancel">取消</i-button>
        <i-button size="large" type="primary" @click="handleOk">保存</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Table, Input, Button, Transfer, Tooltip } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import myModal from "@/components/common/myModal";
import myPagination from "@/components/common/myPagination";

export default {
  name: "roles",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-transfer": Transfer,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        { type: "index", width: 70, align: "center", title: "序号" },
        { title: "角色名称", align: "center", key: "roleName", tooltip: true },
        { title: "关联用户", align: "center", slot: "users" },
        { title: "操作", align: "center", width: 200, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {
        // 用户Ids
        userIds: [],
        // 点击的记录对应的角色id
        roleId: "",
        // 点击的记录对应的角色名称
        roleName: ""
      },
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-roles"
      },
      // 穿梭框的配置参数
      transferOptions: {
        // 标题列表
        titles: ["待选用户", "已关联用户"],
        // 可以关联的用户列表
        userList: [],
        // 已经关联的用户列表
        connectList: [],
        // 穿梭框样式
        listStyle: {
          width: "calc(20vw - 80px)",
          height: "calc(40vh - 86px)",
          "text-align": "left"
        }
      }
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 请求列表数据
    loadTable() {
      this.$axios
        .post("/api/role/list", this.limitQuery)
        .then(res => {
          let data = res.data.data;
          // 请求的数据非空,格式验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return;
          }
          this.tableData = data.list;
          this.msgCount = data.total;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 添加
    handleAdd() {
      this.$router.push("/rolesDetail/add");
    },
    // 点击删除按钮的处理方法
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      let tmpArr = this.selectedHistoryList.map(el => el.id);
      this.$axios
        .delete(`/api/role`, { data: tmpArr })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击查看一条记录
    handleSee(index) {
      this.$router.push(`/rolesDetail/see/${this.tableData[index].id}`);
    },
    // 点击修改一条记录
    handleModify(index) {
      this.$router.push(`/rolesDetail/modify/${this.tableData[index].id}`);
    },
    // 点击关联一条记录
    handleConnect(index) {
      // 获取可关联的用户列表
      this.requireConnectList();
      // 保存正在关联用户的角色名称
      this.formData.roleName = this.tableData[index].roleName;
      this.formData.roleId = this.tableData[index].id;
      // 已关联的用户列表数据格式化
      let tmpArr = this.tableData[index].users.map(el => {
        return el.userId;
      });
      // 保存到已关联用户列表中
      this.transferOptions.connectList = tmpArr;
      // 配置对话框的参数
      this.modalOption.title = "关联用户";
      this.modalOption.modalVisiabal = true;
    },
    // 请求可以关联的用户列表
    requireConnectList() {
      this.$axios
        .get("/api/user/select")
        .then(res => {
          let data = res.data.data;
          // 获取数据类型验证
          if (!Array.isArray(data)) {
            console.error("可关联的用户列表数据格式不正确");
            return;
          }
          // 进行数据格式化处理
          let tmpArr = data.map(el => {
            return { key: el.userId, label: `${el.name}  ${el.userName}` };
          });
          // 保存可关联的用户列表
          this.transferOptions.userList = tmpArr;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    handleOk() {
      this.handleConnectSave();
    },
    // 处理关联用户保存
    handleConnectSave() {
      this.formData.userIds = this.transferOptions.connectList;
      this.$axios
        .put(`/api/role/${this.formData.roleId}`, this.formData.userIds)
        .then(res => {
          this.$Message.success("关联成功");
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    handleCancel() {
      // 清空表单
      this.transferOptions.connectList = [];
      this.modalOption.modalVisiabal = false;
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 角色id
        roleId: "",
        // 用户Ids
        userIds: [],
        // 角色名称
        roleName: ""
      };
    },
    // 处理关联用户的变化
    handleConnectChange(newTargetKeys, direction, moveKeys) {
      this.transferOptions.connectList = newTargetKeys;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  },
  filters: {
    // 过滤一个列表，显示label内容的拼接
    userListToString(arr) {
      if (!Array.isArray(arr)) {
        console.error("过滤的参数格式错误");
        return "";
      }
      return arr
        .map(el => {
          return el ? el.name : "";
        })
        .join(",");
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.name === from.meta.name) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.roles {
  .content {
    .toSee,
    .modify,
    .connect {
      cursor: pointer;
    }
    .toSee {
      text-decoration: underline;
      color: $theme;
    }
    .modify {
      text-decoration: underline;
      color: $orange;
    }
    .connect {
      text-decoration: underline;
      color: $blue;
    }
    /deep/ .ivu-tooltip-rel {
      line-height: 22px;
    }
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
// 模态框内容的样式设置
.modal-roles {
  .ivu-modal-body {
    height: 40vh;
    text-align: center;
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
  .ivu-modal {
    width: 42vw !important;
  }
  .modal-content {
    height: 100%;
    display: flex;
    padding: $top;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    .role-name {
      width: 100%;
      text-align: left;
      margin-bottom: $top;
    }
  }
}
</style>
