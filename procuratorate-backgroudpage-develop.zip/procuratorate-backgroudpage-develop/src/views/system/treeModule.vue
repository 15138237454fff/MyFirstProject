<template lang="html">
  <div class="module">
    <my-content-head>
      <div slot="left"></div>
      <div slot="right">
        <i-button
          size="large"
          @click="handleAdd"
          type="primary"
          v-if="$btnAuthorityTest('menu:add')"
          >添加</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <zk-table
        ref="table"
        :data="data"
        :columns="columns"
        :stripe="true"
        :border="true"
        :show-header="true"
        :show-summary="false"
        :show-row-hover="true"
        :show-index="false"
        :tree-type="true"
        :is-fold="true"
        :expand-type="false"
        :selection-type="false"
      >
        <template slot="icon" slot-scope="scope">
          <i-icon :type="scope.row.icon"></i-icon>
        </template>
        <template slot="menuType" slot-scope="scope">
          <div>
            <span class="orange" v-if="scope.row.menuType == 0">目录</span>
            <span class="green" v-if="scope.row.menuType == 1">菜单</span>
            <span class="blue" v-if="scope.row.menuType == 2">按钮</span>
          </div>
        </template>
        <template slot="option" slot-scope="scope">
          <div>
            <span
              @click="handleModify(scope.row)"
              class="modify"
              v-if="$btnAuthorityTest('menu:update')"
              >修改</span
            >
            <span v-if="$btnAuthorityTest('menu:delete')">&nbsp;|&nbsp;</span>
            <span
              @click="clickDelete(scope.row.menuId)"
              class="delete"
              v-if="$btnAuthorityTest('menu:delete')"
              >删除</span
            >
          </div>
        </template>
        <template slot="status" slot-scope="scope">
          <span class="green" v-if="scope.row.status === 1">正常</span>
          <span class="red" v-else-if="scope.row.status === 0">失效</span>
        </template>
      </zk-table>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>
          <span class="required">模块类型：</span>
          <i-radio-group
            v-model="formData.menuType"
            @on-change="requireParentSelectList"
            size="large"
          >
            <i-radio :label="0">一级菜单</i-radio>
            <i-radio :label="1">二级菜单</i-radio>
            <i-radio :label="2">按钮</i-radio>
          </i-radio-group>
        </p>
        <p>
          <span class="required">模块名称：</span>
          <i-input
            placeholder="请输入"
            size="large"
            v-model="formData.menuName"
          ></i-input>
        </p>
        <p>
          <span class="required">上级模块：</span>
          <i-select v-model="formData.parentId" size="large">
            <i-option
              v-for="(item, index) of parentSelectOption"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
        </p>
        <p>
          <span class="required">排序号：</span>
          <i-input
            placeholder="请输入"
            size="large"
            v-model="formData.orderNum"
          ></i-input>
        </p>
        <p>
          <span>模块地址：</span>
          <i-input
            placeholder="请输入"
            size="large"
            v-model="formData.url"
          ></i-input>
        </p>
        <p>
          <span class="required">状态：</span>
          <i-radio-group v-model="formData.status" size="large">
            <i-radio :label="1">有效</i-radio>
            <i-radio :label="0">无效</i-radio>
          </i-radio-group>
        </p>
        <p>
          <span>授权标识：</span>
          <i-input
            placeholder="请输入"
            size="large"
            v-model="formData.perms"
          ></i-input>
        </p>
        <p>
          <span>图标：</span>
          <i-input
            placeholder="请输入"
            size="large"
            v-model="formData.icon"
            :icon="formData.icon"
          ></i-input>
        </p>
      </div>
      <p slot="footer">
        <i-button size="large" @click="handleCancel">取消</i-button>
        <i-button size="large" type="primary" @click="handleOk">保存</i-button>
      </p>
    </my-modal>
  </div>
</template>

<script>
import {
  Input,
  Button,
  Icon,
  RadioGroup,
  Radio,
  Select,
  Option
} from "view-design";
import myContentHead from "@/components/common/myContentHead";
import myModal from "@/components/common/myModal";
export default {
  name: "treeModule",
  components: {
    "i-input": Input,
    "i-button": Button,
    "i-icon": Icon,
    "i-radio-group": RadioGroup,
    "i-radio": Radio,
    "i-select": Select,
    "i-option": Option,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      data: [],
      columns: [
        {
          label: "菜单名称",
          prop: "menuName"
        },
        {
          label: "图标",
          prop: "icon",
          type: "template",
          template: "icon"
        },
        {
          label: "模块类型",
          prop: "menuType",
          type: "template",
          template: "menuType"
        },
        {
          label: "排序",
          prop: "orderNum"
        },
        {
          label: "模块地址",
          prop: "url"
        },
        {
          label: "状态",
          prop: "status",
          type: "template",
          template: "status"
        },
        {
          label: "授权",
          prop: "perms"
        },
        {
          label: "操作",
          type: "template",
          template: "option"
        }
      ],
      // 可选的上级模块列表
      parentSelectOption: [],
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        //
        key: "add",
        // 标题内容
        title: "",
        className: "modal-module"
      },
      // 待提交的表单数据
      formData: {
        // 菜单图标
        icon: "",
        // 菜单名称
        menuName: "",
        // 菜单类型
        menuType: "",
        // 排序
        orderNum: "",
        // 父菜单ID,一级菜单上级菜单为0
        parentId: "",
        // 授权标识
        perms: "",
        // 状态
        status: "",
        // url
        url: "",
        // 菜单id
        menuId: ""
      },
      menuId: ""
    };
  },
  created() {
    this.getMenuList();
  },
  methods: {
    // 删除按钮
    clickDelete(menuId) {
      this.menuId = menuId;
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.$axios
        .delete(`/api/menu/${this.menuId}`)
        .then(res => {
          this.$Message.success("删除成功");
          this.menuId = [];
          this.getMenuList();
        })
        .catch(error => {
          console.error(error.message);
        });
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    handleAdd() {
      this.modalOption.title = "添加";
      this.modalOption.key = "add";
      // 清空可选上级模块列表
      this.parentSelectOption = [];
      this.modalOption.modalVisiabal = true;
    },
    // 保存添加内容
    saveAdd() {
      // 必填项
      let requiredArr = [
          "menuName",
          "menuType",
          "orderNum",
          "parentId",
          "status"
        ],
        // 验证状态
        sign = true;
      requiredArr.forEach(key => {
        if (this.formData[key] === "") {
          sign = false;
          return false;
        }
      });
      // 如果验证不通过
      if (!sign) {
        this.$Message.error("请填写完整后再尝试保存");
        return false;
      }
      this.$axios
        .post("/api/menu", this.formData)
        .then(res => {
          this.$Message.success("添加成功");
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
          this.getMenuList();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击修改一条记录
    handleModify(row) {
      var data = JSON.parse(JSON.stringify(row));
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      // 清空可选上级模块列表
      this.parentSelectOption = [];
      this.modalOption.modalVisiabal = true;
      this.formData.menuType = data.menuType;
      // 重新请求上级模块
      this.requireParentSelectList();
      // 将要修改的数据回显到对话框
      this.formData = data;
    },
    // 获取列表
    getMenuList() {
      this.$axios.get("/api/menu/tree/list").then(response => {
        this.data = response.data.data;
      });
    },
    // 根据模块类型请求上级模块列表
    requireParentSelectList() {
      // 如果是一级菜单
      this.$axios
        .get(`/api/menu/select/${this.formData.menuType}`)
        .then(res => {
          let data = res.data.data;
          // 数据类型验证
          if (!Array.isArray(data)) {
            console.error("获取上级模块列表数据失败");
            return false;
          }
          if (data.length === 0) {
            data = [{ value: "0", label: "顶级模块" }];
          }
          this.parentSelectOption = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    handleOk() {
      // 如果是添加对话框
      if (this.modalOption.key === "add") {
        // 调用保存添加的方法
        this.saveAdd();
      } else {
        this.saveModify();
      }
    },
    // 保存修改内容
    saveModify() {
      // 必填项
      let requiredArr = [
          "menuName",
          "menuType",
          "orderNum",
          "parentId",
          "status",
          "menuId"
        ],
        // 验证状态
        sign = true;
      requiredArr.forEach(key => {
        if (this.formData[key] === "") {
          sign = false;
          return false;
        }
      });
      // 如果验证不通过
      if (!sign) {
        this.$Message.error("请填写完整后再尝试保存");
        return false;
      }
      this.$axios
        .put("/api/menu", this.formData)
        .then(res => {
          this.$Message.success("修改成功");
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
          this.getMenuList();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    handleCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      // 清空可选上级模块列表
      this.parentSelectOption = [];
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 菜单图标
        icon: "",
        // 菜单名称
        menuName: "",
        // 菜单类型
        menuType: "",
        // 排序
        orderNum: "",
        // 父菜单ID,一级菜单上级菜单为0
        parentId: "",
        // 授权标识
        perms: "",
        // 状态
        status: "",
        // url
        url: "",
        // 菜单Id
        menuId: ""
      };
    }
  }
};
</script>
<style lang="scss" scoped>
.module {
  .content {
    height: calc(100vh - 182px);
    overflow: auto;
    .modify {
      color: $orange;
      text-decoration: underline;
      cursor: pointer;
    }
    .delete {
      color: $red;
      text-decoration: underline;
      cursor: pointer;
    }
    .ivu-icon {
      font-size: 24px;
    }
    .orange,
    .green,
    .red,
    .blue {
      display: inline-block;
      padding: 5px 10px;
      border-radius: 5px;
      color: $white;
    }
    .orange {
      background: $orange;
    }
    .green {
      background: $success;
    }
    .red {
      background: $error;
    }
    .blue {
      background: $blue;
    }
    /deep/ .zk-table__cell-inner {
      text-align: center;
      @extend .normal-font;
    }
    /deep/ .zk-table__body-cell:first-child .zk-table__cell-inner,
    /deep/ .zk-table__header-cell:first-child .zk-table__cell-inner {
      text-align: left;
    }
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
td.ivu-table-expanded-cell {
  padding: 0;
}
// 模态框内容的样式设置
.modal-module {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 400px !important;
  }
  .modal-content {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    p:not(:last-child) {
      margin-bottom: $input-top;
    }
    p {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      span {
        flex: 1;
        text-align: right;
      }
      .ivu-input-wrapper {
        flex: 3;
        min-width: 160px;
      }
      .ivu-select {
        text-align: left;
        flex: 3;
        min-width: 160px;

        span {
          text-align: left;
        }
      }
      .ivu-radio-group {
        text-align: left;
        flex: 3;
        min-width: 160px;
      }
    }
  }
}
</style>
