<template>
  <div class="parameter">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入参数名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="action">
          <span @click="handleSee(row.id)" class="toSee">查看</span>&nbsp;|
          <span
            @click="handleModify(row.id)"
            class="modify"
            v-if="$btnAuthorityTest('param:update')"
            >修改</span
          >&nbsp;
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>参数名称：{{ formData.parameterName }}</p>
        <p v-if="modalOption.key === 'modify'">
          <i-tree :data="treeData" :render="renderContent"></i-tree>
        </p>
        <p v-if="modalOption.key === 'see'">
          <i-tree :data="treeData" :render="detailFatherRender"></i-tree>
        </p>
      </div>
      <p slot="footer" v-show="modalOption.key === 'modify'">
        <i-button size="large" @click="handleCancel">取消</i-button>
        <i-button size="large" type="primary" @click="handleOk">保存</i-button>
      </p>
    </my-modal>
  </div>
</template>

<script>
import { Table, Input, Button, Tree, Icon } from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "parameter",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "my-modal": myModal,
    "i-tree": Tree,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      loading: false,
      // 消息总数量
      msgCount: 0,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-parameter"
      },
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { title: "序号", type: "index", width: 70, align: "center" },

        {
          title: "参数名称",
          align: "center",
          key: "parameterName",
          tooltip: true
        },
        {
          title: "参数类型",
          align: "center",
          key: "parameterType",
          render: (h, params) => {
            return h("div", [
              h(
                "span",
                this.$getListValue(
                  params.row.parameterType,
                  this.parameterTypeOptions
                )
              )
            ]);
          },
          tooltip: true
        },
        { title: "操作", align: "center", slot: "action", width: 120 }
      ],
      parameterTypeOptions: [
        { label: "一级下拉框", value: 1 },
        { label: "二级下拉框", value: 2 }
      ],
      // 详情
      formData: {
        // 内容
        content: [],
        // ID
        id: "",
        // 参数名称
        parameterName: "",
        // 参数类型 1:一级 2:二级
        parameterType: ""
      },
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 查看详情
    handleSee(index) {
      this.modalOption.title = "详情";
      this.modalOption.key = "see";
      this.modalOption.modalVisiabal = true;
      // 查询详情
      this.queryInfo(index);
    },
    // 修改
    handleModify(index) {
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      // 查询详情
      this.queryInfo(index);
    },
    saveModify() {
      // 获取验证结果
      let result = this.testForm();
      // 如果验证未通过，退出
      if (!result) {
        return;
      }
      this.$axios
        .put("/api/param", this.formData)
        .then(res => {
          this.$Message.success("保存成功");
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 表单验证
    testForm() {
      let sign = true;
      this.formData.content.map(el => {
        if (!sign) {
          return;
        }
        if (el.title === "") {
          this.$Message.error("请输入一级类别名称");
          sign = false;
          return;
        }
        if (el.title.length > 20) {
          this.$Message.error("一级类别名称长度不能超过20位");
          sign = false;
          return;
        }
        el.children.map(el => {
          if (el === "") {
            this.$Message.error("请输入二级类别名称");
            sign = false;
            return;
          }
          if (el.length > 20) {
            this.$Message.error("二级类别名称长度不能超过20位");
            sign = false;
          }
        });
      });
      return sign;
    },
    // 对话框确认的处理方法
    handleOk() {
      this.saveModify();
    },
    // 对话框取消的处理方法
    handleCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 根据ID查看详情
    queryInfo(id) {
      this.$axios
        .get("/api/param/" + id)
        .then(res => {
          // 取消列表加载状态
          let data = res.data.data;
          data.content.forEach(el => {
            if (this.$isEmpty(el.children)) {
              el.children = [];
            }
          });
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/param/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 内容
        content: [],
        // ID
        id: "",
        // 参数名称
        parameterName: "",
        // 参数类型 1:一级 2:二级
        parameterType: ""
      };
    },
    // 添加一级类别
    addFather() {
      this.formData.content.push({ title: "一级类别", children: [] });
    },
    // 移除一级类别
    removeFather(root, node) {
      let key = node.nodeKey;
      let tmpArr = root.filter(el => {
        return el.parent === undefined;
      });
      let index = tmpArr.findIndex(el => {
        return el.nodeKey === key;
      });
      this.formData.content.splice(index, 1);
    },
    // 在一级类别下添加二级类别
    appendFather(root, node, data) {
      let key = node.nodeKey;
      let tmpArr = root.filter(el => {
        return el.parent === undefined;
      });
      let index = tmpArr.findIndex(el => {
        return el.nodeKey === key;
      });
      this.formData.content[index].children.push("二级类别");
    },
    // 新增二级类别
    addChild(root, node) {
      let key = node.parent;
      let tmpArr = root.filter(el => {
        return el.parent === undefined;
      });
      let index = tmpArr.findIndex(el => {
        return el.nodeKey === key;
      });
      this.formData.content[index].children.push("二级类别");
    },
    // 移除二级类别
    removeChild(root, node, data) {
      let key = node.parent;
      let tmpArr = root.filter(el => {
        return el.parent === undefined;
      });
      let index = tmpArr.findIndex(el => {
        return el.nodeKey === key;
      });

      let sonIndex = tmpArr[index].children.findIndex(el => {
        return data.nodeKey === el;
      });
      this.formData.content[index].children.splice(sonIndex, 1);
    },
    // 一级类别的渲染函数
    fatherRender(h, { root, node, data }) {
      return h(
        "span",
        {
          style: {
            display: "inline-block",
            width: "100%"
          },
          class: "father-area"
        },
        [
          h(Input, {
            props: { value: data.title, size: "large" },
            class: "father-input-text",
            // 监听一级节点名称改变
            on: {
              input: val => {
                let key = node.nodeKey;
                let tmpArr = root.filter(el => {
                  return el.parent === undefined;
                });
                let index = tmpArr.findIndex(el => {
                  return el.nodeKey === key;
                });
                this.formData.content[index].title = val;
              }
            }
          }),
          h("span", { class: "father-span-text" }, data.title),
          h(
            "span",
            {
              style: {
                display: "inline-block",
                float: "right",
                marginRight: "32px"
              },
              class: "right-btn"
            },
            [
              h(Icon, {
                props: Object.assign({}, this.buttonProps, {
                  type: "md-remove-circle",
                  color: "red",
                  size: 24
                }),
                class: "icon-btn",
                on: {
                  click: () => {
                    this.removeFather(root, node);
                  }
                }
              }),
              h(Icon, {
                props: Object.assign({}, this.buttonProps, {
                  type: "md-add-circle",
                  size: 24
                }),
                class: "icon-btn green",
                on: {
                  click: () => {
                    this.addFather();
                  }
                }
              }),
              h(Icon, {
                props: Object.assign({}, this.buttonProps, {
                  type: "md-git-merge",
                  size: 24
                }),
                class:
                  this.formData.id === "XP-001" || this.formData.id === "XP-002"
                    ? "icon-btn "
                    : "icon-btn display-none",
                on: {
                  click: () => {
                    this.appendFather(root, node);
                  }
                }
              })
            ]
          )
        ]
      );
    },
    // 二级类别的渲染函数
    renderContent(h, { root, node, data }) {
      return h(
        "span",
        {
          style: {
            display: "inline-block",
            width: "100%"
          },
          class: "son-area"
        },
        [
          h(Input, {
            props: { value: data.title, size: "large" },
            class: "input-text",
            // 监听二级节点名称改变
            on: {
              input: val => {
                let key = node.parent;
                let tmpArr = root.filter(el => {
                  return el.parent === undefined;
                });
                let index = tmpArr.findIndex(el => {
                  return el.nodeKey === key;
                });
                let sonIndex = tmpArr[index].children.findIndex(el => {
                  return data.nodeKey === el;
                });
                this.formData.content[index].children[sonIndex] = val;
                data.title = val;
              }
            }
          }),
          h("span", { class: "span-text" }, data.title),
          h(
            "span",
            {
              style: {
                display: "inline-block",
                float: "right",
                marginRight: "32px"
              }
            },
            [
              h(Icon, {
                props: Object.assign({}, this.buttonProps, {
                  type: "md-remove-circle",
                  color: "red",
                  size: 24
                }),
                class: "icon-btn right-btn",
                on: {
                  click: () => {
                    this.removeChild(root, node, data);
                  }
                }
              }),
              h(Icon, {
                props: Object.assign({}, this.buttonProps, {
                  type: "md-add-circle",
                  size: 24
                }),
                class: "icon-btn green right-btn",
                on: {
                  click: () => {
                    this.addChild(root, node, data);
                  }
                }
              })
            ]
          )
        ]
      );
    },
    detailFatherRender(h, { root, node, data }) {
      return h(
        "span",
        {
          style: {
            display: "inline-block",
            width: "100%"
          }
        },
        [h("span", data.title)]
      );
    },
    detailRenderContent(h, { root, node, data }) {
      return h(
        "span",
        {
          style: {
            display: "inline-block",
            width: "100%"
          }
        },
        [h("span", data.title)]
      );
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    // 根据表单数据返回一个展示的树状数据结构
    treeData() {
      let tmpArr = [];
      tmpArr = this.formData.content.map(el => {
        let tmpObj = {
          title: el.title,
          expand: true,
          children:
            el.children &&
            el.children.map(item => {
              return { title: item };
            }),
          buttonProps: {
            type: "default",
            size: "small"
          },
          render:
            this.modalOption.key === "modify"
              ? this.fatherRender
              : this.detailFatherRender
        };
        return tmpObj;
      });
      return tmpArr;
    }
  }
};
</script>

<style lang="scss" scoped>
.parameter {
  .toSee {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
}
</style>
<style lang="scss">
// 模态框内容的样式设置
.modal-parameter {
  .ivu-modal {
    width: 500px !important;
  }
  .ivu-tree-arrow {
    margin-right: 10px;
  }
  .display-none {
    display: none;
  }
  .ivu-tree-children {
    li {
      line-height: 36px;
      margin: 0;
      .father-span-text,
      .span-text {
        display: inline-block;
        width: 100%;
      }
      .father-area {
        &:not(:hover) {
          .father-input-text {
            display: none;
          }
          .right-btn {
            display: none !important;
          }
        }
        &:hover {
          .father-span-text {
            display: none;
          }
        }
      }
      .son-area {
        &:not(:hover) {
          .input-text {
            display: none;
          }
          .right-btn {
            display: none !important;
          }
        }
        &:hover {
          .span-text {
            display: none;
          }
        }
      }
    }
  }
  .icon-btn {
    border-radius: 50%;
    width: 24px;
    height: 24px;
    cursor: pointer;
    &:not(:last-child) {
      margin-right: 10px;
    }
  }
  .green {
    color: $theme;
  }
}
</style>
