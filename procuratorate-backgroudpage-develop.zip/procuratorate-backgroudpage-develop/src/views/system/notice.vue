<template>
  <div class="notice">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入标题"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('notice:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('notice:delete')"
          >删除</i-button
        >
        <i-button
          size="large"
          @click="clickRelease(releaseBtnText)"
          type="primary"
          ghost
          v-if="$btnAuthorityTest(releaseBtnKey)"
          >{{ releaseBtnText }}</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="title">
          <i-tooltip
            :content="row.title"
            :class="{ isTop: row.stick === 1 }"
            :transfer="true"
            max-width="300px"
            >{{ row.title }}</i-tooltip
          >
        </template>
        <template slot-scope="{ row }" slot="status">
          <span :class="row.status === 1 ? 'isRelease' : 'noRelease'">{{
            row.status === 1 ? "已发布" : "未发布"
          }}</span>
        </template>
        <template slot-scope="{ row }" slot="publishType">
          <span>{{ row.name }}</span>
        </template>
        <template slot-scope="{ row }" slot="publishTime">
          <span>{{ row.publishTime }}</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <div
            :class="{
              'release-justify':
                row.stick === 1 &&
                row.status === 1 &&
                $btnAuthorityTest('notice:unstick')
            }"
          >
            <span @click="clickSee(row.id)" class="toSee">查看</span>
            <span
              v-if="
                ($btnAuthorityTest('notice:update') && row.status === 0) ||
                  ($btnAuthorityTest(
                    row.stick === 1 ? 'notice:unstick' : 'notice:stick'
                  ) &&
                    row.status !== 0)
              "
              >&nbsp;|&nbsp;</span
            >
            <span
              @click="clickModify(row.id, row.status !== 1)"
              class="modify"
              v-if="$btnAuthorityTest('notice:update') && row.status === 0"
              >修改</span
            >
            <span
              @click="clickTop(row.id, row.stick === 1, row.status === 1)"
              class="setTop"
              v-else-if="
                $btnAuthorityTest(
                  row.stick === 1 ? 'notice:unstick' : 'notice:stick'
                ) && row.status !== 0
              "
              >{{ row.stick === 1 ? "取消置顶" : "置顶" }}</span
            >
          </div>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Input, Button, Tooltip } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "notice",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "标题",
          align: "center",
          slot: "title",
          minWidth: 100
        },
        {
          title: "发送对象",
          align: "center",
          slot: "publishType"
        },
        { title: "发布时间", align: "center", slot: "publishTime", width: 200 },
        { title: "状态", align: "center", slot: "status", width: 100 },
        { title: "操作", align: "center", width: 240, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 是否发布按钮
      isRelease: true,
      // 历史勾选记录列表
      selectedHistoryList: []
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/notice/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击添加的处理函数
    clickAdd() {
      this.$router.push("/noticeDetail/add");
    },
    // 点击查看的处理函数
    clickSee(id) {
      this.$router.push(`/noticeDetail/see/${id}`);
    },
    // 点击修改的处理函数
    clickModify(id, bool) {
      if (bool) {
        this.$router.push(`/noticeDetail/modify/${id}`);
      } else {
        this.$log.INFO("已发布数据无法修改");
      }
    },
    clickTop(id, bool, active) {
      // 判断是否发布，未发布不处理
      if (!active) {
        this.$log.INFO("未发布无法置顶");
        return;
      }
      // 已置顶，执行取消置顶
      if (bool) {
        this.$log.INFO("取消置顶");
        // 取消置顶
        this.$axios
          .put(`/api/notice/unstick/${id}`)
          .then(res => {
            this.$Message.success("取消置顶成功");
            this.loadTable();
          })
          .catch(error => {
            console.error(error.message);
          });
      } else {
        // 未置顶，执行置顶
        this.$log.INFO("置顶");
        // 置顶
        this.$axios
          .put(`/api/notice/stick/${id}`)
          .then(res => {
            this.$Message.success("置顶成功");
            this.loadTable();
          })
          .catch(error => {
            console.error(error.message);
          });
      }
    },
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 待提交的id列表
      let ids = [];
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.id);
      this.$axios
        .delete("/api/notice", { data: ids })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击发布按钮
    clickRelease(msg) {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: msg,
        msg: `确定${msg}已选记录？`,
        modalVisiabal: true,
        handleOk: this.handleRelease
      });
    },
    // 发布的方法
    handleRelease() {
      this.saveRelease();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    saveRelease() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 以第一条记录发布状态作为判断是发布还是取消发布
      let status = this.selectedHistoryList[0].status,
        // 判断所有记录是否和第一条记录发布状态相同
        sign = this.selectedHistoryList.every(el => el.status === status),
        // 待提交的id列表
        ids = [];
      // 如果不相同
      if (!sign) {
        this.$Message.error("请选择相同状态的数据");
        return;
      }
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.id);
      // 已发布的数据，去取消发布
      if (status === 1) {
        this.$axios
          .put("/api/notice/unpublished", ids)
          .then(res => {
            this.$Message.success("取消发布成功");
            // 清空历史的勾选记录
            this.selectedHistoryList = [];
            this.loadTable();
          })
          .catch(error => {
            console.error(error.message);
          });
      } else {
        // 未发布的数据，去发布
        this.$axios
          .put("/api/notice/published", ids)
          .then(res => {
            this.$Message.success("发布成功");
            this.loadTable();
          })
          .catch(error => {
            console.error(error.message);
          });
      }
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    releaseBtnText() {
      return this.selectedHistoryList.length !== 0 &&
        this.selectedHistoryList[0].status === 1
        ? "取消发布"
        : "发布";
    },
    // 按钮权限控制的key
    releaseBtnKey() {
      return this.selectedHistoryList.length !== 0 &&
        this.selectedHistoryList[0].status === 1
        ? "notice:unpublished"
        : "notice:published";
    }
  },
  filters: {
    publishTypeFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "全部用户";
        case 2:
          return "部门";
        case 3:
          return "角色";
        default:
          return "";
      }
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.name === from.meta.name) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.notice {
  .toSee {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .setTop {
    cursor: pointer;
    text-decoration: underline;
    color: $blue;
  }
  .isRelease {
    color: $theme;
  }
  .noRelease {
    color: $orange;
  }
  .release-justify {
    text-indent: 2em;
  }
  .isTop {
    background: url("../../assets/images/top.png") no-repeat 0px 0px;
    background-size: 30px;
  }
  /deep/ .ivu-tooltip {
    transform: translate(-18px);
    padding-left: 16px;
    .ivu-tooltip-rel {
      text-align: left;
    }
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
</style>
