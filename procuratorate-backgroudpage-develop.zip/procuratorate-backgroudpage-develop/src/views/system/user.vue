<template>
  <div class="user">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入用户名/姓名"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-select
          size="large"
          v-model="limitQuery.roleId"
          @on-change="initLoadTable"
        >
          <i-option
            v-for="(item, index) of roleList"
            :key="index"
            :value="item.id"
            >{{ item.roleName }}</i-option
          >
        </i-select>
        <i-select
          size="large"
          v-model="limitQuery.deptNum"
          @on-change="initLoadTable"
        >
          <i-option :value="-1">全部组织机构</i-option>
          <i-option
            v-for="(item, index) of institutionSelectOptions"
            :key="index"
            :value="item.value"
            >{{ item.label }}</i-option
          >
        </i-select>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('user:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('user:delete')"
          >删除</i-button
        >
        <i-button
          size="large"
          @click="clickPasswordReset"
          type="primary"
          ghost
          v-if="$btnAuthorityTest('user:initialize')"
          >密码初始化</i-button
        >
        <i-button size="large" @click="handleDown" type="primary" ghost
          >下载模板</i-button
        >
        <i-dropdown trigger="click" @on-click="handleDropdownItemClick">
          <i-button size="large" type="primary" ghost>
            批量操作
            <i-icon type="ios-arrow-down"></i-icon>
          </i-button>
          <i-dropdown-menu slot="list">
            <i-dropdown-item name="input">导入</i-dropdown-item>
            <i-dropdown-item name="output">导出</i-dropdown-item>
          </i-dropdown-menu>
        </i-dropdown>
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="sex">
          <span>{{ row.sex | sexFilter }}</span>
        </template>
        <template slot-scope="{ row }" slot="status">
          <i-switch
            v-model="row.status"
            size="large"
            @on-change="handleSwitch(row.userId, row.status)"
            :false-value="0"
            :true-value="1"
            v-if="$btnAuthorityTest('user:status')"
          >
            <span slot="open">正常</span>
            <span slot="close">锁定</span>
          </i-switch>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span @click="handleSee(row.userId)" class="toSee">查看</span>&nbsp;|
          <span
            @click="handleModify(row.userId)"
            class="modify"
            v-if="$btnAuthorityTest('user:update')"
            >修改</span
          >&nbsp;
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="modalOption.key === 'add'">
          <table border="1">
            <tr>
              <td class="required">用户名</td>
              <td>
                <i-input
                  size="large"
                  v-model="formData.userName"
                  number
                ></i-input>
              </td>
              <td class="required">姓名</td>
              <td>
                <i-input size="large" v-model="formData.name"></i-input>
              </td>
              <td rowspan="3">
                <i-upload
                  :format="format"
                  type="drag"
                  :action="uploadUrl"
                  :on-success="handleUploadSuccess"
                  :show-upload-list="false"
                  :max-size="maxSize"
                  :on-exceeded-size="handleMaxSize"
                  :on-format-error="handleFormatError"
                >
                  <div class="btn-icon" v-if="!formData.photo">
                    <i-icon type="ios-camera" size="60"></i-icon>点击上传
                  </div>
                  <div v-else class="btn-icon">
                    <img :src="formData.photo" />
                    <span>点击修改</span>
                  </div>
                </i-upload>
              </td>
            </tr>
            <tr>
              <td class="required">性别</td>
              <td>
                <i-radio-group v-model="formData.sex">
                  <i-radio :label="1">男</i-radio>
                  <i-radio :label="2">女</i-radio>
                </i-radio-group>
              </td>
              <td class="required" v-if="modalOption.key === 'add'">密码</td>
              <td>
                <i-input
                  size="large"
                  v-model="formData.passWord"
                  v-if="modalOption.key === 'add'"
                ></i-input>
              </td>
            </tr>
            <tr>
              <td class="required">职务</td>
              <td>
                <i-select size="large" v-model="formData.duty">
                  <i-option
                    v-for="(item, index) of dutySelectOptions"
                    :key="index"
                    :value="item.title"
                    >{{ item.title }}</i-option
                  >
                </i-select>
              </td>
              <td class="required">所属部门</td>
              <td>
                <i-select size="large" v-model="formData.deptNum">
                  <i-option
                    v-for="(item, index) of deptSelectOptions"
                    :key="index"
                    :value="item.value"
                    >{{ item.label }}</i-option
                  >
                </i-select>
              </td>
            </tr>
            <tr>
              <td class="required">所属角色</td>
              <td>
                <i-select size="large" v-model="formData.roleIdList" multiple>
                  <i-option
                    v-for="(item, index) of roleSelectOptions"
                    :key="index"
                    :value="item.id"
                    >{{ item.roleName }}</i-option
                  >
                </i-select>
              </td>
              <td class="required">身份证号</td>
              <td colspan="2">
                <i-input size="large" v-model="formData.idNumber"></i-input>
              </td>
            </tr>
            <tr>
              <td class="required">手机号码</td>
              <td>
                <i-input size="large" v-model="formData.mobile"></i-input>
              </td>
              <td class="required">电子邮箱</td>
              <td colspan="2">
                <i-input size="large" v-model="formData.email"></i-input>
              </td>
            </tr>
          </table>
        </template>
        <template v-else-if="modalOption.key === 'modify'">
          <table border="1">
            <tr>
              <td class="required">用户名</td>
              <td style="text-align:center">
                {{ formData.userName }}
              </td>
              <td class="required">姓名</td>
              <td>
                <i-input size="large" v-model="formData.name"></i-input>
              </td>
              <td rowspan="3">
                <i-upload
                  :format="format"
                  type="drag"
                  :action="uploadUrl"
                  :on-success="handleUploadSuccess"
                  :show-upload-list="false"
                  :max-size="maxSize"
                  :on-exceeded-size="handleMaxSize"
                  :on-format-error="handleFormatError"
                >
                  <div class="btn-icon" v-if="!formData.photo">
                    <i-icon type="ios-camera" size="60"></i-icon>点击上传
                  </div>
                  <div v-else class="btn-icon">
                    <img :src="formData.photo" />
                    <span>点击修改</span>
                  </div>
                </i-upload>
              </td>
            </tr>
            <tr>
              <td class="required">性别</td>
              <td>
                <i-radio-group v-model="formData.sex">
                  <i-radio :label="1">男</i-radio>
                  <i-radio :label="2">女</i-radio>
                </i-radio-group>
              </td>
              <td class="required">职务</td>
              <td>
                <i-select size="large" v-model="formData.duty">
                  <i-option
                    v-for="(item, index) of dutySelectOptions"
                    :key="index"
                    :value="item.title"
                    >{{ item.title }}</i-option
                  >
                </i-select>
              </td>
            </tr>
            <tr>
              <td class="required">所属部门</td>
              <td>
                <i-select size="large" v-model="formData.deptNum">
                  <i-option
                    v-for="(item, index) of deptSelectOptions"
                    :key="index"
                    :value="item.value"
                    >{{ item.label }}</i-option
                  >
                </i-select>
              </td>
              <td class="required">所属角色</td>
              <td>
                <i-select size="large" v-model="formData.roleIdList" multiple>
                  <i-option
                    v-for="(item, index) of roleSelectOptions"
                    :key="index"
                    :value="item.id"
                    >{{ item.roleName }}</i-option
                  >
                </i-select>
              </td>
            </tr>
            <tr>
              <td class="required">身份证号</td>
              <td colspan="2">
                <i-input size="large" v-model="formData.idNumber"></i-input>
              </td>
              <td class="required">手机号码</td>
              <td>
                <i-input size="large" v-model="formData.mobile"></i-input>
              </td>
            </tr>
            <tr>
              <td class="required">电子邮箱</td>
              <td colspan="4">
                <i-input size="large" v-model="formData.email"></i-input>
              </td>
            </tr>
          </table>
        </template>
        <template v-else-if="modalOption.key === 'see'">
          <table border="1" class="see-detail">
            <tr>
              <td>用户名</td>
              <td>{{ formData.userName }}</td>
              <td>姓名</td>
              <td>{{ formData.name }}</td>
              <td rowspan="3">
                <div class="btn-icon">
                  <img :src="formData.photo" />
                </div>
              </td>
            </tr>
            <tr>
              <td>性别</td>
              <td>{{ formData.sex | sexFilter }}</td>
              <td>职务</td>
              <td>{{ formData.duty }}</td>
            </tr>
            <tr>
              <td>所属部门</td>
              <td>
                <i-tooltip
                  :content="deptName"
                  :transfer="true"
                  max-width="300px"
                >
                  {{ deptName }}
                </i-tooltip>
              </td>
              <td>所属角色</td>
              <td>
                <i-tooltip
                  :content="formData.roleNames"
                  :transfer="true"
                  max-width="300px"
                >
                  {{ formData.roleNames }}
                </i-tooltip>
              </td>
            </tr>
            <tr>
              <td>身份证号</td>
              <td colspan="2">{{ formData.idNumber }}</td>
              <td>手机号码</td>
              <td>{{ formData.mobile }}</td>
            </tr>
            <tr>
              <td>电子邮箱</td>
              <td colspan="4">{{ formData.email }}</td>
            </tr>
          </table>
        </template>
      </div>
      <p slot="footer" v-if="modalOption.key !== 'see'">
        <i-button size="large" @click="handleCancel">取消</i-button>
        <i-button size="large" type="primary" @click="handleOk">保存</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Icon,
  Switch,
  RadioGroup,
  Radio,
  Upload,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Tooltip
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "user",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-dropdown": Dropdown,
    "i-dropdown-menu": DropdownMenu,
    "i-dropdown-item": DropdownItem,
    "i-icon": Icon,
    "i-switch": Switch,
    "i-radio-group": RadioGroup,
    "i-radio": Radio,
    "i-upload": Upload,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        { title: "用户名", align: "center", key: "userName", tooltip: true },
        { title: "姓名", align: "center", key: "name", tooltip: true },
        { title: "性别", align: "center", slot: "sex", width: 80 },
        { title: "所属部门", align: "center", key: "deptName", tooltip: true },
        { title: "职务", align: "center", key: "duty", tooltip: true },
        { title: "所属角色", align: "center", key: "roleNames", tooltip: true },
        { title: "账号状态", align: "center", width: 120, slot: "status" },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 角色id
        roleId: -1,
        deptNum: -1
      },
      // 待提交的表单数据
      formData: {
        // 所属部门
        deptNum: "",
        // 职务
        duty: "",
        // 邮箱
        email: "",
        // 身份证号
        idNumber: "",
        // 手机号
        mobile: "",
        // 姓名
        name: "",
        // 角色名字
        roleNames: "",
        // 密码
        passWord: "",
        // 照片
        photo: "",
        // 角色id列表
        roleIdList: [],
        // 性别
        sex: "",
        // 用户名
        userName: ""
      },
      // 职务参数的id
      dutyId: "XP-003",
      // 当前操作的用户Id
      userId: "",
      // 文件最大大小
      maxSize: 2048,
      format: ["jpg", "jpeg", "png"],
      // 职务待选列表
      dutySelectOptions: [],
      // 部门待选列表
      deptSelectOptions: [],
      // 角色待选列表
      roleSelectOptions: [],
      // 机构待选列表
      institutionSelectOptions: [],
      // 选中的记录列表
      selectedHistoryList: [],
      // 可选的角色列表
      roleList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-user"
      },
      passwordReg: /[^\u4e00-\u9fa5]{8,16}/,
      userNameReg: /^[a-zA-Z0-9]{5,11}$/,
      nameReg: /^[\u4e00-\u9fa5a-zA-Z]{1,20}$/,
      idNumberReg: /(^\d{15}$)|(^\d{17}([0-9]|X|x)$)/,
      mobileReg: /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/,
      emailReg: /^[a-zA-Z0-9][\w.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z.]*[a-zA-Z]$/
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求角色下拉列表
    this.requireRoleList();
    // 请求职务下拉列表
    this.requireDutyList();
    // 请求部门下拉列表
    this.requireDeptList();
    // 请求机构下拉列表
    this.requireInstitutionList();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      let tmpObj = { ...this.limitQuery };
      if (tmpObj.roleId === -1) {
        tmpObj.roleId = "";
      }
      if (tmpObj.deptNum === -1) {
        tmpObj.deptNum = "";
      }
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/user/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    requireInstitutionList() {
      this.$axios
        .get("/api/dept/select")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("机构下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.institutionSelectOptions = data;
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 请求可选的职务列表数据
    requireDutyList() {
      this.$axios.get(`/api/param/select/${this.dutyId}`).then(res => {
        let data = res.data.data;
        // 获得的参数验证
        if (!data || !Array.isArray(data)) {
          console.error("职务下拉框数据获取失败");
          return false;
        }
        // 保存下拉列表数据
        this.dutySelectOptions = data;
      });
    },
    // 请求可选的部门列表数据
    requireDeptList() {
      this.$axios
        .get("/api/dept/select")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("部门下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.deptSelectOptions = data;
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 请求可选的角色列表数据
    requireRoleList() {
      this.$axios
        .get("/api/role/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("获取可选的角色列表数据失败");
            return;
          }
          this.roleSelectOptions = data;
          // 添加一个全部角色项
          this.roleList = [].concat([{ id: -1, roleName: "全部角色" }], data);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 添加
    clickAdd() {
      this.modalOption.title = "添加";
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
    },
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 待提交的id列表
      let ids = [];
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.userId);
      this.$axios
        .delete("/api/user", { data: ids })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickPasswordReset() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "密码初始化",
        msg: "确定初始化所选用户密码？",
        modalVisiabal: true,
        handleOk: this.handlePasswordReset
      });
    },
    // 密码初始化的方法
    handlePasswordReset() {
      this.$log.INFO("正在密码初始化");
      this.savePasswordReset();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    savePasswordReset() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 待提交的id列表
      let ids = [];
      // 过滤选中的记录，获取id列表
      ids = this.selectedHistoryList.map(el => el.userId);
      this.$axios
        .put("/api/user/initialize", ids)
        .then(res => {
          this.$Message.success("密码初始化成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    testForm() {
      // 声明一个变量保存验证结果
      let sign = true;
      // 遍历待提交的表单
      Object.keys(this.formData).forEach(key => {
        // 验证未失败
        if (sign) {
          // 特别的roleName不进行非空验证
          if (key === "roleNames") {
            return;
          }
          // 有一项为空
          if (this.formData[key] === "") {
            sign = false;
            return false;
          }
        } else {
          return false;
        }
      });
      if (!this.userNameReg.test(this.formData.userName)) {
        this.$Message.error("用户名格式不正确，请输入5-11位字母或数字");
        return false;
      }
      if (!this.passwordReg.test(this.formData.passWord)) {
        this.$Message.error("密码格式不正确，请输入8-16位非汉字字符");
        return false;
      }
      if (!this.nameReg.test(this.formData.name)) {
        this.$Message.error(
          "姓名格式不正确，只能输入汉字或英文字母，长度不能超过20位"
        );
        return false;
      }
      if (!this.idNumberReg.test(this.formData.idNumber)) {
        this.$Message.error("身份证号格式不正确");
        return false;
      }
      if (!this.mobileReg.test(this.formData.mobile)) {
        this.$Message.error("手机号格式不正确");
        return false;
      }
      if (!this.emailReg.test(this.formData.email)) {
        this.$Message.error("邮箱格式不正确");
        return false;
      }
      if (this.formData.roleIdList.length === 0) {
        // 验证角色列表是否选择数据
        sign = false;
      }
      // 如果验证失败了
      if (!sign) {
        this.$Message.error("请填写完整后再尝试保存");
        return false;
      } else {
        return true;
      }
    },
    // 对话框确认的处理方法
    handleOk() {
      // 获取验证结果
      let sign = this.testForm();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      // 根据key值调用不同的方法
      if (this.modalOption.key === "add") {
        this.saveAdd();
      }
      if (this.modalOption.key === "modify") {
        this.saveModify();
      }
    },
    // 保存添加的信息
    saveAdd() {
      this.$axios
        .post("/api/user", this.formData)
        .then(res => {
          this.$Message.success("添加成功");
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 保存修改的信息
    saveModify() {
      this.$axios
        .put("/api/user", Object.assign(this.formData, { userId: this.userId }))
        .then(res => {
          this.$Message.success("修改成功");
          // 重新渲染列表
          this.loadTable();
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 对话框取消的处理方法
    handleCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 开关切换的处理函数
    handleSwitch(id, bool) {
      this.$axios.put(`/api/user/status/${id}/${bool}`).catch(error => {
        this.loadTable();
        console.error(error.message);
      });
    },
    // 点击查看的处理函数
    handleSee(id) {
      this.modalOption.title = "详情";
      this.modalOption.key = "see";
      this.modalOption.modalVisiabal = true;
      // 获取当前用户信息
      this.requireUserDetail(id);
    },
    // 点击修改的处理函数
    handleModify(id) {
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      // 获取当前用户信息
      this.requireUserDetail(id);
    },
    // 获取用户详细信息
    requireUserDetail(id) {
      this.$axios
        .get(`/api/user/${id}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          // 保存当前操作的用户id
          this.userId = data.userId;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 文件上传成功的处理函数
    handleUploadSuccess(res) {
      this.formData.photo = res.data.url;
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 所属部门
        deptNum: "",
        // 职务
        duty: "",
        // 邮箱
        email: "",
        // 身份证号
        idNumber: "",
        // 手机号
        mobile: "",
        // 姓名
        name: "",
        // 密码
        passWord: "",
        // 照片
        photo: "",
        // 角色id列表
        roleIdList: [],
        // 角色名字
        roleNames: "",
        // 性别
        sex: "",
        // 用户名
        userName: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },

    // 下载模板
    handleDown() {
      this.$log.INFO("正在下载模板");
    },
    // 导入的方法
    handleInput() {
      this.$log.INFO("正在导入");
    },
    // 导出的方法
    handleOutput() {
      this.$log.INFO("正在导出");
    },
    // 处理下拉项点击事件的方法
    handleDropdownItemClick(name) {
      if (name === "input") {
        // 调用导入
        this.handleInput();
      } else {
        // 调用导出
        this.handleOutput();
      }
    },
    // 上传文件大小超过限制的处理函数
    handleMaxSize() {
      this.$Message.error(`请上传${this.maxSize / 1024}M以下的文件`);
    },
    // 上传文件格式不正确
    handleFormatError() {
      this.$Message.error(`请上传${this.format.join("、")}等格式的文件`);
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    uploadUrl() {
      return this.$store.getters["skb/getUploadUrl"];
    },
    deptName() {
      let tmpObj = this.deptSelectOptions.find(el => {
        return this.formData.deptNum === el.value;
      });
      if (tmpObj) {
        return tmpObj.label;
      } else {
        return "";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.user {
  .ivu-dropdown-menu {
    min-width: 90px;
  }
  .ivu-dropdown-item {
    color: $theme;
    text-align: center;
  }
  .toSee {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
    .ivu-select-large:last-child {
      margin-left: $left;
    }
  }
}
// 模态框内容的样式设置
.modal-user {
  .ivu-modal {
    width: 600px !important;
  }
  .see-detail {
    td {
      width: 120px;
      height: 46px;
      text-align: center;
      img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }
    }
  }
  .modal-content {
    table {
      border: 1px solid #ccc;
      td {
        width: 120px;
        height: 46px;
        .btn-icon {
          width: 120px;
          height: 138px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          p {
            font-size: 10px;
          }
          span {
            display: none;
          }
        }
        .ivu-upload {
          height: 100%;
          position: relative;
          &:hover {
            .btn-icon {
              opacity: 1;
              img {
                opacity: 0.4;
              }
              span {
                display: block;
                position: absolute;
                color: #000;
                left: 50%;
                top: 80%;
                transform: translate(-50%);
              }
            }
          }
          img {
            width: 100%;
            height: 100%;
            object-fit: contain;
          }
        }
        .ivu-input-wrapper {
          width: 100% !important;
          height: 46px;
          .ivu-input-large {
            height: 100% !important;
          }
        }
        .ivu-select {
          width: 100% !important;
          height: 100%;
          line-height: 1;
          .ivu-select-placeholder,
          .ivu-select-selected-value {
            line-height: 46px !important;
          }
        }
        .ivu-select-large.ivu-select-multiple,
        .ivu-select-large.ivu-select-single {
          .ivu-select-selection {
            height: 100%;
          }
        }
        .ivu-select-large.ivu-select-multiple .ivu-tag {
          height: 38px;
          .ivu-tag-text {
            line-height: 38px;
          }
        }
        .ivu-radio-group {
          margin-left: $input-top;
        }
      }
      td:first-child,
      td:nth-child(3) {
        @extend .header-bg;
        padding: 0 $input-top;
        width: 100px;
      }
    }
  }
}
</style>
