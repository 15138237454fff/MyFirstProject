<template>
  <div class="institution">
    <my-content-head>
      <div slot="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入机构名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="handleAdd"
          type="primary"
          v-if="$btnAuthorityTest('dept:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('dept:delete')"
          >删除</i-button
        >
        <i-button size="large" @click="handleDown" type="primary" ghost
          >下载模板</i-button
        >
        <i-dropdown trigger="click" @on-click="handleDropdownItemClick">
          <i-button size="large" type="primary" ghost>
            批量操作
            <i-icon type="ios-arrow-down"></i-icon>
          </i-button>
          <i-dropdown-menu slot="list">
            <i-dropdown-item name="input">导入</i-dropdown-item>
            <i-dropdown-item name="output">导出</i-dropdown-item>
          </i-dropdown-menu>
        </i-dropdown>
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row, index }" slot="action">
          <span
            @click="handleModify(index)"
            class="modify"
            v-if="$btnAuthorityTest('dept:update')"
            >修改</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <i-form
          :model="formData"
          :label-width="100"
          ref="formValidate"
          :rules="ruleValidate"
        >
          <i-form-item label="机构代码：" required prop="deptNum">
            <i-input
              placeholder="请输入"
              size="large"
              v-model="formData.deptNum"
              v-if="modalOption.key === 'add'"
            ></i-input>
            <span v-else style="text-align:center">{{ formData.deptNum }}</span>
          </i-form-item>
          <i-form-item label="机构名称：" required prop="deptName">
            <i-input
              placeholder="请输入"
              size="large"
              v-model="formData.deptName"
            ></i-input>
          </i-form-item>
          <i-form-item label="所属机构：" prop="parentDeptNum">
            <i-select size="large" v-model="formData.parentDeptNum">
              <i-option
                v-for="(item, index) of beloneInstitutionOption"
                :key="index"
                :value="item.value"
                >{{ item.label }}</i-option
              >
            </i-select>
          </i-form-item>
        </i-form>
      </div>
      <p slot="footer">
        <i-button size="large" @click="handleCancel">取消</i-button>
        <i-button size="large" type="primary" @click="handleOk">保存</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Icon,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Form,
  FormItem
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "institution",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-dropdown": Dropdown,
    "i-dropdown-menu": DropdownMenu,
    "i-dropdown-item": DropdownItem,
    "i-icon": Icon,
    "i-form": Form,
    "i-form-item": FormItem,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        { title: "机构代码", align: "center", key: "deptNum", tooltip: true },
        { title: "机构名称", align: "center", key: "deptName", tooltip: true },
        {
          title: "所属机构",
          align: "center",
          key: "parentDeptName",
          tooltip: true
        },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      // 表单校验规则
      ruleValidate: {
        deptNum: [
          {
            required: true,
            message: "请输入机构代码,长度不能超过8个数字",
            trigger: "blur",
            pattern: /^\d{1,8}$/
          }
        ],
        deptName: [
          {
            required: true,
            trigger: "blur",
            message: "请输入机构名称,只能包含汉字或字母",
            pattern: /^[a-zA-Z\u4e00-\u9fa5]+$/
          }
        ]
      },
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {
        // 机构名称
        deptName: "",
        // 机构代码
        deptNum: "",
        // 所属机构代码
        parentDeptNum: ""
      },
      // 所属机构可选列表
      beloneInstitutionOption: [],
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-institution"
      },
      numberRegx: /^\d{1,8}$/
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/dept/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 获取部门下拉框列表数据
    requireDeptSelectList() {
      this.$axios
        .get("/api/dept/select")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("部门下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.beloneInstitutionOption = data;
          // 添加"无"选择项
          this.beloneInstitutionOption.unshift({ label: "无", value: "0" });
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 添加
    handleAdd() {
      this.modalOption.title = "添加";
      this.modalOption.key = "add";
      this.modalOption.modalVisiabal = true;
      // 请求部门下拉框列表
      this.requireDeptSelectList();
    },
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      let tmpArr = this.selectedHistoryList.map(el => el.deptNum);
      this.$axios
        .delete("/api/dept", { data: tmpArr })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 下载模板
    handleDown() {},
    // 点击修改
    handleModify(index) {
      // 取出要修改的部门信息
      let deptObj = this.tableData[index];
      // 存入表单中
      Object.keys(this.formData).forEach(key => {
        this.formData[key] = deptObj[key];
      });
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      // 请求部门下拉框列表
      this.requireDeptSelectList();
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 对话框确认的处理方法
    handleOk() {
      // 对表单验证
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          // 根据key值调用不同的方法
          if (this.modalOption.key === "add") {
            this.saveAdd();
          }
          if (this.modalOption.key === "modify") {
            this.saveModify();
          }
        } else {
          this.$Message.error("请正确填写后再尝试保存！");
        }
      });
      // 隐藏模态框
    },
    // 保存添加
    saveAdd() {
      this.$axios
        .post("/api/dept", this.formData)
        .then(res => {
          this.$Message.success("添加成功");
          this.modalOption.modalVisiabal = false;
          // 重新加载列表数据
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 保存修改
    saveModify() {
      this.$axios
        .put("/api/dept", this.formData)
        .then(res => {
          this.$Message.success("修改成功");
          this.modalOption.modalVisiabal = false;
          // 重新加载列表数据
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 对话框取消的处理方法
    handleCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 清空表单数据
    clearFormData() {
      // 重置表单
      this.$refs.formValidate.resetFields();
      this.formData = {
        deptNum: "",
        deptName: "",
        parentDeptNum: "0"
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 导入的方法
    handleInput() {
      this.$log.INFO("正在导入");
    },
    // 导出的方法
    handleOutput() {
      this.$log.INFO("正在导出");
    },
    // 处理下拉项点击事件的方法
    handleDropdownItemClick(name) {
      if (name === "input") {
        // 调用导入
        this.handleInput();
      } else {
        // 调用导出
        this.handleOutput();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.institution {
  .content {
    .modify {
      color: $orange;
      text-decoration: underline;
      cursor: pointer;
    }
  }
  .ivu-dropdown-menu {
    min-width: 90px;
  }
  .ivu-dropdown-item {
    color: $theme;
    text-align: center;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
// 模态框内容的样式设置
.modal-institution {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 20vw !important;
  }
  .modal-content {
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    .ivu-form {
      width: 100%;
    }
    .ivu-form-item-content {
      text-align: left;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
    .ivu-select {
      width: 100% !important;
      text-align: left;
    }
  }
}
</style>
