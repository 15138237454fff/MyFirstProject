<template>
  <div class="institution">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入用户名/IP地址"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-date-picker
          :editable="false"
          v-model="limitQuery.time"
          size="large"
          format="yyyy-MM-dd"
          type="daterange"
          separator="至"
          placeholder="请选择日期范围"
          style="width: auto;"
          @on-change="loadTable"
        ></i-date-picker>
        <i-select
          v-model="limitQuery.type"
          style="width:auto"
          @on-change="loadTable"
          size="large"
        >
          <i-option :value="-1">全部日志类型</i-option>
          <i-option
            v-for="item in logTypeList"
            :value="item.value"
            :key="item.value"
            >{{ item.label }}</i-option
          >
        </i-select>
      </div>
      <div slot="right">
        <i-button size="large">导出</i-button>
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      ></i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import { Table, Input, Button, Select, Option, DatePicker } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "systemLog",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-date-picker": DatePicker,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      loading: false,
      // 消息总数量
      msgCount: 0,
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { title: "序号", type: "index", width: 80, align: "center" },
        { title: "用户名", align: "center", key: "userName", tooltip: true },
        {
          title: "日志类型",
          align: "center",
          key: "logType",
          width: 120,
          render: (h, params) => {
            return h("div", [
              h(
                "strong",
                this.$getListValue(params.row.logType, this.logTypeList)
              )
            ]);
          },
          tooltip: true
        },
        { title: "日志内容", align: "center", key: "operation", tooltip: true },
        { title: "IP地址", align: "center", key: "ip", tooltip: true },
        {
          title: "异常信息",
          align: "center",
          key: "exceptionMssage",
          tooltip: true
        },
        {
          title: "操作时间",
          align: "center",
          key: "createDate",
          tooltip: true,
          width: 200
        }
      ],
      // 日志类型
      logTypeList: [
        { label: "登录日志", value: 1 },
        { label: "操作日志", value: 2 },
        { label: "异常日志", value: 3 }
      ],
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        time: [],
        type: -1
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      let tmpObj = { ...this.limitQuery };
      // 查询时间从00：00：00 分改为 23：59：59
      tmpObj.time[1] = this.$endTime(tmpObj.time[1]);
      if (tmpObj.type === -1) {
        tmpObj.type = "";
      }
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/log/list", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>

<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .ivu-date-picker:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .left {
    flex: 2 !important;
  }
  /deep/ .right {
    flex: 1 !important;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
</style>
