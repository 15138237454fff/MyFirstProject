<template>
  <div class="rolesDetail">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "rolesDetail"
};
</script>
<style lang="scss" scoped>
</style>
