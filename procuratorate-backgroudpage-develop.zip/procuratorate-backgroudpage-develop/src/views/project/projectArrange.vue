<template>
  <div class="projectArrange">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训项目"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="detailList">
          <span
            class="to-detail"
            @click="
              clickToDetailRoster(
                row.projectId,
                row.projectName,
                row.projectStatus
              )
            "
            v-if="
              row.projectStatus === 4004 ||
                row.projectStatus === 4007 ||
                $btnAuthorityTest('register:detailed')
            "
            >{{ row.projectStatus | projectDeatilFilter }}</span
          >
        </template>
        <template slot-scope="{ row }" slot="deadline">
          <span>{{ row.deadline | toDateTime(".") }}</span>
        </template>
        <template slot-scope="{ row }" slot="projectStatus">
          <span :class="row.projectStatus | projectStatusClassFilter">{{
            row.projectStatus | projectStatusValueFilter
          }}</span>
        </template>

        <template slot-scope="{ row }" slot="projectArrange">
          <span
            class="to-detail"
            v-if="
              ((row.projectStatus === 4002 || row.projectStatus === 4000) &&
                $btnAuthorityTest('projectArrangement:arrangement')) ||
                (row.projectStatus === 4003 &&
                  $btnAuthorityTest('projectArrangement:arrangementUpdate')) ||
                row.projectStatus === 4007 ||
                row.projectStatus === 4004
            "
            @click="
              clickToArrange(row.projectId, row.projectName, row.projectStatus)
            "
            >{{ row.projectStatus | projectArrangeFilter }}</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Input, Button } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "projectArrange",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "index", width: 80, align: "center", title: "序号" },
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        {
          title: "培训人数限制",
          align: "center",
          key: "memberLimit",
          tooltip: true,
          width: 150
        },
        {
          title: "报名人数",
          align: "center",
          key: "memberActual",
          tooltip: true,
          width: 150
        },
        { title: "详细名单", align: "center", slot: "detailList", width: 120 },
        {
          title: "报名截止时间",
          align: "center",
          slot: "deadline",
          width: 140,
          tooltip: true
        },
        { title: "状态", align: "center", slot: "projectStatus", width: 120 },
        {
          title: "培训安排",
          align: "center",
          slot: "projectArrange",
          width: 120
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/projectArrangement/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击前往详情名单
    clickToDetailRoster(projectId, projectName, projectStatus) {
      this.$router.push(
        `detailRosterList/${projectId}/${projectName}/${projectStatus}`
      );
    },
    // 点击前往安排
    clickToArrange(projectId, projectName, status) {
      status = parseInt(status);
      switch (status) {
        case 4000:
        case 4002:
          this.$router.push(`projectArrangeAdd/${projectId}/${projectName}`);
          return;
        case 4003:
          this.$router.push(`projectArrangeModify/${projectId}/${projectName}`);
          return;
        case 4004:
        case 4007:
          this.$router.push(`projectArrangeDetail/${projectId}/${projectName}`);
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  },
  filters: {
    projectDeatilFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
        case 4002:
        case 4003:
          return "调整名单";
        case 4004:
        case 4007:
          return "详细名单";
        default:
          return "";
      }
    },
    projectArrangeFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
        case 4002:
          return "安排培训";
        case 4003:
          return "调整安排";
        case 4004:
        case 4007:
          return "查看详情";
        default:
          return "";
      }
    },
    projectStatusValueFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
          return "已延期";
        case 4002:
          return "未安排";
        case 4003:
        case 4007:
          return "已安排";
        case 4004:
          return "已开始";
        default:
          return "";
      }
    },
    projectStatusClassFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
          return "red";
        case 4002:
          return "orange";
        case 4003:
        case 4007:
          return "blue";
        case 4004:
          return "green";
        default:
          return "";
      }
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.name === from.meta.name) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.projectArrange {
  .to-detail {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .red {
    color: $error;
  }
  .orange {
    color: $orange;
  }
  .blue {
    color: $blue;
  }
  .green {
    color: $success;
  }
}
</style>
