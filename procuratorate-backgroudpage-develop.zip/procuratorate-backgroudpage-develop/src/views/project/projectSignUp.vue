<template>
  <div class="projectSignUp">
    <i-tabs v-model="activeTab" @on-click="handleTabClick">
      <i-tab-pane name="noSignUp" label="未报名"></i-tab-pane>
      <i-tab-pane name="SignUped" label="已报名"></i-tab-pane>
    </i-tabs>
    <template v-if="activeTab === 'noSignUp'">
      <project-no-sign-up ref="projectNoSignUp"></project-no-sign-up>
    </template>
    <template v-else>
      <project-sign-uped ref="projectSignUped"></project-sign-uped>
    </template>
  </div>
</template>
<script>
import { Tabs, TabPane } from "view-design";
import projectNoSignUp from "@/components/projectSignUpTab/projectNoSignUp";
import projectSignUped from "@/components/projectSignUpTab/projectSignUped";
export default {
  name: "projectSignUp",
  components: {
    "i-tabs": Tabs,
    "i-tab-pane": TabPane,
    "project-no-sign-up": projectNoSignUp,
    "project-sign-uped": projectSignUped
  },
  data() {
    return {
      activeTab: "noSignUp",
      canReadHistoryLimitQuery: false
    };
  },
  created() {
    // 如果路由传参了指定页，则展示指定页
    if (this.$route.query.activeTab) {
      this.activeTab = this.$route.query.activeTab;
    }
  },
  methods: {
    handleTabClick() {
      if (!this.canReadHistoryLimitQuery) {
        return;
      }
      // 清空之前分页数据
      this.$store.commit("skb/updateLimitQuery", {
        pageNum: 1,
        pageSize: 15
      });
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.name === from.meta.name) {
        vm.canReadHistoryLimitQuery = true;
        if (vm.activeTab === "noSignUp") {
          vm.$refs.projectNoSignUp.readHistoryLimitQuery();
        } else {
          vm.$refs.projectSignUped.readHistoryLimitQuery();
        }
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.projectSignUp {
  /deep/ .ivu-tabs-bar {
    margin-bottom: $top;
  }
}
</style>
