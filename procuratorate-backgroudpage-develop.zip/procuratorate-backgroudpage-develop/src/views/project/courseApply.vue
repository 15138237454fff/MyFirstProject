<template>
  <div class="courseApply">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入课程名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickApply"
          type="primary"
          v-if="$btnAuthorityTest('projectClass:apply')"
          >申请培训课程</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="classStatus">
          <span :class="row.classStatus | classStatusFilter('class')">{{
            row.classStatus | classStatusFilter("value")
          }}</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="formData.classType === 1">
          <i-form
            :model="formData"
            :label-width="100"
            ref="formValidate"
            :rules="ruleValidate"
          >
            <i-form-item label="申请类型：" required prop="classType">
              <i-radio-group
                v-model="formData.classType"
                size="large"
                @on-change="handleRadioChange"
              >
                <i-radio :label="1">关联已有课程</i-radio>
                <i-radio :label="2">添加新课程</i-radio></i-radio-group
              >
            </i-form-item>
            <i-form-item label="课程类别：" required prop="classCategoryId">
              <i-cascader
                size="large"
                v-model="formData.classCategoryId"
                :data="courseTypeOption"
                @on-change="handleCascaderChange"
              ></i-cascader>
            </i-form-item>
            <i-form-item label="课程名称：" required prop="classId">
              <i-select
                v-model="formData.classId"
                size="large"
                @on-change="handleSelectChange"
              >
                <i-option
                  v-for="(item, index) of courseOption"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </i-form-item>
            <i-form-item label="培训讲师：" prop="noMessage">
              {{ formData.classExternalTeacherName }}
            </i-form-item>
            <i-form-item label="学分：" prop="noMessage">
              {{ formData.classCredit }}
            </i-form-item>
            <i-form-item label="学时：" prop="noMessage">
              <span>{{ formData.classPeriod }}</span>
              <span
                style="color:#aaa;margin-left:5px;"
                v-if="formData.classPeriod"
              >
                时
              </span>
            </i-form-item>
            <i-form-item label="培训要求：" prop="noMessage">
              <i-input
                v-model="formData.trainingRequire"
                placeholder="请输入"
                size="large"
                type="textarea"
                :autosize="{ minRows: 3, maxRows: 6 }"
              ></i-input>
            </i-form-item>
          </i-form>
        </template>
        <template v-else>
          <i-form
            :model="formData"
            :label-width="100"
            ref="formValidate"
            :rules="ruleValidate"
          >
            <i-form-item label="申请类型：" required prop="classType">
              <i-radio-group
                v-model="formData.classType"
                size="large"
                @on-change="handleRadioChange"
              >
                <i-radio :label="1">关联已有课程</i-radio>
                <i-radio :label="2">添加新课程</i-radio></i-radio-group
              >
            </i-form-item>
            <i-form-item label="课程类别：" required prop="classCategoryId">
              <i-cascader
                size="large"
                v-model="formData.classCategoryId"
                :data="courseTypeOption"
              ></i-cascader>
            </i-form-item>
            <i-form-item label="课程名称：" required prop="className">
              <i-input
                v-model="formData.className"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
            <i-form-item
              label="培训讲师："
              required
              prop="classExternalTeacherName"
            >
              <i-input
                v-model="formData.classExternalTeacherName"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
            <i-form-item label="学分：" required prop="classCredit">
              <i-input-number
                v-model="formData.classCredit"
                placeholder="请输入"
                size="large"
                :min="0.5"
              ></i-input-number>
            </i-form-item>
            <i-form-item label="学时：" required prop="classPeriod">
              <i-input-number
                v-model="formData.classPeriod"
                placeholder="请输入"
                size="large"
                :min="0.5"
              ></i-input-number>
              <span style="color:#aaa;margin-left:5px;">时</span>
            </i-form-item>
            <i-form-item label="培训要求：" prop="trainingRequire">
              <i-input
                v-model="formData.trainingRequire"
                placeholder="请输入"
                size="large"
                type="textarea"
                :autosize="{ minRows: 3, maxRows: 6 }"
              ></i-input>
            </i-form-item>
          </i-form>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" @click="modalOption.modalVisiabal = false"
          >取消</i-button
        >
        <i-button size="large" type="primary" @click="clickOk">提交</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Form,
  FormItem,
  Cascader,
  Radio,
  RadioGroup,
  InputNumber
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "courseApply",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-radio": Radio,
    "i-radio-group": RadioGroup,
    "i-select": Select,
    "i-option": Option,
    "i-cascader": Cascader,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-input-number": InputNumber,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "index", width: 80, align: "center", title: "序号" },
        {
          title: "课程名称",
          align: "center",
          key: "className",
          tooltip: true
        },
        {
          title: "课程类别",
          align: "center",
          key: "classCategoryId",
          tooltip: true
        },
        {
          title: "培训要求",
          align: "center",
          key: "trainingRequire",
          tooltip: true
        },
        {
          title: "申请时间",
          align: "center",
          key: "applyTime",
          tooltip: true,
          width: 200
        },
        { title: "状态", align: "center", slot: "classStatus", width: 100 }
      ],
      // 课程类别参数id
      parameterID: "XP-001",
      // 课程类别可选列表
      courseTypeOption: [],
      // 课程可选列表
      courseOption: [],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 待提交的表单数据
      formData: {
        // 申请课程已有：1 新课程：2
        classType: 1,
        // 课程类别
        classCategoryId: [],
        // 学分
        classCredit: "",
        // 讲师姓名
        classExternalTeacherName: "",
        // 课程名称
        className: "",
        // 课程id
        classId: "",
        // 学时
        classPeriod: "",
        // 培训要求
        trainingRequire: ""
      },
      // 表单校验规则
      ruleValidate: {
        classType: [],
        classCategoryId: [
          {
            type: "array",
            required: true,
            message: "课程类型不能为空"
          }
        ],
        classExternalTeacherName: [
          {
            required: true,
            message: "培训讲师不能为空"
          }
        ],
        className: [
          {
            required: true,
            message: "课程名称不能为空"
          }
        ],
        classId: [
          {
            required: true,
            message: "课程名称不能为空"
          }
        ],
        classCredit: [
          {
            type: "number",
            message: "请输入数字"
          },
          {
            required: true,
            message: "学分不能为空"
          }
        ],
        classPeriod: [
          {
            type: "number",
            message: "请输入数字"
          },
          {
            required: true,
            message: "学时不能为空"
          }
        ]
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-course-apply"
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求课程类别下拉框数据
    this.requireCourseTypeOption();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/projectClass/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击申请课程
    clickApply() {
      this.$log.INFO("申请培训课程");
      this.modalOption.title = "申请培训课程";
      this.modalOption.key = "apply";
      this.modalOption.modalVisiabal = true;
    },
    // 保存申请课程
    saveApply() {
      if (this.formData.classType === 1) {
        // 关联课程
        this.connectCourse();
      } else {
        // 新课程
        this.createCourse();
      }
    },
    // 创建新课程
    createCourse() {
      let {
        classCategoryId,
        classCredit,
        classExternalTeacherName,
        className,
        classPeriod,
        trainingRequire
      } = this.formData;
      classCategoryId = classCategoryId[classCategoryId.length - 1];
      let tmpObj = {
        classCategoryId,
        classCredit,
        classExternalTeacherName,
        className,
        classPeriod,
        trainingRequire
      };
      this.$axios
        .post("/api/projectClass/classCreate", tmpObj)
        .then(res => {
          this.loadTable();
          this.$Message.success("申请成功，新课程已经保存到课程库");
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 关联已有课程
    connectCourse() {
      let { classId, trainingRequire } = this.formData,
        tmpObj = {
          classId,
          trainingRequire
        };
      this.$axios
        .post("/api/projectClass/classApply", tmpObj)
        .then(res => {
          this.loadTable();
          this.$Message.success("申请成功");
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 表单验证
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    // 对话框确认的处理方法
    clickOk() {
      // 获取表单验证结果
      let sign = this.testForm();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      this.saveApply();
    },
    // 请求课程类型参数的待选列表
    requireCourseTypeOption() {
      this.$axios
        .get(`/api/param/${this.parameterID}`)
        .then(res => {
          let data = res.data.data;
          if (!data || !Array.isArray(data.content)) {
            console.error("课程类别参数获取失败");
            return false;
          }
          // 数据格式化
          data.content = data.content.map(el => {
            return { label: el.title, value: el.title };
          });
          this.courseTypeOption = data.content;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 清空表单数据
    clearFormData() {
      // 清空表单
      this.$refs.formValidate.resetFields();
      this.formData = {
        classType: 1,
        // 课程类别
        classCategoryId: [],
        // 学分
        classCredit: "",
        // 讲师姓名
        classExternalTeacherName: "",
        // 课程名称
        className: "",
        // 课程id
        classId: "",
        // 学时
        classPeriod: "",
        // 培训要求
        trainingRequire: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 级联选择器选择值改变的处理方法
    handleCascaderChange(val) {
      let id = val[val.length - 1];
      this.$axios
        .get(`/api/projectClass/getClasses/${id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("课程列表获取失败");
            return false;
          }
          this.courseOption = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 选择器选择值改变的处理方法
    handleSelectChange() {
      if (!this.formData.classId) {
        return;
      }
      this.$axios
        .get(`/api/class/${this.formData.classId}`)
        .then(res => {
          let data = res.data.data;
          this.formData.classPeriod = data.classPeriod;
          this.formData.classCredit = data.classCredit;
          if (data.teacherInfoVOS.length === 0) {
            this.formData.classExternalTeacherName =
              data.classExternalTeacherName;
          } else {
            this.formData.classExternalTeacherName = data.teacherInfoVOS
              .map(el => {
                return el ? el.name : "";
              })
              .join(",");
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    handleRadioChange(val) {
      // 清空表单
      this.clearFormData();
      this.formData.classType = val;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  },
  filters: {
    classStatusFilter(val, type) {
      if (type === "value") {
        switch (val) {
          case 4001:
            return "未发布";
          case 4002:
            return "已发布";
          case 4003:
          case 4004:
            return "已安排";
          case 4005:
            return "已结束";
          default:
            return "";
        }
      } else {
        switch (val) {
          case 4001:
            return "orange";
          case 4002:
            return "blue";
          case 4003:
          case 4004:
            return "green";
          case 4005:
            return "";
          default:
            return "";
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.courseApply {
  .orange {
    color: $orange;
  }
  .blue {
    color: $blue;
  }
  .green {
    color: $success;
  }
}
</style>
<style lang="scss">
.modal-course-apply {
  .ivu-modal {
    width: 400px !important;
  }
  .modal-content {
    .ivu-input-wrapper,
    .ivu-select,
    .ivu-cascader {
      width: 240px !important;
    }
  }
}
</style>
