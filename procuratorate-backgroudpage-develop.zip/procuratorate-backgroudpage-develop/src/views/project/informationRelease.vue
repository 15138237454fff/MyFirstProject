<template>
  <div class="informationRelease">
    <i-tabs v-model="activeTab" @on-click="handleTabClick">
      <i-tab-pane name="unRelease" label="未发布"></i-tab-pane>
      <i-tab-pane name="release" label="已发布"></i-tab-pane>
    </i-tabs>
    <template v-if="activeTab === 'unRelease'">
      <information-un-release
        ref="informationUnRelease"
      ></information-un-release>
    </template>
    <template v-else>
      <information-released ref="informationReleased"></information-released>
    </template>
  </div>
</template>
<script>
import { Tabs, TabPane } from "view-design";
import informationUnRelease from "@/components/informationReleaseTab/informationUnRelease";
import informationReleased from "@/components/informationReleaseTab/informationReleased";
export default {
  name: "informationRelease",
  components: {
    "i-tabs": Tabs,
    "i-tab-pane": TabPane,
    "information-un-release": informationUnRelease,
    "information-released": informationReleased
  },
  data() {
    return {
      activeTab: "unRelease",
      canReadHistoryLimitQuery: false
    };
  },
  created() {
    // 如果路由传参了指定页，则展示指定页
    if (this.$route.query.activeTab) {
      this.activeTab = this.$route.query.activeTab;
    }
  },
  methods: {
    handleTabClick() {
      if (!this.canReadHistoryLimitQuery) {
        return;
      }
      // 清空之前分页数据
      this.$store.commit("skb/updateLimitQuery", {
        pageNum: 1,
        pageSize: 15
      });
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.name === from.meta.name) {
        vm.canReadHistoryLimitQuery = true;
        if (vm.activeTab === "unRelease") {
          vm.$refs.informationUnRelease.readHistoryLimitQuery();
        } else {
          vm.$refs.informationReleased.readHistoryLimitQuery();
        }
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.informationRelease {
  /deep/ .ivu-tabs-bar {
    margin-bottom: $top;
  }
}
</style>
