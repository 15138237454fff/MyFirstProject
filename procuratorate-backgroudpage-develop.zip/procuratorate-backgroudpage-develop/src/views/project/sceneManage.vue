<template>
  <div class="sceneManage">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训项目/课程"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-select
          size="large"
          v-model="limitQuery.status"
          @on-change="initLoadTable"
        >
          <i-option
            v-for="(item, index) of statusOptions"
            :key="index"
            :value="item.value"
            >{{ item.label }}</i-option
          >
        </i-select>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <!-- <template slot-scope="{ row }" slot="trainingTime">
          <span
            >{{ row.trainingTimeStart | toDate }}&nbsp;~&nbsp;{{
              row.trainingTimeEnd | toDate
            }}&nbsp;&nbsp;{{ row.trainingTimeStart | toTime }}~{{
              row.trainingTimeEnd | toTime
            }}</span
          >
        </template> -->
        <template slot-scope="{ row }" slot="trainingTime">
          <i-tooltip
            :content="`${row.trainingTimeStart} ~ ${row.trainingTimeEnd}`"
            :transfer="true"
            max-width="300px"
            >{{ row.trainingTimeStart }} ~ {{ row.trainingTimeEnd }}</i-tooltip
          >
        </template>
        <template slot-scope="{ row, index }" slot="isHasTeaching">
          <span
            class="to-see"
            v-if="row.isHasTeaching === 1"
            @click="clickTeaching(index)"
            >评教汇总</span
          >
          <span v-else>无</span>
        </template>
        <template slot-scope="{ row, index }" slot="isNeedCheckin">
          <span
            class="to-see"
            v-if="row.isNeedCheckin === 1"
            @click="clickCheckin(index)"
            >签到统计</span
          >
          <span v-else>无</span>
        </template>
        <template slot-scope="{ row, index }" slot="isNeedExam">
          <span
            class="to-see"
            v-if="row.isNeedExam === 1"
            @click="clickExam(index)"
            >成绩统计</span
          >
          <span v-else>无</span>
        </template>
        <template slot-scope="{ row }" slot="status">
          <span :class="row.classStatus | statusClassFilter">{{
            row.classStatus | statusValueFilter
          }}</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="modalOption.key === 'checkin'">
          <div>
            <div class="row">
              <div>
                <span>培训项目：</span>
                <span>{{ dataForCheckin.projectName }}</span>
              </div>
              <div>
                <span>总人数：</span>
                <span>{{ dataForCheckin.memberActual }}</span>
              </div>
            </div>
            <div class="row">
              <div>
                <span>培训课程：</span>
                <span>{{ dataForCheckin.className }}</span>
              </div>
              <div>
                <span>已签到人数：</span>
                <span>{{ dataForCheckin.actualCheckinNumber }}</span>
              </div>
            </div>
            <i-table
              :data="tableDataForCheckin"
              :columns="checkinColOption"
              :border="true"
              :max-height="300"
            >
              <template slot-scope="{ row }" slot="checkInStatus">
                <span :class="row.checkInStatus | checkinStatusClassFilter">{{
                  row.checkInStatus | checkinStatusValueFilter
                }}</span>
              </template>
            </i-table>
          </div>
        </template>
        <template v-if="modalOption.key === 'exam'">
          <div>
            <div class="row">
              <div>
                <span>培训项目：</span>
                <span>{{ dataForExam.className }}</span>
              </div>
              <div>
                <span>总人数：</span>
                <span>{{ dataForExam.studentNum }}</span>
              </div>
            </div>
            <div class="row">
              <div>
                <span>培训课程：</span>
                <span>{{ dataForExam.className }}</span>
              </div>
              <div>
                <span>参加考试人数：</span>
                <span>{{ dataForExam.examNum }}</span>
              </div>
            </div>
            <i-table
              :data="tableDataForExam"
              :columns="examColOption"
              :border="true"
              :max-height="300"
              :row-class-name="rowClassNameForExam"
            >
            </i-table>
          </div>
        </template>
        <template v-if="modalOption.key === 'teaching'">
          <div>
            <div class="row">
              <div>
                <span>培训项目：</span>
                <span>{{ dataForTeaching.projectName }}</span>
              </div>
              <div class="avg-score">
                <span>平均分数：</span>
                <span>{{ dataForTeaching.avg }}分</span>
              </div>
            </div>
            <div class="row">
              <div>
                <span>培训课程：</span>
                <span>{{ dataForTeaching.className }}</span>
              </div>
              <div>
                <span>试卷总分：</span>
                <span>{{ dataForTeaching.sum }}分</span>
              </div>
            </div>
            <div class="row">
              <div>
                <span>培训讲师：</span>
                <span>{{ dataForTeaching.teacherName }}</span>
              </div>
              <div></div>
            </div>
            <i-table
              :data="tableDataForTeaching"
              :columns="teachingColOption"
              :border="true"
              :height="300"
              :row-class-name="rowClassNameForTeaching"
              v-if="!modalOption.teachingShowDetail"
            >
              <template slot-scope="{ row, index }" slot="score">
                <span
                  class="to-see"
                  @click="clickToDetail(index)"
                  v-if="row.score !== 0"
                  >{{ row.score }}</span
                >
              </template>
            </i-table>
            <div class="teachingDetailBox" v-else>
              <div class="closeBtn" @click="clickCloseDetail">
                <i-icon type="md-close" size="24"></i-icon>
              </div>
              <div class="detailRow">
                <div>
                  <span>姓名：</span>
                  <span>{{ dataForTeaching.name }}</span>
                </div>
                <div>
                  <span>所属部门：</span>
                  <span>{{ dataForTeaching.deptName }}</span>
                </div>
                <div>
                  <span>评教总分：</span>
                  <span>{{ dataForTeaching.score }}</span>
                </div>
              </div>
              <i-table
                :data="tableDataForTeachingDetail"
                :columns="teachingDetailColOption"
                :border="true"
                :height="250"
              >
              </i-table>
            </div>
          </div>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" type="primary" @click="clickOutput"
          >导出</i-button
        >
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Tooltip,
  Icon
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "sceneManage",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-tooltip": Tooltip,
    "i-icon": Icon,
    "my-pagination": myPagination,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      tableDataForCheckin: [],
      tableDataForTeaching: [],
      tableDataForTeachingDetail: [],
      tableDataForExam: [],
      // 表格上方展示的数据
      dataForCheckin: {
        // 项目名称
        projectName: "",
        // 课程名称
        className: "",
        // 总人数
        memberActual: "",
        // 实际签到人数
        actualCheckinNumber: ""
      },
      dataForExam: {
        projectName: "",
        className: "",
        // 考试人数
        examNum: "",
        // 总人数
        studentNum: ""
      },
      dataForTeaching: {
        projectClassId: "",
        userId: "",
        teacherName: "",
        avg: "",
        sum: "",
        projectName: "",
        className: "",
        name: "",
        deptName: "",
        score: ""
      },

      // 表格显示的配置项
      colOption: [
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        { title: "培训课程", align: "center", key: "className", tooltip: true },
        {
          title: "培训讲师",
          align: "center",
          key: "teacherName",
          tooltip: true
        },
        { title: "培训时间", align: "center", slot: "trainingTime" },
        { title: "培训场地", align: "center", key: "siteName", tooltip: true },
        {
          title: "培训人数",
          align: "center",
          key: "memberActual",
          tooltip: true,
          width: 120
        },
        {
          title: "签到统计",
          align: "center",
          slot: "isNeedCheckin",
          width: 120
        },
        {
          title: "成绩统计",
          align: "center",
          slot: "isNeedExam",
          width: 120
        },
        {
          title: "评教汇总",
          align: "center",
          slot: "isHasTeaching",
          width: 120
        },
        { title: "状态", align: "center", width: 120, slot: "status" }
      ],
      checkinColOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "签到状态",
          align: "center",
          slot: "checkInStatus",
          tooltip: true
        },
        {
          title: "签到时间",
          align: "center",
          key: "actualCheckinTime",
          tooltip: true
        }
      ],
      examColOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "成绩",
          align: "center",
          key: "examScore",
          tooltip: true
        }
      ],
      teachingColOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "评教结果",
          align: "center",
          slot: "score",
          tooltip: true
        }
      ],
      teachingDetailColOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        {
          title: "评价项目",
          align: "center",
          key: "questionnaireProject",
          tooltip: true
        },
        {
          title: "评价内容",
          align: "center",
          key: "questionnaireContent",
          tooltip: true
        },
        {
          title: "结果",
          align: "center",
          key: "questionnaireSorce",
          width: 80
        }
      ],

      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 状态
        status: -1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-scene-manage",
        teachingShowDetail: false
      },
      statusOptions: [
        { value: -1, label: "全部状态" },
        { value: 4003, label: "未开始" },
        { value: 4004, label: "已开始" },
        { value: 4005, label: "已结束" }
      ]
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/scene/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    clickCloseDetail() {
      this.modalOption.teachingShowDetail = false;
    },
    // 查看签到统计
    clickCheckin(index) {
      // 取出当前点击的记录对象
      let currentObj = this.tableData[index];
      if (currentObj.classStatus !== 4005) {
        this.$Message.warning("培训课程未结束，暂不可查看签到统计！");
        return;
      }
      this.modalOption.title = "签到统计";
      this.modalOption.key = "checkin";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-scene-manage-checkin";
      // 从对象中取出要展示的值
      this.dataForCheckin.projectName = currentObj.projectName;
      this.dataForCheckin.className = currentObj.className;
      this.dataForCheckin.memberActual = currentObj.memberActual;
      this.requireCheckinList(currentObj.projectClassapplyId);
    },
    // 获取签到数据列表
    requireCheckinList(projectClassapplyId) {
      this.$axios
        .get(`/api/scene/getCheckinCount/${projectClassapplyId}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("签到统计数据获取失败");
            return;
          }
          this.dataForCheckin.actualCheckinNumber = data.actualCheckinNumber;
          this.tableDataForCheckin = data.checkinCountListVOS;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查看成绩统计
    clickExam(index) {
      // 取出当前点击的记录对象
      let currentObj = this.tableData[index];
      if (currentObj.classStatus !== 4005) {
        this.$Message.warning("培训课程未结束，暂不可查看成绩统计！");
        return;
      }
      this.modalOption.title = "成绩统计";
      this.modalOption.key = "exam";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-scene-manage-exam";
      this.dataForExam.className = currentObj.className;
      this.dataForExam.projectName = currentObj.projectName;
      this.requireScoreList(currentObj.projectClassapplyId);
    },
    // 获取考试成绩列表
    requireScoreList(id) {
      this.$axios
        .get(`/api/scene/scoreSummary/${id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data) {
            console.error("学员名单数据获取失败");
            return false;
          }
          this.dataForExam.examNum = data.examNum;
          this.dataForExam.studentNum = data.studentNum;
          // 保存列表数据
          this.tableDataForExam = data.scoreSummaryListVOS;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 查看评教汇总
    clickTeaching(index) {
      // 取出当前点击的记录对象
      let currentObj = this.tableData[index];
      if (currentObj.classStatus !== 4005) {
        this.$Message.warning("培训课程未结束，暂不可查看评教汇总！");
        return;
      }
      this.modalOption.title = "评教汇总";
      this.modalOption.key = "teaching";
      this.modalOption.modalVisiabal = true;
      this.modalOption.className = "modal-scene-manage-teaching";
      // 保存项目课程id
      this.dataForTeaching.projectClassId = currentObj.projectClassapplyId;
      // 从对象中取出要展示的值
      this.dataForTeaching.className = currentObj.className;
      this.dataForTeaching.projectName = currentObj.projectName;
      this.dataForTeaching.teacherName = currentObj.teacherName;
      this.requireTeachingList();
    },
    // 获取评教汇总列表
    requireTeachingList(projectClassaplyId) {
      this.$axios
        .get(`/api/scene/evaSummary/${this.dataForTeaching.projectClassId}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("签到统计数据获取失败");
            return;
          }
          this.dataForTeaching.avg = data.avg;
          this.dataForTeaching.sum = data.sum;
          this.tableDataForTeaching = data.evaluationSummaryDetailVOS;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickToDetail(index) {
      this.modalOption.teachingShowDetail = true;
      // 取出当前点击的记录对象
      let currentObj = this.tableDataForTeaching[index];
      this.dataForTeaching.score = currentObj.score;
      this.dataForTeaching.userId = currentObj.userId;
      this.dataForTeaching.name = currentObj.name;
      this.dataForTeaching.deptName = currentObj.deptName;
      this.requireTeachingDetailList();
    },
    // 获取个人评教详情数据
    requireTeachingDetailList() {
      this.$axios
        .get(
          `/api/scene/evaSummaryInfo/${this.dataForTeaching.projectClassId}/${this.dataForTeaching.userId}`
        )
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("个人评教详情列表数据获取失败");
            return;
          }
          this.tableDataForTeachingDetail = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    rowClassNameForExam(row) {
      if (row.examScore === null) {
        return "red";
      }
    },
    rowClassNameForTeaching(row) {
      if (row.score === 0) {
        return "red";
      }
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      // 如果当前对话框为评教汇总
      if (this.modalOption.key === "teaching") {
        // 可见性改变时，将评教汇总的详情隐藏
        this.modalOption.teachingShowDetail = false;
      }
    },
    // 导出的方法
    clickOutput() {
      this.$log.INFO("正在导出");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  },
  filters: {
    statusValueFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
        case 4002:
        case 4003:
        case 4007:
          return "未开始";
        case 4004:
          return "已开始";
        case 4005:
          return "已结束";
        default:
          return "";
      }
    },
    statusClassFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
        case 4002:
        case 4003:
        case 4007:
          return "orange";
        case 4004:
          return "green";
        case 4005:
        default:
          return "";
      }
    },
    checkinStatusValueFilter(value) {
      // 101-已签到 102-未签到 103-请假
      value = parseInt(value);
      switch (value) {
        case 101:
          return "已签到";
        case 102:
          return "未签到";
        case 103:
          return "请假";
        default:
          return "";
      }
    },
    checkinStatusClassFilter(value) {
      // 101-已签到 102-未签到 103-请假
      value = parseInt(value);
      switch (value) {
        case 101:
          return "green";
        case 102:
          return "red";
        case 103:
          return "blue";
        default:
          return "";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.sceneManage {
  .orange {
    color: $orange;
  }
  .green {
    color: $success;
  }
  .blue {
    color: $blue;
  }
  .red {
    color: $error;
  }
  .to-see {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
  }
}
// 模态框内容的样式设置
.modal-scene-manage-checkin,
.modal-scene-manage-exam,
.modal-scene-manage-teaching {
  .ivu-modal {
    width: 560px !important;
  }
  .modal-content {
    .ivu-select {
      width: 200px !important;
    }
  }
  .to-see {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .green {
    color: $success;
  }
  .blue {
    color: $blue;
  }
  .red {
    color: $error;
  }
}
.modal-scene-manage-checkin,
.modal-scene-manage-exam {
  .row:nth-child(2) {
    & > div:last-child span {
      color: $success;
    }
  }
}
.modal-scene-manage-teaching {
  .row {
    & > div:last-child {
      &.avg-score {
        color: $theme;
      }
      width: 320px;
      text-align: right;
      span {
        white-space: nowrap; //溢出不换行
      }
    }
  }
  .teachingDetailBox {
    border: 1px solid $border-color;
    padding: $top;
    height: 300px;
    position: relative;
    .closeBtn {
      width: 30px;
      height: 30px;
      position: absolute;
      top: 0;
      right: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      @extend .header-bg;
    }
    .detailRow {
      display: flex;
      margin-bottom: 10px;
      div {
        margin-right: 20px;
      }
    }
  }
}
</style>
