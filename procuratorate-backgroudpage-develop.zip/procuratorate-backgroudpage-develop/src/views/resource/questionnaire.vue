<template>
  <div class="case-base">
    <my-content-head>
      <div slot="left" class="left-content"></div>
      <div slot="right">
        <i-button
          size="large"
          @click="publish"
          type="primary"
          ghost
          v-if="state === 0 && $btnAuthorityTest('questionnaire:publish')"
          >发布</i-button
        >
        <i-button
          size="large"
          @click="unpublish"
          type="primary"
          ghost
          v-else-if="$btnAuthorityTest('questionnaire:depublish')"
          >取消发布</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="state === 1 ? publishColOption : noPublishColOption"
        :border="true"
        :loading="loading"
        ref="selection"
      >
        <template slot="questionnaireProject" slot-scope="{ row, index }">
          <i-input
            v-if="state == 0"
            v-model="tableData[index].questionnaireProject"
            placeholder="请输入"
            size="large"
          />
          <span v-else>{{ row.questionnaireProject }}</span>
        </template>
        <template slot="questionnaireContent" slot-scope="{ row, index }">
          <i-input
            v-if="state == 0"
            v-model="tableData[index].questionnaireContent"
            placeholder="请输入"
            size="large"
          />
          <span v-else>{{ row.questionnaireContent }}</span>
        </template>
        <template slot="option" slot-scope="{ row, index }">
          <span v-if="index + 1 < tableData.length">
            <i-icon
              type="ios-remove-circle"
              size="large"
              class="romove-icon"
              @click="romoveRow(index)"
            />
          </span>
          <span v-else>
            <i-icon
              type="ios-add-circle"
              size="large"
              class="add-icon"
              @click="addRow"
            />
          </span>
        </template>
      </i-table>
    </div>
  </div>
</template>

<script>
import { Table, Input, Button, Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "caseBase",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-icon": Icon,
    "my-content-head": myContentHead
  },
  data() {
    return {
      loading: false,
      // 消息总数量
      msgCount: 0,
      // 表格展示的数据
      tableData: [{ questionnaireNum: 1 }],
      // 表格显示的配置项
      noPublishColOption: [
        { title: "序号", align: "center", key: "questionnaireNum", width: 80 },
        {
          title: "评价项目",
          align: "center",
          key: "questionnaireProject",
          slot: "questionnaireProject"
        },
        {
          title: "评价内容",
          align: "center",
          key: "questionnaireContent",
          slot: "questionnaireContent"
        },
        { title: "操作", align: "center", slot: "option", width: 100 }
      ],
      // 表格显示的配置项
      publishColOption: [
        { title: "序号", align: "center", key: "questionnaireNum", width: 80 },
        {
          title: "评价项目",
          align: "center",
          key: "questionnaireProject",
          slot: "questionnaireProject"
        },
        {
          title: "评价内容",
          align: "center",
          key: "questionnaireContent",
          slot: "questionnaireContent"
        }
      ],
      state: 0
    };
  },
  mounted() {
    // 获取评教问卷状态
    this.getQuestionnaireState();
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 移除行
    romoveRow(index) {
      if (this.tableData.length === 1) {
        this.$Message.error("已经不能再删除了！");
        return;
      }
      this.tableData.splice(index, 1);
      for (let index = 0; index < this.tableData.length; index++) {
        const element = this.tableData[index];
        element.questionnaireNum = index + 1;
      }
    },
    // 添加行
    addRow() {
      this.tableData.push({
        questionnaireNum: this.tableData.length + 1
      });
    },
    // 发布前验证发布项目是否为空
    testForm() {
      let sign = true;
      this.tableData.forEach(el => {
        if (!sign) {
          return;
        }
        if (this.$isEmpty(el.questionnaireProject)) {
          sign = false;
          this.$Message.error("请填写评价项目");
        }
      });
      return sign;
    },
    // 发布
    publish() {
      let sign = this.testForm();
      if (!sign) {
        return;
      }
      this.$axios
        .post("/api/questionnaire/publish", this.tableData)
        .then(res => {
          this.$Message.success("发布成功");
          // 获取评教问卷状态
          this.getQuestionnaireState();
          // 请求列表数据
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 取消发布
    unpublish() {
      this.$axios
        .put("/api/questionnaire/unpublish")
        .then(res => {
          this.$Message.success("取消发布成功");
          this.state = 0;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 获取评教问卷状态
    getQuestionnaireState() {
      this.$axios
        .get("/api/questionnaire/isPublish")
        .then(res => {
          this.state = res.data.data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 列表
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/questionnaire/list")
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (this.$isEmpty(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>

<style lang="scss" scoped>
.content {
  .ivu-input-wrapper {
    width: 100% !important;
  }
  .romove-icon {
    font-size: 24px;
    color: $error;
  }
  .add-icon {
    font-size: 24px;
    color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .ivu-date-picker:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .left {
    flex: 2 !important;
  }
  /deep/ .right {
    flex: 1 !important;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
    // max-width: 380px;
    // min-width: 320px;
  }
}
</style>
