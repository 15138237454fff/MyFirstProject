<template>
  <div class="testQuestions">
    <my-content-head>
      <div slot="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入题目名称/课程名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-select
          v-model="limitQuery.questionTypeId"
          size="large"
          @on-change="initLoadTable"
        >
          <i-option
            v-for="(item, index) of questionsOption"
            :key="index"
            :value="item.value"
            >{{ item.label }}</i-option
          >
        </i-select>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('question:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('question:add')"
          >删除</i-button
        >
        <i-button size="large" @click="clickDown" type="primary" ghost
          >下载模板</i-button
        >
        <i-dropdown trigger="click" @on-click="handleDropdownItemClick">
          <i-button size="large" type="primary" ghost>
            批量操作
            <i-icon type="ios-arrow-down"></i-icon>
          </i-button>
          <i-dropdown-menu slot="list">
            <i-dropdown-item name="input">导入</i-dropdown-item>
            <i-dropdown-item name="output">导出</i-dropdown-item>
          </i-dropdown-menu>
        </i-dropdown>
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="questionTypeId">
          <span>{{ row.questionTypeId | questionTypeFilter }}</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span @click="clickSee(row.questionId)" class="toSee">查看</span>
          <span v-if="row.questionStatus !== 2">&nbsp;|&nbsp;</span>
          <span
            @click="clickModify(row.questionId)"
            class="modify"
            v-if="
              row.questionStatus !== 2 && $btnAuthorityTest('question:update')
            "
            >修改</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :category="limitQuery.questionTypeId"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="modalOption.key == 'see'">
          <div class="modal-see">
            <div class="row">
              <span>题目名称：</span>
              <span>{{ formData.questionName }}</span>
            </div>
            <div class="row">
              <span>题目类型：</span>
              <span>{{ formData.questionTypeId | questionTypeFilter }}</span>
            </div>
            <div class="row">
              <span>关联课程：</span>
              <span>{{ formData.className }}</span>
            </div>
            <div class="row">
              <span>培训讲师：</span>
              <span>{{ connectTeacher }}</span>
            </div>
            <div class="row">
              <span>分 值：</span>
              <span>{{ formData.questionScore }}</span>
            </div>
            <i-table
              :data="formData.resourceQuestionOptionDTOS"
              :columns="colSeeOption"
              :border="true"
            >
              <template slot-scope="{ row }" slot="optionIsanswer">
                <span class="option-isanwer">{{
                  row.optionIsanswer === 1 ? "✔" : ""
                }}</span>
              </template>
            </i-table>
          </div>
        </template>
        <template v-if="modalOption.key == 'modify'">
          <div class="modal-modify">
            <div class="row">
              <span class="required">题目名称：</span>
              <i-input
                size="large"
                v-model="formData.questionName"
                placeholder="请输入"
              ></i-input>
            </div>
            <div class="row">
              <span class="required">题目类型：</span>
              <i-radio-group
                v-model="formData.questionTypeId"
                size="large"
                @on-change="handleQuestionTypeChange"
              >
                <i-radio :label="1">单选题</i-radio>
                <i-radio :label="2">多选题</i-radio>
                <i-radio :label="3">判断题</i-radio>
              </i-radio-group>
            </div>
            <div class="row">
              <span class="required">关联课程：</span>
              <i-select
                v-model="formData.questionClassId"
                size="large"
                filterable
                placeholder="请输入选择"
                @on-change="requireConnectTeacher"
              >
                <i-option
                  v-for="(item, index) of courseOption"
                  :key="index"
                  :value="item.classId"
                  >{{ item.className }}</i-option
                >
              </i-select>
            </div>
            <div class="row">
              <span>培训讲师：</span>
              <span>{{ connectTeacher }}</span>
            </div>
            <div class="row">
              <span class="required">分 值：</span>
              <i-input
                size="large"
                v-model="formData.questionScore"
                type="number"
                class="score"
              ></i-input>
            </div>
            <i-table
              :data="formData.resourceQuestionOptionDTOS"
              :columns="
                formData.questionTypeId !== 3
                  ? colModifyOption
                  : colJudgeModifyOption
              "
              :border="true"
              class="question-table"
            >
              <template slot-scope="{ row, index }" slot="optionIsanswer">
                <i-checkbox
                  size="large"
                  v-model="
                    formData.resourceQuestionOptionDTOS[index].optionIsanswer
                  "
                  :true-value="1"
                  :false-value="0"
                  v-if="formData.questionTypeId === 2"
                ></i-checkbox>
                <i-radio
                  size="large"
                  :value="row.optionIsanswer"
                  :true-value="1"
                  :false-value="0"
                  @on-change="
                    handleresourceQuestionOptionDTOSChange(
                      index,
                      row.optionIsanswer
                    )
                  "
                  v-else
                ></i-radio>
              </template>
              <template slot-scope="{ row, index }" slot="action">
                <div
                  @click="addRow"
                  class="add"
                  v-if="
                    index === formData.resourceQuestionOptionDTOS.length - 1
                  "
                >
                  +
                </div>
                <div v-else class="reduce" @click="reduceRow(index)">-</div>
              </template>
              <template slot-scope="{ row, index }" slot="optionText">
                <i-input
                  size="large"
                  v-model="
                    formData.resourceQuestionOptionDTOS[index].optionText
                  "
                  v-if="formData.questionTypeId !== 3"
                  placeholder="请输入"
                  class="option-text"
                ></i-input>
              </template>
            </i-table>
          </div>
        </template>
      </div>
      <p slot="footer" v-if="modalOption.key == 'modify'">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Icon,
  Select,
  Option,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Radio,
  RadioGroup,
  Checkbox
} from "view-design";
import myModal from "@/components/common/myModal";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "testQuestions",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-dropdown": Dropdown,
    "i-dropdown-menu": DropdownMenu,
    "i-dropdown-item": DropdownItem,
    "i-select": Select,
    "i-option": Option,
    "i-icon": Icon,
    "i-radio": Radio,
    "i-radio-group": RadioGroup,
    "i-checkbox": Checkbox,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "题目名称",
          align: "center",
          key: "questionName",
          tooltip: true
        },
        {
          title: "题目类型",
          align: "center",
          slot: "questionTypeId",
          width: 120
        },
        { title: "关联课程", align: "center", key: "className", tooltip: true },
        {
          title: "培训讲师",
          align: "center",

          render: (h, params) => {
            let row = params.row;
            return h(
              "span",
              row.classTeacherVOS
                .map(el => {
                  return el.name;
                })
                .join(",")
            );
          }
        },
        {
          title: "答案",
          align: "center",
          key: "answer",
          tooltip: true
        },
        {
          title: "分值",
          align: "center",
          key: "questionScore",
          width: 80,
          tooltip: true
        },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      colSeeOption: [
        { title: "选项", align: "center", key: "optionNum", width: 80 },
        {
          title: "选项内容",
          align: "center",
          key: "optionText",
          tooltip: true
        },
        {
          title: "正确答案",
          align: "center",
          width: 120,
          slot: "optionIsanswer"
        }
      ],
      colModifyOption: [
        { title: "选项", align: "center", key: "optionNum", width: 70 },
        {
          title: "选项内容",
          align: "center",
          slot: "optionText",
          tooltip: true
        },
        {
          title: "正确答案",
          align: "center",
          width: 100,
          slot: "optionIsanswer"
        },
        { title: "操作", align: "center", width: 70, slot: "action" }
      ],
      colJudgeModifyOption: [
        { title: "选项", align: "center", key: "optionNum", width: 70 },
        {
          title: "选项内容",
          align: "center",
          slot: "optionText",
          tooltip: true
        },
        {
          title: "正确答案",
          align: "center",
          width: 100,
          slot: "optionIsanswer"
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 试题类别id
        questionTypeId: 0
      },
      // 表单数据
      formData: {
        // 课程名字
        className: "",
        // 试题关联的课程ID
        questionClassId: "",
        // 试题名称
        questionName: "",
        // 试题分值
        questionScore: "",
        // 试题类型ID
        questionTypeId: 1,
        // 试题选项列表
        resourceQuestionOptionDTOS: []
      },
      // 当前查看的题目id
      questionId: "",
      // 试题类别可选列表
      questionsOption: [
        { value: 0, label: "全部题目类型" },
        { value: 1, label: "单选题" },
        { value: 2, label: "多选题" },
        { value: 3, label: "判断题" }
      ],
      // 选中的记录列表
      selectedHistoryList: [],
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        // 样式名
        className: "modal-test-questions",
        // 功能名称
        key: ""
      },
      // 关联课程的老师
      connectTeacher: "",
      // 选项名称的备选列表
      optionNumOption: ["A", "B", "C", "D", "E", "F"],
      // 课程待选列表
      courseOption: []
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      this.$axios
        .post("/api/question/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 添加
    clickAdd() {
      this.$router.push("/testQuestionsDetail");
    },
    clickDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      let tmpArr = this.selectedHistoryList.map(el => el.questionId);
      this.$axios
        .delete("/api/question/delete", { data: tmpArr })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 单条试题数据回显
    dataBack() {
      this.$axios
        .get(`/api/question/${this.questionId}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.connectTeacher = data.classTeacherVOS
            .map(el => {
              return el.name;
            })
            .join(",");
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击查看
    clickSee(index) {
      this.$log.INFO("去查看");
      // 保存当前查看的题目id
      this.questionId = index;
      this.modalOption.title = "详情";
      this.modalOption.key = "see";
      this.modalOption.modalVisiabal = true;
      // 查询详情
      this.dataBack();
    },
    // 点击修改
    clickModify(index) {
      this.$log.INFO("去修改");
      // 保存当前查看的题目id
      this.questionId = index;
      this.modalOption.title = "修改";
      this.modalOption.key = "modify";
      this.modalOption.modalVisiabal = true;
      // 请求课程列表
      this.requireCourseOption();
      // 查询详情
      this.dataBack();
    },
    // 校验表单的方法
    testForm() {
      let {
          questionClassId,
          questionName,
          questionScore,
          questionTypeId,
          resourceQuestionOptionDTOS
        } = this.formData,
        sign = true,
        normal = { value: false, msg: "请填写完整后再尝试保存！" };
      // 判断课程是否为空
      if (questionClassId === "") {
        return normal;
      }
      // 题目名称为空
      if (questionName === "" || questionName.length > 50) {
        normal.msg = "请输入50位以内的题目名称";
        return normal;
      }
      // 题目分数为空
      if (questionScore === "") {
        return normal;
      }
      // 题目类型为空
      if (questionTypeId === "") {
        return normal;
      }
      // 当多选和单选时判断题目内容
      if (questionTypeId === 1 || questionTypeId === 2) {
        resourceQuestionOptionDTOS.forEach(resource => {
          if (!sign) {
            return;
          }
          let optionText = resource.optionText;
          if (optionText === "" || optionText.length > 50) {
            sign = false;
            normal.msg = "请输入50位以内的选项内容";
          }
        });
      }
      if (questionTypeId === 1) {
        let count = resourceQuestionOptionDTOS.reduce((prev, resource) => {
          return resource.optionIsanswer + prev;
        }, 0);
        if (count !== 1) {
          sign = false;
          normal.msg = "单选题请选择一个答案";
        }
      }
      if (questionTypeId === 2) {
        let count = resourceQuestionOptionDTOS.reduce((prev, resource) => {
          return resource.optionIsanswer + prev;
        }, 0);
        if (count < 2) {
          sign = false;
          normal.msg = "多选题请至少选择两个答案";
        }
      }
      if (questionTypeId === 3) {
        let count = resourceQuestionOptionDTOS.reduce((prev, resource) => {
          return resource.optionIsanswer + prev;
        }, 0);
        if (count !== 1) {
          sign = false;
          normal.msg = "判断题请选择一个答案";
        }
      }
      if (sign) {
        return { value: true, msg: "验证通过" };
      } else {
        return normal;
      }
    },
    clickOk() {
      // 隐藏模态框
      let result = this.testForm();
      if (result.value) {
        this.handleSave();
      } else {
        this.$Message.error(result.msg);
      }
    },
    // 处理保存的方法
    handleSave() {
      let tmpObj = Object.assign({}, this.formData, {
        questionId: this.questionId
      });
      delete tmpObj.className;
      this.$axios
        .put("/api/question/update", tmpObj)
        .then(res => {
          this.$Message.success("修改成功");
          this.modalOption.modalVisiabal = false;
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 请求课程的待选列表
    requireCourseOption() {
      this.$axios
        .get(`/api/class/getInnerClass`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("课程列表获取失败");
            return false;
          }
          this.courseOption = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求关联课程的老师
    requireConnectTeacher() {
      // 验证课程Id非空
      if (!this.formData.questionClassId) {
        this.$log.INFO("课程Id为空，无法请求关联的老师");
        return;
      }
      this.$axios
        .get(`/api/class/getTeachersName/${this.formData.questionClassId}`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("培训教师获取失败");
            return false;
          }
          this.connectTeacher = data
            .map(el => {
              return el.name;
            })
            .join(",");
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 添加题目的选项
    addRow() {
      if (this.formData.resourceQuestionOptionDTOS.length > 5) {
        this.$Message.error("题目中的选项不能超过6个");
        return;
      }
      this.formData.resourceQuestionOptionDTOS.push({
        // 是否是答案
        optionIsanswer: 0,
        // 选项名称
        optionNum: "",
        // 选项内容
        optionText: ""
      });
      // 重新定义选项名称
      this.formData.resourceQuestionOptionDTOS.forEach((el, ind) => {
        el.optionNum = this.optionNumOption[ind];
      });
    },
    // 删除题目的选项
    reduceRow(index) {
      if (this.formData.resourceQuestionOptionDTOS.length < 3) {
        this.$Message.error("题目中的选项不能少于2个");
        return;
      }
      this.formData.resourceQuestionOptionDTOS.splice(index, 1);
      // 重新定义选项名称
      this.formData.resourceQuestionOptionDTOS.forEach((el, index) => {
        el.optionNum = this.optionNumOption[index];
      });
    },
    // 处理判断题选择改变的函数
    handleresourceQuestionOptionDTOSChange(index, val) {
      // 先将所有清空所有选项
      this.formData.resourceQuestionOptionDTOS.forEach(el => {
        el.optionIsanswer = 0;
      });
      // 选择选中项
      this.formData.resourceQuestionOptionDTOS[index].optionIsanswer = 1;
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 下载模板
    clickDown() {},
    // 导入的方法
    handleInput() {
      this.$log.INFO("正在导入");
    },
    // 导出的方法
    handleOutput() {
      this.$log.INFO("正在导出");
    },
    // 处理下拉项点击事件的方法
    handleDropdownItemClick(name) {
      if (name === "input") {
        // 调用导入
        this.handleInput();
      } else {
        // 调用导出
        this.handleOutput();
      }
    },
    // 清空表单
    clearFormData() {
      this.formData = {
        // 课程名字
        className: "",
        // 试题关联的课程ID
        questionClassId: "",
        // 试题名称
        questionName: "",
        // 试题分值
        questionScore: "",
        // 试题类型ID
        questionTypeId: 1,
        // 试题选项列表
        resourceQuestionOptionDTOS: []
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 切换题目类型的处理函数
    handleQuestionTypeChange(val) {
      switch (val) {
        case 1:
        case 2:
          this.formData.resourceQuestionOptionDTOS.map((el, index) => {
            el.optionIsanswer = 0;
            el.optionNum = this.optionNumOption[index];
          });
          return false;
        case 3:
          this.formData.resourceQuestionOptionDTOS = [
            {
              // 是否是答案
              optionIsanswer: 0,
              // 选项名称
              optionNum: "T",
              // 选项内容
              optionText: ""
            },
            {
              // 是否是答案
              optionIsanswer: 0,
              // 选项名称
              optionNum: "F",
              // 选项内容
              optionText: ""
            }
          ];
          return false;
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  },
  filters: {
    // 过滤问题类型
    questionTypeFilter(val) {
      val = parseInt(val);
      switch (val) {
        case 1:
          return "单选题";
        case 2:
          return "多选题";
        case 3:
          return "判断题";
        default:
          return "";
      }
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.name === from.meta.name) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
        vm.limitQuery.questionTypeId = limitQuery.category;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.testQuestions {
  .content {
    .toSee,
    .modify {
      cursor: pointer;
    }
    .toSee {
      text-decoration: underline;
      color: $theme;
    }
    .modify {
      text-decoration: underline;
      color: $orange;
    }
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .left {
    flex: 1 !important;
    & > div {
      display: flex;
      flex-wrap: wrap;
    }
  }
  .right {
    flex: 1 !important;
  }
}
.modal-test-questions {
  .ivu-modal {
    width: 40vw !important;
    min-width: 520px !important;
  }
  .modal-content {
    .modal-see {
      width: 100%;
      .row {
        display: flex;
        align-items: center;
        margin-bottom: $top;
        width: 100%;
        & > span:first-child {
          display: block;
          line-height: 34px;
          width: 74px;
          text-align: left;
        }
      }
    }
    .modal-modify {
      width: 100%;
      .row {
        display: flex;
        align-items: center;
        margin-bottom: $top;
        width: 90%;
        & > span:first-child {
          display: block;
          line-height: 34px;
          width: 100px;
          text-align: right;
        }
      }
    }

    .option-isanwer {
      color: $theme;
      font-size: 20px;
    }
    .add,
    .reduce {
      background: $error;
      margin: 0 auto;
      width: 24px;
      height: 24px;
      text-align: center;
      line-height: 24px;
      color: $white;
      border-radius: 50%;
      font-size: 24px;
    }
    .add {
      background: $theme;
    }
    .reduce {
      line-height: 20px;
      font-size: 30px;
    }
    .ivu-select,
    .ivu-input-wrapper {
      width: 80% !important;
      &.score {
        width: auto !important;
      }
    }
    .question-table {
      .ivu-input-wrapper {
        width: 100% !important;
      }
      .ivu-radio-wrapper,
      .ivu-radio,
      .ivu-checkbox-wrapper {
        margin-right: 0;
      }
    }
  }
}
</style>
