<template>
  <div class="courseDetail">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "courseDetail"
};
</script>
