<template>
  <div class="course">
    <my-content-head>
      <div slot="left">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入课程名称/培训讲师"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
        <i-cascader
          size="large"
          v-model="limitQuery.classCategoryId"
          :data="courseTypeOption"
          @on-change="handleCascaderChange"
          :clearable="false"
        ></i-cascader>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAdd"
          type="primary"
          v-if="$btnAuthorityTest('class:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('class:delete')"
          >删除</i-button
        >
        <i-badge type="error" overflow-count="10" :count="waitAduitNum">
          <i-button size="large" @click="clickAduit" type="primary" ghost
            >课程审核</i-button
          >
        </i-badge>
        <i-button size="large" @click="clickDown" type="primary" ghost
          >下载模板</i-button
        >
        <i-dropdown trigger="click" @on-click="handleDropdownItemClick">
          <i-button size="large" type="primary" ghost>
            批量操作
            <i-icon type="ios-arrow-down"></i-icon>
          </i-button>
          <i-dropdown-menu slot="list">
            <i-dropdown-item name="input">导入</i-dropdown-item>
            <i-dropdown-item name="output">导出</i-dropdown-item>
          </i-dropdown-menu>
        </i-dropdown>
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="action">
          <span @click="clickSee(row.classId)" class="toSee">查看</span>&nbsp;|
          <span
            @click="clickModify(row.classId)"
            class="modify"
            v-if="$btnAuthorityTest('class:update')"
            >修改</span
          >
        </template>
        <template slot-scope="{ row }" slot="teacherName">
          <i-tooltip
            :content="row.teacherInfoVOS.map(el => el.name).join('、')"
            :transfer="true"
            max-width="300px"
            >{{ row.teacherInfoVOS.map(el => el.name).join("、") }}</i-tooltip
          >
          <span></span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :category="limitQuery.classCategoryId"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Icon,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Cascader,
  Tooltip,
  Badge
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "course",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "i-dropdown": Dropdown,
    "i-dropdown-menu": DropdownMenu,
    "i-dropdown-item": DropdownItem,
    "i-icon": Icon,
    "i-cascader": Cascader,
    "i-badge": Badge,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        { title: "课程号", align: "center", key: "classNum", tooltip: true },
        { title: "课程名称", align: "center", key: "className", tooltip: true },
        {
          title: "课程类别",
          align: "center",
          key: "classCategoryId",
          tooltip: true
        },
        {
          title: "培训讲师",
          align: "center",
          slot: "teacherName",
          tooltip: true
        },
        {
          title: "学分",
          align: "center",
          key: "classCredit",
          width: 120,
          tooltip: true
        },
        {
          title: "学时",
          align: "center",
          key: "classPeriod",
          width: 120,
          tooltip: true
        },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 课程类别id
        classCategoryId: [""],
        // 审核状态 1：未审核 2：已审核
        classStatus: 2
      },
      // 课程类别可选列表
      courseTypeOption: [],
      // 选中的记录列表
      selectedHistoryList: [],
      // 课程类型查询的参数id
      parameterID: "XP-001",
      // 待审核的记录数
      waitAduitNum: 0,
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
      // 请求课程类别下拉框数据
      this.requireCourseTypeOption();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 监听级联选择器的变化
    handleCascaderChange(val) {
      this.limitQuery.classCategoryId = val;
      this.initLoadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      let tmpObj = Object.assign({}, this.limitQuery);
      // 取出课程类别id并覆盖原值
      tmpObj.classCategoryId =
        tmpObj.classCategoryId[tmpObj.classCategoryId.length - 1];
      this.$axios
        .post("/api/class/listClass", tmpObj)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
      // 请求待审核的记录条数
      this.loadWaitAduitNum();
    },
    // 获取待审核的记录数
    loadWaitAduitNum() {
      this.$axios
        .get("/api/class/getUncheckCount")
        .then(res => {
          let data = res.data;
          this.waitAduitNum = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求课程类型参数的待选列表
    requireCourseTypeOption() {
      this.$axios
        .get(`/api/param/${this.parameterID}`)
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data.content)) {
            console.error("课程类别参数获取失败");
            return false;
          }
          // 数据格式化
          data.content = data.content.map(el => {
            return { label: el.title, value: el.title };
          });
          data.content.unshift({ value: "", label: "全部课程类别" });
          this.courseTypeOption = data.content;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 添加
    clickAdd() {
      this.$router.push("/courseDetail/add");
    },
    clickDelete() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      this.saveDelete();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存删除的操作
    saveDelete() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      let tmpArr = this.selectedHistoryList.map(el => el.classId);
      this.$axios
        .delete("/api/class/delete", { data: tmpArr })
        .then(res => {
          this.$Message.success("删除成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击课程审核
    clickAduit() {
      this.$router.push("/courseAduit/list");
    },
    // 点击查看
    clickSee(index) {
      this.$log.INFO("去查看");
      this.$router.push(`/courseDetail/see/${index}`);
    },
    // 点击修改
    clickModify(index) {
      this.$log.INFO("去修改");
      this.$router.push(`/courseDetail/modify/${index}`);
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 下载模板
    clickDown() {},
    // 导入的方法
    handleInput() {
      this.$log.INFO("正在导入");
    },
    // 导出的方法
    handleOutput() {
      this.$log.INFO("正在导出");
    },
    // 处理下拉项点击事件的方法
    handleDropdownItemClick(name) {
      if (name === "input") {
        // 调用导入
        this.handleInput();
      } else {
        // 调用导出
        this.handleOutput();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  },
  beforeRouteEnter: (to, from, next) => {
    next(vm => {
      if (to.meta.name === from.meta.name) {
        let limitQuery = vm.$store.getters["skb/getLimitQuery"];
        vm.limitQuery.pageSize = limitQuery.pageSize;
        vm.limitQuery.pageNum = limitQuery.pageNum;
        vm.limitQuery.query = limitQuery.query;
        vm.limitQuery.classCategoryId = limitQuery.category;
      }
    });
  }
};
</script>
<style lang="scss" scoped>
.course {
  .content {
    .toSee,
    .modify {
      cursor: pointer;
    }
    .toSee {
      text-decoration: underline;
      color: $theme;
    }
    .modify {
      text-decoration: underline;
      color: $orange;
    }
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .ivu-badge {
    margin-right: $left;
    .ivu-btn-large {
      margin-right: 0;
    }
  }
  .left {
    flex: 1 !important;
    & > div {
      display: flex;
      flex-wrap: wrap;
    }
  }
  .right {
    flex: 1 !important;
  }
}
</style>
