<template>
  <div class="resourceLibraryAudit">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "resourceLibraryAudit"
};
</script>
<style lang="scss" scoped>

</style>
