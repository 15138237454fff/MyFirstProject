<template>
  <div class="site">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入场地名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="handleAdd"
          type="primary"
          v-if="$btnAuthorityTest('site:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('site:delete')"
          >删除</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="status" slot-scope="{ row }">
          <i-switch
            v-model="row.siteLockStatus"
            size="large"
            @on-change="handleSwitch(row.siteId, row.siteLockStatus)"
            :false-value="0"
            :true-value="1"
            v-if="$btnAuthorityTest('site:lock')"
          >
            <span slot="open">正常</span>
            <span slot="close">锁定</span>
          </i-switch>
        </template>
        <template slot="useDetail" slot-scope="{ row }">
          <span
            class="detail"
            @click="queryUseDetail(row.siteId, row.siteName)"
            v-if="$btnAuthorityTest('site:update')"
            >使用详情</span
          >
        </template>
        <template slot="siteCheckinId" slot-scope="{ row }">
          <span>{{ siteCheckinIdFilter(row.siteCheckinId) }}</span>
        </template>
        <template slot="option" slot-scope="{ row }">
          <span
            class="modify"
            v-if="row.useStatus == 0"
            @click="updateSiteInfo(row)"
            >修改</span
          >
          <span class="unModify" v-else>修改</span>
        </template>
      </i-table>
      <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
        <div class="modal-content">
          <div class="useDetail" v-if="modalOption.key === 'useDetail'">
            <i-table
              :data="useDetailPageInfo"
              :columns="useDetailColOption"
              :border="true"
              ref="selection"
              @on-selection-change="handleSelectChange"
            ></i-table>
            <div style="padding-top:20px;text-align: center;">
              <i-page
                show-total
                show-sizer
                :pageSize="useDetailQuery.pageSize"
                :pageNum="useDetailQuery.pageNum"
                :total="modalMsgCount"
                @on-page-size-change="modalLoadTable"
                @on-change="modalLoadTable"
                show-elevator
              ></i-page>
            </div>
          </div>
          <div
            class="modifyInfo"
            v-if="modalOption.key === 'modify' || modalOption.key === 'add'"
          >
            <i-form
              :model="site"
              :label-width="100"
              class="site-form"
              ref="formValidate"
              :rules="ruleValidate"
            >
              <i-form-item label="场地名称：" required prop="siteName">
                <i-input
                  v-model="site.siteName"
                  placeholder="请输入"
                  size="large"
                ></i-input>
              </i-form-item>
              <i-form-item label="地点：" required prop="siteLocation">
                <i-input
                  v-model="site.siteLocation"
                  placeholder="请输入"
                  size="large"
                  type="textarea"
                  :autosize="{ minRows: 2, maxRows: 5 }"
                ></i-input>
              </i-form-item>
              <i-form-item label="容量：" required prop="siteCapacity">
                <i-input
                  v-model="site.siteCapacity"
                  placeholder="请输入"
                  number
                  size="large"
                >
                  <span slot="append">人</span>
                </i-input>
              </i-form-item>
              <i-form-item label="签到设备：">
                <i-select
                  v-model="site.siteCheckinId"
                  placeholder="请输入"
                  size="large"
                >
                  <i-option
                    v-for="(item, index) of signInEquipmentList"
                    :key="index"
                    :value="item.value"
                    >{{ item.label }}</i-option
                  >
                </i-select>
              </i-form-item>
            </i-form>
          </div>
        </div>
        <p
          slot="footer"
          v-if="modalOption.key === 'modify' || modalOption.key === 'add'"
        >
          <i-button size="large" @click="modalOption.modalVisiabal = false"
            >取消</i-button
          >
          <i-button
            size="large"
            type="primary"
            @click="handleUpdate('formValidate')"
            >保存</i-button
          >
        </p>
      </my-modal>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>

<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Switch,
  Page,
  Form,
  FormItem
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "site",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-switch": Switch,
    "i-page": Page,
    "i-form": Form,
    "i-form-item": FormItem,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      loading: false,
      // 消息总数量
      msgCount: 0,
      // 表格展示的数据
      tableData: [],
      // 详情列表信息
      useDetailColOption: [
        {
          title: "预定人",
          align: "center",
          key: "name",
          width: 120,
          tooltip: true
        },
        {
          title: "使用时间",
          align: "center",
          width: 200,
          render: (h, params) => {
            return h(
              "span",
              params.row.startTime + " 至 " + params.row.endTime
            );
          }
        },
        { title: "培训课程", align: "center", key: "className", tooltip: true },
        {
          title: "状态",
          align: "center",
          key: "siteStatus",
          width: 100,
          render: (h, params) => {
            var color = params.row.siteStatus === 2 ? "#188f96" : "#FF9A32";
            var text = params.row.siteStatus === 2 ? "使用中" : "已预约";
            return h(
              "span",
              {
                style: {
                  color: color
                }
              },
              text
            );
          }
        }
      ],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        { title: "场地名称", align: "center", key: "siteName", tooltip: true },
        { title: "地点", align: "center", key: "siteLocation", tooltip: true },
        { title: "容量", align: "center", key: "siteCapacity", tooltip: true },
        {
          title: "签到设备",
          align: "center",
          slot: "siteCheckinId",
          tooltip: true
        },
        {
          title: "状态",
          align: "center",
          key: "siteLockStatus",
          slot: "status",
          width: 120
        },
        { title: "使用详情", align: "center", slot: "useDetail", width: 120 },
        { title: "操作", align: "center", slot: "option", width: 120 }
      ],
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-site-detail"
      },
      // 表单数据
      site: {
        siteCapacity: "",
        siteCheckinId: 1,
        siteLocation: "",
        siteName: ""
      },
      // 表单校验规则
      ruleValidate: {
        siteName: [
          {
            required: true,
            message: "场地名称不能为空，且长度不能超过20位",
            trigger: "blur",
            max: 20
          }
        ],
        siteLocation: [
          { required: true, message: "场地位置不能为空", trigger: "blur" }
        ],
        siteCapacity: [
          {
            required: true,
            message: "场地容量只能为正整数",
            trigger: "blur",
            pattern: /^[1-9]\d*$/
          }
        ]
      },
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 选中数据
      selectedHistoryList: [],
      // 使用详情列表信息
      useDetailPageInfo: [],
      modalMsgCount: 0,
      // 使用详情查询辅助
      useDetailQuery: {
        query: "",
        pageSize: 10,
        pageNum: 1
      },
      signInEquipmentList: [{ label: "人脸识别", value: 1 }]
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 添加
    handleAdd() {
      this.modalOption.title = `添加`;
      this.modalOption.key = "add";
      this.modalOption.className = "modal-site-update";
      this.modalOption.modalVisiabal = true;
    },
    // 确认删除
    clickDelete() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      for (let index = 0; index < this.selectedHistoryList.length; index++) {
        const element = this.selectedHistoryList[index];
        if (element.useStatus > 0) {
          this.$Message.error("培训场地在使用中/预定中，不可删除！");
          return;
        }
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 删除
    handleDelete() {
      let tmpArr = this.selectedHistoryList.map(item => {
        return item.siteId;
      });
      this.$axios
        .delete("/api/site/delete", { data: tmpArr })
        .then(res => {
          this.$Message.success("删除成功");
          // 重新加载列表数据
          this.loadTable();
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 修改
    handleUpdate(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          if (this.$isEmpty(this.site.siteId)) {
            this.submitSave();
          } else {
            this.submitUpdate();
          }
        } else {
          this.$Message.error("请填写完整后再尝试保存！");
        }
      });
    },
    // 提交添加信息
    submitSave() {
      this.$axios
        .post("/api/site/insert", this.site)
        .then(res => {
          this.$Message.success("添加成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 提交修改信息
    submitUpdate() {
      this.$axios
        .put("/api/site/update", this.site)
        .then(res => {
          this.$Message.success("修改成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 修改
    updateSiteInfo(row) {
      this.modalOption.title = `修改`;
      this.modalOption.key = "modify";
      this.modalOption.className = "modal-site-update";
      this.modalOption.modalVisiabal = true;
      this.site = JSON.parse(JSON.stringify(row));
    },
    // 使用详情
    queryUseDetail(siteId, sieteName) {
      // 查询使用详情
      this.useDetailQuery.query = siteId;
      this.modalLoadTable();
      this.modalOption.className = "modal-site-detail";
      this.modalOption.key = "useDetail";
      this.modalOption.title = `${sieteName}·使用详情`;
    },
    modalLoadTable() {
      this.$axios
        .post("/api/site/detailList", this.useDetailQuery)
        .then(res => {
          let data = res.data.data;
          // 是否有数据
          if (data.total === 0) {
            this.$Message.info("此场地暂未使用");
            return;
          }
          if (!Array.isArray(data.list)) {
            this.$log.INFO("场地使用详情列表数据获取失败");
            return;
          }
          this.useDetailPageInfo = data.list;
          this.modalMsgCount = data.total;
          this.modalOption.modalVisiabal = true;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // switch 改变事件
    handleSwitch(id, state) {
      this.$axios.put(`/api/site/updateLock/${id}/${state}`).catch(error => {
        this.loadTable();
        console.error(error.message);
      });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/site/siteList", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },

    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool && this.modalOption.key !== "useDetail") {
        // 重置表单状态
        this.clearFormData();
      }
    },
    // 清空表单
    clearFormData() {
      this.$refs.formValidate.resetFields();
      this.site = {
        siteCapacity: "",
        siteCheckinId: 1,
        siteLocation: "",
        siteName: ""
      };
    },
    siteCheckinIdFilter(val) {
      if (typeof val !== "number") {
        console.error("过滤的场地签到设变参数格式错误");
        return "";
      }
      let result = this.signInEquipmentList.find(el => val === el.value);
      if (!result || !result.label) {
        return "";
      }
      return result.label;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>

<style lang="scss" scoped>
.site {
  .detail {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  .unModify {
    text-decoration: underline;
    color: $grey;
  }
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .ivu-switch {
    background-color: $red;
  }
  .ivu-switch-checked {
    background-color: $theme;
  }
}
</style>
<style lang="scss">
.site-form {
  .ivu-form-item {
    &:last-child {
      margin-bottom: 0px;
    }
  }
}
.modal-site-detail {
  .ivu-modal {
    width: 800px !important;
  }
  /deep/ .ivu-select {
    width: auto !important;
  }
}
.modal-site-update {
  .ivu-modal {
    width: 390px !important;
  }
}
.modal-site-update,
.modal-site-detail {
  .ivu-input-wrapper,
  .ivu-select {
    width: 100% !important;
  }
}
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .ivu-date-picker:not(:last-child) {
    margin-right: $left;
  }

  .left-content {
    display: flex;
    flex-wrap: nowrap;
    // max-width: 380px;
    // min-width: 320px;
  }
}
</style>
