<template>
  <div class="courseAduit">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "courseAduit"
};
</script>
