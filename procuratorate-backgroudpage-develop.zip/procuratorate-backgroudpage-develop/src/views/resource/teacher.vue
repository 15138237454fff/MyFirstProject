<template>
  <div class="teacher">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入用户名/姓名"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="handleAdd"
          type="primary"
          v-if="$btnAuthorityTest('teacher:add')"
          >添加</i-button
        >
        <i-button
          size="large"
          @click="clickDelete"
          type="error"
          v-if="$btnAuthorityTest('teacher:delete')"
          >删除</i-button
        >
        <i-button size="large" type="primary" @click="clickOutput" ghost
          >导出</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="option" slot-scope="{ row }">
          <span class="view" @click="viewTecherInfo(row.teacherId)">查看</span>
          <span>&nbsp;|&nbsp;</span>
          <span
            class="modify"
            @click="updateTeacherInfo(row.teacherId, row.userName)"
            v-if="$btnAuthorityTest('teacher:update')"
            >修改</span
          >
        </template>
      </i-table>
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="msgCount"
      ></my-pagination>
      <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
        <div class="modal-content">
          <template
            v-if="modalOption.key === 'add' || modalOption.key === 'update'"
          >
            <table border="1">
              <tr class="fix-empty">
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
                <td class="required">
                  讲师
                </td>
                <td colspan="3">
                  <i-select
                    size="large"
                    v-model="user.userId"
                    filterable
                    remote
                    :loading="searchLoading"
                    @on-change="searchUserChange"
                    v-if="modalOption.key === 'add'"
                  >
                    <i-option
                      v-for="(option, index) in userList"
                      :value="option.userId"
                      :key="index"
                      >{{ option.name }}({{ option.userName }})</i-option
                    >
                  </i-select>
                  <div style="text-align:center;" v-else>
                    {{ user.name }}({{ user.userName }})
                  </div>
                </td>
                <td rowspan="3" style="padding:0;">
                  <div class="btn-icon">
                    <img :src="user.photo" v-if="user.photo" />
                    <div v-else class="img-icon">
                      <i-icon type="md-images" size="40" />
                    </div>
                  </div>
                </td>
              </tr>
              <tr class="get-require">
                <td>性别</td>
                <td>{{ user.sex | sexFilter }}</td>
                <td>所属部门</td>
                <td>
                  <i-tooltip
                    :content="user.deptName"
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ user.deptName }}
                  </i-tooltip>
                </td>
              </tr>
              <tr class="get-require">
                <td>职务</td>
                <td>{{ user.duty }}</td>
                <td>手机号码</td>
                <td>{{ user.mobile }}</td>
              </tr>
              <tr class="get-require">
                <td>电子邮箱</td>
                <td>
                  <i-tooltip
                    :content="user.email"
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ user.email }}
                  </i-tooltip>
                </td>
                <td>身份证号</td>
                <td colspan="2">{{ user.idNumber }}</td>
              </tr>
              <tr class="input-textarea">
                <td>专长</td>
                <td colspan="4">
                  <i-input
                    v-model="teacher.specialty"
                    placeholder="请输入"
                    size="large"
                    type="textarea"
                    :autosize="{ minRows: 2, maxRows: 5 }"
                  ></i-input>
                </td>
              </tr>
              <tr class="input-textarea">
                <td>个人简介</td>
                <td colspan="4">
                  <i-input
                    v-model="teacher.introducation"
                    placeholder="请输入"
                    type="textarea"
                    size="large"
                    :autosize="{ minRows: 2, maxRows: 5 }"
                  ></i-input>
                </td>
              </tr>
            </table>
          </template>
          <template v-if="modalOption.key === 'detail'">
            <table border="1" class="see-detail">
              <tr>
                <td>用户名</td>
                <td>{{ user.userName }}</td>
                <td>姓名</td>
                <td>{{ user.name }}</td>
                <td rowspan="3">
                  <div class="btn-icon">
                    <img :src="user.photo" v-if="user.photo" />
                    <div v-else class="img-icon">
                      <i-icon type="md-images" size="40" />
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <td>性别</td>
                <td>{{ user.sex | sexFilter }}</td>
                <td>所属部门</td>
                <td>
                  <i-tooltip
                    :content="user.deptName"
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ user.deptName }}
                  </i-tooltip>
                </td>
              </tr>
              <tr>
                <td>职务</td>
                <td>{{ user.duty }}</td>
                <td>手机号码</td>
                <td>{{ user.mobile }}</td>
              </tr>
              <tr>
                <td>电子邮箱</td>
                <td>
                  <i-tooltip
                    :content="user.email"
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ user.email }}
                  </i-tooltip>
                </td>
                <td>身份证号</td>
                <td colspan="2">{{ user.idNumber }}</td>
              </tr>
              <tr>
                <td>专长</td>
                <td colspan="4">{{ teacher.specialty }}</td>
              </tr>
              <tr>
                <td>个人简介</td>
                <td colspan="4">
                  <i-tooltip
                    :content="teacher.introducation"
                    :transfer="true"
                    max-width="300px"
                  >
                    {{ teacher.introducation }}
                  </i-tooltip>
                </td>
              </tr>
            </table>
          </template>
        </div>
        <p
          slot="footer"
          v-if="modalOption.key === 'add' || modalOption.key === 'update'"
        >
          <i-button size="large" @click="modalOption.modalVisiabal = false"
            >取消</i-button
          >
          <i-button
            size="large"
            type="primary"
            @click="handleUpdate('formValidate')"
            >保存</i-button
          >
        </p>
      </my-modal>
    </div>
  </div>
</template>
<script>
import {
  Table,
  Input,
  Button,
  Select,
  Option,
  Icon,
  Tooltip
} from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "site",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-icon": Icon,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      loading: false,
      searchLoading: false,
      // 消息总数量
      msgCount: 0,
      // 列表数据
      tableData: [],
      // 查询用户数据
      userList: [],
      // 表单数据
      teacher: {
        introducation: "",
        specialty: "",
        teacherId: ""
      },
      user: {
        photo: null,
        userId: "",
        deptName: "",
        duty: "",
        email: "",
        idNumber: "",
        mobile: "",
        name: "",
        sex: 0,
        userName: ""
      },
      colOption: [
        { type: "selection", width: 50, align: "center" },
        { title: "用户名", align: "center", key: "userName", tooltip: true },
        { title: "姓名", align: "center", key: "name", tooltip: true },
        {
          title: "性别",
          align: "center",
          key: "sex",
          width: 100,
          render: (h, params) => {
            let sex = params.row.sex;
            return h("span", sex === 1 ? "男" : sex === 2 ? "女" : "未知");
          }
        },
        { title: "所属部门", align: "center", key: "deptName", tooltip: true },
        { title: "职务", align: "center", key: "duty" },
        { title: "专长", align: "center", key: "specialty", tooltip: true },
        { title: "操作", align: "center", slot: "option", width: 120 }
      ],
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 查看的对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "添加",
        className: "modal-teacher"
      },
      // 列表选中ID
      selectedHistoryList: [],
      timer: null
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
    // 请求过滤了师资库中用户的用户列表
    this.submitRemoteSearch();
  },
  methods: {
    // 提交修改
    submitUpdate() {
      this.$axios
        .put(`/api/teacher/update`, this.teacher)
        .then(res => {
          this.$Message.success("修改成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 提交保存
    submitSave() {
      let tmpObj = {
        userId: this.user.userId,
        introducation: this.teacher.introducation,
        specialty: this.teacher.specialty
      };
      this.$axios
        .post(`/api/teacher/insert`, tmpObj)
        .then(res => {
          this.$Message.success("添加成功");
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 保存按钮
    handleUpdate() {
      if (this.$isEmpty(this.user.userId)) {
        this.$Message.error("请填写完整的内容!");
        return;
      }
      if (
        this.teacher.introducation &&
        this.teacher.introducation.length > 100
      ) {
        this.$Message.error("个人简介长度不能超过100位");
        return;
      }
      if (this.teacher.specialty && this.teacher.specialty.length > 100) {
        this.$Message.error("个人专长长度不能超过100位");
        return;
      }
      if (this.modalOption.key === "add") {
        this.submitSave();
      } else {
        this.submitUpdate();
      }
    },
    // 查询下拉框改变事件
    searchUserChange(value) {
      this.userList.forEach(element => {
        if (value === element.userId) {
          Object.keys(this.user).forEach(key => {
            this.user[key] = element[key];
          });
        }
      });
    },
    submitRemoteSearch() {
      this.$axios
        .get(`/api/teacher/getUsers`)
        .then(res => {
          this.userList = res.data.data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查看
    viewTecherInfo(teacherId) {
      this.$axios
        .get(`/api/teacher/${teacherId}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.teacher).forEach(key => {
            this.teacher[key] = data[key];
          });
          Object.keys(this.user).forEach(key => {
            if (data[key]) {
              this.user[key] = data[key];
            }
          });
          this.modalOption = {
            className: "modal-teacher",
            modalVisiabal: true,
            title: "详情",
            key: "detail"
          };
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 修改
    updateTeacherInfo(teacherId, userName) {
      this.$axios
        .get(`/api/teacher/${teacherId}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.teacher).forEach(key => {
            this.teacher[key] = data[key];
          });
          Object.keys(this.user).forEach(key => {
            if (data[key]) {
              this.user[key] = data[key];
            }
          });
          this.modalOption = {
            className: "modal-teacher",
            modalVisiabal: true,
            title: "修改",
            key: "update"
          };
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 添加按钮
    handleAdd() {
      this.modalOption = {
        className: "modal-teacher",
        modalVisiabal: true,
        title: "添加",
        key: "add"
      };
    },
    // 删除按钮
    clickDelete() {
      if (this.$isEmpty(this.selectedHistoryList)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "删除",
        msg: "确定删除已选记录？",
        modalVisiabal: true,
        handleOk: this.handleDelete
      });
    },
    // 提交删除数据
    handleDelete() {
      this.$axios
        .delete("/api/teacher/delete", { data: this.selectedHistoryList })
        .then(res => {
          this.$Message.success("删除成功");
          this.selectedHistoryList = [];
          // 重新加载列表数据
          this.loadTable();
          // 隐藏Model
          this.$store.commit("skb/updateConfirmModalOption", {
            modalVisiabal: false
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/teacher/teacherList", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    clearForm() {
      this.teacher = {
        introducation: "",
        specialty: "",
        teacherId: ""
      };
      this.user = {
        photo: null,
        userId: "",
        deptName: "",
        duty: "",
        email: "",
        idNumber: "",
        mobile: "",
        name: "",
        sex: 0,
        userName: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        this.clearForm();
      }
    },
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection.map(item => {
        return item.teacherId;
      });
    },
    // 点击导出
    clickOutput() {
      this.$log.INFO("正在导出");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.teacher {
  .modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  .view {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
}
</style>
<style lang="scss">
.myContentHead {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .ivu-date-picker:not(:last-child) {
    margin-right: $left;
  }
  /deep/ .left {
    flex: 2 !important;
  }
  /deep/ .right {
    flex: 1 !important;
  }
  .left-content {
    display: flex;
    flex-wrap: nowrap;
    // max-width: 380px;
    // min-width: 320px;
  }
}
// 模态框内容的样式设置
.modal-teacher {
  .ivu-modal {
    width: 600px !important;
  }
  .see-detail {
    td {
      width: 120px;
      height: 46px;
      text-align: center;
      img {
        width: 100%;
        height: 100%;
        object-fit: contain;
      }
    }
  }
  .modal-content {
    table {
      border: 1px solid #ccc;
      .fix-empty {
        td {
          display: none;
        }
      }
      td {
        width: 120px;
        height: 46px;
        .btn-icon {
          width: 120px;
          height: 138px;
          img {
            width: 100%;
            height: 100%;
            object-fit: contain;
          }
          .img-icon {
            width: 100%;
            height: 100%;
            display: flex;
            color: #999;
            justify-content: center;
            align-items: center;
          }
        }
        .ivu-input-wrapper {
          width: 100% !important;
          height: 46px;
          .ivu-input-large {
            height: 100% !important;
          }
        }
        .ivu-select {
          width: 100% !important;
          height: 100%;
          line-height: 1;
          .ivu-select-placeholder,
          .ivu-select-selected-value {
            line-height: 46px !important;
          }
        }
        .ivu-select-large.ivu-select-multiple,
        .ivu-select-large.ivu-select-single {
          .ivu-select-selection {
            height: 100%;
            & > div,
            .ivu-select-input {
              height: 100%;
            }
          }
        }
      }
      .input-textarea {
        td {
          height: auto;
          .ivu-input-wrapper {
            height: auto;
          }
        }
      }
      .get-require {
        td:not(:first-child):not(:nth-child(3)) {
          text-align: center;
        }
      }
      td:first-child,
      td:nth-child(3) {
        @extend .header-bg;
        padding: 0 $input-top;
        width: 100px;
      }
    }
  }
}
</style>
