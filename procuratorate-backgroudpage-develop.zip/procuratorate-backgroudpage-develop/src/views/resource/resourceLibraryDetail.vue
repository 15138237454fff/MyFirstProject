<template>
  <div class="resourceLibraryDetail">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "resourceLibraryDetail"
};
</script>
<style lang="scss" scoped>
</style>
