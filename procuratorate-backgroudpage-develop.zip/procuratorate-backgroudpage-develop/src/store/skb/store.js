import router from '@/router'
export default {
  state: {
    // 富文本编辑器配置参数
    editorOption: {
      language_url: '/static/tinymce/zh_CN.js',
      language: 'zh_CN',
      skin_url: '/static/tinymce/skins/lightgray',
      height: 630,
      plugins: 'link lists code table colorpicker textcolor wordcount  contextmenu',
      toolbar: 'bold italic underline strikethrough | fontsizeselect | forecolor backcolor | aligncenter aligncenter alignright alignjustify | bullist numlist |outdent indent blockquote | undo redo | link unlink image code | removeformat',
      branding: false
    },
    // 表格高度
    tableHeight: null,
    // 是否登录
    isLogin: false,
    // 确认对话框参数
    confirmModalOption: {
      // 对话框显示状态
      modalVisiabal: false,
      // 标题内容
      title: "",
      // 内容
      msg: "",
      className: "modal-confirm",
      handleOk: () => { }
    },
    // 模块管理传递的参数
    moduleParams: null,
    // 模块管理勾选的记录
    moduleSelectList: [],
    // 文件上传地址
    uploadUrl: "/api/upload",
    // 培训信息发布勾选的记录
    informationSelectHistoryList: [],
    // 当前用户被授权的按钮列表
    btnAuthorityList: [],
    // 分页参数
    limitQuery: {
      pageNum: 1,
      pageSize: 15,
      query: "",
      category: ""
    }
  },
  getters: {
    // 外部获取培训信息发布勾选的记录
    getInformationSelectHistoryList(state) {
      return state.informationSelectHistoryList
    },
    // 外部获取富文本编辑器配置参数
    getEditorOption(state) {
      return state.editorOption
    },
    // 外部获取表格高度
    getTableHeight(state) {
      return state.tableHeight
    },
    // 外部获取登录状态
    getLogin(state) {
      return state.isLogin
    },
    // 外部获取确认对话框参数
    getConfirmModalOption(state) {
      return state.confirmModalOption
    },
    // 外部获取模块管理传递的参数
    getModuleParams(state) {
      return state.moduleParams
    },
    // 外部获取模块管理勾选的记录
    getModuleSelectList(state) {
      return state.moduleSelectList
    },
    // 外部获取上传地址
    getUploadUrl(state) {
      return state.uploadUrl
    },
    // 外部获取当前用户被授权的按钮列表
    getBtnAuthorityList(state) {
      return state.btnAuthorityList
    },
    // 外部获取列表查询参数
    getLimitQuery(state) {
      return state.limitQuery
    }
  },
  mutations: {
    // 更新培训信息发布勾选的记录
    updateInformationSelectHistoryList(state, list) {
      state.informationSelectHistoryList = list
    },
    // 拼接培训信息发布勾选的记录
    concatInformationSelectHistoryList(state, list) {
      state.informationSelectHistoryList = state.informationSelectHistoryList.concat(list)
    },
    // 删除一条培训信息发布勾选的记录
    deleteInformationSelectHistoryList(state, index) {
      state.informationSelectHistoryList.splice(index, 1)
    },
    modifyInformationSelectHistoryListTime(state, obj) {
      let { arr, index, date } = obj
      if (date) {
        state.informationSelectHistoryList[index].trainingDate = date
      }
      if (arr) {
        state.informationSelectHistoryList[index].trainingTimeStart = arr[0];
        state.informationSelectHistoryList[index].trainingTimeEnd = arr[1];
      }
    },
    // 更新表格高度
    updateTableHeight(state) {
      state.tableHeight = document.documentElement.clientHeight - 230
    },
    // 更新登录状态
    updateLogin(state, bool) {
      state.isLogin = bool
      if (!bool) {
        router.push("/login")
      }
    },
    // 更新对话框参数
    updateConfirmModalOption(state, obj) {
      let { modalVisiabal, title, handleOk, msg } = obj
      if (modalVisiabal !== undefined) {
        state.confirmModalOption.modalVisiabal = modalVisiabal
      }
      if (title) {
        state.confirmModalOption.title = title
      }
      if (handleOk) {
        state.confirmModalOption.handleOk = handleOk
      }
      if (msg) {
        state.confirmModalOption.msg = msg
      }
    },
    // 更新模块管理传递的参数
    updateModuleParams(state, obj) {
      state.moduleParams = obj
    },
    // 更新获取模块管理勾选的记录
    updateModuleSelectList(state, arr) {
      state.moduleSelectList = arr
    },
    // 更新获取当前用户被授权的按钮列表
    updateBtnAuthorityList(state, arr) {
      state.btnAuthorityList = arr
    },
    updateLimitQuery(state, obj) {
      let { pageNum, pageSize, query, category } = obj
      if (pageNum) {
        state.limitQuery.pageNum = pageNum
      }
      if (pageSize) {
        state.limitQuery.pageSize = pageSize
      }
      if (query !== undefined) {
        state.limitQuery.query = query
      }
      if (category !== undefined) {
        state.limitQuery.category = category
      }
    }
  },
  actions: {

  },
  namespaced: true
}
