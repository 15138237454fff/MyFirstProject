import Vue from 'vue';
import Router from 'vue-router';
import Index from './views/index.vue';
import store from './store/store';

Vue.use(Router);
const router = new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index,
      redirect: '/home',
      children: [
        {
          path: 'home',
          name: 'home',
          component: () => import('./views/home.vue'),
          meta: {
            title: '首页',
            name: "home"
          }
        },
        {
          path: 'homeNotice',
          name: 'homeNotice',
          component: () => import('./views/notice/homeNotice.vue'),
          meta: {
            title: '首页',
            name: "home"
          }
        },
        {
          path: 'homeNoticeDetail/:id',
          name: 'homeNoticeDetail',
          component: () => import('./views/notice/homeNoticeDetail.vue'),
          meta: {
            title: '首页',
            name: "home"
          },
          props: true
        },
        // 系统管理
        {
          path: 'institution',
          name: 'institution',
          component: () => import('./views/system/institution.vue'),
          meta: {
            title: '组织机构',
            name: 'institution'
          }
        },
        {
          path: 'roles',
          name: 'roles',
          component: () => import('./views/system/roles.vue'),
          meta: {
            title: '角色管理',
            name: 'roles'
          }
        },
        {
          path: 'rolesDetail',
          name: 'rolesDetail',
          component: () => import('./views/system/rolesDetail.vue'),
          redirect: '/rolesDetail/add',
          children: [
            {
              path: 'add',
              name: 'rolesAdd',
              component: () => import('./components/rolesDetail/add.vue'),
              meta: {
                title: '角色管理',
                name: 'roles'
              }
            },
            {
              path: 'see/:id',
              name: 'rolesSee',
              component: () => import('./components/rolesDetail/see.vue'),
              meta: {
                title: '角色管理',
                name: 'roles'
              },
              props: true
            },
            {
              path: 'modify/:id',
              name: 'rolesModify',
              component: () => import('./components/rolesDetail/modify.vue'),
              meta: {
                title: '角色管理',
                name: 'roles'
              },
              props: true
            }
          ]
        },
        {
          path: 'user',
          name: 'user',
          component: () => import('./views/system/user.vue'),
          meta: {
            title: '用户管理',
            name: "user"
          }
        },
        {
          path: 'parameter',
          name: 'parameter',
          component: () => import('./views/system/parameter.vue'),
          meta: {
            title: '参数设置',
            name: "parameter"
          }
        },
        {
          path: 'notice',
          name: 'notice',
          component: () => import('./views/system/notice.vue'),
          meta: {
            title: '通知公告',
            name: "notice"
          }
        },
        {
          path: 'noticeDetail',
          name: 'noticeDetail',
          component: () => import('./views/system/noticeDetail.vue'),
          redirect: '/noticeDetail/add',
          children: [
            {
              path: 'add',
              name: 'noticeAdd',
              component: () => import('./components/noticeDetail/add.vue'),
              meta: {
                title: '通知公告',
                name: "notice"
              }
            },
            {
              path: 'see/:id',
              name: 'noticeSee',
              component: () => import('./components/noticeDetail/see.vue'),
              meta: {
                title: '通知公告',
                name: "notice"
              },
              props: true
            },
            {
              path: 'modify/:id',
              name: 'noticeModify',
              component: () => import('./components/noticeDetail/modify.vue'),
              meta: {
                title: '通知公告',
                name: "notice"
              },
              props: true
            }
          ]
        },
        {
          path: 'module',
          name: 'module',
          component: () => import('./views/system/treeModule.vue'),
          meta: {
            title: '模块管理',
            name: "module"
          }
        },
        {
          path: 'systemlog',
          name: 'systemlog',
          component: () => import('./views/system/systemlog.vue'),
          meta: {
            title: '系统日志',
            name: "systemlog"
          }
        },
        // 培训资源管理
        {
          path: 'site',
          name: 'site',
          component: () => import('./views/resource/site.vue'),
          meta: {
            title: '培训场地',
            name: "site"
          }
        },
        {
          path: 'teacher',
          name: 'teacher',
          component: () => import('./views/resource/teacher.vue'),
          meta: {
            title: '师资库',
            name: "teacher"
          }
        },
        {
          path: 'course',
          name: 'course',
          component: () => import('./views/resource/course.vue'),
          meta: {
            title: '课程库',
            name: "course"
          }
        },
        {
          path: 'courseDetail',
          name: 'courseDetail',
          component: () => import('./views/resource/courseDetail.vue'),
          children: [
            {
              path: 'add',
              name: 'courseDetailAdd',
              component: () => import('./components/courseDetail/detail/add.vue'),
              meta: {
                title: '课程库',
                name: "course"
              }
            },
            {
              path: 'modify/:id',
              name: 'courseDetailModify',
              component: () => import('./components/courseDetail/detail/modify.vue'),
              meta: {
                title: '课程库',
                name: "course"
              },
              props: true
            },
            {
              path: 'see/:id',
              name: 'courseDetailSee',
              component: () => import('./components/courseDetail/detail/see.vue'),
              meta: {
                title: '课程库',
                name: "course"
              },
              props: true
            }
          ]
        },
        {
          path: 'courseAduit',
          name: 'courseAduit',
          component: () => import('./views/resource/courseAduit.vue'),
          children: [
            {
              path: 'see/:id',
              name: 'courseAduitSee',
              component: () => import('./components/courseDetail/aduit/see.vue'),
              meta: {
                title: '课程库',
                name: "course"
              },
              props: true
            },
            {
              path: 'list',
              name: 'courseAduitList',
              component: () => import('./components/courseDetail/aduit/list.vue'),
              meta: {
                title: '课程库',
                name: "course"
              }
            }
          ]
        },
        {
          path: 'caseBase',
          name: 'caseBase',
          component: () => import('./views/resource/caseBase.vue'),
          meta: {
            title: '案例库',
            name: "caseBase"
          }
        },
        {
          path: 'testQuestions',
          name: 'testQuestions',
          component: () => import('./views/resource/testQuestions.vue'),
          meta: {
            title: '试题库',
            name: "testQuestions"
          }
        },
        {
          path: 'testQuestionsDetail',
          name: 'testQuestionsDetail',
          component: () => import('./views/resource/testQuestionsDetail.vue'),
          meta: {
            title: '试题库',
            name: "testQuestions"
          }
        },
        {
          path: 'resourceLibrary',
          name: 'resourceLibrary',
          component: () => import('./views/resource/resourceLibrary.vue'),
          meta: {
            title: '资源库',
            name: "resourceLibrary"
          }
        },
        {
          path: 'resourceLibraryAudit',
          name: 'resourceLibraryAudit',
          component: () => import('./views/resource/resourceLibraryAudit.vue'),
          children: [
            {
              path: 'list',
              name: 'resourceLibraryAuditList',
              component: () => import('./components/resourceLibrary/audit/list.vue'),
              meta: {
                title: '资源库',
                name: "resourceLibrary"
              },
              props: true
            },
            {
              path: 'see/:id',
              name: 'resourceLibraryAuditSee',
              component: () => import('./components/resourceLibrary/audit/see.vue'),
              meta: {
                title: '资源库',
                name: "resourceLibrary"
              },
              props: true
            }
          ]
        },
        {
          path: 'resourceLibraryDetail',
          name: 'resourceLibraryDetail',
          component: () => import('./views/resource/resourceLibraryDetail.vue'),
          children: [
            {
              path: 'see/:id',
              name: 'resourceLibraryDetailSee',
              component: () => import('./components/resourceLibrary/detail/see.vue'),
              meta: {
                title: '资源库',
                name: "resourceLibrary"
              },
              props: true
            }
          ]
        },
        {
          path: 'questionnaire',
          name: 'questionnaire',
          component: () => import('./views/resource/questionnaire.vue'),
          meta: {
            title: '评教问卷',
            name: "questionnaire"
          }
        },
        // 培训项目管理
        {
          path: 'courseApply',
          name: 'courseApply',
          component: () => import('./views/project/courseApply.vue'),
          meta: {
            title: '培训课程申请',
            name: "courseApply"
          }
        },
        {
          path: 'informationRelease',
          name: 'informationRelease',
          component: () => import('./views/project/informationRelease.vue'),
          meta: {
            title: '培训信息发布',
            name: "informationRelease"
          }
        },
        {
          path: 'informationUnReleasePublish',
          name: 'informationUnReleasePublish',
          component: () => import('./components/informationReleaseTab/detail/informationUnReleasePublish.vue'),
          meta: {
            title: '培训信息发布',
            name: "informationRelease"
          }
        },
        {
          path: 'informationReleasedDetail/:id',
          name: 'informationReleasedDetail',
          component: () => import('./components/informationReleaseTab/detail/informationReleasedDetail.vue'),
          meta: {
            title: '培训信息发布',
            name: "informationRelease"
          },
          props: true
        },
        {
          path: 'projectSignUp',
          name: 'projectSignUp',
          component: () => import('./views/project/projectSignUp.vue'),
          meta: {
            title: '培训项目报名',
            name: "projectSignUp"
          }
        },
        {
          path: 'onlineSignUp/:projectId/:reduce',
          name: 'onlineSignUp',
          component: () => import('./components/projectSignUpTab/detail/onlineSignUp.vue'),
          meta: {
            title: '培训项目报名',
            name: "projectSignUp"
          },
          props: true
        },
        {
          path: 'signUpDetail/:id/:projectId/:reduce',
          name: 'signUpDetail',
          component: () => import('./components/projectSignUpTab/detail/signUpDetail.vue'),
          meta: {
            title: '培训项目报名',
            name: "projectSignUp"
          },
          props: true
        },
        {
          path: 'signUpModify/:id/:projectId/:reduce/:deptNum',
          name: 'signUpModify',
          component: () => import('./components/projectSignUpTab/detail/signUpModify.vue'),
          meta: {
            title: '培训项目报名',
            name: "projectSignUp"
          },
          props: true
        },
        {
          path: 'projectArrange',
          name: 'projectArrange',
          component: () => import('./views/project/projectArrange.vue'),
          meta: {
            title: '培训项目安排',
            name: "projectArrange"
          }
        },
        {
          path: 'projectArrangeAdd/:projectId/:projectName',
          name: 'projectArrangeAdd',
          component: () => import('./components/projectArrange/arrange/projectArrangeAdd.vue'),
          meta: {
            title: '培训项目安排',
            name: "projectArrange"
          },
          props: true
        },
        {
          path: 'projectArrangeDetail/:projectId/:projectName',
          name: 'projectArrangeDetail',
          component: () => import('./components/projectArrange/arrange/projectArrangeDetail.vue'),
          meta: {
            title: '培训项目安排',
            name: "projectArrange"
          },
          props: true
        },
        {
          path: 'projectArrangeModify/:projectId/:projectName',
          name: 'projectArrangeModify',
          component: () => import('./components/projectArrange/arrange/projectArrangeModify.vue'),
          meta: {
            title: '培训项目安排',
            name: "projectArrange"
          },
          props: true
        },
        {
          path: 'detailRosterList/:projectId/:projectName/:projectStatus',
          name: 'detailRosterList',
          component: () => import('./components/projectArrange/roster/detailRosterList.vue'),
          meta: {
            title: '培训项目安排',
            name: "projectArrange"
          },
          props: true
        },
        {
          path: 'detailRosterModify/:projectId/:projectName',
          name: 'detailRosterModify',
          component: () => import('./components/projectArrange/roster/detailRosterModify.vue'),
          meta: {
            title: '培训项目安排',
            name: "projectArrange"
          },
          props: true
        },
        {
          path: 'sceneManage',
          name: 'sceneManage',
          component: () => import('./views/project/sceneManage.vue'),
          meta: {
            title: '培训现场管理',
            name: "sceneManage"
          }
        },
        {
          path: 'briefSummary',
          name: 'briefSummary',
          component: () => import('./views/project/briefSummary.vue'),
          meta: {
            title: '培训小结汇总',
            name: "briefSummary"
          }
        },
        {
          path: 'briefSummaryDetail/:id',
          name: 'briefSummaryDetail',
          component: () => import('./components/briefSummary/briefSummaryDetail.vue'),
          meta: {
            title: '培训小结汇总',
            name: "briefSummary"
          },
          props: true
        },
        // 学员考勤管理
        {
          path: 'comeOut',
          name: 'comeOut',
          component: () => import('./views/attendance/comeOut.vue'),
          meta: {
            title: '学员出入管理',
            name: "comeOut"
          }
        },
        {
          path: 'signIn',
          name: 'signIn',
          component: () => import('./views/attendance/signIn.vue'),
          meta: {
            title: '学员签到管理',
            name: "signIn"
          }
        },
        {
          path: 'leaveAduit',
          name: 'leaveAduit',
          component: () => import('./views/attendance/leaveAduit.vue'),
          meta: {
            title: '学员请假审核',
            name: "leaveAduit"
          }
        },
        {
          path: 'leaveSummary',
          name: 'leaveSummary',
          component: () => import('./views/attendance/leaveSummary.vue'),
          meta: {
            title: '学员请假汇总',
            name: "leaveSummary"
          }
        },
        // 食宿管理
        {
          path: 'roomInfo',
          name: 'roomInfo',
          component: () => import('./views/boardLodging/roomInfo.vue'),
          meta: {
            title: '房间信息维护',
            name: "roomInfo"
          }
        },
        {
          path: 'roomDistribution',
          name: 'roomDistribution',
          component: () => import('./views/boardLodging/roomDistribution.vue'),
          meta: {
            title: '住宿分配',
            name: "roomDistribution"
          }
        },
        {
          path: 'roomInfoQuery',
          name: 'roomInfoQuery',
          component: () => import('./views/boardLodging/roomInfoQuery.vue'),
          meta: {
            title: '住宿信息查询',
            name: "roomInfoQuery"
          }
        },
        {
          path: 'eatInfoStatistics',
          name: 'eatInfoStatistics',
          component: () => import('./views/boardLodging/eatInfoStatistics.vue'),
          meta: {
            title: '就餐信息统计',
            name: "eatInfoStatistics"
          }
        },
        // 教学用具管理
        {
          path: 'toolInfo',
          name: 'toolInfo',
          component: () => import('./views/tool/toolInfo.vue'),
          meta: {
            title: '用具信息维护',
            name: "toolInfo"
          }
        },
        {
          path: 'toolReceive',
          name: 'toolReceive',
          component: () => import('./views/tool/toolReceive.vue'),
          meta: {
            title: '教学用具领取',
            name: "toolReceive"
          }
        },
        {
          path: 'toolReturn',
          name: 'toolReturn',
          component: () => import('./views/tool/toolReturn.vue'),
          meta: {
            title: '教学用具归还',
            name: "toolReturn"
          }
        },
        // 车辆调度管理
        {
          path: 'carInfo',
          name: 'carInfo',
          component: () => import('./views/vrp/carInfo.vue'),
          meta: {
            title: '车辆信息维护',
            name: "carInfo"
          }
        },
        {
          path: 'vehicleArrangement',
          name: 'vehicleArrangement',
          component: () => import('./views/vrp/vehicleArrangement.vue'),
          meta: {
            title: '车辆使用安排',
            name: "vehicleArrangement"
          }
        },
        {
          path: 'vehicleReturn',
          name: 'vehicleReturn',
          component: () => import('./views/vrp/vehicleReturn.vue'),
          meta: {
            title: '车辆返回登记',
            name: "vehicleReturn"
          }
        }
      ]
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('./views/login/login.vue')
    },
    {
      path: '/forget',
      name: 'forget',
      component: () => import('./views/login/forget.vue')
    }
  ]
});
// 可以拦截登录，如果未登陆，则重定向到'/login'页面
router.beforeEach((to, from, next) => {
  let isLogin = store.getters['skb/getLogin'];
  if (to.path !== '/login' && to.path !== '/forget' && !isLogin) {
    next('/login');
  } else if ((to.path === '/login' || to.path === '/forget') && isLogin) {
    next(from.path);
  } else {
    next();
  }
});
export default router;
