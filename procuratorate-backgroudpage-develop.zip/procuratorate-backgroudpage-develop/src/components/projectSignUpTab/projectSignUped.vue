<template>
  <div class="projectSignUped">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训项目名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        :row-class-name="rowClassName"
      >
        <template slot-scope="{ row }" slot="projectStatus">
          <span
            :class="row.projectStatus | projectStatusFilter('class')"
            v-if="row.projectStatus !== 4006"
            >{{ row.projectStatus | projectStatusFilter("value") }}</span
          >
          <i-tooltip :max-width="450" v-else :content="row.cancelReason"
            >{{ row.projectStatus | projectStatusFilter("value") }}
          </i-tooltip>
        </template>
        <template slot-scope="{ row }" slot="action">
          <span
            @click="
              clickToSee(
                row.projectId,
                row.id,
                row.memberLimit - row.memberActual
              )
            "
            class="to-see"
            >查看</span
          >
          <template v-if="row.isWriteable">
            <span v-if="$btnAuthorityTest('register:update')"
              >&nbsp;|&nbsp;</span
            >
            <span
              @click="
                clickToModify(
                  row.projectId,
                  row.id,
                  row.memberLimit - row.memberActual,
                  row.deptNum
                )
              "
              class="to-modify"
              v-if="$btnAuthorityTest('register:update')"
              >修改</span
            >
            <span v-if="$btnAuthorityTest('register:cancel')"
              >&nbsp;|&nbsp;</span
            >
            <span
              @click="clickToCancel(row.projectId, row.id)"
              class="to-cancel"
              v-if="$btnAuthorityTest('register:cancel')"
              >取消</span
            >
          </template>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>是否取消该培训项目的报名？</p>
        <p class="required">取消原因：</p>
        <i-input
          v-model="formData.content"
          size="large"
          placeholder="请输入"
          type="textarea"
          :autosize="{ minRows: 3, maxRows: 6 }"
        ></i-input>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Table, Input, Button, Tooltip } from "view-design";
import myModal from "@/components/common/myModal";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "projectSignUped",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        {
          title: "剩余名额",
          align: "center",
          width: 100,
          tooltip: true,
          render: (h, params) => {
            let row = params.row;
            return h(
              "span",
              row.remainingPlaces === "" ? "无限制" : row.remainingPlaces
            );
          }
        },
        {
          title: "报名截止时间",
          align: "center",
          key: "deadline",
          width: 200
        },
        {
          title: "报名单位",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "报名时间",
          align: "center",
          key: "registrationTime",
          width: 200
        },
        {
          title: "状态",
          align: "center",
          slot: "projectStatus",
          tooltip: true,
          width: 120
        },
        {
          title: "操作",
          align: "center",
          slot: "action",
          tooltip: true,
          width: 180
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 当前操作id值
      handleId: "",
      // 项目id
      handleProjectId: "",
      formData: {
        // 退回理由
        content: ""
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-project-sign-up-cancel"
      }
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 读取历史的分页数据
    readHistoryLimitQuery() {
      let limitQuery = this.$store.getters["skb/getLimitQuery"];
      this.limitQuery.pageSize = limitQuery.pageSize;
      this.limitQuery.pageNum = limitQuery.pageNum;
      this.limitQuery.query = limitQuery.query;
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/register/registered/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          let now = new Date();
          data.list.forEach(el => {
            if (
              new Date(el.deadline) - now > 0 &&
              (el.projectStatus === 4000 || el.projectStatus === 4002)
            ) {
              el.isWriteable = true;
            } else {
              el.isWriteable = false;
            }
          });
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击查看按钮
    clickToSee(projectId, id, reduce) {
      this.$router.push(`/signUpDetail/${id}/${projectId}/${reduce}`);
    },
    // 点击修改按钮
    clickToModify(projectId, id, reduce, deptNum) {
      this.$router.push(
        `/signUpModify/${id}/${projectId}/${reduce}/${deptNum}`
      );
    },
    // 点击取消按钮
    clickToCancel(projectId, id) {
      // 保存当前取消的Id值
      this.handleId = id;
      this.handleProjectId = projectId;
      this.modalOption.title = "取消报名";
      this.modalOption.modalVisiabal = true;
    },
    // 保存取消报名的操作
    saveCancel() {
      if (this.formData.content === "") {
        this.$Message.error("请填写取消报名理由");
        return;
      }
      this.$axios
        .put("/api/register/cancel", {
          cancellationReasons: this.formData.content,
          id: this.handleId,
          projectId: this.handleProjectId
        })
        .then(res => {
          this.$Message.success("取消报名成功");
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },

    // 点击对话框的确定
    clickOk() {
      // 隐藏模态框
      this.saveCancel();
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 清空表单数据
    clearFormData() {
      this.handleId = "";
      this.handleProjectId = "";
      this.formData = {
        // 退回理由
        content: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    rowClassName(row) {
      if (row.projectStatus === 4006) {
        return "disable";
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 50;
    }
  },
  filters: {
    projectStatusFilter(val, type) {
      if (type === "value") {
        switch (val) {
          case 4000:
            return "已延期";
          case 4002:
            return "未安排";
          case 4003:
          case 4004:
          case 4005:
          case 4007:
            return "已安排";
          case 4006:
            return "已取消";
          default:
            return "";
        }
      } else {
        switch (val) {
          case 4000:
            return "red";
          case 4002:
            return "orange";
          case 4003:
          case 4004:
          case 4005:
          case 4007:
            return "green";
          case 4006:
            return "disable";
          default:
            return "";
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.projectSignUped {
  .online-sign-up {
    color: $theme;
    cursor: pointer;
    text-decoration: underline;
  }
  /deep/ .disable {
    span {
      color: $grey;
    }
  }
  .orange {
    color: $orange;
  }
  .red {
    color: $error;
  }
  .blue {
    color: $blue;
  }
  .green {
    color: $success;
  }
  span.to-see {
    cursor: pointer;
    text-decoration: underline;
    color: $theme;
  }
  span.to-modify {
    cursor: pointer;
    text-decoration: underline;
    color: $orange;
  }
  span.to-cancel {
    cursor: pointer;
    text-decoration: underline;
    color: $error;
  }
}
</style>
<style lang="scss">
.modal-project-sign-up-cancel {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    p {
      line-height: 24px;
      text-align: left;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
