<template>
  <div class="onlineSignUp">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clickSubmit"
          >提交</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="main-left" span="15">
        <div class="margin-bottom-20 row">
          <div class="col">
            <span>培新项目：</span>
            <span>{{ projectDetail.projectName }}</span>
          </div>
          <div class="col">
            <span>培训人数限制：</span>
            <span>{{ projectDetail.memberLimit }}</span>
          </div>
        </div>
        <div class="margin-bottom-20 row">
          <div class="col">
            <span>培训地点：</span>
            <span>{{ projectDetail.trainingLocation }}</span>
          </div>
          <div class="col">
            <span>报名截止时间：</span>
            <span>{{ projectDetail.deadline }}</span>
          </div>
        </div>
        <i-table
          :data="projectDetail.projectPublishClassVOs"
          :columns="colOption"
          :border="true"
          :max-height="tableHeight"
        >
          <template slot-scope="{ row }" slot="trainingTime">
            <i-tooltip
              :transfer="true"
              max-width="300px"
              :content="`${row.trainingTimeStart} ~ ${row.trainingTimeEnd}`"
              >{{ row.trainingTimeStart }} ~
              {{ row.trainingTimeEnd }}</i-tooltip
            >
          </template>
        </i-table>
      </div>
      <div class="main-right" span="9">
        <div>
          <div class="main-right-head">
            填写报名信息
          </div>
          <div class="main-right-content">
            <div class="transfer-title">
              <span>添加培训人员：</span>
              <span
                >剩余名额：<span class="green">{{
                  reduce - transferOptions.connectList.length + historyLength
                }}</span>
              </span>
            </div>
            <div>
              <i-transfer
                :data="transferOptions.userList"
                :target-keys="transferOptions.connectList"
                :list-style="transferOptions.listStyle"
                :operations="['到左边', '到右边']"
                :titles="transferOptions.titles"
                filterable
                @on-change="handleConnectChange"
              ></i-transfer>
            </div>
          </div>
          <div class="main-right-footer">
            <div class="row car-card">
              <span>添加车牌号：</span>
              <i-input
                v-model="carCard"
                placeholder="请输入"
                size="large"
              ></i-input>
              <span @click="addCarCard" class="add">+</span>
            </div>
            <div class="car-card-list">
              <i-tag
                size="large"
                closable
                @on-close="clickCloseTag(index)"
                v-for="(item, index) of formData.plateNumbers"
                :key="index"
                >{{ item }}</i-tag
              >
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {
  Button,
  Icon,
  Table,
  Input,
  Transfer,
  Tag,
  Tooltip
} from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "onlineSignUp",
  props: {
    // 报名Id
    id: {},
    // 项目id
    projectId: {},
    // 之前剩余名额
    reduce: {},
    // 部门代码
    deptNum: {}
  },
  components: {
    "i-table": Table,
    "i-icon": Icon,
    "i-button": Button,
    "i-input": Input,
    "i-transfer": Transfer,
    "i-tooltip": Tooltip,
    "i-tag": Tag,
    "my-content-head": myContentHead
  },
  data() {
    return {
      tableData: [],
      colOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        {
          title: "培训课程",
          align: "center",
          key: "className",
          tooltip: true,
          width: 160
        },
        {
          title: "课程类型",
          align: "center",
          key: "classCategoryId",
          width: 100,
          tooltip: true
        },
        {
          title: "培训时间",
          align: "center",
          slot: "trainingTime"
        }
      ],
      // 项目详情内容
      projectDetail: {
        // 项目名称
        projectName: "",
        // 限制人数
        memberLimit: "",
        // 培训地点
        trainingLocation: "",
        // 截止日期
        deadline: "",
        // 课程列表
        projectPublishClassVOs: []
      },
      historyLength: 0,
      carCard: "",
      // 穿梭框的配置参数
      transferOptions: {
        // 标题列表
        titles: ["待添加", "已添加"],
        // 可以关联的用户列表
        userList: [],
        // 已经关联的用户列表
        connectList: [],
        // 穿梭框样式
        listStyle: {
          width: "179px",
          height: "300px",
          "text-align": "left"
        }
      },
      formData: {
        // 车牌号列表
        plateNumbers: []
      }
    };
  },
  mounted() {
    // 请求项目详细信息
    if (this.projectId) {
      // 请求项目详情
      this.requireProjectDetail();
      // 请求用户列表
      this.requireUserOptions();
    }
    // 回显报名数据
    if (this.id) {
      this.dataCallBack();
    }
  },
  methods: {
    // 返回列表
    goBack() {
      // 清空之前勾选保存的记录
      this.clearFormData();
      // 清空之前勾选保存的记录
      this.$router.push({
        path: "/projectSignUp",
        query: { activeTab: "SignUped" }
      });
    },
    // 数据回显
    dataCallBack() {
      this.$axios
        .get(`/api/register/${this.id}`)
        .then(res => {
          let data = res.data.data;
          if (this.$isEmpty(data)) {
            console.error("报名数据获取失败");
            return false;
          }
          this.formData.plateNumbers = data.plateNumbers;
          this.historyLength = data.trainingStaffs.length;
          this.transferOptions.connectList = data.trainingStaffs.map(el => {
            return el.userId;
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击提交
    clickSubmit() {
      this.$log.INFO("提交");
      // 校验
      if (!this.testForm()) {
        return false;
      }
      let tmpObj = {
        projectId: this.projectId,
        userIds: this.transferOptions.connectList,
        plateNumbers: this.formData.plateNumbers
      };
      this.$axios
        .put(`/api/register/${this.id}`, tmpObj)
        .then(res => {
          this.$Message.success("修改成功");
          // 返回列表
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 校验表单
    testForm() {
      if (this.transferOptions.connectList.length === 0) {
        this.$Message.error("请选择要报名的人员");
        return false;
      }
      return true;
    },
    // 获取项目详细信息
    requireProjectDetail() {
      this.$axios
        .get(`/api/projectPublish/getProjectInfo/${this.projectId}`)
        .then(res => {
          let data = res.data.data;
          if (!data) {
            console.error("项目详情数据获取失败");
            return false;
          }
          Object.keys(this.projectDetail).forEach(key => {
            this.projectDetail[key] = data[key];
          });
          // 过滤课程列表中非法项
          this.projectDetail.projectPublishClassVOs = data.projectPublishClassVOs.filter(
            el => el
          );
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 获取报名人员列表
    requireUserOptions() {
      this.$axios
        .get(`/api/user/select/${this.deptNum}`)
        .then(res => {
          let data = res.data.data;
          if (!data || !Array.isArray(data)) {
            console.error("人员列表数据获取失败");
            return false;
          }
          // 进行数据格式化处理
          this.transferOptions.userList = data.map(el => {
            return {
              key: el.userId,
              label: `${el.name}  ${el.userName}`,
              disabled: false
            };
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 处理关联用户的变化
    handleConnectChange(newTargetKeys, direction, moveKeys) {
      let reduce = this.reduce - newTargetKeys.length + this.historyLength;
      if (reduce < 0) {
        this.$Message.error("报名人数超过剩余人数");
        return;
      }
      this.transferOptions.connectList = newTargetKeys;
    },
    // 添加车牌号
    addCarCard() {
      this.$log.INFO("添加车牌号");
      if (!this.carCard) {
        this.$Message.error("请输入车牌号后再点击添加");
        return;
      }
      if (this.formData.plateNumbers.some(el => el === this.carCard)) {
        this.$Message.error("请勿添加重复车牌");
        return;
      }
      this.$axios
        .get(`/api/register/verify/plateNumber/${this.projectId}`, {
          params: { plateNumber: this.carCard }
        })
        .then(res => {
          let data = res.data.data;
          if (!data) {
            this.formData.plateNumbers.push(this.carCard);
          } else {
            this.$Message.error("车牌被添加过,请勿重复添加");
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击删除一个车牌号
    clickCloseTag(index) {
      this.formData.plateNumbers.splice(index, 1);
    },
    // 清空表单数据
    clearFormData() {
      // 清空表单
      this.formData = {
        plateNumbers: []
      };
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 142;
    }
  }
};
</script>
<style lang="scss" scoped>
.onlineSignUp {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .green {
    color: $theme;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .row {
    display: flex;
    justify-content: space-between;
    & > .col {
      flex: 1;
    }
  }
  .content {
    height: calc(100vh - 184px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    overflow: auto;
    display: flex;
    flex-direction: row;
    .main-left {
      padding: 14px;
      @extend .header-bg;
      margin-right: 14px;
      width: calc(100vw - 776px);
    }
    .main-right {
      width: 488px;
      & > div {
        border: 1px solid $border-color;
      }
      .main-right-head {
        height: $td-height;
        @extend .header-bg;
        padding-left: $top;
        line-height: $td-height;
      }
      .main-right-content {
        padding: $top;
        border-bottom: 1px solid $border-color;
        border-top: 1px solid $border-color;
        height: 400px;
        /deep/ .ivu-input-wrapper {
          width: 100% !important;
        }
        .transfer-title {
          width: 100%;
          display: flex;
          justify-content: space-between;
          height: 44px;
          line-height: 44px;
        }
        /deep/ .ivu-transfer-list-header-count {
          color: $theme;
          &::after {
            content: "人";
          }
        }
      }
      .main-right-footer {
        padding: $top;
        .car-card {
          align-items: center;
          margin-bottom: $top;
          &.row {
            justify-content: flex-start;
          }
        }
        .add {
          margin-left: $top;
          display: block;
          width: 24px;
          height: 24px;
          text-align: center;
          line-height: 24px;
          color: $white;
          border-radius: 50%;
          font-size: 24px;
          background: $theme;
          cursor: pointer;
        }
        .car-card-list {
          padding-left: 6em;
        }
      }
    }
    .margin-bottom-20 {
      margin-bottom: 20px;
    }
  }
}
</style>
