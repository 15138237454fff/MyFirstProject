<template>
  <div class="projectNoSignUp">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训项目名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="action">
          <span
            class="online-sign-up"
            @click="
              clickOnlineSignUp(
                row.projectId,
                row.memberLimit - row.memberActual
              )
            "
            v-if="
              (row.remainingPlaces === '' || row.remainingPlaces > 0) &&
                $btnAuthorityTest('register:apply')
            "
            >在线报名</span
          >
          <span
            v-else-if="$btnAuthorityTest('register:apply')"
            class="disable-online-sign-up"
            >在线报名</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Input, Button } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "projectNoSignUp",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        {
          title: "培训人数限制",
          align: "center",
          // key: "memberLimit",
          width: 140,
          render: (h, params) => {
            let row = params.row;
            return h(
              "span",
              row.memberLimit === "" ? "无限制" : row.memberLimit
            );
          }
        },
        {
          title: "剩余名额",
          align: "center",
          // key: "remainingPlaces",
          width: 100,
          render: (h, params) => {
            let row = params.row;
            return h(
              "span",
              row.remainingPlaces === "" ? "无限制" : row.remainingPlaces
            );
          }
        },
        {
          title: "报名截止时间",
          align: "center",
          key: "deadline",
          width: 200
        },
        {
          title: "发布时间",
          align: "center",
          key: "publishTime",
          width: 200
        },
        {
          title: "发布人",
          align: "center",
          key: "publishUser",
          tooltip: true,
          width: 160
        },
        {
          title: "操作",
          align: "center",
          slot: "action",
          tooltip: true,
          width: 100
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    // 读取历史的分页数据
    readHistoryLimitQuery() {
      let limitQuery = this.$store.getters["skb/getLimitQuery"];
      this.limitQuery.pageSize = limitQuery.pageSize;
      this.limitQuery.pageNum = limitQuery.pageNum;
      this.limitQuery.query = limitQuery.query;
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/register/noSign/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击在线报名按钮
    clickOnlineSignUp(id, reduce) {
      this.$router.push(`/onlineSignUp/${id}/${reduce}`);
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 50;
    }
  }
};
</script>
<style lang="scss" scoped>
.projectNoSignUp {
  .online-sign-up {
    color: $theme;
    cursor: pointer;
    text-decoration: underline;
  }
  .disable-online-sign-up {
    color: $grey;
    text-decoration: underline;
  }
}
</style>
