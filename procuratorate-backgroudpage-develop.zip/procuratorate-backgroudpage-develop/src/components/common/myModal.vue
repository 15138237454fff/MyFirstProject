<template>
  <div class="myModal">
    <i-modal
      :title="title"
      :value="modalVisiabal"
      :class-name="className"
      @on-visible-change="handleVisibleChange"
      :mask-closable="false"
    >
      <slot></slot>
      <p slot="footer">
        <slot name="footer"></slot>
      </p>
    </i-modal>
  </div>
</template>
<script>
import { Modal } from "view-design";
export default {
  name: "myModal",
  props: {
    // 对话框显示状态
    modalVisiabal: { type: Boolean },
    // 标题内容
    title: { type: String },
    // 样式名
    className: { type: String }
  },
  components: {
    "i-modal": Modal
  },
  methods: {
    // 处理可见性改变的事件
    handleVisibleChange(bool) {
      this.$emit("visiableChange", bool);
    }
  }
};
</script>
<style lang="scss" scoped>
/deep/ .ivu-modal-wrap {
  display: flex;
  align-items: center;
  justify-content: center;
  .ivu-modal {
    top: 0;
    min-width: 360px;
  }
  .ivu-modal-header p,
  .ivu-modal-header-inner {
    font-weight: 500;
  }
  .ivu-modal-body {
    padding: $left-padding;
    min-height: 130px;
  }
  .ivu-modal-header {
    padding: 14px 20px;
  }
  .ivu-modal-footer {
    padding: 12px 18px;
    text-align: center;
  }
  .ivu-modal-footer button + button {
    margin-left: 20px;
  }
}
</style>
