<template>
  <div class="modalAddCourse">
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <template v-if="formData.classType === 1">
          <i-form
            :model="formData"
            :label-width="100"
            ref="formValidate"
            :rules="ruleValidate"
          >
            <i-form-item label="申请类型：" required prop="classType">
              <i-radio-group
                v-model="formData.classType"
                size="large"
                @on-change="handleRadioChange"
              >
                <i-radio :label="1">关联已有课程</i-radio>
                <i-radio :label="2">添加新课程</i-radio></i-radio-group
              >
            </i-form-item>
            <i-form-item label="课程类别：" required prop="classCategoryId">
              <i-cascader
                size="large"
                v-model="formData.classCategoryId"
                :data="courseTypeOption"
                @on-change="handleCascaderChange"
              ></i-cascader>
            </i-form-item>
            <i-form-item label="课程名称：" required prop="classId">
              <i-select
                v-model="formData.classId"
                size="large"
                @on-change="handleSelectChange"
              >
                <i-option
                  v-for="(item, index) of courseOption"
                  :key="index"
                  :value="item.value"
                  >{{ item.label }}</i-option
                >
              </i-select>
            </i-form-item>
            <i-form-item label="培训讲师：" prop="noMessage">
              {{ formData.classExternalTeacherName }}
            </i-form-item>
            <i-form-item label="学分：" prop="noMessage">
              {{ formData.classCredit }}
            </i-form-item>
            <i-form-item label="学时：" prop="noMessage">
              <span>{{ formData.classPeriod }}</span>
              <span
                style="color:#aaa;margin-left:5px;"
                v-if="formData.classPeriod"
              >
                时
              </span>
            </i-form-item>
          </i-form>
        </template>
        <template v-else>
          <i-form
            :model="formData"
            :label-width="100"
            ref="formValidate"
            :rules="ruleValidate"
          >
            <i-form-item label="申请类型：" required prop="classType">
              <i-radio-group
                v-model="formData.classType"
                size="large"
                @on-change="handleRadioChange"
              >
                <i-radio :label="1">关联已有课程</i-radio>
                <i-radio :label="2">添加新课程</i-radio></i-radio-group
              >
            </i-form-item>
            <i-form-item label="课程类别：" required prop="classCategoryId">
              <i-cascader
                size="large"
                v-model="formData.classCategoryId"
                :data="courseTypeOption"
              ></i-cascader>
            </i-form-item>
            <i-form-item label="课程名称：" required prop="className">
              <i-input
                v-model="formData.className"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
            <i-form-item
              label="培训讲师："
              required
              prop="classExternalTeacherName"
            >
              <i-input
                v-model="formData.classExternalTeacherName"
                placeholder="请输入"
                size="large"
              ></i-input>
            </i-form-item>
            <i-form-item label="学分：" required prop="classCredit">
              <i-input-number
                v-model="formData.classCredit"
                placeholder="请输入"
                size="large"
                :min="0.5"
              ></i-input-number>
            </i-form-item>
            <i-form-item label="学时：" required prop="classPeriod">
              <i-input-number
                v-model="formData.classPeriod"
                placeholder="请输入"
                size="large"
                :min="0.5"
              ></i-input-number
              ><span style="color:#aaa;margin-left:5px;">时</span>
            </i-form-item>
          </i-form>
        </template>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">提交</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import {
  Input,
  Button,
  Select,
  Option,
  Form,
  FormItem,
  Cascader,
  Radio,
  RadioGroup,
  InputNumber
} from "view-design";
import myModal from "@/components/common/myModal";
export default {
  props: {
    modalOption: { type: Object }
  },
  name: "modalAddCourse",
  components: {
    "i-input": Input,
    "i-button": Button,
    "i-radio": Radio,
    "i-radio-group": RadioGroup,
    "i-select": Select,
    "i-option": Option,
    "i-cascader": Cascader,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-input-number": InputNumber,
    "my-modal": myModal
  },
  data() {
    return {
      // 课程类别参数id
      parameterID: "XP-001",
      // 课程类别可选列表
      courseTypeOption: [],
      // 课程可选列表
      courseOption: [], // 待提交的表单数据
      formData: {
        // 申请课程已有：1 新课程：2
        classType: 1,
        // 课程类别
        classCategoryId: [],
        // 学分
        classCredit: null,
        // 讲师姓名
        classExternalTeacherName: "",
        // 讲师类型
        classTeacherType: "",
        // 内部讲师列表
        teacherInfoVOS: [],
        // 课程名称
        className: "",
        // 课程id
        classId: "",
        // 学时
        classPeriod: null
      },
      // 表单校验规则
      ruleValidate: {
        classType: [],
        classCategoryId: [
          {
            type: "array",
            required: true,
            message: "课程类型不能为空"
          }
        ],
        classExternalTeacherName: [
          {
            required: true,
            message: "培训讲师不能为空"
          }
        ],
        className: [
          {
            required: true,
            message: "课程名称不能为空"
          }
        ],
        classId: [
          {
            required: true,
            message: "课程名称不能为空"
          }
        ],
        classCredit: [
          {
            type: "number",
            message: "请输入数字"
          },
          {
            required: true,
            message: "学分不能为空"
          }
        ],
        classPeriod: [
          {
            type: "number",
            message: "请输入数字"
          },
          {
            required: true,
            message: "学时不能为空"
          }
        ]
      }
    };
  },
  mounted() {
    // 请求课程类别下拉框数据
    this.requireCourseTypeOption();
  },
  methods: {
    // 保存申请课程
    saveApply() {
      if (this.formData.classType === 1) {
        // 关联课程
        this.connectCourse();
      } else {
        // 新课程
        this.createCourse();
      }
    },
    // 创建新课程
    createCourse() {
      let {
        classCategoryId,
        classCredit,
        classExternalTeacherName,
        className,
        classPeriod
      } = this.formData;
      classCategoryId = classCategoryId[classCategoryId.length - 1];
      let tmpObj = {
        classCategoryId,
        classCredit,
        classExternalTeacherName,
        className,
        classPeriod
      };
      this.$axios
        .post("/api/projectPublish/classCreate", tmpObj)
        .then(res => {
          let data = res.data.data;
          this.$Message.success("新课程成功保存到课程库");
          this.$emit("fatherVisiableChange", false);
          // 保存的数据格式
          let tmpArr = [
            {
              classId: data,
              className,
              classCategoryId,
              trainingTimeStart: "",
              trainingTimeEnd: "",
              trainingDate: "",
              classTeacherType: 1,
              classExternalTeacherName,
              isNeedCar: 0,
              isNeedCheckin: 0,
              isNeedExam: 0,
              isNeedTools: 0,
              carUseMember: null,
              loading: false,
              toolsApplyDTOS: [{ toolId: "", toolUnit: "", useNumber: null }]
            }
          ];
          // 保存勾选的记录到vuex中
          this.$store.commit("skb/concatInformationSelectHistoryList", tmpArr);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 关联已有课程
    connectCourse() {
      let {
          classId,
          className,
          classCategoryId,
          classTeacherType,
          teacherInfoVOS,
          classExternalTeacherName
        } = this.formData,
        tmpArr = [];
      tmpArr = [
        {
          classId,
          className,
          classCategoryId: classCategoryId[classCategoryId.length - 1],
          trainingTimeStart: "",
          trainingTimeEnd: "",
          trainingDate: "",
          classTeacherType,
          teachers: teacherInfoVOS.map(el => {
            return { value: el.teacherId, label: el.name };
          }),
          classExternalTeacherName,
          isNeedCar: 0,
          isNeedCheckin: 0,
          isNeedExam: 0,
          isNeedTools: 0,
          carUseMember: null,
          loading: false,
          toolsApplyDTOS: [{ toolId: "", useNumber: null }]
        }
      ];
      // 保存勾选的记录到vuex中
      this.$store.commit("skb/concatInformationSelectHistoryList", tmpArr);
      this.$emit("fatherVisiableChange", false);
    },
    // 表单验证
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    // 对话框确认的处理方法
    clickOk() {
      // 获取表单验证结果
      let sign = this.testForm();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      this.saveApply();
    },
    // 点击取消
    clickCancel() {
      this.$emit("fatherVisiableChange", false);
    },
    // 请求课程类型参数的待选列表
    requireCourseTypeOption() {
      this.$axios
        .get(`/api/param/${this.parameterID}`)
        .then(res => {
          let data = res.data.data;
          if (!data || !Array.isArray(data.content)) {
            console.error("课程类别参数获取失败");
            return false;
          }
          // 数据格式化
          data.content = data.content.map(el => {
            return { label: el.title, value: el.title };
          });
          this.courseTypeOption = data.content;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 清空表单数据
    clearFormData() {
      // 清空表单
      this.$refs.formValidate.resetFields();
      this.formData = {
        classType: 1,
        // 课程类别
        classCategoryId: [],
        // 学分
        classCredit: null,
        // 讲师姓名
        classExternalTeacherName: "",
        // 讲师类型
        classTeacherType: "",
        // 内部讲师列表
        teacherInfoVOS: [],
        // 课程名称
        className: "",
        // 课程id
        classId: "",
        // 学时
        classPeriod: null
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.$emit("fatherVisiableChange", bool);
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 级联选择器选择值改变的处理方法
    handleCascaderChange(val) {
      let id = val[val.length - 1];
      this.$axios
        .get(`/api/projectClass/getClasses/${id}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("课程列表获取失败");
            return false;
          }
          this.courseOption = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 选择器选择值改变的处理方法
    handleSelectChange() {
      if (!this.formData.classId) {
        return;
      }
      this.formData.className = this.$getListValue(
        this.formData.classId,
        this.courseOption
      );
      this.$axios
        .get(`/api/class/${this.formData.classId}`)
        .then(res => {
          let data = res.data.data;
          this.formData.classPeriod = data.classPeriod;
          this.formData.classCredit = data.classCredit;
          this.formData.teacherInfoVOS = data.teacherInfoVOS;
          this.formData.classTeacherType = data.classTeacherType;
          if (data.teacherInfoVOS.length === 0) {
            this.formData.classExternalTeacherName =
              data.classExternalTeacherName;
          } else {
            this.formData.classExternalTeacherName = data.teacherInfoVOS
              .map(el => {
                return el ? el.name : "";
              })
              .join(",");
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    handleRadioChange(val) {
      // 清空表单
      this.clearFormData();
      this.formData.classType = val;
    }
  }
};
</script>
<style lang="scss">
.modal-add-course {
  .ivu-modal {
    width: 400px !important;
  }
  .modal-content {
    .ivu-input-wrapper,
    .ivu-select,
    .ivu-cascader {
      width: 240px !important;
    }
  }
}
</style>
