<template>
  <div class="myHeader">
    <div class="logo">
      <img :src="imgUrl" />
    </div>
    <div class="title">
      <span>综合教育培训管理系统</span>
    </div>
    <div class="btn-area">
      <div @click="clickUserCenter">
        <i-icon type="ios-person" :size="24" />
      </div>
      <div @click="clickUserCenter">个人中心</div>
      <div @click="clickModifyPassword">
        <i-icon type="ios-lock" :size="24" />
      </div>
      <div @click="clickModifyPassword">修改密码</div>
      <div @click="clickLogout">
        <i-icon type="ios-log-out" :size="24" />
      </div>
      <div @click="clickLogout">退出</div>
    </div>
    <my-modal
      v-bind="ConfirmModalOption"
      @visiableChange="handleConfirmVisiableChange"
    >
      <div class="modal-content">
        <p>{{ ConfirmModalOption.msg }}</p>
      </div>
      <p slot="footer">
        <i-button size="large" @click="handleCancel">取消</i-button>
        <i-button
          size="large"
          type="primary"
          @click="ConfirmModalOption.handleOk"
          >确定</i-button
        >
      </p>
    </my-modal>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <template v-if="modalOption.key === 'modifyPassword'">
        <div class="modal-content">
          <i-form
            :model="formDataForPassword"
            :label-width="100"
            ref="formValidateForPassword"
            :rules="ruleValidate"
          >
            <i-form-item label="原密码：" required prop="passWord">
              <i-input
                placeholder="请输入"
                size="large"
                v-model="formDataForPassword.passWord"
                password
                type="password"
              ></i-input>
            </i-form-item>
            <i-form-item
              label="新密码："
              required
              prop="newPassWord"
              class="new-password"
            >
              <i-input
                placeholder="请输入"
                size="large"
                v-model="formDataForPassword.newPassWord"
                password
                type="password"
              ></i-input>
            </i-form-item>
            <i-form-item label="确认密码：" required prop="confirmPassWord">
              <i-input
                placeholder="请输入"
                size="large"
                v-model="formDataForPassword.confirmPassWord"
                password
                type="password"
              ></i-input>
            </i-form-item>
          </i-form>
        </div>
        <p slot="footer">
          <i-button size="large" @click="clickCancel">取消</i-button>
          <i-button size="large" type="primary" @click="clickOk">保存</i-button>
        </p>
      </template>
      <template v-else-if="modalOption.key === 'userCenter'">
        <div class="modal-content">
          <table>
            <tr>
              <td>用户名</td>
              <td>{{ formDataForUser.userName }}</td>
              <td rowspan="4" class="avatar">
                <div>
                  <img :src="formDataForUser.photo" />
                </div>
              </td>
            </tr>
            <tr>
              <td>姓名</td>
              <td>{{ formDataForUser.name }}</td>
            </tr>
            <tr>
              <td>性别</td>
              <td>{{ formDataForUser.sex | sexFilter }}</td>
            </tr>
            <tr>
              <td>职务</td>
              <td>{{ formDataForUser.duty }}</td>
            </tr>
            <tr>
              <td>所属角色</td>
              <td colspan="2">{{ formDataForUser.roleNames }}</td>
            </tr>
            <tr>
              <td>所属部门</td>
              <td colspan="2">{{ formDataForUser.deptName }}</td>
            </tr>
            <tr>
              <td>身份证号</td>
              <td colspan="2">{{ formDataForUser.idNumber }}</td>
            </tr>
            <tr>
              <td>手机号码</td>
              <td colspan="2" class="row">
                <div class="row text-ellipsis">
                  <template v-if="!mobileModify">
                    <div class="text">
                      <span>{{ formDataForUser.mobile }}</span>
                    </div>
                    <div class="btn-area">
                      <i-button
                        size="small"
                        @click="mobileModify = true"
                        class="btn-area"
                        >修改</i-button
                      >
                    </div>
                  </template>
                  <template v-else>
                    <div class="text">
                      <i-input
                        placeholder="请输入"
                        size="large"
                        v-model="formDataForUser.mobile"
                      ></i-input>
                    </div>

                    <div class="btn-area">
                      <i-button
                        type="primary"
                        size="small"
                        @click="clickSaveMobile"
                        >保存</i-button
                      >
                    </div>
                  </template>
                </div>
              </td>
            </tr>
            <tr>
              <td>电子邮箱</td>
              <td colspan="2">
                <div class="row text-ellipsis">
                  <template v-if="!emailModify">
                    <div class="text">
                      <span>{{ formDataForUser.email }}</span>
                    </div>
                    <div class="btn-area">
                      <i-button
                        size="small"
                        @click="emailModify = true"
                        class="btn-area"
                        >修改</i-button
                      >
                    </div>
                  </template>
                  <template v-else>
                    <div class="text">
                      <i-input
                        placeholder="请输入"
                        size="large"
                        v-model="formDataForUser.email"
                      ></i-input>
                    </div>
                    <div class="btn-area">
                      <i-button
                        type="primary"
                        size="small"
                        @click="clickSaveEmail"
                        >保存</i-button
                      >
                    </div>
                  </template>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </template>
    </my-modal>
  </div>
</template>
<script>
import { Icon, Button, Form, FormItem, Input } from "view-design";
import myModal from "@/components/common/myModal";
export default {
  name: "myHeader",
  data() {
    return {
      imgUrl: require("../../assets/images/logo2.png"),
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: ""
      },
      // 密码正则
      passwordReg: /^(?!^(\d+|[a-zA-Z]+|[~!@#$%^&*?]+)$)^[\w~!.@#$%^&*?]{8,16}$/,
      // 手机正则验证
      mobileReg: /^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\d{8}$/,
      // 邮箱正则验证
      emailReg: /^[a-zA-Z0-9][\w.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z.]*[a-zA-Z]$/,
      formDataForPassword: {
        // 原密码
        passWord: "",
        // 新密码
        newPassWord: "",
        // 确认密码
        confirmPassWord: ""
      },
      emailModify: false,
      mobileModify: false,
      formDataForUser: {
        // 所属部门
        deptName: "",
        // 所属部门
        deptNum: "",
        // 职务
        duty: "",
        // 邮箱
        email: "",
        // 身份证号
        idNumber: "",
        // 手机号
        mobile: "",
        // 姓名
        name: "",
        // 照片
        photo: "",
        // 所属角色
        roleIdList: [],
        // 角色名称
        roleNames: "",
        // 性别
        sex: "",
        // 用户ID
        userId: "",
        // 用户名
        userName: ""
      },
      // 表单校验规则
      ruleValidate: {
        passWord: [{ required: true, message: "请输入原密码" }],
        newPassWord: [
          {
            validator: (rule, value, callback) => {
              if (value === "") {
                callback(new Error("请输入密码"));
              } else if (!this.passwordReg.test(value)) {
                callback(new Error("8-16位，包含数字、字母、特殊字符中的2种"));
              } else if (this.formDataForPassword.passWord === value) {
                callback(new Error("新密码不能与原密码相同"));
              } else {
                if (this.formDataForPassword.confirmPassWord !== "") {
                  // 对第二个密码框单独验证
                  this.$refs.formValidateForPassword.validateField(
                    "confirmPassWord"
                  );
                }
                callback();
              }
            }
          }
        ],
        confirmPassWord: [
          {
            validator: (rule, value, callback) => {
              if (value === "") {
                callback(new Error("请再次输入密码"));
              } else if (value !== this.formDataForPassword.newPassWord) {
                callback(new Error("两次密码输入不一致"));
              } else {
                callback();
              }
            }
          }
        ]
      }
    };
  },
  components: {
    "i-icon": Icon,
    "i-button": Button,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-input": Input,
    "my-modal": myModal
  },
  methods: {
    // 点击个人中心
    clickUserCenter() {
      // 查询用户信息
      this.requireUserInfo();
      this.modalOption.title = "个人中心";
      this.modalOption.key = "userCenter";
      this.modalOption.className = "modal-user-center";
      this.modalOption.modalVisiabal = true;
    },
    // 获取用户信息
    requireUserInfo() {
      this.$axios
        .get("/api/center")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data) {
            console.error("用户信息获取失败");
            return false;
          }
          Object.keys(this.formDataForUser).forEach(key => {
            this.formDataForUser[key] = data[key];
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击保存手机号
    clickSaveMobile() {
      let mobile = this.formDataForUser.mobile;
      if (!this.mobileReg.test(mobile)) {
        this.$Message.error("手机格式不正确");
        return;
      }
      this.$axios
        .put(`/api/center/mobile?mobile=${mobile}`)
        .then(res => {
          this.$Message.success("手机修改成功");
          this.mobileModify = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击保存邮箱
    clickSaveEmail() {
      let email = this.formDataForUser.email;
      if (!this.emailReg.test(email)) {
        this.$Message.error("邮箱格式不正确");
        return;
      }
      this.$axios
        .put(`/api/center/email?email=${email}`)
        .then(res => {
          this.$Message.success("邮箱修改成功");
          this.emailModify = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击修改密码
    clickModifyPassword() {
      this.modalOption.title = "修改密码";
      this.modalOption.key = "modifyPassword";
      this.modalOption.className = "modal-modify-password";
      this.modalOption.modalVisiabal = true;
    },
    testFormForPassword() {
      let sign = false;
      this.$refs.formValidateForPassword.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      return sign;
    },
    // 保存修改密码
    handleSaveModifyPassword() {
      console.log("保存密码");
      this.$axios
        .put("/api/center/update/passWord", this.formDataForPassword)
        .then(res => {
          this.$Message.success("修改成功");
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击对话框确认
    clickOk() {
      // 获取表单验证结果
      let sign = this.testFormForPassword();
      // 如果验证未通过，退出
      if (!sign) {
        return;
      }
      this.handleSaveModifyPassword();
    },
    // 点击对话框取消
    clickCancel() {
      this.modalOption.modalVisiabal = false;
    },
    // 点击退出登录
    clickLogout() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "退出登录",
        msg: "是否确定退出登录",
        modalVisiabal: true,
        handleOk: this.handleOk
      });
    },
    // 退出登录
    logout() {
      this.$axios
        .get("/api/login/logout")
        .then(res => {
          // 提示成功
          this.$Message.success("退出登录成功");
          this.$store.commit("skb/updateLogin", false);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 对话框确认的处理方法
    handleOk() {
      // 发送退出登录请求
      this.logout();
      // 隐藏模态框
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 对话框取消的处理方法
    handleCancel() {
      // 隐藏模态框
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 对话框可见性改变的处理方法
    handleConfirmVisiableChange(bool) {
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: bool
      });
    },
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        if (this.modalOption.key === "modifyPassword") {
          this.clearFormDataForPassword();
        } else {
          this.clearFormDataForUserCenter();
        }
      }
    },
    // 清空密码表单
    clearFormDataForPassword() {
      this.formDataForPassword = {
        // 原密码
        passWord: "",
        // 新密码
        newPassWord: "",
        // 确认密码
        confirmPassWord: ""
      };
      this.$refs.formValidateForPassword.resetFields();
    },
    // 清空用户中心表单
    clearFormDataForUserCenter() {
      this.mobileModify = false;
      this.emailModify = false;
    }
  },
  computed: {
    ConfirmModalOption() {
      return this.$store.getters["skb/getConfirmModalOption"];
    }
  }
};
</script>
<style lang="scss" scoped>
.myHeader {
  width: 100%;
  height: $header-height;
  background: $theme;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 40px;
  .logo {
    height: $header-height;
    flex: 1;
    img {
      height: 100%;
    }
  }
  .title {
    font-family: "Arial Negreta", "Arial Normal", "Arial";
    font-weight: 700;
    font-size: 24px;
    color: #fff;
    flex: 1;
    text-align: center;
    line-height: $header-height;
  }
  .btn-area {
    flex: 1;
    text-align: right;
    display: flex;
    color: #fff;
    justify-content: flex-end;
    font-weight: 600;
    line-height: $header-height;
    div {
      cursor: pointer;
      &:nth-child(even) {
        margin-left: 10px;
        font-size: 16px;
        @extend .text-ellipsis;
      }
      &:nth-child(odd) {
        margin-left: 16px;
      }
    }
  }
}
</style>
<style lang="scss">
// 模态框内容的样式设置
.modal-confirm {
  .ivu-modal-body {
    height: 10vh;
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
.modal-user-center {
  .ivu-modal {
    width: 450px !important;
  }
  td {
    padding: 0 10px;
    height: 34px;
    border: 1px solid $border-color;
    .row {
      display: flex;
      flex-wrap: nowrap;
      height: 100%;
      align-items: center;
      .text {
        flex: 1;
        line-height: 34px;
      }
    }
  }
  .avatar {
    padding: 0;
    width: 120px;
    height: 138px;
    & > div {
      width: 120px;
      height: 138px;
    }
    img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
  }
  td:first-child {
    width: 100px;
    @extend .header-bg;
  }
}
.modal-modify-password {
  .ivu-modal {
    width: 380px !important;
  }
}
</style>
