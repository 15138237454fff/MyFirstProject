<template>
  <div class="myContentHead">
    <div class="header">
      <div class="left">
        <slot name="left"></slot>
      </div>
      <div class="right">
        <slot name="right"></slot>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "myContentHead"
};
</script>
<style lang="scss" scoped>
.myContentHead {
  .header {
    width: 100%;
    height: $btn-height;
    margin-bottom: $top;
    display: flex;
    .ivu-input-wrapper {
      margin-right: $left;
    }
    /deep/ .ivu-icon {
      font-size: 16px;
    }
  }
  .left {
    flex: 1;
  }
  .right {
    flex: 2;
    text-align: right;
  }
}
</style>
