<template>
  <div class="mySideBar">
    <!-- 侧边导航 -->
    <!-- <div > -->
    <i-menu
      theme="dark"
      :accordion="isCollapse"
      width="210px"
      ref="side_menu"
      :active-name="'/' + $route.meta.name"
      :open-names="openNames"
    >
      <template v-for="(item, index) of menuList">
        <i-submenu :name="item.menuId" :key="index">
          <template slot="title">
            <!-- <img :src="item.icon" class="icon-img" /> -->
            <i-icon :type="item.icon" size="large" class="icon-img"></i-icon>
            {{ item.menuName }}
          </template>
          <template v-for="(sub, index) of item.children">
            <i-menu-item :name="sub.url" :key="index" :to="sub.url"
              >{{ sub.menuName }}
            </i-menu-item>
          </template>
        </i-submenu>
      </template>
    </i-menu>
  </div>
</template>

<script>
import { Menu, Submenu, MenuItem, Icon } from "view-design";
export default {
  name: "mySideBar",
  data() {
    return {
      isCollapse: true,
      menuList: []
      /* // menuList: [
        //   {
        //     // icon: require("../../assets/icons/sidebar/1.png"),
        //     icon: "ios-settings",
        //     index: "1",
        //     name: "系统管理",
        //     subs: [
        //       {
        //         index: "1-1",
        //         name: "• 组织机构",
        //         path: "/institution"
        //       },
        //       {
        //         index: "1-2",
        //         name: "• 角色管理",
        //         path: "/roles"
        //       },
        //       {
        //         index: "1-3",
        //         name: "• 用户管理",
        //         path: "/user"
        //       },
        //       {
        //         index: "1-4",
        //         name: "• 参数设置",
        //         path: "/parameter"
        //       },
        //       {
        //         index: "1-5",
        //         name: "• 通知公告",
        //         path: "/notice"
        //       },
        //       {
        //         index: "1-6",
        //         name: "• 系统日志",
        //         path: "/systemlog"
        //       },
        //       {
        //         index: "1-7",
        //         name: "• 模块管理",
        //         path: "/module"
        //       }
        //     ]
        //   },
        //   {
        //     // icon: require("../../assets/icons/sidebar/2.png"),
        //     icon: "ios-desktop",
        //     index: "2",
        //     name: "设备接入管理"
        //   },
        //   {
        //     // icon: require("../../assets/icons/sidebar/3.png"),
        //     icon: "ios-folder",
        //     index: "3",
        //     name: "培训资源管理",
        //     subs: [
        //       {
        //         index: "3-1",
        //         name: "• 培训场地",
        //         path: "/site"
        //       },
        //       {
        //         index: "3-2",
        //         name: "• 师资库",
        //         path: "/teacher"
        //       },
        //       {
        //         index: "3-3",
        //         name: "• 课程库",
        //         path: "/course"
        //       },
        //       {
        //         index: "3-4",
        //         name: "• 案例库",
        //         path: "/caseBase"
        //       },
        //       {
        //         index: "3-5",
        //         name: "• 试题库",
        //         path: "/testQuestions"
        //       },
        //       {
        //         index: "3-6",
        //         name: "• 资源库",
        //         path: "/resourceLibrary"
        //       },
        //       {
        //         index: "3-7",
        //         name: "• 评教问卷",
        //         path: "/questionnaire"
        //       }
        //     ]
        //   },
        //   {
        //     icon: "ios-keypad",
        //     index: "4",
        //     name: "培训项目管理",
        //     subs: [
        //       {
        //         index: "4-1",
        //         name: "• 培训课程申请",
        //         path: "/courseApply"
        //       },
        //       {
        //         index: "4-2",
        //         name: "• 培训信息发布",
        //         path: "/informationRelease"
        //       },
        //       {
        //         index: "4-3",
        //         name: "• 培训项目报名",
        //         path: "/projectSignUp"
        //       },
        //       {
        //         index: "4-4",
        //         name: "• 培训项目安排",
        //         path: "/projectArrange"
        //       },
        //       {
        //         index: "4-5",
        //         name: "• 培训现场管理",
        //         path: "/sceneManage"
        //       },
        //       {
        //         index: "4-6",
        //         name: "• 培训小结汇总",
        //         path: "/briefSummary"
        //       }
        //     ]
        //   },
        //   {
        //     icon: "ios-calendar",
        //     index: "5",
        //     name: "学员考勤管理",
        //     subs: [
        //       {
        //         index: "5-1",
        //         name: "• 学员出入管理",
        //         path: "/comeOut"
        //       },
        //       {
        //         index: "5-2",
        //         name: "• 学员签到管理",
        //         path: "/signIn"
        //       },
        //       {
        //         index: "5-3",
        //         name: "• 学员请假审核",
        //         path: "/leaveAduit"
        //       },
        //       {
        //         index: "5-4",
        //         name: "• 学员请假汇总",
        //         path: "/leaveSummary"
        //       }
        //     ]
        //   },
        //   {
        //     icon: "ios-home",
        //     index: "6",
        //     name: "食宿管理",
        //     subs: [
        //       {
        //         index: "6-1",
        //         name: "• 房间信息维护",
        //         path: "/roomInfo"
        //       },
        //       {
        //         index: "6-2",
        //         name: "• 住宿分配",
        //         path: "/roomDistribution"
        //       },
        //       {
        //         index: "6-3",
        //         name: "• 住宿信息查询",
        //         path: "/roomInfoQuery"
        //       },
        //       {
        //         index: "6-4",
        //         name: "• 就餐信息统计",
        //         path: "/eatInfoStatistics"
        //       }
        //     ]
        //   },
        //   {
        //     icon: "ios-color-wand",
        //     index: "7",
        //     name: "教学用具管理",
        //     subs: [
        //       {
        //         index: "7-1",
        //         name: "• 用具信息维护",
        //         path: "/toolInfo"
        //       },
        //       {
        //         index: "7-2",
        //         name: "• 教学用具领取",
        //         path: "/toolReceive"
        //       },
        //       {
        //         index: "7-3",
        //         name: "• 教学用具归还",
        //         path: "/toolReturn"
        //       }
        //     ]
        //   },
        //   {
        //     icon: "ios-calendar",
        //     index: "8",
        //     name: "车辆调度管理",
        //     subs: [
        //       {
        //         index: "8-1",
        //         name: "• 车辆信息维护",
        //         path: "/carInfo"
        //       },
        //       {
        //         index: "8-2",
        //         name: "• 车辆使用安排",
        //         path: "/vehicleArrangement"
        //       },
        //       {
        //         index: "8-3",
        //         name: "• 车辆返回登记",
        //         path: "/vehicleReturn"
        //       }
        //     ]
        //   }
        // ]
      */
    };
  },
  components: {
    "i-menu": Menu,
    "i-submenu": Submenu,
    "i-menu-item": MenuItem,
    "i-icon": Icon
  },
  created() {
    // 请求当前用户的菜单列表
    this.requireMenuList();
    // 请求当前用户被授权的按钮列表
    this.requireBtnList();
  },
  methods: {
    // 请求菜单列表
    requireMenuList() {
      this.$axios
        .get("/api/menu/user")
        .then(res => {
          let data = res.data.data;
          if (!data || !Array.isArray(data)) {
            console.error("用户菜单列表数据获取失败");
            return false;
          }
          this.menuList = data;
          this.initMenu();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求按钮列表
    requireBtnList() {
      this.$axios
        .get("/api/menu/perms")
        .then(res => {
          let data = res.data.data;
          if (!data || !Array.isArray(data)) {
            console.error("用户菜单列表数据获取失败");
            return false;
          }
          // 保存被授权的按钮列表到vuex中
          this.$store.commit("skb/updateBtnAuthorityList", data);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 初始化菜单高亮状态
    initMenu() {
      this.$nextTick(() => {
        this.$refs.side_menu.updateActiveName();
        this.$refs.side_menu.updateOpened();
      });
    }
  },
  computed: {
    // 根据当前路由变化，切换一级菜单
    openNames() {
      if (!this.$route.meta) {
        return [];
      }
      let name = "/" + this.$route.meta.name,
        tmpArr = [];
      this.menuList.forEach(item => {
        if (Array.isArray(item.children)) {
          item.children.forEach(obj => {
            if (obj.url === name) {
              tmpArr = [item.menuId];
            }
          });
        }
      });
      return tmpArr;
    }
  },
  watch: {
    // 路由变化时，实时更新菜单栏高亮状态
    $route() {
      this.initMenu();
    }
  }
};
</script>

<style lang="scss" scoped>
.mySideBar {
  display: block;
  position: absolute;
  left: 0;
  top: $header-height;
  @extend .sider-nav-bg;
  padding-top: 20px;
  bottom: 0;
  overflow-y: scroll;
  overflow-x: hidden;
  color: $success;
  .icon-img {
    font-size: 20px;
    vertical-align: middle;
    margin-right: 7px;
  }
  .ivu-menu-dark {
    @extend .sider-nav-bg;
  }
  .ivu-menu-dark.ivu-menu-vertical {
    /deep/ .ivu-menu-submenu-title {
      &:hover {
        background: $theme !important;
      }
    }
    .ivu-menu-submenu .ivu-menu-item-active {
      &,
      &:hover {
        color: #fff;
        background: $theme !important;
      }
    }
  }
  .ivu-menu-vertical .ivu-menu-submenu .ivu-menu-item {
    padding-left: 52px !important;
  }
  .ivu-menu-dark.ivu-menu-vertical .ivu-menu-opened {
    @extend .sider-nav-bg;
    /deep/ .ivu-menu-submenu-title {
      background: $theme !important;
      color: #fff;
    }
    .ivu-menu-item:hover {
      color: #fff;
      background: $theme !important;
    }
  }
  & > ul {
    height: 100%;
  }
  &::-webkit-scrollbar {
    width: 0;
  }
}
</style>
