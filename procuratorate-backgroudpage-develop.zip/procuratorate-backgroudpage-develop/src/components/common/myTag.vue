<template>
  <!-- 标签导航栏 -->
  <div class="tag-nav">
    <!-- v-if="showTags" -->
    <div class="tags">
      <div
        class="index tags-li"
        :class="{
          active: this.$route.name === 'home'
        }"
        ref="tag0"
      >
        <router-link to="/home" class="tags-li-title">首页</router-link>
      </div>
      <div class="tagsArea" @mousewheel="hualun" ref="tagsArea">
        <ul>
          <template v-for="(item, index) in tagsList">
            <li
              class="tags-li"
              :key="index"
              :class="{
                active: isActive(item.title),
                index: item.title === '首页'
              }"
              v-if="item.title !== '首页'"
              :ref="'tag' + index"
            >
              <router-link :to="item.path" class="tags-li-title">{{
                item.title
              }}</router-link>
              <span
                class="tags-li-icon"
                @click="closeTags(item)"
                v-if="item.title !== '首页'"
              >
                <!-- <i class="ivu-icon ivu-icon-ios-close"></i> -->
                ×
              </span>
            </li>
          </template>
        </ul>
      </div>
      <div class="tags-close-box">
        <i-dropdown
          @on-click="handleTags"
          placement="bottom-end"
          trigger="click"
        >
          <i-button>
            <i-icon type="ios-arrow-down" :size="24" />
          </i-button>
          <i-dropdown-menu slot="list">
            <i-dropdown-item name="other">关闭其它</i-dropdown-item>
            <i-dropdown-item name="all">关闭所有</i-dropdown-item>
          </i-dropdown-menu>
        </i-dropdown>
      </div>
    </div>
  </div>
</template>

<script>
import {
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Button,
  Icon
} from "view-design";
export default {
  name: "",
  data() {
    return {
      tagsList: [{ name: "home", path: "/home", title: "首页" }]
    };
  },

  watch: {
    $route(newValue) {
      this.setTags(newValue);
    }
  },
  created() {
    this.setTags(this.$route);
  },
  components: {
    "i-dropdown": Dropdown,
    "i-dropdown-menu": DropdownMenu,
    "i-dropdown-item": DropdownItem,
    "i-button": Button,
    "i-icon": Icon
  },
  methods: {
    isActive(title) {
      return title === this.$route.meta.title;
    },
    // 关闭单个标签
    closeTags(obj) {
      let index = this.tagsList.indexOf(obj);
      const delItem = this.tagsList.splice(index, 1)[0];
      const item = this.tagsList[index]
        ? this.tagsList[index]
        : this.tagsList[index - 1];
      if (item) {
        // 改为判断路由名字
        delItem.name = this.$route.name && this.$router.push(item.path);
      } else {
        this.$router.push("/home");
      }
    },
    // 关闭所有标签
    closeAll() {
      this.tagsList = [];
      this.$router.push("/home");
    },
    // 关闭其它标签
    closeOther() {
      const curItem = this.tagsList.filter(item => {
        return item.path === this.$route.path;
      });
      this.tagsList = curItem;
    },
    // 设置标签
    setTags(route) {
      if (!route.meta.title) {
        return false;
      }
      const isExist = this.tagsList.some(item => {
        return item.path === route.path;
      });
      let tmpRoute = {
        title: route.meta.title,
        path: route.path,
        name: route.matched[1].components.default.name
      };
      // 如果要设置的标签不存在列表中
      if (!isExist) {
        // 不添加重复名称的标签
        if (
          !this.tagsList.some(el => {
            return el.title === route.meta.title;
          })
        ) {
          this.tagsList.push(tmpRoute);
          // 最新的标签默认显示在最右侧
          this.$nextTick(() => {
            this.$refs.tagsArea.scrollLeft += 150;
          });
        }
      } else {
        let index = this.tagsList.findIndex(el => {
          return el.path === route.path;
        });
        this.$nextTick(() => {
          let tagName = "tag" + index;
          if (index !== 0) {
            this.$refs.tagsArea.scrollLeft = this.$refs[tagName][0].offsetLeft;
          }
        });
      }
    },

    handleTags(command) {
      command === "other" ? this.closeOther() : this.closeAll();
    },
    hualun($event) {
      // 获取滚轮滚动距离
      let deltaY = $event.deltaY;
      // 将距离赋给横向滚动距离
      this.$refs.tagsArea.scrollLeft += deltaY / 4;
    }
  }
};
</script>

<style lang="scss" scoped>
.homeBtn {
  background: none;
  border: none;
  outline: none;
  cursor: pointer;
}
.ivu-icon {
  font-size: 18px;
}
.tag-nav {
  height: $tab-height;
  padding-left: $sidebar-width;
}
.tags {
  position: relative;
  width: 100%;
  height: $tab-height;
  @extend .header-bg;
  // padding-right: $other-tag-width;
  // border-bottom: 1px solid #cccccc;
  display: flex;
}
.tagsArea {
  width: 100%;
  overflow: hidden;
  overflow-x: auto;
  position: relative;
}
.tags ul {
  box-sizing: border-box;
  height: $tab-height;
  position: absolute;
  left: 0;
  white-space: nowrap;
  z-index: 9;
  // border-bottom: 1px solid #cccccc;
}
.tags-li {
  display: inline-block;
  // margin: 3px 2px 2px 3px;
  min-width: 80px;
  text-align: center;
  border-radius: 3px;
  font-size: 12px;
  overflow: hidden;
  cursor: pointer;
  height: $tab-height;
  @extend .normal-font;
  line-height: $tab-height;
  border: 1px solid #e9eaec;
  @extend .header-bg;
  padding: 0 20px;
  vertical-align: middle;
  color: #666;
  transition: all 0.3s ease-in;
  box-sizing: border-box;
  .ivu-icon {
    line-height: $tab-height;
  }
}
.tags-li.index {
  width: 70px;
  min-width: 70px;
}
.tags-li:not(.active):hover {
  background: #f8f8f8;
}
.tags-li.active {
  background-color: $white;
  border-bottom: 1px solid #fff;
  color: $theme;
  a {
    color: $theme;
  }
}
.tags-li-title {
  float: left;
  max-width: 90px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: #666;
  margin-right: 10px;
}
.tags-close-box {
  box-sizing: border-box;
  position: relative;
  padding-top: 1px;
  text-align: center;
  width: 71px;
  height: $tab-height;
  // line-height: calc($tab-height - 1px);
  line-height: 39px;
  background: #fff;
  border-left: 1px solid #e9eaec;
  z-index: 10;
  /deep/ .ivu-dropdown,
  /deep/ .ivu-btn,
  /deep/ .ivu-dropdown-rel {
    width: 100%;
    height: 100%;
    @extend .header-bg;
    color: #666;
    opacity: 1;
    outline: none;
    border: none;
    padding: 0;
  }
  /deep/ .ivu-select-dropdown {
    width: 100px;
    height: 72px;
    .ivu-dropdown-item:first-child {
      border-bottom: 1px solid #e9eaec;
    }
    .ivu-dropdown-item {
      color: $theme;
    }
  }
}
</style>
