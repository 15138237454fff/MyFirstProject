<template>
  <div class="myPagination pageinationModify">
    <i-page
      show-elevator
      show-sizer
      show-total
      placement="top"
      @on-page-size-change="handleSize"
      @on-change="handleCurrent"
      :current="pageNum"
      :page-size-opts="[15, 30, 50, 100]"
      :page-size="pageSize"
      :total="msgCount"
    ></i-page>
  </div>
</template>
<script>
import { Page } from "view-design";
export default {
  name: "myPagination",
  props: {
    // 当前页
    pageNum: { default: 1 },
    // 页大小
    pageSize: { default: 15 },
    // 总记录数
    msgCount: { default: 0 },
    query: { default: "" },
    category: {}
  },
  components: {
    "i-page": Page
  },
  methods: {
    // 监听页大小变化
    handleSize(val) {
      // 触发父组件监听的事件，请求新数据
      this.$emit("paginate", {
        pageSize: val
      });
    },
    // 监听当前页变化
    handleCurrent(val) {
      // 触发父组件监听的事件，请求新数据
      this.$emit("paginate", {
        pageNum: val
      });
    }
  },
  watch: {
    msgCount(val) {
      let pageNum = this.pageNum;
      while (val < (pageNum - 1) * this.pageSize) {
        pageNum--;
      }
      if (val < (this.pageNum - 1) * this.pageSize) {
        // 触发父组件监听的事件，请求新数据
        this.$emit("paginate", {
          pageNum
        });
      }
    }
  },
  computed: {
    userStatus() {
      return this.$store.getters.getStatus;
    }
  },
  beforeDestroy() {
    if (this.$route.meta.name === this.$route.name) {
      return;
    }
    console.log("保存当前分页信息");
    this.$store.commit("skb/updateLimitQuery", {
      pageNum: this.pageNum,
      pageSize: this.pageSize,
      query: this.query,
      category: this.category
    });
  }
};
</script>
<style lang="scss" scoped>
.myPagination {
  margin-top: $top;
  text-align: center;
  position: fixed;
  left: 0;
  right: 0;
  margin: 0 auto;
  bottom: $top;
  width: 60vw;
  /deep/ .ivu-select {
    width: auto !important;
  }
}
.pageinationModify {
  transform: translateX(120px);
}
</style>
