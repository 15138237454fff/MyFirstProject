<template>
  <div class="courseDetailSee">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <my-course-detail :id="id"></my-course-detail>
    </div>
  </div>
</template>
<script>
import { Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import courseCommonDetail from "@/components/courseDetail/common/detail.vue";
export default {
  name: "courseDetailSee",
  props: {
    id: {}
  },
  components: {
    "i-icon": Icon,
    "my-content-head": myContentHead,
    "my-course-detail": courseCommonDetail
  },
  methods: {
    // 返回列表
    goBack() {
      this.$router.push("/course");
    }
  }
};
</script>
<style lang="scss" scoped>
.courseDetailSee {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    height: calc(100vh - 184px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    overflow: auto;
  }
}
</style>
