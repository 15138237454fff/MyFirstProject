<template>
  <div class="courseAduitSee">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clcikPass">通过</i-button>
        <i-button size="large" type="error" @click="clcikBack">退回</i-button>
      </div>
    </my-content-head>
    <div class="content">
      <my-course-detail :id="id"></my-course-detail>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>是否退回该条记录？</p>
        <p class="required">请输入退回原因：</p>
        <i-input
          v-model="formData.content"
          size="large"
          placeholder="请输入"
          type="textarea"
          :autosize="{ minRows: 3, maxRows: 6 }"
        ></i-input>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Button, Icon, Input } from "view-design";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
import courseCommonDetail from "@/components/courseDetail/common/detail.vue";
export default {
  name: "courseAduitSee",
  props: {
    id: {}
  },
  components: {
    "i-icon": Icon,
    "i-button": Button,
    "i-input": Input,
    "my-content-head": myContentHead,
    "my-modal": myModal,
    "my-course-detail": courseCommonDetail
  },
  data() {
    return {
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-course-aduit-see"
      },
      // 待提交的表单数据
      formData: {
        // 退回理由
        content: ""
      }
    };
  },
  methods: {
    // 返回列表
    goBack() {
      this.$router.push("/courseAduit/list");
    },
    // 点击通过
    clcikPass() {
      this.$log.INFO("通过");
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "通过",
        msg: "是否通过该条记录？",
        modalVisiabal: true,
        handleOk: this.handlePass
      });
    },
    // 通过
    handlePass() {
      this.savePass();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存通过的操作
    savePass() {
      let tmpArr = [this.id];
      this.$axios
        .put("/api/class/updateApplyOn", tmpArr)
        .then(res => {
          this.$Message.success("通过成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击退回
    clcikBack() {
      this.$log.INFO("退回");
      this.modalOption.title = "退回";

      this.modalOption.modalVisiabal = true;
    },
    // 保存退回的操作结果
    saveBack() {
      if (this.formData.content === "") {
        this.$Message.error("请填写退回理由");
        return;
      }
      let tmpArr = [{ classId: this.id, reason: this.formData.content }];
      this.$axios
        .put("/api/class/updateApplyOff", tmpArr)
        .then(res => {
          this.$Message.success("退回成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击对话框的确定
    clickOk() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      this.saveBack();
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 退回理由
        content: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.courseAduitSee {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    height: calc(100vh - 184px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    overflow: auto;
  }
}
</style>
<style lang="scss">
.modal-course-aduit-see {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    p {
      line-height: 24px;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
