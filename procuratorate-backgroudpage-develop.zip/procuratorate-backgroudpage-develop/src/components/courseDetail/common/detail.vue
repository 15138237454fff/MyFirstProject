<template>
  <div class="courseCommonDetail">
    <div class="row">
      <span>课程名称：</span>
      <span>{{ showData.className }}</span>
    </div>
    <div class="row">
      <div class="col">
        <span>课程类别：</span>
        <span>{{ showData.classCategoryId }}</span>
      </div>
      <div class="col">
        <span>培训讲师：</span>
        <span style="margin-right:10px;">{{
          showData.classTeacherType === 0
            ? "内部讲师"
            : showData.classTeacherType === 1
            ? "外部讲师"
            : ""
        }}</span>
        <span>{{ showData.teacherName.join("、") }}</span>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <span>学分：</span>
        <span>{{ showData.classCredit }}</span>
      </div>
      <div class="col">
        <span>学时：</span>
        <span class="danwei">{{ showData.classPeriod }}</span>
      </div>
    </div>
    <div class="row">
      <span>课程简介：</span>
      <pre>{{ showData.classIntroduction }}</pre>
    </div>
    <div class="row outline">
      <span>教学大纲：</span>
      <p v-html="showData.classOutline"></p>
    </div>
    <div class="row">
      <span>教学课件：</span>
      <div
        class="attachment"
        v-for="(item, index) of showData.classFileVOS"
        :key="index"
      >
        <a
          :href="item.fileSrc"
          target="_blank"
          class="attachment"
          :download="item.fileName"
          >{{ item.fileName }}</a
        >
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "courseCommonDetail",
  props: {
    id: {}
  },
  data() {
    return {
      // 课程详情数据
      showData: {
        // 课程名称
        className: "",
        // 课程类别
        classCategoryId: "",
        // 培训讲师
        teacherName: [],
        // 讲师类型
        classTeacherType: "",
        // 学分
        classCredit: "",
        // 学时
        classPeriod: "",
        // 课程简介
        classIntroduction: "",
        // 教学大纲
        classOutline: "",
        // 教学课件
        classFileVOS: []
      }
    };
  },
  mounted() {
    // 请求详情数据
    this.requireDetail();
  },
  methods: {
    // 请求课程详情数据
    requireDetail() {
      this.$axios
        .get(`/api/class/${this.id}`)
        .then(res => {
          let data = res.data.data;
          data.teacherName = data.teacherInfoVOS.map(el => el.name);
          if (data.classTeacherType === 1) {
            data.teacherName.push(data.classExternalTeacherName);
          }
          Object.keys(this.showData).forEach(key => {
            this.showData[key] = data[key];
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  }
};
</script>
<style lang="scss" scoped>
.courseCommonDetail {
  display: flex;
  flex-direction: column;
  .row {
    display: flex;
    margin-bottom: $input-top;
    span:first-child {
      display: block;
      width: 80px;
    }
    .col {
      flex: 1;
      display: flex;
      span:first-child {
        width: 80px;
      }
    }
  }
  .outline {
    height: 400px;
    p {
      width: 90%;
      height: 100%;
      overflow: auto;
      padding: $top;
      border: 1px solid $border-color;
    }
  }
  .attachment {
    text-decoration: underline;
    color: $theme;
  }
  .danwei:after {
    content: "时";
    color: $input-color;
    margin-left: 5px;
  }
}
</style>
