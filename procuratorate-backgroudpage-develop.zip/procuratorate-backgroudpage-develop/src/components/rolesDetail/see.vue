<template>
  <div class="rolesModify">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <div class="content-right">
          <span>角色名称：{{ roleName }}</span>
        </div>
      </div>
    </my-content-head>
    <i-tabs v-model="activeTab">
      <i-tab-pane
        v-for="(item, index) of userMenuList"
        :key="index"
        :name="item.menuId"
        :label="item.menuName"
      >
        <div class="content">
          <i-table
            :height="tableHeight"
            :data="tableData"
            :columns="colOption"
            :border="true"
            :loading="loading"
          >
            <template slot-scope="{ row }" slot="action">
              <div class="action-area">
                <div v-for="(item, index) of row.children" :key="index">
                  <span v-if="menuIds.some(el => el === item.menuId)">{{
                    item.menuName
                  }}</span>
                </div>
              </div>
            </template>
          </i-table>
        </div>
      </i-tab-pane>
    </i-tabs>
  </div>
</template>
<script>
import { Tabs, TabPane, Icon, Table } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "rolesModify",
  components: {
    "i-tabs": Tabs,
    "i-tab-pane": TabPane,
    "i-icon": Icon,
    "i-table": Table,
    "my-content-head": myContentHead
  },
  props: {
    // 角色id
    id: {}
  },
  data() {
    return {
      // 用户菜单列表
      userMenuList: [],
      colOption: [
        { title: "功能模块", align: "center", key: "menuName", tooltip: true },
        {
          title: "操作按钮",
          align: "center",
          width: 800,
          slot: "action"
        }
      ],
      // 选中的二级菜单
      selectHistory: [],
      activeTab: "",
      // 按钮id
      menuIds: [],
      loading: false,
      roleName: ""
    };
  },
  mounted() {
    // 请求角色菜单详情
    this.requireRoleMenuDetail();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/roles");
    },
    // 请求角色菜单的方法
    requireRoleMenu() {
      this.loading = true;
      this.$axios
        .get("/api/menu/user/role")
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          // 获取的数据格式验证
          if (!Array.isArray(data)) {
            console.error("用户菜单数据格式不正确");
            return false;
          }
          // 保存用户菜单列表
          this.userMenuList = data;
          // 设置默认tab页
          this.activeTab = data[0].menuId;
          let tmpArr = [];
          // 选取勾选的二级菜单数据
          this.selectHistory.forEach(el => {
            this.userMenuList.forEach(obj => {
              if (!obj.children) {
                return;
              }
              obj.children.forEach((item, index) => {
                if (item.menuId === el) {
                  item.index = index;
                  tmpArr.push(item);
                }
              });
            });
          });
          // 保存勾选的二级菜单
          this.selectHistory = tmpArr;
        })
        .catch(error => {
          this.loading = false;
          console.error(error.message);
        });
    },
    // 请求角色菜单详情
    requireRoleMenuDetail() {
      this.$axios
        .get(`/api/role/${this.id}`)
        .then(res => {
          let data = res.data.data;
          // 非空验证
          if (!data) {
            console.error("获取角色菜单详情数据失败");
            return false;
          }
          // 保存角色名
          this.roleName = data.roleName;
          // 保存勾选的菜单id列表
          let tmpArr = data.menuIds;
          // 保存按钮id列表
          this.menuIds = tmpArr.filter(el => el.length === 6);
          // 保存二级菜单id列表
          this.selectHistory = tmpArr.filter(el => el.length === 4);
          this.requireRoleMenu();
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    tableData() {
      // 取出当前tab页对应的数据
      let tmpArr = this.selectHistory.filter(
        el => el.parentId === this.activeTab
      );
      if (tmpArr) {
        return tmpArr;
      } else {
        return [];
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.rolesModify {
  .ivu-checkbox-group {
    text-align: left;
  }
  /deep/ td.ivu-table-column-center {
    .ivu-checkbox-wrapper {
      margin-right: 16px;
      span {
        margin-right: 5px;
      }
    }
  }
  .action-area {
    text-align: left;
    display: flex;
    justify-content: flex-start;
    & > div:first-child {
      margin-left: 12px;
    }
    & > div:not(:first-child) {
      margin-left: 30px;
    }
  }
  .content-left {
    height: 100%;
    line-height: $btn-height;
  }
  .content-right {
    height: 100%;
    line-height: $btn-height;
    font-size: 14px;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  /deep/ .ivu-input-wrapper {
    width: 200px;
  }
}
</style>
