<template>
  <div class="rolesAdd">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <span class="required">角色名称：</span>
        <i-input placeholder="请输入" size="large" v-model="roleName"></i-input>
        <i-button size="large" type="primary" @click="handleSave"
          >保存</i-button
        >
      </div>
    </my-content-head>
    <i-tabs v-model="activeTab">
      <i-tab-pane
        v-for="(item, index) of userMenuList"
        :key="index"
        :name="item.menuId"
        :label="item.menuName"
      >
        <div class="content">
          <i-table
            :height="tableHeight"
            :data="tableData"
            :columns="colOption"
            :border="true"
            :loading="loading"
          >
            <template slot-scope="{ row, index }" slot="selection">
              <i-check-box
                :key="index"
                label=""
                :value="row.selected"
                @on-change="handleTwoSelectChange($event, index)"
              ></i-check-box>
            </template>
            <template slot-scope="{ row, index }" slot="action">
              <div class="btn-area">
                <i-check-box
                  @on-change="handleBtnSelectChange($event, index, ind)"
                  v-model="item.selected"
                  :label="item.menuId"
                  v-for="(item, ind) of row.children"
                  :key="item.menuId"
                  >{{ item.menuName }}</i-check-box
                >
              </div>
            </template>
          </i-table>
        </div>
      </i-tab-pane>
    </i-tabs>
  </div>
</template>
<script>
import { Tabs, TabPane, Icon, Input, Button, Table, Checkbox } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "rolesAdd",
  components: {
    "i-tabs": Tabs,
    "i-tab-pane": TabPane,
    "i-input": Input,
    "i-button": Button,
    "i-icon": Icon,
    "i-table": Table,
    "i-check-box": Checkbox,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 用户菜单列表
      userMenuList: [],
      colOption: [
        {
          slot: "selection",
          width: 50,
          align: "center",
          renderHeader: (h, params) => {
            let { selected, indeterminate } = this.selectionAllOption;

            // 列头的多选渲染
            return h(Checkbox, {
              props: {
                disabled: this.tableData.length === 0,
                value: selected,
                indeterminate: indeterminate
              },
              on: {
                "on-change": () => {
                  if (indeterminate) {
                    this.clickAllSelect(true);
                  }
                  if (selected) {
                    this.clickAllSelect(false);
                  }
                  if (!indeterminate && !selected) {
                    this.clickAllSelect(true);
                  }
                }
              }
            });
          }
        },
        { title: "功能模块", align: "center", key: "menuName", tooltip: true },
        {
          title: "操作按钮",
          align: "center",
          width: 800,
          slot: "action"
        }
      ],
      selectHistory: [],
      activeTab: "",
      // 菜单id
      menuIds: [],
      loading: false,
      roleName: ""
    };
  },
  mounted() {
    // 请求用户菜单
    this.requireRoleMenu();
  },
  methods: {
    // 处理保存的方法
    handleSave() {
      this.$log.INFO("正在保存");
      // 验证角色名称非空
      if (this.roleName === "") {
        this.$Message.error("请输入角色名称");
        return false;
      }
      let tmpObj = {},
        menuIds = [];
      this.userMenuList.forEach(item => {
        // 一级菜单的选中情况
        let selected = false;
        if (!Array.isArray(item.children)) {
          return;
        }
        // 遍历二级菜单
        item.children.forEach(obj => {
          if (obj.selected) {
            selected = true;
            menuIds.push(obj.menuId);
          }
          if (!Array.isArray(obj.children)) {
            return;
          }
          // 遍历按钮
          obj.children.forEach(el => {
            if (el.selected) {
              menuIds.push(el.menuId);
            }
          });
        });
        if (selected) {
          menuIds.push(item.menuId);
        }
      });
      tmpObj.roleName = this.roleName;
      tmpObj.menuIds = menuIds;
      this.$axios
        .post("/api/role", tmpObj)
        .then(res => {
          this.$Message.success("添加成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 返回列表方法
    goBack() {
      this.$router.push("/roles");
    },
    // 请求用户菜单的方法
    requireRoleMenu() {
      this.loading = true;
      this.$axios
        .get("/api/menu/user/role")
        .then(res => {
          this.loading = false;
          let data = res.data.data;
          // 获取的数据格式验证
          if (!Array.isArray(data)) {
            console.error("用户菜单数据格式不正确");
            return false;
          }
          data.forEach(obj => {
            // 如果没有一级菜单退出
            if (!obj.children) {
              return;
            }
            // 遍历一级菜单
            obj.children.forEach((item, index) => {
              // 如果一级菜单有历史记录
              // 为一级菜单对象添加一个index属性
              item.index = index;
              item.selected = false;
              // 如果没有二级菜单退出
              if (!item.children) {
                return;
              }
              item.children.forEach((el, index) => {
                el.selected = false;
              });
            });
          });
          this.userMenuList = data;
          this.activeTab = data[0].menuId;
        })
        .catch(error => {
          this.loading = false;
          console.error(error.message);
        });
    },
    // 点击全选框的方法
    clickAllSelect(bool) {
      this.tableData.forEach(obj => {
        obj.selected = bool;
        obj.children &&
          obj.children.forEach(el => {
            el.selected = bool;
          });
      });
    },
    // 勾选二级菜单变化的处理函数
    handleTwoSelectChange(val, index) {
      // 保存变化值
      this.tableData[index].selected = val;
      // 根据当前值给二级菜单下的按钮设置相同的状态
      let childList = this.tableData[index].children;
      if (Array.isArray(childList)) {
        childList.forEach(el => {
          el.selected = val;
        });
      }
    },
    handleBtnSelectChange(val, index, ind) {
      // 保存变化值
      this.tableData[index].children[ind].selected = val;
      // 如果按钮全都未勾选则取消勾选二级菜单
      let childList = this.tableData[index].children;
      this.tableData[index].selected = !childList.every(
        el => el.selected === false
      );
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    },
    tableData() {
      // 取出当前tab页对应的数据
      let tmpArr = this.userMenuList.find(el => el.menuId === this.activeTab);
      if (tmpArr) {
        if (!tmpArr.children) {
          return [];
        }
        return tmpArr.children;
      } else {
        return [];
      }
    },
    // 返回列表全选选中项数据
    selectionAllOption() {
      let selected = false,
        indeterminate = false;
      // 取出当前tab页对应的数据
      let tmpArr = this.userMenuList.find(el => el.menuId === this.activeTab);
      if (tmpArr) {
        // 如果有二级菜单
        if (tmpArr.children) {
          selected = tmpArr.children.every(obj => {
            // 如果有按钮
            if (obj.children) {
              // 都勾选则返回true
              return obj.children.every(el => el.selected);
            } else {
              // 没有按钮，返回二级菜单勾选状态
              return obj.selected;
            }
          });
          indeterminate = tmpArr.children.some(obj => {
            // 如果有按钮
            if (obj.children) {
              // 都勾选则返回true
              return obj.children.some(el => el.selected);
            } else {
              // 没有按钮，返回二级菜单勾选状态
              return obj.selected;
            }
          });
          // 如果都选中了，半勾选状态为false
          if (selected) {
            indeterminate = false;
          }
        } else {
          selected = false;
          indeterminate = false;
        }
      }
      return { selected, indeterminate };
    }
  }
};
</script>
<style lang="scss" scoped>
.rolesAdd {
  .ivu-tabs {
    border-top: 1px solid $border-color;
  }
  /deep/ td.ivu-table-column-center {
    .ivu-checkbox-wrapper {
      margin-right: 16px;
      span {
        margin-right: 5px;
      }
    }
  }
  /deep/ th.ivu-table-column-center {
    .ivu-checkbox-wrapper {
      margin-right: 0px;
    }
  }
  .btn-area {
    text-align: left;
  }
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  /deep/ .ivu-input-wrapper {
    width: 200px;
  }
}
</style>
