<template>
  <div class="resourceLibraryCommonDetail">
    <div class="detail-left">
      <div v-if="isMV">
        <video ref="myVideo" controls class="my-video"></video>
      </div>
      <div v-else class="my-pdf">
        <iframe
          :src="formData.resourceFile.url"
          width="100%"
          height="100%"
          scroll="auto"
          class="iframe"
        ></iframe>
      </div>
    </div>
    <div class="detail-right">
      <div class="row">
        <div>
          <span>资源名称：</span>
        </div>
        <span>{{ formData.resourceName }}</span>
      </div>
      <div class="row">
        <span>资源类别：</span>
        <span>{{ formData.resourceType.join(" / ") }}</span>
      </div>
      <div class="row">
        <span>申请人：</span>
        <span>{{ `${formData.name}(${formData.userName})` }}</span>
      </div>
      <div class="row">
        <span>申请时间：</span>
        <span>{{ $tagTime(formData.createTime, "yyyy.MM.dd") }}</span>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "resourceLibraryCommonDetail",
  props: {
    // 资源id
    id: {}
  },
  components: {},
  mounted() {
    // 获取详情数据
    this.callBack();
  },
  data() {
    return {
      formData: {
        // 申请时间
        createTime: "",
        // 上传人
        userName: "",
        // 文件
        resourceFile: { fileName: "", url: "" },
        // 资源文件类型
        resourceFileType: "",
        // 资源名称
        resourceName: "",
        // 资源类别
        resourceType: [],
        // 访问量
        visits: "",
        name: ""
      },
      isMV: false,
      // mvList:['rm','rmvb','mpeg1-4','mov','mtv', 'dat' ,'wmv','avi','3gp','amv','dmv','flv','mkv','mp4'],
      wordList: ["pdf", "doc", "docx"]
    };
  },
  methods: {
    // 根据资源id回显数据
    callBack() {
      this.$axios
        .get(`/api/library/${this.id}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.isMV = !this.wordList.includes(
            data.resourceFileType.toLowerCase()
          );
          // 如果是视频资源
          if (this.isMV) {
            this.playVideo(data.resourceFile.url);
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    playVideo(url) {
      this.$nextTick(() => {
        let vdo = this.$refs.myVideo;
        vdo.src = url;
      });
    }
  },
  computed: {}
};
</script>
<style lang="scss" scoped>
.resourceLibraryCommonDetail {
  padding: 10px 10px 0;
  display: flex;
  height: calc(100vh - 184px);
  .detail-left {
    flex: 1;
    height: 100%;
    padding-right: 10px;
    .my-video {
      width: 100%;
      background: #000;
      border: 1px solid #ccc;
      height: calc(100vh - 200px);
    }
    .my-pdf {
      height: 100%;
    }
  }
  .detail-right {
    width: 300px;
    padding: 0px 20px;
    border-left: 1px solid $border-color;
    .row {
      display: flex;
      padding: 10px;
      border-top: 1px solid $border-color;
      span:first-child {
        width: 90px;
        padding-right: 20px;
        text-align: right;
        &.rate {
          line-height: 32px;
        }
      }
    }
  }
  /deep/ .ivu-rate-star {
    margin-right: 0px;
  }
}
</style>
