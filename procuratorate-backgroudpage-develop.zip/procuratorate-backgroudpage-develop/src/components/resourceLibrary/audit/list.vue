<template>
  <div class="resourceLibraryAuditList">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clcikAllPass"
          >一键通过</i-button
        >
        <i-button size="large" type="error" @click="clcikAllBack"
          >一键退回</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot-scope="{ row }" slot="action">
          <span @click="clickSee(row.id)" class="toSee">查看详情</span>
        </template>
      </i-table>
      <my-pagination
        @paginate="handlePaginate"
        :pageSize="limitQuery.pageSize"
        :pageNum="limitQuery.pageNum"
        :msgCount="msgCount"
      ></my-pagination>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>是否退回所有已选记录？</p>
        <p class="required">请输入退回原因：</p>
        <i-input
          v-model="AuditHelper.comment"
          size="large"
          placeholder="请输入"
          type="textarea"
          :autosize="{ minRows: 3, maxRows: 6 }"
        ></i-input>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Button, Icon, Table, Input } from "view-design";
import myPagination from "@/components/common/myPagination";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "resourceLibraryAuditList",
  components: {
    "i-table": Table,
    "i-icon": Icon,
    "i-button": Button,
    "i-input": Input,
    "my-modal": myModal,
    "my-content-head": myContentHead,
    "my-pagination": myPagination
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "资源名称",
          align: "center",
          key: "resourceName",
          tooltip: true
        },
        {
          title: "资源类别",
          align: "center",
          key: "resourceType",
          render: (h, params) => {
            let type = params.row.resourceType;
            if (!Array.isArray(type)) {
              type = [];
            }
            return h("span", type.join(" / "));
          }
        },
        {
          title: "申请人",
          align: "center",
          key: "userName",
          tooltip: true,
          render: (h, params) => {
            return h("span", `${params.row.name}(${params.row.userName})`);
          }
        },
        { title: "申请时间", align: "center", key: "applyDate", width: 200 },
        { title: "操作", align: "center", width: 120, slot: "action" }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1,
        // 课程类别id
        classCategoryId: [""],
        // 审核状态 1：未审核 2：已审核
        classStatus: 1
      },
      // 待提交的表单数据
      AuditHelper: {
        ids: [],
        // 退回理由
        comment: ""
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-course-aduit-list"
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/library/audit/list", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
      // 请求待审核的记录条数
    },
    // 返回列表
    goBack() {
      this.$router.push("/resourceLibrary");
    },
    // 点击一键通过
    clcikAllPass() {
      if (this.$isEmpty(this.AuditHelper.ids)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "一键通过",
        msg: "是否通过所有已选记录？",
        modalVisiabal: true,
        handleOk: this.handleAllPass
      });
    },
    // 一键通过
    handleAllPass() {
      this.saveAllPass();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存一键通过的操作
    saveAllPass() {
      this.AuditHelper.status = 1;
      this.$axios
        .post("/api/library/audit", this.AuditHelper)
        .then(res => {
          this.$Message.success("一键通过成功");
          this.AuditHelper.ids = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击一键退回
    clcikAllBack() {
      if (this.$isEmpty(this.AuditHelper.ids)) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.modalOption.title = "一键退回";
      this.modalOption.modalVisiabal = true;
    },
    // 保存一键退回的操作结果
    saveAllBack() {
      if (this.AuditHelper.comment === "") {
        this.$Message.error("请填写退回理由");
        return;
      }
      this.AuditHelper.status = 2;
      this.$axios
        .post("/api/library/audit", this.AuditHelper)
        .then(res => {
          this.$Message.success("一键退回成功");
          this.AuditHelper.ids = [];
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击对话框的确定
    clickOk() {
      this.saveAllBack();
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击查看详情
    clickSee(id) {
      this.$router.push(`/resourceLibraryAudit/see/${id}`);
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.AuditHelper.ids = selection.map(item => {
        return item.id;
      });
    },
    // 清空表单数据
    clearFormData() {
      this.AuditHelper.comment = "";
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.resourceLibraryAuditList {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    .toSee {
      cursor: pointer;
      text-decoration: underline;
      color: $theme;
    }
  }
}
</style>
<style lang="scss">
.modal-course-aduit-list {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    p {
      line-height: 24px;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
