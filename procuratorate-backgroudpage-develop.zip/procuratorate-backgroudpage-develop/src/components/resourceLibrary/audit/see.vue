<template>
  <div class="resourceLibraryAuditSee">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clcikPass">通过</i-button>
        <i-button size="large" type="error" @click="clcikBack">退回</i-button>
      </div>
    </my-content-head>
    <div class="content">
      <my-detail :id="id"></my-detail>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>是否退回所有该条记录？</p>
        <p class="required">请输入退回原因：</p>
        <i-input
          v-model="AuditHelper.comment"
          size="large"
          placeholder="请输入"
          type="textarea"
          :autosize="{ minRows: 3, maxRows: 6 }"
        ></i-input>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Icon, Button, Input } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import resourceLibraryCommonDetail from "@/components/resourceLibrary/common/aduitDetail.vue";
import myModal from "@/components/common/myModal";
export default {
  name: "resourceLibraryAuditSee",
  props: {
    // 资源id
    id: {}
  },
  components: {
    "i-icon": Icon,
    "i-button": Button,
    "i-input": Input,
    "my-modal": myModal,
    "my-content-head": myContentHead,
    "my-detail": resourceLibraryCommonDetail
  },
  data() {
    return {
      // 待提交的表单数据
      AuditHelper: {
        ids: [this.id],
        // 退回理由
        comment: ""
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-course-aduit-list"
      }
    };
  },
  methods: {
    // 返回列表
    goBack() {
      this.$router.push("/resourceLibraryAudit/list");
    },
    // 点击通过
    clcikPass() {
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "通过",
        msg: "是否通过该条记录？",
        modalVisiabal: true,
        handleOk: this.handlePass
      });
    },
    // 通过
    handlePass() {
      this.savePass();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存一键通过的操作
    savePass() {
      this.AuditHelper.status = 1;
      this.$axios
        .post("/api/library/audit", this.AuditHelper)
        .then(res => {
          this.$Message.success("通过成功");
          this.AuditHelper.ids = [];
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击一键退回
    clcikBack() {
      this.modalOption.title = "一键退回";
      this.modalOption.modalVisiabal = true;
    },
    // 保存一键退回的操作结果
    saveBack() {
      if (this.AuditHelper.comment === "") {
        this.$Message.error("请填写退回理由");
        return;
      }
      this.AuditHelper.status = 2;
      this.$axios
        .post("/api/library/audit", this.AuditHelper)
        .then(res => {
          this.$Message.success("退回成功");
          this.AuditHelper.ids = [];
          // 隐藏模态框
          this.modalOption.modalVisiabal = false;
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击对话框的确定
    clickOk() {
      this.saveBack();
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 清空表单数据
    clearFormData() {
      this.AuditHelper.comment = "";
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.resourceLibraryAuditSee {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    border-top: 1px solid $border-color;
  }
}
</style>
<style lang="scss">
.modal-course-aduit-list {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    p {
      line-height: 24px;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
