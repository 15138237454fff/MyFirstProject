<template>
  <div class="noticeSee">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <div>
        <span class="">标题：</span>
        <div class="title">{{ formData.title }}</div>
      </div>
      <div>
        <span class="">发送对象：</span>
        <div class="send-object">{{ concreteObject }}</div>
      </div>
      <div>
        <span class="">正文：</span>
        <div v-html="formData.content"></div>
      </div>
      <div>
        <span>相关附件：</span>
        <div class="upload">
          <div v-for="(item, index) of formData.attachment" :key="index">
            <span v-if="index !== 0">、</span>
            <a
              :href="item.url"
              target="_blank"
              class="attachment"
              :download="item.fileName"
              >{{ item.fileName }}</a
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "noticeSee",
  components: {
    "i-icon": Icon,
    "my-content-head": myContentHead
  },
  props: { id: {} },
  data() {
    return {
      // 待提交的表单数据
      formData: {
        // 附件
        attachment: [],
        // 发布对象
        concreteObject: [],
        // 正文
        content: "",
        // 发布类型 1：全部用户 2：部门 3：角色
        publishType: 1,
        // 标题
        title: ""
      },
      // 发布类型可选列表
      publishTypeOptions: [
        { label: "全部用户", value: 1 },
        { label: "按部门发送", value: 2 },
        { label: "按角色发送", value: 3 }
      ],
      // 具体发布类型可选列表
      publishTypeDetailOptions: []
    };
  },
  mounted() {
    // 回显数据
    this.requireHistoryData();
  },
  methods: {
    // 请求历史数据
    requireHistoryData() {
      this.$axios
        .get(`/api/notice/${this.id}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          if (data.concreteObject) {
            // 将具体发送对象数据进行处理，数组化
            this.formData.concreteObject = data.concreteObject.split(",");
          }
          // 根据发送对象类型请求对应下拉框列表数据
          this.handleSelectChange(data.publishType);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 处理选择器选中项发生改变的方法
    handleSelectChange(value) {
      // 按部门
      if (value === 2) {
        this.requireDeptList();
      }
      // 按角色
      if (value === 3) {
        this.requireRoleList();
      }
    },
    // 请求可选的角色列表数据
    requireRoleList() {
      this.$axios
        .get("/api/role/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("获取可选的角色列表数据失败");
            return;
          }
          data = data.map(el => {
            return { value: el.id, label: el.roleName };
          });
          // 保存下拉列表数据
          this.publishTypeDetailOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求可选的部门列表数据
    requireDeptList() {
      this.$axios
        .get("/api/dept/select")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("部门下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.publishTypeDetailOptions = data;
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 返回列表方法
    goBack() {
      this.clearFormData();
      this.$router.push("/notice");
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 附件
        attachment: [],
        // 发布对象
        concreteObject: "",
        // 正文
        content: "",
        // 发布类型 1：全部用户 2：部门 3：角色
        publishType: 1,
        // 标题
        title: ""
      };
    }
  },
  computed: {
    // 返回发布对象
    concreteObject() {
      if (!this.formData.publishType) {
        return "";
      }
      if (this.formData.publishType === 1) {
        return "全部用户";
      } else {
        return this.formData.concreteObject
          .map(el => {
            let tmpObj = this.publishTypeDetailOptions.find(v => {
              return v.value === el;
            });
            if (tmpObj) {
              return tmpObj.label;
            } else {
              return "";
            }
          })
          .join("、");
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.noticeSee {
  .content {
    height: calc(100vh - 210px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    // padding-top:100px;
    .attachment {
      text-decoration: underline;
      color: $theme;
    }
    .title {
      .ivu-input-wrapper {
        width: 50% !important;
      }
    }

    & > div {
      display: flex;
      margin-bottom: $input-top;
      span {
        width: 100px;
      }
      .send-object {
        display: flex;
        align-items: flex-start;
      }
      & > :last-child {
        width: 100%;
      }
      .ivu-select {
        &:not(:last-child) {
          margin-right: $left;
        }
      }
      .upload {
        display: flex;
      }
    }
  }
  .content-left {
    height: 100%;
    line-height: $btn-height;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  /deep/ .ivu-input-wrapper {
    width: 200px;
  }
}
</style>
