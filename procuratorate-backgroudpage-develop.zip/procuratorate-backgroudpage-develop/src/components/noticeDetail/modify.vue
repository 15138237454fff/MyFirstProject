<template>
  <div class="noticeModify">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clickSave">保存</i-button>
      </div>
    </my-content-head>
    <div class="content">
      <div>
        <span class="required">标题：</span>
        <div class="title">
          <i-input
            v-model="formData.title"
            placeholder="请输入"
            size="large"
          ></i-input>
        </div>
      </div>
      <div>
        <span class="required">发送对象：</span>
        <div class="send-object">
          <i-select
            v-model="formData.publishType"
            size="large"
            @on-change="handleSelectChange"
          >
            <i-option
              v-for="(item, index) of publishTypeOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
          <i-select
            v-model="formData.concreteObject"
            size="large"
            v-if="formData.publishType !== 1"
            multiple
          >
            <i-option
              v-for="(item, index) of publishTypeDetailOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
        </div>
      </div>
      <div>
        <span class="required">正文：</span>
        <div>
          <!-- <quill-editor v-model="formData.content" :options="editorOption"></quill-editor> -->
          <tinymce-editor v-model="formData.content"></tinymce-editor>
        </div>
      </div>
      <div>
        <span>相关附件：</span>
        <div class="upload">
          <i-upload
            :action="uploadUrl"
            :on-success="handleUploadSuccess"
            multiple
            :max-size="maxSize"
            :on-exceeded-size="handleMaxSize"
            :on-remove="handleRemoveList"
            :default-file-list="attachment"
            :before-upload="handleBeforeUpload"
            :show-upload-list="true"
          >
            <i-button ghost type="primary" size="large">点击上传附件+</i-button>
            <span class="upload-msg">请上传10M以内的附件</span>
          </i-upload>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { Input, Button, Select, Option, Upload, Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import TinymceEditor from "@/components/common/tinymce-editor";
export default {
  name: "noticeModify",
  components: {
    "i-input": Input,
    "i-icon": Icon,
    "i-button": Button,
    "i-upload": Upload,
    "i-select": Select,
    "i-option": Option,
    "tinymce-editor": TinymceEditor,
    "my-content-head": myContentHead
  },
  props: { id: {} },
  data() {
    return {
      // 待提交的表单数据
      formData: {
        // 附件
        attachment: [],
        // 发布对象
        concreteObject: [],
        // 正文
        content: "",
        // 发布类型 1：全部用户 2：部门 3：角色
        publishType: 1,
        // 标题
        title: ""
      },
      historyConcreteObject: [],
      firstBack: false,
      // 发布类型可选列表
      publishTypeOptions: [
        { label: "全部用户", value: 1 },
        { label: "按部门发送", value: 2 },
        { label: "按角色发送", value: 3 }
      ],
      // 具体发布类型可选列表
      publishTypeDetailOptions: [],
      // 文件最大大小
      maxSize: 10240
    };
  },
  mounted() {
    // 回显数据
    this.requireHistoryData();
  },
  methods: {
    // 请求历史数据
    requireHistoryData() {
      this.$axios
        .get(`/api/notice/${this.id}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.firstBack = true;
          if (data.concreteObject) {
            // 将具体发送对象数据进行处理，数组化
            this.historyConcreteObject = data.concreteObject.split(",");
          }
          // 根据发送对象类型请求对应下拉框列表数据
          this.handleSelectChange(data.publishType);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 处理保存的方法
    clickSave() {
      this.$log.INFO("正在保存");
      // 如果验证失败，不继续执行
      if (!this.testForm()) {
        return;
      }
      // 浅克隆一份表单数据
      let tmpObj = Object.assign({}, this.formData, { id: this.id });
      // 将发送对象转为字符串
      if (Array.isArray(tmpObj.concreteObject)) {
        tmpObj.concreteObject = tmpObj.concreteObject.join(",");
      }
      this.$axios
        .put("/api/notice", tmpObj)
        .then(res => {
          this.$Message.success("修改成功");
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 对表单数据进行验证
    testForm() {
      let {
        concreteObject,
        content,
        publishType,
        title,
        attachment
      } = this.formData;
      // 当发送对象不为全部用户
      if (publishType !== 1) {
        if (concreteObject.length === 0) {
          this.$Message.error("请选择要发送的对象");
          return false;
        }
      }
      // 验证标题为空
      if (title === "") {
        this.$Message.error("通知标题不能为空");
        return false;
      }
      // 验证标题长度
      if (title.length > 50) {
        this.$Message.error("通知标题长度不能超过50位");
        return false;
      }
      // 验证内容为空
      if (content === "") {
        this.$Message.error("通知内容不能为空");
        return false;
      }
      // 附件个数超出限制
      if (attachment.length > 10) {
        this.$Message.error("最多上传10个附件");
        return false;
      }
      return true;
    },
    // 处理选择器选中项发生改变的方法
    handleSelectChange(value) {
      this.formData.concreteObject = [];
      // 按部门
      if (value === 2) {
        this.requireDeptList();
      }
      // 按角色
      if (value === 3) {
        this.requireRoleList();
      }
    },
    // 请求可选的角色列表数据
    requireRoleList() {
      this.$axios
        .get("/api/role/select")
        .then(res => {
          let data = res.data.data;
          if (!Array.isArray(data)) {
            console.error("获取可选的角色列表数据失败");
            return;
          }
          data = data.map(el => {
            return { value: el.id, label: el.roleName };
          });
          // 保存下拉列表数据
          this.publishTypeDetailOptions = data;
          if (this.firstBack) {
            this.formData.concreteObject = this.historyConcreteObject;
            this.firstBack = false;
          }
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求可选的部门列表数据
    requireDeptList() {
      this.$axios
        .get("/api/dept/select")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("部门下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.publishTypeDetailOptions = data;
          if (this.firstBack) {
            this.formData.concreteObject = this.historyConcreteObject;
            this.firstBack = false;
          }
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 文件上传前校验原附件个数
    handleBeforeUpload(file) {
      if (this.formData.attachment.length > 9) {
        this.$Message.error("最多上传10个附件");
        return false;
      }
    },
    // 文件上传成功的处理函数
    handleUploadSuccess(res) {
      this.formData.attachment.push(res.data);
    },
    // 上传文件大小超过限制的处理函数
    handleMaxSize() {
      this.$Message.error(`请上传${this.maxSize / 1024}M以下的文件`);
    },
    handleRemoveList(file) {
      this.$log.INFO("移除文件列表");
      let index = this.formData.attachment.findIndex(el => {
        return el.name === file.name && el.url === file.url;
      });
      this.formData.attachment.splice(index, 1);
    },
    // 返回列表方法
    goBack() {
      this.clearFormData();
      this.$router.push("/notice");
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 附件
        attachment: [],
        // 发布对象
        concreteObject: [],
        // 正文
        content: "",
        // 发布类型 1：全部用户 2：部门 3：角色
        publishType: 1,
        // 标题
        title: ""
      };
    }
  },
  computed: {
    editorOption() {
      return this.$store.getters["skb/getEditorOption"];
    },
    uploadUrl() {
      return this.$store.getters["skb/getUploadUrl"];
    },
    attachment() {
      return this.formData.attachment.map(el => {
        return { name: el.fileName, url: el.url };
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.noticeModify {
  .content {
    height: calc(100vh - 210px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    // padding-top:100px;
    .title {
      .ivu-input-wrapper {
        width: 50% !important;
      }
    }
    /deep/ .ivu-select-multiple {
      width: auto !important;
      min-width: 200px;
      max-width: 80%;
    }
    & > div {
      display: flex;
      margin-bottom: $input-top;
      span {
        width: 100px;
        line-height: $btn-height;
      }
      .send-object {
        display: flex;
        align-items: flex-start;
      }
      & > :last-child {
        width: 100%;
      }
      .ivu-select {
        &:not(:last-child) {
          margin-right: $left;
        }
      }
      .upload {
        width: 300px;
        .upload-msg {
          color: $error;
          margin-left: $top;
          line-height: $btn-height;
        }
      }
    }
  }
  .content-left {
    height: 100%;
    line-height: $btn-height;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  /deep/ .ivu-input-wrapper {
    width: 200px;
  }
  .quill-editor {
    width: 90%;
  }
  /deep/ .ql-container {
    height: 200px;
  }
}
</style>
