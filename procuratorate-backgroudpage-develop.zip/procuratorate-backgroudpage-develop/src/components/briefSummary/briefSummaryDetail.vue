<template>
  <div class="briefSummaryDetail">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clickOutput"
          >导出</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        :row-class-name="rowClassName"
      >
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Button, Icon } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "briefSummaryDetail",
  props: {
    id: {}
  },
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-icon": Icon,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项

      colOption: [
        {
          title: "姓名",
          align: "left",
          key: "name",
          tooltip: true,
          width: 120
        },
        {
          title: "所属部门",
          align: "left",
          key: "deptName",
          tooltip: true,
          width: 200
        },
        {
          title: "培训身份",
          align: "left",
          key: "identity",
          tooltip: true,
          width: 120,
          render: (h, params) => {
            return h("span", params.row.identity === 1 ? "学员" : "讲师");
          }
        },
        {
          title: "提交时间",
          align: "left",
          key: "createTime",
          tooltip: true,
          width: 200
        },
        { title: "培训小结", align: "left", key: "summary", tooltip: true }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 返回列表方法
    goBack() {
      this.$router.push("/briefSummary");
    },
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post(`/api/summary/collect/list/${this.id}`, this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 表格一行的颜色
    rowClassName(row) {
      if (this.$isEmpty(row.createTime)) {
        return "red";
      }
    },
    // 点击导出
    clickOutput() {
      this.$log.INFO("正在导出");
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.briefSummaryDetail {
  /deep/ .red {
    span {
      color: $error;
    }
  }
  .content-left {
    height: 100%;
    line-height: $btn-height;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
}
</style>
