<template>
  <div class="detailRosterModify">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clcikToSave"
          >保存</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="content-head">
        <div class="content-head-left">
          <div>
            <span>项目名称：</span>
            <span>{{ projectName }}</span>
          </div>
          <!-- <div>
            <span>所属部门： </span>
            <i-select
              v-model="deptNum"
              size="large"
              @on-change="handleSelectChange"
            >
              <i-option
                v-for="(item, index) of moreDeptOptions"
                :key="index"
                :value="item.value"
                >{{ item.label }}</i-option
              >
            </i-select>
          </div> -->
          <div>
            <span>报名人数： </span>
            <span>{{ this.tableData.length }}</span>
          </div>
        </div>
        <div class="content-head-right">
          <i-button size="large" type="primary" ghost @click="clickAdd"
            >新增报名人员</i-button
          >
        </div>
      </div>

      <i-table
        :data="tableData"
        :columns="colOption"
        :border="true"
        :height="tableHeight"
      >
        <template slot-scope="{ row, index }" slot="action">
          <div class="reduce" @click="reduceRow(index)">-</div>
        </template>
      </i-table>
    </div>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <div class="row">
          <span>所属部门：</span>
          <i-select v-model="formData.deptNum" size="large">
            <i-option
              v-for="(item, index) of staffOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
        </div>
        <div class="row">
          <span>报名人员：</span>
          <i-select v-model="formData.userId" size="large" multiple>
            <i-option
              v-for="(item, index) of userOptions"
              :key="index"
              :tag="item.name"
              :value="item.userId"
              >{{ item.name }}</i-option
            >
          </i-select>
        </div>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Icon, Table, Button, Select, Option } from "view-design";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "detailRosterModify",
  props: {
    projectId: {},
    projectName: {}
  },
  components: {
    "i-table": Table,
    "i-icon": Icon,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "my-modal": myModal,
    "my-content-head": myContentHead
  },
  data() {
    return {
      tableData: [],
      colOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "联系方式",
          align: "center",
          key: "mobile",
          tooltip: true
        },
        {
          title: "操作",
          align: "center",
          slot: "action",
          width: 80
        }
      ],
      // 当前选择的部门编号
      deptNum: "",
      // 可选的部门列表
      deptOptions: [],
      // 可选的报名人员列表
      staffOptions: [],
      // 表单数据
      formData: {
        // 部门value
        deptNum: "",
        // 用户id
        userId: []
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-detail-roster-modify"
      }
    };
  },
  mounted() {
    // 获取报名名单数据
    this.requireSignUpRoster();
    // 获取可选的部门列表
    this.requireDeptList();
    // 获取可选的报名人员列表
    this.requireSignUpList();
  },
  methods: {
    // 请求报名名单列表数据
    requireSignUpRoster() {
      // 发送请求列表数据的请求
      this.$axios
        .get(`/api/register/detailed/list/${this.projectId}`, {
          params: { deptNum: this.deptNum }
        })
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求可选的部门列表
    requireDeptList() {
      this.$axios
        .get(`/api/register/detailed/select/${this.projectId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.deptOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求可选的报名人员列表
    requireSignUpList() {
      this.$axios
        .get(`/api/register/detailed/add/${this.projectId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.staffOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 新增报名人员
    clickAdd() {
      // // 如果在新增前按部门过滤了
      // if (this.deptNum) {
      //   // 部门过滤清空
      //   this.deptNum = "";
      //   // 重新请求报名人员列表
      //   this.requireSignUpRoster();
      // }
      this.modalOption.title = "新增报名人员";
      this.modalOption.modalVisiabal = true;
    },
    // 点击对话框的确定
    clickOk() {
      this.saveAdd();
    },
    // 将选择的人员添加到展示的列表中
    saveAdd() {
      // 在人员列表中过滤出当前选中的人员
      let tmpArr = this.staffArray.filter(el => {
        return this.formData.userId.includes(el.userId);
      });
      // 判断这个人是否已经被报过名
      let result = this.tableData.some(el => {
        return tmpArr.some(val => {
          return val.userId === el.userId;
        });
      });
      // 如果报过名
      if (result) {
        this.$Message.error("请勿添加重复人员");
      } else {
        // 还没有报名，添加到展示的列表中去
        this.tableData = this.tableData.concat(tmpArr);
        // 数组去重
        this.tableData = Array.from(new Set(this.tableData));
        // 隐藏模态框
        this.modalOption.modalVisiabal = false;
      }
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 点击保存
    clcikToSave() {
      this.$axios
        .post("/api/register/detailed", {
          projectId: this.projectId,
          newStaff: this.tableData.map(el => el.userId)
        })
        .then(res => {
          this.$Message.success("调整成功");
          this.$router.go(-1);
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击删除一行记录
    reduceRow(index) {
      this.tableData.splice(index, 1);
    },
    // 返回列表
    goBack() {
      this.$router.push("/projectArrange");
    },
    // 选择器选中项发生变化
    handleSelectChange() {
      // 重新请求名单列表
      this.requireSignUpRoster();
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 部门value
        deptNum: "",
        // 用户id
        userId: []
      };
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 4;
    },
    // 返回一个更多内容的部门选项列表
    moreDeptOptions() {
      return [{ value: "", label: "全部部门" }, ...this.deptOptions];
    },
    staffArray() {
      let tmpArr = [];
      this.staffOptions.forEach(item => {
        tmpArr = tmpArr.concat(item.children);
      });
      return tmpArr;
    },
    userOptions() {
      let tmpObj = this.staffOptions.find(
        el => el.value === this.formData.deptNum
      );
      if (this.$isEmpty(tmpObj)) {
        return [];
      }
      // 去除已经报名的人员
      return tmpObj.children.filter(el => !this.tableData.includes(el));
    }
  }
};
</script>
<style lang="scss" scoped>
.detailRosterModify {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    border-top: 1px solid $border-color;
    .content-head {
      display: flex;
      justify-content: space-between;
      .content-head-left {
        display: flex;
        align-items: center;
        height: 50px;
        & > div {
          margin-right: 30px;
          &:first-child {
            font-weight: 900;
          }
          &:last-child {
            color: $theme;
          }
        }
      }
      .content-head-right {
        display: flex;
        align-items: center;
      }
    }

    .reduce {
      cursor: pointer;
      background: $error;
      margin: 0 auto;
      width: 24px;
      height: 24px;
      text-align: center;
      color: $white;
      border-radius: 50%;
      line-height: 20px;
      font-size: 30px;
    }
  }
}
</style>
<style lang="scss">
.modal-detail-roster-modify {
  .ivu-modal {
    width: 16vw !important;
  }
  .row {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
