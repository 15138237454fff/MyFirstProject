<template>
  <div class="detailRosterList">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button
          size="large"
          type="primary"
          @click="clcikToModify"
          v-if="
            projectStatus === '4000' ||
              projectStatus === '4002' ||
              projectStatus === '4003'
          "
          >调整</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="content-head">
        <div>
          <span>项目名称：</span>
          <span>{{ projectName }}</span>
        </div>
        <div>
          <span>所属部门： </span>
          <i-select
            v-model="deptNum"
            size="large"
            @on-change="handleSelectChange"
          >
            <i-option :value="-1">所有部门</i-option>
            <i-option
              v-for="(item, index) of deptOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
        </div>
        <div>
          <span>报名人数： </span>
          <span>{{ this.tableData.length }}</span>
        </div>
      </div>
      <i-table :data="tableData" :columns="colOption" :border="true"> </i-table>
    </div>
  </div>
</template>
<script>
import { Icon, Table, Button, Select, Option } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "detailRosterList",
  props: {
    projectId: {},
    projectName: {},
    projectStatus: {}
  },
  components: {
    "i-table": Table,
    "i-icon": Icon,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "my-content-head": myContentHead
  },
  data() {
    return {
      tableData: [],
      colOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true
        },
        {
          title: "联系方式",
          align: "center",
          key: "mobile",
          tooltip: true
        }
      ],
      // 当前选择的部门编号
      deptNum: -1,
      // 可选的部门列表
      deptOptions: []
    };
  },
  mounted() {
    // 获取报名名单数据
    this.requireSignUpRoster();
    // 获取可选的部门列表
    this.requireDeptList();
  },
  methods: {
    requireSignUpRoster() {
      // 发送请求列表数据的请求
      this.$axios
        .get(`/api/register/detailed/list/${this.projectId}`, {
          params: { deptNum: this.deptNum === -1 ? "" : this.deptNum }
        })
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 请求可选的部门列表
    requireDeptList() {
      this.$axios
        .get(`/api/register/detailed/select/${this.projectId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.deptOptions = data;
          // this.deptOptions = [{ value: "", label: "所有部门" }, ...data];
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 返回列表
    goBack() {
      this.$router.push("/projectArrange");
    },
    // 点击前往调整页面
    clcikToModify() {
      this.$router.push(
        `/detailRosterModify/${this.projectId}/${this.projectName}`
      );
    },
    // 选择器选中项发生变化
    handleSelectChange() {
      // 重新请求名单列表
      this.requireSignUpRoster();
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"];
    }
  }
};
</script>
<style lang="scss" scoped>
.detailRosterList {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    border-top: 1px solid $border-color;
    .content-head {
      display: flex;
      align-items: center;
      height: 50px;
      & > div {
        margin-right: 30px;
        &:first-child {
          font-weight: 900;
        }
        &:last-child {
          color: $theme;
        }
      }
    }
  }
}
</style>
