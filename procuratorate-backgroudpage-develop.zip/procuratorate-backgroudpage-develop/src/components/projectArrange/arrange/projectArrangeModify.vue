<template>
  <div class="projectArrangeAdd">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button size="large" type="primary" @click="clcikToSubmit"
          >提交</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <div class="content-head">
        <div>
          <span>项目名称：</span>
          <span>{{ projectName }}</span>
        </div>
        <i-button size="large" type="primary" @click="clickAddCourse" ghost
          >添加培训课程</i-button
        >
      </div>
      <div class="content-body">
        <table
          class="content-card"
          v-for="(item, index) of tableData"
          :key="index"
        >
          <thead>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td colspan="4">
                <div>
                  <div>
                    <span>课程名称：</span>
                    <span>{{ item.className }}</span>
                  </div>
                  <i-icon
                    type="md-close-circle"
                    :size="24"
                    color="red"
                    @click="reduceRow(index)"
                  ></i-icon>
                </div>
              </td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="required">培训讲师</td>
              <td>
                <!-- 内部讲师 -->
                <div v-if="item.classTeacherType !== 1">
                  <i-select v-model="item.teacherId" size="large">
                    <i-option
                      v-for="(item, index) of item.teachers"
                      :key="index"
                      :value="item.value"
                      >{{ item.label }}</i-option
                    >
                  </i-select>
                </div>
                <!-- 外部讲师 -->
                <div v-else>
                  <i-input
                    size="large"
                    v-model="item.classExternalTeacherName"
                  ></i-input>
                </div>
              </td>
              <td>课时费</td>
              <td>
                <i-input size="large" v-model="item.classCost" number>
                  <span slot="append">元/节</span>
                </i-input>
              </td>
            </tr>
            <tr>
              <td class="required">培训时间</td>
              <td>
                <i-date-picker
                  :transfer="true"
                  :options="dateOption"
                  type="date"
                  placeholder="请选择上课时间段"
                  :value="item.trainingDate"
                  @on-change="handleListDateChange($event, index)"
                  size="large"
                  :editable="false"
                ></i-date-picker>
                <i-time-picker
                  type="timerange"
                  separator="~"
                  size="large"
                  :value="[item.trainingTimeStart, item.trainingTimeEnd]"
                  @on-change="handleListTimeChange($event, index)"
                  :editable="false"
                ></i-time-picker>
              </td>
              <td class="required">是否考试</td>
              <td>
                <i-radio-group v-model="item.isNeedExam" size="large">
                  <i-radio :label="0">否</i-radio>
                  <i-radio :label="1" :disabled="item.classTeacherType === 1"
                    >是</i-radio
                  >
                </i-radio-group>
              </td>
            </tr>
            <tr>
              <td class="required">
                是否签到
              </td>
              <td>
                <i-radio-group
                  v-model="item.isNeedCheckin"
                  size="large"
                  @on-change="handleRadioCheckinChange(index)"
                >
                  <i-radio :label="0">否</i-radio>
                  <i-radio :label="1">是</i-radio>
                </i-radio-group>
              </td>
              <td class="required">培训场地</td>
              <td>
                <i-select
                  v-model="item.siteId"
                  filterable
                  placeholder="请搜索选择"
                  remote
                  clearable
                  ref="select"
                  :loading="item.loading"
                >
                  <i-option
                    v-for="(option, index) in item.option"
                    :value="option.value"
                    :key="index"
                    >{{ option.label }}</i-option
                  >
                </i-select>
              </td>
            </tr>
            <tr>
              <td class="required">是否需要培训用车</td>
              <td colspan="3">
                <div class="row car">
                  <i-radio-group v-model="item.isNeedCar" size="large">
                    <i-radio :label="0">否</i-radio>
                    <i-radio :label="1">是</i-radio>
                  </i-radio-group>
                  <template v-if="item.isNeedCar === 1">
                    <div>
                      <span>用车人数：</span>
                      <!-- <i-input size="large" v-model="item.carUseMember" number>
                      </i-input> -->
                      <i-input-number
                        v-model="item.carUseMember"
                        placeholder="请输入"
                        :min="1"
                        size="large"
                      ></i-input-number>
                    </div>
                    <div>
                      <span>目的地：</span>
                      <i-input size="large" v-model="item.destination">
                      </i-input>
                    </div>
                  </template>
                </div>
              </td>
            </tr>
            <tr>
              <td class="required">是否需要教学用具</td>
              <td colspan="3">
                <div class="row">
                  <i-radio-group
                    v-model="item.isNeedTools"
                    size="large"
                    @on-change="handleRadioChange($event, index)"
                  >
                    <i-radio :label="0">否</i-radio>
                    <i-radio :label="1">是</i-radio>
                  </i-radio-group>
                  <template v-if="item.isNeedTools === 1">
                    <div class="tool-input">
                      <div
                        v-for="(tool, ind) of item.toolsApplyDTOS"
                        :key="ind"
                      >
                        <i-select
                          v-model="tool.toolId"
                          size="large"
                          clearable
                          @on-open-change="
                            handleSelectOpenChange($event, index, ind)
                          "
                          @on-change="tool.useNumber = null"
                        >
                          <i-option
                            v-for="(toolItem, toolIndex) of tool.toolOption"
                            :key="toolIndex"
                            :value="toolItem.toolId"
                            >{{ toolItem.toolName }}(剩余{{ toolItem.toolStock
                            }}{{ toolItem.toolUnit }})</i-option
                          >
                        </i-select>
                        <!-- <i-input size="large" v-model="tool.useNumber">
                        </i-input> -->
                        <div>
                          <i-input-number
                            v-model="tool.useNumber"
                            placeholder="请输入"
                            :min="1"
                            size="large"
                            :max="
                              tool.toolOption | toolNumberFilter(tool.toolId)
                            "
                          ></i-input-number>
                        </div>
                        <div>
                          <div
                            @click="addToolRow(index)"
                            class="add"
                            v-if="ind === item.toolsApplyDTOS.length - 1"
                          >
                            +
                          </div>
                          <div
                            v-else
                            class="reduce"
                            @click="reduceToolRow(index, ind)"
                          >
                            -
                          </div>
                        </div>
                      </div>
                    </div>
                  </template>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <modal-add-course
      :modalOption="modalOption"
      @fatherVisiableChange="handleFatherVisiableChange"
    ></modal-add-course>
    <i-spin size="large" fix v-if="loading"></i-spin>
  </div>
</template>
<script>
import {
  Icon,
  Button,
  Select,
  Option,
  Input,
  DatePicker,
  Radio,
  RadioGroup,
  Spin,
  TimePicker,
  InputNumber
} from "view-design";
import myContentHead from "@/components/common/myContentHead";
import modalAddCourse from "@/components/common/modalAddCourse";
export default {
  name: "projectArrangeAdd",
  props: {
    projectId: {},
    projectName: {}
  },
  components: {
    "i-icon": Icon,
    "i-button": Button,
    "i-select": Select,
    "i-option": Option,
    "i-date-picker": DatePicker,
    "i-input": Input,
    "i-radio": Radio,
    "i-radio-group": RadioGroup,
    "i-spin": Spin,
    "i-time-picker": TimePicker,
    "i-input-number": InputNumber,
    "modal-add-course": modalAddCourse,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-add-course"
      },
      deleteIds: [],
      // 日期选择器的禁止选择日期范围
      dateOption: {
        disabledDate(date) {
          if (!date) {
            return false;
          }
          return date.valueOf() < Date.now();
        }
      },
      loading: false
    };
  },
  created() {
    // 清空之前勾选保存的记录
    this.$store.commit("skb/updateInformationSelectHistoryList", []);
  },
  mounted() {
    // 请求安排详情
    this.requireArrangeDetail();
  },
  methods: {
    requireArrangeDetail() {
      // 发送请求列表数据的请求
      this.$axios
        .get(`/api/projectArrangement/getArrangementInfo/${this.projectId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          data = data.map((el, index) => {
            if (this.$isEmpty(el.toolsApplyVOS)) {
              el.toolsApplyVOS = [{ toolId: "", useNumber: null }];
            }

            el.trainingDate = this.$tagTime(el.trainingTimeStart, "yyyy-MM-dd");
            el.trainingTimeStart = this.$tagTime(
              el.trainingTimeStart,
              "HH:mm:ss"
            );
            el.trainingTimeEnd = this.$tagTime(el.trainingTimeEnd, "HH:mm:ss");
            el.teachers = el.teacherInfoVOS.map(teacher => {
              return { value: teacher.teacherId, label: teacher.name };
            });
            // 如果是外部讲师
            if (el.classTeacherType === 1) {
              el.classExternalTeacherName = el.teacherName;
            }
            el.option = [{ value: el.siteId, label: el.siteName }];
            // el.toolOption = el.toolsApplyVOS;
            el.toolsApplyDTOS = el.toolsApplyVOS.map((obj, ind) => {
              return {
                toolId: obj.toolId,
                useNumber: obj.useNumber,
                toolOption: this.toolOptionFilter(el.toolsApplyVOS, index, ind)
              };
            });
            return el;
          });
          this.$store.commit("skb/updateInformationSelectHistoryList", data);
          this.$nextTick(() => {
            this.tableData.forEach((el, index) => {
              this.remoteMethod(index);
            });
          });
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 表单验证
    testForm() {
      let sign = true;
      this.tableData.forEach(el => {
        // 如果验证不通过不继续验证
        if (!sign) return;
        let {
          carUseMember,
          classExternalTeacherName,
          classTeacherType,
          destination,
          isNeedCar,
          siteId,
          teacherId,
          isNeedTools,
          toolsApplyDTOS,
          trainingTimeEnd,
          trainingTimeStart
        } = el;
        // 验证讲课教师
        if (classTeacherType === 0) {
          if (this.$isEmpty(teacherId)) {
            sign = false;
            return;
          }
        } else {
          if (this.$isEmpty(classExternalTeacherName)) {
            sign = false;
            return;
          }
        }
        // 培训时间验证
        if (trainingTimeStart === "") {
          sign = false;
          return;
        }
        if (trainingTimeEnd === "") {
          sign = false;
          return;
        }
        // 培训场地验证
        if (this.$isEmpty(siteId)) {
          sign = false;
          return;
        }
        if (isNeedCar === 1) {
          if (this.$isEmpty(carUseMember)) {
            sign = false;
            return;
          }
          if (this.$isEmpty(destination)) {
            sign = false;
          }
        }
        if (isNeedTools === 1) {
          toolsApplyDTOS.forEach(el => {
            if (this.$isEmpty(el.toolId)) {
              sign = false;
              return;
            }
            if (this.$isEmpty(el.useNumber)) {
              sign = false;
            }
          });
        }
      });
      return sign;
    },
    // 返回列表
    goBack() {
      // 清空之前勾选保存的记录
      this.$store.commit("skb/updateInformationSelectHistoryList", []);
      this.$router.push("/projectArrange");
    },
    // 点击提交
    clcikToSubmit() {
      this.$log.INFO("点击提交");
      let result = this.testForm();
      if (result) {
        this.handleSave();
      } else {
        this.$Message.error("请填写完整后再尝试提交");
      }
    },
    handleSave() {
      this.loading = true;
      this.$axios
        .put("/api/projectArrangement/arrangementUpdate", this.formData)
        .then(res => {
          this.$Message.success("调整成功");
          this.loading = false;
          this.goBack();
        })
        .catch(error => {
          this.loading = false;
          console.error(error.message);
        });
    },
    // 点击添加课程
    clickAddCourse() {
      this.modalOption.title = "添加培训课程";
      this.modalOption.key = "apply";
      this.modalOption.modalVisiabal = true;
    },
    // 根据课程id请求内部教师可选列表
    requireTeacherOptions(classId) {
      // 发送请求数据的请求
      this.$axios
        .get(`/api/projectArrangement/getInnerTeachers/${classId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          this.teacherOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 对话框可见性改变
    handleFatherVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 删除一条课程记录
    reduceRow(index) {
      if (this.tableData.length === 1) {
        this.$Message.error("项目至少包含一门培训课程");
        return;
      }
      this.deleteIds.push(this.tableData[index].projectClassapplyId);
      this.$store.commit("skb/deleteInformationSelectHistoryList", index);
    },
    handleListDateChange(date, index) {
      this.$store.commit("skb/modifyInformationSelectHistoryListTime", {
        date,
        index
      });
      this.tableData[index].siteId = "";
      this.remoteMethod(index);
    },
    // 时间选择器发生改变的处理函数
    handleListTimeChange(arr, index) {
      let date = this.tableData[index].trainingDate,
        dateTime = new Date(date + " " + arr[0]);
      if (dateTime - new Date() < 168000000) {
        this.$Message.error("请保证预留充足的工作安排时间！");
      }
      this.$store.commit("skb/modifyInformationSelectHistoryListTime", {
        arr,
        index
      });
      this.tableData[index].siteId = "";
      this.remoteMethod(index);
    },
    // 远程搜索可选场地的方法
    remoteMethod(index) {
      // 获取当前操作的课程信息对象
      let tmpCourse = this.tableData[index];
      if (
        !this.$isEmpty(tmpCourse.trainingTimeStart) &&
        !this.$isEmpty(tmpCourse.isNeedCheckin)
      ) {
        tmpCourse.loading = true;
        this.$axios
          .post("/api/projectArrangement/getSites", {
            isNeedCheckin: tmpCourse.isNeedCheckin,
            projectId: this.projectId,
            projectClassapplyId: tmpCourse.projectClassapplyId,
            trainingTimeStart: new Date(
              tmpCourse.trainingDate + " " + tmpCourse.trainingTimeStart
            ),
            trainingTimeEnd: new Date(
              tmpCourse.trainingDate + " " + tmpCourse.trainingTimeEnd
            )
          })
          .then(res => {
            tmpCourse.loading = false;
            let data = res.data.data;
            // 获得的参数验证
            if (!Array.isArray(data)) {
              console.error("场地下拉框数据获取失败");
              return false;
            }

            // 保存下拉列表数据
            // 给对象添加新属性，避免无法响应
            this.$set(
              tmpCourse,
              "option",
              // data.filter(item => item.label.indexOf(query) > -1)
              data
            );
          })
          .catch(error => {
            console.error(error.message);
            tmpCourse.option = [];
          });
      } else {
        tmpCourse.option = [];
      }
    },
    // 远程搜索可选用具的方法
    toolRemoteMethod(index, ind) {
      let tmp = this.tableData[index];
      if (!tmp) {
        console.log("找不到对应下标的表格数据");
      }
      tmp = tmp.toolsApplyDTOS;
      if (!Array.isArray(tmp)) {
        console.log("用具列表数据错误");
      }
      // 获取当前操作的课程信息对象
      let tmpCourse = tmp[ind];
      this.$axios
        .get("/api/projectArrangement/getTools")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("用具下拉框数据获取失败");
            return false;
          }
          data = this.toolOptionFilter(data, index, ind);
          // 保存下拉列表数据
          // 给对象添加新属性，避免无法响应
          this.$set(tmpCourse, "toolOption", data);
        })
        .catch(error => {
          console.error(error.message);
          tmpCourse.toolOption = [];
        });
    },
    // 过滤传入的可选用具列表
    toolOptionFilter(arr, index, ind) {
      if (!Array.isArray(arr)) {
        console.log("传入的待过滤列表数据错误");
        return [];
      }
      let tmp = this.tableData[index];
      if (!tmp) {
        console.log("找不到对应下标的表格数据");
        return arr;
      }
      tmp = tmp.toolsApplyDTOS;
      if (!Array.isArray(tmp)) {
        console.log("用具列表数据错误");
        return arr;
      }
      tmp = [...tmp];
      let resultArr = arr.filter(el => {
        let sign = true;
        tmp.forEach((obj, objIndex) => {
          if (objIndex === ind) {
            return;
          }
          if (!sign) {
            return;
          }
          if (obj.toolId === el.toolId) {
            sign = false;
          }
        });
        return sign;
      });
      return resultArr;
    },
    handleSelectOpenChange(bool, index, ind) {
      if (bool) {
        this.toolRemoteMethod(index, ind);
      }
    },
    // // 用具单选框改变的事件
    handleRadioChange(value, index) {
      if (value === 0) {
        this.tableData[index].toolsApplyDTOS.forEach(el => {
          el.toolOption = [];
        });
      }
    },
    addToolRow(index) {
      this.tableData[index].toolsApplyDTOS.push({
        toolId: "",
        useNumber: null
      });
    },
    reduceToolRow(index, ind) {
      this.tableData[index].toolsApplyDTOS.splice(ind, 1);
    },
    // 是否签到修改时清空场地选择
    handleRadioCheckinChange(index) {
      this.tableData[index].siteId = "";
      this.remoteMethod(index);
    }
  },
  computed: {
    // 返回课程培训记录
    tableData() {
      return this.$store.getters["skb/getInformationSelectHistoryList"];
    },
    // 整理要提交的表单数据
    formData() {
      return {
        projectId: this.projectId,
        deleteIds: this.deleteIds,
        arrangementClassDTOS: this.tableData.map(el => {
          return {
            carUseMember: el.carUseMember,
            classCost: el.classCost,
            classExternalTeacherName: el.classExternalTeacherName,
            classId: el.classId,
            classTeacherType: el.classTeacherType,
            destination: el.destination,
            isNeedCar: el.isNeedCar,
            isNeedCheckin: el.isNeedCheckin,
            isNeedExam: el.isNeedExam,
            isNeedTools: el.isNeedTools,
            projectClassapplyId: el.projectClassapplyId,
            siteId: el.siteId,
            teacherId: el.teacherId,
            toolsApplyDTOS: el.toolsApplyDTOS,
            trainingTimeEnd: new Date(
              el.trainingDate + " " + el.trainingTimeEnd
            ),
            trainingTimeStart: new Date(
              el.trainingDate + " " + el.trainingTimeStart
            )
          };
        })
      };
    }
  },
  filters: {
    toolNumberFilter(arr, id) {
      if (arr) {
        let tmpObj = arr.find(el => {
          return el.toolId === id;
        });
        if (tmpObj) {
          return tmpObj.toolStock;
        } else {
          return null;
        }
      } else {
        return null;
      }
    }
  },
  destroyed() {
    console.log("清空记录");
    // 清空之前勾选保存的记录
    this.$store.commit("skb/updateInformationSelectHistoryList", []);
  }
};
</script>
<style lang="scss" scoped>
.projectArrangeAdd {
  position: relative;
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    border-top: 1px solid $border-color;
    .content-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 50px;
    }
    .content-body {
      height: calc(100vh - 234px);
      overflow: auto;
      .content-card {
        border: 1px solid $border-color;
        margin-bottom: $top;
        tr {
          border: 1px solid $border-color;
          height: 44px;
        }
        thead td:nth-child(odd) {
          width: 160px;
        }
        thead tr:first-child {
          height: 0;
          visibility: hidden;
        }
        thead td > div {
          height: 44px;
          display: flex;
          font-weight: normal;
          justify-content: space-between;
          align-items: center;
          padding: 0 10px 0 14px;
          .ivu-icon {
            cursor: pointer;
          }
        }
        tbody td {
          padding-left: $top;
          padding-right: $top;
          /deep/ {
            .ivu-date-picker-rel .ivu-input-wrapper {
              width: 100% !important;
            }
            .ivu-date-picker {
              width: 49%;
              &:not(:last-child) {
                margin-right: 5px;
              }
            }
            .ivu-select {
              width: 100% !important;
            }
          }
          .row {
            display: flex;
            & > div {
              display: flex;
              align-items: center;
              &:first-child {
                line-height: 44px;
              }
              margin-right: 30px;
            }
          }
          .car {
            & > div {
              display: flex;
              align-items: center;
            }
          }
          &:nth-child(odd) {
            @extend .header-bg;
            &:not(.required) {
              text-indent: 0.8em;
            }
          }
          .tool-input {
            display: flex;
            flex-direction: column;
            padding: $top;
            /deep/ .ivu-input-number {
              display: inline-block;
            }
            & > div {
              display: flex;
              align-items: center;
              .ivu-select {
                width: 160px !important;
              }
              &:not(:last-child) {
                margin-bottom: $top;
              }
              & > div {
                margin-right: 10px;
              }
            }
          }
          .add,
          .reduce {
            background: $error;
            cursor: pointer;
            width: 24px;
            height: 24px;
            text-align: center;
            line-height: 24px;
            color: $white;
            border-radius: 50%;
            font-size: 24px;
          }
          .add {
            background: $theme;
          }
          .reduce {
            line-height: 20px;
            font-size: 30px;
          }
        }
      }
    }
  }
}
</style>
