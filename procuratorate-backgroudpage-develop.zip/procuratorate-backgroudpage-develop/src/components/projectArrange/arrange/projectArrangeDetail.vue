<template>
  <div class="projectArrangeDetail">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <div class="content-head">
        <div>
          <span>项目名称：</span>
          <span>{{ projectName }}</span>
        </div>
      </div>
      <div class="content-body">
        <table
          class="content-card"
          v-for="(item, index) of tableData"
          :key="index"
        >
          <thead>
            <tr>
              <td></td>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td colspan="4">
                <div>
                  <div>
                    <span>课程名称：</span>
                    <span>{{ item.className }}</span>
                  </div>
                </div>
              </td>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="">培训讲师</td>
              <td>
                {{ item.teacherName }}
              </td>
              <td>课时费</td>
              <td>
                <span v-if="item.classCost">{{ item.classCost }} 元/节</span>
              </td>
            </tr>
            <tr>
              <td class="">培训时间</td>
              <td>
                {{ item.trainingTimeStart | toDateTime(".") }} ~
                {{ item.trainingTimeEnd | toDateTime(".") }}
              </td>
              <td class="">是否考试</td>
              <td>
                {{ item.isNeedExam === 1 ? "是" : "否" }}
              </td>
            </tr>
            <tr>
              <td class="">
                是否签到
              </td>
              <td>
                {{ item.isNeedCheckin === 1 ? "是" : "否" }}
              </td>
              <td class="">培训场地</td>
              <td>
                {{ item.siteName }}
              </td>
            </tr>
            <tr>
              <td class="">是否需要培训用车</td>
              <td colspan="3">
                <div class="row">
                  <div>{{ item.isNeedCar === 1 ? "是" : "否" }}</div>
                  <template v-if="item.isNeedCar === 1">
                    <div>
                      <span>用车人数：{{ item.carUseMember }}</span>
                    </div>
                    <div>
                      <span>目的地：{{ item.destination }}</span>
                    </div>
                  </template>
                </div>
              </td>
            </tr>
            <tr>
              <td class="">是否需要教学用具</td>
              <td colspan="3">
                <div class="row">
                  <div>{{ item.isNeedTools === 1 ? "是" : "否" }}</div>
                  <template v-if="item.isNeedTools === 1">
                    <div v-for="(tool, ind) of item.toolsApplyVOS" :key="ind">
                      <span class="tool-name">{{ tool.toolName }} </span>
                      <span>{{ tool.useNumber }}{{ tool.toolUnit }}</span>
                    </div>
                  </template>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>
<script>
import { Icon } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "projectArrangeDetail",
  props: {
    projectId: {},
    projectName: {}
  },
  components: {
    "i-icon": Icon,
    "my-content-head": myContentHead
  },
  data() {
    return {
      tableData: []
    };
  },
  mounted() {
    // 请求安排详情
    this.requireArrangeDetail();
  },
  methods: {
    requireArrangeDetail() {
      // 发送请求列表数据的请求
      this.$axios
        .get(`/api/projectArrangement/getArrangementInfo/${this.projectId}`)
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!Array.isArray(data)) {
            console.error("列表数据获取失败");
            return false;
          }
          data = data.map(el => {
            el.trainingTimeStart = new Date(el.trainingTimeStart);
            el.trainingTimeEnd = new Date(el.trainingTimeEnd);
            return el;
          });
          this.tableData = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 返回列表
    goBack() {
      // 清空之前勾选保存的记录
      this.$store.commit("skb/updateInformationSelectHistoryList", []);
      this.$router.push("/projectArrange");
    }
  }
};
</script>
<style lang="scss" scoped>
.projectArrangeDetail {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    border-top: 1px solid $border-color;
    .content-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 50px;
    }
    .content-body {
      height: calc(100vh - 234px);
      overflow: auto;
      .content-card {
        border: 1px solid $border-color;
        margin-bottom: $top;
        tr {
          border: 1px solid $border-color;
          height: 44px;
        }
        thead td:nth-child(odd) {
          width: 160px;
        }
        thead tr:first-child {
          height: 0;
          visibility: hidden;
        }
        thead td > div {
          height: 44px;
          display: flex;
          font-weight: normal;
          justify-content: space-between;
          align-items: center;
          padding: 0 10px 0 14px;
          .ivu-icon {
            cursor: pointer;
          }
        }
        tbody td {
          padding-left: $top;
          padding-right: $top;
          // text-align: center;
          .row {
            display: flex;
            line-height: 44px;
            text-align: center;
            // justify-content: center;
            & > div,
            .tool-name {
              margin-right: 30px;
            }
          }
          &:nth-child(odd) {
            @extend .header-bg;
            &:not(.required) {
              text-indent: 0.8em;
            }
          }
          .tool-input {
            display: flex;
            flex-direction: column;
            padding: $top;
            & > div {
              display: flex;
              align-items: center;
              &:not(:last-child) {
                margin-bottom: $top;
              }
              & > div {
                margin-right: 10px;
              }
            }
          }
        }
      }
    }
  }
}
</style>
