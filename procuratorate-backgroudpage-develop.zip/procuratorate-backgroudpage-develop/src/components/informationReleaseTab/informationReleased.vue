<template>
  <div class="informationReleased">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入培训项目"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickCancelPublish"
          type="primary"
          v-if="$btnAuthorityTest('register:unpublish')"
          >取消发布</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        @on-selection-change="handleSelectChange"
        ref="selection"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="publishObject">
          <i-tooltip
            :content="
              row.publishObject && row.publishObject.length !== 0
                ? row.publishObject.join('、')
                : '全部用户'
            "
            :transfer="true"
            max-width="300px"
            >{{
              row.publishObject && row.publishObject.length !== 0
                ? row.publishObject.join("、")
                : "全部用户"
            }}</i-tooltip
          >
        </template>
        <template slot-scope="{ row }" slot="status">
          <span :class="row.projectStatus | projectStatusClassFilter">{{
            row.projectStatus | projectStatusValueFilter
          }}</span>
        </template>
        <template slot-scope="{ row }" slot="detail">
          <span @click="clickToDetail(row.projectId)" class="to-detail"
            >培训详情</span
          >
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>选中项目存在报名学员</p>
        <p class="required">请填写取消发布原因（系统会自动通知报名学员)：</p>
        <i-input
          v-model="formData.content"
          size="large"
          placeholder="请输入"
          type="textarea"
          :autosize="{ minRows: 3, maxRows: 6 }"
        ></i-input>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Table, Input, Button, Tooltip } from "view-design";
import myModal from "@/components/common/myModal";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "informationReleased",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        {
          title: "发布对象",
          align: "center",
          slot: "publishObject",
          tooltip: true
        },
        {
          title: "人数限制",
          align: "center",
          key: "memberLimit",
          width: 120,
          tooltip: true,
          render: (h, params) => {
            let row = params.row;
            return h(
              "span",
              row.memberLimit === "" ? "无限制" : row.memberLimit
            );
          }
        },
        {
          title: "报名截止时间",
          align: "center",
          key: "deadline",
          width: 200
        },
        {
          title: "发布时间",
          align: "center",
          key: "publishTime",
          width: 200
        },
        {
          title: "状态",
          align: "center",
          slot: "status",
          tooltip: true,
          width: 120
        },
        {
          title: "培训详情",
          align: "center",
          slot: "detail",
          tooltip: true,
          width: 120
        }
      ],
      // 选中的记录列表
      selectedHistoryList: [],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 待提交的表单数据
      formData: {
        // 退回理由
        content: ""
      },
      // 是否允许取消发布
      allowCancel: false,
      haveSignUp: false,
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-information-Released"
      }
    };
  },
  created() {
    let limitQuery = this.$store.getters["skb/getLimitQuery"];
    this.limitQuery.pageSize = limitQuery.pageSize;
    this.limitQuery.pageNum = limitQuery.pageNum;
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    readHistoryLimitQuery() {
      let limitQuery = this.$store.getters["skb/getLimitQuery"];
      this.limitQuery.pageSize = limitQuery.pageSize;
      this.limitQuery.pageNum = limitQuery.pageNum;
      this.limitQuery.query = limitQuery.query;
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/projectPublish/getPublished", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          data.list.forEach(el => {
            if (el.projectStatus === 4000 || el.projectStatus >= 4004) {
              el._disabled = true;
            }
          });
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击取消发布
    clickCancelPublish() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      // 如果不允许取消发布
      if (!this.allowCancel) {
        this.$Message.error("项目已开始/预开始，不可取消发布！");
        return;
      }
      // 如果有报名的人，直接能取消发布不用填写原因
      if (this.haveSignUp) {
        this.modalOption.title = "取消发布";
        this.modalOption.modalVisiabal = true;
      } else {
        this.$store.commit("skb/updateConfirmModalOption", {
          title: "取消发布",
          msg: "确定取消发布已选项目？",
          modalVisiabal: true,
          handleOk: this.handleCancelPublish
        });
      }
    },
    // 删除
    handleCancelPublish() {
      this.saveCancelPublish();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存取消发布的操作
    saveCancelPublish() {
      if (this.haveSignUp && this.formData.content === "") {
        this.$Message.error("请填写取消发布理由");
        return;
      }
      let tmpArr = this.selectedHistoryList.map(el => {
        return el.projectId;
      });
      this.$axios
        .put("/api/register/unpublish", {
          comment: this.formData.content,
          ids: tmpArr
        })
        .then(res => {
          this.$Message.success("取消发布成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
          this.modalOption.modalVisiabal = false;
        })
        .catch(error => {
          console.error(error.message);
        });
    },

    // 点击对话框的确定
    clickOk() {
      // 隐藏模态框
      this.saveCancelPublish();
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      // 清空表单
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 退回理由
        content: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    },
    // 前往查看培训详情
    clickToDetail(id) {
      this.$router.push(`/informationReleasedDetail/${id}`);
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      this.haveSignUp = selection.some(el => {
        return el.memberActual > 0;
      });
      this.allowCancel = !selection.some(el => {
        return el.flag === 0;
      });
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 50;
    }
  },
  filters: {
    projectStatusValueFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
        case 4002:
        case 4003:
        case 4007:
          return "未开始";
        case 4004:
          return "已开始";
        default:
          return "已结束";
      }
    },
    projectStatusClassFilter(value) {
      value = parseInt(value);
      switch (value) {
        case 4000:
        case 4002:
        case 4003:
        case 4007:
          return "orange";
        case 4004:
          return "green";
        default:
          return "";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.informationReleased {
  .to-detail {
    color: $theme;
    text-decoration: underline;
    cursor: pointer;
  }
  .green {
    color: $theme;
  }
  .orange {
    color: $orange;
  }
}
</style>
<style lang="scss">
.modal-information-Released {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    p {
      line-height: 24px;
      text-align: left;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
