<template>
  <div class="informationUnRelease">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入课程名称"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickPublish"
          type="primary"
          v-if="$btnAuthorityTest('projectPublish:publish')"
          >发布培训信息</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        @on-selection-change="handleSelectChange"
        ref="selection"
        :loading="loading"
      >
        <template slot-scope="{ row }" slot="applyTime">
          <span>{{ row.applyTime | toDateTime("-") }}</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :query="limitQuery.query"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Table, Input, Button } from "view-design";
import myPagination from "@/components/common/myPagination";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "informationUnRelease",
  components: {
    "i-table": Table,
    "i-input": Input,
    "i-button": Button,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        { type: "selection", width: 50, align: "center" },
        {
          title: "课程名称",
          align: "center",
          key: "className",
          tooltip: true
        },
        {
          title: "课程类别",
          align: "center",
          key: "classCategoryId",
          tooltip: true
        },
        {
          title: "培训要求",
          align: "center",
          key: "trainingRequire",
          tooltip: true
        },
        { title: "申请人", align: "center", key: "applyUser", tooltip: true },
        { title: "申请部门", align: "center", key: "deptName", tooltip: true },
        { title: "申请时间", align: "center", slot: "applyTime", width: 200 }
      ],
      // 选中的记录列表
      selectedHistoryList: [],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    this.$nextTick(() => {
      // 请求列表数据
      this.loadTable();
    });
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    readHistoryLimitQuery() {
      let limitQuery = this.$store.getters["skb/getLimitQuery"];
      this.limitQuery.pageSize = limitQuery.pageSize;
      this.limitQuery.pageNum = limitQuery.pageNum;
      this.limitQuery.query = limitQuery.query;
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/projectPublish/getDepublished", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 发布课程信息
    clickPublish() {
      this.$log.INFO("发布课程信息");
      // 取出保存的数据
      let tmpArr = this.selectedHistoryList.map(el => {
        return {
          projectClassapplyId: el.projectClassapplyId,
          classId: el.classId,
          className: el.className,
          classCategoryId: el.classCategoryId,
          trainingTimeStart: "",
          trainingTimeEnd: ""
        };
      });
      // 保存勾选的记录到vuex中
      this.$store.commit("skb/updateInformationSelectHistoryList", tmpArr);
      this.$router.push("/informationUnReleasePublish");
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection;
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 50;
    }
  }
};
</script>
<style lang="scss" scoped>
.informationUnRelease {
}
</style>
