<template>
  <div class="informationReleasedDetail">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-form :model="formData" :label-width="120" :inline="true">
        <i-form-item label="项目名称：">
          {{ formData.projectName }}
        </i-form-item>
        <i-form-item label="发布对象：">
          {{
            formData.publishObject && formData.publishObject.length !== 0
              ? formData.publishObject.join("、")
              : "全部用户"
          }}
        </i-form-item>
        <i-form-item label="培训人数限制：">
          {{ formData.memberLimit === "" ? "不限" : formData.memberLimit }}
        </i-form-item>
        <i-form-item label="培训地点：">
          {{ formData.trainingLocation }}
        </i-form-item>
        <i-form-item label="报名截止时间：">
          {{ formData.deadline }}
        </i-form-item>
      </i-form>
      <table class="my-table-title">
        <tr>
          <td align="left">| 培训课程信息</td>
          <td align="right"></td>
        </tr>
      </table>

      <i-table :data="tableData" :columns="colOption" :border="true">
        <template slot-scope="{ row }" slot="trainingTime">
          <i-tooltip
            :content="`${row.trainingTimeStart} ~ ${row.trainingTimeEnd}`"
            :transfer="true"
            max-width="300px"
            >{{ row.trainingTimeStart }} ~ {{ row.trainingTimeEnd }}</i-tooltip
          >
        </template>
      </i-table>
    </div>
  </div>
</template>
<script>
import { Icon, Table, Form, FormItem, Tooltip } from "view-design";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "informationReleasedDetail",
  components: {
    "i-table": Table,
    "i-icon": Icon,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-tooltip": Tooltip,
    "my-content-head": myContentHead
  },
  props: {
    id: {}
  },
  data() {
    return {
      colOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        {
          title: "培训课程",
          align: "center",
          key: "className",
          tooltip: true
        },
        {
          title: "课程类型",
          align: "center",
          key: "classCategoryId",
          width: 200,
          tooltip: true
        },
        {
          title: "培训时间",
          align: "center",
          slot: "trainingTime"
        }
      ],
      formData: {
        // 报名截止日期
        deadline: "",
        // 人数限制
        memberLimit: "",
        // 培训项目名称
        projectName: "",
        // 发布对象内容 如果type是部门(6002)就存储部门编号
        publishObject: [],
        // 培训地点
        trainingLocation: "",
        // 培训课程信息
        projectPublishClassVOs: []
      }
    };
  },
  mounted() {
    // 获取详情数据
    this.dataCallBack();
  },
  methods: {
    dataCallBack() {
      this.$axios
        .get(`/api/projectPublish/getProjectInfo/${this.id}`)
        .then(res => {
          let data = res.data.data;
          Object.keys(this.formData).forEach(key => {
            this.formData[key] = data[key];
          });
          this.formData.toolCategoryId = data.toolCategoryName;
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 返回列表
    goBack() {
      this.$router.push({
        path: "/informationRelease",
        query: { activeTab: "release" }
      });
    }
  },
  computed: {
    tableData() {
      let tmpArr = this.formData.projectPublishClassVOs;
      if (!tmpArr || tmpArr.some(el => !el)) {
        return [];
      }
      return tmpArr;
    }
  }
};
</script>
<style lang="scss" scoped>
.informationReleasedDetail {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    height: calc(100vh - 184px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    overflow: auto;
    .ivu-form-inline .ivu-form-item {
      width: 46%;
      &:first-child {
        width: 100%;
      }
    }
    .my-table-title {
      background: #f8f8f9;
      height: $td-height;
      border: 1px solid $border-color;
      border-bottom: 0;
      margin-top: $top;
      td:first-child {
        font-weight: 900;
        padding-left: $top;
      }
      td:last-child {
        padding-right: $top;
      }
    }
    .project-name {
      width: 80% !important;
    }
  }
}
</style>
