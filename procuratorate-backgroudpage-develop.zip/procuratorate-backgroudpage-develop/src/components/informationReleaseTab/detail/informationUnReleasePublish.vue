<template>
  <div class="informationUnReleasePublish">
    <my-content-head>
      <div slot="left" class="content-left">
        <i-icon type="ios-undo" class="back" @click="goBack"></i-icon>
        <span class="back" @click="goBack">返回列表</span>
      </div>
      <div slot="right">
        <i-button
          size="large"
          type="primary"
          @click="clickPublish"
          :disabled="relay"
          >发布</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-form
        :model="formData"
        :label-width="120"
        ref="formValidate"
        :rules="ruleValidate"
        :inline="true"
      >
        <i-form-item label="项目名称：" required prop="projectName">
          <i-input
            class="project-name"
            v-model="formData.projectName"
            placeholder="请输入"
            size="large"
          ></i-input>
        </i-form-item>
        <i-form-item label="发布对象：" required prop="publishObjectType">
          <i-select v-model="formData.publishObjectType" size="large">
            <i-option
              v-for="(item, index) of publishObjectTypeOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
          <i-select
            v-model="formData.publishObjectContent"
            size="large"
            v-if="formData.publishObjectType !== 6001"
            multiple
          >
            <i-option
              v-for="(item, index) of publishObjectContentOptions"
              :key="index"
              :value="item.value"
              >{{ item.label }}</i-option
            >
          </i-select>
        </i-form-item>
        <i-form-item label="培训人数限制：">
          <!-- <i-input
            v-model="formData.memberLimit"
            placeholder="请输入"
            number
          ></i-input> -->
          <i-input-number
            v-model="formData.memberLimit"
            placeholder="请输入"
            :min="1"
            size="large"
          ></i-input-number>
        </i-form-item>
        <i-form-item label="培训地点：" required prop="trainingLocation">
          <i-input
            v-model="formData.trainingLocation"
            placeholder="请输入"
            size="large"
          ></i-input>
        </i-form-item>
        <i-form-item label="报名截止时间：" required prop="deadline">
          <i-date-picker
            :transfer="true"
            :options="dateOption"
            type="datetime"
            placeholder="请选择截止时间"
            v-model="formData.deadline"
            size="large"
            :editable="false"
          ></i-date-picker>
        </i-form-item>
      </i-form>
      <table class="my-table-title">
        <tr>
          <td align="left">| 培训课程信息</td>
          <td align="right">
            <i-button
              size="large"
              type="primary"
              @click="clickAddCourse"
              v-if="$btnAuthorityTest('projectPublish:applyClass')"
              >添加课程</i-button
            >
          </td>
        </tr>
      </table>

      <i-table :data="tableData" :columns="colOption" :border="true">
        <template slot-scope="{ row, index }" slot="trainingTime">
          <i-date-picker
            :transfer="true"
            :options="dateOption"
            type="date"
            placeholder="请选择上课时间段"
            :value="row.trainingDate"
            @on-change="handleListDateChange($event, index)"
            size="large"
            :editable="false"
          ></i-date-picker>
          <i-time-picker
            type="timerange"
            separator="~"
            size="large"
            :value="[row.trainingTimeStart, row.trainingTimeEnd]"
            :transfer="true"
            @on-change="handleListTimeChange($event, index)"
            :editable="false"
          ></i-time-picker>
        </template>
        <template slot-scope="{ row, index }" slot="action">
          <div class="reduce" @click="reduceRow(index)">-</div>
        </template>
      </i-table>
    </div>
    <modal-add-course
      :modalOption="modalOption"
      @fatherVisiableChange="handleFatherVisiableChange"
    ></modal-add-course>
  </div>
</template>
<script>
import {
  Button,
  Icon,
  Table,
  Input,
  DatePicker,
  Form,
  FormItem,
  Select,
  Option,
  InputNumber,
  TimePicker
} from "view-design";
import modalAddCourse from "@/components/common/modalAddCourse";
import myContentHead from "@/components/common/myContentHead";
export default {
  name: "informationUnReleasePublish",
  components: {
    "i-table": Table,
    "i-icon": Icon,
    "i-button": Button,
    "i-input": Input,
    "i-input-number": InputNumber,
    "i-date-picker": DatePicker,
    "i-form": Form,
    "i-form-item": FormItem,
    "i-select": Select,
    "i-option": Option,
    "i-time-picker": TimePicker,
    "modal-add-course": modalAddCourse,
    "my-content-head": myContentHead
  },
  data() {
    return {
      colOption: [
        {
          title: "序号",
          align: "center",
          type: "index",
          width: 80
        },
        {
          title: "培训课程",
          align: "center",
          key: "className",
          tooltip: true,
          width: 200
        },
        {
          title: "课程类型",
          align: "center",
          key: "classCategoryId",
          tooltip: true,
          width: 200
        },
        {
          title: "培训时间",
          align: "center",
          slot: "trainingTime"
        },
        {
          title: "操作",
          align: "center",
          slot: "action",
          width: 80
        }
      ],
      formData: {
        // 报名截止日期
        deadline: "",
        // 人数限制
        memberLimit: null,
        // 培训项目名称
        projectName: "",
        // 发布对象内容 如果type是部门(6002)就存储部门编号
        publishObjectContent: "",
        // 发布对象类型 6001-全部用户 6002-部门
        publishObjectType: 6001,
        // 培训地点
        trainingLocation: "",
        // 培训课程信息
        classInfoDTOs: []
      },
      // 表单校验规则
      ruleValidate: {
        projectName: [
          {
            required: true,
            message: "项目名称不能为空，且长度不能超过20位",
            max: 20
          }
        ],
        publishObjectType: [
          {
            required: true,
            message: "请选择发布对象",
            validator: (rule, value, callback) => {
              if (!value) {
                callback(new Error("请选择发布对象的类型"));
              } else if (value === 6001) {
                callback();
              } else {
                if (!this.formData.publishObjectContent) {
                  callback(new Error("请选择要发布的对象"));
                } else {
                  callback();
                }
              }
            }
          }
        ],
        trainingLocation: [
          {
            required: true,
            message: "请输入培训地点"
          }
        ],
        deadline: [
          {
            required: true,
            message: "请选择报名截止时间"
          }
        ]
      },
      // 发布对象类型的可选列表
      publishObjectTypeOptions: [
        { label: "全部用户", value: 6001 },
        { label: "部门", value: 6002 }
      ],
      // 发布对象的可选列表
      publishObjectContentOptions: [],
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        key: "",
        className: "modal-add-course"
      },
      // 日期选择器的禁止选择日期范围
      dateOption: {
        disabledDate(date) {
          if (!date) {
            return false;
          }
          return date.valueOf() < Date.now();
        }
      }
    };
  },
  mounted() {
    // 请求部门可选列表
    this.requireDeptOptions();
  },
  methods: {
    // 返回列表
    goBack() {
      this.clearFormData();
      this.$router.push({
        path: "/informationRelease",
        query: { activeTab: "unRelease" }
      });
    },
    // 点击发布
    clickPublish() {
      this.$log.INFO("发布");
      this.formData.classInfoDTOs = this.tableData;
      if (!this.testForm()) {
        return;
      }
      // 课程信息
      this.formData.classInfoDTOs = this.formData.classInfoDTOs.map(el => {
        return {
          classId: el.classId,
          projectClassapplyId: el.projectClassapplyId,
          trainingTimeStart: new Date(
            el.trainingDate + " " + el.trainingTimeStart
          ),
          trainingTimeEnd: new Date(el.trainingDate + " " + el.trainingTimeEnd)
        };
      });
      let tmpObj = Object.assign({}, this.formData);
      if (Array.isArray(tmpObj.publishObjectContent)) {
        tmpObj.publishObjectContent = tmpObj.publishObjectContent.join(",");
      }
      this.$axios
        .post("/api/projectPublish/publish", tmpObj)
        .then(res => {
          this.$Message.success("发布成功");
          // 返回列表
          this.goBack();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击添加课程
    clickAddCourse() {
      this.modalOption.title = "添加培训课程";
      this.modalOption.key = "apply";
      this.modalOption.modalVisiabal = true;
    },
    // 对话框可见性改变
    handleFatherVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
    },
    // 删除一条课程记录
    reduceRow(index) {
      if (this.formData.classInfoDTOs.length === 0) {
        this.$Message.error("项目至少包含一门培训课程");
        return false;
      }
      this.$store.commit("skb/deleteInformationSelectHistoryList", index);
    },
    // 表格内时间选择器发生改变的处理函数
    handleListTimeChange(arr, index) {
      let date = this.tableData[index].trainingDate,
        dateTime = new Date(date + " " + arr[0]);
      if (dateTime - new Date() < 168000000) {
        this.$Message.error("请保证预留充足的工作安排时间！");
      }
      this.$store.commit("skb/modifyInformationSelectHistoryListTime", {
        arr,
        index
      });
    },
    handleListDateChange(date, index) {
      this.$store.commit("skb/modifyInformationSelectHistoryListTime", {
        date,
        index
      });
    },
    // 校验表单
    testForm() {
      let sign = true;
      this.$refs.formValidate.validate(valid => {
        if (valid) {
          sign = true;
          return true;
        } else {
          sign = false;
          this.$Message.error("请填写完整后再尝试保存！");
          return false;
        }
      });
      if (this.formData.classInfoDTOs.length === 0) {
        this.$Message.error("项目至少包含一门培训课程");
        return false;
      }
      // 如果已经验证错误了，直接退出
      if (!sign) {
        return sign;
      }
      this.formData.classInfoDTOs.forEach(el => {
        if (!sign) {
          return;
        }
        if (el.trainingTimeEnd === "" || el.trainingDate === "") {
          this.$Message.error("请填写项目课程时间");
          sign = false;
          return;
        }
        if (this.formData.deadline - new Date() < 0) {
          this.$Message.error("报名截止时间不能早于当前时间");
          sign = false;
          return;
        }
        if (
          new Date(el.trainingDate + " " + el.trainingTimeStart) <
          this.formData.deadline
        ) {
          this.$Message.error("报名截止时间不能晚于第一门课程开始时间");
          sign = false;
          return;
        }
        if (
          new Date(el.trainingDate + " " + el.trainingTimeStart).getTime() ===
          new Date(el.trainingDate + " " + el.trainingTimeEnd).getTime()
        ) {
          this.$Message.error("课程开始时间不能等于结束时间");
          sign = false;
          return;
        }
        if (
          new Date(el.trainingDate + " " + el.trainingTimeStart) - new Date() <
          86400000
        ) {
          this.$Message.error("课程开始时间需晚于当前时间24h");
          sign = false;
          return;
        }
        this.formData.classInfoDTOs.forEach(obj => {
          if (
            new Date(el.trainingDate + " " + el.trainingTimeStart) >
              new Date(obj.trainingDate + " " + obj.trainingTimeStart) &&
            new Date(el.trainingDate + " " + el.trainingTimeStart) <
              new Date(obj.trainingDate + " " + obj.trainingTimeEnd)
          ) {
            sign = false;
            this.$Message.error("课程时间不能重叠");
          }
        });
      });
      return sign;
    },
    // 清空表单数据
    clearFormData() {
      // 清空表单
      this.$refs.formValidate.resetFields();
      this.formData = {
        // 报名截止日期
        deadline: "",
        // 人数限制
        memberLimit: null,
        // 培训项目名称
        projectName: "",
        // 发布对象内容 如果type是部门(6002)就存储部门编号
        publishObjectContent: "",
        // 发布对象类型 6001-全部用户 6002-部门
        publishObjectType: 6001,
        // 培训地点
        trainingLocation: "",
        // 培训课程信息
        classInfoDTOs: []
      };
    },
    // 请求部门可选列表
    requireDeptOptions() {
      this.$axios
        .get("/api/dept/select")
        .then(res => {
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data)) {
            console.error("部门下拉框数据获取失败");
            return false;
          }
          // 保存下拉列表数据
          this.publishObjectContentOptions = data;
        })
        .catch(error => {
          console.error(error.message);
        });
    }
  },
  computed: {
    // 返回课程培训记录
    tableData() {
      return this.$store.getters["skb/getInformationSelectHistoryList"];
    },
    // 延期时间过期禁用提交
    relay() {
      let sign = false;
      this.formData.classInfoDTOs.forEach(item => {
        let time = new Date(item.trainingDate + " " + item.trainingTimeStart);
        if (time - new Date() < 86400000) {
          sign = true;
        }
      });
      return sign;
    }
  },
  destroyed() {
    // 清空之前勾选保存的记录
    this.$store.commit("skb/updateInformationSelectHistoryList", []);
  }
};
</script>
<style lang="scss" scoped>
.informationUnReleasePublish {
  .content-left {
    display: flex;
    align-items: center;
    height: 100%;
  }
  .back {
    color: $theme;
    cursor: pointer;
  }
  .back.ivu-icon {
    font-size: 20px;
    margin-right: 5px;
    line-height: inherit;
  }
  span.back {
    font-size: 14px;
  }
  .content {
    height: calc(100vh - 184px);
    border-top: 1px solid $border-color;
    padding: 30px 20px;
    overflow: auto;
    .ivu-form-inline .ivu-form-item {
      width: 46%;
      &:first-child {
        width: 100%;
      }
    }
    .ivu-select-multiple {
      margin-left: $top;
    }
    /deep/ .ivu-table-body {
      .ivu-date-picker {
        width: 49%;
        &:not(:last-child) {
          margin-right: 5px;
        }
      }
      .ivu-date-picker-rel .ivu-input-wrapper {
        width: 100% !important;
        .ivu-input {
          text-align: center;
        }
      }
    }
    .my-table-title {
      background: #f8f8f9;
      height: $td-height;
      border: 1px solid $border-color;
      border-bottom: 0;
      margin-top: $top;
      td:first-child {
        font-weight: 900;
        padding-left: $top;
      }
      td:last-child {
        padding-right: $top;
      }
    }
    .project-name {
      width: 80% !important;
    }
    .reduce {
      cursor: pointer;
      background: $error;
      margin: 0 auto;
      width: 24px;
      height: 24px;
      text-align: center;
      color: $white;
      border-radius: 50%;
      line-height: 20px;
      font-size: 30px;
    }
  }
}
</style>
<style lang="scss">
.ivu-picker-confirm {
  .ivu-btn:last-child {
    margin-left: $top;
  }
}
</style>
