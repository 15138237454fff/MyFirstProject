<template>
  <div class="leaveAduited">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入姓名"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right"></div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
      >
        <template slot="leaveClassList" slot-scope="{ row }">
          <template v-if="!row.leaveClassList.includes(null)">
            <i-tooltip
              :content="
                row.leaveClassList
                  .map(el => {
                    return `${el.className}\n（${$tagTime(
                      el.trainingTimeStart,
                      'yyyy-MM-dd HH:mm'
                    )} ~ ${$tagTime(el.trainingTimeEnd, 'HH:mm')}）`;
                  })
                  .join('\n')
              "
              :transfer="true"
              max-width="300px"
            >
              {{
                row.leaveClassList
                  .map(el => {
                    return `${el.className} (${$tagTime(
                      el.trainingTimeStart,
                      "yyyy-MM-dd HH:mm"
                    )} ~ ${$tagTime(el.trainingTimeEnd, "HH:mm")}) `;
                  })
                  .join("，")
              }}
            </i-tooltip>
          </template>
        </template>
        <template slot-scope="{ row }" slot="status">
          <span :class="row.status | statusFilter('class')">{{
            row.status | statusFilter("value")
          }}</span>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
  </div>
</template>
<script>
import { Button, Table, Input, Tooltip } from "view-design";
import myContentHead from "@/components/common/myContentHead";
import myPagination from "@/components/common/myPagination";
export default {
  name: "leaveAduited",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-input": Input,
    "i-tooltip": Tooltip,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true,
          width: 200
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          tooltip: true,
          width: 200
        },
        {
          title: "请假类型",
          align: "center",
          key: "leaveType",
          width: 100,
          render: (h, params) => {
            return h("span", params.row.leaveType === 0 ? "事假" : "病假");
          }
        },
        {
          title: "请假事由",
          align: "center",
          key: "leaveReason",
          tooltip: true
        },
        {
          title: "关联培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        {
          title: "请假课程",
          align: "center",
          slot: "leaveClassList",
          tooltip: true
        },
        {
          title: "申请时间",
          align: "center",
          tooltip: true,
          width: 180,
          render: (h, params) => {
            return h("span", params.row.applyTime);
          }
        },
        { title: "状态", align: "center", slot: "status", width: 120 }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求

      this.$axios
        .post("/api/attence/leaveReview/listReviewed", this.limitQuery)
        // this.$axios
        //   .post("/api/attence/leaveReview/listReviewed", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    }
  },
  filters: {
    statusFilter(value, type) {
      if (type === "class") {
        switch (value) {
          case 1:
            return "red";
          case 2:
            return "green";
          default:
            return "";
        }
      } else {
        switch (value) {
          case 1:
            return "未通过";
          case 2:
            return "通过";
          default:
            return "";
        }
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 50;
    }
  }
};
</script>
<style lang="scss" scoped>
.leaveAduited {
  .green {
    color: $success;
  }
  .red {
    color: $error;
  }
}
</style>
