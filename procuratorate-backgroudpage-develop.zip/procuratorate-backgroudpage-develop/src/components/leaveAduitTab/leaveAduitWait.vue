<template>
  <div class="courseDetail">
    <my-content-head>
      <div slot="left" class="left-content">
        <i-input
          size="large"
          suffix="ios-search"
          v-model="limitQuery.query"
          @keyup.enter.native="initLoadTable"
          placeholder="请输入姓名"
          style="width: 210px"
          clearable
          @on-clear="initLoadTable"
        />
        <i-button size="large" @click="initLoadTable">查询</i-button>
      </div>
      <div slot="right">
        <i-button
          size="large"
          @click="clickAllPass"
          type="primary"
          v-if="$btnAuthorityTest('attence:apply')"
          >一键通过</i-button
        >
        <i-button
          size="large"
          @click="clickAllFail"
          type="error"
          v-if="$btnAuthorityTest('attence:reject')"
          >一键不通过</i-button
        >
      </div>
    </my-content-head>
    <div class="content">
      <i-table
        :height="tableHeight"
        :data="tableData"
        :columns="colOption"
        :border="true"
        :loading="loading"
        @on-selection-change="handleSelectChange"
        ref="selection"
      >
        <template slot="leaveClassList" slot-scope="{ row }">
          <template v-if="!row.leaveClassList.includes(null)">
            <i-tooltip
              :content="
                row.leaveClassList
                  .map(el => {
                    return `${el.className}\n（${$tagTime(
                      el.trainingTimeStart,
                      'yyyy-MM-dd HH:mm'
                    )} ~ ${$tagTime(el.trainingTimeEnd, 'HH:mm')}）`;
                  })
                  .join('\n')
              "
              :transfer="true"
              max-width="300px"
            >
              {{
                row.leaveClassList
                  .map(el => {
                    return `${el.className} (${$tagTime(
                      el.trainingTimeStart,
                      "yyyy-MM-dd HH:mm"
                    )} ~ ${$tagTime(el.trainingTimeEnd, "HH:mm")}) `;
                  })
                  .join("，")
              }}
            </i-tooltip>
          </template>
        </template>
      </i-table>
    </div>
    <my-pagination
      @paginate="handlePaginate"
      :pageSize="limitQuery.pageSize"
      :pageNum="limitQuery.pageNum"
      :msgCount="msgCount"
    ></my-pagination>
    <my-modal v-bind="modalOption" @visiableChange="handleVisiableChange">
      <div class="modal-content">
        <p>是否不通过所有已选记录？</p>
        <p class="required">请输入不通过原因：</p>
        <i-input
          v-model="formData.content"
          size="large"
          placeholder="请输入"
          type="textarea"
          :autosize="{ minRows: 3, maxRows: 6 }"
        ></i-input>
      </div>
      <p slot="footer">
        <i-button size="large" @click="clickCancel">取消</i-button>
        <i-button size="large" type="primary" @click="clickOk">确定</i-button>
      </p>
    </my-modal>
  </div>
</template>
<script>
import { Button, Table, Input, Tooltip } from "view-design";
import myModal from "@/components/common/myModal";
import myContentHead from "@/components/common/myContentHead";
import myPagination from "@/components/common/myPagination";
export default {
  name: "courseDetail",
  components: {
    "i-table": Table,
    "i-button": Button,
    "i-input": Input,
    "i-tooltip": Tooltip,
    "my-modal": myModal,
    "my-pagination": myPagination,
    "my-content-head": myContentHead
  },
  data() {
    return {
      // 表格展示的数据
      tableData: [],
      // 表格显示的配置项
      colOption: [
        {
          align: "center",
          type: "selection",
          width: 50
        },
        {
          title: "姓名",
          align: "center",
          key: "name",
          tooltip: true,
          width: 160
        },
        {
          title: "所属部门",
          align: "center",
          key: "deptName",
          width: 180,
          tooltip: true
        },
        {
          title: "请假类型",
          align: "center",
          key: "leaveType",
          width: 100,
          render: (h, params) => {
            return h("span", params.row.leaveType === 0 ? "事假" : "病假");
          }
        },
        {
          title: "请假事由",
          align: "center",
          key: "leaveReason",
          tooltip: true
        },
        {
          title: "关联培训项目",
          align: "center",
          key: "projectName",
          tooltip: true
        },
        {
          title: "请假课程",
          align: "center",
          slot: "leaveClassList",
          tooltip: true
        },
        {
          title: "申请时间",
          align: "center",
          tooltip: true,
          width: 180,
          render: (h, params) => {
            return h("span", params.row.applyTime);
          }
        }
      ],
      // 分页查询的参数
      limitQuery: {
        query: "",
        pageSize: 15,
        pageNum: 1
      },
      // 消息总数量
      msgCount: 0,
      // 是否正在加载数据
      loading: false,
      // 待提交的表单数据
      formData: {
        // 退回理由
        content: ""
      },
      // 对话框配置项
      modalOption: {
        // 对话框显示状态
        modalVisiabal: false,
        // 标题内容
        title: "",
        className: "modal-leave-aduit-wait"
      },
      // 选中的记录列表
      selectedHistoryList: []
    };
  },
  mounted() {
    // 请求列表数据
    this.loadTable();
  },
  methods: {
    // 接收分页组件传递的分页数据，并调用加载数据方法
    handlePaginate(page) {
      // 解构出分页数据
      let { pageSize, pageNum } = page;
      // 保存到pageList中
      if (pageNum !== undefined) {
        this.limitQuery.pageNum = pageNum;
      }
      if (pageSize !== undefined) {
        this.limitQuery.pageSize = pageSize;
      }
      // 重新请求列表数据
      this.loadTable();
    },
    // 查询时初始化查询当前页
    initLoadTable() {
      this.limitQuery.pageNum = 1;
      this.loadTable();
    },
    loadTable() {
      // 列表加载状态
      this.loading = true;
      // 发送请求列表数据的请求
      this.$axios
        .post("/api/attence/leaveReview/listUnreviewed", this.limitQuery)
        .then(res => {
          // 取消列表加载状态
          this.loading = false;
          let data = res.data.data;
          // 获得的参数验证
          if (!data || !Array.isArray(data.list)) {
            console.error("列表数据获取失败");
            return false;
          }
          // 保存总条数
          this.msgCount = data.total;
          // 保存列表数据
          this.tableData = data.list;
        })
        .catch(error => {
          console.error(error.message);
          // 取消列表加载状态
          this.loading = false;
        });
    },
    // 点击一键通过
    clickAllPass() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.$store.commit("skb/updateConfirmModalOption", {
        title: "一键通过",
        msg: "是否通过所有已选记录？",
        modalVisiabal: true,
        handleOk: this.handleAllPass
      });
    },
    // 一键通过
    handleAllPass() {
      this.saveAllPass();
      this.$store.commit("skb/updateConfirmModalOption", {
        modalVisiabal: false
      });
    },
    // 保存一键通过的操作
    saveAllPass() {
      this.$axios
        .put("/api/attence/leaveReview/pass", this.selectedHistoryList)
        .then(res => {
          this.$Message.success("一键通过成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    clickAllFail() {
      if (this.selectedHistoryList.length === 0) {
        this.$Message.error("请选择一条数据！");
        return;
      }
      this.modalOption.title = "一键不通过";
      this.modalOption.modalVisiabal = true;
    },
    // 保存一键不通过的操作结果
    saveAllFail() {
      if (this.formData.content === "") {
        this.$Message.error("请填写不通过理由");
        return;
      }
      let tmpArr = this.selectedHistoryList.map(el => {
        return { leaveReviewId: el, rejectReason: this.formData.content };
      });
      this.$axios
        .put("/api/attence/leaveReview/reject", tmpArr)
        .then(res => {
          this.$Message.success("一键不通过成功");
          // 清空历史的勾选记录
          this.selectedHistoryList = [];
          this.loadTable();
        })
        .catch(error => {
          console.error(error.message);
        });
    },
    // 点击对话框的确定
    clickOk() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
      this.saveAllFail();
    },
    clickCancel() {
      // 隐藏模态框
      this.modalOption.modalVisiabal = false;
    },
    // 勾选变化的处理函数
    handleSelectChange(selection) {
      // 将选中值保存起来
      this.selectedHistoryList = selection.map(item => {
        return item.leaveReviewId;
      });
    },
    // 清空表单数据
    clearFormData() {
      this.formData = {
        // 退回理由
        content: ""
      };
    },
    // 接收子组件触发的模态框可见性改变事件
    handleVisiableChange(bool) {
      this.modalOption.modalVisiabal = bool;
      if (!bool) {
        // 清空表单
        this.clearFormData();
      }
    }
  },
  computed: {
    tableHeight() {
      return this.$store.getters["skb/getTableHeight"] - 50;
    }
  }
};
</script>
<style lang="scss" scoped>
.courseDetail {
  .ivu-btn-large:not(:last-child) {
    margin-right: $left;
  }
}
</style>
<style lang="scss">
.modal-leave-aduit-wait {
  .ivu-modal-body {
    text-align: center;
  }
  .ivu-modal {
    width: 16vw !important;
  }
  .modal-content {
    color: #333;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    p {
      line-height: 24px;
    }
    .ivu-input-wrapper {
      width: 100% !important;
    }
  }
}
</style>
