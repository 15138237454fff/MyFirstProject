<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style lang="scss">
// 设置全局输入框高度
.ivu-input-large {
  height: $btn-height !important;
}
.ivu-table td,
.ivu-table th {
  height: $td-height !important;
}
.ivu-tabs-nav {
  height: 40px;
  .ivu-tabs-tab {
    line-height: 24px;
  }
}
.ivu-tooltip {
  width: 100%;
  height: $btn-height;
  display: flex !important;
  align-items: center;
  .ivu-tooltip-rel {
    @extend .text-ellipsis;
  }
}
.ivu-table,
.ivu-modal-body,
.ivu-form-item-content,
.ivu-form .ivu-form-item-label {
  @extend .normal-font;
}
.ivu-form-item-error-tip {
  @extend .tip-font;
}
.ivu-form-item {
  &:not(.ivu-form-item-required) {
    margin-bottom: 20px;
  }
  &.ivu-form-item-required {
    margin-bottom: 20px;
  }
}
.ivu-date-picker-rel {
  .ivu-input-wrapper {
    width: 210px !important;
  }
}
a,
a:active,
a:visited {
  color: $theme;
}
pre {
  margin: 0;
  white-space: pre-wrap;
  tab-size: 4;
}
</style>
